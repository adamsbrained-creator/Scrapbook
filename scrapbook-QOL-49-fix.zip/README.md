# Scrapbook (v0.1)

A personal notes and archive app for Android: notes, quotes, links and photos with eight page layouts,
collections, search, a Rediscover swipe, per-page styling, a Settings page (theme, white or soft grey background,
accent, lists, boxes, backup/restore; seven box styles: Tabbed, Paper stack, Tinted tiles, Folder tabs, Chips, List rows, Notebook covers; and five looks for the Boxes screen: Default, Nested, Shelf, Cover, Stack), an About page (version, What's new, feedback, licenses, and links to the other apps in the family), a home-screen widget, and sharing into the app from other apps. The app reopens in the box you were last in (switch off in Settings). A scrap reopens with the cursor and scroll where you left them, and with the keyboard up if you were typing (`EditorSpots.kt`: view state kept on the phone, never inside the scrap). Deleted scraps go to a Bin for 30 days (Menu, then Bin) and every scrap keeps earlier versions of its text (3-dot menu, then Version history); every scrap can have its own icon, accent, page color, cover and layout (3-dot menu, then Page style), and its card in the lists is dressed to match (`NoteRow` and `NoteTile` in `ui/Home.kt`); both are plain Room tables, see `Versions.kt` for the rules. Inbox is where quick captures land; when scraps are waiting there, Home shows a To sort card that opens Sort Inbox (`ui/SortInbox.kt`: add to a box, keep close, delete or later, oldest first; the rules are in `Inbox.kt`). A scrap arriving in a hidden Inbox brings it back. Long-press a scrap on All scraps or in a box to pick several: `ui/Selecting.kt` has the toolbar (add to box, pin, tags, delete, each with one Undo), `Selection.kt` the plain rules, and the batch queries live in `Data.kt` and `ArchiveViewModel.kt`.

**Attachments:** photos (tap one to open the full-screen viewer, `ui/PhotoViewer.kt`) and files of any kind, up to 100 MB each. The editor's 3-dot menu has Attach file; files shared into the app from other apps are attached to a new scrap. A file is copied into `files/attachments/<id>/` and listed in the scrap's `files` column (`Attachments.kt` has the format); PDFs get a first-page thumbnail (`ui/Attachments.kt`, Android's own `PdfRenderer`). They are included in backups, searchable by file name, and cleaned up like photos when nothing uses them any more.

**Reading, writing, view only** (`ui/Editor.kt`): a scrap opens as a page to read, with no toolbar. Tapping the text (or the header) starts writing at that spot, a tap on a link opens it, and a tap on a checkbox ticks it. The book button in the header turns on **view only**: the editor is blocked until it is tapped again, and the choice is kept per scrap (`LockedScraps` and `EditorMemory.isLocked` in `EditorSpots.kt`, stored with the other view memory, never inside the scrap). Reading and writing use the same fields (the text field is just disabled while reading), so nothing moves between the modes. `vm.pendingEdit` makes the reading page's Edit button and a new duplicate open straight into writing.

**Arrange page** (`Blocks.kt`, `ui/Arrange.kt`): the page's photos, files and text can be put in any order, saved per scrap in `Item.blocks` (database version 16, `MIGRATION_15_16`; empty means the usual order) and in backups.

**Custom colors** (`Colors.kt`, `ui/RgbPicker.kt`): page color, page accent and the app accent can be any color. A custom page color or accent is stored in the same `Item.color` / `Item.accent` number as the ready-made ones: 0 is none, 1 to 5 are the ready-made colors, and `CustomColors.FLAG` (16777216) plus the color's 0xRRGGBB is a color of your own, so old scraps and backups need no change. Use `pageTint`, `pageAccent` and `noteColor` (never index `Sb.notes` with the number). The app accent is the setting `accent = -1` with the color in `accent_rgb`. The picker is two bars (hue, and black to white) that the editor's text color panel also uses (`GradientSlider`).

**Connected scraps** (`Connections.kt` has the rules, `ui/Connections.kt` the section and the picker): a link is the text `[words](scrapbook://scrap/<uid>)` (see `Links.kt`), so nothing is stored: for the scrap on screen, `Connections` works out the scraps it links to, the scraps that link to it (backlinks), titles written in the text but not linked (whole words, at least 4 letters, never inside a link, address or code; a longer title beats a shorter one, a newer scrap beats an older one with the same title) and scraps that share tags (a rare tag counts more). It runs off the main thread a moment after typing stops (`rememberConnections`). The picker (`LinkPickerSheet`, from the 3-dot menu or by typing `[[`, see `Connections.typedBrackets`) ranks scraps by context when nothing is typed. `ScrapInfo` is a plain copy of the facts the rules need, so they are unit tested without the database (`ConnectionsTest`). Settings has "Suggest links between scraps" for the two kinds of suggestion.

**Tags and filters:** a tag is a word on a scrap, independent of its box, so one tag can sit on scraps in any boxes (`Tags.kt`: tidying, counting, spelling and the card line). Tags are edited as pills in the editor's Details (`ui/TagEditor.kt`) and a tag in the editor header opens Search filtered to it. `Filters.kt` holds the one filter every list uses (type, box, tags, date; a scrap must pass all of them) and `ui/FilterSheet.kt` the Filter button and sheet; `Hashtags.kt` holds the rules for #words typed in a scrap becoming tags (what counts, the word still being typed, which ones are new), applied in `ui/Editor.kt` and switched in Settings; where the accent color shows inside text (list marks, links, hashtags) is chosen in Settings and read through `LocalTextColors` (`ui/TextColors.kt`) by the editor (`mdRender`) and the reading view (`ui/Pages.kt`); by default list marks take the color of their line's text (`TextMarks.kt`); smart paste (`SmartPaste.kt`) recognizes what was just pasted and offers a tidier form (link, quote, list, checklist, joined lines) through `ui/PasteHint.kt`, without changing anything by itself; All scraps, boxes and Search each keep their own filter.

## Get it on your phone

**Easiest, no tools to install (GitHub):**
1. Create a GitHub repository and push this folder to it (branch `main`).
2. Do the one-time key setup in `SIGNING.md` (about 10 minutes). This is what lets every new version
   install over the old one without deleting the app.
3. Open the repo's **Actions** tab, open the latest **Android CI** run, and download the
   `scrapbook-release-apk` artifact (a zip containing `app-release.apk`).
4. Copy the APK to your phone and open it. Android will ask you to allow installing from that source.

**With Android Studio:** open this folder, let Gradle sync, plug in a phone (USB debugging on) or start an
emulator, and press Run.

**From a phone, with a zip:** keep one zip of the whole project at the top of the repo, plus
`.github/workflows/scrapbook-zip.yml`. Uploading a new zip starts **Scrapbook (from zip)**, which unpacks it and builds
the signed APK (same key setup, see `SIGNING.md`). If there is more than one zip, the one uploaded last is built.

Install `scrapbook-release-apk` (`app-release.apk`): it is optimized (R8 and a baseline profile, see `app/proguard-rules.pro` and `app/src/main/baseline-prof.txt`) and much smoother than a debug build. `scrapbook-debug-apk` is only built when you press Run workflow on "Scrapbook (from zip)" and set "Also build debug" to yes; it updates over the release one with the same key, so it is easy to end up on it without noticing. If the optimized app ever misbehaves, run the workflow by hand with Optimize = no (or build with `-Pscrapbook.minify=false`); if the optimized build itself fails, the workflow builds an unoptimized release and says so in the run's Summary.
**Speed notes:** list cards show only the first part of a scrap's text (`previewHead` in `Share.kt`; the whole text is read only for Two Column cards and for search, through `cachedPreview`); date formats come from `Fmt` (`ui/Formats.kt`) instead of being built per card; the start-up clean-up (`sweepImages`, `pruneSpots`) waits 6 seconds.
**App icon:** a glass-pages icon in seven colors, one per accent (Coral, Teal, Amber, Violet, Green, Pink, Blue). The launcher entry is an
`<activity-alias>` per accent in `AndroidManifest.xml` (`.IconCoral` and so on); `AppIcon.kt` enables the one that matches the accent when the app
is left, and Settings has an "Icon matches accent" switch. To add an accent, add it to `Themes`, to `AppIcon.names`, and add an alias plus
`ic_launcher_<name>.xml` and `ic_launcher_bg_<name>.xml` (a unit test checks the lists agree).
**Motion:** `ui/Motion.kt` holds the small animation helpers (`pressScale`, `appear`); screen transitions are set on the `NavHost` in `MainActivity.kt`.

Fonts: see `FONTS.md`. Widget: long-press your home screen, Widgets, Scrapbook.

Search (`Search.kt`, `ui/Highlight.kt`): every typed word must appear somewhere in a scrap, in any order; matches are found in the original text (never a lowercased copy) so highlights cannot drift; results show a snippet around the first match. Used by the Search screen and the search bar inside a box.

Find in scrap (editor only): `FindInNote.kt` has the plain rules, `ui/FindBar.kt` the find bar, the back button that turns into a search button when held, and the highlight. Matches are searched in the shown text (without hidden marks), so they line up with what is drawn. Where it starts from is a setting (`findEntry`: hold back, 3-dot menu, or both).

Find in the reading view (`ui/Pages.kt`): the body is drawn as lines through `FText`; `FindState` (a composition local) numbers matches across lines and blocks (`runningStart`) so each line knows if it holds the current match and reports its position so the page scrolls to it. Same find bar, hold-back gesture and setting as the editor. Title and the Quote layout are not searched.


Links to scraps (`Links.kt`): scrapbook://scrap/<uid>. Every scrap has a permanent `Item.uid` (migration 14 to 15 gives existing scraps one; backups save it and restore keeps it unless it is already taken). `MainActivity.handleLink` turns a VIEW intent into `vm.linkRequest`, which AppRoot opens as the reading view. In notes, a scrapbook:// link (bare or [text](...)) is tappable and a bare one shows the target's current title (`LocalLinkTitle`).

Code and checklists: `inline code` and fenced blocks (three backticks) are literal, in monospace, and the rules live in `Markup.kt` (tested in `MarkupTest.kt`). Checklist icons are round: the editor leaves a blank of the right width and `drawEditorBackdrop` paints the circles (and the card behind a code block) on top; the reading view draws the same in `TaskBox` and `CodeCard`.
