package app.scrapbook.ui

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * A smooth shadow: three soft layers (a tight one close to the edge, a middle one and a wide faint one) instead of one hard blur. Deeper in dark mode, where
 * a shadow shows less. Use it on floating bars, cards and menus.
 */
fun Modifier.softShadow(shape: Shape): Modifier {
    val k = if (Sb.dark) 1.7f else 1f
    fun c(a: Float) = Color.Black.copy(alpha = (a * k).coerceAtMost(1f))
    return this
        .shadow(3.dp, shape, clip = false, ambientColor = c(.08f), spotColor = c(.10f))
        .shadow(12.dp, shape, clip = false, ambientColor = c(.08f), spotColor = c(.14f))
        .shadow(28.dp, shape, clip = false, ambientColor = c(.04f), spotColor = c(.10f))
}

/** The Growing card's own colors. Flat: no outline and no light overlay. In dark mode the pill is deep black and the cards a hair above it, so they read as one piece. */
val growPill: Color get() = if (Sb.dark) Color(0xFF000000) else Color(0xFF1F1F23)
val growCard: Color get() = if (Sb.dark) Color(0xFF050506) else Color(0xFF2A2A2F)
/** Text and icons on the pill and its dark cards. */
val growFg: Color get() = Color(0xFFF2F2F5)
/** A soft group or chip fill on the dark pill and cards. */
val growChip: Color get() = Color.White.copy(alpha = .07f)
