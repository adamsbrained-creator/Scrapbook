package app.scrapbook.ui

import android.content.Intent
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.snap
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.style.TextOverflow
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

@Composable
fun Field(v: String, onChange: (String) -> Unit, hint: String, size: TextUnit, font: FontFamily, weight: FontWeight = FontWeight.Normal, modifier: Modifier = Modifier) {
    BasicTextField(v, onChange, Modifier.fillMaxWidth().then(modifier),
        textStyle = TextStyle(fontSize = size, fontFamily = font, fontWeight = weight, color = Sb.ink, lineHeight = size * 1.4f),
        cursorBrush = SolidColor(LocalSb.current.acc), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
        decorationBox = { inner -> Box { if (v.isEmpty()) Text(hint, color = Sb.mute, fontSize = size, fontFamily = font, fontWeight = weight); inner() } })
}

/** What the editor shows for the raw text: the marks hidden, plus the maps between shown and saved positions. */
/** One checklist line: the saved offset of its "- [ ] ", whether it is ticked, and the color of its ring when it is not (see TextColors). */
private class CheckMark(val at: Int, val done: Boolean, val ring: Color)

private class MdView(val source: String, val out: TransformedText, val o2t: IntArray, private val lo: IntArray, private val hi: IntArray, val hidden: BooleanArray,
                     /** Every checklist line outside a code block. */
                     val checks: List<CheckMark> = emptyList(),
                     /** The saved range of every fenced code block, from its opening fence to the end of its closing fence. */
                     val blocks: List<IntRange> = emptyList()) {
    /** Saved offset for the start of a range: after any hidden opening marks. */
    fun start(t: Int) = hi[t.coerceIn(0, hi.lastIndex)]
    /** Saved offset for the end of a range: before any hidden closing marks. */
    fun end(t: Int) = lo[t.coerceIn(0, lo.lastIndex)]
}

/** How long the last styling of the whole text took, in milliseconds. A long scrap shows it in the menu next to the word count, so slowness can be seen and compared. */
private var lastStyledMs = 0L

private const val DIVIDER_GLYPHS = "────────────────"

/** What stands in the text for a checklist's round icon: a blank one em wide. The icon itself is painted on top by drawEditorBackdrop. */
private const val CHECK_BLANK = "\u2003"

/**
 * What the renderer works out for one line that is not inside a code block, with positions inside the line: its styles, the marks to hide, the glyph that stands in for
 * a bullet or a divider, the cursor stops of an empty ** pair, and the checklist icon. It depends on nothing but the line (and the look parameters), so it is kept.
 */
private class LineData(
    val spans: List<AnnotatedString.Range<SpanStyle>>, val para: ParagraphStyle?,
    /** Triples: from, to, 1 if the run is a closing mark. */
    val hides: IntArray, val repl: Pair<Int, String>?, val mids: IntArray, val check: CheckMark?,
)

/** The lines worked out so far. It starts over when the look changes, and when it holds more lines than any scrap needs. */
private object MdCache {
    private var params: List<Any?> = emptyList()
    private val lines = HashMap<String, LineData>()
    @Synchronized fun get(params: List<Any?>, key: String, make: () -> LineData): LineData {
        if (params != this.params) { lines.clear(); this.params = params }
        if (lines.size > 8000) lines.clear()
        return lines.getOrPut(key, make)
    }
}

private fun lineData(line: String, push: Float, acc: Color, baseLine: Float, tc: TextColors, hl: SpanStyle): LineData {
    val len = line.length
    val ml = maskCodeSpans(line)   // the line with code spans blanked out, so nothing inside code is taken for formatting
    val (pfx, tags) = leadOf(line)
    val styled = buildAnnotatedString {
        append(line)
        val st: SpanStyle? = when {
            line.startsWith("## ") -> SpanStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold)
            line.startsWith("# ") -> SpanStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold)
            line.startsWith("> ") -> SpanStyle(fontStyle = FontStyle.Italic, color = Sb.mute)
            line.startsWith("- [x] ") -> SpanStyle(textDecoration = TextDecoration.LineThrough, color = Sb.mute)
            line == "---" -> SpanStyle(color = Sb.mute)
            else -> null
        }
        if (st != null && line.isNotEmpty()) addStyle(st, if (line.startsWith("- [x] ")) 5 else 0, len)   // a ticked item is struck through after its icon, not across it
        // Bullets and boxes have the color of the line's text (the normal text color, or the color the text was given), unless Settings says accent.
        // A ticked box is dimmed like its ticked text.
        val rest = line.substring((pfx.length + tags.length).coerceAtMost(len))
        val ticked = line.startsWith("- [x] ")
        val markColor = if (tc.marksAccent) acc else leadingTextColor(rest)?.let { hexColor(it) } ?: if (ticked) Sb.mute else Sb.ink
        if (line.startsWith("- [ ] ") || ticked) addStyle(SpanStyle(color = markColor, fontWeight = FontWeight.Bold), 0, 5)
        else if (line.startsWith("- ")) addStyle(SpanStyle(color = markColor, fontWeight = FontWeight.Bold), 0, 1)
        // Numbered lists keep the normal text color on purpose.
        // #words that count as tags get the accent color (unless Settings says otherwise). This comes before the color spans on purpose: a hashtag
        // the person colored with the text color tool keeps the color they gave it.
        if (tc.colorHashtags) hashtagRanges(ml).forEach { r -> addStyle(SpanStyle(color = acc), r.first, r.last + 1) }
        val linkColor = if (tc.linksAccent) acc else Color.Unspecified
        styleInline(ml, 0, acc, hl); styleLinks(ml, 0, linkColor); styleSpans(ml, 0); styleBareLinks(ml, 0, linkColor); styleCode(line, 0)
    }
    // Alignment, indent and the taller lines big text needs are paragraph styles; each covers its line and the line break after it.
    val (ind, al) = tagsOf(tags)
    val big = SPAN_RE.findAll(ml).maxOfOrNull { parseSpanAttrs(it.groupValues[1]).size ?: 0 } ?: 0
    val tall = big * 1.3f > baseLine
    val para = if (ind > 0 || al != 'l' || tall || push > 0f) ParagraphStyle(
        textAlign = when (al) { 'c' -> TextAlign.Center; 'r' -> TextAlign.End; else -> TextAlign.Unspecified },
        lineHeight = if (tall) (big * 1.3f).sp else TextUnit.Unspecified,
        textIndent = if (ind > 0 || push > 0f) TextIndent((24 * ind + push).sp, (24 * ind + push).sp) else null) else null

    // Which characters of the line are hidden or swapped for a glyph.
    val hides = ArrayList<Int>(); val mids = ArrayList<Int>()
    fun hideRun(from: Int, to: Int, isClosing: Boolean) { hides.add(from); hides.add(to); hides.add(if (isClosing) 1 else 0) }
    fun inline(s: String, off: Int) {
        for (m in INLINE.findAll(s)) {
            val g = m.groupValues; val s0 = off + m.range.first; val e0 = off + m.range.last + 1
            val mk = if (g[4].isNotEmpty()) 1 else 2; val inner = innerOf(g)
            // "2 * 3 * 4" is not italic: a single * next to a space stays visible.
            val spaced = g[4].isNotEmpty() && (inner.first().isWhitespace() || inner.last().isWhitespace())
            if (!spaced) { hideRun(s0, s0 + mk, false); hideRun(e0 - mk, e0, true) }
            inline(inner, s0 + mk)
        }
    }
    var repl: Pair<Int, String>? = null; var check: CheckMark? = null
    when {
        line.startsWith("## ") || line.startsWith("# ") || line.startsWith("> ") -> hideRun(0, pfx.length, false)
        line.startsWith("- [ ] ") || line.startsWith("- [x] ") -> {
            repl = 5 to CHECK_BLANK
            // The ring is grey, like the empty circle of a to-do app, unless Settings says accent or the line's text was colored: then it follows that.
            val ring = if (tc.marksAccent) acc else leadingTextColor(line.substring((pfx.length + tags.length).coerceAtMost(len)))?.let { hexColor(it) } ?: Sb.mute
            check = CheckMark(0, line.startsWith("- [x] "), ring)
        }
        line.startsWith("- ") -> repl = 1 to "•"
        line == "---" -> repl = 3 to DIVIDER_GLYPHS
    }
    if (tags.isNotEmpty()) hideRun(pfx.length, pfx.length + tags.length, false)
    for (m in EMPTY_SPAN.findAll(ml)) hideRun(m.range.first, m.range.last + 1, false)   // a color or size with nothing left in it is never shown
    if (ml.length > 4) for (m in EMPTY_PAIR.findAll(ml)) { hideRun(m.range.first, m.range.last + 1, false); mids.add(m.range.first + 2) }
    inline(ml, 0)
    for (m in SPAN_RE.findAll(ml)) {
        val cr = m.groups[2]!!.range
        hideRun(m.range.first, cr.first, false); hideRun(cr.last + 1, m.range.last + 1, true)
    }
    for (m in LINK.findAll(ml)) {
        val s0 = m.range.first; val e0 = m.range.last + 1
        hideRun(s0, s0 + 1, false); hideRun(s0 + 1 + m.groupValues[1].length, e0, true)
    }
    // `code`: the backticks are hidden, the text between them stays.
    for (m in CODE_SPAN.findAll(line)) { val s0 = m.range.first; val e0 = m.range.last + 1; hideRun(s0, s0 + 1, false); hideRun(e0 - 1, e0, true) }
    return LineData(styled.spanStyles, para, hides.toIntArray(), repl, mids.toIntArray(), check)
}

/**
 * Styles the text as you type and hides the markdown marks. Line prefixes (# , ## , > ) are always hidden, bullets are drawn as •, a checkbox
 * leaves a blank of the right width for the round icon that drawEditorBackdrop paints, and inline marks (** ~~ == * ` , {color|size|underline} and
 * the [ ](url) of a link) are always hidden. Code is literal: inside a fenced block or a `code span` nothing else is formatted.
 * The saved text is never changed; the returned maps translate between saved and shown positions.
 */
private fun mdRender(text: String, acc: Color, baseLine: Float, tc: TextColors = TextColors(), wrapSp: Map<Int, Float> = emptyMap(), remnant: IntRange? = null, hl: SpanStyle = markerStyle(acc)): MdView {
    val n = text.length
    val lines = text.split("\n")
    val cs = codeLineStates(lines)
    // Everything that makes a line look the way it does besides its own text: when one of these changes, what was worked out for the lines is thrown away.
    val params = listOf<Any?>(acc, baseLine, tc, hl, Sb.ink, Sb.mute)
    val sp = ArrayList<AnnotatedString.Range<SpanStyle>>(); val pp = ArrayList<AnnotatedString.Range<ParagraphStyle>>()
    // Which saved characters are hidden or swapped for a glyph.
    val hide = BooleanArray(n); val closing = BooleanArray(n); val repl = arrayOfNulls<Pair<Int, String>>(n); val mids = mutableListOf<Int>()
    fun hideRun(from: Int, to: Int, isClosing: Boolean) { for (k in from until minOf(to, n)) { hide[k] = true; closing[k] = isClosing } }
    var i = 0
    val checks = mutableListOf<CheckMark>(); val blocks = mutableListOf<IntRange>(); var blockStart = 0
    for ((li, line) in lines.withIndex()) {
        val le = i + line.length
        val push = wrapSp[li] ?: 0f   // a line beside a wrapped photo or file is pushed in from the left by the width of the object (see Floats.indents)
        if (cs[li] != CodeLine.NONE) {
            // Inside a fenced block everything is literal: monospace, no formatting. The tinted card is painted behind the text by drawEditorBackdrop.
            if (line.isNotEmpty()) sp += AnnotatedString.Range(SpanStyle(fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = if (cs[li] == CodeLine.BODY) Color.Unspecified else Sb.mute), i, i + line.length)
            pp += AnnotatedString.Range(ParagraphStyle(textIndent = TextIndent((10f + push).sp, (10f + push).sp)), i, minOf(i + line.length + 1, n))
            if (cs[li] == CodeLine.OPEN) blockStart = i
            if (cs[li] == CodeLine.CLOSE) blocks += blockStart until le
            i = le + 1; continue
        }
        // A line of text depends only on itself, so what the renderer worked out for it is kept: typing in a long scrap works out the one line that changed, not all of them.
        val d = MdCache.get(params, "$push|$line") { lineData(line, push, acc, baseLine, tc, hl) }
        for (r in d.spans) sp += AnnotatedString.Range(r.item, r.start + i, r.end + i)
        d.para?.let { pp += AnnotatedString.Range(it, i, minOf(i + line.length + 1, n)) }
        // What is left of a mark that is being deleted (see remStart in the editor) is hidden, and the line is plain text from there.
        if (remnant != null && remnant.first == i) { hideRun(i, i + remnant.last + 1 - remnant.first, false); i = le + 1; continue }
        var h = 0
        while (h < d.hides.size) { hideRun(i + d.hides[h], i + d.hides[h + 1], d.hides[h + 2] == 1); h += 3 }
        d.repl?.let { if (i < n) repl[i] = it }
        for (m in d.mids) mids += i + m
        d.check?.let { checks += CheckMark(i, it.done, it.ring) }
        i = le + 1
    }

    // Shown text, and where every saved offset lands in it.
    val shown = StringBuilder(); val o2t = IntArray(n + 1)
    var k = 0
    while (k < n) {
        val r = repl[k]
        if (r != null) {
            o2t[k] = shown.length; shown.append(r.second)
            for (j in 1 until r.first) o2t[k + j] = shown.length
            k += r.first
        } else {
            o2t[k] = shown.length
            if (!hide[k]) shown.append(text[k])
            k++
        }
    }
    o2t[n] = shown.length
    val m = shown.length
    // Back again: several saved offsets can share one shown offset (next to hidden marks). Opening marks put the cursor
    // after them (inside the formatting), closing marks before them.
    val lo = IntArray(m + 1) { Int.MAX_VALUE }; val hi = IntArray(m + 1) { -1 }; val allOpen = BooleanArray(m + 1) { true }
    for (j in 0..n) { val t = o2t[j]; if (j < lo[t]) lo[t] = j; if (j > hi[t]) hi[t] = j }
    for (j in 0 until n) if (hide[j] && closing[j]) allOpen[o2t[j]] = false
    for (t in 1..m) if (hi[t] < 0) { lo[t] = lo[t - 1]; hi[t] = hi[t - 1] }
    val pick = IntArray(m + 1) { if (allOpen[it]) hi[it] else lo[it] }
    for (p in mids) if (p <= n) pick[o2t[p]] = p   // the cursor of an empty **|** pair stays between its marks

    val shownText = buildAnnotatedString {
        append(shown.toString())
        for (r in sp) {
            val s = o2t[r.start.coerceIn(0, n)]; val e = o2t[r.end.coerceIn(0, n)]
            if (e > s) addStyle(r.item, s, e)
        }
        for (r in pp) {
            val s = o2t[r.start.coerceIn(0, n)]; val e = o2t[r.end.coerceIn(0, n)]
            if (e > s) addStyle(r.item, s, e)
        }
    }
    val map = object : OffsetMapping {
        override fun originalToTransformed(offset: Int) = o2t[offset.coerceIn(0, n)]
        override fun transformedToOriginal(offset: Int) = pick[offset.coerceIn(0, m)]
    }
    return MdView(text, TransformedText(shownText, map), o2t, lo, hi, hide, checks, blocks)
}

private val EMPTY_PAIR = Regex("\\*\\*\\*\\*|~~~~|====")

/**
 * The top of every line of the saved text (a line is a paragraph, up to its line break) in px from the top of the text field: where the text beside a
 * placed photo or file starts, and where a wrapped one sits. Empty until the field has been laid out.
 */
private fun lineTopsOf(lay: TextLayoutResult?, v: MdView): List<Float> {
    if (lay == null) return emptyList()
    val len = lay.layoutInput.text.length
    val out = ArrayList<Float>(); var start = 0
    while (true) {
        val shown = v.o2t[start.coerceIn(0, v.o2t.lastIndex)].coerceIn(0, len)
        out.add(lay.getLineTop(lay.getLineForOffset(shown)))
        val nl = v.source.indexOf('\n', start)
        if (nl < 0) break
        start = nl + 1
    }
    return out
}

/** The photos and files that are placed (wrapped or free), with what they are, photos first. Each photo address and file path counts once. */
private fun floatItemsOf(placed: Map<String, Placed>, imgs: List<String>, files: List<Attachment>): List<FloatItem> {
    if (placed.isEmpty()) return emptyList()
    val out = ArrayList<FloatItem>(); val seen = HashSet<String>()
    for (u in imgs) { val k = Floats.photoKey(u); val p = placed[k]; if (p != null && p.how != Placing.Inline && seen.add(k)) out.add(FloatItem(k, u, null, p)) }
    for (a in files) { val k = Floats.fileKey(a.path); val p = placed[k]; if (p != null && p.how != Placing.Inline && seen.add(k)) out.add(FloatItem(k, null, a, p)) }
    return out
}
/** The saved offset of the line start whose round checklist icon is under the finger, or null. */
private fun checkboxAt(lay: TextLayoutResult, v: MdView, p: Offset, pad: Float): Int? {
    for (mark in v.checks) {
        val at = mark.at; val t = v.o2t[at.coerceIn(0, v.o2t.lastIndex)]
        if (t >= lay.layoutInput.text.length) continue
        val box = lay.getBoundingBox(t)
        if (p.x >= box.left - pad && p.x <= box.right + pad && p.y >= box.top && p.y <= box.bottom) return at
    }
    return null
}

/** Paints what text alone cannot: the round checklist icons, and a tinted card behind every fenced code block. Coordinates are the text field's own. */
private fun DrawScope.drawEditorBackdrop(lay: TextLayoutResult, v: MdView, acc: Color) {
    val shownLen = lay.layoutInput.text.length
    val blockTint = Sb.mute.copy(alpha = .14f)
    for (r in v.blocks) {
        val t0 = v.o2t[r.first.coerceIn(0, v.o2t.lastIndex)].coerceIn(0, shownLen); val t1 = v.o2t[(r.last + 1).coerceIn(0, v.o2t.lastIndex)].coerceIn(0, shownLen)
        val top = lay.getLineTop(lay.getLineForOffset(t0)) - 3.dp.toPx(); val bottom = lay.getLineBottom(lay.getLineForOffset(t1)) + 3.dp.toPx()
        drawRoundRect(blockTint, Offset(0f, top), Size(size.width, bottom - top), CornerRadius(12.dp.toPx()))
    }
    val sw = 1.6.dp.toPx(); val tick = if (acc.luminance() > .5f) Color(0xFF1A1A1A) else Color.White
    for (mark in v.checks) {
        val t = v.o2t[mark.at.coerceIn(0, v.o2t.lastIndex)]
        if (t >= shownLen) continue
        val box = lay.getBoundingBox(t); val d = box.width * 1.04f; val rad = d / 2f - sw / 2f
        // The icon sits on the middle of the letters, not the middle of the (taller) line.
        val ctr = Offset(box.left + box.width / 2f, lay.getLineBaseline(lay.getLineForOffset(t)) - 17.sp.toPx() * .36f)
        if (mark.done) {
            drawCircle(acc, rad + sw / 2f, ctr)
            val p = Path().apply { moveTo(ctr.x - d * .24f, ctr.y + d * .02f); lineTo(ctr.x - d * .07f, ctr.y + d * .19f); lineTo(ctr.x + d * .26f, ctr.y - d * .17f) }
            drawPath(p, tick, style = Stroke(width = sw * 1.15f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        } else drawCircle(mark.ring, rad, ctr, style = Stroke(width = sw))
    }
}

/** Backspaces closer together than this are one held key; a gap longer than this is a new press. */
private const val HOLD_BACK_MS = 250L

/**
 * The start of the cursor's line when that line is only a hidden mark (a list, checklist, quote or heading mark with no text after it) and the cursor
 * is at its end: the line the keyboard has just deleted a character from. Null for any other line.
 */
private fun emptyMarkLine(before: TextFieldValue): Int? {
    val s = before.text; val pos = before.selection.start
    if (!before.selection.collapsed || pos < 1 || pos > s.length) return null
    val ls = s.lastIndexOf('\n', pos - 1) + 1
    val le = s.indexOf('\n', ls).let { if (it < 0) s.length else it }
    if (le != pos || s.substring(ls, le) !in LINE_PREFIXES || codeStateAt(s, pos) != CodeLine.NONE) return null
    return ls
}

private val PASTED_URL = Regex("^https?://\\S+$")

/**
 * Smart edits on top of plain typing: pasting a web address over selected text makes it a link, and backspace never
 * eats a hidden mark: at the start of a list, heading or quote it removes the whole mark in one go, elsewhere it skips over them.
 */
private fun smartEdit(old: TextFieldValue, new: TextFieldValue, view: MdView?): TextFieldValue {
    var r = smartEditCore(old, new, view)
    // Deleting a selection (or typing over it) that takes one end of a bold, highlight or color with it must not leave the other end behind as plain symbols.
    if (r.selection.collapsed && r.text != old.text) {
        val o = old.text; val t = r.text; val m = minOf(o.length, t.length)
        var p = 0; while (p < m && o[p] == t[p]) p++
        var q = 0; while (q < m - p && o[o.length - 1 - q] == t[t.length - 1 - q]) q++
        val b = o.length - q
        if (b > p) replaceHealingMarks(o, p, b, t.substring(p, t.length - q)) { codeStateAt(o, it) != CodeLine.NONE }?.let { (nt, c) -> r = r.copy(text = nt, selection = TextRange(c)) }
    }
    // Deleting the last letter inside bold, a highlight or a color leaves marks with nothing in them, which would show as plain symbols: they go too.
    if (r.text.length < old.text.length && r.selection.collapsed && codeStateAt(r.text, r.selection.start) == CodeLine.NONE)
        dropEmptyMarks(r.text, r.selection.start)?.let { (t, c) -> return r.copy(text = t, selection = TextRange(c)) }
    return r
}

private fun smartEditCore(old: TextFieldValue, new: TextFieldValue, view: MdView?): TextFieldValue {
    val os = old.selection; val a = minOf(os.start, os.end); val b = maxOf(os.start, os.end)
    if (a != b && new.selection.collapsed) {
        val ins = new.text.length - (old.text.length - (b - a))
        if (ins > 0 && new.selection.start == a + ins && new.text.startsWith(old.text.substring(0, a)) && new.text.endsWith(old.text.substring(b))) {
            val pasted = new.text.substring(a, a + ins); val label = old.text.substring(a, b)
            if (PASTED_URL.matches(pasted) && label.none { it == '\n' || it == '[' || it == ']' })
                return new.copy(text = old.text.substring(0, a) + "[$label]($pasted)" + old.text.substring(b), selection = TextRange(a + 1, a + 1 + label.length))
        }
    }
    if (os.collapsed && new.text.length == old.text.length - 1 && new.selection.collapsed && new.selection.start == os.start - 1) {
        val s = old.text; val pos = os.start
        val ls = s.lastIndexOf('\n', pos - 1) + 1; val le = s.indexOf('\n', ls).let { if (it < 0) s.length else it }
        val line = s.substring(ls, le)
        val inCode = codeStateAt(s, pos) != CodeLine.NONE   // code is literal: nothing in it is a hidden mark
        val hidden = if (inCode) "" else LINE_PREFIXES.firstOrNull { line.startsWith(it) }.orEmpty()
        val numPfx = if (hidden.isEmpty() && !inCode) NUM.find(line)?.value.orEmpty() else ""
        val tags = if (inCode) "" else LINE_TAGS.find(line.substring(hidden.length + numPfx.length))?.value.orEmpty()
        if (hidden.length + numPfx.length + tags.length > 0 && pos == ls + hidden.length + numPfx.length + tags.length) {
            // The mark in front of the text is hidden, so one backspace removes all of it: the prefix first, then the layout tags.
            val from = if (hidden.isNotEmpty()) ls else ls + numPfx.length
            val to = if (hidden.isNotEmpty()) ls + hidden.length else if (tags.isNotEmpty()) from + tags.length else from
            if (to > from) return new.copy(text = s.removeRange(from, to), selection = TextRange(pos - (to - from)))
        }
        // A divider is hidden behind a drawn line: backspace right after it removes the whole thing.
        if (!inCode && line == "---" && pos == le) return new.copy(text = s.removeRange(ls, le), selection = TextRange(ls))
        // An empty pair of marks (left by Bold, Italic or Strike with nothing selected) goes in one backspace.
        if (!inCode) for (pair in listOf("****", "~~~~", "====")) if (pos >= 2 && s.startsWith(pair, pos - 2)) return new.copy(text = s.removeRange(pos - 2, pos + 2), selection = TextRange(pos - 2))
        if (!inCode && pos >= 1 && pos < s.length && s[pos - 1] == '*' && s[pos] == '*' && (pos < 2 || s[pos - 2] != '*') && (pos + 1 >= s.length || s[pos + 1] != '*'))
            return new.copy(text = s.removeRange(pos - 1, pos + 1), selection = TextRange(pos - 1))
        // Hidden marks are never deleted by accident: backspace skips over them and removes the visible character before.
        // The cursor then waits right after the character that is now last (in front of the marks), not behind them. Looks the same on screen, and the
        // next backspace needs no rewriting: the keyboard's own text goes through untouched, so holding backspace keeps repeating instead of stopping
        // at every character next to a bold, link or heading mark.
        if (view != null && view.source == s && pos >= 1 && view.hidden[pos - 1]) {
            var idx = pos - 1; while (idx >= 0 && view.hidden[idx]) idx--
            return if (idx < 0) old else new.copy(text = s.removeRange(idx, idx + 1), selection = TextRange(idx))
        }
    }
    return new
}

private val NUM = Regex("^(\\d+)\\. ")
private val INLINE = Regex("\\*\\*(.+?)\\*\\*|~~(.+?)~~|==(.+?)==|\\*(.+?)\\*")
private val LINK = Regex("\\[([^\\]\\n]+)\\]\\(([^)\\s]*)\\)")

/** Which marker an INLINE match used: "**", "~~", "==" or "*". */
private fun markerOf(g: List<String>) = when { g[1].isNotEmpty() -> "**"; g[2].isNotEmpty() -> "~~"; g[3].isNotEmpty() -> "=="; else -> "*" }
private fun innerOf(g: List<String>) = g[1].ifEmpty { g[2] }.ifEmpty { g[3] }.ifEmpty { g[4] }

/** Styles bold, strike, highlight and italic runs (also when nested) and dims their markers. */
private fun AnnotatedString.Builder.styleInline(s: String, off: Int, acc: Color, hl: SpanStyle) {
    for (m in INLINE.findAll(s)) {
        val g = m.groupValues; val s0 = off + m.range.first; val e0 = off + m.range.last + 1
        val mk = if (g[4].isNotEmpty()) 1 else 2
        val st2 = when {
            g[1].isNotEmpty() -> SpanStyle(fontWeight = FontWeight.Bold)
            g[2].isNotEmpty() -> SpanStyle(textDecoration = TextDecoration.LineThrough)
            g[3].isNotEmpty() -> hl   // the highlighter as set in the color panel (with the accent: the page's own accent, not the one deepened for reading text, so it is alike on light and dark pages)
            else -> SpanStyle(fontStyle = FontStyle.Italic)
        }
        addStyle(st2, s0, e0); addStyle(SpanStyle(color = Sb.mute), s0, s0 + mk); addStyle(SpanStyle(color = Sb.mute), e0 - mk, e0)
        styleInline(innerOf(g), s0 + mk, acc, hl)
    }
}

/** {c:ff0000 s:20 u|text}: color, size and underline for the text, the braces and attributes dimmed (they are hidden unless the cursor is in them). */
private fun AnnotatedString.Builder.styleSpans(s: String, off: Int) {
    for (m in SPAN_RE.findAll(s)) {
        val a = parseSpanAttrs(m.groupValues[1]); val s0 = off + m.range.first; val e0 = off + m.range.last + 1
        val cr = m.groups[2]!!.range; val cs = off + cr.first; val ce = off + cr.last + 1
        addStyle(SpanStyle(color = a.color?.let { hexColor(it) } ?: Color.Unspecified, fontSize = a.size?.sp ?: TextUnit.Unspecified,
            textDecoration = if (a.underline) TextDecoration.Underline else null), cs, ce)
        addStyle(SpanStyle(color = Sb.mute), s0, cs); addStyle(SpanStyle(color = Sb.mute), ce, e0)
    }
}

/** A web address written out in a line looks like a link too (underlined, in the accent color), the same as in the reading view. */
private fun AnnotatedString.Builder.styleBareLinks(s: String, off: Int, acc: Color) {
    for (r in bareUrlRanges(s)) addStyle(SpanStyle(color = acc, textDecoration = TextDecoration.Underline), off + r.first, off + r.last + 1)
}

/** `code`: monospace on a faint tint; the backticks are dimmed (and hidden). */
private fun AnnotatedString.Builder.styleCode(line: String, off: Int) {
    for (m in CODE_SPAN.findAll(line)) {
        val s0 = off + m.range.first; val e0 = off + m.range.last + 1
        addStyle(SpanStyle(fontFamily = FontFamily.Monospace, fontSize = 15.sp, background = Sb.mute.copy(alpha = .18f)), s0 + 1, e0 - 1)
        addStyle(SpanStyle(color = Sb.mute), s0, s0 + 1); addStyle(SpanStyle(color = Sb.mute), e0 - 1, e0)
    }
}

/** [text](url): the text looks like a link, the brackets and address are dimmed. */
private fun AnnotatedString.Builder.styleLinks(s: String, off: Int, acc: Color) {
    for (m in LINK.findAll(s)) {
        val s0 = off + m.range.first; val e0 = off + m.range.last + 1; val len = m.groupValues[1].length
        addStyle(SpanStyle(color = Sb.mute), s0, s0 + 1)
        addStyle(SpanStyle(color = acc, textDecoration = TextDecoration.Underline), s0 + 1, s0 + 1 + len)
        addStyle(SpanStyle(color = Sb.mute), s0 + 1 + len, e0)
    }
}

private val LINE_PREFIXES = listOf("## ", "# ", "> ", "- [x] ", "- [ ] ", "- ")

/** Adds, switches or removes a line prefix (heading, quote, bullet, checklist, number) on the cursor's line, or on every line of the selection (see toggleLines). */
private fun TextFieldValue.toggleLine(prefix: String): TextFieldValue {
    val r = toggleLines(text, selection.start, selection.end, prefix)
    return copy(text = r.text, selection = if (selection.start <= selection.end) TextRange(r.start, r.end) else TextRange(r.end, r.start))
}

private fun TextFieldValue.wrap(marker: String): TextFieldValue {
    val a = minOf(selection.start, selection.end).coerceIn(0, text.length); val b = maxOf(selection.start, selection.end).coerceIn(0, text.length)
    val m = marker.length; val sel = text.substring(a, b)
    // Over several lines every line gets its own pair: one pair across a line break would be shown as plain symbols.
    if ('\n' in sel) return wrapEachLine(text, a, b, marker) { leadOf(it).let { (p, t) -> p.length + t.length } }?.let { (t, x, y) -> copy(text = t, selection = TextRange(x, y)) } ?: this
    val partOfBold = m == 1 && ((a >= 2 && text[a - 2] == '*') || (b + 2 <= text.length && text[b + 1] == '*'))
    if (!partOfBold && a >= m && b + m <= text.length && text.substring(a - m, a) == marker && text.substring(b, b + m) == marker)
        return copy(text = text.substring(0, a - m) + sel + text.substring(b + m), selection = TextRange(a - m, b - m))
    return copy(text = text.substring(0, a) + marker + sel + marker + text.substring(b), selection = TextRange(a + m, b + m))
}

private fun TextFieldValue.insertDivider(): TextFieldValue {
    val pos = selection.start.coerceIn(0, text.length); val before = text.substring(0, pos)
    val ins = (if (before.isEmpty() || before.endsWith("\n")) "" else "\n") + "---\n"
    return copy(text = before + ins + text.substring(pos), selection = TextRange(pos + ins.length))
}

private fun marks(s: String, off: Int, out: MutableList<Pair<String, IntRange>>) {
    for (r in INLINE.findAll(s)) {
        val g = r.groupValues; val mk = markerOf(g); val from = off + r.range.first
        out += mk to (from until off + r.range.last + 1)
        marks(innerOf(g), from + mk.length, out)
    }
}

/** The pair of this marker ("**", "~~", "==" or "*") that surrounds the selection, as a range of the whole text. */
private fun TextFieldValue.enclosing(marker: String): IntRange? {
    val s = text; val a = minOf(selection.start, selection.end).coerceIn(0, s.length); val b = maxOf(selection.start, selection.end).coerceIn(0, s.length)
    val ls = s.lastIndexOf('\n', a - 1) + 1; val le = s.indexOf('\n', a).let { if (it < 0) s.length else it }
    val found = mutableListOf<Pair<String, IntRange>>(); marks(s.substring(ls, le), ls, found)
    val m = marker.length
    return found.firstOrNull { it.first == marker && a >= it.second.first + m && b <= it.second.last + 1 - m }?.second
}

/** Bold, italic, strike or highlight: removes the pair around the selection if there is one, otherwise wraps the selection. */
private fun TextFieldValue.toggleInline(marker: String): TextFieldValue {
    val r = enclosing(marker) ?: return wrap(marker)
    val m = marker.length; val a = minOf(selection.start, selection.end); val b = maxOf(selection.start, selection.end)
    return copy(text = text.substring(0, r.first) + text.substring(r.first + m, r.last + 1 - m) + text.substring(r.last + 1),
        selection = TextRange(a - m, b - m))
}

/** The line prefix on the cursor's line: "# ", "## ", "> ", "- ", "- [ ] ", "- [x] ", "1. " for any number, or null. */
private fun TextFieldValue.linePrefix(): String? {
    val s = text; val pos = selection.start.coerceIn(0, s.length)
    val ls = s.lastIndexOf('\n', pos - 1) + 1; val le = s.indexOf('\n', pos).let { if (it < 0) s.length else it }
    val line = s.substring(ls, le)
    return LINE_PREFIXES.firstOrNull { line.startsWith(it) } ?: NUM.find(line)?.let { "1. " }
}

private fun TextFieldValue.selRange(): Pair<Int, Int> = minOf(selection.start, selection.end).coerceIn(0, text.length) to maxOf(selection.start, selection.end).coerceIn(0, text.length)

/** The Code button for words: `backticks` around the selection (see toggleCodeSpan). */
private fun TextFieldValue.toggleCodeSpanHere(): TextFieldValue {
    val (a, b) = selRange(); val r = toggleCodeSpan(text, a, b) ?: return this
    return copy(text = r.text, selection = TextRange(r.start, r.end))
}

/** The Code block button: a fenced block around the selected lines, or the fences taken away when the cursor is in one (see toggleCodeBlock). */
private fun TextFieldValue.toggleCodeBlockHere(): TextFieldValue {
    val (a, b) = selRange(); val r = toggleCodeBlock(text, a, b)
    return copy(text = r.text, selection = TextRange(r.start, r.end))
}

/** One heading button: none, then heading, then subheading, then none again. */
private fun TextFieldValue.cycleHeading(): TextFieldValue = when (linePrefix()) { "# " -> toggleLine("## "); "## " -> toggleLine("## "); else -> toggleLine("# ") }

/** The [text](url) link around the selection, with its range in the whole text. */
private fun TextFieldValue.link(): Pair<IntRange, MatchResult>? {
    val s = text; val a = minOf(selection.start, selection.end).coerceIn(0, s.length); val b = maxOf(selection.start, selection.end).coerceIn(0, s.length)
    val ls = s.lastIndexOf('\n', a - 1) + 1; val le = s.indexOf('\n', a).let { if (it < 0) s.length else it }
    for (m in LINK.findAll(s.substring(ls, le))) {
        val from = ls + m.range.first; val to = ls + m.range.last + 1
        if (a >= from && b <= to) return (from until to) to m
    }
    return null
}

/** Turns the selected text into a link to url, or changes the address if the selection is already a link. */
private fun TextFieldValue.setLink(url: String): TextFieldValue {
    val found = link()
    if (found != null) {
        val (r, m) = found; val label = m.groupValues[1]
        return copy(text = text.substring(0, r.first) + "[$label]($url)" + text.substring(r.last + 1), selection = TextRange(r.first + 1, r.first + 1 + label.length))
    }
    val a = minOf(selection.start, selection.end).coerceIn(0, text.length); val b = maxOf(selection.start, selection.end).coerceIn(0, text.length)
    val label = text.substring(a, b).ifEmpty { url }
    if (label.any { it == '\n' || it == '[' || it == ']' }) return this
    return copy(text = text.substring(0, a) + "[$label]($url)" + text.substring(b), selection = TextRange(a + 1, a + 1 + label.length))
}

private fun TextFieldValue.removeLink(): TextFieldValue {
    val (r, m) = link() ?: return this
    val label = m.groupValues[1]
    return copy(text = text.substring(0, r.first) + label + text.substring(r.last + 1), selection = TextRange(r.first, r.first + label.length))
}

/** A saved color such as "ff3b30" as a Compose color. */
fun hexColor(hex: String): Color = Color(0xFF000000L or (hex.toLongOrNull(16) ?: 0L))

/** The prefix (# , - , 1.  and so on) and the layout tags at the start of a line. */
private fun leadOf(line: String): Pair<String, String> {
    val prefix = LINE_PREFIXES.firstOrNull { line.startsWith(it) } ?: NUM.find(line)?.value ?: ""
    return prefix to (LINE_TAGS.find(line.substring(prefix.length))?.value ?: "")
}

private fun tagString(indent: Int, align: Char) = (if (indent > 0) "{i:$indent}" else "") + (if (align == 'c' || align == 'r') "{a:$align}" else "")

/** Indent level and alignment ('l', 'c' or 'r') written in a line's tags. */
private fun tagsOf(tags: String): Pair<Int, Char> {
    val m = LINE_TAGS.find(tags); return (m?.groupValues?.get(1)?.toIntOrNull() ?: 0) to (m?.groupValues?.get(2)?.firstOrNull() ?: 'l')
}

/** Indent and alignment of the line the selection starts on. */
private fun TextFieldValue.lineState(): Pair<Int, Char> {
    val s = text; val pos = selection.start.coerceIn(0, s.length)
    val ls = s.lastIndexOf('\n', pos - 1) + 1; val le = s.indexOf('\n', pos).let { if (it < 0) s.length else it }
    return tagsOf(leadOf(s.substring(ls, le)).second)
}

/** Changes the indent and alignment of every line the selection touches. change gets (indent, align) and returns the new pair. */
private fun TextFieldValue.changeLines(change: (Int, Char) -> Pair<Int, Char>): TextFieldValue {
    val s = text; val a = minOf(selection.start, selection.end).coerceIn(0, s.length); val b = maxOf(selection.start, selection.end).coerceIn(0, s.length)
    val lines = s.split("\n"); val out = StringBuilder(); val mods = mutableListOf<Pair<Int, Int>>() // (end of old tags, size change)
    var i = 0
    for ((idx, line) in lines.withIndex()) {
        val le = i + line.length
        if (le >= a && i <= b) {
            val (pfx, tags) = leadOf(line); val (ind, al) = tagsOf(tags)
            val (ni, na) = change(ind, al); val nt = tagString(ni.coerceIn(0, 4), na)
            if (nt != tags) {
                out.append(pfx).append(nt).append(line.substring(pfx.length + tags.length)); mods += (i + pfx.length + tags.length) to (nt.length - tags.length)
            } else out.append(line)
        } else out.append(line)
        if (idx < lines.size - 1) out.append('\n')
        i = le + 1
    }
    if (mods.isEmpty()) return this
    fun shift(o: Int) = o + mods.filter { o >= it.first }.sumOf { it.second }
    return copy(text = out.toString(), selection = TextRange(shift(selection.start), shift(selection.end)))
}

private fun TextFieldValue.setAlign(c: Char) = changeLines { i, _ -> i to c }
private fun TextFieldValue.indentBy(d: Int) = changeLines { i, a -> (i + d) to a }

/** A run of a line: plain text or one {..|..} span. from..to is the whole run, cs..ce the text inside it. */
private class Atom(val from: Int, val to: Int, val cs: Int, val ce: Int, val attrs: SpanAttrs)

private fun atoms(line: String): List<Atom> {
    val out = mutableListOf<Atom>(); var p = 0
    for (m in SPAN_RE.findAll(line)) {
        if (m.range.first > p) out += Atom(p, m.range.first, p, m.range.first, SpanAttrs())
        val c = m.groups[2]!!.range
        out += Atom(m.range.first, m.range.last + 1, c.first, c.last + 1, parseSpanAttrs(m.groupValues[1])); p = m.range.last + 1
    }
    if (p < line.length) out += Atom(p, line.length, p, line.length, SpanAttrs())
    return out
}

private fun wrapSpan(text: String, a: SpanAttrs) = if (text.isEmpty() || a.none) text else "{${a.tag()}|$text}"

/** Rewrites one line so that f is applied to the formatting of the text in x until y. Returns the new line and the new x and y, or null if nothing changed. */
private fun rewriteLine(line: String, x: Int, y: Int, f: (SpanAttrs) -> SpanAttrs): Triple<String, Int, Int>? {
    val sb = StringBuilder(); var nx = -1; var ny = -1
    for (at in atoms(line)) {
        val lo = maxOf(at.cs, x); val hi = minOf(at.ce, y)
        if (lo >= hi) { sb.append(line, at.from, at.to); continue }
        val mid = line.substring(lo, hi)
        if ('}' in mid) return null
        val na = f(at.attrs); val head = if (na.none) 0 else na.tag().length + 2
        sb.append(wrapSpan(line.substring(at.cs, lo), at.attrs))
        if (nx < 0) nx = sb.length + head
        ny = sb.length + head + mid.length
        sb.append(wrapSpan(mid, na)).append(wrapSpan(line.substring(hi, at.ce), at.attrs))
    }
    return if (nx < 0) null else Triple(sb.toString(), nx, ny)
}

/** Colors, resizes or underlines the text from a to b by changing its {..|..} spans. Line prefixes are never wrapped. The result selects the same text. */
private fun TextFieldValue.formatSpan(a: Int, b: Int, f: (SpanAttrs) -> SpanAttrs): TextFieldValue {
    val lines = text.split("\n"); val out = StringBuilder(); var ns = -1; var ne = -1; var i = 0
    for ((idx, line) in lines.withIndex()) {
        val le = i + line.length; val (pfx, tags) = leadOf(line)
        val x = maxOf(maxOf(a, i) - i, pfx.length + tags.length); val y = minOf(b, le) - i
        val r = if (y > x) rewriteLine(line, x, y, f) else null
        if (r != null) { if (ns < 0) ns = out.length + r.second; ne = out.length + r.third; out.append(r.first) } else out.append(line)
        if (idx < lines.size - 1) out.append('\n')
        i = le + 1
    }
    return if (ns < 0) this else copy(text = out.toString(), selection = TextRange(ns, ne))
}

/** The formatting of every run of text between a and b (plain text counts as no formatting). */
private fun TextFieldValue.attrsIn(a: Int, b: Int): List<SpanAttrs> {
    val res = mutableListOf<SpanAttrs>(); var i = 0
    for (line in text.split("\n")) {
        val le = i + line.length; val (pfx, tags) = leadOf(line)
        val x = maxOf(maxOf(a, i) - i, pfx.length + tags.length); val y = minOf(b, le) - i
        if (y > x) for (at in atoms(line)) if (maxOf(at.cs, x) < minOf(at.ce, y)) res += at.attrs
        i = le + 1
    }
    return res
}

/** Enter inside a list or a quote continues it; Enter on an empty item leaves it. A new line keeps the indent and alignment of the one above. */
/**
 * Enter inside bold, a highlight, a color and so on: the formatting is closed on the line above and opened again on the new line (see splitMarksAtBreak), so
 * no mark is ever left alone on a line, where it would show up as plain symbols. [next] is the edit after list continuation; anything else is left alone.
 */
private fun breakMarksAtEnter(old: TextFieldValue, next: TextFieldValue): TextFieldValue {
    if (!old.selection.collapsed) return next
    val p = old.selection.start; val o = old.text; val n = next.text
    val cont = n.length - o.length - 1   // what list continuation added after the line break ("- ", "2. ", tags)
    if (cont < 0 || p > o.length || !next.selection.collapsed || next.selection.start != p + 1 + cont) return next
    if (!n.startsWith(o.substring(0, p) + "\n") || !n.endsWith(o.substring(p))) return next
    if (codeStateAt(o, p) != CodeLine.NONE) return next
    if (cont > 0) { val (pf, tg) = leadOf(n.substring(p + 1, p + 1 + cont)); if (pf.length + tg.length != cont) return next }   // only a list mark, not pasted text
    val ls = o.lastIndexOf('\n', p - 1) + 1; val le = o.indexOf('\n', p).let { if (it < 0) o.length else it }
    val line = o.substring(ls, le)
    val (a, b) = splitMarksAtBreak(line, maskCodeSpans(line), p - ls) ?: return next
    val text = o.substring(0, ls) + a + "\n" + n.substring(p + 1, p + 1 + cont) + b + o.substring(le)
    return next.copy(text = text, selection = TextRange(ls + a.length + 1 + cont), composition = null)
}

/** Enter pressed with the cursor in an empty span: the text without the span, and the same Enter without it (see [enterInEmptySpan]). Null when it is anything else. */
private fun liftEmptySpan(old: TextFieldValue, new: TextFieldValue): Pair<TextFieldValue, TextFieldValue>? {
    if (!old.selection.collapsed || !new.selection.collapsed) return null
    val p = old.selection.start
    if (new.text.length != old.text.length + 1 || new.selection.start != p + 1 || new.text.getOrNull(p) != '\n') return null
    val r = emptySpanAt(old.text, p) ?: return null
    val plain = old.text.removeRange(r.first, r.last + 1)
    return old.copy(text = plain, selection = TextRange(r.first), composition = null) to
        new.copy(text = plain.substring(0, r.first) + "\n" + plain.substring(r.first), selection = TextRange(r.first + 1), composition = null)
}

/** After Enter: the new line starts with an empty span in the look the cursor had (see [carryStyleOverEnter]); the edit stays as it is when there is none to carry. */
private fun carryLook(old: TextFieldValue, next: TextFieldValue): TextFieldValue {
    if (!old.selection.collapsed || !next.selection.collapsed) return next
    val e = carryStyleOverEnter(old.text, old.selection.start, next.text, next.selection.start) ?: return next
    return next.copy(text = e.text, selection = TextRange(e.start), composition = null)
}

private fun continueList(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
    if (new.text.length != old.text.length + 1 || new.selection.start == 0 || new.text[new.selection.start - 1] != '\n') return new
    val s = new.text; val nl = new.selection.start - 1
    if (codeStateAt(s, nl) != CodeLine.NONE) return new   // inside a code block a line starting with "- " is just code
    val ls = s.lastIndexOf('\n', nl - 1) + 1; val line = s.substring(ls, nl)
    val numM = NUM.find(line)
    val listPfx = numM?.value ?: listOf("- [x] ", "- [ ] ", "- ", "> ").firstOrNull { line.startsWith(it) }
    val (anyPfx, tags) = leadOf(line)
    if (listPfx == null && tags.isEmpty()) return new
    if (line.length == anyPfx.length + tags.length) return new.copy(text = s.substring(0, ls) + s.substring(nl), selection = TextRange(ls + 1))
    val cont = when { numM != null -> "${numM.groupValues[1].toInt() + 1}. "; listPfx == "- [x] " -> "- [ ] "; listPfx != null -> listPfx; else -> "" } + tags
    return new.copy(text = s.substring(0, nl + 1) + cont + s.substring(nl + 1), selection = TextRange(nl + 1 + cont.length))
}

private val BUBBLE_W = 288.dp
private val BUBBLE_H = 48.dp

@Composable
private fun BubbleBtn(on: Boolean, desc: String, enabled: Boolean = true, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(if (on) Sb.card.copy(alpha = .22f) else Color.Transparent)
        .alpha(if (enabled) 1f else .35f).semantics { selected = on }.tapIcon(desc) { if (enabled) onClick() }, Alignment.Center) { content() }
}

/** Where a piece of text sits in the text field (its own coordinates): the top of its first line, the bottom of its last, and the middle of it (of the page's width when it spans lines). */
private class TextSpan(val top: Float, val bottom: Float, val centerX: Float)

/** [a]..[b] are positions in the saved text; the layout is of the shown text (marks hidden), so they are translated first. */
private fun textSpanOf(layout: TextLayoutResult, map: OffsetMapping, a: Int, b: Int): TextSpan {
    val tn = layout.layoutInput.text.length
    val ta = map.originalToTransformed(a).coerceIn(0, tn); val tb = map.originalToTransformed(b).coerceIn(0, tn)
    val ra = layout.getCursorRect(ta); val rb = layout.getCursorRect(tb)
    val same = layout.getLineForOffset(ta) == layout.getLineForOffset(tb)
    return TextSpan(ra.top, rb.bottom, if (same) (ra.left + rb.left) / 2f else layout.size.width / 2f)
}

/** Which way the little arrow of a bubble points: at the text above it, at the text below it, or nowhere (docked at the bottom edge). */
private fun BubblePlace.Side.arrowAt(h: Float, size: Float): Float? = when (this) { BubblePlace.Side.Below -> -size; BubblePlace.Side.Above -> h - size; BubblePlace.Side.Docked -> null }

/**
 * The small dark bubble by the selected text: bold, italic, strikethrough, highlight, code, link and copy. It sits under the text, past the selection handles,
 * and never while a finger is on the page or the page is moving (the editor decides, see [BubblePlace] and the call site): it fades in once things are still, in place.
 */
@Composable
private fun SelectionBubble(value: TextFieldValue, layout: TextLayoutResult, span: TextSpan, spot: BubblePlace.Spot, fade: Float, marker: Marker, onRect: (Rect?) -> Unit, onInline: (String) -> Unit, onLink: () -> Unit, onCode: () -> Unit, onCopy: () -> Unit) {
    val t = LocalSb.current; val d = LocalDensity.current
    val n = value.text.length
    val a = minOf(value.selection.start, value.selection.end).coerceIn(0, n); val b = maxOf(value.selection.start, value.selection.end).coerceIn(0, n)
    if (a == b) return
    val w = with(d) { BUBBLE_W.toPx() }; val h = with(d) { BUBBLE_H.toPx() }
    val left = BubblePlace.left(span.centerX, w, layout.size.width.toFloat())
    val edge = with(d) { 18.dp.toPx() }; val arrowX = (span.centerX - left).coerceIn(edge, w - edge)
    val arrowY = spot.side.arrowAt(h, with(d) { 5.dp.toPx() })
    SideEffect { onRect(Rect(left - 8f, spot.top - 8f, left + w + 8f, spot.top + h + 8f)) }
    DisposableEffect(Unit) { onDispose { onRect(null) } }
    val mark = markerBase(t.acc, marker)   // the "ab" button shows the highlighter as it is set
    val canLink = value.link() != null || !value.text.substring(a, b).any { it == '\n' || it == '[' || it == ']' }
    Box(Modifier.offset { IntOffset(left.roundToInt(), spot.top.roundToInt()) }.size(BUBBLE_W, BUBBLE_H).alpha(fade)) {
        if (arrowY != null) Box(Modifier.offset { IntOffset((arrowX - 5.dp.toPx()).roundToInt(), arrowY.roundToInt()) }.size(10.dp).rotate(45f).background(Sb.ink))
        Row(Modifier.fillMaxSize().softShadow(RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Sb.ink).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            BubbleBtn(value.enclosing("**") != null, "Bold", onClick = { onInline("**") }) { Text("B", color = Sb.card, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            BubbleBtn(value.enclosing("*") != null, "Italic", onClick = { onInline("*") }) { Text("I", color = Sb.card, fontSize = 17.sp, fontWeight = FontWeight.Medium, fontStyle = FontStyle.Italic) }
            BubbleBtn(value.enclosing("~~") != null, "Strikethrough", onClick = { onInline("~~") }) { Text("S", color = Sb.card, fontSize = 17.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.LineThrough) }
            BubbleBtn(value.enclosing("==") != null, "Highlight", onClick = { onInline("==") }) {
                Text("ab", color = Color(0xFF161616), fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.clip(RoundedCornerShape(5.dp)).background(mark).padding(horizontal = 5.dp, vertical = 1.dp))
            }
            BubbleBtn(inCodeSpan(value.text, a, b), "Code", onClick = onCode) { Ic("code", 20.dp, Sb.card) }
            BubbleBtn(value.link() != null, "Add link", enabled = canLink, onClick = onLink) { Ic("link", 20.dp, Sb.card) }
            BubbleBtn(false, "Copy", onClick = onCopy) { Ic("copy", 20.dp, Sb.card) }
        }
    }
}

/** True once [key] has not changed for [ms]: the bubbles wait for the selection, the text and the finger to be still. */
@Composable
private fun rememberCalm(key: Any?, ms: Long): Boolean {
    var calm by remember { mutableStateOf(false) }
    LaunchedEffect(key) { calm = false; delay(ms); calm = true }
    return calm
}

private val LINK_BUBBLE_H = 44.dp

@Composable
private fun LinkBtn(icon: String, label: String, onClick: () -> Unit) {
    Row(Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(14.dp)).tap(label, onClick).padding(horizontal = 12.dp), Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
        Ic(icon, 18.dp, Sb.card); Text(label, color = Sb.card, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/**
 * The small dark bubble that appears over a link while the cursor is in it: Open (in the browser, or the app that owns the address) and, for a
 * [text](url) link, Edit. It sits above the link, or below it when there is no room above, shows only while the page is still, and goes away by
 * itself after a few seconds. Typing and moving the cursor work as always.
 */
@Composable
private fun LinkBubble(spot: LinkSpot, layout: TextLayoutResult, map: OffsetMapping, fieldTop: Float, scrollY: Int, viewportH: Int, fade: Float, onRect: (Rect?) -> Unit, onOpen: () -> Unit, onEdit: (() -> Unit)?) {
    val d = LocalDensity.current
    val hasOpen = spot.url.isNotBlank(); val buttons = (if (hasOpen) 1 else 0) + (if (onEdit != null) 1 else 0)
    if (buttons == 0) return
    val span = textSpanOf(layout, map, spot.label.first, spot.label.last + 1)
    val wDp = if (buttons == 2) 172.dp else 96.dp
    val w = with(d) { wDp.toPx() }; val h = with(d) { LINK_BUBBLE_H.toPx() }
    val left = BubblePlace.left(span.centerX, w, layout.size.width.toFloat())
    val visTop = scrollY - fieldTop; val visBottom = if (viewportH > 0) scrollY + viewportH - fieldTop else Float.MAX_VALUE / 4f
    val at = BubblePlace.placeAboveFirst(span.top, span.bottom, h, visTop, visBottom, with(d) { 30.dp.toPx() }, with(d) { 12.dp.toPx() }, with(d) { 8.dp.toPx() })
    val edge = with(d) { 18.dp.toPx() }; val arrowX = (span.centerX - left).coerceIn(edge, w - edge)
    val arrowY = at.side.arrowAt(h, with(d) { 5.dp.toPx() })
    SideEffect { onRect(Rect(left - 8f, at.top - 8f, left + w + 8f, at.top + h + 8f)) }
    DisposableEffect(Unit) { onDispose { onRect(null) } }
    Box(Modifier.offset { IntOffset(left.roundToInt(), at.top.roundToInt()) }.size(wDp, LINK_BUBBLE_H).alpha(fade)) {
        if (arrowY != null) Box(Modifier.offset { IntOffset((arrowX - 5.dp.toPx()).roundToInt(), arrowY.roundToInt()) }.size(10.dp).rotate(45f).background(Sb.ink))
        Row(Modifier.fillMaxSize().softShadow(RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Sb.ink).padding(4.dp),
            Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            if (hasOpen) LinkBtn("external", "Open", onOpen)
            if (onEdit != null) LinkBtn("edit", "Edit", onEdit)
        }
    }
}

/** The rounded 56dp bar the editor toolbars sit in. floating adds a border and shadow (the pill). */
@Composable
private fun Bar(floating: Boolean, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
        .then(if (floating) Modifier.softShadow(shape) else Modifier)
        .height(56.dp).clip(shape).background(Sb.surface)
        .then(if (floating) Modifier.border(1.dp, Sb.line, shape) else Modifier)
        .padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically, content = content)
}

/**
 * How the bubble toolbar and its pop-ups mark what is on (Settings > Editor > Toolbar highlight): 0 is a soft tint behind the button, 1 is the accent
 * color with a small dot under it. Set by the editor screen; read by the buttons here.
 */
private var barLookNow by mutableIntStateOf(0)

/** The mark for something that is on, in the style the setting says: the tint as a background, the dot as a small circle at the bottom of the box. */
private fun Modifier.onMark(on: Boolean, acc: Color, shape: Shape): Modifier =
    if (!on) this else when (barLookNow) {
        0 -> this.clip(shape).background(acc.copy(alpha = .16f))
        2 -> this.shadow(2.dp, shape, ambientColor = Color.Black.copy(alpha = .22f), spotColor = Color.Black.copy(alpha = .22f)).background(Sb.tile, shape)   // raised, like a chip on a track
        else -> this
    }

@Composable
private fun BoxScope.OnDot(on: Boolean, acc: Color, bottom: Dp = 3.dp) {
    if (on && barLookNow == 1) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = bottom).size(5.dp).clip(CircleShape).background(accentText(acc)))
}

/**
 * One button in a bar. [on] marks it (see [barLookNow]); hold runs [onHold] (for example redo on the undo button). The whole cell is the touch area, but the
 * mark is always the same 44dp rounded square in the middle of it (or narrower on a narrow screen), so every button looks the same when it is on and two
 * neighbors that are both on never touch.
 */
@Composable
private fun RowScope.BarCell(on: Boolean, desc: String, holdLabel: String? = null, onHold: (() -> Unit)? = null, onClick: () -> Unit, content: @Composable (Color) -> Unit) {
    val acc = LocalSb.current.acc
    val base = Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(16.dp)).semantics { selected = on }
    Box(if (onHold != null) base.tapOrHold(desc, holdLabel, onHold, onClick) else base.tap(desc, onClick), Alignment.Center) {
        Box(Modifier.padding(horizontal = 2.dp).widthIn(max = 44.dp).fillMaxWidth().height(44.dp).onMark(on, acc, RoundedCornerShape(16.dp)), Alignment.Center) {
            content(if (on) accentText(acc) else Sb.ink)
            OnDot(on, acc)
        }
    }
}

private fun headingLabel(prefix: String?) = when (prefix) { "# " -> "H1"; "## " -> "H2"; else -> "H" }

/**
 * Everything the editor lets you change, as one value, so undo can bring all of it back: the text (with the cursor), the title, photos, color, type,
 * box, tags and source. When something new can be changed here (a voice recording, say), add it to Snap, to restore() and to record() calls in the
 * editor, and undo covers it.
 */
private data class Snap(val title: String, val body: TextFieldValue, val color: Int, val kind: Kind, val shelf: String, val tags: String,
                        val imgs: List<String>, val source: String, val files: List<Attachment> = emptyList(), val parts: List<Part> = emptyList(),
                        /** The photos and files that are not in line with the page (see Floats.kt). */
                        val placed: Map<String, Placed> = emptyMap(),
    /** The free cards of a Cards page (see PageCards.kt). */
    val cards: List<PageCard> = emptyList())

/** Same content, ignoring where the cursor is. */
private fun Snap.sameAs(o: Snap) = title == o.title && body.text == o.body.text && color == o.color && kind == o.kind && shelf == o.shelf &&
    tags == o.tags && imgs == o.imgs && source == o.source && files == o.files && parts == o.parts && placed == o.placed && cards == o.cards

/** What the undo button and its bubble need: what the next undo and redo would change (null: nothing to do), and the three actions. */
private class HistoryUi(val undoLabel: String?, val redoLabel: String?, val canRevert: Boolean, val onUndo: () -> Unit, val onRedo: () -> Unit, val onRevert: () -> Unit)

/** What the + window can do besides the text blocks. Page one is the list that used to be "Add to page" in the 3-dot menu; the rest belongs to page two. */
private class AddActions(val card: (() -> Unit)?, val attach: () -> Unit, val record: () -> Unit, val linkScrap: () -> Unit, val textTools: () -> Unit, val settings: () -> Unit,
                         val webLink: () -> Unit, val date: () -> Unit)

/** One tile of the Quick tools window: a drawn [icon] or a short [glyph] (like "AA"), a label and what it does. [stays] keeps the window open, for tools you tap several times. */
private class QuickTool(val label: String, val icon: String? = null, val glyph: String? = null, val stays: Boolean = false, val danger: Boolean = false, val run: () -> Unit)

/** The tiles of the Quick tools window, in titled groups. */
private class QuickGroup(val title: String, val tools: List<QuickTool>)

/**
 * The Quick tools window, opened by holding the + button: the things you reach for while writing, in the toolbar's own color and in titled groups (lists
 * and blocks, insert, lines, selected words). Each group is a rounded card of tiles, four to a row; it scrolls when it is taller than the screen allows.
 */
@Composable
private fun QuickToolsWindow(groups: List<QuickGroup>, grow: Boolean = false, layout: Int = 0, pinned: List<String> = emptyList(), onPinned: (List<String>) -> Unit = {}, onClose: () -> Unit) {
    val sans = LocalFonts.current.second; val shape = RoundedCornerShape(menuSkin().popupCorner)
    val gap = with(LocalDensity.current) { 8.dp.roundToPx() }
    val pinnedLook = grow && layout == 1   // Growing card, Pinned + sections: your four tools on top, every group below in one scroll
    val railLook = grow && layout == 2   // Growing card, Side rail: a thin rail of group buttons on the left, big tiles of one group on the right
    val listLook = grow && layout == 3   // Growing card, Search list: a search box over one plain list of every tool
    val tabbed = !pinnedLook && !railLook && !listLook && (grow || barLookNow == 2)   // Growing card, or Raised segment: one group at a time under a tab switcher, each tile its own card
    // Growing card: flat and light-weight, the toolbar's own dark in dark mode, a soft grey in light mode; no outline.
    val bg = if (!grow) Sb.sheet else if (Sb.dark) growCard else Color(0xFFF3F3F6)
    val tileBg = if (!grow) Sb.tile else if (Sb.dark) growChip else Color.White
    val pad = if (grow) 20.dp else 0.dp
    var tab by remember { mutableIntStateOf(0) }
    val runTool = { tool: QuickTool -> if (!tool.stays) onClose(); tool.run() }
    Popup(popupPositionProvider = AboveAnchor(gap, with(LocalDensity.current) { pad.roundToPx() }), onDismissRequest = onClose, properties = PopupProperties(focusable = true)) {
        // The Growing card version has room around it, so its soft shadow is not cut off by the edge of the pop-up window.
        Box(Modifier.padding(pad)) {
        Column(Modifier.width(if (grow) 300.dp else 316.dp).heightIn(max = 520.dp).then(if (grow) Modifier.softShadow(shape) else Modifier).clip(shape).background(bg).then(if (grow) Modifier else Modifier.border(1.dp, Sb.line, shape))
            .padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 12.dp)) {
            if (!pinnedLook) Text("Quick tools", Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = if (grow) 8.dp else 10.dp), color = Sb.ink, fontSize = if (grow) 14.sp else 16.sp, fontFamily = sans, fontWeight = FontWeight.SemiBold)
            if (pinnedLook) QuickPinned(groups, pinned, onPinned, tileBg) { runTool(it) }
            else if (listLook) QuickSearchList(groups, tileBg) { runTool(it) }
            else if (railLook) {
                val at = tab.coerceIn(0, groups.lastIndex)
                val railIcons = listOf("list", "plus", "divider", "edit")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.clip(RoundedCornerShape(16.dp)).background(if (Sb.dark) growChip else Color(0xFFE4E4E9)).padding(3.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        groups.forEachIndexed { n, g ->
                            Box(Modifier.size(40.dp, 44.dp).clip(RoundedCornerShape(13.dp)).background(if (n == at) (if (Sb.dark) Color.White.copy(alpha = .12f) else Color.White) else Color.Transparent)
                                .semantics { selected = n == at }.tap(g.title) { tab = n }, Alignment.Center) { Ic(railIcons.getOrElse(n) { "list" }, 20.dp, if (n == at) Sb.ink else Sb.mute) }
                        }
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        Text(groups[at].title.uppercase(), Modifier.padding(start = 2.dp, bottom = 6.dp), color = Sb.mute, fontSize = 10.sp, letterSpacing = .8.sp, fontFamily = sans, fontWeight = FontWeight.SemiBold)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (row in groups[at].tools.chunked(3)) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (tool in row) QuickTile(tool, Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(tileBg), 62.dp) { runTool(tool) }
                                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
            else if (tabbed) {
                val at = tab.coerceIn(0, groups.lastIndex)
                val pill = RoundedCornerShape(14.dp)
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(if (grow) 13.dp else 17.dp)).background(if (grow) (if (Sb.dark) growChip else Color(0xFFE4E4E9)) else Sb.ink.copy(alpha = .07f)).padding(if (grow) 2.dp else 3.dp)) {
                    groups.forEachIndexed { n, g ->
                        Box(Modifier.weight(1f).height(if (grow) 32.dp else 36.dp).then(if (grow) Modifier.clip(RoundedCornerShape(11.dp)).background(if (n == at) (if (Sb.dark) Color.White.copy(alpha = .12f) else Color.White) else Color.Transparent) else Modifier.onMark(n == at, LocalSb.current.acc, pill))
                            .semantics { selected = n == at }.tap(g.title) { tab = n }, Alignment.Center) {
                            Text(g.title.substringBefore(' '), fontSize = 12.5.sp, fontFamily = sans, fontWeight = FontWeight.SemiBold, color = if (n == at) Sb.ink else Sb.mute, maxLines = 1)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(if (grow) 6.dp else 8.dp)) {
                    for (row in groups[at].tools.chunked(4)) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(if (grow) 6.dp else 8.dp)) {
                        for (tool in row) QuickTile(tool, Modifier.weight(1f).clip(RoundedCornerShape(if (grow) 14.dp else 18.dp)).background(tileBg), if (grow) 62.dp else 76.dp) { runTool(tool) }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            } else Column(Modifier.verticalScroll(rememberScrollState())) {
                for (g in groups) {
                    Text(g.title.uppercase(), Modifier.padding(start = 6.dp, top = 8.dp, bottom = 6.dp), color = Sb.mute, fontSize = 11.5.sp, letterSpacing = .6.sp, fontFamily = sans, fontWeight = FontWeight.SemiBold)
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Sb.tile).padding(4.dp)) {
                        for (row in g.tools.chunked(4)) Row(Modifier.fillMaxWidth()) {
                            for (tool in row) QuickTile(tool, Modifier.weight(1f)) { runTool(tool) }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }
        }
    }
}

/**
 * The Pinned + sections layout of the Quick tools window (Growing card): the tools you pinned on top, big and one tap away, then every group in one scroll with compact tiles.
 * "Edit pinned" turns the tiles into switches: tap a tool to pin or unpin it (up to four).
 */
@Composable
private fun QuickPinned(groups: List<QuickGroup>, pinned: List<String>, onPinned: (List<String>) -> Unit, tileBg: Color, runTool: (QuickTool) -> Unit) {
    val sans = LocalFonts.current.second; val acc = LocalSb.current.acc
    val a = if (Sb.dark) accentOnInk(acc) else accentText(acc); val tint = a.copy(alpha = .22f)
    var editing by remember { mutableStateOf(false) }
    val pins = pinned.mapNotNull { l -> groups.firstNotNullOfOrNull { g -> g.tools.firstOrNull { it.label == l } } }
    fun toggle(tool: QuickTool) { if (tool.label in pinned) onPinned(pinned - tool.label) else if (pinned.size < 4) onPinned(pinned + tool.label) }
    @Composable
    fun label(t: String) = Text(t, Modifier.padding(start = 4.dp, top = 10.dp, bottom = 6.dp), color = Sb.mute, fontSize = 10.sp, letterSpacing = .8.sp, fontFamily = sans, fontWeight = FontWeight.SemiBold)
    Row(Modifier.fillMaxWidth().padding(start = 6.dp, top = 2.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Quick tools", Modifier.weight(1f), color = Sb.ink, fontSize = 14.sp, fontFamily = sans, fontWeight = FontWeight.SemiBold)
        Box(Modifier.clip(RoundedCornerShape(10.dp)).background(if (editing) tint else tileBg).tap(if (editing) "Done editing pinned tools" else "Edit pinned tools") { editing = !editing }
            .padding(horizontal = 10.dp, vertical = 5.dp)) { Text(if (editing) "Done" else "Edit pinned", fontSize = 11.sp, fontFamily = sans, color = if (editing) a else Sb.mute) }
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        label(if (editing) "PINNED, TAP A TOOL BELOW TO PIN OR UNPIN (UP TO 4)" else "PINNED")
        if (pins.isEmpty()) Text("Nothing pinned yet. Tap Edit pinned to choose up to four tools.", Modifier.padding(horizontal = 4.dp, vertical = 8.dp), color = Sb.mute, fontSize = 12.sp, fontFamily = sans)
        else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (tool in pins) QuickTile(tool, Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (editing) tint else tileBg), 62.dp) { if (editing) toggle(tool) else runTool(tool) }
            repeat(4 - pins.size) { Spacer(Modifier.weight(1f)) }
        }
        for (g in groups) {
            label(g.title.uppercase())
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (row in g.tools.chunked(5)) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (tool in row) QuickTile(tool, Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (editing && tool.label in pinned) tint else tileBg), 54.dp, small = true) { if (editing) toggle(tool) else runTool(tool) }
                    repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

/**
 * The Search list layout of the Quick tools window (Growing card): a search box over one plain list of every tool, with its group on the right. Without a search the list is
 * in groups, with titles; typing a few letters (a name, or the group) leaves only the tools that match.
 */
@Composable
private fun QuickSearchList(groups: List<QuickGroup>, tileBg: Color, runTool: (QuickTool) -> Unit) {
    val sans = LocalFonts.current.second
    var query by remember { mutableStateOf("") }
    val q = query.trim()
    Row(Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(13.dp)).background(if (Sb.dark) growChip else Color(0xFFE4E4E9)).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Ic("search", 18.dp, Sb.mute); Spacer(Modifier.width(8.dp))
        BasicTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, textStyle = TextStyle(color = Sb.ink, fontSize = 14.sp, fontFamily = sans), cursorBrush = SolidColor(Sb.ink),
            decorationBox = { inner -> Box(contentAlignment = Alignment.CenterStart) { if (query.isEmpty()) Text("Search tools", color = Sb.mute, fontSize = 14.sp, fontFamily = sans); inner() } })
    }
    Spacer(Modifier.height(6.dp))
    Column(Modifier.verticalScroll(rememberScrollState())) {
        val hits = groups.map { g -> g to g.tools.filter { q.isEmpty() || it.label.contains(q, true) || g.title.contains(q, true) } }.filter { it.second.isNotEmpty() }
        if (hits.isEmpty()) Text("No tool called \u201C$q\u201D.", Modifier.padding(horizontal = 6.dp, vertical = 12.dp), color = Sb.mute, fontSize = 13.sp, fontFamily = sans)
        for ((g, tools) in hits) {
            if (q.isEmpty()) Text(g.title.uppercase(), Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp), color = Sb.mute, fontSize = 10.sp, letterSpacing = .8.sp, fontFamily = sans, fontWeight = FontWeight.SemiBold)
            for (tool in tools) {
                val ink = if (tool.danger) Sb.danger else Sb.ink
                Row(Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(12.dp)).tap(tool.label) { runTool(tool) }.padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(tileBg), Alignment.Center) {
                        if (tool.icon != null) Ic(tool.icon, 18.dp, ink) else Text(tool.glyph.orEmpty(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ink, maxLines = 1)
                    }
                    Text(tool.label, Modifier.weight(1f).padding(start = 12.dp), color = ink, fontSize = 14.sp, fontFamily = sans, maxLines = 1)
                    Text(g.title.substringBefore(' '), color = Sb.mute, fontSize = 11.sp, fontFamily = sans)
                }
            }
        }
    }
}

@Composable
private fun QuickTile(tool: QuickTool, modifier: Modifier, height: Dp = 64.dp, small: Boolean = false, onRun: () -> Unit) {
    val ink = if (tool.danger) Sb.danger else Sb.ink
    Column(modifier.height(height).clip(RoundedCornerShape(14.dp)).tap(tool.label, onRun).padding(horizontal = 2.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Box(Modifier.height(if (small) 22.dp else 26.dp), Alignment.Center) {
            if (tool.icon != null) Ic(tool.icon, if (small) 19.dp else 22.dp, ink) else Text(tool.glyph.orEmpty(), fontSize = if (small) 13.sp else 15.sp, fontWeight = FontWeight.SemiBold, color = ink, maxLines = 1)
        }
        Text(tool.label, fontSize = if (small) 10.sp else 11.sp, lineHeight = if (small) 12.sp else 13.sp, color = if (tool.danger) Sb.danger else Sb.mute, maxLines = 2, textAlign = TextAlign.Center)
    }
}

/** Puts a popup just above its anchor (under it when there is no room above), lined up with the anchor's left edge and kept inside the window. */
private class AboveAnchor(private val gapPx: Int, private val roomPx: Int = 0) : PopupPositionProvider {
    override fun calculatePosition(anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize): IntOffset {
        val x = (anchorBounds.left - roomPx).coerceIn(0, maxOf(0, windowSize.width - popupContentSize.width))
        val above = anchorBounds.top - popupContentSize.height - gapPx + roomPx
        val y = if (above >= 0) above else (anchorBounds.bottom + gapPx - roomPx).coerceAtMost(maxOf(0, windowSize.height - popupContentSize.height))
        return IntOffset(x, y)
    }
}

/**
 * The + window of the bubble toolbar: a floating card above the button with two pages you swipe between. Page one is what "Add to page" used to be in the
 * 3-dot menu (attach a file, record audio, link to a scrap, text tools, editor settings); page two has the text blocks (quote, divider, code block) and two inserts.
 * Rows are the 3-dot menu's own MenuRow, so it looks the same; the dots in the header show which page you are on.
 */
@Composable
private fun AddWindow(add: AddActions, onQuote: () -> Unit, onDivider: () -> Unit, onCode: () -> Unit, grow: Boolean = false, onClose: () -> Unit) {
    val sans = LocalFonts.current.second; val shape = RoundedCornerShape(menuSkin().popupCorner)
    val pages = rememberPagerState { 2 }
    val gap = with(LocalDensity.current) { 8.dp.roundToPx() }
    fun closeThen(f: () -> Unit): () -> Unit = { onClose(); f() }
    // Growing card: the same flat colors as its Quick tools window, smaller rows, a soft shadow that has room around it.
    val bg = if (!grow) Sb.sheet else if (Sb.dark) growCard else Color(0xFFF3F3F6)
    val tile = if (Sb.dark) growChip else Color.White
    val pad = if (grow) 20.dp else 0.dp
    @Composable
    fun row(icon: String, title: String, sub: String, onClick: () -> Unit) = if (grow) AddRow(icon, title, sub, tile, onClick) else MenuRow(icon, title, sub, onClick = onClick)
    Popup(popupPositionProvider = AboveAnchor(gap, with(LocalDensity.current) { pad.roundToPx() }), onDismissRequest = onClose, properties = PopupProperties(focusable = true)) {
        Box(Modifier.padding(pad)) {
        Column(Modifier.width(if (grow) 264.dp else 276.dp).then(if (grow) Modifier.softShadow(shape) else Modifier).clip(shape).background(bg).then(if (grow) Modifier else Modifier.border(1.dp, Sb.line, shape)).padding(if (grow) 6.dp else 8.dp)) {
            Row(Modifier.fillMaxWidth().height(if (grow) 36.dp else 40.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (pages.currentPage == 0) "Add to page" else "Insert", Modifier.weight(1f), color = if (grow) Sb.ink else Sb.mute, fontSize = 14.sp, fontFamily = sans, fontWeight = if (grow) FontWeight.SemiBold else FontWeight.Medium)
                repeat(2) { i ->
                    val here = pages.currentPage == i
                    Box(Modifier.padding(start = 6.dp).size(if (here) 8.dp else 6.dp).clip(CircleShape).background(if (here) Sb.ink else Sb.mute.copy(alpha = .45f)))
                }
            }
            HorizontalPager(pages, Modifier.fillMaxWidth().height(if (grow) (if (add.card != null) 318.dp else 266.dp) else if (add.card != null) 356.dp else 304.dp)) { page ->
                Column(Modifier.fillMaxWidth()) {
                    if (page == 0) {
                        add.card?.let { c -> row("layout", "Add a card", "A free card anywhere on this page", onClick = closeThen(c)) }
                        row("page", "Attach file", "PDF, zip or any file", onClick = closeThen(add.attach))
                        row("mic", "Record audio", "A voice memo or a demo", onClick = closeThen(add.record))
                        row("link", "Link to scrap", "Connect it to another scrap", onClick = closeThen(add.linkScrap))
                        row("edit", "Text tools", "Move line, checklist, date", onClick = closeThen(add.textTools))
                        if (grow) Spacer(Modifier.height(4.dp)) else MenuDivider()
                        row("sliders", "Editor settings", "Pasting, #tags, links, toolbar", onClick = closeThen(add.settings))
                    } else {
                        row("quote", "Quote", "Set the line apart", onClick = closeThen(onQuote))
                        row("divider", "Divider", "A line between two parts", onClick = closeThen(onDivider))
                        row("code", "Code block", "Text in a fixed-width box", onClick = closeThen(onCode))
                        row("external", "Web link", "Link the selected text", onClick = closeThen(add.webLink))
                        row("clock", "Today's date", todayText(), onClick = closeThen(add.date))
                    }
                }
            }
        }
        }
    }
}

/** One row of the Growing card's Add to page window: a small soft tile with the icon, the name and one short line. Smaller than the 3-dot menu's own row. */
@Composable
private fun AddRow(icon: String, title: String, sub: String, tile: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(14.dp)).tap(title, onClick).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(tile), Alignment.Center) { Ic(icon, 20.dp, Sb.ink) }
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, color = Sb.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(sub, color = Sb.mute, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * Editor A, the default: a round + button (opens the + window: add to the page, quote, divider, code block), heading, checklist, text options, font color, font size and undo. Inline formatting is also in the
 * selection bubble. Tap the undo button to undo; hold it for a bubble with Undo, Redo (each says what it would change) and Revert all changes.
 */
@Composable
private fun BubbleBar(prefix: String?, h: HistoryUi, sizeLabel: String, colorBar: Color, panel: Int, onPanel: (Int) -> Unit,
                      onQuote: () -> Unit, onDivider: () -> Unit, onHeading: () -> Unit, onCheck: () -> Unit, onCode: () -> Unit, sizeNow: Int?, onSize: (Int?) -> Unit, add: AddActions, quick: List<QuickGroup>) {
    Bar(floating = false) {
        var menu by remember { mutableStateOf(false) }; var quickOpen by remember { mutableStateOf(false) }; val haptics = LocalHaptics.current
        Box {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Sb.ink).tapOrHold("Insert", "Quick tools", { haptics.tick(); quickOpen = true }) { menu = true }
                .semantics { contentDescription = "Insert" }, Alignment.Center) { Ic("plus", 22.dp, Sb.card) }
            if (menu) AddWindow(add, onQuote, onDivider, onCode) { menu = false }
            if (quickOpen) QuickToolsWindow(quick) { quickOpen = false }
        }
        BarCell(prefix == "# " || prefix == "## ", "Heading", onClick = onHeading) { c -> Text(headingLabel(prefix), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = c) }
        BarCell(prefix == "- [ ] " || prefix == "- [x] ", "Checklist", onClick = onCheck) { c -> Ic("taskcheck", 22.dp, c) }
        BarCell(panel == 1, "Text options", onClick = { onPanel(if (panel == 1) 0 else 1) }) { c -> Text("Aa", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c) }
        BarCell(panel == 2, "Text and highlighter colors", onClick = { onPanel(if (panel == 2) 0 else 2) }) { c ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("A", fontSize = 18.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, color = c)
                Box(Modifier.padding(top = 2.dp).width(18.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(colorBar))
            }
        }
        BarCell(panel == 3, "Font size", onClick = { onPanel(if (panel == 3) 0 else 3) }) { c ->
            Box {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(sizeLabel, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = c)
                    Text("▾", fontSize = 11.sp, color = c)
                }
                if (panel == 3) SizeList(sizeNow, 17, onSize) { onPanel(0) }
            }
        }
        var bubble by remember { mutableStateOf(false) }
        BarCell(false, "Undo", "More undo and redo", { bubble = true }, h.onUndo) { c ->
            Ic("undo", 22.dp, if (h.undoLabel != null) c else if (h.redoLabel != null) Sb.mute else Sb.mute.copy(alpha = .4f))
            // The bubble stays open so you can step back and forth; it shows what each step would change.
            PopupMenu(bubble, { bubble = false }, Sb.sheet, Sb.line) {
                PopupItem("Undo", "undo", sub = h.undoLabel ?: "Nothing to undo", tint = if (h.undoLabel != null) Sb.ink else Sb.mute) { h.onUndo() }
                PopupItem("Redo", "redo", sub = h.redoLabel ?: "Nothing to redo", tint = if (h.redoLabel != null) Sb.ink else Sb.mute) { h.onRedo() }
                PopupDivider()
                PopupItem("Revert all changes", "close", sub = if (h.canRevert) "Back to when you opened it" else "Nothing has changed",
                    tint = if (h.canRevert) Sb.ink else Sb.mute) { if (h.canRevert) { bubble = false; h.onRevert() } }
            }
        }
    }
}

/**
 * One button of the Growing card pill (44dp, 42dp while text is selected). [on] marks it the way Toolbar highlight says: a soft circle of the page's accent (smaller than the
 * button, so two neighbours that are on never touch), the accent icon with a dot under it, or a raised chip. Hold runs [onHold].
 */
@Composable
private fun GrowBtn(on: Boolean, desc: String, holdLabel: String? = null, onHold: (() -> Unit)? = null, onClick: () -> Unit, size: Dp = 44.dp, content: @Composable (Color) -> Unit) {
    val a = accentOnInk(LocalSb.current.acc); val look = barLookNow
    val base = Modifier.size(size).clip(RoundedCornerShape(16.dp)).semantics { selected = on }
    Box(if (onHold != null) base.tapOrHold(desc, holdLabel, onHold, onClick) else base.tap(desc, onClick), Alignment.Center) {
        if (on && look == 0) Box(Modifier.size(size - 6.dp).clip(CircleShape).background(a.copy(alpha = .22f)))
        if (on && look == 2) Box(Modifier.size(size - 4.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .12f)))
        content(if (on) a else growFg)
        if (on && look == 1) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp).size(5.dp).clip(CircleShape).background(a))
    }
}

/**
 * Editor C, the Adaptive toolbar (it was the Growing card): one floating dark pill. Undo, Heading, Checklist, Aa and +; Aa grows a dark card with text options, color and size; + opens the + window and
 * holding it opens Quick tools; undo works as before (tap, hold for redo and revert all). The tools follow what you are doing ([mode], see pillMode): on selected words
 * Bold, Italic, Color and Size (panels 4 and 5); on a heading line the heading levels; on a checklist line indent and outdent.
 * Without the keyboard it is the normal compact pill, centered at the bottom. When the keyboard opens ([rail], see railMode in the editor) the pill slides to the right and
 * stands up as a slim vertical bar just above the keyboard, where the thumb rests: the line's tools on top, then a thin divider, then Aa, + and undo, which never move. The
 * bar grows upward with more tools; the page's text runs under it. It adapts: while you type ([mode] is Tucked) the bar shrinks to a small handle at the edge and comes back
 * when you pause or tap it; on a new empty line it offers the ways to start a block; scrolling slides it away (see pillHidden in the editor). One calm curve, no bounce, no
 * icons popping in. The page's accent marks what is on.
 */
@Composable
private fun GrowBar(prefix: String?, h: HistoryUi, panel: Int, onPanel: (Int) -> Unit, onQuote: () -> Unit, onDivider: () -> Unit, onHeading: () -> Unit, onCheck: () -> Unit,
                    onCode: () -> Unit, add: AddActions, quick: List<QuickGroup>, sel: Boolean, bold: Boolean, italic: Boolean, onBold: () -> Unit, onItalic: () -> Unit,
                    colorNow: Color, sizeLabel: String, quickLayout: Int, quickPinned: List<String>, onQuickPinned: (List<String>) -> Unit,
                    mode: PillMode, rail: Boolean, onLevel: (Int) -> Unit, onIndent: (Int) -> Unit,
                    onOpenLink: () -> Unit, onEditLink: (() -> Unit)?, onRemoveLink: (() -> Unit)?, onCopyCode: () -> Unit, onUnwrapCode: () -> Unit, onBullet: () -> Unit, onWake: () -> Unit) {
    var menu by remember { mutableStateOf(false) }; var quickOpen by remember { mutableStateOf(false) }; var bubble by remember { mutableStateOf(false) }
    val haptics = LocalHaptics.current; val fg = growFg
    // One calm curve, no overshoot, for everything that moves.
    val calm = androidx.compose.animation.core.CubicBezierEasing(.2f, 0f, 0f, 1f)
    // 0 the compact pill (no keyboard), 1 the bar on the right, 2 the small handle the bar shrinks to while you type.
    val layout = if (!rail) 0 else if (mode == PillMode.Tucked) 2 else 1
    // The line's tools, laid out in a row (the pill) or a column (the bar). The state above is kept here, so the pop-ups survive the switch between the two.
    val tools: @Composable (PillMode, Boolean) -> Unit = { m, v ->
        val d = if (v || sel) 40.dp else 44.dp
        when (m) {
            PillMode.Selection -> GrowLine(v) {
                GrowBtn(bold, "Bold", onClick = onBold, size = d) { c -> Text("B", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = c) }
                GrowBtn(italic, "Italic", onClick = onItalic, size = d) { c -> Text("I", fontSize = 17.sp, fontWeight = FontWeight.Medium, fontStyle = FontStyle.Italic, color = c) }
                GrowBtn(panel == 4, "Text color", onClick = { onPanel(if (panel == 4) 0 else 4) }, size = d) { c ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("A", fontSize = 17.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, color = c)
                        Box(Modifier.padding(top = 2.dp).size(16.dp, 3.dp).clip(RoundedCornerShape(2.dp)).background(colorNow))
                    }
                }
                GrowBtn(panel == 5, "Text size", onClick = { onPanel(if (panel == 5) 0 else 5) }, size = d) { c -> Text(sizeLabel, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c) }
            }
            PillMode.Heading -> GrowLine(v) {
                GrowBtn(prefix == "# ", "Heading 1", onClick = { onLevel(1) }, size = d) { c -> Text("H1", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c) }
                GrowBtn(prefix == "## ", "Heading 2", onClick = { onLevel(2) }, size = d) { c -> Text("H2", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c) }
            }
            PillMode.Task -> GrowLine(v) {
                GrowBtn(false, "Outdent", onClick = { onIndent(-1) }, size = d) { c -> Ic("outdent", 22.dp, c) }
                GrowBtn(false, "Indent", onClick = { onIndent(1) }, size = d) { c -> Ic("indent", 22.dp, c) }
                GrowBtn(true, "Checklist", onClick = onCheck, size = d) { c -> Ic("taskcheck", 22.dp, c) }
            }
            PillMode.Link -> GrowLine(v) {
                GrowBtn(false, "Open link", onClick = onOpenLink, size = d) { c -> Ic("external", 22.dp, c) }
                if (onEditLink != null) GrowBtn(false, "Edit link", onClick = onEditLink, size = d) { c -> Ic("edit", 22.dp, c) }
                if (onRemoveLink != null) GrowBtn(false, "Remove link", onClick = onRemoveLink, size = d) { c -> Ic("trash", 22.dp, c) }
            }
            PillMode.Code -> GrowLine(v) {
                GrowBtn(false, "Copy code", onClick = onCopyCode, size = d) { c -> Ic("copy", 22.dp, c) }
                GrowBtn(true, "Code block", onClick = onUnwrapCode, size = d) { c -> Ic("code", 22.dp, c) }
            }
            PillMode.Empty -> GrowLine(v) {
                GrowBtn(false, "Heading", onClick = onHeading, size = d) { c -> Text(headingLabel(prefix), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c) }
                GrowBtn(false, "Checklist", onClick = onCheck, size = d) { c -> Ic("taskcheck", 22.dp, c) }
                GrowBtn(false, "Bulleted list", onClick = onBullet, size = d) { c -> Ic("list", 22.dp, c) }
                GrowBtn(false, "Quote", onClick = onQuote, size = d) { c -> Ic("quote", 22.dp, c) }
            }
            PillMode.Tools, PillMode.Tucked -> GrowLine(v) {
                GrowBtn(false, "Heading", onClick = onHeading, size = d) { c -> Text(headingLabel(prefix), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c) }
                GrowBtn(false, "Checklist", onClick = onCheck, size = d) { c -> Ic("taskcheck", 22.dp, c) }
            }
        }
    }
    // Aa, + and undo: the same in every state, last in the row and last in the column.
    val tail: @Composable (Boolean) -> Unit = { v ->
        val d = if (v || sel) 40.dp else 44.dp
        GrowLine(v) {
            GrowBtn(panel == 1 || panel == 2, "Text options, color and size", onClick = { onPanel(if (panel == 1) 0 else 1) }, size = d) { c -> Text("Aa", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c) }
            Box {
                GrowBtn(false, "Insert", "Quick tools", { haptics.tick(); quickOpen = true }, { menu = true }, d) { c -> Ic("plus", 22.dp, c) }
                if (menu) AddWindow(add, onQuote, onDivider, onCode, grow = true) { menu = false }
                if (quickOpen) QuickToolsWindow(quick, grow = true, layout = quickLayout, pinned = quickPinned, onPinned = onQuickPinned) { quickOpen = false }
            }
            // Undo sits last, after a thin gap, as the one button that is about history rather than writing.
            if (v) Spacer(Modifier.height(2.dp)) else Spacer(Modifier.width(2.dp))
            GrowBtn(false, "Undo", "More undo and redo", { bubble = true }, h.onUndo, d) {
                Ic("undo", 22.dp, if (h.undoLabel != null) fg else if (h.redoLabel != null) fg.copy(alpha = .6f) else fg.copy(alpha = .35f))
                PopupMenu(bubble, { bubble = false }, Sb.sheet, Sb.line) {
                    PopupItem("Undo", "undo", sub = h.undoLabel ?: "Nothing to undo", tint = if (h.undoLabel != null) Sb.ink else Sb.mute) { h.onUndo() }
                    PopupItem("Redo", "redo", sub = h.redoLabel ?: "Nothing to redo", tint = if (h.redoLabel != null) Sb.ink else Sb.mute) { h.onRedo() }
                    PopupDivider()
                    PopupItem("Revert all changes", "close", sub = if (h.canRevert) "Back to when you opened it" else "Nothing has changed",
                        tint = if (h.canRevert) Sb.ink else Sb.mute) { if (h.canRevert) { bubble = false; h.onRevert() } }
                }
            }
        }
    }
    // The pill slides out to the right while the bar slides in from the right (and back when the keyboard closes).
    AnimatedContent(layout, Modifier.fillMaxWidth(),
        transitionSpec = {
            (fadeIn(tween(200, 80)) + androidx.compose.animation.slideInHorizontally(tween(240, easing = calm)) { it / 8 })
                .togetherWith(fadeOut(tween(110)) + androidx.compose.animation.slideOutHorizontally(tween(240, easing = calm)) { it / 8 })
                .using(SizeTransform(clip = false) { _, _ -> snap() })
        }, label = "growLayout") { l ->
        if (l == 0) {
            val shape = RoundedCornerShape(24.dp)
            Box(Modifier.fillMaxWidth().padding(bottom = 14.dp), Alignment.BottomCenter) {
                Row(Modifier.softShadow(shape).clip(shape).background(growPill).height(48.dp).padding(horizontal = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    AnimatedContent(mode, transitionSpec = { fadeIn(tween(120, 40)).togetherWith(fadeOut(tween(80))).using(SizeTransform(clip = false) { _, _ -> tween(220, easing = calm) }) }, contentAlignment = Alignment.Center, label = "pillTools") { m -> tools(m, false) }
                    tail(false)
                }
            }
        } else if (l == 1) {
            val shape = RoundedCornerShape(26.dp)
            Box(Modifier.fillMaxWidth().padding(end = 10.dp, bottom = 12.dp), Alignment.BottomEnd) {
                // Anchored at the bottom (the Box): more tools make the tools group grow, and the bar with it, upward, never sideways.
                Column(Modifier.softShadow(shape).clip(shape).background(growPill)
                    .width(52.dp).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AnimatedContent(mode, transitionSpec = { fadeIn(tween(120, 40)).togetherWith(fadeOut(tween(80))).using(SizeTransform(clip = false) { _, _ -> tween(220, easing = calm) }) }, contentAlignment = Alignment.BottomCenter, label = "railTools") { m -> tools(m, true) }
                    Box(Modifier.padding(vertical = 3.dp).size(24.dp, 1.dp).background(Color.White.copy(alpha = .13f)))
                    tail(true)
                }
            }
        } else {
            // Minimized while you type: a small handle flush against the right edge, out of the way. Tap it to bring the bar back; it returns by itself when you pause.
            val shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)
            Box(Modifier.fillMaxWidth().padding(bottom = 12.dp), Alignment.BottomEnd) {
                Box(Modifier.size(30.dp, 56.dp).softShadow(shape).clip(shape).background(growPill).tap("Show tools", onWake), Alignment.Center) {
                    Text("Aa", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = fg.copy(alpha = .8f))
                }
            }
        }
    }
}

/** A group of tools: side by side in the pill, stacked in the bar. */
@Composable
private fun GrowLine(vertical: Boolean, content: @Composable () -> Unit) {
    if (vertical) Column(horizontalAlignment = Alignment.CenterHorizontally) { content() }
    else Row(verticalAlignment = Alignment.CenterVertically) { content() }
}

/**
 * Editor D, the Expanding chip: a small dark chip in the corner instead of a bar. Its face shows what you are on (Aa for text, H on a heading, the checklist, link or code
 * icon, an underlined A on selected words); tapping it grows the chip to the left into the tools for that line: the same tools as the Growing card pill ([mode], see pillMode),
 * then Aa, + and undo, which never move. The arrow at the left end shrinks it again. [open] is kept by the editor: selecting words opens it, typing closes it (see chipNext).
 * Aa, +, and the pop-ups above it work as in the Growing card, and the page's Toolbar highlight setting marks what is on.
 */
@Composable
private fun ChipBar(open: Boolean, onOpen: () -> Unit, onClose: () -> Unit, prefix: String?, h: HistoryUi, panel: Int, onPanel: (Int) -> Unit, onQuote: () -> Unit, onDivider: () -> Unit, onHeading: () -> Unit, onCheck: () -> Unit,
                    onCode: () -> Unit, add: AddActions, quick: List<QuickGroup>, bold: Boolean, italic: Boolean, onBold: () -> Unit, onItalic: () -> Unit,
                    colorNow: Color, sizeLabel: String, quickLayout: Int, quickPinned: List<String>, onQuickPinned: (List<String>) -> Unit,
                    mode: PillMode, onLevel: (Int) -> Unit, onIndent: (Int) -> Unit,
                    onOpenLink: () -> Unit, onEditLink: (() -> Unit)?, onRemoveLink: (() -> Unit)?, onCopyCode: () -> Unit, onUnwrapCode: () -> Unit) {
    var menu by remember { mutableStateOf(false) }; var quickOpen by remember { mutableStateOf(false) }; var bubble by remember { mutableStateOf(false) }
    val haptics = LocalHaptics.current; val fg = growFg; val d = if (mode == PillMode.Selection) 40.dp else 44.dp
    // One calm curve for everything: no overshoot, no bounce. The size starts to change at once and the contents fade in a moment later.
    val calm = androidx.compose.animation.core.CubicBezierEasing(.2f, 0f, 0f, 1f)
    val shape = RoundedCornerShape(26.dp)
    Box(Modifier.padding(end = 14.dp, bottom = 14.dp).softShadow(shape).clip(shape).background(growPill)) {
        AnimatedContent(open, transitionSpec = { fadeIn(tween(140, 90)).togetherWith(fadeOut(tween(90))).using(SizeTransform(clip = true) { _, _ -> tween(260, easing = calm) }) },
            contentAlignment = Alignment.BottomEnd, label = "chip") { isOpen ->
            if (!isOpen) {
                Box(Modifier.size(52.dp).tap("Show tools", onOpen), Alignment.Center) {
                    when (mode) {
                        PillMode.Selection -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("A", fontSize = 18.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold, color = fg)
                            Box(Modifier.padding(top = 2.dp).size(16.dp, 3.dp).clip(RoundedCornerShape(2.dp)).background(colorNow))
                        }
                        PillMode.Heading -> Text(headingLabel(prefix), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = fg)
                        PillMode.Task -> Ic("taskcheck", 22.dp, fg)
                        PillMode.Link -> Ic("link", 22.dp, fg)
                        PillMode.Code -> Ic("code", 22.dp, fg)
                        else -> Text("Aa", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = fg)
                    }
                }
            } else {
                Row(Modifier.animateContentSize(tween(200, easing = calm)).height(52.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    GrowBtn(false, "Hide tools", onClick = onClose, size = 32.dp) { _ -> Ic("chevron", 20.dp, fg.copy(alpha = .5f)) }
                    // The first group of tools changes with the mode and fades in place; the rest (Aa, +, undo) stays put.
                    AnimatedContent(mode, transitionSpec = { fadeIn(tween(120, 40)).togetherWith(fadeOut(tween(80))).using(SizeTransform(clip = false) { _, _ -> snap() }) }, label = "chipTools") { m ->
                        when (m) {
                            PillMode.Selection -> Row(verticalAlignment = Alignment.CenterVertically) {
                                GrowBtn(bold, "Bold", onClick = onBold, size = d) { c -> Text("B", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = c) }
                                GrowBtn(italic, "Italic", onClick = onItalic, size = d) { c -> Text("I", fontSize = 17.sp, fontWeight = FontWeight.Medium, fontStyle = FontStyle.Italic, color = c) }
                                GrowBtn(panel == 4, "Text color", onClick = { onPanel(if (panel == 4) 0 else 4) }, size = d) { c ->
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("A", fontSize = 17.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, color = c)
                                        Box(Modifier.padding(top = 2.dp).size(16.dp, 3.dp).clip(RoundedCornerShape(2.dp)).background(colorNow))
                                    }
                                }
                                GrowBtn(panel == 5, "Text size", onClick = { onPanel(if (panel == 5) 0 else 5) }, size = d) { c -> Text(sizeLabel, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c) }
                            }
                            PillMode.Heading -> Row(verticalAlignment = Alignment.CenterVertically) {
                                GrowBtn(prefix == "# ", "Heading 1", onClick = { onLevel(1) }, size = d) { c -> Text("H1", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c) }
                                GrowBtn(prefix == "## ", "Heading 2", onClick = { onLevel(2) }, size = d) { c -> Text("H2", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c) }
                            }
                            PillMode.Task -> Row(verticalAlignment = Alignment.CenterVertically) {
                                GrowBtn(false, "Outdent", onClick = { onIndent(-1) }, size = d) { c -> Ic("outdent", 22.dp, c) }
                                GrowBtn(false, "Indent", onClick = { onIndent(1) }, size = d) { c -> Ic("indent", 22.dp, c) }
                                GrowBtn(true, "Checklist", onClick = onCheck, size = d) { c -> Ic("taskcheck", 22.dp, c) }
                            }
                            PillMode.Link -> Row(verticalAlignment = Alignment.CenterVertically) {
                                GrowBtn(false, "Open link", onClick = onOpenLink, size = d) { c -> Ic("external", 22.dp, c) }
                                if (onEditLink != null) GrowBtn(false, "Edit link", onClick = onEditLink, size = d) { c -> Ic("edit", 22.dp, c) }
                                if (onRemoveLink != null) GrowBtn(false, "Remove link", onClick = onRemoveLink, size = d) { c -> Ic("trash", 22.dp, c) }
                            }
                            PillMode.Code -> Row(verticalAlignment = Alignment.CenterVertically) {
                                GrowBtn(false, "Copy code", onClick = onCopyCode, size = d) { c -> Ic("copy", 22.dp, c) }
                                GrowBtn(true, "Code block", onClick = onUnwrapCode, size = d) { c -> Ic("code", 22.dp, c) }
                            }
                            PillMode.Tools, PillMode.Tucked, PillMode.Empty -> Row(verticalAlignment = Alignment.CenterVertically) {
                                GrowBtn(false, "Heading", onClick = onHeading, size = d) { c -> Text(headingLabel(prefix), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c) }
                                GrowBtn(false, "Checklist", onClick = onCheck, size = d) { c -> Ic("taskcheck", 22.dp, c) }
                            }
                        }
                    }
                    GrowBtn(panel == 1 || panel == 2, "Text options, color and size", onClick = { onPanel(if (panel == 1) 0 else 1) }, size = d) { c -> Text("Aa", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c) }
                    Box {
                        GrowBtn(false, "Insert", "Quick tools", { haptics.tick(); quickOpen = true }, { menu = true }, d) { c -> Ic("plus", 22.dp, c) }
                        if (menu) AddWindow(add, onQuote, onDivider, onCode, grow = true) { menu = false }
                        if (quickOpen) QuickToolsWindow(quick, grow = true, layout = quickLayout, pinned = quickPinned, onPinned = onQuickPinned) { quickOpen = false }
                    }
                    Spacer(Modifier.width(2.dp))
                    GrowBtn(false, "Undo", "More undo and redo", { bubble = true }, h.onUndo, d) {
                        Ic("undo", 22.dp, if (h.undoLabel != null) fg else if (h.redoLabel != null) fg.copy(alpha = .6f) else fg.copy(alpha = .35f))
                        PopupMenu(bubble, { bubble = false }, Sb.sheet, Sb.line) {
                            PopupItem("Undo", "undo", sub = h.undoLabel ?: "Nothing to undo", tint = if (h.undoLabel != null) Sb.ink else Sb.mute) { h.onUndo() }
                            PopupItem("Redo", "redo", sub = h.redoLabel ?: "Nothing to redo", tint = if (h.redoLabel != null) Sb.ink else Sb.mute) { h.onRedo() }
                            PopupDivider()
                            PopupItem("Revert all changes", "close", sub = if (h.canRevert) "Back to when you opened it" else "Nothing has changed",
                                tint = if (h.canRevert) Sb.ink else Sb.mute) { if (h.canRevert) { bubble = false; h.onRevert() } }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GrowLabel(text: String) = Text(text, Modifier.padding(start = 2.dp, top = 6.dp), color = growFg.copy(alpha = .5f), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.08.em)

/** A group of chips that share one soft track, so related buttons read as one control. */
@Composable
private fun RowScope.GrowGroup(weight: Float, content: @Composable RowScope.() -> Unit) =
    Row(Modifier.weight(weight).clip(RoundedCornerShape(12.dp)).background(growChip).padding(2.dp), Arrangement.spacedBy(2.dp), content = content)

/** One chip inside a group: flat, tinted with the page's accent when it is on. */
@Composable
private fun RowScope.GrowChip(on: Boolean, desc: String, enabled: Boolean = true, onClick: () -> Unit, content: @Composable (Color) -> Unit) {
    val a = accentOnInk(LocalSb.current.acc)
    Box(Modifier.weight(1f).height(32.dp).clip(RoundedCornerShape(10.dp)).background(if (on) a.copy(alpha = .22f) else Color.Transparent).alpha(if (enabled) 1f else .35f)
        .semantics { selected = on }.tap(desc) { if (enabled) onClick() }, Alignment.Center) { content(if (on) a else growFg) }
}

/**
 * The dark card that grows out of the Growing card pill when Aa is on: Text (bold, italic, underline, strikethrough, lists, alignment, indent), Color (the ready colors,
 * your recent ones, and Highlight / the rainbow dot, which open the full color panel above the bar) and Size (the whole 6 to 64 list, scrolling sideways).
 */
@Composable
private fun GrowCard(prefix: String?, bold: Boolean, italic: Boolean, underline: Boolean, strike: Boolean, align: Char, indent: Int,
                     onBullet: () -> Unit, onNumber: () -> Unit, onAlign: (Char) -> Unit, onInline: (String) -> Unit, onUnderline: () -> Unit, onIndent: (Int) -> Unit,
                     color: String?, recent: List<String>, onColor: (String?) -> Unit, onMoreColor: (Int) -> Unit, sizeNow: Int?, onSize: (Int?) -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(Modifier.fillMaxWidth().softShadow(shape).clip(shape).background(growCard)
        .heightIn(max = 380.dp).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        GrowLabel("TEXT")
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            GrowGroup(1.4f) {
                GrowChip(bold, "Bold", onClick = { onInline("**") }) { c -> Text("B", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c) }
                GrowChip(italic, "Italic", onClick = { onInline("*") }) { c -> Text("I", fontSize = 16.sp, fontWeight = FontWeight.Medium, fontStyle = FontStyle.Italic, color = c) }
                GrowChip(underline, "Underline", onClick = onUnderline) { c -> Text("U", fontSize = 16.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.Underline, color = c) }
                GrowChip(strike, "Strikethrough", onClick = { onInline("~~") }) { c -> Text("S", fontSize = 16.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.LineThrough, color = c) }
            }
            GrowGroup(1f) {
                GrowChip(prefix == "- ", "Bullet list", onClick = onBullet) { c -> Ic("list", 20.dp, c) }
                GrowChip(prefix == "1. ", "Numbered list", onClick = onNumber) { c -> Ic("numbered", 20.dp, c) }
            }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            GrowGroup(1.4f) {
                GrowChip(align == 'l', "Align left", onClick = { onAlign('l') }) { c -> Ic("alignl", 20.dp, c) }
                GrowChip(align == 'c', "Align center", onClick = { onAlign('c') }) { c -> Ic("alignc", 20.dp, c) }
                GrowChip(align == 'r', "Align right", onClick = { onAlign('r') }) { c -> Ic("alignr", 20.dp, c) }
            }
            GrowGroup(1f) {
                GrowChip(false, "Indent", enabled = indent < 4, onClick = { onIndent(1) }) { c -> Ic("indent", 20.dp, c) }
                GrowChip(false, "Outdent", enabled = indent > 0, onClick = { onIndent(-1) }) { c -> Ic("outdent", 20.dp, c) }
            }
        }
        GrowLabel("COLOR")
        GrowColors(color, recent, onColor, onMoreColor)
        GrowLabel("SIZE")
        GrowSizes(sizeNow, onSize)
    }
}

/** The color part of the Growing card (and of its Color pop-up): Text and Highlight, the ready colors, the recent ones, the rainbow dot for the full panel. */
@Composable
private fun ColumnScope.GrowColors(color: String?, recent: List<String>, onColor: (String?) -> Unit, onMoreColor: (Int) -> Unit) {
    val dim = growFg.copy(alpha = .55f); val cur = color?.lowercase()
        Row(Modifier.fillMaxWidth()) {
            GrowGroup(1f) {
                GrowChip(true, "Text color", onClick = { }) { c -> Text("Text", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = c) }
                GrowChip(false, "Highlighter", onClick = { onMoreColor(1) }) { c -> Text("Highlight", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = c) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            val none = color == null
            Box(Modifier.size(28.dp).clip(CircleShape).border(if (none) 2.dp else 1.dp, if (none) growFg else dim, CircleShape).tapIcon("Default color") { onColor(null) }
                .semantics { selected = none }, Alignment.Center) { Ic("none", 16.dp, dim) }
            FONT_COLOR_PRESETS.forEach { hex ->
                val on = cur == hex
                Box(Modifier.size(28.dp).clip(CircleShape).background(hexColor(hex)).then(if (on) Modifier.border(2.dp, growFg, CircleShape) else Modifier)
                    .tapIcon("Color $hex") { onColor(hex) }.semantics { selected = on }, Alignment.Center) { if (on) Ic("check", 16.dp, onAccent(hexColor(hex))) }
            }
            Box(Modifier.size(28.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                .tapIcon("More colors") { onMoreColor(0) })
        }
        if (recent.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Recent", color = dim, fontSize = 11.sp)
            recent.forEach { hex ->
                val on = cur == hex
                Box(Modifier.size(22.dp).clip(CircleShape).background(hexColor(hex)).then(if (on) Modifier.border(2.dp, growFg, CircleShape) else Modifier)
                    .tapIcon("Recent color $hex") { onColor(hex) }.semantics { selected = on }, Alignment.Center) { if (on) Ic("check", 14.dp, onAccent(hexColor(hex))) }
            }
        }
}

/** The size part of the Growing card (and of its Size pop-up): the whole 6 to 64 list, scrolling sideways, opened near the current size. */
@Composable
private fun ColumnScope.GrowSizes(sizeNow: Int?, onSize: (Int?) -> Unit) {
    val a = accentOnInk(LocalSb.current.acc)
        val now = sizeNow ?: 17
        LazyRow(state = rememberLazyListState(initialFirstVisibleItemIndex = maxOf(FONT_SIZES.indexOf(now) - 2, 0)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(FONT_SIZES) { n ->
                val on = n == now
                Box(Modifier.size(40.dp, 32.dp).clip(RoundedCornerShape(10.dp)).background(if (on) a.copy(alpha = .22f) else growChip).semantics { selected = on }
                    .tap("Size $n") { onSize(if (n == 17) null else n) }, Alignment.Center) { Text("$n", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (on) a else growFg) }
            }
        }
}

/** The small dark card above the pill for the Color and Size buttons that show while words are selected. */
@Composable
private fun GrowPop(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(Modifier.fillMaxWidth().softShadow(shape).clip(shape).background(growCard).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
}

/** Editor B: one floating pill with inline formatting and block buttons that light up for the text under the cursor. */
@Composable
private fun PillBar(value: TextFieldValue, onInline: (String) -> Unit, onHeading: () -> Unit, onBullet: () -> Unit, onNumber: () -> Unit, onCheck: () -> Unit) {
    val t = LocalSb.current; val prefix = value.linePrefix(); val mark = lerp(t.acc, Color.White, .5f)
    Bar(floating = true) {
        BarCell(value.enclosing("**") != null, "Bold", onClick = { onInline("**") }) { c -> Text("B", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = c) }
        BarCell(value.enclosing("*") != null, "Italic", onClick = { onInline("*") }) { c -> Text("I", fontSize = 17.sp, fontWeight = FontWeight.Medium, fontStyle = FontStyle.Italic, color = c) }
        BarCell(value.enclosing("~~") != null, "Strikethrough", onClick = { onInline("~~") }) { c -> Text("S", fontSize = 17.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.LineThrough, color = c) }
        BarCell(value.enclosing("==") != null, "Highlight", onClick = { onInline("==") }) { _ ->
            Text("ab", color = Color(0xFF161616), fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.clip(RoundedCornerShape(5.dp)).background(mark).padding(horizontal = 5.dp, vertical = 1.dp))
        }
        Box(Modifier.padding(horizontal = 3.dp).width(1.dp).height(24.dp).background(Sb.line))
        BarCell(prefix == "# " || prefix == "## ", "Heading", onClick = onHeading) { c -> Text(headingLabel(prefix), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = c) }
        BarCell(prefix == "- ", "Bullet list", onClick = onBullet) { c -> Ic("list", 22.dp, c) }
        BarCell(prefix == "1. ", "Numbered list", onClick = onNumber) { c -> Ic("numbered", 22.dp, c) }
        BarCell(prefix == "- [ ] " || prefix == "- [x] ", "Checklist", onClick = onCheck) { c -> Ic("taskcheck", 22.dp, c) }
    }
}

/** Opens a link from the page in whatever app handles it, or says that nothing here can. */
private fun openPageLink(ctx: android.content.Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: android.content.ActivityNotFoundException) { Toast.makeText(ctx, "Nothing on this phone can open that.", Toast.LENGTH_SHORT).show() }
}

/** A photo as a taped polaroid; while writing ([removable]) the cross removes it. */
@Composable
private fun Polaroid(uri: String, kind: Kind, i: Int, removable: Boolean, onOpen: () -> Unit, onHold: (() -> Unit)? = null, onRemove: () -> Unit) {
    Box(Modifier.padding(horizontal = 8.dp, vertical = 12.dp).rotate(if (i % 2 == 0) -3f else 3f)) {
        Box(Modifier.softShadow(RoundedCornerShape(8.dp)).background(Color.White, RoundedCornerShape(8.dp)).padding(5.dp)) {
            ItemImage(Item(title = "", body = "", kind = kind, collection = "", imageUri = uri),
                Modifier.size(150.dp, 120.dp).let { m -> if (onHold != null) m.tapOrHold("Open photo", "Photo options", onHold = onHold) { onOpen() } else m.tap("Open photo", onOpen) }, 4.dp)
        }
        Box(Modifier.align(Alignment.TopCenter).offset(y = (-8).dp).size(56.dp, 16.dp).rotate(-2f).background(Color(0x77A8A8A8)))
        // The cross only shows while writing; reading the page never takes a photo off by accident.
        if (removable) Box(Modifier.align(Alignment.TopEnd).size(48.dp).tapIcon("Remove image") { onRemove() }, Alignment.Center) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(Color(0x99000000)), Alignment.Center) { Ic("close", 14.dp, Color.White) }
        }
    }
}

/** A 40dp round button inside the header's action pill. */
@Composable
internal fun HeaderBtn(desc: String, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).tapIcon(desc, onClick), Alignment.Center) { content() }
}

/** The 3-dot menu surface: 252dp wide, corners from the menu skin (24dp in Classic), hanging under the header's top-right corner. */
@Composable
internal fun MenuPanel(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(menuSkin().popupCorner)
    // It can be taller than a small screen, so it scrolls inside the room that is left.
    Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(top = 60.dp, end = 16.dp, bottom = 16.dp).width(252.dp)
        .softShadow(shape).clip(shape).background(Sb.menu).verticalScroll(rememberScrollState()).padding(8.dp), content = content)
}

/** The 3-dot menu of the editor and the reading view: the screen dims and a card drops from the header's top-right corner. Back or a tap outside closes it. */
@Composable
internal fun BoxScope.HeaderMenu(open: Boolean, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    BackHandler(open) { onClose() }
    AnimatedVisibility(open, Modifier.fillMaxSize(), enter = fadeIn(tween(120)), exit = fadeOut(tween(100))) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .5f)).semantics { contentDescription = "Close menu" }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() })
    }
    AnimatedVisibility(open, Modifier.align(Alignment.TopEnd),
        enter = fadeIn(tween(140)) + scaleIn(tween(160), initialScale = .92f, transformOrigin = TransformOrigin(1f, 0f)), exit = fadeOut(tween(100))) {
        MenuPanel(content)
    }
}

/** The pages of the editor's 3-dot menu: the short main list and the groups inside it. */
internal enum class MenuPage { Main, Add, Page, Share, Format }

/** One menu row: icon and label, with an optional second line. */
@Composable
internal fun MenuRow(icon: String, label: String, sub: String? = null, tint: Color = Sb.ink, iconColor: Color = tint, enabled: Boolean = true, chevron: Boolean = false, onClick: () -> Unit) {
    val sans = LocalFonts.current.second
    Row(Modifier.fillMaxWidth().height(if (sub != null) 58.dp else 52.dp).clip(RoundedCornerShape(16.dp)).alpha(if (enabled) 1f else .4f)
        .tap(label) { if (enabled) onClick() }.padding(horizontal = 12.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic(icon, 22.dp, iconColor)
        Column(Modifier.weight(1f)) {
            Text(label, color = tint, fontSize = 16.sp, lineHeight = 20.sp, fontFamily = sans)
            if (sub != null) Text(sub, color = Sb.mute, fontSize = 12.5.sp, lineHeight = 16.sp, fontFamily = sans)
        }
        // A row that opens a page inside the menu ends with an arrow.
        if (chevron) Ic("chevron", 20.dp, Sb.mute)
    }
}

/** The top row of a page inside the 3-dot menu: an arrow back to the main list and the page's name. */
@Composable
internal fun MenuBack(title: String, onBack: () -> Unit) {
    val sans = LocalFonts.current.second
    Row(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(16.dp)).tap("Back to menu") { onBack() }.padding(horizontal = 12.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic("back", 22.dp, Sb.mute)
        Text(title, color = Sb.mute, fontSize = 14.sp, lineHeight = 18.sp, fontFamily = sans, fontWeight = FontWeight.Medium)
    }
}

@Composable
internal fun MenuDivider() = Box(Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth().height(1.dp).background(Sb.menuLine))

/** The floating card the toolbar's text options, color and size open above the bar. It is the toolbar's own color, so it reads as part of the bar. */
@Composable
private fun PanelCard(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(menuSkin().popupCorner)
    Column(Modifier.fillMaxWidth().softShadow(shape).clip(shape).background(Sb.sheet)
        .padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Sb.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, fontFamily = LocalFonts.current.second, modifier = Modifier.weight(1f))
            Box(Modifier.size(44.dp).clip(CircleShape).tapIcon("Close") { onClose() }, Alignment.Center) { Ic("close", 22.dp, Sb.ink) }
        }
        Column(Modifier.padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

/** A rounded group of option buttons inside a panel. */
@Composable
private fun OptGroup(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) =
    Row(modifier.clip(RoundedCornerShape(18.dp)).background(Sb.tile).padding(4.dp), verticalAlignment = Alignment.CenterVertically, content = content)

/** One option button; on tints it with the accent. */
@Composable
private fun RowScope.OptBtn(on: Boolean, desc: String, enabled: Boolean = true, onClick: () -> Unit, content: @Composable (Color) -> Unit) {
    val acc = LocalSb.current.acc
    Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(14.dp)).onMark(on, acc, RoundedCornerShape(14.dp))
        .alpha(if (enabled) 1f else .35f).semantics { selected = on }.tap(desc) { if (enabled) onClick() }, Alignment.Center) { content(if (on) accentText(acc) else Sb.ink); OnDot(on, acc, 2.dp) }
}

/** Text options: lists, alignment, bold, italic, underline, strikethrough, indent and outdent. */
@Composable
private fun TextOptionsPanel(prefix: String?, bold: Boolean, italic: Boolean, underline: Boolean, strike: Boolean, align: Char, indent: Int,
                             onBullet: () -> Unit, onNumber: () -> Unit, onAlign: (Char) -> Unit, onInline: (String) -> Unit, onUnderline: () -> Unit,
                             onIndent: (Int) -> Unit, onClose: () -> Unit) {
    PanelCard("Text options", onClose) {
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            OptGroup(Modifier.weight(2f)) {
                OptBtn(prefix == "- ", "Bullet list", onClick = onBullet) { c -> Ic("list", 22.dp, c) }
                OptBtn(prefix == "1. ", "Numbered list", onClick = onNumber) { c -> Ic("numbered", 22.dp, c) }
            }
            OptGroup(Modifier.weight(3f)) {
                OptBtn(align == 'l', "Align left", onClick = { onAlign('l') }) { c -> Ic("alignl", 22.dp, c) }
                OptBtn(align == 'c', "Align center", onClick = { onAlign('c') }) { c -> Ic("alignc", 22.dp, c) }
                OptBtn(align == 'r', "Align right", onClick = { onAlign('r') }) { c -> Ic("alignr", 22.dp, c) }
            }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            OptGroup(Modifier.weight(4f)) {
                OptBtn(bold, "Bold", onClick = { onInline("**") }) { c -> Text("B", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = c) }
                OptBtn(italic, "Italic", onClick = { onInline("*") }) { c -> Text("I", fontSize = 18.sp, fontWeight = FontWeight.Medium, fontStyle = FontStyle.Italic, color = c) }
                OptBtn(underline, "Underline", onClick = onUnderline) { c -> Text("U", fontSize = 18.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.Underline, color = c) }
                OptBtn(strike, "Strikethrough", onClick = { onInline("~~") }) { c -> Text("S", fontSize = 18.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.LineThrough, color = c) }
            }
            OptGroup(Modifier.weight(2f)) {
                OptBtn(false, "Indent", enabled = indent < 4, onClick = { onIndent(1) }) { c -> Ic("indent", 22.dp, c) }
                OptBtn(false, "Outdent", enabled = indent > 0, onClick = { onIndent(-1) }) { c -> Ic("outdent", 22.dp, c) }
            }
        }
    }
}

/**
 * Font size, like Samsung Notes: a narrow list that opens right above the size button and runs from 6 to 64 (see FONT_SIZES). The size you have now is in the
 * accent color and the list opens scrolled to it. Picking the normal size takes the size off the text again, so it follows the page's size.
 */
@Composable
private fun SizeList(current: Int?, normal: Int, onPick: (Int?) -> Unit, onClose: () -> Unit) {
    val acc = accentText(LocalSb.current.acc); val density = LocalDensity.current
    val now = current ?: normal
    val rowH = 46.dp; val listH = 250.dp
    val state = rememberLazyListState(initialFirstVisibleItemIndex = maxOf(FONT_SIZES.indexOf(now) - 2, 0))
    // Not focusable: the keyboard stays up and the text keeps its selection. A tap outside is caught by the screen behind it (the panel host), and Back closes it.
    Popup(alignment = Alignment.TopCenter, offset = IntOffset(0, -with(density) { (listH + 10.dp).roundToPx() }), properties = PopupProperties(focusable = false)) {
        val shape = RoundedCornerShape(18.dp)
        LazyColumn(Modifier.width(104.dp).height(listH).softShadow(shape).clip(shape).background(Sb.sheet)
            .border(1.dp, Sb.line, shape).padding(horizontal = 6.dp), state = state) {
            items(FONT_SIZES) { n ->
                val on = n == now
                Box(Modifier.fillMaxWidth().padding(vertical = 1.dp).height(rowH - 2.dp).onMark(on, LocalSb.current.acc, RoundedCornerShape(14.dp)).semantics { selected = on }
                    .tap("Size $n") { onPick(if (n == normal) null else n); onClose() }, Alignment.CenterStart) {
                    if (on && barLookNow == 1) Box(Modifier.padding(start = 12.dp).size(5.dp).clip(CircleShape).background(acc))
                    Text("$n", Modifier.padding(start = 28.dp), fontSize = 17.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, color = if (on) acc else Sb.ink)
                }
            }
        }
    }
}


/** A bar with a gradient and a round handle. onChange runs while dragging, onDone when the finger lifts. */
@Composable
internal fun GradientSlider(value: Float, brush: Brush, handle: Color, onChange: (Float) -> Unit, onDone: () -> Unit) {
    var w by remember { mutableIntStateOf(1) }
    val change by rememberUpdatedState(onChange); val done by rememberUpdatedState(onDone)
    Box(Modifier.fillMaxWidth().height(34.dp).onSizeChanged { w = it.width.coerceAtLeast(1) }.clip(RoundedCornerShape(17.dp)).background(brush)
        .pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                change((down.position.x / size.width).coerceIn(0f, 1f)); down.consume()
                do {
                    val ev = awaitPointerEvent(); val c = ev.changes.firstOrNull() ?: break
                    change((c.position.x / size.width).coerceIn(0f, 1f)); c.consume()
                } while (ev.changes.any { it.pressed })
                done()
            }
        }) {
        Box(Modifier.offset { IntOffset((value * (w - 34.dp.roundToPx())).roundToInt(), 0) }.size(34.dp).padding(3.dp).clip(CircleShape).background(handle).border(2.dp, Color.White, CircleShape))
    }
}

/**
 * A normal notes editor: autosaves as you type, formatting toolbar, lists continue on Enter, undo and redo. id == 0 starts a new note.
 * An existing scrap is opened only once it has been read. When Android has closed the app and brings it back on this screen, the list in
 * memory is still empty for a moment; starting from it would show an empty editor, and typing there would overwrite the real scrap.
 */
@Composable
fun EditorScreen(vm: ArchiveViewModel, nav: NavController, routeId: Long) {
    // A new scrap's route stays "edit/0" even after its first save gives it a real id. So that id is also kept in the saved state of this screen: if Android
    // closes the app and brings it back, the screen reopens that scrap with its text instead of an empty page. It is read once, when the screen first appears
    // (a later change must not swap the scrap under your fingers while you type).
    var made by rememberSaveable(routeId) { mutableStateOf(0L) }
    val id = remember(routeId) { if (routeId == 0L) made else routeId }
    val cached = remember(id) { if (id == 0L) null else vm.items.value.firstOrNull { it.id == id } }
    var loaded by remember(id) { mutableStateOf(id == 0L || cached != null) }
    var stored by remember(id) { mutableStateOf(cached) }
    LaunchedEffect(id) {
        if (!loaded) {
            val item = vm.load(id)
            // The scrap is gone (deleted): there is nothing to edit, so go back rather than start an empty one under its old id.
            if (item == null) { nav.popBackStack(); return@LaunchedEffect }
            stored = item; loaded = true
        }
    }
    LaunchedEffect(id, loaded) { if (id != 0L && loaded) vm.opened(Recents.scrap(id)) }   // feeds the quick switcher's "Recently opened"
    // The scrap's own accent color colors the whole editor (cursor, buttons, selection), the way it does in the reading view.
    val all by vm.items.collectAsState(); val baseTheme = LocalSb.current
    val accent = all.firstOrNull { it.id == (if (routeId != 0L) routeId else made) }?.accent ?: stored?.accent ?: 0
    CompositionLocalProvider(LocalSb provides baseTheme.copy(acc = pageAccent(accent) ?: baseTheme.acc)) {
        if (loaded) EditorContent(vm, nav, id, stored) { made = it }
        else Box(Modifier.fillMaxSize().background(LocalSb.current.editorPage))
    }
}

/**
 * Runs [content] as a function of its own. Row, Column and Box are inlined into whatever calls them, so a long screen turns into one enormous method, and
 * when a method gets that big R8 (the optimizer of the release build) writes code Android refuses to load: the app then crashes with a VerifyError the moment
 * the page opens. Putting a big block inside Chunk gives that block a method of its own. It draws nothing and changes nothing else.
 */
@Composable
private fun Chunk(content: @Composable () -> Unit) { content() }

@Composable
private fun EditorContent(vm: ArchiveViewModel, nav: NavController, id: Long, existing: Item?, onCreated: (Long) -> Unit) {
    val t = LocalSb.current; val list by vm.items.collectAsState(); val scope = rememberCoroutineScope(); val haptics = LocalHaptics.current; val fileCtx0 = LocalContext.current
    val knownTags = remember(list) { tagCounts(list) }
    var curId by remember(id) { mutableLongStateOf(id) }
    // Where you were the last time you left this scrap (cursor, scroll, keyboard). Read right here, before the first frame, so the page opens in place instead of jumping.
    val memory = remember { EditorMemory(fileCtx0) }
    val spot = remember(id) { if (existing != null && id != 0L) memory.get(id) else null }
    // Three ways to be on this page. Reading (the way every scrap opens): no toolbar, a tap puts you in the editor. Writing: the toolbar is up and the text can be changed.
    // View only: the page is locked, nothing changes and a tap does nothing until you turn it off with the book button. That choice is kept for each scrap on this phone,
    // so a locked scrap opens locked next time, whatever the others do. A new scrap starts in writing.
    var locked by remember(id) { mutableStateOf(existing != null && id != 0L && memory.isLocked(id)) }
    var editing by rememberSaveable(id) { mutableStateOf(existing == null) }
    // Where the text and each photo and each file sit on the page, from the top down (see PageLayout). Changed by dragging a photo or a file, or with Arrange page.
    // The same in reading and in writing.
    var pageParts by remember(id) { mutableStateOf(PageLayout.parse(existing?.blocks, existing?.allImages()?.size ?: 0, existing?.attachments()?.size ?: 0)) }
    // Photos and files that are not in line: they wrap the text or float anywhere (see Floats.kt and FloatLayer.kt). Keyed by the photo's address or the file's path.
    var placed by remember(id) { mutableStateOf(Floats.parse(existing?.blocks, existing?.allImages() ?: emptyList(), existing?.attachments()?.map { it.path } ?: emptyList())) }
    var cards by remember(id) { mutableStateOf(PageCards.parse(existing?.canvas)) }; var cardEdit by remember(id) { mutableStateOf<String?>(null) }
    var selFloat by remember(id) { mutableStateOf<String?>(null) }                       // the placed photo or file that is selected (it has a frame, a handle and a bar)
    var floatSizes by remember(id) { mutableStateOf<Map<String, IntSize>>(emptyMap()) } // how big each placed object is on screen, in px
    var wrapSp by remember(id) { mutableStateOf<Map<Int, Float>>(emptyMap()) }          // how far each line of the text is pushed in to make room beside a wrapped object
    var textBoxW by remember(id) { mutableIntStateOf(0) }
    var arrangeOpen by remember { mutableStateOf(false) }; var boxOpen by remember { mutableStateOf(false) }; var tagsOpen by remember { mutableStateOf(false) }
    // "Link to scrap": the picker is open, and (when it was opened by typing [[) which two characters the chosen link replaces.
    var pickerOpen by remember { mutableStateOf(false) }; var pickerAt by remember { mutableStateOf<IntRange?>(null) }; var switcher by remember { mutableStateOf(false) }
    var title by remember(id) { mutableStateOf(existing?.let { x -> if (bodyWithoutTitle(x.title, x.body) != x.body) "" else x.title } ?: "") }
    var body by remember(id) { mutableStateOf(existing?.body?.let { TextFieldValue(it, TextRange(EditorSpots.cursorFor(spot, it.length))) } ?: vm.takePendingBody()?.let { TextFieldValue(it, TextRange(it.length)) } ?: TextFieldValue("")) }
    // Deleting the mark of an empty list, checklist, quote or heading line ("- [ ] ") is one backspace for the person, but the keyboard deletes one character
    // at a time. Rewriting the whole mark in one go made the keyboard stop repeating a held backspace, so now its single-character deletion is taken as it is:
    // what is left of the mark (the remnant) is hidden, goes with the next deletion or, when nothing follows, after a moment. remStart is where the remnant
    // starts in the text (-1 for none) and remText what is left of it; lastBackAt is when the last character was deleted.
    var remStart by remember(id) { mutableIntStateOf(-1) }
    var remText by remember(id) { mutableStateOf("") }
    var lastBackAt by remember(id) { mutableLongStateOf(0L) }
    fun remOk(text: String) = remStart >= 0 && remText.isNotEmpty() && text.startsWith(remText, remStart)
    /** The text without the remnant, and the selection moved to match; as it is when there is none. */
    fun withoutRemnant(v: TextFieldValue): TextFieldValue {
        if (!remOk(v.text)) return v
        val a = remStart; val n = remText.length
        fun sh(x: Int) = if (x >= a + n) x - n else if (x > a) a else x
        return TextFieldValue(v.text.removeRange(a, a + n), TextRange(sh(v.selection.start), sh(v.selection.end)))
    }
    var color by remember(id) { mutableIntStateOf(existing?.color ?: 0) }
    var kind by remember(id) { mutableStateOf(existing?.kind ?: Kind.Note) }
    var shelf by remember(id) { mutableStateOf(existing?.collection ?: vm.takePendingShelf() ?: "Inbox") }
    var tags by remember(id) { mutableStateOf(existing?.tags?.joinToString(", ") ?: vm.takePendingTags() ?: "") }
    // Hashtags: a #word typed in the text becomes a tag (see Hashtags.kt). hashBase holds the ones already dealt with, so a #word that was in the text when the
    // scrap was opened, or whose tag you took off, is not turned into a tag again.
    val hashtagsOn by vm.hashtagTags.collectAsState()
    val pasteOffers by vm.pasteOffers.collectAsState()
    val plainPhotos by vm.plainPhotos.collectAsState(); val screenDp = LocalConfiguration.current.screenWidthDp
    var hashBase by remember(id) { mutableStateOf(hashtagKeys(existing?.body.orEmpty())) }
    var imgs by remember(id) { mutableStateOf(existing?.allImages() ?: emptyList()) }
    var files by remember(id) { mutableStateOf(existing?.attachments() ?: emptyList()) }
    var viewerAt by remember { mutableStateOf<Int?>(null) }   // the photo open full screen, if any
    var source by remember(id) { mutableStateOf(existing?.source ?: "") }
    var menu by remember { mutableStateOf(false) }
    // Which page of the 3-dot menu is showing: 0 is the short main list, the others are the groups inside it.
    var menuPage by remember { mutableStateOf(MenuPage.Main) }
    var recording by remember { mutableStateOf(false) }   // the Record audio sheet is open
    // History: one list of steps for everything that can be changed here, so Undo and Redo cover the text, the title, photos, color, type, box, tags and
    // source. Every change calls record() just before it is applied (see History.kt for how steps are grouped).
    fun snap() = Snap(title, withoutRemnant(body), color, kind, shelf, tags, imgs, source, files, PageLayout.fit(pageParts, imgs.size, files.size), Floats.clean(placed, imgs, files.map { it.path }), cards)
    val hist = remember { History<Snap>({ it.body.text.length + it.title.length + it.tags.length }) }
    var histVer by remember { mutableIntStateOf(0) }   // read on screen so the buttons and the bubble refresh after every undo and redo
    val origin = remember(id) { snap() }                // how the scrap was when it was opened, for "Revert all changes"
    fun record(what: String, key: String = what, merge: Boolean = false) { hist.record(snap(), what, System.currentTimeMillis(), key, merge); histVer++ }
    fun restore(s: Snap) {
        remStart = -1; remText = ""
        title = s.title; body = s.body.copy(composition = null); color = s.color; kind = s.kind; shelf = s.shelf; tags = s.tags; imgs = s.imgs; source = s.source; files = s.files; pageParts = s.parts; placed = s.placed; cards = s.cards
    }
    fun doUndo() { hist.undo(snap())?.let { restore(it); histVer++ } }
    fun doRedo() { hist.redo(snap())?.let { restore(it); histVer++ } }
    fun revertAll() { if (!snap().sameAs(origin)) { record("Revert"); restore(origin) } }

    // Carrying a photo or a file to another place on the page. Holding it opens a small menu (menuFor: "p2" is the third photo, "f0" the first file);
    // Drag in that menu starts carrying it (dragKey). While the finger moves, dragGap is the gap it would drop into (see PageLayout.dropGap) and
    // dragLine is where the line that shows it is drawn; letting go moves it there.
    var menuFor by remember { mutableStateOf<String?>(null) }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragGap by remember { mutableStateOf<Int?>(null) }
    var dragLine by remember { mutableStateOf<Cell?>(null) }
    var dragAt by remember { mutableStateOf(Offset.Zero) }
    var dragging by remember { mutableStateOf(false) }
    var overlayCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val objCoords = remember { HashMap<String, LayoutCoordinates>() }
    fun startDrag(key: String) { menuFor = null; dragKey = key; dragGap = null; dragLine = null; dragging = false; dragAt = Offset.Zero }
    fun cancelDrag() { dragKey = null; dragGap = null; dragLine = null; dragging = false }
    fun updateDrop() {
        val key = dragKey ?: return
        val oc = overlayCoords ?: return
        if (!oc.isAttached) return
        val origin = oc.positionInRoot()
        val ps = PageLayout.fit(pageParts, imgs.size, files.size)
        var pk = 0; var fk = 0
        val cells = ps.map { part ->
            val id = when (part) { Part.Photo -> "p${pk++}"; Part.File -> "f${fk++}"; Part.Text -> "T" }
            val c = objCoords[id]
            if (c != null && c.isAttached) { val q = c.positionInRoot(); Cell(q.x, q.y, q.x + c.size.width, q.y + c.size.height) } else null
        }
        val gap = PageLayout.dropGap(ps, cells, if (key.startsWith("p")) Part.Photo else Part.File, origin.x + dragAt.x, origin.y + dragAt.y)
        dragGap = gap
        dragLine = PageLayout.dropLine(ps, cells, gap)?.let { Cell(it.left - origin.x, it.top - origin.y, it.right - origin.x, it.bottom - origin.y) }
    }
    fun commitDrop() {
        val key = dragKey; val gap = dragGap
        cancelDrag()
        if (key == null || gap == null) return
        val part = if (key.startsWith("p")) Part.Photo else Part.File
        val n = key.drop(1).toIntOrNull() ?: return
        val ps = PageLayout.fit(pageParts, imgs.size, files.size)
        val m = PageLayout.moveResult(ps, PageLayout.slotOf(ps, part, n), gap) ?: return
        record(if (part == Part.Photo) "Photo moved" else "File moved")
        pageParts = m.layout
        if (m.fromKind != m.toKind) { if (part == Part.Photo) imgs = imgs.movedItem(m.fromKind, m.toKind) else files = files.movedItem(m.fromKind, m.toKind) }
    }
    fun setTitle(v: String) { val n = v.replace("\n", " "); if (n != title) { record("Title", merge = true); title = n } }
    fun setColor(v: Int) { if (v != color) { record("Color"); color = v } }
    fun setKind(v: Kind) { if (v != kind) { record("Type"); kind = v } }
    fun setShelf(v: String) { if (v != shelf) { haptics.tick(); record("Box"); shelf = v } }
    fun setTags(v: String) { if (v != tags) { record("Tags", merge = true); tags = v } }
    fun setSource(v: String) { if (v != source) { record("Source", merge = true); source = v } }
    val lock = remember { Mutex() }; var leaving by remember { mutableStateOf(false) }
    // Autosave is silent by design (it happens while you type), so a small "Saved" shows in the header for a moment after each real save instead of a vibration.
    var savedPulse by remember { mutableStateOf(0) }; var savedMark by remember { mutableStateOf(false) }
    LaunchedEffect(savedPulse) { if (savedPulse > 0) { savedMark = true; delay(1500); savedMark = false } }
    val editorStyle by vm.editorStyle.collectAsState(); val barLook by vm.toolbarLook.collectAsState(); val quickLayout by vm.quickLayout.collectAsState(); val quickPinned by vm.quickPinned.collectAsState(); SideEffect { barLookNow = barLook }; val showSaved by vm.showSaved.collectAsState(); val autoKeyboard by vm.autoKeyboard.collectAsState()
    var touching by remember { mutableStateOf(false) }; var touchEnd by remember { mutableLongStateOf(0L) }   // a finger on the text, and when the last one lifted
    val scroll = rememberScrollState(spot?.scroll ?: 0); var viewportH by remember { mutableIntStateOf(0) }; var fieldTop by remember { mutableFloatStateOf(0f) }
    var textLayout by remember { mutableStateOf<TextLayoutResult?>(null) }; var focused by remember { mutableStateOf(false) }
    val live = list.firstOrNull { it.id == curId }
    val baseLine = pageLine((live ?: existing)?.density ?: 1).value
    val tc = LocalTextColors.current
    val accT = accentText(t.acc)   // hashtags and links in the text: the accent, deepened when it would be too faint to read
    val remRange = if (remOk(body.text)) remStart until remStart + remText.length else null
    // This page's highlighter: its color and strength, set in the toolbar's color panel (Highlighter). Each page has its own; it is written to the page at once
    // when the page exists, and goes with the first save when it does not yet.
    var mk by remember(id) { mutableStateOf((live ?: existing)?.let { Marker(it.hlColor, it.hlOpacity) } ?: Marker()) }
    fun setMarker(m: Marker) { mk = m; if (curId != 0L) vm.setHighlight(curId, m.color, m.opacity) }
    val hl = markerStyle(t.acc, mk, Sb.paper)
    val view = remember(body.text, accT, Sb.ink, baseLine, tc, wrapSp, remRange, hl) {
        val t0 = System.nanoTime()
        mdRender(body.text, accT, baseLine, tc, wrapSp, remRange, hl).also { lastStyledMs = (System.nanoTime() - t0) / 1_000_000L }
    }
    val viewNow by rememberUpdatedState(view)
    // Find in scrap: the find bar replaces the header while it is open. Matches are searched in the text as shown (without the hidden marks), so they
    // line up with what is drawn. The current match gets the strong mark, and is scrolled into view when you move to it or change the query.
    val findEntry by vm.findEntry.collectAsState()
    var finding by remember { mutableStateOf(false) }; var findQ by remember { mutableStateOf("") }; var findAt by remember { mutableIntStateOf(0) }
    val matches = remember(view, findQ, finding) { if (finding) findMatches(view.out.text.text, findQ) else emptyList<IntRange>() }
    val findCur = if (matches.isEmpty()) -1 else findAt.coerceIn(0, matches.lastIndex)
    val md = remember(view, matches, findCur, t.acc) {
        VisualTransformation { s ->
            val out = if (s.text == view.source) view.out else mdRender(s.text, accT, baseLine, tc, wrapSp, remRange, hl).out
            if (matches.isEmpty()) out else withFindMarks(out, matches, findCur, t.acc)
        }
    }
    LaunchedEffect(finding, findAt, findQ) {
        val lay = textLayout
        if (!finding || findCur < 0 || lay == null) return@LaunchedEffect
        val line = lay.getLineForOffset(matches[findCur].first.coerceIn(0, (lay.layoutInput.text.length - 1).coerceAtLeast(0)))
        val top = fieldTop + lay.getLineTop(line); val bottom = fieldTop + lay.getLineBottom(line)
        if (top < scroll.value + 16 || bottom > scroll.value + viewportH - 16) scroll.animateScrollTo((top - viewportH / 3f).toInt().coerceIn(0, scroll.maxValue))
    }
    // Follow the cursor (see CaretFollow.kt): when typing, the keyboard or the arrow keys put the cursor near the bottom or top edge of what you can see, the page glides
    // just far enough to bring it back, at the speed chosen in Settings > Editor. It is never started by a finger: not while one is on the page, and not for the cursor a tap just
    // placed (you tapped where you could see). Not while finding or carrying a photo (they scroll on their own) and not in view only. A finger that starts to scroll takes over at once.
    val followTopM = with(LocalDensity.current) { 28.dp.toPx() }; val followBottomM = with(LocalDensity.current) { 64.dp.toPx() }
    val followSpeed by vm.followSpeed.collectAsState(); val speedNow by rememberUpdatedState(followSpeed)
    var followTo by remember { mutableFloatStateOf(-1f) }   // where the page is gliding to (-1: nowhere)
    var seenText by remember(id) { mutableStateOf(body.text) }; var seenView by remember(id) { mutableIntStateOf(viewportH) }
    val prevSel = remember { intArrayOf(body.selection.start, body.selection.end) }
    LaunchedEffect(body.selection.start, body.selection.end, textLayout, viewportH, editing, focused) {
        // The edge of the selection that moved is the one to keep in view: dragging the start handle up has to bring the page up too, not only the end handle down.
        val startMoved = body.selection.start != prevSel[0]; val endMoved = body.selection.end != prevSel[1]
        prevSel[0] = body.selection.start; prevSel[1] = body.selection.end
        val edge = if (startMoved && !endMoved) body.selection.start else body.selection.end
        val lay = textLayout
        if (!editing || locked || !focused || finding || dragKey != null || lay == null || viewportH <= 0) return@LaunchedEffect
        // The layout is from the text as it was a moment ago; wait for the one that matches (this effect starts again when it arrives).
        if (lay.layoutInput.text.length != view.out.text.length) return@LaunchedEffect
        val typed = body.text != seenText; val resized = viewportH != seenView
        seenText = body.text; seenView = viewportH
        if (!typed && !resized && (touching || System.currentTimeMillis() - touchEnd < 450L)) return@LaunchedEffect
        val at = view.out.offsetMapping.originalToTransformed(edge.coerceIn(0, body.text.length)).coerceIn(0, lay.layoutInput.text.length)
        val r = lay.getCursorRect(at)
        followTo = CaretFollow.goal(fieldTop + r.top, fieldTop + r.bottom, scroll.value.toFloat(), viewportH.toFloat(), followTopM, followBottomM) ?: -1f
    }
    LaunchedEffect(Unit) {
        snapshotFlow { followTo }.collectLatest { goal ->
            if (goal < 0f) return@collectLatest
            val rate = CaretFollow.rate(speedNow)
            try {
                if (rate == null) { scroll.scrollTo(goal.roundToInt().coerceIn(0, scroll.maxValue)); return@collectLatest }
                var last = withFrameNanos { it }; var waited = 0
                while (true) {
                    val now = withFrameNanos { it }; val dt = (now - last) / 1_000_000_000f; last = now
                    val to = minOf(goal, scroll.maxValue.toFloat()); val left = to - scroll.value
                    // The page may still be growing under the new line: give it a few frames before settling for less.
                    if (abs(left) <= 1f) { if (goal - scroll.maxValue > 1f && ++waited < 6) continue else break }
                    if (abs(scroll.scrollBy(CaretFollow.step(left, rate, dt))) < 0.01f) break
                }
            } catch (e: CancellationException) {
                // A finger took the scroll (or the page is gone): if this coroutine is still wanted, just stop gliding.
                currentCoroutineContext().ensureActive(); followTo = -1f
            }
        }
    }
    val clipboard = LocalClipboardManager.current
    var linkSheet by remember { mutableStateOf<TextRange?>(null) }; var linkUrl by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris -> uris.forEach { u -> vm.importImage(u) { p -> record("Photo added", merge = true); imgs = imgs + p } } }
    val cardsOn = live != null && live.layout == Layout.Cards
    var cardPicTarget by remember { mutableStateOf("icon") }
    val pickCardPic = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) vm.importImage(u) { p ->
            cardEdit?.let { cid ->
                record("Card picture")
                cards = PageCards.update(cards, cid) { c -> if (cardPicTarget == "badge") c.copy(badgeIcon = PageCards.PIC + p) else c.copy(icon = PageCards.PIC + p) }
            }
        }
    }
    val cardsDensity = androidx.compose.ui.platform.LocalDensity.current.density
    fun addCard() {
        record("Add card")
        val c = PageCards.newCard(cards, scroll.value / cardsDensity)
        cards = cards + c
        cardEdit = c.id
    }
    fun addImage() = pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    // Any file: a PDF, a zip, a document... Each is copied into the app (see ArchiveViewModel.importFile) and shows as a card under the photos.
    val fileCtx = LocalContext.current
    // ---- Photos and files placed on the page (Floats.kt, FloatLayer.kt) ----
    val dn = LocalDensity.current
    val lineTops = remember(textLayout, view) { lineTopsOf(textLayout, view) }
    val floatItems = remember(placed, imgs, files) { floatItemsOf(placed, imgs, files) }
    // The text beside a wrapped object is pushed in, one line (paragraph) at a time. Pushing a line in can make it wrap onto more lines, which moves the lines
    // below it, so this runs again each time the text has been laid out again, and stops when nothing changes.
    LaunchedEffect(textLayout, view, floatItems, floatSizes, textBoxW) {
        val zones = floatItems.filter { it.placed.how == Placing.Wrap }
            .map { f -> WrapZone(f.placed.line, (floatSizes[f.key]?.height ?: 0) + 8f * dn.density, f.placed.width * textBoxW + 12f * dn.density) }
        if (zones.isEmpty()) { if (wrapSp.isNotEmpty()) wrapSp = emptyMap(); return@LaunchedEffect }
        val lay = textLayout ?: return@LaunchedEffect
        if (textBoxW <= 0 || lay.layoutInput.text.length != view.out.text.length) return@LaunchedEffect
        val next = Floats.indents(lineTopsOf(lay, view), zones).mapValues { it.value / (dn.density * dn.fontScale) }
        if (next != wrapSp) wrapSp = next
    }
    // The text box is at least as tall as the lowest placed object, so nothing hangs out of the page.
    val floatsMinDp = remember(floatItems, floatSizes, lineTops, dn.density) {
        var bottom = 0f
        for (f in floatItems) {
            val top = if (f.placed.how == Placing.Wrap) (lineTops.getOrNull(f.placed.line) ?: 0f) else f.placed.y * dn.density
            bottom = maxOf(bottom, top + (floatSizes[f.key]?.height ?: 0))
        }
        bottom / dn.density
    }
    /** Switches a photo or file between in line, wrapped and free. The object stays selected so it can be moved and resized right away. */
    fun setMode(key: String, how: Placing) {
        val cur = placed[key]
        val topDp = if (cur != null && cur.how == Placing.Wrap) (lineTops.getOrNull(cur.line) ?: 0f) / dn.density else 0f
        val next = Floats.switchTo(cur, how, key.startsWith("f"), topDp)
        if (next == cur) return
        record(when (how) { Placing.Inline -> "Put in line"; Placing.Wrap -> "Text wraps around it"; Placing.Free -> "Placed freely" })
        placed = if (next == null) placed - key else placed + (key to next)
        selFloat = if (next == null || locked) null else key
        menuFor = null
    }
    /** A placed object was moved or resized. The many small steps of one drag are one step in Undo. */
    fun changeFloat(key: String, p: Placed, what: String) {
        if (placed[key] == p) return
        record(what, key = "float:$key:$what", merge = true)
        placed = placed + (key to p)
    }
    fun removeFloat(key: String) {
        val ps = PageLayout.fit(pageParts, imgs.size, files.size)
        if (key.startsWith("p")) {
            val u = key.drop(1); val n = imgs.indexOf(u); if (n < 0) return
            record("Photo removed"); pageParts = PageLayout.without(ps, Part.Photo, n); imgs = imgs - u
        } else {
            val n = files.indexOfFirst { it.path == key.drop(1) }; if (n < 0) return
            record("File removed"); pageParts = PageLayout.without(ps, Part.File, n); files = files.filterIndexed { i, _ -> i != n }
        }
        placed = placed - key; selFloat = null
    }
    fun openFloat(key: String) {
        if (key.startsWith("p")) { val n = imgs.indexOf(key.drop(1)); if (n >= 0) viewerAt = n }
        else files.firstOrNull { it.path == key.drop(1) }?.let { openAttachment(fileCtx, it) }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u ->
            vm.importFile(u, failed = { msg -> Toast.makeText(fileCtx, msg, Toast.LENGTH_LONG).show() }) { a -> record("File attached", merge = true); files = files + a }
        }
    }
    fun attachFile() = pickFiles.launch(arrayOf("*/*"))
    // The camera writes to a temporary file in the app's cache (shared/ in file_paths.xml), then the photo is copied in like a picked one.
    var cameraPath by rememberSaveable { mutableStateOf<String?>(null) }
    val shoot = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = cameraPath?.let { java.io.File(it) }; cameraPath = null
        if (ok && f != null && f.length() > 0) vm.importImage(android.net.Uri.fromFile(f)) { p -> f.delete(); record("Photo added", merge = true); imgs = imgs + p }
        else f?.delete()
    }
    fun takePhoto() {
        val f = java.io.File(java.io.File(fileCtx.cacheDir, "shared").apply { mkdirs() }, "camera_${System.currentTimeMillis()}.jpg")
        cameraPath = f.absolutePath
        try { shoot.launch(androidx.core.content.FileProvider.getUriForFile(fileCtx, "${fileCtx.packageName}.files", f)) }
        catch (e: Exception) { cameraPath = null; Toast.makeText(fileCtx, "No camera app found", Toast.LENGTH_SHORT).show() }
    }
    // The Home page's image button opens a new scrap and goes straight to the photo picker.
    LaunchedEffect(id) { if (existing == null && vm.takePendingImage()) addImage() }
    // The writing bar's microphone button opens a new scrap with the Record audio sheet already up.
    LaunchedEffect(id) { if (existing == null && vm.takePendingRecord()) recording = true }
    // The writing bar's + menu: Files opens the file picker and Camera the camera.
    LaunchedEffect(id) { if (existing == null && vm.takePendingFile()) attachFile() }
    LaunchedEffect(id) { if (existing == null && vm.takePendingCamera()) takePhoto() }
    /** Opens the link sheet for the current selection. The selection is remembered because the sheet takes focus from the text. */
    fun openLink() { linkUrl = body.link()?.second?.groupValues?.get(2) ?: ""; linkSheet = body.selection }

    var pasteHint by remember { mutableStateOf<PasteHint?>(null) }
    LaunchedEffect(pasteHint) { val h = pasteHint; if (h != null && !h.busy) { delay(9000); pasteHint = null } }
    /**
     * Every body change goes through here so undo and redo see it. Typing in a row is grouped into steps (History.kt); pressing Enter starts a new step,
     * and anything that is not typing (bold, a heading, a ticked checkbox...) is a step of its own.
     */
    fun edit(new: TextFieldValue, typing: Boolean = false) {
        val before = body
        val now = System.currentTimeMillis()
        var asIs = false   // the keyboard's own deletion is taken exactly as it came
        if (typing) {
            val oneBack = before.selection.collapsed && new.selection.collapsed && new.text.length == before.text.length - 1 && new.selection.start == before.selection.start - 1 &&
                new.text == before.text.removeRange(before.selection.start - 1, before.selection.start)
            val remEnd = remStart + remText.length
            when {
                remOk(before.text) && oneBack && before.selection.start == remEnd -> {
                    if (now - lastBackAt < HOLD_BACK_MS) {
                        // A held backspace carries on through what is left of the mark.
                        asIs = true; remText = remText.dropLast(1); if (remText.isEmpty()) remStart = -1
                    } else {
                        // A new press: the mark goes, and with it the line break in front, as the second press used to.
                        val a = remStart; val cut = if (a > 0) a - 1 else a
                        val t = before.text.removeRange(cut, remEnd)
                        remStart = -1; remText = ""; lastBackAt = now
                        record("Typing", key = "text", merge = false)
                        body = TextFieldValue(t, TextRange(cut)); return
                    }
                }
                oneBack && emptyMarkLine(before) != null -> { val ls = emptyMarkLine(before)!!; asIs = true; remStart = ls; remText = before.text.substring(ls, before.selection.start - 1) }
                remOk(before.text) && new.text != before.text -> {
                    // Some other edit: the remnant stays where it is, moved along when the edit is in front of it, and dropped when the edit touches it.
                    var p = 0; val m = minOf(before.text.length, new.text.length); while (p < m && before.text[p] == new.text[p]) p++
                    if (p <= remStart) remStart += new.text.length - before.text.length else if (p < remEnd) { remStart = -1; remText = "" }
                }
            }
            if (oneBack) lastBackAt = now
        }
        // Enter inside an empty span (a size or color that was just picked) steps the span out of the way first, so the break never lands inside its braces.
        val lifted = if (typing && !asIs) liftEmptySpan(before, new) else null
        val base = lifted?.first ?: body; val incoming = lifted?.second ?: new
        val continued = if (asIs) new else continueList(base, smartEdit(base, incoming, viewNow))
        val next0 = if (typing) breakMarksAtEnter(base, continued) else continued
        // A size, color or underline goes on on the new line: Enter does not make the next line plain.
        val next = if (typing) carryLook(before, next0) else next0
        if (next.text != body.text) {
            val newLine = next.text.count { it == '\n' } != body.text.count { it == '\n' }
            if (typing) record("Typing", key = "text", merge = !newLine) else record("Formatting", key = "format")
        }
        body = next
        // Typing [[ opens the scrap picker, and the chosen link takes the place of the two brackets.
        if (typing && !locked) Connections.typedBrackets(before.text, next.text, next.selection.end)?.let { pickerAt = it; pickerOpen = true }
        // A paste is recognized and OFFERED a tidier form (a link, a quote, a list...); the text itself is never changed here. Any other edit clears the offer.
        if (next.text != before.text) {
            pasteHint = if (typing && pasteOffers) insertedRange(before.text, before.selection.start, before.selection.end, next.text, next.selection.start)
                ?.let { r -> offerFor(next.text, r, before.selection.start != before.selection.end)?.let { PasteHint(it, r) } } else null
        }
    }

    /**
     * Turns a pasted web address into a link card: the page's title, a short description of it as a quote, its photo among the scrap's photos, and the link
     * below. The page is only read now, because the person asked. One undo step takes all of it back. When the page gives nothing (many sites, X among
     * them, hide their content from apps), the address stays as it is.
     */
    fun applyCard(h: PasteHint) {
        val text = body.text
        if (h.range.last >= text.length) { pasteHint = null; return }
        val url = text.substring(h.range.first, h.range.last + 1).trim()
        pasteHint = h.copy(busy = true)
        vm.fetchLinkPreview(url) { preview, photo ->
            pasteHint = null
            val cur = body.text
            val here = h.range.last < cur.length && cur.substring(h.range.first, h.range.last + 1).trim() == url
            val at = if (here) h.range.first else cur.indexOf(url)
            if (preview == null || !preview.hasContent) { Toast.makeText(fileCtx, "No preview available for this link", Toast.LENGTH_SHORT).show(); return@fetchLinkPreview }
            if (at < 0) return@fetchLinkPreview   // the address was deleted meanwhile
            val range = if (here) h.range else at until at + url.length
            // On a scrap with nothing else in it, the page title becomes the scrap's title instead of a bold line.
            val asTitle = title.isBlank() && cur.removeRange(range).isBlank() && preview.title != null
            val r = applyLinkCard(cur, range, linkCardText(url, preview, includeTitle = !asTitle))
            record("Link card", key = "card")
            body = TextFieldValue(r.text, TextRange(r.range.last + 1))
            if (asTitle) title = preview.title!!.replace("\n", " ")
            if (photo != null && photo !in imgs) imgs = imgs + photo
        }
    }

    /** Applies the offered form to the pasted piece only, as one undoable step. A link first gets the site's name, then its page title when that arrives. */
    fun applyPaste(h: PasteHint) {
        pasteHint = null
        val text = body.text
        if (h.range.last >= text.length) return
        val result = applyPasteOffer(text, h.range, h.offer)
        record("Formatting", key = "format"); body = TextFieldValue(result.text, TextRange(result.range.last + 1))
        if (h.offer == PasteOffer.Link) {
            val url = text.substring(h.range.first, h.range.last + 1).trim(); val md0 = linkMarkdown(url, hostLabel(url))
            vm.fetchTitle(url) { title ->
                val cur = body; val i = cur.text.indexOf(md0)
                if (i >= 0) {
                    val md1 = linkMarkdown(url, title); val delta = md1.length - md0.length
                    fun adj(p: Int) = if (p >= i + md0.length) p + delta else p
                    record("Formatting", key = "format")
                    body = cur.copy(text = cur.text.replaceRange(i, i + md0.length, md1), selection = TextRange(adj(cur.selection.start), adj(cur.selection.end)))
                }
            }
        }
    }

    var panel by remember { mutableIntStateOf(0) }   // 0 none, 1 text options, 2 font color, 3 font size
    var colorTab by remember { mutableIntStateOf(0) }   // the color panel's tab: 0 text color, 1 highlighter
    var pendingTab by remember { mutableStateOf<Int?>(null) }   // the Growing card asks the color panel to open on a given tab
    var lastColor by remember { mutableStateOf<String?>(null) }
    val recentColors by vm.recentColors.collectAsState()   // the font colors used last, newest first (kept across scraps)
    /** The text a formatting button acts on: the selection, or the word at the cursor when nothing is selected. */
    fun target(): Pair<Int, Int>? {
        val s = body.text; var a = minOf(body.selection.start, body.selection.end).coerceIn(0, s.length); var b = maxOf(body.selection.start, body.selection.end).coerceIn(0, s.length)
        if (a == b) {
            var x = a; var y = a
            while (x > 0 && s[x - 1].isLetterOrDigit()) x--
            while (y < s.length && s[y].isLetterOrDigit()) y++
            if (x == y) return null
            a = x; b = y
        }
        return a to b
    }
    /**
     * Size, color and underline. With text selected they change that text and the selection stays. With only a cursor they set how the NEXT letters look
     * (an empty, hidden span waits at the cursor, see TypingStyle.kt), so a size you pick is the size of everything you write after it.
     */
    fun applySpan(f: (SpanAttrs) -> SpanAttrs) {
        if (!body.selection.collapsed) { val (a, b) = target() ?: return; edit(body.formatSpan(a, b, f)); return }
        val e = typingStyleAt(body.text, body.selection.start, f) ?: return
        edit(body.copy(text = e.text, selection = TextRange(e.start, e.end), composition = null))
    }
    fun inlineOnTarget(marker: String) {
        // Marks are hidden, so the way out of bold, italic or strike while typing is the same button: it steps past the closing mark.
        if (body.selection.collapsed && body.text.startsWith(marker, body.selection.start) && body.enclosing(marker) != null) {
            body = body.copy(selection = TextRange(body.selection.start + marker.length)); return
        }
        val tg = target(); edit((if (tg != null) body.copy(selection = TextRange(tg.first, tg.second)) else body).toggleInline(marker))
    }
    fun toggleUnderline() {
        val runs = if (!body.selection.collapsed) target()?.let { (a, b) -> body.attrsIn(a, b) }.orEmpty() else listOf(attrsAtCursor(body.text, body.selection.start))
        val all = runs.isNotEmpty() && runs.all { it.underline }
        applySpan { it.copy(underline = !all) }
    }
    /** Ticks or unticks the checklist line that starts at saved offset ls. */
    fun toggleCheck(ls: Int) {
        val s = body.text; if (ls + 4 > s.length) return
        val on = s[ls + 3] != 'x'
        haptics.toggle(on)
        edit(body.copy(text = s.replaceRange(ls + 3, ls + 4, if (on) "x" else " ")))
    }
    /** How long the start of a line that is not text is (a bullet, a number, a heading mark): a selection of the line or of a sentence leaves it out. */
    fun leadLen(line: String): Int = (LINE_PREFIXES.firstOrNull { line.startsWith(it) } ?: NUM.find(line)?.value)?.length ?: 0
    /** The word at the shown place [t], as a range of the saved text (so hidden marks stay outside it): the writer's word of SmartSelect (hashtags, web addresses, don't, 3.14), or the phone's own word if that finds none. */
    fun wordAt(lay: TextLayoutResult, t: Int): TextRange {
        val s = body.text
        val w = SmartSelect.word(lay.layoutInput.text.text, t)
        val a = w?.start ?: lay.getWordBoundary(t).start; val b = w?.end ?: lay.getWordBoundary(t).end
        val x = viewNow.start(a).coerceIn(0, s.length); val y = viewNow.end(b).coerceIn(0, s.length)
        return TextRange(minOf(x, y), maxOf(x, y))
    }
    val lastTick = remember { LongArray(1) }
    /** While a double tap or a long press is dragged: selects whole words from the [anchor] word (a range of the shown text) to the word under [pos], with a light tick each time the selection changes. */
    fun extendWords(anchor: SmartSelect.Span, pos: Offset) {
        val lay = textLayout ?: return; val s = body.text
        val shown = lay.layoutInput.text.text
        val e = SmartSelect.extend(shown, anchor, lay.getOffsetForPosition(pos).coerceIn(0, shown.length))
        val x = viewNow.start(e.start).coerceIn(0, s.length); val y = viewNow.end(e.end).coerceIn(0, s.length)
        val r = TextRange(minOf(x, y), maxOf(x, y))
        // While the page scrolls fast under the finger many words pass in one moment: a tick for each would be a buzz, so there is one at most every 45 ms.
        if (r != body.selection) { body = body.copy(selection = r); val now = System.currentTimeMillis(); if (now - lastTick[0] >= 45L) { lastTick[0] = now; haptics.tick() } }
    }
    /**
     * Double tap selects the word, triple tap the line, four taps everything. Another double tap on what is selected (the word, its sentence or its line, as an earlier double tap selected it;
     * [before] is the selection from before the taps) grows it along the ladder word, sentence, line, everything.
     */
    fun selectByTaps(pos: Offset, taps: Int, before: TextRange? = null) {
        val lay = textLayout ?: return; val s = body.text; if (s.isEmpty()) return
        val t = lay.getOffsetForPosition(pos).coerceIn(0, lay.layoutInput.text.length)
        val range = when {
            taps >= 4 -> TextRange(0, s.length)
            taps == 3 -> {
                val o = viewNow.end(t).coerceIn(0, s.length)
                val ls = s.lastIndexOf('\n', o - 1) + 1; val le = s.indexOf('\n', o).let { if (it < 0) s.length else it }
                val line = s.substring(ls, le)
                TextRange(minOf(ls + leadLen(line), le), le)
            }
            else -> {
                val word = wordAt(lay, t)
                val o = viewNow.end(t).coerceIn(0, s.length)
                val cur = before
                val level = cur != null && !cur.collapsed && o >= cur.min && o <= cur.max && (cur == word ||
                    SmartSelect.sentence(s, o) { l -> leadLen(l) }.let { it.start == cur.min && it.end == cur.max } ||
                    SmartSelect.lineText(s, o) { l -> leadLen(l) }.let { it.start == cur.min && it.end == cur.max })
                if (level && cur != null) SmartSelect.grow(s, SmartSelect.Span(cur.min, cur.max)) { l -> leadLen(l) }.let { TextRange(it.start, it.end) } else word
            }
        }
        if (!range.collapsed) body = body.copy(selection = range)
    }

    // ---- Connected scraps (Connections.kt): links in both directions, titles that could be linked, scraps that share tags ----
    val suggestLinks by vm.linkSuggestions.collectAsState()
    val connectionsOpen by vm.connectionsOpen.collectAsState()
    val connections = rememberConnections(body.text, parseTags(tags), live?.uid ?: "", list, suggestLinks)
    fun draft(): Item? {
        val savedBody = withoutRemnant(body).text   // a remnant of a deleted mark is never saved
        if (title.isBlank() && savedBody.isBlank() && imgs.isEmpty() && files.isEmpty() && cards.isEmpty()) return null
        val firstLine = savedBody.lineSequence().firstOrNull { it.isNotBlank() && !it.startsWith("```") }?.let { plainPreview(it) }?.takeIf { it.isNotBlank() }?.take(50)
        val base = vm.items.value.firstOrNull { it.id == curId } ?: existing ?: Item(title = "", body = "", kind = kind, collection = shelf)
        return base.copy(id = curId, title = title.ifBlank { firstLine ?: "Untitled" }, body = savedBody, kind = kind, collection = shelf,
            color = color, imageUri = imgs.firstOrNull(), images = imgs.drop(1).joinToString("\n"), files = files.encodeAll(), source = source, canvas = PageCards.save(cards, base.canvas), blocks = Floats.save(pageParts, placed, imgs, files.map { it.path }),
            tags = cleanTags(parseTags(tags)), hlColor = mk.color, hlOpacity = mk.opacity, savedAt = System.currentTimeMillis())
    }
    /** One save at a time, and a started save always finishes, so a new note can never be created twice. */
    suspend fun flush() = withContext(NonCancellable) {
        lock.withLock {
            val d = draft() ?: return@withLock
            val cur = vm.items.value.firstOrNull { it.id == curId }
            if (cur != null && d.copy(savedAt = cur.savedAt) == cur) return@withLock
            val r = vm.saveNow(d); if (curId == 0L) { curId = r; onCreated(r) }
            savedPulse++
        }
    }
    /**
     * Adds the #words typed since last time as tags. While you type, the word at the cursor waits (it may not be finished); [closing] counts it too.
     * The text is never changed, and taking a tag off later sticks, because the #word is already in hashBase.
     */
    fun absorbHashtags(closing: Boolean) {
        if (!hashtagsOn) return
        val fresh = newHashtags(body.text, if (closing) null else body.selection.end, hashBase)
        if (fresh.isEmpty()) return
        hashBase = hashBase + fresh.map { it.lowercase() }
        tags = cleanTags(parseTags(tags) + fresh, knownTags.map { it.first }).joinToString(", ")
    }
    // Shorter than the save delay below, so a new tag goes out with the same save as the words around it.
    LaunchedEffect(body.text, body.selection, hashtagsOn) { delay(300); absorbHashtags(false) }
    // What is left of a deleted mark goes after a moment of quiet (longer than the pause before a held key starts repeating, so a hold is not cut short).
    LaunchedEffect(remStart, remText, body.text) {
        if (!remOk(body.text)) return@LaunchedEffect
        delay(700)
        if (remOk(body.text)) { body = withoutRemnant(body); remStart = -1; remText = "" }
    }
    LaunchedEffect(title, body.text, color, kind, shelf, tags, imgs, source, files, pageParts, placed, cards) { delay(400); flush() }
    // [songbook hook 5] Songbook changed this scrap while it is open (the link line, or the song's text): take the new text, or the next save would put the old one back.
    val songbookTick by vm.songbookTouched.collectAsState()
    LaunchedEffect(songbookTick) {
        if (songbookTick.first == 0L || songbookTick.first != curId) return@LaunchedEffect
        val fresh = vm.bodyOf(curId) ?: return@LaunchedEffect
        if (fresh != body.text) body = body.copy(text = fresh, selection = TextRange(body.selection.end.coerceIn(0, fresh.length)))
    }
    // Leaving the app (Home, recents, another app on top) saves at once instead of waiting for the short delay above, so the last words typed
    // are on disk before Android can close the app. Saving when nothing changed does nothing.
    val owner = LocalLifecycleOwner.current
    // Remember my view: the cursor, how far the page is scrolled, and whether the keyboard was up in the text. That flag is only updated while the
    // screen is in front: when you leave the app Android closes the keyboard a moment later, and that must not count as you having put it away.
    val bodyFocus = remember { FocusRequester() }; val keyboard = LocalSoftwareKeyboardController.current
    val imeInsets = WindowInsets.ime; val dens = LocalDensity.current
    var keyboardOpen by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        snapshotFlow { imeInsets.getBottom(dens) > 0 && focused }.collect { now -> if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) keyboardOpen = now }
    }
    // Typing fast with the keyboard up tucks the Growing card pill into the keyboard's edge and a short pause brings it back. Only one-letter changes count as typing,
    // so a tool that rewrites a line (a heading, a list mark) or a paste does not shrink the pill under your finger.
    var typing by remember { mutableStateOf(false) }
    LaunchedEffect(id) {
        var last = body.text
        snapshotFlow { body.text }.collectLatest { t ->
            val key = t != last && kotlin.math.abs(t.length - last.length) <= 1; last = t
            typing = key
            if (key) { delay(900); typing = false }
        }
    }
    // Dragging the page down with a finger slides the Growing card pill away; dragging up, or reaching the top, brings it back. The keyboard, a selection and an open panel keep it
    // (typing scrolls the page too, which is why only a finger on the text counts).
    var scrolledAway by remember { mutableStateOf(false) }
    LaunchedEffect(id) {
        var anchor = scroll.value
        snapshotFlow { scroll.value }.collect { v ->
            if (v < 8) { scrolledAway = false; anchor = v }
            else if (!touching) { anchor = v }
            else if (v - anchor > 24) { scrolledAway = true; anchor = v }
            else if (anchor - v > 12) { scrolledAway = false; anchor = v }
        }
    }
    val pillHidden = scrolledAway && !keyboardOpen && body.selection.collapsed && panel == 0
    // The Expanding chip: tapping it opens it; selecting words opens it by itself and the end of the selection closes it again; typing closes it (see chipNext).
    // The Growing card stands up as a bar on the right while the keyboard is open, if the screen is tall enough to hold it above the keyboard; otherwise it stays the compact pill.
    val railMode = editorStyle == 2 && keyboardOpen && androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp >= 700
    var chipOpen by remember { mutableStateOf(false) }; var chipAuto by remember { mutableStateOf(false) }
    LaunchedEffect(body.selection.collapsed, typing, panel) {
        val (o, a) = chipNext(chipOpen, chipAuto, !body.selection.collapsed, typing && keyboardOpen, panel != 0)
        chipOpen = o; chipAuto = a
    }
    // Coming back to a scrap you were typing in: put the cursor back in the text, with the keyboard, once the screen has finished opening.
    LaunchedEffect(id) { if (autoKeyboard && spot?.keyboard == true && editing && !locked) { delay(400); try { bodyFocus.requestFocus() } catch (_: Exception) { /* the field was not ready: stay without the keyboard */ } } }
    fun rememberSpot() {
        if (curId == 0L) return
        memory.put(curId, EditorSpot(body.selection.end.coerceIn(0, body.text.length), scroll.value, keyboardOpen))
        if (memory.isLocked(curId) != locked) memory.setLocked(curId, locked)
    }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_PAUSE) { rememberSpot(); scope.launch { flush() } } }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    fun leave() { if (leaving) return; leaving = true; absorbHashtags(true); rememberSpot(); scope.launch { flush(); nav.popBackStack() } }
    // ---- Reading, writing and view only ----
    val focusManager = LocalFocusManager.current
    var focusTick by remember { mutableIntStateOf(0) }
    /** Goes from reading to writing: puts the cursor where [at] says (a spot in the saved text), raises the toolbar and, with [focus], the keyboard. Does nothing while view only. */
    fun startEditing(at: Int? = null, focus: Boolean = true) {
        if (locked) return
        if (at != null) body = body.copy(selection = TextRange(at.coerceIn(0, body.text.length)))
        editing = true
        if (focus) focusTick++
    }
    LaunchedEffect(focusTick) {
        if (focusTick == 0) return@LaunchedEffect
        withFrameNanos { }   // the field becomes editable in this frame; it can take focus in the next
        try { bodyFocus.requestFocus(); keyboard?.show() } catch (_: Exception) { /* the field was not ready: the toolbar is up, a tap in the text brings the keyboard */ }
    }
    /** The book button: locks the page so it can only be read, or opens it up again. Kept for this scrap. */
    fun setLocked(on: Boolean) {
        if (on == locked) return
        haptics.toggle(on)
        if (on) { editing = false; panel = 0; focusManager.clearFocus(); keyboard?.hide() }
        locked = on
        if (curId != 0L) memory.setLocked(curId, on)
    }
    // Coming from the reading page's Edit button (or a fresh duplicate) means "I want to write", so the editor opens straight into writing.
    // (With "Open the keyboard automatically" off it still opens into writing, with the toolbar, but waits for a tap in the text before raising the keyboard.)
    LaunchedEffect(id) { if (vm.takePendingEdit()) startEditing(focus = autoKeyboard) }
    // A tap on the page while reading: on a link it opens the link, anywhere else it starts writing right at that spot.
    fun readingTap(pos: Offset) {
        val lay = textLayout; var at: Int? = null
        if (lay != null && body.text.isNotEmpty()) {
            val shown = lay.getOffsetForPosition(pos).coerceIn(0, lay.layoutInput.text.length)
            val o = viewNow.end(shown).coerceIn(0, body.text.length)
            val m = LINK.findAll(body.text).firstOrNull { o >= it.range.first && o <= it.range.last }
            if (m != null) {
                val url = m.groupValues[2]
                val scrapUid = parseScrapLink(url)
                if (scrapUid != null) vm.linkRequest.value = scrapUid else openPageLink(fileCtx, url)
                return
            }
            at = o
        }
        startEditing(at)
    }
    /** Puts a link to [s] in the text (over the typed [[ if that is how the picker was opened) and moves the cursor after it. */
    fun insertScrapLink(s: ScrapInfo) {
        val fromBrackets = pickerAt != null
        val e = Connections.insertLink(body.text, body.selection.start, body.selection.end, s.title, s.uid, pickerAt)
        record("Link added"); haptics.confirm()
        body = body.copy(text = e.text, selection = TextRange(e.cursor), composition = null)
        pickerOpen = false; pickerAt = null
        startEditing(e.cursor, focus = fromBrackets)
    }
    /** Turns a title written in the text into a link, leaving the cursor where it was (moved along if the text before it grew). */
    fun linkMentioned(m: Mention) {
        val e = Connections.linkMention(body.text, m.range, m.scrap.uid, m.scrap.title) ?: return
        val grew = e.text.length - body.text.length
        fun shift(i: Int) = (if (i > m.range.last) i + grew else i).coerceIn(0, e.text.length)
        record("Link added"); haptics.tick()
        body = body.copy(text = e.text, selection = TextRange(shift(body.selection.start), shift(body.selection.end)), composition = null)
    }

    // ---- Extra tools (the rules are in EditorTools.kt): share, copy, move a line, tidy a checklist, today's date, replace ----
    var toolsOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Attachment?>(null) }   // the attached file whose new name is being asked for
    var replaceWith by remember { mutableStateOf("") }
    /** Puts a finished text change in place as one undo step (merge: repeated taps, like moving a line several times, undo together). */
    fun applyTool(e: TextEdit?, what: String, merge: Boolean = false) {
        if (e == null) return
        record(what, merge = merge)
        body = body.copy(text = e.text, selection = TextRange(e.start, e.end), composition = null)
    }
    fun moveLine(up: Boolean) = applyTool(moveLines(body.text, body.selection.start, body.selection.end, up), if (up) "Line moved up" else "Line moved down", merge = true)
    fun tidyChecklist(a: CheckAction, what: String) = applyTool(applyChecklist(body.text, body.selection.start, a), what)
    fun insertDate() = applyTool(insertAt(body.text, body.selection.start, body.selection.end, todayText()), "Date inserted")
    // Quick tools (hold the + button). A tool that cannot do anything says why instead of staying quiet.
    fun said(msg: String) = Toast.makeText(fileCtx, msg, Toast.LENGTH_SHORT).show()
    fun tool(e: TextEdit?, what: String, otherwise: String, merge: Boolean = false) { if (e == null) said(otherwise) else applyTool(e, what, merge) }
    val quickGroups = listOf(
        QuickGroup("Lists and blocks", listOf(
            QuickTool("Bullets", "list") { edit(body.toggleLine("- ")) },
            QuickTool("Numbers", "numbered") { edit(body.toggleLine("1. ")) },
            QuickTool("Checklist", "taskcheck") { edit(body.toggleLine("- [ ] ")) },
            QuickTool("Heading", glyph = "H") { edit(body.cycleHeading()) },
            QuickTool("Quote", "quote") { edit(body.toggleLine("> ")) },
            QuickTool("Divider", "divider") { edit(body.insertDivider()) },
            QuickTool("Code block", "code") { edit(body.toggleCodeBlockHere()) },
            QuickTool("Tick all", "check") { tool(applyChecklist(body.text, body.selection.start, CheckAction.TickAll), "Ticked all", "There is nothing to tick.") },
        )),
        QuickGroup("Insert", listOf(
            QuickTool("Date", "clock") { insertDate() },
            QuickTool("Time", glyph = "12:00") { applyTool(insertAt(body.text, body.selection.start, body.selection.end, timeText()), "Time inserted") },
            QuickTool("Date and time", glyph = "Date+") { applyTool(insertAt(body.text, body.selection.start, body.selection.end, dateTimeText()), "Date and time inserted") },
        )),
        QuickGroup("Lines", listOf(
            QuickTool("Move up", "up", stays = true) { moveLine(true) },
            QuickTool("Move down", "down", stays = true) { moveLine(false) },
            QuickTool("Duplicate", "copy") { applyTool(duplicateLines(body.text, body.selection.start, body.selection.end), "Line duplicated") },
            QuickTool("Delete line", "trash", danger = true) { tool(deleteLines(body.text, body.selection.start, body.selection.end), "Line deleted", "There is nothing to delete.") },
            QuickTool("Sort A–Z", glyph = "A→Z") { tool(sortLines(body.text, body.selection.start, body.selection.end, true), "Sorted A to Z", "Select two or more lines to sort, or they are in order already.") },
            QuickTool("Sort Z–A", glyph = "Z→A") { tool(sortLines(body.text, body.selection.start, body.selection.end, false), "Sorted Z to A", "Select two or more lines to sort, or they are in order already.") },
            QuickTool("Join lines", glyph = "a b") { tool(joinLines(body.text, body.selection.start, body.selection.end), "Lines joined", "Select two or more lines to join.") },
            QuickTool("No repeats", glyph = "A=A") { tool(removeDuplicateLines(body.text, body.selection.start, body.selection.end), "Repeated lines removed", "No line is written twice here.") },
            QuickTool("Trim spaces", glyph = "|a|") { tool(trimSpaces(body.text, body.selection.start, body.selection.end), "Spaces trimmed", "There are no extra spaces here.") },
            QuickTool("No blank lines", glyph = "¶") { tool(removeBlankLines(body.text, body.selection.start, body.selection.end), "Blank lines removed", "There are no blank lines here.") },
        )),
        QuickGroup("Selected words", listOf(
            QuickTool("CAPITALS", glyph = "AA") { tool(changeCase(body.text, body.selection.start, body.selection.end, CaseChange.Upper), "Capitals", "Select some words first.") },
            QuickTool("small", glyph = "aa") { tool(changeCase(body.text, body.selection.start, body.selection.end, CaseChange.Lower), "Small letters", "Select some words first.") },
            QuickTool("Each Word", glyph = "Aa") { tool(changeCase(body.text, body.selection.start, body.selection.end, CaseChange.Title), "Capital on each word", "Select some words first.") },
            QuickTool("Sentence case", glyph = "A.a") { tool(changeCase(body.text, body.selection.start, body.selection.end, CaseChange.Sentence), "Sentence case", "Select some words first.") },
            QuickTool("Clear format", glyph = "T×") { tool(clearFormatting(body.text, body.selection.start, body.selection.end), "Formatting cleared", "There is no formatting here.") },
            QuickTool("Count", glyph = "123") {
                val a = minOf(body.selection.start, body.selection.end).coerceIn(0, body.text.length); val b = maxOf(body.selection.start, body.selection.end).coerceIn(0, body.text.length)
                said(textStats(if (a == b) body.text else body.text.substring(a, b)).say() + if (a == b) "" else " selected")
            },
        )),
    )
    fun shareNow() {
        val t = plainText(title, body.text)
        if (t.isBlank()) { Toast.makeText(fileCtx, "There is nothing to share yet.", Toast.LENGTH_SHORT).show(); return }
        fileCtx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, title.trim()); putExtra(Intent.EXTRA_TEXT, t)
        }, "Share scrap"))
    }
    fun copyNow() {
        val t = plainText(title, body.text)
        if (t.isBlank()) { Toast.makeText(fileCtx, "There is nothing to copy yet.", Toast.LENGTH_SHORT).show(); return }
        clipboard.setText(AnnotatedString(t)); Toast.makeText(fileCtx, "Copied", Toast.LENGTH_SHORT).show()
    }
    fun duplicateNow() { val d = draft() ?: return; scope.launch { flush(); vm.duplicate(d) { vm.pendingEdit = true; nav.navigate("edit/$it") } } }
    /** Replaces the match you are on, or every match. Only text you can see is touched: never a link's address or a color code hidden behind the page. */
    fun replaceNow(all: Boolean) {
        val q = findQ.trim(); if (q.isEmpty()) return
        val map = view.out.offsetMapping
        val seen = visibleOccurrences(body.text, q, { map.originalToTransformed(it) }, view.out.text.text)
        val cur = matches.getOrNull(findCur)
        val chosen = if (all) seen else seen.filter { cur != null && map.originalToTransformed(it.first) == cur.first }.take(1)
        if (chosen.isEmpty()) {
            Toast.makeText(fileCtx, if (all) "Nothing to replace." else "This one has formatting inside it, so it cannot be replaced. Try the next.", Toast.LENGTH_SHORT).show(); return
        }
        val out = replaceRanges(body.text, chosen, replaceWith)
        record(if (all) "Replace all" else "Replace")
        val at = (chosen.first().first + replaceWith.length).coerceIn(0, out.length)
        body = body.copy(text = out, selection = TextRange(at), composition = null)
        if (all) Toast.makeText(fileCtx, if (chosen.size == 1) "Replaced 1" else "Replaced ${chosen.size}", Toast.LENGTH_SHORT).show()
    }
    var versionsOpen by remember { mutableStateOf(false) }
    var pageStyle by remember { mutableStateOf(false) }
    /** Brings an earlier text back. What is in the scrap now is kept as a version first, and Undo in the editor takes the change back as well. */
    fun restoreVersion(v: ItemVersion) {
        scope.launch {
            flush(); vm.keepVersion(curId)
            record("Version restored"); haptics.confirm()
            title = if (bodyWithoutTitle(v.title, v.body) != v.body) "" else v.title
            body = TextFieldValue(v.body, TextRange(v.body.length))
        }
    }
    BackHandler { leave() }
    BackHandler(finding) { finding = false; findQ = ""; findAt = 0 }
    // The menu goes back to its main list only after it has faded out, so it never flashes the wrong page while closing.
    LaunchedEffect(menu) { if (!menu) { delay(200); menuPage = MenuPage.Main } }
    BackHandler(menu) { if (menuPage != MenuPage.Main) menuPage = MenuPage.Main else menu = false }
    BackHandler(panel != 0) { panel = 0 }
    BackHandler(dragKey != null) { cancelDrag() }
    BackHandler(selFloat != null && dragKey == null) { selFloat = null }
    LaunchedEffect(focused) { if (focused) selFloat = null }   // writing in the text puts the selected photo or file away

    Box(Modifier.fillMaxSize()) {
    Scaffold(containerColor = t.editorPage) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).background(pageTint(color) ?: Color.Transparent).imePadding()) {
            val subtitle = (listOf(vm.shelves.value.displayName(shelf)) + tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }).joinToString(" · ")
            Chunk {
            if (finding) FindBar(findQ, { findQ = it; findAt = 0 }, matches.size, findCur, { findAt = nextMatch(findCur, matches.size, true) },
                { findAt = nextMatch(findCur, matches.size, false) }, { finding = false; findQ = ""; findAt = 0 },
                ReplaceUi(replaceWith, { replaceWith = it }, matches.isNotEmpty(), { replaceNow(false) }, { replaceNow(true) }))
            else Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                // Tap saves and goes back. Held, it turns into a search button (unless Settings keeps find in the 3-dot menu only).
                BackFindButton(findEntry != 1, { leave() }, { finding = true; menu = false; panel = 0 })
                Column(Modifier.weight(1f).pointerInput(editing, locked) { if (!editing && !locked) detectTapGestures { startEditing() } }, verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                    val icon = (live ?: existing)?.icon.orEmpty()
                    if (icon.isNotBlank() && live != null) Text(icon, fontSize = 22.sp, lineHeight = 26.sp, modifier = Modifier.padding(end = 8.dp).tap("Change icon") { scope.launch { flush(); keyboard?.hide(); pageStyle = true } })
                    // The same field in every mode, so nothing moves when you switch; it just stops taking taps while you are reading.
                    BasicTextField(title, { setTitle(it) }, Modifier.weight(1f), singleLine = true, enabled = editing,
                        textStyle = TextStyle(fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp, fontFamily = headFont(), fontWeight = FontWeight.Medium, color = Sb.ink),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        cursorBrush = SolidColor(t.acc),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (title.isEmpty()) Text("Title", color = Sb.mute.copy(alpha = .6f), fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp, fontFamily = headFont(), fontWeight = FontWeight.Medium)
                                inner()
                            }
                        })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // The box, then each tag. A tag is a button: it opens Search filtered to that tag, across all boxes.
                        Row(Modifier.weight(1f, fill = false).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                            Text(shelf, fontSize = 12.5.sp, lineHeight = 16.sp, color = Sb.mute, fontFamily = LocalFonts.current.second, maxLines = 1)
                            parseTags(tags).forEach { tg ->
                                Text(" · ", fontSize = 12.5.sp, lineHeight = 16.sp, color = Sb.mute, maxLines = 1)
                                Text("#$tg", Modifier.tap("Show scraps tagged $tg") { rememberSpot(); scope.launch { flush(); vm.pendingFilter = ScrapFilter(tags = setOf(tg)); nav.navigate("search") } }.padding(vertical = 4.dp),
                                    fontSize = 12.5.sp, lineHeight = 16.sp, color = accentText(t.acc), fontFamily = LocalFonts.current.second, maxLines = 1)
                            }
                        }
                        // Eases in with a small spring and fades away again, so it never sits there nagging.
                        AnimatedVisibility(savedMark && showSaved, enter = fadeIn(tween(160)) + scaleIn(spring(dampingRatio = .6f, stiffness = Spring.StiffnessMedium), initialScale = .6f), exit = fadeOut(tween(350))) {
                            Text("Saved", Modifier.padding(start = 8.dp), fontSize = 12.5.sp, lineHeight = 16.sp, color = accentText(t.acc), fontWeight = FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
                // One pill holds the actions: the book (view only on or off), add image (only while writing; it slides in and out) and more.
                Row(Modifier.height(44.dp).clip(CircleShape).background(Sb.surface).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    val lockFill by animateColorAsState(if (locked) t.acc.copy(alpha = .18f) else Color.Transparent, tween(200), label = "viewOnlyFill")
                    Box(Modifier.size(44.dp).clip(CircleShape).background(lockFill).tapIcon(if (locked) "View only is on. Tap to turn it off" else "View only", onClick = { setLocked(!locked) }), Alignment.Center) {
                        Ic("book", 22.dp, if (locked) t.acc else Sb.ink)
                    }
                    AnimatedVisibility(editing, enter = fadeIn(tween(200)) + expandHorizontally(tween(240)), exit = fadeOut(tween(120)) + shrinkHorizontally(tween(200))) {
                        HeaderBtn("Add image", { addImage() }) { Ic("plus", 22.dp, accentText(t.acc)) }
                    }
                    HeaderBtn("More options", { menu = true }) { Ic("more", 22.dp, Sb.ink) }
                }
            }
            }
            // Worked out before the page so the floating Growing card pill, which lies over the page, can use them.
            val tg = target()
            // A selection shows its own look. A cursor shows the look new text gets there: that of the text it is in, or of the look that was just picked and is waiting.
            val attrNow = if (!body.selection.collapsed) tg?.let { (a, b) -> body.attrsIn(a, b) }.orEmpty() else listOf(attrsAtCursor(body.text, body.selection.start))
            val sizesNow = attrNow.map { it.size }.distinct()
            val sizeNow = sizesNow.singleOrNull(); val mixedSize = sizesNow.size > 1; val colorNow = attrNow.firstOrNull()?.color
            val historyVersion = histVer   // read here so the bar refreshes after every undo and redo
            val history = HistoryUi(hist.undoLabel, hist.redoLabel, !snap().sameAs(origin), { doUndo() }, { doRedo() }, { revertAll() })
            val adds = AddActions(if (cardsOn) ::addCard else null, { attachFile() }, { recording = true }, { keyboard?.hide(); pickerAt = null; pickerOpen = true }, { keyboard?.hide(); toolsOpen = true },
            { scope.launch { flush(); vm.settingsSearch = "Editor"; nav.navigate("settings") } }, { openLink() }, { insertDate() })
            Box(Modifier.weight(1f)) {
            Box(Modifier.fillMaxSize().onSizeChanged { viewportH = it.height }.verticalScroll(scroll)) {
Column(Modifier.fillMaxWidth().heightIn(min = if (cardsOn) PageCards.bottomDp(cards).dp else 0.dp).padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = if (editorStyle >= 2 && editing) 100.dp else 14.dp)) {
                (live ?: existing)?.cover?.let { c -> ItemImage((live ?: existing)!!.copy(imageUri = c), Modifier.fillMaxWidth().height(130.dp), t.radius); Spacer(Modifier.height(14.dp)) }
                if (kind == Kind.Quote) { Field(source, { setSource(it) }, "Source: who said it, or where it is from", 14.sp, headFont()); Spacer(Modifier.height(10.dp)) }
                // The page is a list of places from the top down: the text, and every photo and every attached file on its own (see PageLayout). Holding a photo or a
                // file opens a small menu with Drag; after that it can be carried anywhere: above or below the text, or between other photos and files. View only turns this off.
                val slots = PageLayout.fit(pageParts, imgs.size, files.size)
                val canArrange = !locked
                PageLayout.runs(slots).forEach { run ->
                    key(if (run.part == Part.Text) "text" else run.part.name + (if (run.part == Part.Photo) imgs.getOrNull(run.first) else files.getOrNull(run.first)?.path)) {
                        when (run.part) {
                            Part.Photo -> Chunk { Row(Modifier.horizontalScroll(rememberScrollState())) {
                                for (n in run.first until minOf(run.first + run.count, imgs.size)) {
                                    val u = imgs[n]
                                    if (placed.containsKey(Floats.photoKey(u))) continue   // wrapped or free: drawn over the text instead
                                    key(u) {
                                        val onHold: (() -> Unit)? = if (canArrange) ({ haptics.tick(); menuFor = "p$n" }) else null
                                        val remove = { record("Photo removed"); pageParts = PageLayout.without(slots, Part.Photo, n); imgs = imgs - u }
                                        Box(Modifier.onGloballyPositioned { objCoords["p$n"] = it }.alpha(if (dragKey == "p$n") .3f else 1f)) {
                                            // Polaroids (the default) or normal pictures, as chosen in Settings.
                                            if (plainPhotos) PlainPhoto(u, plainPhotoWidth(screenDp, run.count).dp, editing, { viewerAt = n }, onHold) { remove() }
                                            else Polaroid(u, kind, n, editing, { viewerAt = n }, onHold) { remove() }
                                            if (canArrange) PopupMenu(menuFor == "p$n", { menuFor = null }) {
                                                PopupItem("Drag", "sort") { startDrag("p$n") }
                                                PopupItem("Wrap text", "alignl", "Text runs beside it") { setMode(Floats.photoKey(u), Placing.Wrap) }
                                                PopupItem("Place freely", "expand", "Anywhere, any size") { setMode(Floats.photoKey(u), Placing.Free) }
                                                if (editing) PopupItem("Remove", "trash", tint = Sb.danger) { menuFor = null; remove() }
                                            }
                                        }
                                    }
                                }
                            } }
                            Part.File -> CompositionLocalProvider(LocalAttachmentRename provides { a: Attachment -> renaming = a }) {
                                AttachmentList(files.subList(run.first, minOf(run.first + run.count, files.size)).filter { !placed.containsKey(Floats.fileKey(it.path)) }, Modifier.padding(top = 4.dp, bottom = 10.dp),
                                    if (editing) ({ a -> record("File removed"); pageParts = PageLayout.without(slots, Part.File, files.indexOfFirst { it.path == a.path }); files = files - a }) else null,
                                    if (canArrange) ({ a -> startDrag("f" + files.indexOfFirst { it.path == a.path }) }) else null,
                                    if (canArrange) ({ a, how -> setMode(Floats.fileKey(a.path), how) }) else null,
                                    { a -> val n = files.indexOfFirst { it.path == a.path }; Modifier.onGloballyPositioned { objCoords["f$n"] = it }.alpha(if (dragKey == "f$n") .3f else 1f) })
                            }
                            Part.Text -> Chunk {
                            val bubbleHits = remember { arrayOfNulls<Rect>(2) }   // where the selection bubble [0] and the link bubble [1] are, so a tap on them is told apart from a tap on the page
                            Box(Modifier.fillMaxWidth().heightIn(min = floatsMinDp.dp).onSizeChanged { textBoxW = it.width }.onGloballyPositioned { fieldTop = it.positionInParent().y; objCoords["T"] = it }) {
                            Box(Modifier.fillMaxWidth()
                            .drawBehind { val lay = textLayout; if (lay != null) drawEditorBackdrop(lay, viewNow, t.acc) }
                            .pointerInput(Unit) {
                                // Only watches (nothing is consumed): while a finger is down on the text the bubbles stay hidden.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    // A finger on a bubble's own buttons is not a finger on the page: the bubble must stay where it is for the tap to reach its button.
                                    val onBubble = bubbleHits.any { it != null && it.contains(down.position) }
                                    if (!onBubble) touching = true
                                    do { val e = awaitPointerEvent(PointerEventPass.Initial) } while (e.changes.any { it.pressed })
                                    touching = false; touchEnd = System.currentTimeMillis()
                                }
                            }
                            .pointerInput(id) {
                                // Tapping a ☐ / ☑ ticks it without moving the cursor or opening the keyboard. Reading and writing both do it; view only does not.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    if (locked) return@awaitEachGesture
                                    val lay = textLayout
                                    val hit = if (lay != null) checkboxAt(lay, viewNow, down.position, 10.dp.toPx()) else null
                                    if (hit != null) {
                                        down.consume()
                                        val up = waitForUpOrCancellation(PointerEventPass.Initial)
                                        if (up != null && (up.position - down.position).getDistance() < viewConfiguration.touchSlop) { up.consume(); toggleCheck(hit) }
                                    }
                                }
                            }
                            .pointerInput(id) {
                                // Counts quick taps in the same spot. The text field handles the first two; this makes sure 2, 3 and 4 taps always select (see selectByTaps). It also does two things the text field
                                // does not: if the finger of a double tap moves before it lifts, the selection goes with it by whole words (and the page scrolls when the finger is near its top or bottom),
                                // and a long press selects the writer's word the way a double tap does.
                                var taps = 0; var lastUp = 0L; var lastPos = Offset.Zero; var seqSel: TextRange? = null
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    if (!editing) return@awaitEachGesture
                                    val slop = viewConfiguration.touchSlop
                                    val continuing = taps >= 1 && down.uptimeMillis - lastUp < 350 && (down.position - lastPos).getDistance() < slop * 3f
                                    if (!continuing) seqSel = body.selection   // what was selected before this run of taps began
                                    val canDrag = continuing && taps == 1
                                    var dragging = false; var longDone = false
                                    var anchor = SmartSelect.Span(0, 0); var finger = down.position; var autoSpeed = 0f
                                    var autoJob: Job? = null
                                    var up: PointerInputChange? = null
                                    try {
                                        while (true) {
                                            val ev = if (continuing || longDone) awaitPointerEvent(PointerEventPass.Initial)
                                                else withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis + 60L) { awaitPointerEvent(PointerEventPass.Initial) }
                                            if (ev == null) { longDone = true; selectByTaps(down.position, 2, null); continue }   // held still: a long press
                                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                            if (ch.changedToUpIgnoreConsumed()) { up = ch.takeIf { !it.isConsumed }; break }
                                            if (!dragging && ch.isConsumed) break
                                            if (!dragging && (ch.position - down.position).getDistance() > slop) {
                                                if (!canDrag && !longDone) break   // a scroll, or a drag that is not ours (a finger that stayed down for a long press is dragging a selection)
                                                val lay = textLayout ?: break
                                                dragging = true
                                                val shown = lay.layoutInput.text.text; val t0 = lay.getOffsetForPosition(down.position).coerceIn(0, shown.length)
                                                anchor = SmartSelect.word(shown, t0) ?: SmartSelect.Span(t0, t0)
                                                autoJob = scope.launch {
                                                    // One step per frame for as long as the finger is in an edge zone. How far it goes depends on the time since the last frame, so the speed is the same on any
                                                    // screen and a slow frame cannot make it stall; the selection is taken along with every step, even while the finger lies still.
                                                    var last = withFrameNanos { it }
                                                    while (isActive) {
                                                        val now = withFrameNanos { it }; val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, .05f); last = now
                                                        if (autoSpeed != 0f) { val d = scroll.scrollBy(autoSpeed * dt); if (d != 0f) { finger = Offset(finger.x, finger.y + d); extendWords(anchor, finger) } }
                                                    }
                                                }
                                            }
                                            if (dragging) {
                                                ch.consume(); finger = ch.position
                                                extendWords(anchor, finger)
                                                // near the top or bottom of the screen the page scrolls on its own, faster the closer the finger is to the edge and fastest past it (EdgeScroll.kt)
                                                val yView = finger.y + fieldTop - scroll.value
                                                autoSpeed = if (viewportH > 0) EdgeScroll.speed(yView, viewportH.toFloat(), EdgeScroll.zone(viewportH.toFloat(), 72.dp.toPx())) else 0f
                                            }
                                        }
                                    } finally { autoJob?.cancel() }
                                    if (dragging) { taps = 0; return@awaitEachGesture }   // the selection was made while dragging
                                    val upC = up
                                    if (upC == null || (upC.position - down.position).getDistance() > slop || upC.uptimeMillis - down.uptimeMillis > 400) { taps = 0; return@awaitEachGesture }
                                    taps = if (continuing) taps + 1 else 1
                                    lastUp = upC.uptimeMillis; lastPos = upC.position
                                    if (taps >= 2) { val p = upC.position; val c = taps; val b = seqSel; scope.launch { delay(70); selectByTaps(p, c, b) } }
                                }
                            }
                            .pointerInput(id) {
                                // Reading: a quick tap opens a link, or starts writing at that spot. A checkbox was already dealt with above (it is consumed), a scroll is not a tap.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    if (editing || locked || down.isConsumed) return@awaitEachGesture
                                    val up = waitForUpOrCancellation(PointerEventPass.Initial) ?: return@awaitEachGesture
                                    if (up.isConsumed || (up.position - down.position).getDistance() > viewConfiguration.touchSlop || up.uptimeMillis - down.uptimeMillis > 400) return@awaitEachGesture
                                    up.consume(); readingTap(down.position)
                                }
                            }) {

                            CompositionLocalProvider(LocalTextSelectionColors provides TextSelectionColors(handleColor = t.acc, backgroundColor = t.acc.copy(alpha = .3f))) {
                                BasicTextField(body, { edit(it, typing = true) }, Modifier.fillMaxWidth().heightIn(min = 320.dp).focusRequester(bodyFocus).onFocusChanged { focused = it.isFocused }, enabled = editing && !locked,
                                    textStyle = TextStyle(fontSize = 17.sp, fontFamily = pageFont((live ?: existing)?.font ?: 0) ?: headFont(), color = Sb.ink, lineHeight = pageLine((live ?: existing)?.density ?: 1)),
                                    cursorBrush = SolidColor(t.acc), visualTransformation = md, onTextLayout = { textLayout = it },
                                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                                    decorationBox = { inner -> Box { if (body.text.isEmpty()) Text("Write something…", color = Sb.mute, fontSize = 17.sp, fontFamily = headFont()); inner() } })
                            }
                            val lay = textLayout
                            // The bubbles (selection, link) stay out of the way: nothing while a finger is on the page, the page is moving or the selection or text
                            // just changed (so they never jump about while a word is being picked); they fade in, in place, once it is all still.
                            val still = !touching && !scroll.isScrollInProgress
                            // A link under the cursor gets a small Open / Edit bubble, so a link can be opened without leaving the editor.
                            val spot = remember(body.text, body.selection, focused, linkSheet, finding) {
                                if (focused && body.selection.collapsed && linkSheet == null && !finding) linkSpotAt(body.text, body.selection.start) else null
                            }
                            val linkCalm = rememberCalm(Triple(body.text, body.selection, touching), 250)
                            var linkShown by remember { mutableStateOf(false) }
                            LaunchedEffect(spot?.label, linkCalm) { if (spot != null && linkCalm) { linkShown = true; delay(4500); linkShown = false } else linkShown = false }
                            val linkFade by animateFloatAsState(if (linkShown && still) 1f else 0f, tween(if (linkShown && still) 140 else 60), label = "linkBubble")
                            if (editing && spot != null && lay != null && linkFade > 0.01f)
                                LinkBubble(spot, lay, view.out.offsetMapping, fieldTop, scroll.value, viewportH, linkFade, { r -> bubbleHits[1] = r }, { openUrl(fileCtx, spot.url) }, if (spot.markdown) ({ openLink() }) else null)
                            val selOn = editorStyle != 1 && editing && focused && !body.selection.collapsed && lay != null && linkSheet == null
                            // The selection bubble shows once the selection has been still for a moment. What its own buttons do to the text (bold and so on) does not hide it:
                            // it stays, so a second tap, or the next button, finds it where it was.
                            var buttonAt by remember { mutableLongStateOf(0L) }
                            var selReady by remember { mutableStateOf(false) }
                            LaunchedEffect(body.text, body.selection, touching) {
                                if (System.currentTimeMillis() < buttonAt + 800L && selReady) return@LaunchedEffect
                                selReady = false; delay(450); selReady = true
                            }
                            val selSpan = if (selOn && lay != null) textSpanOf(lay, view.out.offsetMapping, minOf(body.selection.start, body.selection.end).coerceIn(0, body.text.length), maxOf(body.selection.start, body.selection.end).coerceIn(0, body.text.length)) else null
                            val bd = LocalDensity.current
                            val selSpot = if (selSpan != null) with(bd) {
                                BubblePlace.place(selSpan.top, selSpan.bottom, BUBBLE_H.toPx(), scroll.value - fieldTop, if (viewportH > 0) scroll.value + viewportH - fieldTop else Float.MAX_VALUE / 4f,
                                    30.dp.toPx(), 14.dp.toPx(), 64.dp.toPx(), 8.dp.toPx(), 0f, 0f)
                            } else null
                            val selFade by animateFloatAsState(if (selReady && still) 1f else 0f, tween(if (selReady && still) 160 else 60), label = "selBubble")
                            if (selOn && lay != null && selSpan != null && selSpot != null && selFade > 0.01f)
                                SelectionBubble(body, lay, selSpan, selSpot, selFade, mk, { r -> bubbleHits[0] = r }, { m -> buttonAt = System.currentTimeMillis(); edit(body.toggleInline(m)) }, { buttonAt = System.currentTimeMillis(); openLink() }, { buttonAt = System.currentTimeMillis(); edit(body.toggleCodeSpanHere()) },
                                    { val a = minOf(body.selection.start, body.selection.end).coerceIn(0, body.text.length); val b = maxOf(body.selection.start, body.selection.end).coerceIn(0, body.text.length); clipboard.setText(AnnotatedString(body.text.substring(a, b))) })
                        }
                        // Placed photos and files (see FloatLayer.kt): over the text, at the places and sizes they were given. They sit beside the box that handles
                        // taps on the text (not inside it), so a tap on one selects it even while reading.
                        if (floatItems.isNotEmpty()) FloatLayer(floatItems, FloatHost(textBoxW, maxOf(textLayout?.size?.height ?: 0, with(dn) { 320.dp.roundToPx() }), dn.density, lineTops, floatSizes, selFloat, !locked, editing,
                            { selFloat = it }, { k, s -> if (floatSizes[k] != s) floatSizes = floatSizes + (k to s) }, { k, p, what -> changeFloat(k, p, what) },
                            { k, how -> setMode(k, how) }, { k -> removeFloat(k) }, { k -> openFloat(k) }))
                        } }
                        }
                    }
                }
                viewerAt?.let { at -> PhotoViewer(imgs, at) { viewerAt = null } }
                // Links to and from this scrap, titles you could link, scraps that share its tags. Nothing is drawn for a scrap with no connections.
                ConnectionsSection(connections, connectionsOpen, { vm.setConnectionsOpen(!connectionsOpen) }, { uid -> rememberSpot(); scope.launch { flush(); vm.linkRequest.value = uid } }, if (locked) null else ({ m -> linkMentioned(m) }), Modifier.padding(bottom = 24.dp))
            }
if (cardsOn) CardsLayer(cards, !locked, { nc, what -> record(what); cards = nc }, { cardEdit = it }, Modifier.matchParentSize())
}
            // While a photo or file is being carried: the page dims a little, a line shows where it would land, and a small label follows the finger.
            // Touching and moving anywhere carries it, letting go drops it, a tap or Back cancels. Near the top or bottom edge the page scrolls by itself.
            if (dragKey != null) {
                Chunk {
                val acc = t.acc
                val edge = with(LocalDensity.current) { 72.dp.toPx() }
                val label = dragKey?.let { k -> if (k.startsWith("p")) "Photo" else files.getOrNull(k.drop(1).toIntOrNull() ?: -1)?.name ?: "File" } ?: ""
                LaunchedEffect(Unit) { keyboard?.hide() }
                LaunchedEffect(Unit) {
                    while (true) {
                        val y = dragAt.y; val h = viewportH.toFloat()
                        val step = if (!dragging) 0f else if (y < edge) -(edge - y) / edge * 26f else if (y > h - edge) (y - (h - edge)) / edge * 26f else 0f
                        if (step != 0f) { scroll.scrollBy(step); updateDrop() }
                        withFrameNanos { }
                    }
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .10f))
                    .onGloballyPositioned { overlayCoords = it }
                    .pointerInput(Unit) { detectTapGestures { cancelDrag() } }
                    .pointerInput(Unit) {
                        detectDragGestures(onDragStart = { o -> dragging = true; dragAt = o; updateDrop() }, onDragEnd = { commitDrop() }, onDragCancel = { cancelDrag() }) { change, _ ->
                            change.consume(); dragAt = change.position; updateDrop()
                        }
                    }
                    .drawBehind {
                        val l = dragLine
                        if (l != null) {
                            if (l.left == l.right) drawLine(acc, Offset(l.left, l.top), Offset(l.left, l.bottom), 6.dp.toPx(), StrokeCap.Round)
                            else drawLine(acc, Offset(20.dp.toPx(), l.top), Offset(size.width - 20.dp.toPx(), l.top), 6.dp.toPx(), StrokeCap.Round)
                        }
                    }) {
                    Text("Drag it where it should go, then let go. Tap to cancel", Modifier.align(Alignment.TopCenter).padding(top = 10.dp).clip(RoundedCornerShape(16.dp)).background(Sb.menu)
                        .padding(horizontal = 14.dp, vertical = 8.dp), color = Sb.ink, fontSize = 13.sp)
                    if (dragging) Row(Modifier.offset { IntOffset((dragAt.x - 80.dp.toPx()).roundToInt().coerceAtLeast(8), (dragAt.y - 84.dp.toPx()).roundToInt().coerceAtLeast(8)) }
                        .clip(RoundedCornerShape(20.dp)).background(Sb.menu).border(1.dp, acc, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
                        Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                        Ic(if (label == "Photo") "image" else "page", 18.dp, acc)
                        Text(label, Modifier.widthIn(max = 200.dp), color = Sb.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                }
            }
            // The Growing card pill floats over the page: it takes no room of its own, so the text runs behind it and scrolls clear of it.
            // Written out in full: inside this Box a bare AnimatedVisibility would be taken for the Column's one, which cannot be called here.
            if (editorStyle == 2) androidx.compose.animation.AnimatedVisibility(editing && !finding && !pillHidden, Modifier.align(Alignment.BottomCenter), enter = slideInVertically(tween(240)) { it } + fadeIn(tween(200)), exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(150))) {
                val linkHere = if (body.selection.collapsed) linkSpotAt(body.text, body.selection.start) else null
                val codeHere = remember(body.text, body.selection.start) { inCodeBlock(body.text, body.selection.start) }
                GrowBar(body.linePrefix(), history, panel, { panel = it },
                { edit(body.toggleLine("> ")) }, { edit(body.insertDivider()) }, { edit(body.cycleHeading()) }, { edit(body.toggleLine("- [ ] ")) }, { edit(body.toggleCodeBlockHere()) }, adds, quickGroups,
                !body.selection.collapsed, body.enclosing("**") != null, body.enclosing("*") != null, { inlineOnTarget("**") }, { inlineOnTarget("*") },
                (colorNow ?: lastColor)?.let { hexColor(it) } ?: t.acc, if (mixedSize) "–" else (sizeNow ?: 17).toString(),
                quickLayout, quickPinned, { vm.setQuickPinned(it) },
                pillMode(body.linePrefix(), !body.selection.collapsed, keyboardOpen, typing, panel != 0, linkHere != null, codeHere, isBlankLine(body.text, body.selection.start)), railMode,
                { n -> edit(body.toggleLine(if (n == 1) "# " else "## ")) }, { dd -> edit(body.indentBy(dd)) },
                { linkHere?.let { openUrl(fileCtx, it.url) } }, if (linkHere?.markdown == true) ({ openLink() }) else null, if (linkHere?.markdown == true) ({ edit(body.removeLink()) }) else null,
                { codeBlockAt(body.text, body.selection.start)?.let { clipboard.setText(AnnotatedString(it)) } }, { edit(body.toggleCodeBlockHere()) }, { edit(body.toggleLine("- ")) }, { typing = false })
            }
            // The Expanding chip (editor toolbar D) floats in the bottom corner, over the page, like the pill.
            if (editorStyle == 3) androidx.compose.animation.AnimatedVisibility(editing && !finding && !pillHidden, Modifier.align(Alignment.BottomEnd), enter = slideInVertically(tween(240)) { it } + fadeIn(tween(200)), exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(150))) {
                val linkHere = if (body.selection.collapsed) linkSpotAt(body.text, body.selection.start) else null
                val codeHere = remember(body.text, body.selection.start) { inCodeBlock(body.text, body.selection.start) }
                ChipBar(chipOpen, { chipOpen = true; chipAuto = false }, { chipOpen = false; chipAuto = false }, body.linePrefix(), history, panel, { panel = it },
                { edit(body.toggleLine("> ")) }, { edit(body.insertDivider()) }, { edit(body.cycleHeading()) }, { edit(body.toggleLine("- [ ] ")) }, { edit(body.toggleCodeBlockHere()) }, adds, quickGroups,
                body.enclosing("**") != null, body.enclosing("*") != null, { inlineOnTarget("**") }, { inlineOnTarget("*") },
                (colorNow ?: lastColor)?.let { hexColor(it) } ?: t.acc, if (mixedSize) "–" else (sizeNow ?: 17).toString(),
                quickLayout, quickPinned, { vm.setQuickPinned(it) },
                pillMode(body.linePrefix(), !body.selection.collapsed, keyboardOpen, false, panel != 0, linkHere != null, codeHere),
                { n -> edit(body.toggleLine(if (n == 1) "# " else "## ")) }, { dd -> edit(body.indentBy(dd)) },
                { linkHere?.let { openUrl(fileCtx, it.url) } }, if (linkHere?.markdown == true) ({ openLink() }) else null, if (linkHere?.markdown == true) ({ edit(body.removeLink()) }) else null,
                { codeBlockAt(body.text, body.selection.start)?.let { clipboard.setText(AnnotatedString(it)) } }, { edit(body.toggleCodeBlockHere()) })
            }
            }
            AnimatedVisibility(pasteHint != null && editing && !finding, enter = fadeIn(tween(160)) + expandVertically(), exit = fadeOut(tween(120)) + shrinkVertically()) {
                pasteHint?.let { h -> PasteHintBar(h.offer, h.busy, { applyPaste(h) }, if (h.offer == PasteOffer.Link) ({ applyCard(h) }) else null, { pasteHint = null }) }
            }
            // The toolbar only exists while writing: it slides up from the bottom edge when you start and back down when you stop.
            AnimatedVisibility(editing && !finding && editorStyle < 2, enter = slideInVertically(tween(240)) { it } + fadeIn(tween(200)), exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(150))) {
                if (editorStyle == 0) BubbleBar(body.linePrefix(), history,
                    if (mixedSize) "–" else (sizeNow ?: 17).toString(), (colorNow ?: lastColor)?.let { hexColor(it) } ?: t.acc, panel, { panel = it },
                    { edit(body.toggleLine("> ")) }, { edit(body.insertDivider()) }, { edit(body.cycleHeading()) }, { edit(body.toggleLine("- [ ] ")) }, { edit(body.toggleCodeBlockHere()) },
                    sizeNow, { n -> applySpan { it.copy(size = n) } },
                    adds, quickGroups)
                else PillBar(body, { m -> edit(body.toggleInline(m)) }, { edit(body.cycleHeading()) }, { edit(body.toggleLine("- ")) },
                    { edit(body.toggleLine("1. ")) }, { edit(body.toggleLine("- [ ] ")) })
            }
        }
    }
    // Opening the color panel on text that is highlighted starts on the Highlighter tab, anywhere else on the text color.
    LaunchedEffect(panel) { if (panel == 2) { colorTab = pendingTab ?: if (body.enclosing("==") != null) 1 else 0; pendingTab = null } }
    LaunchedEffect(body.selection.collapsed) { if (body.selection.collapsed && (panel == 4 || panel == 5)) panel = 0 }
    if (panel != 0 && editorStyle != 1) {
        // Floats above the bottom bar, whether or not the keyboard is open. A tap outside closes it; the bar stays tappable.
        val barGap = WindowInsets.ime.union(WindowInsets.navigationBars)
        Box(Modifier.fillMaxSize().windowInsetsPadding(barGap).padding(bottom = if (railMode) 6.dp else if (editorStyle == 2) 64.dp else 76.dp)) {
            Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { panel = 0 })
            Box(Modifier.align(if (editorStyle == 3) Alignment.BottomEnd else Alignment.BottomCenter).then(if (editorStyle == 3) Modifier.widthIn(max = 320.dp) else Modifier).padding(start = if (editorStyle == 2) 12.dp else 16.dp, end = if (railMode) 72.dp else if (editorStyle == 2) 12.dp else 16.dp, top = 6.dp, bottom = 6.dp)) {
                val tg2 = target(); val attrs2 = if (!body.selection.collapsed) tg2?.let { (a, b) -> body.attrsIn(a, b) }.orEmpty() else listOf(attrsAtCursor(body.text, body.selection.start))
                val panelBody: @Composable () -> Unit = {
                when (panel) {
                    4 -> GrowPop {
                        GrowColors(attrs2.firstOrNull()?.color, recentColors, { hex -> lastColor = hex; applySpan { it.copy(color = hex) } }, { tab -> pendingTab = tab; panel = 2 })
                    }
                    5 -> GrowPop { GrowSizes(attrs2.map { it.size }.distinct().singleOrNull(), { n -> applySpan { it.copy(size = n) } }) }
                    1 -> if (editorStyle >= 2) {
                        val (ind0, al0) = body.lineState()
                        GrowCard(body.linePrefix(), body.enclosing("**") != null, body.enclosing("*") != null,
                            attrs2.let { l -> l.isNotEmpty() && l.all { it.underline } }, body.enclosing("~~") != null, al0, ind0,
                            { edit(body.toggleLine("- ")) }, { edit(body.toggleLine("1. ")) }, { c -> edit(body.setAlign(c)) }, { m -> inlineOnTarget(m) }, { toggleUnderline() }, { d -> edit(body.indentBy(d)) },
                            attrs2.firstOrNull()?.color, recentColors, { hex -> lastColor = hex; applySpan { it.copy(color = hex) } }, { tab -> pendingTab = tab; panel = 2 },
                            attrs2.map { it.size }.distinct().singleOrNull(), { n -> applySpan { it.copy(size = n) } })
                    } else {
                        val (ind, al) = body.lineState()
                        TextOptionsPanel(body.linePrefix(), body.enclosing("**") != null, body.enclosing("*") != null, (if (!body.selection.collapsed) attrs2 else listOf(attrsAtCursor(body.text, body.selection.start))).let { l -> l.isNotEmpty() && l.all { it.underline } }, body.enclosing("~~") != null, al, ind,
                            { edit(body.toggleLine("- ")) }, { edit(body.toggleLine("1. ")) }, { c -> edit(body.setAlign(c)) }, { m -> inlineOnTarget(m) }, { toggleUnderline() },
                            { d -> edit(body.indentBy(d)) }, { panel = 0 })
                    }
                    2 -> {
                        val tabs: @Composable () -> Unit = { ColorTabs(colorTab) { colorTab = it } }
                        if (colorTab == 1) HighlighterPanel(mk, { setMarker(mk.copy(color = it)) }, { setMarker(mk.copy(opacity = it)) }, tabs)
                        else FontColorPanel(attrs2.firstOrNull()?.color, recentColors, { hex -> lastColor = hex; applySpan { it.copy(color = hex) } }, { hex -> vm.rememberColor(hex) }, { panel = 0 }, tabs)
                    }
                    else -> Unit   // the size list (panel 3) is a popup that belongs to the size button; this layer only catches a tap outside it
                }
                }
                // The Growing card's cards fade up 8dp as they open (only on opening; going from one card to another does not replay it).
                if (editorStyle >= 2) androidx.compose.animation.AnimatedVisibility(remember { androidx.compose.animation.core.MutableTransitionState(false).apply { targetState = true } }, enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { 24 }) { panelBody() } else panelBody()
            }
        }
    }
    AnimatedVisibility(menu, Modifier.fillMaxSize(), enter = fadeIn(tween(120)), exit = fadeOut(tween(100))) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .5f)).semantics { contentDescription = "Close menu" }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { menu = false })
    }
    AnimatedVisibility(menu, Modifier.align(Alignment.TopEnd),
        enter = fadeIn(tween(140)) + scaleIn(tween(160), initialScale = .92f, transformOrigin = TransformOrigin(1f, 0f)), exit = fadeOut(tween(100))) {
        MenuPanel {
            // The short main list, plus a few small pages inside the same card (Add to page, Page, Share & copy, Format). Each page has a way back
            // and, where it makes sense, a link that opens Settings already narrowed to the related group.
            val openSettings = { query: String -> menu = false; scope.launch { flush(); vm.settingsSearch = query; nav.navigate("settings") } }
            AnimatedContent(menuPage, transitionSpec = { fadeIn(tween(140, delayMillis = 50)) togetherWith fadeOut(tween(90)) }, label = "menu page") { page ->
                Column(Modifier.fillMaxWidth()) {
                    when (page) {
                        MenuPage.Main -> {
                            if (findEntry != 0) MenuRow("search", "Find in scrap") { menu = false; finding = true; panel = 0 }
                            MenuRow("eye", "Reading view") { menu = false; rememberSpot(); scope.launch { flush(); if (curId != 0L) nav.navigate("item/$curId") } }
                            MenuRow("jump", "Go to…") { menu = false; keyboard?.hide(); switcher = true }
                            if (live != null) MenuRow(if (live.pinned) "star" else "starline", if (live.pinned) "Unpin" else "Pin", iconColor = if (live.pinned) t.acc else Sb.ink) { menu = false; haptics.toggle(!live.pinned); vm.togglePin(live) }
                            MenuDivider()
                            // View only turns the editing groups off: nothing on the page can be changed until you unlock it with the book button.
                            // With the bubble toolbar these live in its + window; the pill toolbar has no + button, so it keeps the page here.
                            if (!locked && editorStyle == 1) MenuRow("plus", "Add to page", chevron = true) { menuPage = MenuPage.Add }
                            if (!locked || live != null) MenuRow("palette", "Page", chevron = true) { menuPage = MenuPage.Page }
                            MenuRow("share", "Share & copy", chevron = true) { menuPage = MenuPage.Share }
                            if (editorStyle == 1 && editing) MenuRow("edit", "Format", chevron = true) { menuPage = MenuPage.Format }
                            if (live != null) {
                                MenuDivider()
                                MenuRow("trash", "Delete", tint = Sb.danger) { menu = false; vm.delete(live); nav.backToLists() }
                            }
                            MenuDivider()
                            MenuRow("sliders", "Settings") { menu = false; scope.launch { flush(); nav.navigate("settings") } }
                            MenuDivider()
                            val words = body.text.split(Regex("\\s+")).count { it.isNotBlank() }
                            Text("$words ${if (words == 1) "word" else "words"} · ${body.text.length} characters" + if (body.text.length > 3000) " · styled in $lastStyledMs ms" else "", color = Sb.mute, fontSize = 12.5.sp, fontFamily = LocalFonts.current.second,
                                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp))
                        }
                        MenuPage.Add -> {
                            MenuBack("Add to page") { menuPage = MenuPage.Main }
                            if (cardsOn) MenuRow("layout", "Add a card") { menu = false; addCard() }
                            MenuRow("page", "Attach file", "PDF, zip or any file") { menu = false; attachFile() }
                            MenuRow("mic", "Record audio", "A voice memo or a demo") { menu = false; recording = true }
                            MenuRow("link", "Link to scrap", "Connect it to another scrap") { menu = false; keyboard?.hide(); pickerAt = null; pickerOpen = true }
                            MenuRow("edit", "Text tools", "Move line, checklist, date") { menu = false; keyboard?.hide(); toolsOpen = true }
                            MenuDivider()
                            MenuRow("sliders", "Editor settings", "Pasting, #tags, links, toolbar") { openSettings("Editor") }
                        }
                        MenuPage.Page -> {
                            MenuBack("Page") { menuPage = MenuPage.Main }
                            if (!locked) MenuRow("folder", "Add to box", if (shelf == "Inbox") "Inbox" else vm.shelves.value.displayName(shelf)) { menu = false; keyboard?.hide(); boxOpen = true }
                            if (!locked) MenuRow("tag", "Tags", parseTags(tags).let { l -> if (l.isEmpty()) "Add words to find it by" else l.joinToString(", ") { "#$it" } }) { menu = false; keyboard?.hide(); tagsOpen = true }
                            if (live != null) MenuRow("palette", "Page style", "Icon, accent, cover, type") { menu = false; scope.launch { flush(); keyboard?.hide(); pageStyle = true } }
                            if (!locked && (imgs.isNotEmpty() || files.isNotEmpty())) MenuRow("sort", "Arrange page", "Where photos, files and text sit") { menu = false; keyboard?.hide(); arrangeOpen = true }
                            if (live != null && Layout.entries.size > 1) MenuRow("layout", "Change layout") { menu = false; rememberSpot(); scope.launch { flush(); nav.navigate("layouts/${live.id}") } }
                            if (live != null && !locked) MenuRow("clock", "Version history", "Earlier texts of this scrap") { menu = false; versionsOpen = true }
                            MenuDivider()
                            MenuRow("sliders", "Look settings", "Theme, accent, headings, corners") { openSettings("Look") }
                        }
                        MenuPage.Share -> {
                            MenuBack("Share & copy") { menuPage = MenuPage.Main }
                            MenuRow("share", "Share") { menu = false; shareNow() }
                            MenuRow("copy", "Copy text") { menu = false; copyNow() }
                            MenuRow("link", "Copy link to scrap", "To paste into another app or scrap") {
                                menu = false
                                val u = live?.uid
                                if (u != null) { clipboard.setText(AnnotatedString(scrapLink(u))); Toast.makeText(fileCtx, "Link copied", Toast.LENGTH_SHORT).show() }
                                else Toast.makeText(fileCtx, "Write something first, so there is a scrap to link to", Toast.LENGTH_SHORT).show()
                            }
                            if (live != null) MenuRow("newfile", "Duplicate") { menu = false; duplicateNow() }
                            BinderMenuRows(live?.uid, live?.title ?: title, body.text) { menu = false }   // [binder hook 3]
                            SongbookMenuRows(live?.uid, live?.title ?: title, body.text) { menu = false }   // [songbook hook 3]
                            MenuDivider()
                            MenuRow("sliders", "Backup settings", "Back up, restore, import") { openSettings("Data") }
                        }
                        MenuPage.Format -> {
                            MenuBack("Format") { menuPage = MenuPage.Main }
                            MenuRow("undo", "Undo", hist.undoLabel, enabled = hist.undoLabel != null) { menu = false; doUndo() }
                            MenuRow("redo", "Redo", hist.redoLabel, enabled = hist.redoLabel != null) { menu = false; doRedo() }
                            MenuRow("quote", "Quote") { menu = false; edit(body.toggleLine("> ")) }
                            MenuRow("divider", "Divider") { menu = false; edit(body.insertDivider()) }
                            MenuRow("code", "Code block") { menu = false; edit(body.toggleCodeBlockHere()) }
                            MenuDivider()
                            MenuRow("sliders", "Toolbar settings", "Selection bubble or floating pill") { openSettings("Editor toolbar") }
                        }
                    }
                }
            }
        }
    }
    // "Go to…": the scrap is saved first, then the place opens on top of it (Back returns here).
    if (switcher) SwitcherSheet(vm, { route -> rememberSpot(); scope.launch { flush(); nav.navigate(route) } }) { switcher = false }
    if (pickerOpen) LinkPickerSheet(live?.uid ?: "", body.text, parseTags(tags), shelf, list, { insertScrapLink(it) }, { pickerOpen = false; pickerAt = null })
    // Arranging by group puts all the photos together and all the files together again, in the order chosen here.
    if (boxOpen) BoxPickSheet(shelf, vm, { setShelf(it) }) { boxOpen = false }
    if (tagsOpen) Sheet("Tags", { tagsOpen = false }, subtitle = "Tags are searchable") { TagEditor(tags, knownTags, { setTags(it) }) }
    if (arrangeOpen) ArrangeSheet(PageLayout.groups(PageLayout.fit(pageParts, imgs.size, files.size)), imgs.size, files.size, { from, to ->
        val order = Blocks.move(PageLayout.groups(PageLayout.fit(pageParts, imgs.size, files.size)), from, to)
        record("Page arranged"); pageParts = PageLayout.regroup(order, imgs.size, files.size)
    }, { arrangeOpen = false })
    if (pageStyle) live?.let { l -> CustomizeSheet(l, vm, { pageStyle = false }, color = color, onColor = { setColor(it) }, kind = kind, onKind = { setKind(it) }) }
    // A finished recording joins the scrap's files like any attached file, and is part of Undo like them.
    if (recording) RecordSheet(onSaved = { a -> record("Audio recorded", merge = true); files = files + a; recording = false }, onDone = { recording = false })
    renaming?.let { a -> RenameSheet(a.name, { n -> record("File renamed"); files = files.withName(a.path, n) }, { renaming = null }) }
    if (toolsOpen) {
        val (total, ticked) = checklistCounts(body.text)
        Sheet("Text tools", { toolsOpen = false }) {
            SheetLabel("Lines")
            SheetGroup {
                ActionRow("up", "Move line up", "The line with the cursor, or every selected line") { moveLine(true) }
                SheetDivider(56.dp)
                ActionRow("down", "Move line down") { moveLine(false) }
            }
            if (total > 0) {
                SheetLabel("Checklist")
                SheetNote("$ticked of $total ticked. These work on the list the cursor is in, or on every list when it is not in one.")
                SheetGroup {
                    ActionRow("check", "Ticked items to the bottom") { tidyChecklist(CheckAction.TickedToBottom, "Ticked items moved") }
                    SheetDivider(56.dp)
                    ActionRow("undo", "Untick all") { tidyChecklist(CheckAction.UntickAll, "Unticked all") }
                    SheetDivider(56.dp)
                    ActionRow("check", "Tick all") { tidyChecklist(CheckAction.TickAll, "Ticked all") }
                    SheetDivider(56.dp)
                    ActionRow("trash", "Clear ticked items", "Undo brings them back", danger = true) { tidyChecklist(CheckAction.ClearTicked, "Ticked items cleared") }
                }
            }
            SheetLabel("Insert")
            SheetGroup { ActionRow("clock", "Today's date", todayText()) { insertDate(); toolsOpen = false } }
        }
    }
    if (versionsOpen && curId != 0L) {
        val versions by vm.versionsOf(curId).collectAsState(emptyList())
        VersionsSheet(versions, { restoreVersion(it) }, { versionsOpen = false })
    }
    cardEdit?.let { cid ->
        cards.firstOrNull { it.id == cid }?.let { c ->
            CardsSheet(c, { nc, what -> record("Edit card", "card-$cid-$what", merge = true); cards = PageCards.update(cards, cid) { nc } },
                onDuplicate = { record("Copy card"); cards = PageCards.duplicate(cards, cid); cardEdit = cards.last().id },
                onFront = { record("Bring card to front"); cards = PageCards.toFront(cards, cid) },
                onDelete = { record("Delete card"); cards = PageCards.remove(cards, cid); cardEdit = null },
                onPickPicture = { target -> cardPicTarget = target; pickCardPic.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                onDone = { cardEdit = null })
        }
    }
    linkSheet?.let { sel ->
        val sheetBody = body.copy(selection = sel)
        val existingLink = sheetBody.link() != null
        val clean = linkUrl.trim().filterNot { it.isWhitespace() || it == ')' }
        // An address that already has a scheme (https://, scrapbook://, mailto: ...) is kept as it is; a bare "example.com" gets https://.
        val fullUrl = if ("://" in clean || clean.startsWith("mailto:", true) || clean.startsWith("tel:", true)) clean else "https://$clean"
        val focus = remember { FocusRequester() }
        Sheet(if (existingLink) "Edit link" else "Add link", { linkSheet = null }, doneLabel = if (existingLink) "Save" else "Add link", enabled = clean.isNotEmpty(),
            primary = { edit(sheetBody.setLink(fullUrl)); linkSheet = null }) {
            LaunchedEffect(Unit) { focus.requestFocus() }
            InputBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ic("link", 20.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                    Field(linkUrl, { linkUrl = it }, "https://", 16.sp, headFont(), modifier = Modifier.weight(1f).focusRequester(focus))
                }
            }
            if (existingLink) SheetGroup {
                val current = sheetBody.link()?.second?.groupValues?.get(2).orEmpty()
                if (current.isNotBlank()) { ActionRow("external", "Open link", sub = if (parseScrapLink(current) != null) "Another scrap" else current.take(60)) { openUrl(fileCtx, current) }; SheetDivider(56.dp) }
                ActionRow("close", "Remove link") { edit(sheetBody.removeLink()); linkSheet = null }
            }
        }
    }
    }
}
