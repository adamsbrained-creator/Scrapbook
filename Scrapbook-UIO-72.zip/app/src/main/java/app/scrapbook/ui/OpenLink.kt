package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Opens an address in the browser, or in the app that owns it (readest:// opens Paperback). An address typed without https:// gets it.
 * Says so instead of crashing when nothing on the phone can open it.
 */
fun openUrl(ctx: Context, raw: String) {
    val t = raw.trim()
    val url = if ("://" in t || t.startsWith("mailto:", true) || t.startsWith("tel:", true) || t.startsWith("sms:", true)) t else "https://$t"
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, when { url.startsWith("readest://") -> "Paperback isn't installed on this phone"; url.startsWith("binder://") -> "Binder isn't installed on this phone"; url.startsWith("songbook://") -> "Songbook isn't installed on this phone"; else -> "No app on this phone can open that link" }, Toast.LENGTH_SHORT).show()
    }
}
