package app.scrapbook

import android.content.Context

// What Scrapbook remembers about how a scrap and its song last matched (see Songbook.kt, decideSync). Only a short fingerprint of the text is kept, in the
// phone's small settings storage, so it needs no database change. Lost (a reinstall), it just means the next "Edit in Scrapbook" keeps the scrap as it is.

private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("songbook_sync", Context.MODE_PRIVATE)

/** The fingerprint of the text this scrap and its song had when they last matched, or null. */
fun songbookSyncedKey(ctx: Context, uid: String): String? = prefs(ctx).getString("synced_" + uid.lowercase(), null)

/** Scrap and song match now, with this fingerprint. */
fun songbookRememberSynced(ctx: Context, uid: String, key: String) { prefs(ctx).edit().putString("synced_" + uid.lowercase(), key).apply() }

/** The scrap has just been sent: this is what it said. It counts as matching only once Songbook confirms (see [songbookConfirmSent]). */
fun songbookRememberSent(ctx: Context, uid: String, key: String) { prefs(ctx).edit().putString("sent_" + uid.lowercase(), key).apply() }

/** Songbook confirmed it took what was sent: that text is now the one both sides have. */
fun songbookConfirmSent(ctx: Context, uid: String) {
    val key = prefs(ctx).getString("sent_" + uid.lowercase(), null) ?: return
    songbookRememberSynced(ctx, uid, key)
}
