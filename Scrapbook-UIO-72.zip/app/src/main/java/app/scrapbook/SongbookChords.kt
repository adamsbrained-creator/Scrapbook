package app.scrapbook

// CHORDS ABOVE THE WORDS -> [CHORDS] IN THE WORDS
//
// Many scraps hold a song the way it is written on paper: a line of chords, and under it the line of words, with spaces to push each chord over the word
// it belongs to. Songbook keeps chords inside the words, "[Am]You were [G]light". This turns the first into the second when a scrap is sent. (Pure rules,
// no Android in it; it is used by songTextOf in Songbook.kt, so everything that crosses to Songbook goes through it.)
//
//  * a line is a chord line when every word on it is a chord (Fmaj7, Em/A, G7/F, Asus2, (Fmaj7/A)) or a repeat mark like (x2), and at least one is a chord
//  * a chord line followed by a line of words is laid over those words: each chord goes in front of the word it sits over
//  * a chord line with no words under it (or with more chords than the words have) stays a line of chords, "[Am Fmaj7/A]"
//  * a line of its own that is bold, or short and ending with ":", is a heading: "# verse one:"
//  * "Capo 4 fret" is taken out of the text and its number returned; the chords are shapes played with that capo, so they are written as the sounding
//    chords (a capo on fret 4 turns Fmaj7 into Amaj7) and Songbook shows the shapes again when its capo is set to that fret
//
// Where a chord sits over a word is measured, not counted: the text is in a font where letters have different widths, so "twelve spaces" is not twelve
// letters. Both lines are laid out with the widths of a common sans-serif font (bold for the chords) and each chord goes to the word it is over; one
// that is over the last fifth of a word goes to the next word (that is where the eye puts it).

/** The lines of a song with the chords moved into the words, and the capo fret that was written in it (0 when none was). */
class ChordSheet(val lines: List<String>, val capo: Int)

private fun widths(spec: String): Map<Char, Int> {
    val m = HashMap<Char, Int>()
    for (item in spec.split(' ')) if (item.length > 1) m[item[0]] = item.substring(1).toInt()
    return m
}

private val REGULAR_WIDTHS = widths("!278 '191 ’222 ‘222 “333 ”333 (333 )333 ,278 -333 .278 /278 :278 ;278 ?556 ~584 |260 #556 *389 &667 " +
    "a556 b556 c500 d556 e556 f278 g556 h556 i222 j222 k500 l222 m833 n556 o556 p556 q556 r333 s500 t278 u556 v500 w722 x500 y500 z500 " +
    "A667 B667 C722 D722 E667 F611 G778 H722 I278 J500 K667 L556 M833 N722 O778 P667 Q778 R722 S667 T611 U722 V667 W944 X667 Y667 Z611")

private val BOLD_WIDTHS = widths("!333 '238 ’278 (333 )333 ,278 -333 .278 /278 :333 ;333 ?611 ~584 |280 #556 *389 " +
    "a556 b611 c556 d611 e556 f333 g611 h611 i278 j278 k556 l278 m889 n611 o611 p611 q611 r389 s556 t333 u611 v556 w778 x556 y556 z500 " +
    "A722 B722 C722 D722 E667 F611 G778 H722 I278 J556 K722 L611 M833 N722 O778 P667 Q778 R722 S667 T611 U722 V667 W944 X667 Y667 Z611")

private fun advance(s: String, upto: Int, bold: Boolean): Int {
    val table = if (bold) BOLD_WIDTHS else REGULAR_WIDTHS
    var x = 0
    for (i in 0 until minOf(upto, s.length)) x += if (s[i] == ' ') 278 else (table[s[i]] ?: 556)
    return x
}

private const val NOTE = "[A-G][#b]?"
private val CHORD = Regex("^" + NOTE + "(?:maj|min|dim|aug|sus|add|Add|m|M|\\+|°|ø)?(?:(?:maj|sus|add|Add|b|#|-|\\+)?\\d+)*(?:/" + NOTE + ")?$")
private val REPEAT = Regex("^\\(?[xX]\\d+\\)?$|^\\(?\\d+[xX]\\)?$")
private val SEPARATOR = Regex("^[|/\\-~.]+$")
private val CAPO = Regex("^\\s*capo\\b[^0-9]{0,8}(\\d{1,2})\\b.*$", RegexOption.IGNORE_CASE)
private val WORD = Regex("\\S+")
private val CHORD_PARTS = Regex("^(" + NOTE + ")(.*?)(?:/(" + NOTE + "))?$")

private val SHARPS = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private val NOTE_INDEX = mapOf("C" to 0, "C#" to 1, "Db" to 1, "D" to 2, "D#" to 3, "Eb" to 3, "E" to 4, "F" to 5, "F#" to 6, "Gb" to 6,
    "G" to 7, "G#" to 8, "Ab" to 8, "A" to 9, "A#" to 10, "Bb" to 10, "B" to 11)

private fun transposeNote(note: String, by: Int): String = SHARPS[((NOTE_INDEX[note] ?: 0) + by).mod(12)]

/** A chord [by] semitones higher ("Fmaj7/A" by 4 is "Amaj7/C#"). "Add9" is written "add9". */
fun transposeChord(chord: String, by: Int): String {
    val c = chord.replace("Add", "add")
    if (by == 0) return c
    val m = CHORD_PARTS.matchEntire(c) ?: return c
    val bass = m.groupValues[3]
    return transposeNote(m.groupValues[1], by) + m.groupValues[2] + (if (bass.isEmpty()) "" else "/" + transposeNote(bass, by))
}

private fun words(line: String): List<Pair<Int, String>> = WORD.findAll(line).map { it.range.first to it.value }.toList()

/** The chord a word is ("(Fmaj7/A)" is Fmaj7/A), or null. */
private fun chordOf(word: String): String? {
    val t = word.trim('(', ')')
    return if (CHORD.matches(t)) t else null
}

private fun isChordLine(line: String, bold: Boolean): Boolean {
    val w = words(line)
    if (w.isEmpty()) return false
    var real = 0
    for ((_, x) in w) {
        if (chordOf(x) != null) real++
        else if (!REPEAT.matches(x) && !SEPARATOR.matches(x)) return false
    }
    if (real == 0) return false
    return bold || real > 1 || w.size > 1 || w[0].second.length > 1
}

private fun isHeading(line: String, bold: Boolean): Boolean {
    val s = line.trim()
    if (s.isEmpty()) return false
    if (s.startsWith("#")) return true
    return bold || (s.endsWith(":") && s.split(Regex("\\s+")).size <= 3)
}

private fun wordEnd(text: String, start: Int): Int {
    var e = start
    while (e < text.length && !text[e].isWhitespace()) e++
    return e
}

/** The start of the word that a chord at horizontal position [x] is over: the one it is inside; in a gap, the nearer one; over a word's last fifth, the next. */
private fun pickWord(text: String, starts: List<Int>, x: Int): Int {
    var best = starts[0]
    for (i in starts.indices) {
        val st = starts[i]
        val sx = advance(text, st, false)
        val ex = advance(text, wordEnd(text, st), false)
        if (x < sx) {
            if (i == 0) return st
            val prev = starts[i - 1]
            val prevEnd = advance(text, wordEnd(text, prev), false)
            return if (x - prevEnd <= sx - x) prev else st
        }
        if (x <= ex) {
            if (i + 1 < starts.size && ex > sx && (x - sx).toDouble() / (ex - sx) >= 0.8) return starts[i + 1]
            return st
        }
        best = st
    }
    return best
}

/**
 * [lines] are the lines of a song without their formatting marks; [bolds] says for each whether the whole line was bold in the scrap (a bold line that is
 * not chords is a heading). Returns the lines with chords inside the words, headings as "# ..." and the capo line taken out.
 */
fun convertChordSheet(lines: List<String>, bolds: List<Boolean>): ChordSheet {
    var capo = 0
    val keep = ArrayList<Pair<String, Boolean>>()
    for (i in lines.indices) {
        val l = lines[i]
        val m = CAPO.matchEntire(l)
        if (capo == 0 && m != null && l.trim().split(Regex("\\s+")).size <= 4) { capo = m.groupValues[1].toInt(); continue }
        keep += l to bolds[i]
    }
    val out = ArrayList<String>()
    var i = 0
    while (i < keep.size) {
        val (line, bold) = keep[i]
        if (line.isBlank()) { out += ""; i++; continue }
        if (line.trim().startsWith("#")) { out += line.trim(); i++; continue }
        if (isChordLine(line, bold)) {
            val next = if (i + 1 < keep.size) keep[i + 1] else null
            val hasWords = next != null && next.first.isNotBlank() && !isChordLine(next.first, next.second) && !isHeading(next.first, next.second)
            val chords = words(line).mapNotNull { (col, w) -> chordOf(w)?.let { col to it } }
            if (hasWords && next != null) {
                val text = next.first
                val starts = words(text).map { it.first }
                if (chords.size <= starts.size) {
                    val placed = chords.map { (col, ch) -> pickWord(text, starts, advance(line, col, true)) to transposeChord(ch, capo) }
                    val sb = StringBuilder()
                    var last = 0
                    for (pos in placed.map { it.first }.distinct().sorted()) {
                        sb.append(text, last, pos)
                        for ((p, c) in placed) if (p == pos) sb.append('[').append(c).append(']')
                        last = pos
                    }
                    sb.append(text, last, text.length)
                    out += sb.toString()
                    i += 2
                    continue
                }
            }
            val parts = ArrayList<String>()
            val group = ArrayList<String>()
            for ((_, w) in words(line)) {
                val ch = chordOf(w)
                if (ch != null) group += transposeChord(ch, capo)
                else {
                    if (group.isNotEmpty()) { parts += "[" + group.joinToString(" ") + "]"; group.clear() }
                    parts += w
                }
            }
            if (group.isNotEmpty()) parts += "[" + group.joinToString(" ") + "]"
            out += parts.joinToString(" ")
            i++
            continue
        }
        if (isHeading(line, bold)) { out += "# " + line.trim(); i++; continue }
        out += line
        i++
    }
    return ChordSheet(out, capo)
}
