package app.scrapbook

import java.text.DateFormat
import java.util.Date
import java.util.Locale

// The plain rules behind the editor's extra tools: a clean copy of a scrap for sharing, moving lines, checklist helpers, today's date and
// find-and-replace. They work on text and positions only (no screen code), so they can be tested on their own.

/** New text with the selection (or cursor, when [start] == [end]) in it. */
data class TextEdit(val text: String, val start: Int, val end: Int)

// ---------------------------------------------------------------------------------------------------------------------------------
// Share and copy
// ---------------------------------------------------------------------------------------------------------------------------------

private val LINK_RE = Regex("\\[([^\\]\\n]+)\\]\\(([^)\\s]*)\\)")
private val NUM_START = Regex("^\\d+\\. ")

/**
 * A scrap as plain text for sharing or copying: the title, then the text without its formatting codes. Lists keep a visible marker (• ☐ ☑ or the number),
 * indents stay, a divider becomes a line, and a link keeps its address: "docs (https://example.com)". A first line that only repeats the title is dropped.
 */
fun plainText(title: String, body: String): String {
    val head = title.trim()
    val bodyLines = (if (head.isEmpty()) body else bodyWithoutTitle(head, body)).lines(); val code = codeLineStates(bodyLines)
    // Code keeps its own text, indented four spaces so it stays set apart without the fences; everything else loses its formatting codes.
    val lines = bodyLines.mapIndexedNotNull { i, l ->
        when (code[i]) { CodeLine.OPEN, CodeLine.CLOSE -> null; CodeLine.BODY -> if (l.isEmpty()) "" else "    $l"; else -> plainLine(l) }
    }
    val text = lines.joinToString("\n").trim('\n')
    return when { head.isEmpty() -> text; text.isBlank() -> head; else -> head + "\n\n" + text }
}

private fun plainLine(raw: String): String {
    if (raw.trim() == "---") return "———"
    val prefix = LINE_PREFIX_RE.find(raw)?.value.orEmpty()
    val afterPrefix = raw.substring(prefix.length)
    val tags = LINE_TAGS.find(afterPrefix)
    val indent = tags?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
    val rest = afterPrefix.substring(tags?.value?.length ?: 0)
    val text = stripInline(LINK_RE.replace(rest) { m ->
        val label = m.groupValues[1]; val url = m.groupValues[2]
        if (url.isBlank() || label == url) label else "$label ($url)"
    })
    val marker = when {
        prefix == "- [ ] " -> "☐ "
        prefix == "- [x] " -> "☑ "
        prefix == "- " -> "• "
        prefix == "> " -> "> "
        NUM_START.matches(prefix) -> prefix
        else -> ""
    }
    return "  ".repeat(indent) + marker + text
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Today's date
// ---------------------------------------------------------------------------------------------------------------------------------

/** Today as written in the phone's language, for example "Oct 17, 2026" or "17 Oct 2026". */
fun todayText(now: Long = System.currentTimeMillis(), locale: Locale = Locale.getDefault()): String =
    DateFormat.getDateInstance(DateFormat.MEDIUM, locale).format(Date(now))

/** The time now in the phone's style, for example "9:41 AM" or "09:41". */
fun timeText(now: Long = System.currentTimeMillis(), locale: Locale = Locale.getDefault()): String =
    DateFormat.getTimeInstance(DateFormat.SHORT, locale).format(Date(now))

/** Date and time together: "Oct 17, 2026, 9:41 AM". */
fun dateTimeText(now: Long = System.currentTimeMillis(), locale: Locale = Locale.getDefault()): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale).format(Date(now))

/** [insert] put where the selection is (it replaces the selected text); the cursor ends up after it. */
fun insertAt(text: String, selStart: Int, selEnd: Int, insert: String): TextEdit {
    val a = minOf(selStart, selEnd).coerceIn(0, text.length); val b = maxOf(selStart, selEnd).coerceIn(0, text.length)
    val out = text.substring(0, a) + insert + text.substring(b)
    return TextEdit(out, a + insert.length, a + insert.length)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Move lines
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * Moves the line the cursor is on (or every line the selection touches) one line up or down, and takes the selection along. Null when it is
 * already the first or last line. In a numbered list the numbers stay where they are, so "1. 2. 3." never gets out of order.
 */
fun moveLines(text: String, selStart: Int, selEnd: Int, up: Boolean): TextEdit? {
    val lines = text.split("\n")
    val a0 = minOf(selStart, selEnd).coerceIn(0, text.length); val b0 = maxOf(selStart, selEnd).coerceIn(0, text.length)
    fun pos(off: Int): Pair<Int, Int> {
        var start = 0
        for (i in lines.indices) { val end = start + lines[i].length; if (off <= end) return i to (off - start); start = end + 1 }
        return lines.lastIndex to lines.last().length
    }
    val (sl, sc) = pos(a0)
    var (el, ec) = pos(b0)
    // A selection that ends at the very start of a line does not include that line.
    if (b0 > a0 && ec == 0 && el > sl) { el -= 1; ec = lines[el].length }
    if (if (up) sl == 0 else el == lines.lastIndex) return null
    val nb = if (up) sl - 1 else el + 1
    val block = lines.subList(sl, el + 1).toList()
    val out = ArrayList<String>(lines.size)
    if (up) { out += lines.subList(0, nb); out += block; out += lines[nb]; out += lines.subList(el + 1, lines.size) }
    else { out += lines.subList(0, sl); out += lines[nb]; out += block; out += lines.subList(el + 2, lines.size) }
    // Numbers belong to the place, not to the text that moved.
    for (p in minOf(sl, nb)..maxOf(el, nb)) {
        val op = NUM_START.find(lines[p])?.value; val np = NUM_START.find(out[p])?.value
        if (op != null && np != null && op != np) out[p] = op + out[p].substring(np.length)
    }
    val d = if (up) -1 else 1
    fun offsetOf(line: Int, col: Int): Int {
        val moved = lines[line]; val now = out[line + d]
        val po = NUM_START.find(moved)?.value?.length ?: 0; val pn = NUM_START.find(now)?.value?.length ?: 0
        val c = (if (po > 0 && pn > 0) maxOf(col - po, 0) + pn else col).coerceAtMost(now.length)
        var off = 0
        for (i in 0 until line + d) off += out[i].length + 1
        return off + c
    }
    return TextEdit(out.joinToString("\n"), offsetOf(sl, sc), offsetOf(el, ec))
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Checklists
// ---------------------------------------------------------------------------------------------------------------------------------

private val CHECK_RE = Regex("^- \\[([ x])\\] ")

fun isCheckLine(line: String) = CHECK_RE.containsMatchIn(line)
fun isTicked(line: String) = CHECK_RE.find(line)?.groupValues?.get(1) == "x"

/** How many checklist items the text has, and how many of them are ticked. */
fun checklistCounts(text: String): Pair<Int, Int> {
    val all = text.lines(); val code = codeLineStates(all)
    val items = all.filterIndexed { i, l -> code[i] == CodeLine.NONE && isCheckLine(l) }   // a "- [ ]" inside a code block is code, not a task
    return items.size to items.count { isTicked(it) }
}

enum class CheckAction { TickedToBottom, ClearTicked, UntickAll, TickAll }

/**
 * Tidies the checklist the cursor is in (a run of checklist lines with nothing between them). When the cursor is not in a checklist it tidies
 * every checklist in the text. Null when nothing would change. The cursor ends up at the start of the first list that was tidied.
 */
fun applyChecklist(text: String, cursor: Int, action: CheckAction): TextEdit? {
    val lines = text.split("\n").toMutableList()
    val blocks = mutableListOf<IntRange>(); var i = 0
    val code = codeLineStates(lines)
    fun task(n: Int) = code[n] == CodeLine.NONE && isCheckLine(lines[n])   // code is never tidied
    while (i < lines.size) {
        if (task(i)) { var j = i; while (j + 1 < lines.size && task(j + 1)) j++; blocks += i..j; i = j + 1 } else i++
    }
    if (blocks.isEmpty()) return null
    val cur = text.substring(0, cursor.coerceIn(0, text.length)).count { it == '\n' }
    val targets = blocks.firstOrNull { cur in it }?.let { listOf(it) } ?: blocks
    for (r in targets.reversed()) {
        val part = lines.subList(r.first, r.last + 1).toList()
        val replaced = when (action) {
            CheckAction.TickedToBottom -> part.filter { !isTicked(it) } + part.filter { isTicked(it) }
            CheckAction.ClearTicked -> part.filter { !isTicked(it) }
            CheckAction.UntickAll -> part.map { it.replaceFirst("- [x] ", "- [ ] ") }
            CheckAction.TickAll -> part.map { it.replaceFirst("- [ ] ", "- [x] ") }
        }
        if (replaced == part) continue
        repeat(part.size) { lines.removeAt(r.first) }
        lines.addAll(r.first, replaced)
    }
    val out = lines.joinToString("\n")
    if (out == text) return null
    val at = lines.take(targets.first().first).sumOf { it.length + 1 }.coerceAtMost(out.length)
    return TextEdit(out, at, at)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Find and replace
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * Where [query] occurs in the saved text [original] and can also be seen, whole, in the [shown] text (the saved text with its hidden marks taken away;
 * [toShown] says where a saved position lands in it). Matches that sit inside hidden marks, like a link's address or a color code, or that a mark
 * cuts in two, are left out, so replacing never touches what the page does not show. Same matching as findMatches: no capitals needed, no overlaps.
 */
fun visibleOccurrences(original: String, query: String, toShown: (Int) -> Int, shown: String): List<IntRange> {
    val q = query.trim()
    if (q.isEmpty()) return emptyList()
    val out = ArrayList<IntRange>(); var i = 0
    while (i <= original.length - q.length) {
        if (original.regionMatches(i, q, 0, q.length, ignoreCase = true)) {
            val ts = toShown(i); val te = toShown(i + q.length)
            if (ts >= 0 && te <= shown.length && te - ts == q.length && shown.regionMatches(ts, q, 0, q.length, ignoreCase = true)) out += i until i + q.length
            i += q.length
        } else i++
    }
    return out
}

/** [text] with every range swapped for [with]. */
fun replaceRanges(text: String, ranges: List<IntRange>, with: String): String {
    val sb = StringBuilder(text)
    for (r in ranges.sortedByDescending { it.first }) sb.replace(r.first, r.last + 1, with)
    return sb.toString()
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Font sizes
// ---------------------------------------------------------------------------------------------------------------------------------

/** The sizes the size list offers, like Samsung Notes: every size from 6 to 30, then every second one up to 48, then every fourth up to 64. */
val FONT_SIZES: List<Int> = (6..30).toList() + (32..48 step 2) + (52..64 step 4)

// ---------------------------------------------------------------------------------------------------------------------------------
// Font colors: typed or pasted, and remembered
// ---------------------------------------------------------------------------------------------------------------------------------

private val HEX_RE = Regex("^(?:#|0x)?([0-9a-f]{6})$")
private val SHORT_HEX_RE = Regex("^#([0-9a-f]{3})$")
private val RGB_RE = Regex("^(?:rgb\\s*\\(\\s*)?(\\d{1,3})\\s*[,\\s]\\s*(\\d{1,3})\\s*[,\\s]\\s*(\\d{1,3})\\s*\\)?$")

/**
 * A color typed or pasted in the usual ways, as the six hex digits in small letters ("ff8800"), or null when it is not one. Hex: "#ff8800", "ff8800", "0xff8800",
 * or the short "#f80" (that one needs its #, so a plain 255 is never taken for a color). RGB: "rgb(255, 136, 0)", "255, 136, 0" or "255 136 0", each number 0 to 255.
 */
fun parseColorText(raw: String): String? {
    val s = raw.trim().lowercase()
    HEX_RE.matchEntire(s)?.let { return it.groupValues[1] }
    SHORT_HEX_RE.matchEntire(s)?.let { m -> return m.groupValues[1].map { "$it$it" }.joinToString("") }
    RGB_RE.matchEntire(s)?.let { m ->
        val v = m.groupValues.drop(1).map { it.toInt() }
        if (v.all { it in 0..255 }) return "%02x%02x%02x".format(v[0], v[1], v[2])
    }
    return null
}

fun hexToRgb(hex: String): Int = hex.toIntOrNull(16) ?: 0
fun rgbToHex(rgb: Int): String = "%06x".format(rgb and 0xFFFFFF)
private fun isHex6(s: String) = s.length == 6 && s.all { it in '0'..'9' || it in 'a'..'f' }

/** The most colors kept in the Recent row of the font color panel. */
const val MAX_RECENT_COLORS = 6

/** The saved Recent colors (one per line) back into a list; anything that is not six hex digits is dropped. */
fun parseRecentColors(stored: String?): List<String> =
    (stored ?: "").lines().map { it.trim().lowercase() }.filter { isHex6(it) }.distinct().take(MAX_RECENT_COLORS)

fun encodeRecentColors(list: List<String>): String = list.joinToString("\n")

/** [hex] put at the front of [list]; one already there moves up instead of repeating, the list is cut to [max], and something that is not a color is ignored. */
fun addRecentColor(list: List<String>, hex: String, max: Int = MAX_RECENT_COLORS): List<String> {
    val h = hex.trim().lowercase()
    if (!isHex6(h)) return list
    return (listOf(h) + list.filterNot { it == h }).take(max)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Lists, headings and quotes on every selected line
// ---------------------------------------------------------------------------------------------------------------------------------

private val MARK_PREFIXES = listOf("## ", "# ", "> ", "- [x] ", "- [ ] ", "- ")
private val NUMBER_MARK = Regex("^\\d+\\. ")

/**
 * Puts [prefix] ("- ", "1. ", "- [ ] ", "> ", "# " or "## ") on the line the cursor is on, or on every line the selection touches. If all of those lines already
 * have it, it is taken off them instead; otherwise every line gets it (a line with another mark, such as a bullet, is switched to it, and a line already
 * ticked or numbered keeps what it has). "1. " numbers the lines one, two, three. Blank lines in a selection and the lines of a code block are left alone.
 * A selection that ends right at the start of a line does not count that line. The selection stays on the same text, so the button can be tapped again to undo.
 */
fun toggleLines(text: String, selStart: Int, selEnd: Int, prefix: String): TextEdit {
    val a = minOf(selStart, selEnd).coerceIn(0, text.length); var b = maxOf(selStart, selEnd).coerceIn(0, text.length)
    if (b > a && b > 0 && text[b - 1] == '\n') b -= 1
    val first = text.lastIndexOf('\n', a - 1) + 1
    val lines = ArrayList<IntRange>()   // old start until old end, per line
    var at = first
    while (at <= text.length) {
        val e = text.indexOf('\n', at).let { if (it < 0) text.length else it }
        lines.add(at until e)
        if (e >= b) break
        at = e + 1
    }
    val states = codeLineStates(text.split("\n"))
    val firstIndex = text.take(first).count { it == '\n' }
    val single = lines.size == 1
    val eligible = lines.indices.filter { i -> states.getOrElse(firstIndex + i) { CodeLine.NONE } == CodeLine.NONE && (single || text.substring(lines[i].first, lines[i].last + 1).isNotBlank()) }
    if (eligible.isEmpty()) return TextEdit(text, a, b)
    fun markOf(line: String) = MARK_PREFIXES.firstOrNull { line.startsWith(it) } ?: NUMBER_MARK.find(line)?.value
    fun has(line: String): Boolean { val m = markOf(line); return if (prefix == "1. ") m != null && m[0].isDigit() else if (prefix == "- [ ] ") m == "- [ ] " || m == "- [x] " else m == prefix }
    val taking = eligible.all { has(text.substring(lines[it].first, lines[it].last + 1)) }
    val out = StringBuilder(); val delta = IntArray(lines.size)
    var copied = 0; var number = 1
    for (i in eligible) {
        val r = lines[i]; val line = text.substring(r.first, r.last + 1); val mark = markOf(line)
        val body = if (mark != null) line.substring(mark.length) else line
        val now = when {
            taking -> body
            prefix == "1. " -> "${number++}. $body"
            has(line) -> line
            else -> prefix + body
        }
        out.append(text, copied, r.first).append(now); copied = r.last + 1
        delta[i] = now.length - line.length
    }
    out.append(text, copied, text.length)
    // A selection that starts at the start of a line keeps the new mark inside it; a cursor there ends up after the mark, where typing goes on.
    fun map(p: Int, keepLineStart: Boolean = false): Int {
        var cum = 0
        for (i in lines.indices) {
            val r = lines[i]
            if (p > r.last + 1) cum += delta[i]
            else if (p >= r.first) return if (keepLineStart && p == r.first) p + cum else (p + cum + delta[i]).coerceAtLeast(r.first + cum)
        }
        return p + cum
    }
    val end = maxOf(selStart, selEnd).coerceIn(0, text.length)
    return TextEdit(out.toString(), map(a, keepLineStart = a < end), maxOf(map(end), map(a, keepLineStart = a < end)))
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Quick tools: the lines the cursor or selection touches
// ---------------------------------------------------------------------------------------------------------------------------------

/** The lines a selection touches, as the offset where the first starts and where the last ends (no line break). One that ends right at the start of a line leaves that line out. */
private fun lineBlock(text: String, selStart: Int, selEnd: Int): IntRange {
    val a = minOf(selStart, selEnd).coerceIn(0, text.length); var b = maxOf(selStart, selEnd).coerceIn(0, text.length)
    if (b > a && text[b - 1] == '\n') b -= 1
    val start = text.lastIndexOf('\n', a - 1) + 1
    val end = text.indexOf('\n', b).let { if (it < 0) text.length else it }
    return start until end   // an empty line is an empty range that still says where it is (first = start, last = start - 1)
}

/** A copy of the line (or of every selected line) right under it; the selection moves onto the copy, so tapping again copies the copy. */
fun duplicateLines(text: String, selStart: Int, selEnd: Int): TextEdit {
    val r = lineBlock(text, selStart, selEnd); val block = text.substring(r.first, r.last + 1)
    val shift = block.length + 1
    val a = minOf(selStart, selEnd).coerceIn(0, text.length); val b = maxOf(selStart, selEnd).coerceIn(0, text.length)
    return TextEdit(text.substring(0, r.last + 1) + "\n" + block + text.substring(r.last + 1), a + shift, b + shift)
}

/** Takes away the line (or every selected line) with its line break; the cursor goes to the start of what came next. Null when there is no text. */
fun deleteLines(text: String, selStart: Int, selEnd: Int): TextEdit? {
    if (text.isEmpty()) return null
    val r = lineBlock(text, selStart, selEnd)
    var from = r.first; var to = r.last + 1
    if (to < text.length) to += 1 else if (from > 0) from -= 1   // the last line takes the break before it instead
    val out = text.removeRange(from, to)
    val at = from.coerceAtMost(out.length)
    return TextEdit(out, at, at)
}

/**
 * Sorts the selected lines (two or more) A to Z or Z to A, by their words and not by their marks, capitals ignored, so "- [ ] b" comes after "- [ ] a".
 * A numbered list is numbered again afterwards. Null when fewer than two lines are selected or the order does not change.
 */
fun sortLines(text: String, selStart: Int, selEnd: Int, ascending: Boolean): TextEdit? {
    val r = lineBlock(text, selStart, selEnd); val block = text.substring(r.first, r.last + 1)
    val lines = block.split("\n"); if (lines.size < 2) return null
    fun key(l: String) = l.replace(LINE_PREFIX_RE, "").replace(LINE_TAGS, "").lowercase()
    var sorted = lines.sortedWith(compareBy<String> { key(it) }.let { if (ascending) it else it.reversed() })
    if (lines.all { NUM_START.containsMatchIn(it) }) sorted = sorted.mapIndexed { i, l -> "${i + 1}. " + l.replaceFirst(NUM_START, "") }
    if (sorted == lines) return null
    val joined = sorted.joinToString("\n")
    return TextEdit(text.substring(0, r.first) + joined + text.substring(r.last + 1), r.first, r.first + joined.length)
}

/** Removes the empty lines of the selected lines, or of the whole text when nothing is selected. Null when there are none. */
fun removeBlankLines(text: String, selStart: Int, selEnd: Int): TextEdit? {
    val whole = selStart == selEnd
    val r = if (whole) 0 until text.length else lineBlock(text, selStart, selEnd)
    val block = text.substring(r.first, r.last + 1)
    val kept = block.split("\n").filter { it.isNotBlank() }.joinToString("\n")
    if (kept == block) return null
    val out = text.substring(0, r.first) + kept + text.substring(r.last + 1)
    return if (whole) TextEdit(out, 0.coerceAtMost(out.length), 0.coerceAtMost(out.length)) else TextEdit(out, r.first, r.first + kept.length)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Quick tools: the selected words
// ---------------------------------------------------------------------------------------------------------------------------------

enum class CaseChange { Upper, Lower, Title, Sentence }

// What is saved as codes and is not words: layout and color tags ({c:ff0000|, {i:2}) and the address of a link.
private val HIDDEN_CODES = Regex("\\{[a-z]+:[^}|]*[|}]|\\]\\([^)]*\\)")

/**
 * The selected text in capitals, in small letters, or with a capital on every word. Colors, indents and link addresses are not touched, so the page
 * looks the same afterwards. Null when nothing is selected or nothing changes.
 */
fun changeCase(text: String, selStart: Int, selEnd: Int, how: CaseChange): TextEdit? {
    val a = minOf(selStart, selEnd).coerceIn(0, text.length); val b = maxOf(selStart, selEnd).coerceIn(0, text.length)
    if (a == b) return null
    val sel = text.substring(a, b)
    val hidden = BooleanArray(sel.length).also { h -> HIDDEN_CODES.findAll(sel).forEach { m -> for (i in m.range) h[i] = true } }
    val out = StringBuilder(); var startOfWord = a == 0 || !text[a - 1].isLetterOrDigit()
    // Sentence case: a capital for the first letter after a full stop, ! or ?, or after a line break, small letters otherwise.
    val before = text.substring(0, a).trimEnd(' ', '\t'); var sentence = before.isEmpty() || before.last() in ".!?\n"
    for (i in sel.indices) {
        val c = sel[i]
        if (hidden[i]) { out.append(c); startOfWord = false; continue }
        out.append(when (how) {
            CaseChange.Upper -> c.uppercaseChar()
            CaseChange.Lower -> c.lowercaseChar()
            CaseChange.Title -> if (startOfWord) c.uppercaseChar() else c.lowercaseChar()
            CaseChange.Sentence -> if (c.isLetter()) { val r = if (sentence) c.uppercaseChar() else c.lowercaseChar(); sentence = false; r } else { if (c == '.' || c == '!' || c == '?' || c == '\n') sentence = true; c }
        })
        startOfWord = !c.isLetterOrDigit() && c != '\''
    }
    if (out.toString() == sel) return null
    return TextEdit(text.substring(0, a) + out + text.substring(b), a, b)
}

/** How many words, characters and lines a text has, counting only what is shown (no marks); [say] is the sentence for a message. */
data class TextStats(val words: Int, val characters: Int, val lines: Int) {
    fun say(): String = "${plural(words, "word")} · ${plural(characters, "character")} · ${plural(lines, "line")}"
    private fun plural(n: Int, w: String) = if (n == 1) "1 $w" else "$n ${w}s"
}

fun textStats(text: String): TextStats {
    val shown = plainText("", text)
    val words = shown.split(Regex("\\s+")).count { w -> w.any { it.isLetterOrDigit() } }
    val lines = shown.lines().count { it.isNotBlank() }
    return TextStats(words, shown.count { !it.isWhitespace() }, lines)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Quick tools: clean-up (clear formatting, join lines, repeated lines, extra spaces)
// ---------------------------------------------------------------------------------------------------------------------------------

private val CLEAR_BOLD = Regex("\\*\\*(.+?)\\*\\*")
private val CLEAR_STRIKE = Regex("~~(.+?)~~")
private val CLEAR_MARK = Regex("==(.+?)==")
private val CLEAR_ITALIC = Regex("\\*(.+?)\\*")
private val SPACE_RUN = Regex("[ \\t]{2,}")

/** Runs [f] on the parts of a line that are not `code`, so what is written inside backticks is never changed. */
private fun outsideCode(line: String, f: (String) -> String): String {
    if ('`' !in line) return f(line)
    val sb = StringBuilder(); var last = 0
    for (m in CODE_SPAN.findAll(line)) { sb.append(f(line.substring(last, m.range.first))); sb.append(m.value); last = m.range.last + 1 }
    return sb.append(f(line.substring(last))).toString()
}

private fun clearMarks(s: String) = SPAN_RE.replace(s) { it.groupValues[2] }.replace(CLEAR_BOLD, "\$1").replace(CLEAR_STRIKE, "\$1").replace(CLEAR_MARK, "\$1").replace(CLEAR_ITALIC, "\$1")

/** Replaces the lines the selection touches (or the whole text when [wholeIfNone] and nothing is selected) with [f] of each line; code blocks are left alone. Null when nothing changes. */
private fun mapLines(text: String, selStart: Int, selEnd: Int, wholeIfNone: Boolean, f: (String) -> String): TextEdit? {
    val whole = wholeIfNone && selStart == selEnd
    val r = if (whole) 0 until text.length else lineBlock(text, selStart, selEnd)
    val block = text.substring(r.first, r.last + 1)
    val first = text.take(r.first).count { it == '\n' }
    val states = codeLineStates(text.split("\n"))
    val out = block.split("\n").mapIndexed { i, l -> if (states.getOrElse(first + i) { CodeLine.NONE } != CodeLine.NONE) l else f(l) }.joinToString("\n")
    if (out == block) return null
    val whole2 = text.substring(0, r.first) + out + text.substring(r.last + 1)
    return if (whole) TextEdit(whole2, 0, 0) else TextEdit(whole2, r.first, r.first + out.length)
}

/** Takes bold, italic, strikethrough, highlight, color, size and underline off the lines the cursor or selection touches. Lists, headings, links and `code` stay as they are. Null when there is none. */
fun clearFormatting(text: String, selStart: Int, selEnd: Int): TextEdit? = mapLines(text, selStart, selEnd, false) { l -> outsideCode(l) { clearMarks(it) } }

/** Takes spaces off the ends of the selected lines (or of every line when nothing is selected) and makes every run of spaces one space. Null when there are none to take. */
fun trimSpaces(text: String, selStart: Int, selEnd: Int): TextEdit? = mapLines(text, selStart, selEnd, true) { l -> outsideCode(l) { it.replace(SPACE_RUN, " ") }.trim() }

/**
 * Joins the selected lines (two or more with words) into one line with single spaces. The list marks and layout tags of the lines after the first are dropped, so a list of
 * items becomes one sentence. Null when fewer than two lines have words.
 */
fun joinLines(text: String, selStart: Int, selEnd: Int): TextEdit? {
    val r = lineBlock(text, selStart, selEnd); val lines = text.substring(r.first, r.last + 1).split("\n").filter { it.isNotBlank() }
    if (lines.size < 2) return null
    val joined = (listOf(lines[0].trimEnd()) + lines.drop(1).map { it.replace(LINE_PREFIX_RE, "").replace(LINE_TAGS, "").trim() }).filter { it.isNotEmpty() }.joinToString(" ")
    return TextEdit(text.substring(0, r.first) + joined + text.substring(r.last + 1), r.first, r.first + joined.length)
}

/** Keeps the first of every line that is written twice (capitals and spaces at the ends ignored) in the selected lines, or in the whole text when nothing is selected; empty lines stay. Null when none repeat. */
fun removeDuplicateLines(text: String, selStart: Int, selEnd: Int): TextEdit? {
    val whole = selStart == selEnd
    val r = if (whole) 0 until text.length else lineBlock(text, selStart, selEnd)
    val block = text.substring(r.first, r.last + 1); val seen = HashSet<String>()
    val kept = block.split("\n").filter { l -> l.isBlank() || seen.add(l.trim().lowercase()) }.joinToString("\n")
    if (kept == block) return null
    val out = text.substring(0, r.first) + kept + text.substring(r.last + 1)
    return if (whole) TextEdit(out, 0, 0) else TextEdit(out, r.first, r.first + kept.length)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// The Growing card pill: which tools it shows
// ---------------------------------------------------------------------------------------------------------------------------------

/** What the Adaptive toolbar (the Growing card) is showing right now. */
enum class PillMode { Tools, Selection, Heading, Task, Link, Code, Tucked, Empty }

/**
 * Picks the pill's tools from what the cursor is on and what you are doing. Typing fast with the keyboard up tucks the pill into a slim handle at the
 * keyboard's edge, unless words are selected or a panel is open (then you are using it). Selected words show text tools; a link under the cursor shows
 * Open, Edit and Remove; a code block shows Copy and Remove; a heading line shows the heading levels; a checklist line shows indent and outdent;
 * a new empty line shows the ways to start a block (heading, checklist, bullets, quote); everything else shows the usual tools.
 */
fun pillMode(prefix: String?, selected: Boolean, keyboard: Boolean, typing: Boolean, panelOpen: Boolean, onLink: Boolean = false, inCode: Boolean = false, emptyLine: Boolean = false): PillMode = when {
    keyboard && typing && !selected && !panelOpen -> PillMode.Tucked
    selected -> PillMode.Selection
    onLink -> PillMode.Link
    inCode -> PillMode.Code
    prefix == "# " || prefix == "## " -> PillMode.Heading
    prefix == "- [ ] " || prefix == "- [x] " -> PillMode.Task
    emptyLine && prefix == null -> PillMode.Empty
    else -> PillMode.Tools
}

/** True when the line the cursor is on has nothing on it but spaces (or nothing at all), so the toolbar can offer ways to start a block. */
fun isBlankLine(text: String, at: Int): Boolean {
    val i = at.coerceIn(0, text.length)
    val start = text.lastIndexOf('\n', i - 1) + 1
    val end = text.indexOf('\n', i).let { if (it < 0) text.length else it }
    return text.substring(start, end).isBlank()
}

/**
 * Where the Expanding chip's open state goes next, as (open, auto). [auto] remembers that the chip opened by itself for a selection, so it closes by itself when the
 * selection ends; a chip you opened with a tap stays until you close it. Typing closes it, unless words are selected or a panel is open (then you are using it).
 */
fun chipNext(open: Boolean, auto: Boolean, selected: Boolean, typing: Boolean, panelOpen: Boolean): Pair<Boolean, Boolean> = when {
    selected && !open -> true to true
    selected -> open to auto
    panelOpen -> open to auto
    auto -> false to false
    typing && open -> false to false
    else -> open to auto
}

/** The text inside the fenced code block the cursor is in (the fence lines count as inside), or null when it is not in one. */
fun codeBlockAt(text: String, pos: Int): String? {
    val lines = text.split("\n"); val st = codeLineStates(lines)
    val i = text.substring(0, pos.coerceIn(0, text.length)).count { it == '\n' }
    if (i >= lines.size || st[i] == CodeLine.NONE) return null
    var a = i; while (a > 0 && st[a] != CodeLine.OPEN) a--
    var b = i; while (b < lines.size - 1 && st[b] != CodeLine.CLOSE) b++
    return lines.subList(a + 1, b).joinToString("\n")
}

fun inCodeBlock(text: String, pos: Int): Boolean = codeBlockAt(text, pos) != null
