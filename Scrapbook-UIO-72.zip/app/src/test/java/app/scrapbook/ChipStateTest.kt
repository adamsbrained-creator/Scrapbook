package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class ChipStateTest {
    @Test fun selectingWordsOpensTheChipByItself() = assertEquals(true to true, chipNext(false, false, true, false, false))
    @Test fun whenTheSelectionEndsAChipThatOpenedByItselfCloses() = assertEquals(false to false, chipNext(true, true, false, false, false))
    @Test fun aChipYouOpenedStaysWhenTheSelectionEnds() = assertEquals(true to false, chipNext(true, false, false, false, false))
    @Test fun aChipYouOpenedStaysOpenOverASelection() = assertEquals(true to false, chipNext(true, false, true, false, false))
    @Test fun typingClosesTheChip() = assertEquals(false to false, chipNext(true, false, false, true, false))
    @Test fun typingKeepsItWhileAPanelIsOpen() = assertEquals(true to false, chipNext(true, false, false, true, true))
    @Test fun typingKeepsItWhileWordsAreSelected() = assertEquals(true to false, chipNext(true, false, true, true, false))
    @Test fun aClosedChipStaysClosedWhileTyping() = assertEquals(false to false, chipNext(false, false, false, true, false))
    @Test fun anOpenPanelKeepsAnAutoOpenedChipOpen() = assertEquals(true to true, chipNext(true, true, false, false, true))
}
