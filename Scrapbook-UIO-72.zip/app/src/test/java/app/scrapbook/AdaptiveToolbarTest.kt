package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AdaptiveToolbarTest {
    @Test fun aNewEmptyLineOffersWaysToStartABlock() = assertEquals(PillMode.Empty, pillMode(null, false, true, false, false, emptyLine = true))
    @Test fun aHeadingOrChecklistLineKeepsItsOwnTools() {
        assertEquals(PillMode.Heading, pillMode("# ", false, true, false, false, emptyLine = true))
        assertEquals(PillMode.Task, pillMode("- [ ] ", false, true, false, false, emptyLine = true))
    }
    @Test fun selectedWordsBeatAnEmptyLine() = assertEquals(PillMode.Selection, pillMode(null, true, true, false, false, emptyLine = true))
    @Test fun typingOnAnEmptyLineStillMinimizes() = assertEquals(PillMode.Tucked, pillMode(null, false, true, true, false, emptyLine = true))
    @Test fun aLineWithTextIsNotEmpty() = assertEquals(PillMode.Tools, pillMode(null, false, true, false, false, emptyLine = false))

    @Test fun anEmptyPageIsABlankLine() = assertTrue(isBlankLine("", 0))
    @Test fun aLineWithWordsIsNotBlank() { assertFalse(isBlankLine("abc", 3)); assertFalse(isBlankLine("a\nb", 0)) }
    @Test fun theLineAfterANewlineIsBlank() = assertTrue(isBlankLine("abc\n", 4))
    @Test fun spacesOnlyCountAsBlank() = assertTrue(isBlankLine("abc\n  \nx", 5))
    @Test fun aBlankLineBetweenTwoLinesIsFound() = assertTrue(isBlankLine("one\n\ntwo", 4))
}
