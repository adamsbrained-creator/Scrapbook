package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PillModeTest {
    @Test fun plainLineShowsTheUsualTools() = assertEquals(PillMode.Tools, pillMode(null, false, false, false, false))
    @Test fun selectedWordsShowTextTools() = assertEquals(PillMode.Selection, pillMode(null, true, true, false, false))
    @Test fun headingLinesShowTheLevels() {
        assertEquals(PillMode.Heading, pillMode("# ", false, false, false, false))
        assertEquals(PillMode.Heading, pillMode("## ", false, true, false, false))
    }
    @Test fun checklistLinesShowIndentTools() {
        assertEquals(PillMode.Task, pillMode("- [ ] ", false, false, false, false))
        assertEquals(PillMode.Task, pillMode("- [x] ", false, true, false, false))
    }
    @Test fun otherListsAndQuotesStayWithTheUsualTools() {
        assertEquals(PillMode.Tools, pillMode("- ", false, false, false, false))
        assertEquals(PillMode.Tools, pillMode("> ", false, false, false, false))
    }
    @Test fun typingFastWithTheKeyboardUpTucksThePill() {
        assertEquals(PillMode.Tucked, pillMode(null, false, true, true, false))
        assertEquals(PillMode.Tucked, pillMode("# ", false, true, true, false))
    }
    @Test fun typingWithoutTheKeyboardDoesNotTuck() = assertEquals(PillMode.Tools, pillMode(null, false, false, true, false))
    @Test fun anOpenPanelOrASelectionKeepsThePillOpen() {
        assertEquals(PillMode.Tools, pillMode(null, false, true, true, true))
        assertEquals(PillMode.Selection, pillMode(null, true, true, true, false))
    }
}

class PillModeLinkCodeTest {
    @Test fun aLinkUnderTheCursorShowsLinkTools() = assertEquals(PillMode.Link, pillMode(null, false, false, false, false, onLink = true))
    @Test fun aCodeBlockShowsCodeTools() = assertEquals(PillMode.Code, pillMode(null, false, true, false, false, inCode = true))
    @Test fun selectedWordsBeatALink() = assertEquals(PillMode.Selection, pillMode(null, true, false, false, false, onLink = true))
    @Test fun typingInsideCodeStillTucks() = assertEquals(PillMode.Tucked, pillMode(null, false, true, true, false, inCode = true))
    @Test fun codeBlockTextIsFoundFromAnyLineOfIt() {
        val t = "intro\n```\na = 1\nb = 2\n```\noutro"
        assertEquals("a = 1\nb = 2", codeBlockAt(t, t.indexOf("b = 2")))
        assertEquals("a = 1\nb = 2", codeBlockAt(t, t.indexOf("```")))
        assertNull(codeBlockAt(t, 2))
        assertNull(codeBlockAt(t, t.indexOf("outro")))
    }
    @Test fun noFenceMeansNoCodeBlock() = assertEquals(false, inCodeBlock("plain\ntext", 3))
}
