package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SongbookTest {
    @Test fun linkLineIsAddedOnceAndFoundAgain() {
        val body = withSongbookLink("Night bus", "Night bus", 12)
        assertEquals("Night bus\n\nSongbook: [Night bus](songbook://song/12)", body)
        assertEquals(body, withSongbookLink(body, "Night bus", 12))
        assertEquals(12L, firstSongbookSong(body)); assertEquals(listOf(12L), songbookSongIds(body))
        assertNull(firstSongbookSong("no link here")); assertNull(firstSongbookSong("```\nsongbook://song/5\n```"))
    }

    @Test fun songOneIsNotSongTwelve() {
        val body = withSongbookLink("x", "x", 12)
        assertEquals(listOf(12L), songbookSongIds(body))
        assertTrue(1L !in songbookSongIds(body))
        assertEquals(body + "\n\nSongbook: [x](songbook://song/1)", withSongbookLink(body, "x", 1))
    }

    @Test fun bracketsInTheTitleDoNotBreakTheLine() {
        assertEquals("Songbook: [A B](songbook://song/3)", songbookLinkLine("A [B]", 3))
        assertEquals("Songbook: [song](songbook://song/3)", songbookLinkLine("  ", 3))
    }

    @Test fun aScrapBecomesSongText() {
        val body = "# Verse 1\n[Em]The last **bus** leaves at ten\n- and I'm *still* here\n> [C]counting every ~~stop~~ stop\n\n\n## Chorus\nSee [the map](https://example.com) now\n- [ ] fix the bridge\n- [x] find a title\n\nSongbook: [Night bus](songbook://song/12)"
        val s = songTextOf(body)
        assertEquals("# Verse 1\n[Em]The last bus leaves at ten\nand I'm still here\n[C]counting every stop stop\n\n# Chorus\nSee the map now", s.text)
        assertEquals(listOf("fix the bridge" to false, "find a title" to true), s.tasks)
    }

    @Test fun chordsAreNotMistakenForLinks() {
        assertEquals("[Em](hold) the line", songTextOf("[Em](hold) the line").text)
        assertEquals("[Am]a [G]b", songTextOf("[Am]a [G]b").text)
    }

    @Test fun tabsGoInACodeBlockAndComeBackOut() {
        val song = "# Intro\ne|--0--2--|\nB|--1--3--|\n\nHello"
        val scrap = scrapTextOf(song)
        assertEquals("# Intro\n```\ne|--0--2--|\nB|--1--3--|\n```\n\nHello", scrap)
        assertEquals(song, songTextOf(scrap).text)
    }

    @Test fun otherAppLinkLinesAreNotLyrics() {
        assertEquals("la la", songTextOf("la la\n\nBinder: [Item](binder://item/abcdef1234)\nSongbook: [x](songbook://song/2)").text)
    }

    @Test fun aSongsTextAndTasksMakeAScrapAndBack() {
        val body = scrapBodyOf("# Verse\n[Em]Hello", listOf("fix it" to false, "done" to true))
        assertEquals("# Verse\n[Em]Hello\n\n- [ ] fix it\n- [x] done", body)
        val back = songTextOf(body)
        assertEquals("# Verse\n[Em]Hello", back.text); assertEquals(listOf("fix it" to false, "done" to true), back.tasks)
    }

    @Test fun keptLinkLinesSurviveATextReplacement() {
        val old = "old text\n\nBinder: [Item](binder://item/abcdef1234)\nSongbook: [Night bus](songbook://song/12)"
        val next = withKeptLinkLines(old, "new text", "Night bus", 12)
        assertEquals("new text\n\nBinder: [Item](binder://item/abcdef1234)\nSongbook: [Night bus](songbook://song/12)", next)
        assertEquals("new text\n\nSongbook: [Night bus](songbook://song/12)", withKeptLinkLines("old text", "new text", "Night bus", 12))
    }

    @Test fun theFingerprintIgnoresTrailingSpacesAndBlankEdges() {
        assertEquals(songSyncKey("a  \nb", emptyList()), songSyncKey("\na\nb\n\n", emptyList()))
        assertFalse(songSyncKey("a", emptyList()) == songSyncKey("a", listOf("t" to false)))
        assertFalse(songSyncKey("a", listOf("t" to false)) == songSyncKey("a", listOf("t" to true)))
        assertEquals(40, songSyncKey("a", emptyList()).length)
    }

    @Test fun decidesWhatEditInScrapbookDoes() {
        assertEquals(SongbookSync.SAME, decideSync("a", "a", null))
        assertEquals(SongbookSync.TAKE_SONG, decideSync("old", "new", "old"))
        assertEquals(SongbookSync.KEEP_SCRAP, decideSync("mine", "old", "old"))
        assertEquals(SongbookSync.CONFLICT, decideSync("mine", "theirs", "old"))
        assertEquals(SongbookSync.CONFLICT, decideSync("mine", "theirs", null))
    }

    @Test fun chordsAboveTheWordsMoveIntoTheWordsAndTheCapoIsApplied() {
        val body = "**Capo 2 fret**\n\n**intro:**\n**Dm                Dm/A       Am  (Fmaj7/A) E**\nThe cigarettes still taste like her,\n**E7                    F**\nAnd there's no straight answer."
        val s = songTextOf(body)
        assertEquals("# intro:\n[Em]The cigarettes [Em/B]still [Bm]taste like [Gmaj7/B][F#]her,\n[F#7]And there's no [G]straight answer.", s.text)
        assertEquals(2, s.capo)
    }

    @Test fun chordLinesWithoutWordsStayChordLines() {
        assertEquals("# riff:\n[Am Fmaj7/A]\n[Dm Dm/A]\n\n[Am Fmaj7/A] (x2)", songTextOf("**riff:**\n**Am Fmaj7/A**\n**Dm Dm/A**\n\n**Am Fmaj7/A (x2)**").text)
    }

    @Test fun moreChordsThanWordsKeepTheChordLineApart() {
        assertEquals("# refrain:\n[F9b5 Em/F D G7/F Em/F Dsus2]\nBurn ~", songTextOf("**refrain:**\n**F9b5  Em/F D G7/F Em/F Dsus2**\nBurn ~").text)
    }

    @Test fun aLoneAWordIsNotAChordLineAndAColonLineIsAHeading() {
        assertEquals("# verse one:\nSomething A\nA", songTextOf("verse one:\nSomething A\nA").text)
        assertEquals(0, songTextOf("la la la").capo)
    }

    @Test fun chordsAreTransposedByTheCapo() {
        assertEquals("Amaj7/C#", transposeChord("Fmaj7/A", 4))
        assertEquals("F#m", transposeChord("Dm", 4))
        assertEquals("Fadd9", transposeChord("FAdd9", 0))
        assertEquals("Em/B", transposeChord("Dm/A", 2))
    }
}
