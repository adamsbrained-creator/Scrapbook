package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// Customize home: every part of the Home page as one row. Drag the handle to move a part, tap the eye to hide or show it.
// The rows are short on purpose: the whole page fits on the screen, so a part can travel from the top to the bottom in one drag.
// What is saved is only the order and which parts are hidden (see HomeLayout.kt); no scrap or box is touched.

private fun iconOf(e: HomeElement) = when (e) {
    HomeElement.Header -> "menu"
    HomeElement.Greeting -> "sparkle"
    HomeElement.Capture -> "edit"
    HomeElement.Continue -> "arrow"
    HomeElement.Sort -> "sort"
    HomeElement.Boxes -> "folder"
    HomeElement.Pinned -> "star"
    HomeElement.Recent -> "clock"
}

private fun slotName(s: HomeSlot): String = when (s) {
    is HomeSlot.Part -> s.element.label
    is HomeSlot.Sec -> s.section.name
}

/**
 * The screen that takes the place of Home while it is being customized. [notes] is the line under each part's name. [onChange] gets every new layout straight away.
 * A part in [withOptions] gets a sliders button on its row; it opens [options], a page of that part's own settings that takes the place of this list until it calls its back button.
 */
@Composable
fun HomeCustomize(
    layout: HomeLayout, notes: Map<HomeElement, String>, onChange: (HomeLayout) -> Unit, onDone: () -> Unit,
    withOptions: Set<HomeElement> = emptySet(), options: @Composable (HomeElement, () -> Unit) -> Unit = { _, _ -> },
    /** Whatever goes under the list of parts (the gestures). */
    footer: @Composable () -> Unit = {},
    /** Whatever goes above the list of parts (the skin card). */
    top: @Composable () -> Unit = {},
    /** Your own sections (see HomeSections.kt): they are listed between the parts, move like them, and open their own edit sheet. */
    sections: List<HomeSection> = emptyList(), onSections: (List<HomeSection>) -> Unit = {}, onEditSection: (String) -> Unit = {},
) {
    val haptics = LocalHaptics.current
    val drag = remember { DragReorder(vertical = true) }
    // Several swaps can happen in one drag event, before the screen has had time to show the first: each one starts from the layout the last one made.
    val live = remember { arrayOf(layout) }
    SideEffect { live[0] = layout }
    fun commit(next: HomeLayout) { live[0] = next; onChange(next) }
    // The rows are the parts and the sections together, in page order. A move can change the order of the parts and the place of the sections at once.
    val liveSec = remember { arrayOf(sections) }
    SideEffect { liveSec[0] = sections }
    val move: (Int, Int) -> Unit = { from, to ->
        val (order, secs) = HomeSections.reorderSlots(live[0].order, liveSec[0], from, to)
        val nextLayout = live[0].copy(order = order)
        if (nextLayout != live[0]) commit(nextLayout)
        if (secs != liveSec[0]) { liveSec[0] = secs; onSections(secs) }
    }
    val slots = HomeSections.slots(layout.order, sections)
    val slotKeys: List<Any> = slots.map { it.key }
    BackHandler { onDone() }
    var page by remember { mutableStateOf<HomeElement?>(null) }
    val open = page
    if (open != null) { options(open) { page = null }; return }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 16.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
            Text("Customize home", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
            Text("Done", Modifier.pressScale(.94f).clip(CircleShape).background(Sb.ink).tap("Done", onDone).padding(horizontal = 22.dp, vertical = 12.dp),
                color = Sb.card, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Text("Hold the handle and drag a part to move it. Tap the eye to hide it or bring it back." + if (withOptions.isNotEmpty()) " Parts with a sliders button have their own options." else "", Modifier.padding(horizontal = 24.dp, vertical = 10.dp), fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute)

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp), userScrollEnabled = drag.active == null) {
            item(key = "top") { top() }
            items(slots, key = { it.key }) { slot ->
                val i = slots.indexOf(slot)
                val dragging = drag.active == slot.key
                val semanticsMove = Modifier.semantics {
                    customActions = listOf(
                        CustomAccessibilityAction("Move ${slotName(slot)} up") { if (i > 0) { haptics.tick(); move(i, i - 1); true } else false },
                        CustomAccessibilityAction("Move ${slotName(slot)} down") { if (i < slots.lastIndex) { haptics.tick(); move(i, i + 1); true } else false },
                    )
                }
                // The row being dragged follows the finger, so it must not also slide to its new place; the others do.
                val rowMod = Modifier.animateItem(placementSpec = if (dragging) null else tween(220)).reorderLayer(drag, slot.key).fillMaxWidth().height(80.dp).padding(vertical = 4.dp).then(semanticsMove)
                when (slot) {
                    is HomeSlot.Sec -> {
                        val sec = slot.section
                        Box(rowMod) {
                            Row(Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)).background(Sb.card).padding(start = 18.dp, end = 4.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                Row(Modifier.weight(1f).tap("Edit ${sec.name}") { onEditSection(sec.id) }, Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                    Ic("layout", 24.dp, Sb.ink)
                                    Column(Modifier.weight(1f)) {
                                        Text(sec.name, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(if (sec.isSmart) "Fills itself · ${sec.layout.label}" else "Your section · ${sec.layout.label} · " + (if (sec.refs.size == 1) "1 item" else "${sec.refs.size} items"), fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Edit ${sec.name}") { onEditSection(sec.id) }, Alignment.Center) { Ic("sliders", 22.dp, Sb.ink) }
                                Box(Modifier.size(48.dp).reorderGesture(drag, slot.key, slotKeys, true, move, handle = true).semantics { contentDescription = "Drag ${sec.name}" }, Alignment.Center) {
                                    Ic("grip", 22.dp, Sb.mute)
                                }
                            }
                        }
                    }
                    is HomeSlot.Part -> {
                        val el = slot.element
                        val hidden = layout.isHidden(el)
                        Box(rowMod) {
                    Row(Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)).background(Sb.card).padding(start = 18.dp, end = 4.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        Row(Modifier.weight(1f).alpha(if (hidden) .4f else 1f).then(if (el in withOptions) Modifier.tap("${el.label} options") { page = el } else Modifier), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                            Ic(iconOf(el), 24.dp, Sb.ink)
                            Column(Modifier.weight(1f)) {
                                Text(el.label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (hidden) "Hidden" else notes[el].orEmpty(), fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (el in withOptions) Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("${el.label} options") { page = el }, Alignment.Center) { Ic("sliders", 22.dp, Sb.ink) }
                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon(if (hidden) "Show ${el.label}" else "Hide ${el.label}") {
                            haptics.toggle(hidden); commit(live[0].withHidden(el, !hidden))
                        }, Alignment.Center) { Ic(if (hidden) "eyeoff" else "eye", 22.dp, if (hidden) Sb.mute else Sb.ink) }
                        Box(Modifier.size(48.dp).reorderGesture(drag, slot.key, slotKeys, true, move, handle = true).semantics { contentDescription = "Drag ${el.label}" }, Alignment.Center) {
                            Ic("grip", 22.dp, Sb.mute)
                        }
                    }
                        }
                    }
                }
            }
            if (layout != HomeLayout.Default) item(key = "reset") {
                Text("Back to the usual order", Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f))
                    .tap("Put every part back where it was and show them all") { haptics.confirm(); commit(HomeLayout.Default) }.padding(vertical = 16.dp),
                    color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            }
            item(key = "footer") { footer() }
        }
    }
}
