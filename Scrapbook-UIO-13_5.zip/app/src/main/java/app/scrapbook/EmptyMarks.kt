package app.scrapbook

/** A color / size / underline span with nothing inside it: {c:34c759|}. */
private val EMPTY_SPAN = Regex("\\{(?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2}\\|\\}")

/**
 * When the last letter inside bold, a highlight, a color and so on is deleted, the marks around it have nothing left to wrap and would show up as
 * plain symbols ("****", "{c:34c759|}"). This takes off every empty wrapper that sits exactly at the cursor, from the inside out, so a nested
 * "=={c:34c759|}==" goes away completely. Returns the new text and cursor, or null when there is nothing to take off.
 */
fun dropEmptyMarks(text: String, cursor: Int): Pair<String, Int>? {
    var s = text; var p = cursor; var changed = false
    var guard = 0
    while (guard++ < 12) {
        if (p < 0 || p > s.length) break
        // {c:..|} with the cursor in front of its closing brace.
        val span = EMPTY_SPAN.findAll(s).firstOrNull { it.range.last == p }
        if (span != null) { s = s.removeRange(span.range.first, span.range.last + 1); p = span.range.first; changed = true; continue }
        // ****, ~~~~ and ==== with the cursor in the middle.
        val pair = listOf("****", "~~~~", "====").firstOrNull { p >= 2 && s.startsWith(it, p - 2) }
        if (pair != null) { s = s.removeRange(p - 2, p + 2); p -= 2; changed = true; continue }
        // An empty italic pair, *|*, not part of a longer run of stars.
        if (p >= 1 && p < s.length && s[p - 1] == '*' && s[p] == '*' && (p < 2 || s[p - 2] != '*') && (p + 1 >= s.length || s[p + 1] != '*')) {
            s = s.removeRange(p - 1, p + 1); p -= 1; changed = true; continue
        }
        break
    }
    return if (changed) s to p else null
}
