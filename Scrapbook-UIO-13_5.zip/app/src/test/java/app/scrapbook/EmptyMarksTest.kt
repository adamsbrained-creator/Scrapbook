package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class EmptyMarksTest {
    @Test fun emptyBoldGoesAway() = assertEquals("" to 0, dropEmptyMarks("****", 2))
    @Test fun emptyBoldKeepsTheRestOfTheText() = assertEquals("a b" to 2, dropEmptyMarks("a ****b", 4))
    @Test fun colorInsideHighlight() = assertEquals("" to 0, dropEmptyMarks("=={c:34c759|}==", 12))
    @Test fun highlightInsideColor() = assertEquals("" to 0, dropEmptyMarks("{c:34c759|====}", 12))
    @Test fun colorSizeUnderline() = assertEquals("x" to 1, dropEmptyMarks("x{c:ff0000 s:20 u|}", 18))
    @Test fun strikeAndItalic() { assertEquals("" to 0, dropEmptyMarks("~~~~", 2)); assertEquals("" to 0, dropEmptyMarks("**", 1)) }
    @Test fun cursorNotThereLeavesItAlone() { assertNull(dropEmptyMarks("****", 0)); assertNull(dropEmptyMarks("**a**", 3)) }
    @Test fun spanWithTextIsKept() = assertNull(dropEmptyMarks("{c:34c759|a}", 11))
    @Test fun threeStarsIsNotAnEmptyItalic() = assertNull(dropEmptyMarks("***", 1))
}
