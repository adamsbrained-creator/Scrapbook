package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlin.math.abs
import kotlin.math.roundToInt

// Your own sections on Home (see HomeSections.kt for the rules): a row of shortcuts to scraps and boxes, made by dragging a thing out of Home and letting go.
// Each section has a name, one of four layouts (cards, chips, rows, grid) and whatever you put in it. Hold its title for Move up / Move down / Edit / Delete.
// Things inside a section can be held and carried too: to another section, to a box (a scrap is filed there), or into the open (a new section).

/** What a section can do, given by Home. Every function works on the newest saved sections. */
class SectionOps(
    val edit: (String) -> Unit,
    val move: (String, Int) -> Unit,
    val delete: (String) -> Unit,
    val rename: (String, String) -> Unit,
    val layout: (String, SectionLayout) -> Unit,
    val toggle: (String, SectionRef) -> Unit,
    val remove: (String, SectionRef) -> Unit,
    val newWith: (SectionRef) -> Unit,
    /** Gives a section a rule (or none), a new title if one is given, and, when it stops being smart, the things it keeps (all in one change, so nothing is lost). */
    val rule: (String, SectionRule?, String?, List<SectionRef>?) -> Unit,
    /** Replaces what a card section is (its text or its scope; see SectionCard). */
    val card: (String, SectionCard) -> Unit,
    /** Adds a new section at the end of the page and opens it for editing: a card of the given kind, or null for an empty section of shortcuts. */
    val add: (SectionCard?) -> Unit,
    /** Shows or hides the name line of a section on Home. */
    val showTitle: (String, Boolean) -> Unit,
    /** Gives a section the size [width] percent by [height] dp (0 is automatic). */
    val size: (String, Int, Int) -> Unit,
    /** Starts resizing a section on Home (its corner can be dragged), or ends it with null. */
    val resize: (String?) -> Unit,
    /** Sets the space below a section in dp; a negative number makes it automatic. */
    val space: (String, Int) -> Unit,
)

/** Everything a section needs to draw itself and to be held. */
class HomeEnv(
    val vm: ArchiveViewModel, val nav: NavController, val items: List<Item>, val shelves: List<Shelf>, val counts: Map<String, Int>,
    val inboxHidden: Boolean, val colorOf: (String) -> Color, val drag: HomeDrag, val actions: HomeActions, val ops: SectionOps, val preview: Boolean,
    /** The id of the section whose corner is being dragged, or null. */
    val resizing: String? = null,
)

/** One thing in a section, looked up again each time so a renamed box, a deleted scrap or a hidden Inbox is never shown wrongly. */
private class Entry(val ref: SectionRef, val scrap: Item?, val label: String, val dot: Color?, val count: Int) {
    val token: String get() = ref.token
}

private fun manualEntries(s: HomeSection, env: HomeEnv, byUid: Map<String, Item>): List<Entry> = s.refs.mapNotNull { r ->
    if (r.box) {
        if (r.key == "Inbox") { if (env.inboxHidden) null else Entry(r, null, "Inbox", env.colorOf("Inbox"), env.counts["Inbox"] ?: 0) }
        else env.shelves.firstOrNull { it.name == r.key }?.let { sh -> Entry(r, null, sh.label, TAB_COLORS[sh.color % TAB_COLORS.size], env.counts[sh.name] ?: 0) }
    } else byUid[r.key]?.let { n -> Entry(r, n, n.displayTitle, null, 0) }
}

/** What a section shows: what is in it, or, for a smart one, what its rule finds now. */
private fun entriesOf(s: HomeSection, env: HomeEnv, byUid: Map<String, Item>): List<Entry> {
    val rule = s.rule ?: return manualEntries(s, env, byUid)
    val boxes: Set<String> = if (rule.kind == SectionRule.BOX) (if (rule.arg == "Inbox") setOf("Inbox") else env.shelves.subtreeKeys(rule.arg).toSet()) else emptySet()
    return HomeSections.smartScraps(rule, env.items, boxes, System.currentTimeMillis()).map { n -> Entry(SectionRef(false, n.uid), n, n.displayTitle, null, 0) }
}

/** What a new smart section is called until you rename it. */
internal fun ruleTitle(r: SectionRule, shelves: List<Shelf>): String = when (r.kind) {
    SectionRule.TAG -> "#" + r.arg
    SectionRule.BOX -> if (r.arg == "Inbox") "Inbox" else shelves.labelOf(r.arg)
    else -> "This week"
}

private fun ruleSummary(r: SectionRule, shelves: List<Shelf>): String = when (r.kind) {
    SectionRule.TAG -> "Scraps tagged #${r.arg}"
    SectionRule.BOX -> "Scraps in ${ruleTitle(r, shelves)}"
    else -> "Scraps edited this week"
}

private fun ruleIcon(r: SectionRule): String = when (r.kind) {
    SectionRule.TAG -> "tag"
    SectionRule.BOX -> "folder"
    else -> "clock"
}

private fun countText(n: Int) = if (n == 1) "1 scrap" else "$n scraps"

@Composable
private fun EntryChip(e: Entry, onClick: () -> Unit) {
    Row(Modifier.pressScale(.95f).height(48.dp).homeCard(24.dp).tap("Open ${e.label}", onClick).padding(horizontal = 20.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        if (e.dot != null) Box(Modifier.size(14.dp).clip(CircleShape).background(e.dot)) else Ic("page", 18.dp, Sb.mute)
        Text(e.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
        if (e.scrap == null) Text("${e.count}", fontSize = 15.sp, color = Sb.mute)
    }
}

/** A card the size of a Pinned card: a scrap shows its date and the start of its text, a box its color tab and how many scraps are in it. */
@Composable
private fun EntryCard(e: Entry, preview: Boolean, modifier: Modifier, height: Dp = 136.dp, onClick: () -> Unit) {
    val n = e.scrap
    val lines = ((height.value - 96f) / 18f).toInt().coerceIn(3, 30)
    Column(modifier.pressScale(.96f).height(height).homeCard(28.dp).tap("Open ${e.label}", onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (e.dot != null) { Box(Modifier.size(12.dp).clip(CircleShape).background(e.dot)); Spacer(Modifier.width(8.dp)) }
            Text(e.label, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n != null && n.pinned) { Spacer(Modifier.width(6.dp)); Ic("star", 14.dp, Color(0xFFFFB400)) }
        }
        if (n != null) {
            Text(fmtDate(n.savedAt, true), fontSize = 12.sp, color = Sb.mute)
            if (preview) Text(remember(n.title, n.body) { previewHead(n.title, n.body) }, Modifier.padding(top = 6.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = lines, overflow = TextOverflow.Ellipsis)
        } else {
            Text("Box", fontSize = 12.sp, color = Sb.mute)
            Text(countText(e.count), Modifier.padding(top = 6.dp), fontSize = 14.sp, color = Sb.mute)
        }
    }
}

/** A full-width row for a box (a scrap uses the normal scrap card). */
@Composable
private fun BoxRow(e: Entry, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().homeCard(28.dp).tap("Open ${e.label}", onClick).padding(horizontal = 20.dp, vertical = 18.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(e.dot ?: TAB_GRAY))
        Text(e.label, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(countText(e.count), fontSize = 14.sp, color = Sb.mute)
    }
}

/** The title row of a section: hold the title for Edit / Move up / Move down / Delete, tap Edit to change the section. Every kind of section has one. */
@Composable
private fun SectionTitle(s: HomeSection, env: HomeEnv) {
    val ops = env.ops
    val source = "section:${s.id}"
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            HoldSlot(env.drag, "head:$source", null, Modifier.weight(1f), menu = { close ->
                PopupItem("Edit section", "edit") { close(); ops.edit(s.id) }
                PopupItem("Resize", "expand") { close(); ops.resize(s.id) }
                PopupItem("Move up", "up") { close(); ops.move(s.id, -1) }
                PopupItem("Move down", "down") { close(); ops.move(s.id, 1) }
                PopupDivider()
                PopupItem("Delete section", "trash", tint = Sb.danger) { close(); ops.delete(s.id) }
            }) {
                Text(s.name, Modifier.asHeading(), fontSize = 18.sp, fontWeight = FontWeight.Medium, fontFamily = headFont(), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(if (s.isSmart) "Auto · Edit" else "Edit", Modifier.tap("Edit ${s.name}") { ops.edit(s.id) }.padding(vertical = 6.dp), fontSize = 14.sp, color = Sb.mute)
        }
}

/** The boxes a scope names: the box and every box inside it. Empty when the scope is not a box. */
private fun boxKeysOf(rule: SectionRule?, env: HomeEnv): Set<String> =
    if (rule != null && rule.kind == SectionRule.BOX) (if (rule.arg == "Inbox") setOf("Inbox") else env.shelves.subtreeKeys(rule.arg).toSet()) else emptySet()

// ----- Card sections (see SectionCard): a block of Home that is one thing of its own. -----

@Composable
private fun EmptyCardNote(text: String, s: HomeSection, env: HomeEnv, sz: SizeInfo) {
    Text(text, sz.outer.homeCard(28.dp).tap("Edit ${s.name}") { env.ops.edit(s.id) }.padding(20.dp), fontSize = 15.sp, color = Sb.mute)
}

@Composable
private fun TextCardBody(s: HomeSection, card: SectionCard, env: HomeEnv, sz: SizeInfo) {
    val scroll = rememberScrollState()
    if (card.text.isBlank()) EmptyCardNote("Nothing written yet. Tap to write something.", s, env, sz)
    else Text(card.text, sz.outer.homeCard(28.dp).tap("Edit ${s.name}") { env.ops.edit(s.id) }.then(if (sz.fixedH) Modifier.verticalScroll(scroll) else Modifier).padding(20.dp),
        fontSize = 16.sp, lineHeight = 23.sp, maxLines = if (sz.fixedH) Int.MAX_VALUE else 12, overflow = TextOverflow.Ellipsis)
}

@Composable
private fun QuoteCardBody(s: HomeSection, card: SectionCard, env: HomeEnv, sz: SizeInfo) {
    val lines = card.lines
    val today = remember { System.currentTimeMillis() / 86_400_000L }
    var shift by remember(s.id) { mutableIntStateOf(0) }
    val line = HomeSections.quoteOf(lines, today + shift)
    if (line.isEmpty()) EmptyCardNote("No quotes yet. Tap to add some, one on each line.", s, env, sz)
    else Column(sz.outer.homeCard(28.dp)
        .tap(if (lines.size > 1) "Show another quote" else "Edit ${s.name}") { if (lines.size > 1) shift++ else env.ops.edit(s.id) }.padding(horizontal = 24.dp, vertical = 22.dp),
        verticalArrangement = if (sz.fixedH) Arrangement.spacedBy(10.dp, Alignment.CenterVertically) else Arrangement.spacedBy(10.dp)) {
        Text("\u201C$line\u201D", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = sz.quoteSp.sp, lineHeight = (sz.quoteSp * 1.36f).sp)
        if (lines.size > 1) Text("Tap for another", fontSize = 12.sp, color = Sb.mute)
    }
}

@Composable
private fun RandomCardBody(s: HomeSection, card: SectionCard, env: HomeEnv, sz: SizeInfo) {
    val rule = card.scope
    val boxes = remember(rule, env.shelves) { boxKeysOf(rule, env) }
    val pool = remember(env.items, card.arg, boxes) { HomeSections.matching(rule, env.items, boxes, System.currentTimeMillis()) }
    var seed by remember(s.id) { mutableLongStateOf(System.currentTimeMillis()) }
    val pick = HomeSections.pickOne(pool, seed)
    if (pick == null) EmptyCardNote("No scraps to draw from yet. Tap to change which scraps.", s, env, sz)
    else Column(sz.outer.homeCard(28.dp).tap("Open ${pick.displayTitle}") { env.actions.open(pick) }.padding(start = 20.dp, top = 16.dp, bottom = 18.dp, end = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(pick.displayTitle, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Another", Modifier.clip(CircleShape).tap("Draw another scrap") { seed = System.nanoTime() }.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
        }
        Text(LocalShelves.current.displayName(pick.collection) + " \u00B7 " + fmtDate(pick.savedAt, true), Modifier.padding(end = 12.dp), fontSize = 12.sp, color = Sb.mute)
        if (env.preview) Text(remember(pick.title, pick.body) { previewHead(pick.title, pick.body) }, Modifier.padding(top = 6.dp, end = 12.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = if (sz.fixedH) ((sz.h - 110) / 18).coerceIn(3, 40) else 3, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CounterCardBody(s: HomeSection, card: SectionCard, env: HomeEnv, sz: SizeInfo) {
    val rule = card.scope
    val boxes = remember(rule, env.shelves) { boxKeysOf(rule, env) }
    val n = HomeSections.count(rule, env.items, boxes, System.currentTimeMillis())
    val text = HomeSections.counterText(n, rule, if (rule != null && rule.kind == SectionRule.BOX) ruleTitle(rule, env.shelves) else "")
    Column(sz.outer.homeCard(28.dp).tap("$n $text. Edit ${s.name}") { env.ops.edit(s.id) }.padding(horizontal = 24.dp, vertical = 20.dp), verticalArrangement = if (sz.fixedH) Arrangement.Center else Arrangement.Top) {
        Text("$n", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = sz.bigSp.sp, lineHeight = (sz.bigSp * 1.08f).sp)
        Text(text, fontSize = 15.sp, color = Sb.mute)
    }
}

@Composable
private fun ButtonCardBody(s: HomeSection, card: SectionCard, env: HomeEnv, sz: SizeInfo) {
    val acc = LocalSb.current.acc
    // A box that has since been deleted is the Inbox again.
    val dest = card.destination.let { d -> if (d == "Inbox" || env.shelves.any { it.name == d }) d else "Inbox" }
    val destLabel = if (dest == "Inbox") "Inbox" else env.shelves.labelOf(dest)
    fun start() {
        env.vm.pendingShelf = if (dest == "Inbox") null else dest
        env.vm.pendingBody = card.text.ifEmpty { null }
        env.vm.pendingImage = false
        env.vm.pendingRecord = false
        env.nav.navigate("edit/0")
    }
    Row(sz.outer.pressScale(.98f).homeCard(28.dp).tap("New scrap in $destLabel") { start() }.padding(horizontal = 18.dp, vertical = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(acc), Alignment.Center) { Ic("plus", 22.dp, onAccent(acc)) }
        Column(Modifier.weight(1f)) {
            Text("New scrap in $destLabel", fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(card.text.lines().firstOrNull { it.isNotBlank() }?.trim() ?: "Opens a blank scrap", fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** What a card needs to know about the box it is drawn in: whether it is a sized box, and its fixed height in dp (0 if the height is automatic). */
private class SizeInfo(val boxed: Boolean, val h: Int) {
    val fixedH: Boolean get() = boxed && h > 0
    /** The outer shape of a card: as it has always been on the page, or filling the box it was given. */
    val outer: Modifier get() = if (!boxed) Modifier.padding(horizontal = 20.dp).fillMaxWidth() else if (h > 0) Modifier.fillMaxSize() else Modifier.fillMaxWidth()
    /** The size of a counter's number and of a quote's text: bigger in a taller box. */
    val bigSp: Float get() = if (fixedH) (h * .38f).coerceIn(40f, 120f) else 48f
    val quoteSp: Float get() = if (fixedH) (h * .16f).coerceIn(18f, 40f) else 22f
}

/**
 * Changes the space below by [deltaDp] (a negative number takes space away): what it is put on stays where it is, only the height it reports changes, so whatever comes next moves.
 * Put outside the modifiers that report the section's place, so those keep the section's real bounds.
 */
fun Modifier.moreSpaceBelow(deltaDp: Float): Modifier = if (deltaDp == 0f) this else layout { measurable, constraints ->
    val placeable = measurable.measure(constraints)
    layout(placeable.width, (placeable.height + (deltaDp * density).roundToInt()).coerceAtLeast(0)) { placeable.place(0, 0) }
}

/** A dashed frame on top of what it is put on, so the bounds of a section being resized can be seen. */
private fun Modifier.dashedFrame(color: Color): Modifier = drawWithContent {
    drawContent()
    drawRoundRect(color, cornerRadius = CornerRadius(20.dp.toPx()), style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))))
}

/**
 * Put on the part of the page that holds a section's body while it is being resized: a finger that lands on the corner of the body (within about 30dp) and moves sets the body's
 * size to where the finger is. It works from the finger's place on this part, which does not move while the body grows, so the size never drifts. [body] is the body's
 * current size in px and [padPx] the space to its left. [onLive] hears every size while dragging, [onDone] the last one when the finger lifts.
 */
@Composable
private fun Modifier.cornerResize(body: () -> IntSize, padPx: Float, onLive: (Int, Int) -> Unit, onDone: (Int, Int) -> Unit): Modifier {
    val live by rememberUpdatedState(onLive)
    val done by rememberUpdatedState(onDone)
    val current by rememberUpdatedState(body)
    return this.pointerInput(padPx) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val b = current()
            val cx = padPx + b.width; val cy = b.height.toFloat()
            val reach = 30.dp.toPx()
            if (abs(down.position.x - cx) > reach || abs(down.position.y - cy) > reach) return@awaitEachGesture
            down.consume()
            val gx = down.position.x - cx; val gy = down.position.y - cy
            val avail = size.width - 2f * padPx
            var lastW = 0; var lastH = 0
            drag(down.id) { c ->
                c.consume()
                lastW = HomeSections.widthPercent(c.position.x - gx - padPx, avail)
                lastH = HomeSections.heightDp(c.position.y - gy, density)
                live(lastW, lastH)
            }
            if (lastW > 0) done(lastW, lastH)
        }
    }
}

/**
 * What every kind of section shares: its title row (or none, with No name), its body, and the size you gave it. While the section has no size of its own the body is [preset], exactly as
 * its layout draws it. With a size, [sizedContent] draws the body to fit it (it gets the box's width, its height in dp or 0 for automatic, and whether the section has a size of its own),
 * and while the section is being resized the corner can be dragged to set it, with Done and Automatic size below.
 */
@Composable
private fun SectionFrame(s: HomeSection, env: HomeEnv, modifier: Modifier, preset: @Composable () -> Unit, sizedContent: @Composable (Dp, Int, Boolean) -> Unit) {
    val ops = env.ops
    val acc = LocalSb.current.acc
    val resizing = env.resizing == s.id
    // The size while the corner is being dragged, before it is saved. It only counts while resizing; afterwards the saved size is what is used.
    var liveW by remember(s.id) { mutableStateOf<Int?>(null) }
    var liveH by remember(s.id) { mutableStateOf<Int?>(null) }
    val w = if (resizing) liveW ?: s.width else s.width
    val h = if (resizing) liveH ?: s.height else s.height
    val sized = w > 0 || h > 0
    var bodyPx by remember { mutableStateOf(IntSize.Zero) }
    val padPx = with(LocalDensity.current) { 20.dp.toPx() }

    @Composable
    fun Body() {
        if (!sized && !resizing) { preset(); return }
        Box(Modifier.fillMaxWidth().then(if (resizing) Modifier.cornerResize({ bodyPx }, padPx, { nw, nh -> liveW = nw; liveH = nh }, { nw, nh -> liveW = nw; liveH = nh; ops.size(s.id, nw, nh) }) else Modifier)) {
            BoxWithConstraints(Modifier.padding(horizontal = 20.dp).fillMaxWidth(if (w > 0) w / 100f else 1f).then(if (h > 0) Modifier.height(h.dp) else Modifier)
                .onSizeChanged { bodyPx = it }.then(if (resizing) Modifier.dashedFrame(acc) else Modifier)) {
                sizedContent(maxWidth, h, sized)
            }
            if (resizing) {
                val half = with(LocalDensity.current) { 18.dp.toPx() }
                Box(Modifier.offset { IntOffset((padPx + bodyPx.width - half).roundToInt(), (bodyPx.height - half).roundToInt()) }.size(36.dp).clip(CircleShape).background(acc), Alignment.Center) {
                    Ic("expand", 18.dp, onAccent(acc))
                }
            }
        }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (s.showTitle) {
            SectionTitle(s, env)
            Body()
        } else {
            // With no name line there is no title to hold, so holding the section itself (on a spot that is not one of its things) opens its menu.
            HoldSlot(env.drag, "head:section:${s.id}", null, Modifier, menu = { close ->
                PopupItem("Edit section", "edit") { close(); ops.edit(s.id) }
                PopupItem("Resize", "expand") { close(); ops.resize(s.id) }
                PopupItem("Move up", "up") { close(); ops.move(s.id, -1) }
                PopupItem("Move down", "down") { close(); ops.move(s.id, 1) }
                PopupDivider()
                PopupItem("Delete section", "trash", tint = Sb.danger) { close(); ops.delete(s.id) }
            }) { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { Body() } }
        }
        if (resizing) {
            Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                Box(Modifier.clip(CircleShape).background(acc).tap("Done resizing") { ops.resize(null) }.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    Text("Done", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = onAccent(acc))
                }
                SoftChip("Automatic size") { liveW = null; liveH = null; ops.size(s.id, 0, 0) }
                Text("Drag the corner", Modifier.padding(start = 4.dp), fontSize = 13.sp, color = Sb.mute)
            }
        }
    }
}

/** The card of a card section's kind, in the box it is given. */
@Composable
private fun CardBody(s: HomeSection, card: SectionCard, env: HomeEnv, sz: SizeInfo) {
    when (card.kind) {
        SectionCard.TEXT -> TextCardBody(s, card, env, sz)
        SectionCard.QUOTE -> QuoteCardBody(s, card, env, sz)
        SectionCard.RANDOM -> RandomCardBody(s, card, env, sz)
        SectionCard.COUNTER -> CounterCardBody(s, card, env, sz)
        SectionCard.BUTTON -> ButtonCardBody(s, card, env, sz)
    }
}

/** A card section on Home: its title row (if it has one) and the card of its kind. */
@Composable
private fun CardBlock(s: HomeSection, card: SectionCard, env: HomeEnv, modifier: Modifier) {
    SectionFrame(s, env, modifier, { CardBody(s, card, env, SizeInfo(false, 0)) }) { _, h, _ -> CardBody(s, card, env, SizeInfo(true, h)) }
}

/** One of your sections on Home. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SectionBlock(s: HomeSection, env: HomeEnv, modifier: Modifier = Modifier) {
    if (s.card != null) { CardBlock(s, s.card, env, modifier); return }
    val byUid = remember(env.items) { env.items.associateBy { it.uid } }
    val entries = entriesOf(s, env, byUid)
    val source = "section:${s.id}"
    val ops = env.ops
    fun openEntry(e: Entry) { if (e.scrap != null) env.actions.open(e.scrap) else env.actions.openBox(e.ref.key) }

    /** Makes one entry holdable: its menu, and the payload that lets it be carried. A box in a section is also a place a scrap can be dropped on. */
    @Composable
    fun Held(e: Entry, mod: Modifier, content: @Composable () -> Unit) {
        val id = "sec:${s.id}:${e.token}"
        // Each thing reports its place under the section (so another thing of this section can be dropped on it to change the order); a box is also a place a scrap can be filed.
        val here = mod.dropRect(env.drag, "item:${s.id}\u0001${e.token}")
        val place = if (e.ref.box) here.dropRect(env.drag, "box:${e.ref.key}\u0001${s.id}") else here
        HoldSlot(env.drag, id, DragPayload(id, e.ref, e.label, e.dot, source, if (s.isSmart) null else s.id), place, menu = { close ->
            if (e.scrap != null) ScrapMenu(e.scrap, env.actions, env.vm, close, !s.isSmart) { ops.remove(s.id, e.ref) }
            else BoxMenu(e.ref.key, env.actions, close, true) { ops.remove(s.id, e.ref) }
        }, content = content)
    }

    @Composable
    fun EmptyNote(m: Modifier) {
        Text(if (s.isSmart) "Nothing matches yet. Tap Edit to change what it shows." else "Nothing here yet. Drag a scrap or a box in, or tap Edit.",
            m.homeCard(28.dp).tap("Edit ${s.name}") { ops.edit(s.id) }.padding(20.dp), fontSize = 15.sp, color = Sb.mute)
    }

    /** The section as its layout has always drawn it: used while it has no size of its own. */
    @Composable
    fun PresetBody() {
        if (entries.isEmpty()) {
            EmptyNote(Modifier.padding(horizontal = 20.dp).fillMaxWidth())
        } else when (s.layout) {
            SectionLayout.Chips -> LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(entries, key = { it.token }) { e -> Held(e, Modifier) { EntryChip(e) { openEntry(e) } } }
            }
            SectionLayout.Cards -> LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(entries, key = { it.token }) { e -> Held(e, Modifier) { EntryCard(e, env.preview, Modifier.width(176.dp)) { openEntry(e) } } }
            }
            SectionLayout.Rows -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                entries.forEach { e ->
                    Held(e, Modifier.fillMaxWidth()) {
                        if (e.scrap != null) NoteRow(e.scrap, env.nav, onHold = {}) else BoxRow(e) { openEntry(e) }
                    }
                }
            }
            SectionLayout.Grid -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                entries.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                        pair.forEach { e -> Held(e, Modifier.weight(1f)) { EntryCard(e, env.preview, Modifier.fillMaxWidth()) { openEntry(e) } } }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }

    /**
     * The section drawn to fit the size it was given. The four layouts stay the starting points: cards are as tall as the box and a little wider than tall, chips wrap to fill it,
     * rows stack, the grid takes as many columns as fit the width and shares the height among its rows. What does not fit scrolls inside the box.
     */
    @Composable
    fun SizedContent(boxW: Dp, h: Int, sized: Boolean) {
        val fixedH = h > 0
        val scroll = rememberScrollState()
        val tall = if (fixedH) Modifier.verticalScroll(scroll) else Modifier
        if (entries.isEmpty()) {
            EmptyNote(Modifier.fillMaxWidth().then(if (fixedH) Modifier.fillMaxHeight() else Modifier))
        } else when (s.layout) {
            SectionLayout.Cards -> {
                val cardW = HomeSections.cardWidth(boxW.value, h).dp
                LazyRow(if (fixedH) Modifier.fillMaxSize() else Modifier, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(entries, key = { it.token }) { e -> Held(e, Modifier) { EntryCard(e, env.preview, Modifier.width(cardW), if (fixedH) h.dp else 136.dp) { openEntry(e) } } }
                }
            }
            SectionLayout.Chips -> {
                if (sized) FlowRow(Modifier.fillMaxWidth().then(tall), Arrangement.spacedBy(10.dp), Arrangement.spacedBy(10.dp)) {
                    entries.forEach { e -> Held(e, Modifier) { EntryChip(e) { openEntry(e) } } }
                } else LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(entries, key = { it.token }) { e -> Held(e, Modifier) { EntryChip(e) { openEntry(e) } } }
                }
            }
            SectionLayout.Rows -> Column(Modifier.fillMaxWidth().then(tall), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                entries.forEach { e ->
                    Held(e, Modifier.fillMaxWidth()) {
                        if (e.scrap != null) NoteRow(e.scrap, env.nav, onHold = {}) else BoxRow(e) { openEntry(e) }
                    }
                }
            }
            SectionLayout.Grid -> {
                val cols = HomeSections.gridColumns(boxW.value)
                val cellH = HomeSections.gridCellHeight(h, entries.size, cols).dp
                Column(Modifier.fillMaxWidth().then(tall), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    entries.chunked(cols).forEach { group ->
                        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                            group.forEach { e -> Held(e, Modifier.weight(1f)) { EntryCard(e, env.preview, Modifier.fillMaxWidth(), cellH) { openEntry(e) } } }
                            repeat(cols - group.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }
    }

    SectionFrame(s, env, modifier.dropRect(env.drag, source), { PresetBody() }) { boxW, h, sized -> SizedContent(boxW, h, sized) }
}

/** A slider with its name and number above it, for a size in the sheet. [onDone] gets the number when the finger lifts. */
@Composable
private fun SizeSlider(label: String, value: Int, range: IntRange, suffix: String, onDone: (Int) -> Unit) {
    val acc = LocalSb.current.acc
    var live by remember(value) { mutableFloatStateOf(value.coerceIn(range.first, range.last).toFloat()) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text("${live.roundToInt()}$suffix", fontSize = 14.sp, color = Sb.mute)
        }
        Slider(live, { live = it }, Modifier.fillMaxWidth(), valueRange = range.first.toFloat()..range.last.toFloat(),
            onValueChangeFinished = { onDone(live.roundToInt()) }, colors = SliderDefaults.colors(thumbColor = acc, activeTrackColor = acc, inactiveTrackColor = Sb.line))
    }
}

/** Edit a section: its name, its layout, what is in it (and a way to add boxes and scraps), or what it fills itself with, and Delete. */
@Composable
fun SectionSheet(section: HomeSection, env: HomeEnv, onDone: () -> Unit) {
    var name by remember { mutableStateOf(section.title) }
    var adding by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var picking by remember { mutableIntStateOf(0) }      // 0 the sheet, 1 what to fill it with, 2 which tag, 3 which box, 4 which scraps a card looks at
    var cardText by remember { mutableStateOf(section.card?.text ?: "") }
    val card = section.card
    val ops = env.ops
    val byUid = remember(env.items) { env.items.associateBy { it.uid } }
    val entries = entriesOf(section, env, byUid)
    val rule = section.rule
    /** Gives the section this rule; a section that has no name yet is named after it. */
    fun choose(r: SectionRule) {
        if (card != null) {      // a card: a button's box, or the scraps a random or counter card looks at
            ops.card(section.id, card.copy(arg = if (card.kind == SectionCard.BUTTON) r.arg else r.encode()))
            picking = 0
            return
        }
        val t = if (name.isBlank()) ruleTitle(r, env.shelves) else null
        if (t != null) name = t
        ops.rule(section.id, r, t, null)
        picking = 0
    }
    fun isRule(kind: String, arg: String = ""): Boolean = rule != null && rule.kind == kind && rule.arg.equals(arg, ignoreCase = true)
    /** Whether the name shows on Home, the size of the section, and the way into resizing it on Home. Every kind of section has them. */
    @Composable
    fun LookAndSize() {
        SheetLabel("Name on Home")
        Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            SoftChip("Show the name", section.showTitle) { ops.showTitle(section.id, true) }
            SoftChip("No name", !section.showTitle) { ops.showTitle(section.id, false) }
        }
        if (!section.showTitle) SheetNote("The section is only its content, with nothing above it. To edit it again, hold it on Home or open it from Customize home.")
        SheetLabel("Size")
        Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            SoftChip("Automatic", !section.sized) { ops.size(section.id, 0, 0) }
            SoftChip("My size", section.sized) { if (!section.sized) ops.size(section.id, 100, 220) }
        }
        if (section.sized) {
            val sw = if (section.width > 0) section.width else 100
            val sh = if (section.height > 0) section.height else 220
            SizeSlider("Width", sw, HomeSections.MIN_WIDTH..HomeSections.MAX_WIDTH, "%") { ops.size(section.id, it, sh) }
            SizeSlider("Height", sh, HomeSections.MIN_HEIGHT..HomeSections.MAX_HEIGHT, " dp") { ops.size(section.id, sw, it) }
        }
        SheetGroup { ActionRow("expand", "Resize on Home", "Drag the corner of the section") { ops.resize(section.id); onDone() } }
        SheetLabel("Space below")
        Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            SoftChip("Automatic", section.spaceBelow < 0) { ops.space(section.id, -1) }
            SoftChip("My space", section.spaceBelow >= 0) { if (section.spaceBelow < 0) ops.space(section.id, LocalHomeLook.current.gap) }
        }
        if (section.spaceBelow >= 0) SizeSlider("Space", section.spaceBelow, 0..HomeSections.MAX_SPACE, " dp") { ops.space(section.id, it) }
        SheetNote("The space between this section and whatever comes next. Automatic uses the Space between parts of the Look page.")
    }
    val pickTitle = when { card == null -> "Fill automatically"; card.kind == SectionCard.BUTTON -> "Which box?"; else -> "Which scraps?" }
    Sheet(if (picking == 0) "Edit section" else pickTitle, { if (picking != 0) picking = 0 else onDone() }, doneLabel = if (picking == 0) "Done" else "Back") {
        if (picking == 1) {
            SheetNote("A section that fills itself shows what matches, newest edited first, and keeps up to date. It never holds anything of its own.")
            SheetGroup {
                OptionRow("Scraps with a tag", rule?.kind == SectionRule.TAG, sub = "Every scrap with the tag you pick") { picking = 2 }
                SheetDivider(18.dp)
                OptionRow("Scraps in a box", rule?.kind == SectionRule.BOX, sub = "The box and the boxes inside it") { picking = 3 }
                SheetDivider(18.dp)
                OptionRow("Edited this week", rule?.kind == SectionRule.WEEK, sub = "Everything you touched in the last seven days") { choose(SectionRule(SectionRule.WEEK)) }
            }
        } else if (picking == 2) {
            val tags = remember(env.items) { env.items.flatMap { it.tags }.groupingBy { it.lowercase() }.eachCount().entries.sortedByDescending { it.value }.map { it.key }.take(40) }
            if (tags.isEmpty()) SheetNote("No tags yet. Write #word in a scrap to make one.")
            else SheetGroup {
                tags.forEachIndexed { i, tg ->
                    if (i > 0) SheetDivider(18.dp)
                    OptionRow("#$tg", isRule(SectionRule.TAG, tg)) { choose(SectionRule(SectionRule.TAG, tg)) }
                }
            }
        } else if (picking == 3) {
            SheetGroup {
                if (!env.inboxHidden) { OptionRow("Inbox", isRule(SectionRule.BOX, "Inbox"), dot = env.colorOf("Inbox")) { choose(SectionRule(SectionRule.BOX, "Inbox")) } }
                env.shelves.forEach { sh ->
                    SheetDivider(46.dp)
                    OptionRow(sh.label, isRule(SectionRule.BOX, sh.name), dot = TAB_COLORS[sh.color % TAB_COLORS.size]) { choose(SectionRule(SectionRule.BOX, sh.name)) }
                }
            }
        } else if (picking == 4 && card != null) {
            val scope = card.scope
            SheetGroup {
                OptionRow("All your scraps", scope == null) { ops.card(section.id, card.copy(arg = "")); picking = 0 }
                SheetDivider(18.dp)
                OptionRow("Scraps with a tag", scope?.kind == SectionRule.TAG, sub = "Every scrap with the tag you pick") { picking = 2 }
                SheetDivider(18.dp)
                OptionRow("Scraps in a box", scope?.kind == SectionRule.BOX, sub = "The box and the boxes inside it") { picking = 3 }
                SheetDivider(18.dp)
                OptionRow("Edited this week", scope?.kind == SectionRule.WEEK, sub = "Everything you touched in the last seven days") { ops.card(section.id, card.copy(arg = SectionRule(SectionRule.WEEK).encode())); picking = 0 }
            }
        } else if (card != null) {
            SheetLabel("Name")
            InputBox { Field(name, { name = it.take(HomeSections.MAX_TITLE); ops.rename(section.id, name) }, "Section name", 18.sp, headFont(), FontWeight.Medium) }
            LookAndSize()
            when (card.kind) {
                SectionCard.TEXT -> {
                    SheetLabel("Text")
                    InputBox { Field(cardText, { cardText = it.take(SectionCard.MAX_TEXT); ops.card(section.id, card.copy(text = cardText)) }, "Write something", 16.sp, headFont(), modifier = Modifier.heightIn(min = 96.dp)) }
                    SheetNote("Shown on Home as it is. Tap the card there to come back here.")
                }
                SectionCard.QUOTE -> {
                    SheetLabel("Quotes")
                    InputBox { Field(cardText, { cardText = it.take(SectionCard.MAX_TEXT); ops.card(section.id, card.copy(text = cardText)) }, "One quote on each line", 16.sp, headFont(), modifier = Modifier.heightIn(min = 120.dp)) }
                    SheetNote("Home shows one quote a day, in turn. Tap the card for another.")
                }
                SectionCard.RANDOM, SectionCard.COUNTER -> {
                    SheetLabel(if (card.kind == SectionCard.RANDOM) "Draws from" else "Counts")
                    SheetGroup {
                        ActionRow(card.scope?.let { ruleIcon(it) } ?: "page", card.scope?.let { ruleSummary(it, env.shelves) } ?: "All your scraps", "Tap to change which scraps") { picking = 4 }
                    }
                    SheetNote(if (card.kind == SectionCard.RANDOM) "A different scrap every time Home opens. Tap Another on the card to draw again." else "A big number that keeps up with your scraps by itself.")
                }
                SectionCard.BUTTON -> {
                    val dest = card.destination
                    SheetLabel("Writes in")
                    SheetGroup { ActionRow("folder", if (dest == "Inbox") "Inbox" else env.shelves.labelOf(dest), "Tap to choose the box") { picking = 3 } }
                    SheetLabel("Starts with")
                    InputBox { Field(cardText, { cardText = it.take(SectionCard.MAX_TEXT); ops.card(section.id, card.copy(text = cardText)) }, "Optional: text the new scrap starts with", 16.sp, headFont(), modifier = Modifier.heightIn(min = 72.dp)) }
                    SheetNote("The button on Home opens a new scrap in this box with that text already written. A checklist can start with - [ ] .")
                }
            }
            Spacer(Modifier.height(4.dp))
            SheetGroup { ActionRow("trash", "Delete section", sub = "Only the section goes. Your scraps and boxes are not touched.", danger = true) { ops.delete(section.id); onDone() } }
        } else {
            SheetLabel("Name")
            InputBox { Field(name, { name = it.take(HomeSections.MAX_TITLE); ops.rename(section.id, name) }, "Section name", 18.sp, headFont(), FontWeight.Medium) }
            SheetLabel("Layout")
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
                SectionLayout.entries.forEach { l -> SoftChip(l.label, section.layout == l) { ops.layout(section.id, l) } }
            }
            LookAndSize()
            if (rule != null) {
                SheetLabel("Fills itself")
                SheetGroup {
                    ActionRow(ruleIcon(rule), ruleSummary(rule, env.shelves), "Tap to change what it shows") { picking = 1 }
                    SheetDivider(18.dp)
                    ActionRow("edit", "Choose the things myself", "Keeps the scraps it shows now") { ops.rule(section.id, null, null, entries.map { it.ref }) }
                }
                SheetNote("It shows up to ${SectionRule.MAX_SHOWN} scraps, newest edited first. Hold one to carry it to another section.")
            } else {
            SheetLabel("In this section")
            if (entries.isEmpty()) SheetNote("Nothing yet. Add boxes and scraps below, or drag them in from Home.")
            else SheetGroup {
                entries.forEachIndexed { i, e ->
                    if (i > 0) SheetDivider(46.dp)
                    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(start = 18.dp, end = 6.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        if (e.dot != null) Box(Modifier.size(14.dp).clip(CircleShape).background(e.dot)) else Ic("page", 18.dp, Sb.mute)
                        Text(e.label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Remove ${e.label} from this section") { ops.remove(section.id, e.ref) }, Alignment.Center) { Ic("close", 20.dp, Sb.mute) }
                    }
                }
            }
            SheetNote("A section only holds shortcuts. Taking something out never deletes it.")
            SheetGroup { ActionRow(if (adding) "up" else "plus", if (adding) "Done adding" else "Add boxes and scraps") { adding = !adding } }
            if (adding) {
                SheetLabel("Boxes")
                SheetGroup {
                    val inboxRef = SectionRef(true, "Inbox")
                    var first = true
                    if (!env.inboxHidden) { OptionRow("Inbox", section.has(inboxRef), dot = env.colorOf("Inbox")) { ops.toggle(section.id, inboxRef) }; first = false }
                    env.shelves.forEach { sh ->
                        if (!first) SheetDivider(46.dp); first = false
                        val r = SectionRef(true, sh.name)
                        OptionRow(sh.label, section.has(r), dot = TAB_COLORS[sh.color % TAB_COLORS.size]) { ops.toggle(section.id, r) }
                    }
                }
                SheetLabel("Scraps")
                InputBox { Field(query, { query = it }, "Search your scraps", 16.sp, headFont()) }
                val shown = remember(env.items, query) {
                    val q = query.trim()
                    env.items.filter { q.isEmpty() || it.title.contains(q, true) || it.body.contains(q, true) }.sortedByDescending { it.savedAt }.take(25)
                }
                if (shown.isEmpty()) SheetNote("No scraps match.")
                else SheetGroup {
                    shown.forEachIndexed { i, n ->
                        if (i > 0) SheetDivider(18.dp)
                        val r = SectionRef(false, n.uid)
                        OptionRow(n.displayTitle, section.has(r), sub = LocalShelves.current.displayName(n.collection)) { ops.toggle(section.id, r) }
                    }
                }
            }
                SheetGroup { ActionRow("sliders", "Fill automatically", "By a tag, a box, or this week") { picking = 1 } }
            }
            Spacer(Modifier.height(4.dp))
            SheetGroup { ActionRow("trash", "Delete section", sub = "Only the section goes. Its scraps and boxes stay where they are.", danger = true) { ops.delete(section.id); onDone() } }
        }
    }
}

/** Choose a section to put a scrap or a box in, or start a new one with it. */
@Composable
fun AddToSectionSheet(ref: SectionRef, allSections: List<HomeSection>, ops: SectionOps, onDone: () -> Unit) {
    val sections = allSections.filter { !it.isSmart && !it.isCard }      // a section that fills itself, and a card, hold nothing of their own
    Sheet("Add to a section", onDone, doneLabel = "Cancel", soft = true) {
        if (sections.isNotEmpty()) SheetGroup {
            sections.forEachIndexed { i, s ->
                if (i > 0) SheetDivider(18.dp)
                OptionRow(s.name, s.has(ref), sub = if (s.refs.size == 1) "1 item" else "${s.refs.size} items") { ops.toggle(s.id, ref); onDone() }
            }
        }
        SheetGroup { ActionRow("plus", "New section with this") { ops.newWith(ref); onDone() } }
        if (sections.isEmpty()) SheetNote("You can also make a section by holding a scrap or a box and dragging it onto an empty spot of Home.")
    }
}

/** What a new section can be: a row of shortcuts, or one of the cards (see SectionCard). Choosing adds it at the end of Home and opens it for editing. */
@Composable
fun AddSectionSheet(onPick: (SectionCard?) -> Unit, onDone: () -> Unit) {
    fun icon(kind: String) = when (kind) {
        SectionCard.TEXT -> "page"
        SectionCard.QUOTE -> "star"
        SectionCard.RANDOM -> "sparkle"
        SectionCard.COUNTER -> "list"
        else -> "plus"
    }
    fun about(kind: String) = when (kind) {
        SectionCard.TEXT -> "A note in your own words"
        SectionCard.QUOTE -> "Lines you like, one shown each day"
        SectionCard.RANDOM -> "A scrap drawn from your archive"
        SectionCard.COUNTER -> "A big number counting your scraps"
        else -> "Starts a new scrap in a box you choose"
    }
    Sheet("Add a section", onDone, doneLabel = "Cancel", soft = true) {
        SheetGroup {
            ActionRow("layout", "Section of shortcuts", "Boxes and scraps you pick") { onPick(null) }
            SectionCard.KINDS.forEach { k ->
                SheetDivider(46.dp)
                ActionRow(icon(k), SectionCard.label(k), about(k)) { onPick(SectionCard(k)) }
            }
        }
        SheetNote("You can also make a section by holding a scrap or a box and dragging it onto an empty spot of Home.")
    }
}
