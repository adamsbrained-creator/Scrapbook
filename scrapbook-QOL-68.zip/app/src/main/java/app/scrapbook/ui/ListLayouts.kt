package app.scrapbook.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

/**
 * How a page lists its scraps. The layout picker (top right of the list controls) switches between these, and Settings > Default view picks the one a page starts in.
 * To add a layout: add an entry here, an icon in Icons.kt, and a branch in [scrapLayout] below. The picker and the setting follow by themselves.
 * Grid is the old two-column view; it stays until the new layouts are all in.
 */
enum class ListLayout(val key: String, val label: String, val icon: String) {
    Cards("cards", "Cards", "l_cards"),
    Grid("grid", "Grid", "grid");

    companion object { fun of(key: String?): ListLayout = entries.firstOrNull { it.key == key } ?: Cards }
}

/** The color of a box's dot: the box's own color, the Inbox color, or grey for a scrap that is not in a box. */
@Composable
fun boxDotColor(collection: String): Color {
    val inbox = LocalInboxColor.current
    if (collection == "Inbox") return if (inbox < 0) TAB_GRAY else TAB_COLORS[inbox % TAB_COLORS.size]
    val shelf = LocalShelves.current.firstOrNull { it.name == collection } ?: return TAB_GRAY
    return TAB_COLORS[shelf.color % TAB_COLORS.size]
}

/**
 * Draws [shown] in the chosen [layout]. Used inside a LazyColumn by the All scraps page and by every box.
 * [pickFor] gives the selection state of a scrap while picking, [onSelect] starts picking (long press).
 */
fun LazyListScope.scrapLayout(layout: ListLayout, shown: List<Item>, nav: NavController, terms: List<String>, pickFor: (Item) -> Pick?, onSelect: (Item) -> Unit) {
    when (layout) {
        ListLayout.Cards -> items(shown, key = { it.id }) { n -> NoteRow(n, nav, Modifier.animateItem(), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
        ListLayout.Grid -> items(shown.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { n -> NoteTile(n, nav, Modifier.weight(1f), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/**
 * The layout picker: a pill with the current layout's icon and a chevron. Tapping it opens a small floating menu under it
 * (icon, name, a dot on the current one), in the style of the main menu in Paperback but narrower.
 */
@Composable
fun LayoutPicker(current: ListLayout, onPick: (ListLayout) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val bg by animateColorAsState(if (open) LocalSb.current.tint else Sb.card, tween(150), label = "layoutPill")
    Box {
        Row(Modifier.height(44.dp).clip(CircleShape).background(bg).tap("Change layout, now ${current.label}") { open = true }.padding(start = 14.dp, end = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Ic(current.icon, 22.dp, Sb.ink); Ic("chevdown", 18.dp, Sb.mute)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.width(200.dp),
            shape = RoundedCornerShape(30.dp), containerColor = Sb.card, tonalElevation = 0.dp, shadowElevation = 18.dp, border = BorderStroke(1.dp, Sb.menuLine)) {
            ListLayout.entries.forEach { l -> LayoutRow(l, l == current) { open = false; onPick(l) } }
        }
    }
}

@Composable
private fun LayoutRow(l: ListLayout, selected: Boolean, onClick: () -> Unit) {
    val sans = LocalFonts.current.second
    val bg by animateColorAsState(if (selected) Sb.line else Color.Transparent, tween(150), label = "layoutRow")
    Row(Modifier.pressScale(.97f).fillMaxWidth().padding(horizontal = 6.dp).height(52.dp).clip(RoundedCornerShape(26.dp)).background(bg).tap(l.label, onClick).padding(horizontal = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic(l.icon, 22.dp, Sb.ink)
        Text(l.label, Modifier.weight(1f), fontFamily = sans, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
        if (selected) Box(Modifier.size(9.dp).clip(CircleShape).background(LocalSb.current.acc))
    }
}
