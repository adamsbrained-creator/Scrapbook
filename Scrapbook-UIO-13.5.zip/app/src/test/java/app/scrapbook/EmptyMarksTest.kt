package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class EmptyMarksTest {
    @Test fun emptyBoldGoesAway() = assertEquals("" to 0, dropEmptyMarks("****", 2))
    @Test fun emptyBoldKeepsTheRestOfTheText() = assertEquals("a b" to 2, dropEmptyMarks("a ****b", 4))
    @Test fun colorInsideHighlight() = assertEquals("" to 0, dropEmptyMarks("=={c:34c759|}==", 12))
    @Test fun highlightInsideColor() = assertEquals("" to 0, dropEmptyMarks("{c:34c759|====}", 12))
    @Test fun colorSizeUnderline() = assertEquals("x" to 1, dropEmptyMarks("x{c:ff0000 s:20 u|}", 18))
    @Test fun strikeAndItalic() { assertEquals("" to 0, dropEmptyMarks("~~~~", 2)); assertEquals("" to 0, dropEmptyMarks("**", 1)) }
    @Test fun cursorNotThereLeavesItAlone() { assertNull(dropEmptyMarks("****", 0)); assertNull(dropEmptyMarks("**a**", 3)) }
    @Test fun spanWithTextIsKept() = assertNull(dropEmptyMarks("{c:34c759|a}", 11))
    @Test fun threeStarsIsNotAnEmptyItalic() = assertNull(dropEmptyMarks("***", 1))
}

class SplitMarksTest {
    private fun split(line: String, p: Int) = splitMarksAtBreak(line, line, p)
    @Test fun endOfHighlightMovesTheBreakOutside() = assertEquals("==Test==" to "", split("==Test==", 6))
    @Test fun startOfHighlightMovesTheTextDown() = assertEquals("" to "==Test==", split("==Test==", 2))
    @Test fun middleClosesAndReopens() = assertEquals("==Te==" to "==st==", split("==Test==", 4))
    @Test fun nestedMarksCloseInnerFirst() = assertEquals("**a==b==**" to "**==c==d**", split("**a==bc==d**", 6))
    @Test fun nestedAtTheEnd() = assertEquals("**==Test==**" to "", split("**==Test==**", 8))
    @Test fun colorSpan() = assertEquals("{c:34c759|a}" to "{c:34c759|bc}", split("{c:34c759|abc}", 11))
    @Test fun outsideAnythingNothingHappens() { assertNull(split("abc", 1)); assertNull(split("==a== b", 7)) }
    @Test fun starsWithSpacesAreNotItalic() = assertNull(split("2 * 3 * 4", 4))
    @Test fun listLineKeepsItsPrefix() = assertEquals("- **a**" to "**b**", split("- **ab**", 5))
    @Test fun withoutEmptyMarks() {
        assertEquals("a – b", withoutEmptyMarks("a{c:5e5ce6|} – b"))
        assertEquals("x", withoutEmptyMarks("x=={c:ff0000|}=="))
        assertEquals("plain", withoutEmptyMarks("plain"))
    }
}
