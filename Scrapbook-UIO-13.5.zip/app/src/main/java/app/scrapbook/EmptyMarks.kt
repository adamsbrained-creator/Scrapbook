package app.scrapbook

/** A color / size / underline span with nothing inside it: {c:34c759|}. */
val EMPTY_SPAN = Regex("\\{(?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2}\\|\\}")

/**
 * When the last letter inside bold, a highlight, a color and so on is deleted, the marks around it have nothing left to wrap and would show up as
 * plain symbols ("****", "{c:34c759|}"). This takes off every empty wrapper that sits exactly at the cursor, from the inside out, so a nested
 * "=={c:34c759|}==" goes away completely. Returns the new text and cursor, or null when there is nothing to take off.
 */
fun dropEmptyMarks(text: String, cursor: Int): Pair<String, Int>? {
    var s = text; var p = cursor; var changed = false
    var guard = 0
    while (guard++ < 12) {
        if (p < 0 || p > s.length) break
        // {c:..|} with the cursor in front of its closing brace.
        val span = EMPTY_SPAN.findAll(s).firstOrNull { it.range.last == p }
        if (span != null) { s = s.removeRange(span.range.first, span.range.last + 1); p = span.range.first; changed = true; continue }
        // ****, ~~~~ and ==== with the cursor in the middle.
        val pair = listOf("****", "~~~~", "====").firstOrNull { p >= 2 && s.startsWith(it, p - 2) }
        if (pair != null) { s = s.removeRange(p - 2, p + 2); p -= 2; changed = true; continue }
        // An empty italic pair, *|*, not part of a longer run of stars.
        if (p >= 1 && p < s.length && s[p - 1] == '*' && s[p] == '*' && (p < 2 || s[p - 2] != '*') && (p + 1 >= s.length || s[p + 1] != '*')) {
            s = s.removeRange(p - 1, p + 1); p -= 1; changed = true; continue
        }
        break
    }
    return if (changed) s to p else null
}

private val EMPTY_PAIRS = Regex("\\*\\*\\*\\*|~~~~|====")

/** The text with every empty wrapper taken out ("****", "====", "~~~~", "{c:34c759|}"), also when one sits inside another. For showing text, never for saving it. */
fun withoutEmptyMarks(s: String): String {
    if ('|' !in s && !s.contains("****") && !s.contains("~~~~") && !s.contains("====")) return s
    var t = s
    for (i in 0 until 6) {
        val n = EMPTY_PAIRS.replace(EMPTY_SPAN.replace(t, ""), "")
        if (n == t) break
        t = n
    }
    return t
}

private val INLINE_MARKS = Regex("\\*\\*(.+?)\\*\\*|~~(.+?)~~|==(.+?)==|\\*(.+?)\\*")
private val SPAN_MARKS = Regex("\\{((?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2})\\|(.+?)\\}")

/** One bold / italic / strike / highlight / color run around a spot: how it opens and closes, and where the text inside it is (in the line). */
private class Wrap(val open: String, val close: String, val cs: Int, val ce: Int)

private fun enclosingMarks(masked: String, p: Int): List<Wrap> {
    val chain = mutableListOf<Wrap>()
    var a = 0; var b = masked.length
    while (chain.size < 8) {
        val sub = masked.substring(a, b)
        var best: Wrap? = null
        fun consider(open: String, close: String, cs: Int, ce: Int) {
            if (a + cs <= p && p <= a + ce && (best == null || cs - open.length < best!!.cs - a - best!!.open.length)) best = Wrap(open, close, a + cs, a + ce)
        }
        for (m in INLINE_MARKS.findAll(sub)) {
            val gi = (1..4).first { m.groups[it] != null }; val g = m.groups[gi]!!
            if (gi == 4 && (g.value.first().isWhitespace() || g.value.last().isWhitespace())) continue   // "2 * 3 * 4" is not italic
            consider(sub.substring(m.range.first, g.range.first), sub.substring(g.range.last + 1, m.range.last + 1), g.range.first, g.range.last + 1)
        }
        for (m in SPAN_MARKS.findAll(sub)) {
            val g = m.groups[2]!!
            consider(sub.substring(m.range.first, g.range.first), "}", g.range.first, g.range.last + 1)
        }
        val w = best ?: break
        chain += w; a = w.cs; b = w.ce
    }
    return chain
}

/**
 * Pressing Enter in the middle of bold, a highlight, a color and so on would leave the marks open on one line and closed on the next, and a mark that
 * has lost its partner shows up as plain symbols. So the formatting is closed at the end of the first line and opened again at the start of the
 * second, from the inside out; at the very end of the formatted text that just means the new line starts outside it, and at the very start, the
 * formatted text moves down whole. [line] is the line as saved, [masked] the same with code spans blanked out (same length), [p] the spot in it.
 * Returns what the line before the break and the line after it become, or null when the spot is not inside any formatting.
 */
fun splitMarksAtBreak(line: String, masked: String, p: Int): Pair<String, String>? {
    val chain = enclosingMarks(masked, p)
    if (chain.isEmpty()) return null
    var left = line.substring(0, p); var right = line.substring(p)
    for (w in chain.asReversed()) {
        left = if (left.endsWith(w.open)) left.dropLast(w.open.length) else left + w.close
        right = if (right.startsWith(w.close)) right.drop(w.close.length) else w.open + right
    }
    return left to right
}
