Scrapbook — UI Overhaul (UIO) Development Log

Project: Scrapbook
Milestone: UI Overhaul (UIO)
Status: In progress
Base: Quality of Life update (scrapbook-QOL-88)

Goal: a complete overhaul of the app's look, with more customization, built section by section.
Entries are added in the order they are built. Each one says what the feature is for and what was built.

———

Section: Home

☑ 1. New greeting: account system (Scrapbook-UIO-1)
   For: the greeting needs to know who it is talking to, and the app needs a place for the person behind it.
   Built: an Account with name, nickname, a line about you, pronouns, birthday (no year) and a profile picture (photo, or initial on a chosen color).
   Stored only on this phone. New Account page, an account card at the top of Settings, a profile icon, picture cropping and saving (Avatar.kt).

☑ 2. More greeting options and views: greeting lines and settings (Scrapbook-UIO-1)
   For: a greeting that feels alive instead of the same line every day.
   Built: 170+ greetings across time of day (late night to night), weekdays, casual lines, lines about your scraps (Inbox, pinned, empty, large archive)
   and birthday / New Year's Day lines, in friendly, playful and calm voices. {name} drops out neatly when no name is set. The greeting changes by itself
   (never, 10, 20, 40 or 90 seconds), on every tap, and avoids repeating recent lines. New Settings > Greeting page: show or hide, show my picture,
   line under the greeting (date, about me, scrap count, nothing), change interval, tone, and switches for time-of-day, casual and scrap-related lines.
   The greeting on Home now uses the account's name and picture; tapping the picture opens the Account page.

☑ 3. Greeting: smaller by default, text and picture resize freely (Scrapbook-UIO-1.5)
   For: the greeting took too much room at the top of Home, and everyone wants a different size.
   Built: the greeting now starts smaller (text 24, picture 44 instead of 30 and 56). Settings > Greeting has a live preview and two sliders:
   Text size (14 to 44) and Picture size (20 to 96). The preview follows the slider while you drag, and the size is saved when you let go.
   The line under the greeting scales with the text, and a small picture still has a 44dp touch area.

☑ 4. Account card moved down in Settings (Scrapbook-UIO-1.5)
   For: the account card at the very top pushed the settings down; it belongs with the About page.
   Built: the account card now sits right above the About page, below the list of settings pages.

☑ 5. Greeting options moved into Customize home (Scrapbook-UIO-1.6)
   For: every part of Home is meant to keep its own options next to where it is moved and hidden, so the greeting's settings belong there and not in Settings.
   Built: a row in Customize home can now have a sliders button (and tapping its name does the same) that opens that part's own options page; the Greeting row has one.
   The page keeps the live preview pinned on top and holds text size, picture size, show my picture, the line under the greeting, how often it changes, the tone and the
   three switches for the kinds of lines. The Greeting page in Settings is gone (the Account card stays). Showing or hiding the greeting is still the eye on its row.
   Other parts can get their own options the same way (withOptions and options in HomeCustomize, ui/GreetingOptions.kt).

☑ 6. Home layout: move and hide every part (Scrapbook-UIO-2)
   For: Home should look the way you want it: any part can go anywhere, or be switched off.
   Built: Home is now made of eight parts (Header, Greeting, Quick capture, Continue, To sort, Boxes, Pinned, Recent), each with a place in the order and an on/off switch.
   New Customize home in the Home menu: one short row per part with a drag handle (hold and drag to move it) and an eye (tap to hide or bring it back), a Back to the usual order
   button, and Move up / Move down actions for screen readers. Hidden parts keep their place. The order and the hidden parts are saved on this phone (HomeLayout.kt, ui/HomeEdit.kt).
   Home reads the saved layout and draws its parts in that order. The old "Show greeting" and "Show boxes on home" switches in Settings now use the same on/off state,
   and an update keeps whatever they were set to. With the header hidden, a small menu button stays so the menu can always be reached.

☑ 7. Optional designs for the parts of Home (Scrapbook-UIO-3)
   For: every part of Home can look the way you like, but only if you want it to. Nothing changes until a design is chosen; each part keeps its classic look by default.
   Built: the sliders button on a row in Customize home now opens an options page for Capture, Continue, Boxes, Pinned and Recent as well (the Greeting already had one).
   Each page has a preview of the real part with your own scraps on top, one segmented choice per design under it with a line saying what it looks like, and a
   Back to the classic look button once something is chosen. The row in Customize home shows the chosen design under the name.
   Designs: Greeting (classic, centered, on a card; picture left or right, next to its size sliders), Quick capture (classic, slim one line, icons only),
   Continue (classic, thin line, with a preview of the text), Boxes (chips, grid of two columns, list), Pinned (cards in a row in three sizes, list, grid of two columns),
   Recent (cards, compact lines; 3, 4, 6 or 8 scraps). The choices are saved on this phone (HomeStyles.kt, ui/HomeDesignOptions.kt, the part designs in ui/HomePage.kt).
