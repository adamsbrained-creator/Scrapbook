package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// The options page of a part of Home that has more than one design (Capture, Continue, Boxes, Pinned, Recent), opened from the sliders button on its row in
// Customize home. Same shape as the greeting's page: a preview stays on top while the choices scroll, so a choice can be seen at once. Every choice is optional:
// a part keeps its classic look until one is picked, and "Back to the classic look" undoes all of them. The greeting keeps its own page (GreetingOptions.kt),
// which uses [DesignPicker] for its style and picture side.

/** One choice of design: its name, the options as a segmented control, and a line saying what the chosen option looks like. */
@Composable
fun DesignPicker(k: HomeStyleKey, styles: HomeStyles, onStyles: (HomeStyles) -> Unit) {
    SettingsCard {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(k.label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
            Seg(k.options, styles[k]) { i -> onStyles(styles.with(k, i)) }
            Text(k.hints[styles[k]], fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
        }
    }
}

/** Which choices of a part apply right now: the card size only means something for pinned cards in a row. */
fun designKeys(el: HomeElement, styles: HomeStyles): List<HomeStyleKey> =
    HomeStyleKey.forElement(el).filter { k -> !(k == HomeStyleKey.PinnedSize && styles[HomeStyleKey.PinnedStyle] != 0) }

@Composable
fun HomeDesignOptions(el: HomeElement, styles: HomeStyles, onStyles: (HomeStyles) -> Unit, onBack: () -> Unit, preview: @Composable () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
            CircleBtn("Back to Customize home", onBack) { Ic("back", 22.dp, Sb.ink) }
            Text(el.label, Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
        }
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            // The preview is the real part with your own scraps, but only to look at: taps on it do nothing.
            Box(Modifier.fillMaxWidth().heightIn(max = 300.dp).padding(vertical = 14.dp)) {
                preview()
                Box(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { } })
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            SectionLabel("Design")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                designKeys(el, styles).forEach { k -> DesignPicker(k, styles, onStyles) }
            }
            Text("Optional. ${el.label} keeps its classic look until you choose another one.", Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp), fontSize = 12.sp, color = Sb.mute)
            if (!styles.isDefault(el)) {
                Spacer(Modifier.height(10.dp))
                SettingsCard { IconRow("undo", "Back to the classic look", "") { onStyles(styles.reset(el)) } }
            }
        }
    }
}
