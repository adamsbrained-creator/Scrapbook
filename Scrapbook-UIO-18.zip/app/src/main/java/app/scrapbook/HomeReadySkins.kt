package app.scrapbook

/**
 * Ready-made skins: arrangements that look clearly different from Classic, to start from. One is added to your skins as a copy and worn (so it can be changed or deleted like
 * any other), and adding it twice gives two copies. They hold no sections (those are made of your own scraps and boxes) and use the usual gestures (everything on).
 */
data class ReadySkin(val key: String, val name: String, val blurb: String, val values: Map<String, String>)

object ReadySkins {
    private fun styles(vararg p: Pair<HomeStyleKey, Int>): String = p.fold(HomeStyles.Default) { s, (k, i) -> s.with(k, i) }.encode()
    private fun look(vararg p: Pair<HomeLookKey, Int>): String = p.fold(HomeLook.Default) { s, (k, i) -> s.with(k, i) }.encode()
    private fun layout(order: List<HomeElement>, hidden: Set<HomeElement> = emptySet()) = HomeLayout(order, hidden)

    private fun skin(key: String, name: String, blurb: String, l: HomeLayout, styles: String, look: String, header: Int, headerSize: Int, greetText: Int? = null, greetPic: Int? = null): ReadySkin {
        val v = HashMap<String, String>()
        v[SkinKeys.ORDER] = l.encodeOrder(); v[SkinKeys.HIDDEN] = l.encodeHidden(); v[SkinKeys.STYLES] = styles; v[SkinKeys.LOOK] = look
        v[SkinKeys.HEADER] = header.toString(); v[SkinKeys.HEADER_SIZE] = headerSize.toString()
        if (greetText != null) v[SkinKeys.GREET_TEXT] = greetText.toString()
        if (greetPic != null) v[SkinKeys.GREET_PIC] = greetPic.toString()
        return ReadySkin(key, name, blurb, HomeSkins.sparse(v))
    }

    /** Quiet and light: thin lines instead of cards, one-line parts, a small greeting, a few scraps. */
    val minimal = skin("minimal", "Minimal", "Thin lines, one-line parts and a quiet greeting.",
        layout(HomeElement.entries.toList(), setOf(HomeElement.Sort)),
        styles(HomeStyleKey.GreetingStyle to 5, HomeStyleKey.CaptureStyle to 1, HomeStyleKey.ContinueStyle to 1, HomeStyleKey.BoxesStyle to 2,
            HomeStyleKey.PinnedStyle to 1, HomeStyleKey.RecentStyle to 1, HomeStyleKey.RecentCount to 0),
        look(HomeLookKey.Cards to 1, HomeLookKey.Spacing to 0), header = 0, headerSize = 0)

    /** Big and friendly: round tinted cards on a page with a wash of the accent color, a banner greeting, grids and previews, plenty of room. */
    val bold = skin("bold", "Bold", "Round cards, a banner greeting and room to breathe.",
        layout(listOf(HomeElement.Header, HomeElement.Greeting, HomeElement.Capture, HomeElement.Continue, HomeElement.Pinned, HomeElement.Boxes, HomeElement.Recent, HomeElement.Sort)),
        styles(HomeStyleKey.GreetingStyle to 4, HomeStyleKey.ContinueStyle to 2, HomeStyleKey.BoxesStyle to 1, HomeStyleKey.PinnedStyle to 2, HomeStyleKey.RecentCount to 2),
        look(HomeLookKey.Corners to 2, HomeLookKey.Cards to 2, HomeLookKey.Spacing to 2, HomeLookKey.Tint to 1), header = 2, headerSize = 2, greetText = 32)

    /** A dashboard: everything close together, short parts first and a long list of recent scraps. */
    val dense = skin("dense", "Dense", "Everything close together, with a long list of recent scraps.",
        layout(listOf(HomeElement.Header, HomeElement.Capture, HomeElement.Continue, HomeElement.Sort, HomeElement.Pinned, HomeElement.Boxes, HomeElement.Recent, HomeElement.Greeting),
            setOf(HomeElement.Greeting)),
        styles(HomeStyleKey.CaptureStyle to 2, HomeStyleKey.ContinueStyle to 1, HomeStyleKey.BoxesStyle to 1, HomeStyleKey.PinnedStyle to 1, HomeStyleKey.RecentStyle to 1, HomeStyleKey.RecentCount to 3),
        look(HomeLookKey.Corners to 0, HomeLookKey.Spacing to 0), header = 1, headerSize = 0)

    val all: List<ReadySkin> = listOf(minimal, bold, dense)

    fun of(key: String): ReadySkin? = all.firstOrNull { it.key == key }
}
