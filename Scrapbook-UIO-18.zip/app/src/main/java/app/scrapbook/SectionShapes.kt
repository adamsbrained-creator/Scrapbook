package app.scrapbook

import kotlin.math.max
import kotlin.math.min

// The sizes behind the layouts of a Home section that came after Cards, Chips, Rows and Grid (Carousel, Hero, Banner, Mosaic, Tiles, Timeline, Lines, Compact).
// Only numbers live here, so they are tested on their own (SectionShapesTest); ui/SectionLooks.kt draws with them.

object SectionShapes {
    /** How many tiles fit a box [widthDp] wide: squares about 92dp wide with 10dp between them, never fewer than two. */
    fun tileColumns(widthDp: Float): Int = max(2, ((widthDp + 10f) / 102f).toInt())

    /** The width, in dp, of one carousel card in a box [boxWidthDp] wide: most of the width, so the next card peeks in, but never wider than the box or narrower than 140. */
    fun carouselWidth(boxWidthDp: Float): Float = min(boxWidthDp, max(140f, boxWidthDp * .86f))

    /**
     * The height of the big card and of the strip under it in the Hero layout, in dp, for a box [boxHeightDp] tall (0 is automatic: 176 and 104).
     * With a height the big card takes about three fifths and the strip the rest, with the strip never under 72.
     */
    fun heroHeights(boxHeightDp: Int): Pair<Float, Float> {
        if (boxHeightDp <= 0) return 176f to 104f
        val strip = max(72f, boxHeightDp * .4f - 6f)
        val hero = max(96f, boxHeightDp - strip - 12f)
        return hero to strip
    }

    /** How tall one mosaic card is, in dp: a box is short, a scrap grows with the length of its text from 120 up to 220. */
    fun mosaicHeight(isBox: Boolean, textLength: Int): Float = if (isBox) 104f else 120f + min(max(textLength, 0), 240) / 240f * 100f

    /**
     * Shares things between two columns for the Mosaic layout: each one, in order, goes under the column that is shorter so far (the left one when they are even).
     * [heights] is how tall each thing is. Returns the positions that go in the left column and in the right column, each in their original order.
     */
    fun splitColumns(heights: List<Float>): Pair<List<Int>, List<Int>> {
        val left = ArrayList<Int>(); val right = ArrayList<Int>()
        var lh = 0f; var rh = 0f
        heights.forEachIndexed { i, h -> if (lh <= rh) { left.add(i); lh += h } else { right.add(i); rh += h } }
        return left to right
    }

    /** How many lines of a scrap's text fit a card [heightDp] tall whose title and date take [usedDp]; at least one. */
    fun previewLines(heightDp: Float, usedDp: Float, lineDp: Float = 18f): Int = max(1, ((heightDp - usedDp) / lineDp).toInt())
}

/**
 * The section layouts that came after Cards, Chips, Rows and Grid, offered as more designs of the parts of Home (Continue, Boxes, Pinned, Recent; see HomeStyles.kt).
 * They are added to the end of a part's own designs, so a choice already made keeps its number. A part is named by the key of its style choice, so this does not need the
 * list of choices itself. Recent already has a Compact of its own, so it does not get a second one, and Continue is a single scrap, so only the two layouts that suit one.
 */
object PartShapes {
    private val added: List<SectionLayout> = SectionLayout.entries.drop(4)

    /** The layouts added after the part's own designs, in order. Empty for a style choice that has none. */
    fun layouts(styleKey: String): List<SectionLayout> = when (styleKey) {
        "boxesStyle", "pinnedStyle" -> added
        "recentStyle" -> added.filter { it != SectionLayout.Compact }
        "continueStyle" -> listOf(SectionLayout.Hero, SectionLayout.Banner)
        else -> emptyList()
    }

    /** How many designs the part had of its own: the number of the first added layout. */
    fun firstAdded(styleKey: String): Int = when (styleKey) {
        "boxesStyle", "pinnedStyle", "continueStyle" -> 3
        "recentStyle" -> 2
        else -> Int.MAX_VALUE
    }

    /** The layout chosen by option number [index] of the part's style choice, or null when it is one of the part's own designs. */
    fun layoutFor(styleKey: String, index: Int): SectionLayout? = layouts(styleKey).getOrNull(index - firstAdded(styleKey))

    fun labels(styleKey: String): List<String> = layouts(styleKey).map { it.label }
    fun hints(styleKey: String): List<String> = layouts(styleKey).map { it.note }
}
