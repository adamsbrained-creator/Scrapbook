package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// Skins of Home (see HomeSkins.kt): a card at the top of Customize home shows the skin you are wearing and opens this page, where you put on another one,
// make a new one from the Home you have now, rename, copy, reset or delete. Putting a skin on changes Home at once, and what you change while wearing it stays with it.

/** The card at the top of Customize home: the skin being worn, and a way to the list of skins. */
@Composable
fun SkinCard(name: String, changed: Boolean, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Skins, wearing $name", onOpen).padding(start = 18.dp, end = 12.dp).heightIn(min = 72.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic("layout", 24.dp, Sb.ink)
        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
            Text("Skin", fontSize = 13.sp, color = Sb.mute)
            Text(name + if (changed) " · changed" else "", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("Change", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
        Ic("chevron", 18.dp, Sb.mute)
    }
}

/** How tall the bar for each part of Home is in a skin's small picture. */
private fun barHeight(e: HomeElement): Dp = when (e) {
    HomeElement.Header -> 5.dp
    HomeElement.Greeting -> 9.dp
    HomeElement.Capture -> 11.dp
    HomeElement.Continue -> 8.dp
    HomeElement.Sort -> 6.dp
    HomeElement.Boxes -> 7.dp
    HomeElement.Pinned -> 14.dp
    HomeElement.Recent -> 18.dp
}

/** A skin as a tiny page: one bar for each part that shows, in order, and a tinted bar for each section. */
@Composable
private fun SkinThumb(skin: HomeSkin) {
    // The picture shows the look too: the page tint, the accent color, how round, outlined or flat the cards are, and how close together.
    val look = remember(skin.values) { HomeLook.decode(skin.values[SkinKeys.LOOK]) }
    val acc = look.accentChoice?.let { Themes[it % Themes.size].acc } ?: LocalSb.current.acc
    val page = homePageColor(look.tint, acc)
    val shape = RoundedCornerShape((3f * look.cornerScale).coerceIn(1f, 6f).dp)
    val layout = skin.layout
    val slots = remember(skin.values) { HomeSections.slots(layout.order, skin.sections).filter { it !is HomeSlot.Part || it.element !in layout.hidden } }
    Column(Modifier.size(width = 60.dp, height = 92.dp).clip(RoundedCornerShape(10.dp)).background(page).padding(6.dp), Arrangement.spacedBy(listOf(2, 3, 5)[look[HomeLookKey.Spacing]].dp)) {
        slots.forEach { s ->
            val (h, c) = when (s) {
                is HomeSlot.Part -> barHeight(s.element) to Sb.line
                is HomeSlot.Sec -> 12.dp to acc.copy(alpha = .55f)
            }
            val bar = Modifier.fillMaxWidth().height(h).clip(shape)
            Box(when (look.card) {
                1 -> bar.border(1.dp, if (s is HomeSlot.Part) Sb.mute.copy(alpha = .5f) else acc, shape)
                2 -> bar.background(c).background(acc.copy(alpha = .18f))
                3 -> bar.background(c.copy(alpha = .3f))
                else -> bar.background(c)
            })
        }
    }
}

private fun summaryOf(skin: HomeSkin): String {
    val layout = skin.layout
    val parts = layout.order.count { it !in layout.hidden }
    val secs = skin.sections.size
    return "$parts ${if (parts == 1) "part" else "parts"}" + if (secs > 0) " · $secs ${if (secs == 1) "section" else "sections"}" else ""
}

@Composable
internal fun SkinsPage(
    skins: HomeSkins, onBack: () -> Unit, onWear: (String) -> Unit, onNew: () -> Unit, onReady: (String) -> Unit, onImport: (HomeSkin) -> Unit,
    schedule: SkinSchedule?, onRules: (List<ScheduleRule>) -> Unit,
    onRestore: (HomeSkin, Int) -> Unit, onRestoreValues: (String, Map<String, String>) -> Unit,
    onRename: (String, String) -> Unit, onCopy: (String) -> Unit, onReset: (String) -> Unit, onDelete: (String) -> Unit,
) {
    val haptics = LocalHaptics.current
    var menuFor by remember { mutableStateOf<String?>(null) }
    var importing by remember { mutableStateOf(false) }
    var scheduling by remember { mutableStateOf(false) }
    var undo by remember { mutableStateOf<SkinUndo?>(null) }      // the last delete or reset, for a few seconds
    BackHandler { onBack() }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                CircleBtn("Back to Customize home", onBack) { Ic("back", 22.dp, Sb.ink) }
                Text("Skins", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
            }
            Text("A skin is a whole Home: which parts show and where, their designs, your sections, the header and the add button. Tap one to wear it. What you change while wearing a skin stays with it.",
                Modifier.padding(horizontal = 24.dp, vertical = 10.dp), fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute)
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(skins.skins, key = { it.id }) { skin ->
                    val worn = skin.id == skins.current.id
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.card).tap(if (worn) "${skin.name}, worn now" else "Wear ${skin.name}") { if (!worn) { haptics.confirm(); onWear(skin.id) } }
                        .semantics { selected = worn }.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 6.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        SkinThumb(skin)
                        Column(Modifier.weight(1f)) {
                            Text(skin.name, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(summaryOf(skin), fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (worn) Text(if (skin.builtIn && skin.changed) "Worn now · changed" else "Worn now", Modifier.padding(top = 4.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = accentText(LocalSb.current.acc))
                        }
                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Options for ${skin.name}") { menuFor = skin.id }, Alignment.Center) { Ic("more", 22.dp, Sb.mute) }
                    }
                }
                item(key = "new") {
                    Text("New skin from this Home", Modifier.fillMaxWidth().padding(top = 4.dp).clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f))
                        .tap("Make a new skin from Home as it is now and wear it") { haptics.confirm(); onNew() }.padding(vertical = 16.dp),
                        color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                }
                item(key = "import") {
                    Text("Add a skin from a code", Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f))
                        .tap("Add a skin that someone shared as a code") { haptics.tick(); importing = true }.padding(vertical = 16.dp),
                        color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                }
                item(key = "schedule") {
                    val rules = schedule?.rules.orEmpty()
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Scheduled skins, ${if (rules.isEmpty()) "off" else "${rules.size} set"}") { haptics.tick(); scheduling = true }
                        .padding(start = 18.dp, end = 12.dp).heightIn(min = 68.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        Ic("clock", 24.dp, Sb.ink)
                        Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                            Text("Schedule", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
                            Text(if (rules.isEmpty()) "Wear a skin at certain times. Off." else rules.joinToString(" · ") { r -> (skins.get(r.skinId)?.name ?: "Missing skin") + " " + SkinSchedule.timeText(r.start) + "\u2013" + SkinSchedule.timeText(r.end) },
                                fontSize = 13.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Ic("chevron", 18.dp, Sb.mute)
                    }
                }
                item(key = "ready-label") { SectionLabel("Ready-made") }
                items(ReadySkins.all, key = { "ready-" + it.key }) { ready ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Add ${ready.name} to your skins and wear it") { haptics.confirm(); onReady(ready.key) }
                        .padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 14.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        SkinThumb(HomeSkin(ready.key, ready.name, ready.values))
                        Column(Modifier.weight(1f)) {
                            Text(ready.name, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(ready.blurb, fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                        Text("Add", Modifier.clip(CircleShape).background(Sb.ink).padding(horizontal = 18.dp, vertical = 10.dp), color = Sb.card, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
                item(key = "ready-note") { HomeFooter("A ready-made skin is added to your skins as a copy and worn. You can change or delete the copy like any other skin; the ready-made one stays here.") }
            }
        }
        if (importing) ImportSkinSheet(onImport) { importing = false }
        if (scheduling) ScheduleSheet(skins, schedule?.rules.orEmpty(), onRules) { scheduling = false }
        menuFor?.let { id -> skins.get(id)?.let { skin ->
            SkinMenu(skin, skins, { menuFor = null }, onWear, onRename, onCopy,
                onReset = { sid -> skins.get(sid)?.let { undo = SkinUndo.Reset(it) }; onReset(sid) },
                onDelete = { sid -> skins.get(sid)?.let { undo = SkinUndo.Deleted(it, skins.skins.indexOfFirst { s -> s.id == sid }) }; onDelete(sid) })
        } }
        undo?.let { u ->
            LaunchedEffect(u) { delay(7000); if (undo == u) undo = null }
            Row(Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Sb.ink).padding(start = 20.dp, end = 6.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                Text(u.message, Modifier.weight(1f).padding(vertical = 14.dp), color = Sb.card, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Undo", Modifier.clip(CircleShape).tap("Undo") {
                    when (u) { is SkinUndo.Deleted -> onRestore(u.skin, u.index); is SkinUndo.Reset -> onRestoreValues(u.skin.id, u.skin.values) }
                    undo = null
                }.padding(horizontal = 16.dp, vertical = 12.dp), color = Sb.card, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** What can be done with one skin. */
@Composable
private fun SkinMenu(
    skin: HomeSkin, skins: HomeSkins, onDone: () -> Unit, onWear: (String) -> Unit,
    onRename: (String, String) -> Unit, onCopy: (String) -> Unit, onReset: (String) -> Unit, onDelete: (String) -> Unit,
) {
    var name by remember { mutableStateOf(skin.name) }
    var sure by remember { mutableStateOf(false) }
    val worn = skin.id == skins.current.id
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    Sheet(skin.name, onDone) {
        if (!skin.builtIn) {
            SheetLabel("Name")
            InputBox { Field(name, { name = it.take(HomeSkins.MAX_NAME); onRename(skin.id, name) }, "Skin name", 18.sp, headFont(), FontWeight.Medium) }
        }
        SheetGroup {
            if (!worn) { ActionRow("check", "Wear this skin") { onWear(skin.id); onDone() }; SheetDivider(46.dp) }
            ActionRow("page", "Make a copy") { onCopy(skin.id); onDone() }
            SheetDivider(46.dp)
            if (!skin.builtIn || skin.changed) {
                ActionRow("link", "Copy as a code to share", "Paste it in a message; anyone can add it from the Skins page") {
                    clipboard.setText(AnnotatedString(SkinShare.export(skin)))
                    Toast.makeText(ctx, "Skin code copied", Toast.LENGTH_SHORT).show()
                }
                SheetDivider(46.dp)
            }
            ActionRow("undo", "Back to the classic look", if (worn) "Home changes now" else "Only this skin changes") { onReset(skin.id); onDone() }
            if (skins.canDelete(skin.id)) {
                SheetDivider(46.dp)
                if (sure) ActionRow("trash", "Tap again to delete this skin", "Your Home does not change", danger = true) { onDelete(skin.id); onDone() }
                else ActionRow("trash", "Delete", danger = true) { sure = true }
            }
        }
        if (skin.builtIn) SheetNote("Classic is the look Home started with. It stays in the list; reset brings it back if you changed it.")
        else if (worn) SheetNote("This skin is worn now, so it cannot be deleted. Wear another skin first.")
    }
}

/** Add a skin from a code someone sent: paste it, see what skin it is, and add it next to yours (it is not put on). */
@Composable
private fun ImportSkinSheet(onAdd: (HomeSkin) -> Unit, onDone: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    var added by remember { mutableStateOf(false) }
    val skin = remember(text) { SkinShare.parse(text) }
    Sheet("Add a skin from a code", onDone, doneLabel = "Close") {
        SheetNote("Paste a skin code that someone sent you, or one you copied on another phone.")
        InputBox { Field(text, { text = it.take(SkinShare.MAX_CODE); added = false }, "Paste the code here", 14.sp, headFont(), modifier = Modifier.heightIn(min = 72.dp, max = 160.dp)) }
        SheetGroup { ActionRow("page", "Paste from the clipboard") { text = clipboard.getText()?.text.orEmpty().take(SkinShare.MAX_CODE); added = false } }
        if (text.isNotBlank()) {
            if (skin == null) SheetNote("That is not a Scrapbook skin code.")
            else SheetGroup {
                ActionRow(if (added) "check" else "plus", if (added) "Added to your skins" else "Add \u201C${skin.name}\u201D", summaryOf(skin)) { if (!added) { onAdd(skin); added = true } }
            }
        }
        SheetNote("A shared skin keeps its look, parts, header, cards and sections that fill themselves. Sections of shortcuts stay behind, because they point at one phone's scraps and boxes.")
    }
}

/** One round button with a sign on it (the minus and plus of a time). */
@Composable
private fun StepButton(sign: String, desc: String, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).background(Sb.line).tapIcon(desc, onClick), Alignment.Center) { Text(sign, fontSize = 22.sp, fontWeight = FontWeight.Medium, color = Sb.ink) }
}

/** A time of day that moves half an hour at a time. */
@Composable
private fun TimeStepper(label: String, minute: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 58.dp).padding(horizontal = 18.dp, vertical = 6.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
        StepButton("\u2212", "$label, half an hour earlier") { onChange(Math.floorMod(minute - 30, 1440)) }
        Text(SkinSchedule.timeText(minute), Modifier.widthIn(min = 64.dp), fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink, textAlign = TextAlign.Center)
        StepButton("+", "$label, half an hour later") { onChange(Math.floorMod(minute + 30, 1440)) }
    }
}

/** The seven days of the week as round switches (Monday first). At least one stays on. */
@Composable
private fun DayChips(days: Int, onChange: (Int) -> Unit) {
    val acc = LocalSb.current.acc
    val letters = listOf("M", "T", "W", "T", "F", "S", "S")
    val names = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), Arrangement.SpaceBetween) {
        letters.forEachIndexed { i, l ->
            val on = (days shr i) and 1 == 1
            Box(Modifier.size(42.dp).clip(CircleShape).background(if (on) acc else Sb.line).tap("${names[i]}, ${if (on) "on" else "off"}") { val next = days xor (1 shl i); if (next != 0) onChange(next) }
                .semantics { selected = on }, Alignment.Center) {
                Text(l, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = if (on) onAccent(acc) else Sb.ink)
            }
        }
    }
}

/** The scheduled skins: the list of times, and one time to change. Every change is saved at once (see SkinSchedule.kt for how a time acts). */
@Composable
private fun ScheduleSheet(skins: HomeSkins, rules: List<ScheduleRule>, onRules: (List<ScheduleRule>) -> Unit, onDone: () -> Unit) {
    var editing by remember { mutableStateOf<String?>(null) }
    val rule = rules.firstOrNull { it.id == editing }
    fun change(r: ScheduleRule) = onRules(rules.map { if (it.id == r.id) r else it })
    fun skinName(r: ScheduleRule) = skins.get(r.skinId)?.name ?: "Missing skin"
    fun whenText(r: ScheduleRule) = SkinSchedule.timeText(r.start) + " \u2013 " + SkinSchedule.timeText(r.end) + " \u00B7 " + SkinSchedule.daysText(r.days)
    Sheet(if (rule == null) "Schedule" else skinName(rule), { if (editing != null) editing = null else onDone() }, doneLabel = if (rule == null) "Done" else "Back") {
        if (rule == null) {
            SheetNote("Wear a skin at certain times, for example a quiet one at night. When a time begins the skin goes on, and when it ends the skin you were wearing comes back. In between, change skins whenever you like.")
            if (rules.isNotEmpty()) SheetGroup {
                rules.forEachIndexed { i, r ->
                    if (i > 0) SheetDivider(46.dp)
                    ActionRow("clock", skinName(r), whenText(r)) { editing = r.id }
                }
            }
            if (rules.size < ScheduleRule.MAX_RULES) SheetGroup {
                ActionRow("plus", "Add a time") {
                    val n = ScheduleRule(SkinSchedule.newId(), skins.skins.firstOrNull { it.id != skins.current.id }?.id ?: skins.current.id, 21 * 60, 7 * 60)
                    onRules(rules + n); editing = n.id
                }
            }
            SheetNote("The clock is checked while Home is open. Open Home after a time has begun and the skin goes on then.")
        } else {
            SheetLabel("Skin")
            SheetGroup {
                skins.skins.forEachIndexed { i, s ->
                    if (i > 0) SheetDivider(18.dp)
                    OptionRow(s.name, s.id == rule.skinId) { change(rule.copy(skinId = s.id)) }
                }
            }
            SheetLabel("Time")
            SheetGroup {
                TimeStepper("From", rule.start) { change(rule.copy(start = it)) }
                SheetDivider(18.dp)
                TimeStepper("Until", rule.end) { change(rule.copy(end = it)) }
            }
            SheetNote(if (rule.start == rule.end) "The same time twice means the whole day." else if (rule.start > rule.end) "This one runs through the night, into the next morning." else "Between these two times, the same day.")
            SheetLabel("Days")
            DayChips(rule.days) { change(rule.copy(days = it)) }
            Spacer(Modifier.height(4.dp))
            SheetGroup { ActionRow("trash", "Delete this time", danger = true) { onRules(rules.filter { it.id != rule.id }); editing = null } }
        }
    }
}

/** The last thing taken from a skin, so it can be given back: a deleted skin with its place in the list, or a skin before it was reset. */
private sealed interface SkinUndo {
    val message: String
    class Deleted(val skin: HomeSkin, val index: Int) : SkinUndo { override val message: String get() = "Deleted \u201C${skin.name}\u201D" }
    class Reset(val skin: HomeSkin) : SkinUndo { override val message: String get() = "${skin.name} is back to the classic look" }
}
