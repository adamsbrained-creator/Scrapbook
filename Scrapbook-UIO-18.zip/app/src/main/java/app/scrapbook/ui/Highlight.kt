package app.scrapbook.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import app.scrapbook.matchRanges

/** [text] with every occurrence of the search [terms] marked. With no terms it is just the text. */
fun hlTerms(text: String, terms: List<String>, mark: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    matchRanges(text, terms).forEach { r ->
        append(text.substring(i, r.first))
        withStyle(SpanStyle(background = mark)) { append(text.substring(r.first, r.last + 1)) }
        i = r.last + 1
    }
    append(text.substring(i))
}

/** The ink of highlighted text: dark on the bright marker, on a light page and on a dark one alike. */
val MARKER_INK = Color(0xFF181818)

/**
 * The highlighter's color (the "ab" tool, ==text==): the page's accent made bright and clear. It is the same solid color on a light page and a dark one, so a
 * highlight looks alike in both (it used to be the accent at a third of its strength, which was pale on light pages and dull on dark ones).
 */
fun markerColor(acc: Color): Color {
    val hsv = FloatArray(3); android.graphics.Color.colorToHSV(acc.toArgb(), hsv)
    hsv[1] = if (hsv[1] < .08f) hsv[1] else hsv[1].coerceIn(.45f, .7f)   // a gray accent stays gray; a colored one gets vivid
    hsv[2] = 1f
    var c = Color(android.graphics.Color.HSVToColor(hsv))
    var k = 0f
    while (c.luminance() < .45f && k < .6f) { k += .1f; c = lerp(Color(android.graphics.Color.HSVToColor(hsv)), Color.White, k) }   // deep blues and purples are lightened until dark ink reads on them
    return c
}

/** The look of highlighted text: the bright marker behind it and dark ink on it. */
fun markerStyle(acc: Color) = SpanStyle(background = markerColor(acc), color = MARKER_INK)
