package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinExtrasTest {
    @Test fun theClassicLookHasNoTintAndTheAppsAccent() {
        assertEquals(0, HomeLook.Default.tint)
        assertNull(HomeLook.Default.accentChoice)
        assertEquals("", HomeLook.Default.encode())
    }

    @Test fun theAccentChoiceIsAPlaceInTheListOfAppAccents() {
        assertEquals(0, HomeLook.Default.with(HomeLookKey.Accent, 1).accentChoice)
        assertEquals(6, HomeLook.Default.with(HomeLookKey.Accent, 7).accentChoice)
        assertNull(HomeLook.Default.with(HomeLookKey.Accent, 3).with(HomeLookKey.Accent, 0).accentChoice)
        assertEquals(6, HomeLook.Default.with(HomeLookKey.Accent, 99).accentChoice)
    }

    @Test fun thereIsOneAccentOptionForEveryAppAccentPlusTheAppsOwn() {
        assertEquals(1 + 7, HomeLookKey.Accent.options.size)
        assertEquals("Same as the app", HomeLookKey.Accent.options[0])
        assertEquals(listOf("Coral", "Teal", "Amber", "Violet", "Green", "Pink", "Blue"), HomeLookKey.Accent.options.drop(1))
    }

    @Test fun theTintIsReadBack() {
        assertEquals(2, HomeLook.Default.with(HomeLookKey.Tint, 2).tint)
        assertEquals(4, HomeLook.Default.with(HomeLookKey.Tint, 40).tint)
        assertEquals(HomeLook.Default, HomeLook.Default.with(HomeLookKey.Tint, 3).with(HomeLookKey.Tint, 0))
    }

    @Test fun lookSavedBeforeTintAndAccentStillReadsBack() {
        val old = HomeLook.decode("corners=0,card=3,spacing=2")
        assertEquals(0, old.tint)
        assertNull(old.accentChoice)
        assertEquals("corners=0,card=3,spacing=2", old.encode())
    }

    @Test fun tintAndAccentAreSavedAndReadBack() {
        val l = HomeLook.Default.with(HomeLookKey.Tint, 3).with(HomeLookKey.Accent, 5)
        assertEquals("tint=3,accent=5", l.encode())
        assertEquals(l, HomeLook.decode(l.encode()))
        assertEquals("Cool · Green", l.summary())
    }

    @Test fun nextSkinGoesRoundTheListAndStaysOnTheOnlySkin() {
        val one = HomeSkins.initial(emptyMap())
        assertEquals("classic", one.following.id)
        val (two, a) = one.add("A", emptyMap())
        val (three, b) = two.add("B", emptyMap())
        assertEquals(a.id, three.following.id)
        assertEquals(b.id, three.activate(a.id)!!.following.id)
        assertEquals("classic", three.activate(b.id)!!.following.id)
    }

    @Test fun doubleTapCanPutTheNextSkinOnAndOldChoicesAreKept() {
        assertEquals("Next skin", GesturePrefs.DOUBLE_TAP_OPTIONS.last())
        assertEquals(3, GesturePrefs.DOUBLE_TAP_OPTIONS.lastIndex)
        assertEquals(3, GesturePrefs.decode("1,1,1,1,1,1,1,3").doubleTap)
        assertEquals(2, GesturePrefs.decode("1,1,1,1,1,1,1,2").doubleTap)
        assertEquals(GesturePrefs(doubleTap = 3), GesturePrefs.decode(GesturePrefs(doubleTap = 3).encode()))
        assertTrue(GesturePrefs.DOUBLE_TAP_OPTIONS.size == GesturePrefs.DOUBLE_TAP_OPTIONS.toSet().size)
    }
}
