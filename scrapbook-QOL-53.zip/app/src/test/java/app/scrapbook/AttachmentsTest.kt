package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AttachmentsTest {
    private val pdf = Attachment("file:///data/files/attachments/1_ab/Report.pdf", "Report.pdf", 1234, "application/pdf")
    private val zip = Attachment("file:///data/files/attachments/2_cd/Photos 2026.zip", "Photos 2026.zip", 5_000_000, "application/zip")

    @Test fun attachmentsRoundTrip() = assertEquals(listOf(pdf, zip), listOf(pdf, zip).encodeAll().toAttachments())
    @Test fun noFilesMeansNoAttachments() = assertEquals(emptyList<Attachment>(), "".toAttachments())
    @Test fun brokenLinesAreSkipped() = assertEquals(listOf(pdf), (pdf.encode() + "\nnonsense\n\t\t\t").toAttachments())
    @Test fun badSizeBecomesZero() = assertEquals(0L, parseAttachment("p\tn\tx\tm")?.size)
    @Test fun itemReadsItsFiles() {
        val item = Item(title = "t", body = "", kind = Kind.Note, collection = "Inbox", files = listOf(pdf, zip).encodeAll())
        assertEquals(listOf(pdf, zip), item.attachments())
        assertEquals(emptyList<Attachment>(), Item(title = "t", body = "", kind = Kind.Note, collection = "Inbox").attachments())
    }

    @Test fun pdfIsRecognisedByTypeOrName() {
        assertTrue(pdf.isPdf)
        assertTrue(Attachment("p", "SCAN.PDF", 1, "application/octet-stream").isPdf)
        assertFalse(zip.isPdf)
    }
    @Test fun imagesAreRecognised() {
        assertTrue(Attachment("p", "a.jpg", 1, "image/jpeg").isImage)
        assertFalse(pdf.isImage)
    }
    @Test fun typeLabelIsTheExtension() {
        assertEquals("DOCX", Attachment("p", "Plan.docx", 1, "").typeLabel)
        assertEquals("GZ", Attachment("p", "archive.tar.gz", 1, "").typeLabel)
        assertEquals("FILE", Attachment("p", "notes", 1, "").typeLabel)
    }

    @Test fun displayNamesAreTidied() {
        assertEquals("a b c d", cleanDisplayName("a\tb\nc/d"))
        assertEquals("File", cleanDisplayName(null))
        assertEquals("File", cleanDisplayName("   "))
        assertEquals(120, cleanDisplayName("x".repeat(500)).length)
    }
    @Test fun diskNamesAreSafe() {
        assertEquals("My report _final_.pdf", diskName("My report (final).pdf"))
        assertEquals("notes", diskName("notes"))
        assertFalse(diskName("../../etc/passwd").contains('/'))
        assertEquals("___", diskName("???"))
        assertEquals("file", diskName(""))
    }
    @Test fun sizesAreReadable() {
        assertEquals("0 B", formatSize(0))
        assertEquals("1023 B", formatSize(1023))
        assertEquals("2 KB", formatSize(2048))
        assertEquals("1.5 MB", formatSize(1_572_864))
        assertEquals("100.0 MB", formatSize(MAX_ATTACHMENT_BYTES))
    }
    @Test fun titleFromFileDropsTheExtension() {
        assertEquals("Trip plan", titleFromFileName("Trip plan.pdf"))
        assertEquals("README", titleFromFileName("README"))
        assertEquals(".gitignore", titleFromFileName(".gitignore"))
    }
    @Test fun noMissingTitle() = assertNull(parseAttachment(""))

    @Test fun soundFilesAreRecognisedByTheirType() {
        assertTrue(Attachment("p", "Recording.m4a", 10, Recordings.MIME).isAudio)
        assertTrue(Attachment("p", "Song.mp3", 10, "audio/mpeg").isAudio)
        assertFalse(pdf.isAudio)
    }

    @Test fun durationsShowMinutesAndSeconds() {
        assertEquals("0:00", formatDuration(0))
        assertEquals("0:09", formatDuration(9_400))
        assertEquals("1:23", formatDuration(83_000))
        assertEquals("0:00", formatDuration(-5))
        assertEquals("61:01", formatDuration(3_661_000))
    }
}
