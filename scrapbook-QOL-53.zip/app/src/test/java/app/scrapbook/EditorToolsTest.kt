package app.scrapbook

import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EditorToolsTest {
    // ---- share and copy ----
    @Test fun sharedTextHasNoFormattingCodes() {
        val body = "# Plan\n- [ ] book **flights**\n- [x] pack\n- tea\n1. one\n> quote\n---\n[docs](https://e.com/x)\n{c:ff0000|red} text"
        assertEquals(
            "Trip\n\nPlan\n☐ book flights\n☑ pack\n• tea\n1. one\n> quote\n———\ndocs (https://e.com/x)\nred text",
            plainText("Trip", body),
        )
    }
    @Test fun indentStaysInSharedText() = assertEquals("T\n\n    • item", plainText("T", "- {i:2}item"))
    @Test fun firstLineThatRepeatsTheTitleIsDropped() = assertEquals("Groceries\n\n• milk", plainText("Groceries", "Groceries\n- milk"))
    @Test fun noTitleMeansJustTheText() = assertEquals("a\nb", plainText("", "a\nb"))
    @Test fun noTextMeansJustTheTitle() = assertEquals("T", plainText("T", ""))
    @Test fun aLinkWhoseLabelIsItsAddressIsNotRepeated() = assertEquals("https://e.com", plainText("", "[https://e.com](https://e.com)"))

    // ---- date ----
    @Test fun todayIsWrittenOut() = assertTrue(todayText(1_000_036_800_000L, Locale.US).contains("2001"))
    @Test fun insertReplacesTheSelection() {
        assertEquals(TextEdit("aXYd", 3, 3), insertAt("abcd", 1, 3, "XY"))
        assertEquals(TextEdit("a-b", 2, 2), insertAt("ab", 1, 1, "-"))
    }

    // ---- move lines ----
    @Test fun lineMovesUp() = assertEquals(TextEdit("b\na\nc", 0, 0), moveLines("a\nb\nc", 2, 2, up = true))
    @Test fun lineMovesDownAndCursorFollows() = assertEquals(TextEdit("b\na\nc", 3, 3), moveLines("a\nb\nc", 1, 1, up = false))
    @Test fun firstLineCannotGoUpAndLastCannotGoDown() {
        assertNull(moveLines("a\nb", 0, 0, up = true))
        assertNull(moveLines("a\nb", 3, 3, up = false))
    }
    @Test fun selectedLinesMoveTogether() = assertEquals(TextEdit("b\nc\na\nd", 0, 3), moveLines("a\nb\nc\nd", 2, 5, up = true))
    @Test fun selectionEndingAtTheStartOfALineLeavesThatLineOut() = assertEquals(TextEdit("b\na\nc", 2, 3), moveLines("a\nb\nc", 0, 2, up = false))
    @Test fun numbersStayInPlaceInANumberedList() = assertEquals(TextEdit("1. b\n2. a\n3. c", 3, 3), moveLines("1. a\n2. b\n3. c", 5, 5, up = true))

    // ---- checklists ----
    private val list = "- [ ] a\n- [x] b\n- [ ] c\n- [x] d"
    @Test fun countsItemsAndTicks() = assertEquals(4 to 2, checklistCounts(list))
    @Test fun tickedItemsGoToTheBottomInOrder() = assertEquals(TextEdit("- [ ] a\n- [ ] c\n- [x] b\n- [x] d", 0, 0), applyChecklist(list, 0, CheckAction.TickedToBottom))
    @Test fun tickedItemsCanBeCleared() = assertEquals(TextEdit("- [ ] a\n- [ ] c", 0, 0), applyChecklist(list, 0, CheckAction.ClearTicked))
    @Test fun everythingCanBeUnticked() = assertEquals(TextEdit("- [ ] a\n- [ ] b\n- [ ] c\n- [ ] d", 0, 0), applyChecklist(list, 0, CheckAction.UntickAll))
    @Test fun nothingToDoGivesNull() {
        assertNull(applyChecklist("- [ ] a\n- [x] b", 0, CheckAction.TickedToBottom))
        assertNull(applyChecklist("just text", 0, CheckAction.UntickAll))
    }
    @Test fun onlyTheListUnderTheCursorIsTidied() = assertEquals(TextEdit("\n- [x] b", 0, 0), applyChecklist("- [x] a\n\n- [x] b", 0, CheckAction.ClearTicked))
    @Test fun cursorOutsideAnyListTidiesEveryList() = assertEquals(TextEdit("\nplain\n", 0, 0), applyChecklist("- [x] a\n\nplain\n\n- [x] b", 10, CheckAction.ClearTicked))

    // ---- find and replace ----
    @Test fun plainTextMatchesAreAllFound() = assertEquals(listOf(0..2, 4..6, 8..10), visibleOccurrences("Red red RED", "red", { it }, "Red red RED"))
    @Test fun marksAroundAMatchDoNotHideIt() {
        // "**bold** x" is shown as "bold x"; the two stars on each side take no room.
        val toShown = { i: Int -> when { i <= 2 -> 0; i <= 6 -> i - 2; i <= 8 -> 4; else -> i - 4 } }
        assertEquals(listOf(2..5), visibleOccurrences("**bold** x", "bold", toShown, "bold x"))
    }
    @Test fun hiddenCodesAreNeverMatched() {
        // "{c:ff0000|red}" is shown as "red": the color code takes no room.
        val toShown = { i: Int -> when { i <= 10 -> 0; i <= 13 -> i - 10; else -> 3 } }
        assertEquals(emptyList<IntRange>(), visibleOccurrences("{c:ff0000|red}", "ff", toShown, "red"))
        assertEquals(listOf(10..12), visibleOccurrences("{c:ff0000|red}", "red", toShown, "red"))
    }
    @Test fun rangesAreReplacedFromTheEnd() {
        assertEquals("a X X", replaceRanges("a red red", listOf(2..4, 6..8), "X"))
        assertEquals("a longer longer", replaceRanges("a red red", listOf(6..8, 2..4), "longer"))
    }
}
