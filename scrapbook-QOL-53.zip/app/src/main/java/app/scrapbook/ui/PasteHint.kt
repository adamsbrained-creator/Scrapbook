package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

/** A paste the editor offered to tidy: what was offered, and where the pasted text sits in the body. */
data class PasteHint(val offer: PasteOffer, val range: IntRange)

/** The small offer above the toolbar after a paste: what was recognized, a button to format it, and a cross to dismiss it. It leaves by itself. */
@Composable
fun PasteHintBar(offer: PasteOffer, onApply: () -> Unit, onDismiss: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
        Row(Modifier.clip(CircleShape).background(Sb.card), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.tap(offer.action, onApply).padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(offer.what, fontSize = 12.sp, color = Sb.mute, maxLines = 1); Spacer(Modifier.width(10.dp))
                Text(offer.action, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Sb.ink, maxLines = 1)
            }
            Box(Modifier.tap("Dismiss", onDismiss).padding(horizontal = 14.dp, vertical = 12.dp)) { Ic("close", 16.dp, Sb.mute) }
        }
    }
}
