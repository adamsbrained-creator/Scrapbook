package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import app.scrapbook.*
import kotlin.math.abs

/**
 * Drag to reorder, for a short row or column of things on the page (the parts of a scrap, its photos, its files).
 * The thing being dragged follows the finger; when its leading edge passes the middle of its neighbour the two swap places and the dragged one keeps
 * following the finger. Each thing needs [reorderLayer] (so its size is known and it can float) and a [reorderGesture] (what starts the drag).
 */
@Stable
class DragReorder(val vertical: Boolean, private val gap: Float = 0f) {
    /** The key of the thing being dragged, or null. */
    var active: Any? by mutableStateOf(null)
        private set
    /** How far the dragged thing is from the place it sits in the layout, along the row or column. */
    var offset: Float by mutableFloatStateOf(0f)
        private set
    private val sizes = HashMap<Any, Float>()
    private var started = false
    private var order = mutableListOf<Any>()   // the things in the order they have right now, kept up to date by the swaps of this drag

    internal fun measured(key: Any, px: Float) { sizes[key] = px }
    private fun sizeOf(key: Any) = sizes[key] ?: 0f

    internal fun start(key: Any, keys: List<Any>) { order = keys.toMutableList(); active = key; offset = 0f; started = false }
    internal fun end() { active = null; offset = 0f }

    /** Moves the dragged thing by [delta] and swaps it with its neighbours as it passes their middles. [onFirst] runs once, just before the first swap of a drag. The indexes given to [onMove] always match the order the things have after the swaps so far. */
    internal fun drag(delta: Float, onMove: (from: Int, to: Int) -> Unit, onFirst: () -> Unit) {
        val key = active ?: return
        offset += delta
        var guard = order.size
        while (guard-- > 0) {
            val i = order.indexOf(key)
            if (i < 0) break
            if (i < order.lastIndex && offset > gap + sizeOf(order[i + 1]) / 2f) {
                val next = order[i + 1]
                if (!started) { started = true; onFirst() }
                onMove(i, i + 1); order.add(i + 1, order.removeAt(i)); offset -= sizeOf(next) + gap
            } else if (i > 0 && offset < -(gap + sizeOf(order[i - 1]) / 2f)) {
                val prev = order[i - 1]
                if (!started) { started = true; onFirst() }
                onMove(i, i - 1); order.add(i - 1, order.removeAt(i)); offset += sizeOf(prev) + gap
            } else break
        }
    }
}

/** Put on each thing in the row or column: reports its size, and lifts it a little and moves it with the finger while it is the one being dragged. */
@Composable
fun Modifier.reorderLayer(state: DragReorder, key: Any): Modifier {
    val dragging = state.active == key
    return this
        .onSizeChanged { state.measured(key, if (state.vertical) it.height.toFloat() else it.width.toFloat()) }
        .zIndex(if (dragging) 1f else 0f)
        .graphicsLayer {
            if (dragging) {
                if (state.vertical) translationY = state.offset else translationX = state.offset
                scaleX = 1.03f; scaleY = 1.03f
            }
        }
}

/**
 * What starts the drag: a long press on the thing itself, or (with [handle]) just touching and moving, for a small grip. [keys] are the things in their
 * current order; [onMove] is told "from, to" for each swap; [onFirst] runs before the first swap of a drag (the place to record an Undo step).
 * With [onHold], holding without moving calls it instead, so a hold that used to mean something still does.
 */
@Composable
fun Modifier.reorderGesture(
    state: DragReorder, key: Any, keys: List<Any>, enabled: Boolean,
    onMove: (from: Int, to: Int) -> Unit, onFirst: () -> Unit = {}, onHold: (() -> Unit)? = null, handle: Boolean = false,
): Modifier {
    val haptics = LocalHaptics.current
    val curKeys by rememberUpdatedState(keys)
    val curMove by rememberUpdatedState(onMove)
    val curFirst by rememberUpdatedState(onFirst)
    val curHold by rememberUpdatedState(onHold)
    return this.pointerInput(key, enabled, handle) {
        if (!enabled) return@pointerInput
        var travel = 0f
        val begin: (Offset) -> Unit = { state.start(key, curKeys); travel = 0f; haptics.tick() }
        val step: (Offset) -> Unit = { amount ->
            val d = if (state.vertical) amount.y else amount.x
            travel += abs(d)
            state.drag(d, curMove, curFirst)
        }
        val finish: () -> Unit = {
            val still = travel < viewConfiguration.touchSlop
            state.end()
            if (still) curHold?.invoke()
        }
        if (handle) detectDragGestures(onDragStart = begin, onDragEnd = { finish() }, onDragCancel = { state.end() }) { change, amount -> change.consume(); step(amount) }
        else detectDragGesturesAfterLongPress(onDragStart = begin, onDragEnd = { finish() }, onDragCancel = { state.end() }) { change, amount -> change.consume(); step(amount) }
    }
}

/** The small grip above a part of the page: touch it and move to carry that part up or down the page. */
@Composable
fun DragGrip(state: DragReorder, key: Any, keys: List<Any>, onMove: (from: Int, to: Int) -> Unit) {
    Box(Modifier.fillMaxWidth().height(26.dp), Alignment.Center) {
        Box(Modifier.size(72.dp, 26.dp).reorderGesture(state, key, keys, true, onMove, handle = true).semantics { contentDescription = "Drag to move this part of the page" }, Alignment.Center) {
            Box(Modifier.size(34.dp, 4.dp).clip(CircleShape).background(Sb.mute.copy(alpha = .45f)))
        }
    }
}
