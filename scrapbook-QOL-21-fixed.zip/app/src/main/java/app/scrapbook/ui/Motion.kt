package app.scrapbook.ui

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.navigation.NavBackStackEntry
import kotlinx.coroutines.delay

// Light motion used across the app: a soft press, items that fade up when a screen opens, and one place to keep the timings.
// Everything here is short (under about 350 ms) and never blocks a tap.

/** Shrinks the element a little while a finger is on it and springs back. Put it FIRST in the modifier chain, so the background and clip scale too. Watches touches without consuming them, so taps, holds and scrolling still work. */
fun Modifier.pressScale(to: Float = .97f): Modifier = composed {
    var down by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (down) to else 1f, spring(dampingRatio = .65f, stiffness = 700f), label = "pressScale")
    this.graphicsLayer { scaleX = s; scaleY = s }.pointerInput(Unit) {
        awaitEachGesture {
            val first = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            down = true
            do {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                // Dragging away (a scroll, say) lets go of the press.
                if (ev.changes.any { (it.position - first.position).getDistance() > viewConfiguration.touchSlop }) down = false
            } while (ev.changes.any { it.pressed })
            down = false
        }
    }
}

/** Remembers which items of one screen visit have already faded in, so scrolling back up or coming back to the screen does not replay it. */
class EnterState {
    val seen = HashSet<Any>()
    val born = SystemClock.uptimeMillis()
}

val LocalEnter = compositionLocalOf<EnterState?> { null }

/** Gives a screen its own EnterState, kept per back-stack entry (so going Back to a screen does not re-animate it). */
@Composable
fun Visit(states: MutableMap<String, EnterState>, entry: NavBackStackEntry, content: @Composable () -> Unit) {
    val st = states.getOrPut(entry.id) { EnterState() }
    CompositionLocalProvider(LocalEnter provides st, content = content)
}

/**
 * Fades and lifts an item in the first time it shows on a screen. While the screen is opening, the items start one after another
 * (the first eight, 45 ms apart); an item that arrives later, like a new scrap, just fades in. Put it FIRST in the modifier chain.
 * [key] must be stable and unique on that screen.
 */
@Composable
fun Modifier.appear(key: Any): Modifier {
    val st = LocalEnter.current ?: return this
    val first = remember(key) { st.seen.add(key) }
    if (!first) return this
    val wait = remember(key) { if (SystemClock.uptimeMillis() - st.born < 450) (st.seen.size - 1).coerceIn(0, 7) * 45L else 0L }
    val p = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { delay(wait); p.animateTo(1f, tween(300, easing = FastOutSlowInEasing)) }
    return this.graphicsLayer { alpha = p.value; translationY = (1f - p.value) * 14.dp.toPx() }
}
