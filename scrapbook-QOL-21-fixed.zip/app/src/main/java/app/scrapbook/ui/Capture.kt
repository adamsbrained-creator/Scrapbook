package app.scrapbook.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

/** The box that things shared from Paperback go to. It is made the first time you save one. */
private const val PAPERBACK_BOX = "Paperback"

/** Opened when another app shares text, a link or images to Scrapbook. */
@Composable
fun CaptureScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val inc by vm.incoming.collectAsState()
    val src = inc
    BackHandler(enabled = src != null) { vm.clearIncoming() }
    if (src == null) { LaunchedEffect(Unit) { nav.popBackStack() }; return }
    val hasImage = src.images.isNotEmpty()
    val kind = classifyShare(src.text, hasImage)
    val initial = remember(src) { shareTitle(src.subject, src.text, hasImage) }
    var title by remember(src) { mutableStateOf(initial) }
    var body by remember(src) { mutableStateOf(src.text) }
    val fromPaperback = "readest://" in src.text
    var shelf by remember(src) { mutableStateOf(if (fromPaperback) PAPERBACK_BOX else "Inbox") }
    var img by remember(src) { mutableStateOf<String?>(null) }
    LaunchedEffect(src) { if (isUrl(src.text) && src.subject.isBlank()) vm.fetchTitle(src.text.trim()) { t2 -> if (title == initial) title = t2 } }
    LaunchedEffect(src) { src.images.firstOrNull()?.let { u -> vm.importImage(u) { p -> img = p } } }
    // Files (a PDF, a zip...) shared in are copied into the app first; Save waits until every one has been tried.
    val ctx = LocalContext.current
    var attached by remember(src) { mutableStateOf(emptyList<Attachment>()) }
    var filesDone by remember(src) { mutableIntStateOf(0) }
    LaunchedEffect(src) {
        src.files.forEach { u ->
            vm.importFile(u, failed = { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); filesDone++ }) { a ->
                attached = attached + a; filesDone++
                // A file shared with no words of its own is titled after the file.
                if (title == initial && src.text.isBlank() && src.subject.isBlank()) title = titleFromFileName(a.name)
            }
        }
    }
    val ready = (!hasImage || img != null) && filesDone >= src.files.size

    val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    fun save() {
        if (!ready) return
        if (shelf == PAPERBACK_BOX && vm.shelves.value.none { it.name == PAPERBACK_BOX }) vm.saveShelf(Shelf(PAPERBACK_BOX, "Quotes and notes from my books.", 0))
        val color = (System.currentTimeMillis() % 5).toInt() + 1
        vm.save(Item(title = title.ifBlank { "Untitled" }, body = body, kind = kind, collection = shelf, imageUri = img, color = 0, files = attached.encodeAll()))
        src.images.drop(1).forEach { u ->
            vm.importImage(u) { p -> vm.save(Item(title = title.ifBlank { "Shared image" }, body = "", kind = Kind.Image, collection = shelf, imageUri = p, color = color - 1)) }
        }
        vm.clearIncoming()
    }

    Scaffold(containerColor = t.paper) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
            ScreenHeader({ vm.clearIncoming() }, title = "Save to Scrapbook", backIcon = "close", backDesc = "Cancel")
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 16.dp)) {
                Text(kind.label + (if (src.images.size > 1) " · ${src.images.size} images" else "") + (if (src.files.isNotEmpty()) " · " + (if (src.files.size == 1) "1 file" else "${src.files.size} files") else ""), Modifier.clip(CircleShape).background(Sb.card).padding(horizontal = 14.dp, vertical = 7.dp),
                    fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
                Spacer(Modifier.height(14.dp))
                Field(title, { title = it }, "Title", 26.sp, headFont(), FontWeight.Medium)
                if (img != null) {
                    Spacer(Modifier.height(12.dp))
                    ItemImage(Item(title = "", body = "", kind = kind, collection = shelf, imageUri = img), Modifier.fillMaxWidth().height(180.dp), 24.dp)
                }
                if (attached.isNotEmpty()) AttachmentList(attached, Modifier.padding(top = 12.dp))
                Spacer(Modifier.height(12.dp))
                Field(body, { body = it }, "Write something…", 17.sp, headFont())
            }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(Sb.card).padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 16.dp)) {
                SheetLabel("Save in", start = 2.dp)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), Arrangement.spacedBy(8.dp)) {
                    SoftChip("Inbox", shelf == "Inbox", container = Sb.paper, dot = if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) { shelf = "Inbox" }
                    if (fromPaperback && shelves.none { it.name == PAPERBACK_BOX }) SoftChip(PAPERBACK_BOX, shelf == PAPERBACK_BOX, container = Sb.paper) { shelf = PAPERBACK_BOX }
                    shelves.forEach { sh -> SoftChip(sh.name, shelf == sh.name, container = Sb.paper, dot = TAB_COLORS[sh.color % TAB_COLORS.size]) { shelf = sh.name } }
                }
                Text(if (ready) "Save" else "Preparing…", Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(28.dp)).background(Sb.ink.copy(alpha = if (ready) 1f else .35f))
                    .tap("Save") { save() }.padding(vertical = 16.dp),
                    color = Sb.card, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            }
        }
    }
}
