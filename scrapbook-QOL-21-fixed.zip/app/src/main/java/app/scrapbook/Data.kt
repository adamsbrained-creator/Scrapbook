package app.scrapbook

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

class Converters {
    @TypeConverter fun fromTags(v: List<String>) = v.joinToString("\u001F")
    @TypeConverter fun toTags(v: String) = if (v.isEmpty()) emptyList() else v.split("\u001F")
    @TypeConverter fun fromKind(v: Kind) = v.name
    @TypeConverter fun toKind(v: String) = Kind.valueOf(v)
    @TypeConverter fun fromLayout(v: Layout) = v.name
    @TypeConverter fun toLayout(v: String) = Layout.valueOf(v)
}

@Dao
interface ItemDao {
    @Query("SELECT * FROM items WHERE deletedAt = 0 ORDER BY pinned DESC, savedAt DESC") fun all(): Flow<List<Item>>
    /** Scraps in the Bin, the most recently deleted first. */
    @Query("SELECT * FROM items WHERE deletedAt > 0 ORDER BY deletedAt DESC") fun bin(): Flow<List<Item>>
    /** A scrap that is not in the Bin. */
    @Query("SELECT * FROM items WHERE id = :id AND deletedAt = 0") suspend fun byId(id: Long): Item?
    /** A scrap wherever it is, in the Bin or not. */
    @Query("SELECT * FROM items WHERE id = :id") suspend fun byIdAny(id: Long): Item?
    @Query("UPDATE items SET deletedAt = :at WHERE id = :id") suspend fun markDeleted(id: Long, at: Long)
    @Query("UPDATE items SET deletedAt = :at WHERE collection = :name AND deletedAt = 0") suspend fun binItemsIn(name: String, at: Long)
    /** Batch actions from the selection toolbar. Callers send at most 500 ids at a time (SQLite limits how many values one query may take). */
    @Query("UPDATE items SET collection = :box WHERE id IN (:ids) AND deletedAt = 0") suspend fun moveByIds(ids: List<Long>, box: String)
    @Query("UPDATE items SET pinned = :pinned WHERE id IN (:ids) AND deletedAt = 0") suspend fun pinByIds(ids: List<Long>, pinned: Boolean)
    @Query("UPDATE items SET deletedAt = :at WHERE id IN (:ids) AND deletedAt = 0") suspend fun markDeletedByIds(ids: List<Long>, at: Long)
    @Query("UPDATE items SET deletedAt = 0, collection = :box WHERE id = :id") suspend fun restoreTo(id: Long, box: String)
    @Query("DELETE FROM items WHERE id = :id AND deletedAt > 0") suspend fun purge(id: Long)
    @Query("DELETE FROM items WHERE deletedAt > 0") suspend fun purgeAll()
    @Query("DELETE FROM items WHERE deletedAt > 0 AND deletedAt < :before") suspend fun purgeBefore(before: Long)
    @Query("SELECT * FROM item_versions WHERE itemId = :id ORDER BY takenAt DESC, id DESC") fun versionsOf(id: Long): Flow<List<ItemVersion>>
    @Query("SELECT * FROM item_versions WHERE itemId = :id ORDER BY takenAt DESC, id DESC LIMIT 1") suspend fun latestVersion(id: Long): ItemVersion?
    @Insert suspend fun addVersion(v: ItemVersion)
    @Query("DELETE FROM item_versions WHERE itemId = :id AND id NOT IN (SELECT id FROM item_versions WHERE itemId = :id ORDER BY takenAt DESC, id DESC LIMIT :keep)") suspend fun trimVersions(id: Long, keep: Int)
    @Query("DELETE FROM item_versions WHERE itemId NOT IN (SELECT id FROM items)") suspend fun dropOrphanVersions()
    @Upsert suspend fun upsert(item: Item): Long
    @Delete suspend fun delete(item: Item)
    @Query("SELECT * FROM collections ORDER BY name COLLATE NOCASE") fun shelves(): Flow<List<Shelf>>
    @Upsert suspend fun upsertShelf(shelf: Shelf)
    @Query("DELETE FROM collections WHERE name = :name") suspend fun removeShelf(name: String)
    @Query("UPDATE items SET collection = :newName WHERE collection = :oldName") suspend fun moveItems(oldName: String, newName: String)
    @Query("UPDATE collections SET parent = :newParent WHERE parent = :oldParent") suspend fun moveShelves(oldParent: String, newParent: String)
    @Query("SELECT * FROM items WHERE deletedAt = 0 ORDER BY createdAt ASC LIMIT 20") suspend fun oldest(): List<Item>
    @Query("SELECT COUNT(*) FROM items WHERE deletedAt = 0") suspend fun count(): Int
    /** Every scrap, Bin included: what photo cleanup checks before it deletes a file. */
    @Query("SELECT * FROM items") suspend fun everything(): List<Item>
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE items ADD COLUMN canvas TEXT NOT NULL DEFAULT ''") }
}

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS collections (name TEXT NOT NULL, description TEXT NOT NULL, color INTEGER NOT NULL, coverUri TEXT, PRIMARY KEY(name))")
    }
}

val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE items ADD COLUMN source TEXT NOT NULL DEFAULT ''") }
}

val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE items ADD COLUMN images TEXT NOT NULL DEFAULT ''") }
}

val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE items ADD COLUMN accent INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE items ADD COLUMN cover TEXT")
    }
}

val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE collections ADD COLUMN parent TEXT NOT NULL DEFAULT ''") }
}

/** The Bin and version history: one column on items, one new table. Nothing existing is touched, so every scrap carries over as it was. */
val MIGRATION_9_10 = object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE items ADD COLUMN deletedAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE TABLE IF NOT EXISTS item_versions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, itemId INTEGER NOT NULL, takenAt INTEGER NOT NULL, savedAt INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL)")
    }
}

/** Creation date for sorting. Existing scraps get the earliest date we know: the oldest kept version if there is one, otherwise the last edit. */
val MIGRATION_10_11 = object : Migration(10, 11) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE items ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0")
        db.execSQL("UPDATE items SET createdAt = MIN(savedAt, COALESCE((SELECT MIN(v.savedAt) FROM item_versions v WHERE v.itemId = items.id), savedAt))")
    }
}

/** A scrap's optional icon: one column. Every scrap starts with none. */
val MIGRATION_11_12 = object : Migration(11, 12) {
    override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE items ADD COLUMN icon TEXT NOT NULL DEFAULT ''") }
}

/** Files attached to a scrap: one column. Every scrap starts with none, so nothing existing changes. */
val MIGRATION_12_13 = object : Migration(12, 13) {
    override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("ALTER TABLE items ADD COLUMN files TEXT NOT NULL DEFAULT ''") }
}

@Database(entities = [Item::class, Shelf::class, ItemVersion::class], version = 13, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDb : RoomDatabase() { abstract fun dao(): ItemDao }

/** One shared database for the app and the widget. */
object Db {
    @Volatile private var inst: AppDb? = null
    fun get(c: android.content.Context): AppDb = inst ?: synchronized(this) {
        inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "scrapbook.db")
            .addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13).build().also { inst = it }
    }
}
