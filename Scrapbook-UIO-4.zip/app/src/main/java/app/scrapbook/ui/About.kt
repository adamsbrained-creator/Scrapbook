package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

// The About page, plus the two pages it opens inside the app: What's new and Open-source licenses.
// Layout, spacing and colors follow the "About" mockup. It reuses the grouped rows from Settings.kt.

/**
 * Where the About rows point. Fill these in. While one is blank, its row shows a short "not set up yet" message instead of opening something.
 * (Rate Scrapbook needs no setting: it opens this app's Google Play page.)
 */
object AboutLinks {
    const val FEEDBACK_EMAIL = ""
    const val PRIVACY_URL = ""
    const val PAPERBACK_URL = ""
    const val BINDER_URL = ""
}

private fun Context.toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

private fun Context.tryStart(intent: Intent) {
    try { startActivity(intent) } catch (e: ActivityNotFoundException) { toast("Nothing on this phone can open that.") }
}

private fun Context.openLink(url: String) {
    if (url.isBlank()) { toast("This link isn't set up yet."); return }
    tryStart(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

private fun Context.sendFeedback(version: String) {
    if (AboutLinks.FEEDBACK_EMAIL.isBlank()) { toast("The feedback address isn't set up yet."); return }
    tryStart(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
        putExtra(Intent.EXTRA_EMAIL, arrayOf(AboutLinks.FEEDBACK_EMAIL))
        putExtra(Intent.EXTRA_SUBJECT, "Scrapbook feedback")
        putExtra(Intent.EXTRA_TEXT, "\n\n--\nScrapbook $version, Android ${Build.VERSION.RELEASE}, ${Build.MODEL}")
    })
}

/** Opens this app's Play Store page, in the Play app if there is one, otherwise in a browser. */
private fun Context.rateApp() {
    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))) }
    catch (e: ActivityNotFoundException) { tryStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))) }
}

/** Header for the About pages: a round back button and a centered title. */
@Composable
private fun PageHeader(title: String, nav: NavController) {
    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleBtn("Go back", { nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
        Text(title, Modifier.weight(1f).asHeading(), textAlign = TextAlign.Center, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp,
            letterSpacing = (-0.01).em, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.size(44.dp))
    }
}

/** A small section label above a card, the same as on the Settings page. */
@Composable
private fun SectionLabel(text: String, first: Boolean) {
    Text(text, Modifier.padding(start = 24.dp, end = 24.dp, top = if (first) 22.dp else 26.dp, bottom = 8.dp).asHeading(), fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
}

/** The big "Scrapbook" with a blinking accent caret in front, sized to fit the screen (60sp on a normal phone). */
@Composable
private fun CaretWordmark() {
    val blink = rememberInfiniteTransition(label = "caret")
    // A hard on/off blink, not a fade: visible for the first half of each 1.1 seconds, hidden for the second.
    val caret by blink.animateFloat(
        initialValue = 1f, targetValue = 0f, label = "caretAlpha",
        animationSpec = infiniteRepeatable(keyframes { durationMillis = 1100; 1f at 0; 1f at 549; 0f at 550 }, RepeatMode.Restart))
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 24.dp), Alignment.Center) {
        val size = (maxWidth.value / 5.4f).coerceAtMost(60f)
        val u = with(LocalDensity.current) { size.sp.toDp() }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(u * 0.08f).height(u * 0.95f).clip(RoundedCornerShape(u * 0.04f)).alpha(caret).background(LocalSb.current.acc))
            Spacer(Modifier.width(u * 0.13f))
            Text("Scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = size.sp, lineHeight = (size * 1.1f).sp,
                letterSpacing = (-0.02).em, maxLines = 1, softWrap = false)
        }
    }
}

/** One app in the family card: its name, a line about it, and the arrow that says it opens outside the app. */
@Composable
private fun FamilyRow(name: String, blurb: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(68.dp).tap("Open $name", onClick).padding(start = 18.dp, end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.02).em)
            Text(blurb, fontSize = 13.sp, color = Sb.mute)
        }
        Spacer(Modifier.width(12.dp))
        Ic("external", 18.dp, Sb.mute)
    }
}

@Composable
fun AboutScreen(nav: NavController) {
    val t = LocalSb.current; val ctx = LocalContext.current
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty() }
    Scaffold(containerColor = t.paper) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            PageHeader("About", nav)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Spacer(Modifier.height(52.dp))
                CaretWordmark()
                Text("Quick notes, tidy boxes.", Modifier.fillMaxWidth().padding(top = 12.dp), textAlign = TextAlign.Center, fontSize = 16.sp, color = Sb.ink.copy(alpha = .85f))
                if (version.isNotEmpty()) Text("Version $version", Modifier.fillMaxWidth().padding(top = 6.dp), textAlign = TextAlign.Center, fontSize = 14.sp, color = Sb.mute)
                Spacer(Modifier.height(40.dp))
                GroupCard {
                    NavRow("What's new") { nav.navigate("whatsnew") }
                    RowDivider()
                    NavRow("Send feedback") { ctx.sendFeedback(version) }
                    RowDivider()
                    NavRow("Rate Scrapbook", icon = "external") { ctx.rateApp() }
                    RowDivider()
                    NavRow("Privacy policy", icon = "external") { ctx.openLink(AboutLinks.PRIVACY_URL) }
                    RowDivider()
                    NavRow("Open-source licenses") { nav.navigate("licenses") }
                }
                Spacer(Modifier.height(16.dp))
                // Scrapbook is one of three apps. This card points to the other two.
                GroupCard {
                    Text("PART OF THE FAMILY", Modifier.padding(start = 18.dp, end = 18.dp, top = 16.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = (0.04).em, color = Sb.mute)
                    FamilyRow("paperback", "Your book reader") { ctx.openLink(AboutLinks.PAPERBACK_URL) }
                    RowDivider()
                    FamilyRow("binder", "Track what you watch, play and read") { ctx.openLink(AboutLinks.BINDER_URL) }
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

private class Release(val title: String, val notes: List<String>)

/** Newest first. Add a Release at the top when you ship something new. */
private val RELEASES = listOf(
    Release("Latest", listOf(
        "Binder: Scrapbook now works with Binder, your lists and catalogues app. In a scrap's menu (Share & copy in the editor) choose Add to Binder to put it in one of your binds, with a link to the new item added to the scrap; Open in Binder when a scrap links to an item; and Make a checklist bind when it has checklist lines. A box's menu has Make a bind in Binder, one item per scrap. In Binder, hold an item and choose Write about this to get a scrap with its details and cover. binder:// links open in Binder.",
        "A profile and a livelier greeting. Settings now starts with your account: a name, a nickname, a picture (a photo or your initial on a color), a line about you, pronouns and a birthday, all kept only on this phone. The greeting on Home uses them: it has well over a hundred lines for the time of day, the weekday, your scraps and your birthday, in friendly, playful and calm voices, and it changes by itself every so often. Tap it to see another. The greeting's options are in Customize home: tap the sliders button on the Greeting row to set the tone, how often it changes, the line under it and whether your picture shows, and to resize its text and picture freely, with a preview above. The account card sits just above About in Settings.",
        "No more gray flash when you tap. Android's tap ripple is a grainy gray blink, and when you tapped outside a bottom sheet it spread over the whole screen. It is now switched off everywhere. Things that already shrink or change color when pressed still do.",
        "A switch for the keyboard. Settings > Editor > Open the keyboard automatically. Turn it off and the keyboard no longer comes up by itself: not when you come back to a scrap you left with the keyboard open, and not when you open a scrap with Edit (or Duplicate) from the reading page. You still get the editor and its toolbar, and the keyboard appears when you tap in the text. It is on by default, as before.",
        "Accessibility. Accent-colored words and icons (links, hashtags, \"Replace…\", \"Clear\", check marks) are deepened in light mode when the accent would be too faint to read, and text on an accent-filled button or badge is dark or white, whichever reads better, for every accent including your own custom colors. Icon-only buttons now have a spoken name for TalkBack, titles and section labels are marked as headings, a sheet is announced by its title and its contents are read part by part, and the small close and remove buttons have bigger touch areas. Pills and buttons with text grow with a large system font size instead of cutting the text off.",
        "Photos and files can sit beside the text. Hold a photo (or open a file's ⋮ menu) and choose Wrap text or Place freely, then tap it: a frame, a corner handle and a small bar appear. Drag the handle to make it bigger or smaller, drag the object to move it, and use the bar to switch between In line, Wrap and Free (or take it off). Wrap puts it at the left edge with the text running on its right: the text is pushed in a paragraph at a time, so a long paragraph next to it stays narrow all the way down, and a new line (Enter) makes the text hug the picture more closely. Letting go snaps it to the nearest paragraph. Free puts it anywhere, in front of the text. Tap a selected photo or file again to open it. Undo covers every move, resize and change, and view only shows them but does not let you touch them. (Wrap works on the left edge only for now.)",
        "The writing bar now grows in three steps. The mini bar is a slim pill: a + (Camera, Photos, Files, Checklist, Link), \"Write…\", a dot for the box and a small blue Record pill. Tap it and it gets wider, the hint grows to \"Write something…\", Record shrinks to its round icon and the dot grows into the box's name. Write more than a line and it grows into the big bar: your text on top, and under it the + , the box chip, your tags and the blue button, which becomes the send arrow once you type.",
        "Timeline: your scraps laid out by the day they were made, newest first, grouped by month, with the month heading staying at the top while you scroll. Open it from the menu. Switch between Created and Edited, narrow it with Filter, tap a month heading to jump to any month or year, and look for \"On this day\" at the top once you have scraps from earlier years.",
        "A tidier Settings. The main page now lists just a few pages (Look and feel, Home and lists, Boxes, Editor, Privacy, Data and backup, and About), each with a grey line saying what is inside, and each opens as its own page with its own back button. Search still looks through every setting, and the editor menu's Look, Editor and Backup shortcuts open the right page directly.",
        "The font color panel is smaller and simpler, in the style of the page color picker: the default color, five popular colors and a rainbow choice. The rainbow opens the color bars and a box where you can paste a hex color (#ff8800, ff8800, #f80) or an RGB color (rgb(255, 136, 0) or 255, 136, 0); the color is recognized as you type and Use puts it on the text. Under the dots, a Recent row keeps the colors you used last (even in other scraps), so the same color is one tap away for other text. Picking a color closes the panel.",
        "The font size button now opens a narrow scrolling list, like Samsung Notes, with every size from 6 to 64 (every size up to 30, then every second one to 48, then every fourth). It opens scrolled to the size you have, which is shown in the accent color. Choosing 17, the normal size, takes the size off the text so it follows the page again. Sizes 6 and 7 used to be shown as 8; now they are real.",
        "Attached files: the file-type badge and the play button are now round, and the card has the same corners as the other cards. The ⋮ on a card opens Rename, Share and (in the editor) Remove. Renaming works for any attached file, including voice recordings; the file keeps its ending (like .pdf) unless you type a new one, and when you share it, the new name goes with it.",
        "Useful empty states: an empty box now offers New scrap, Move scraps in (pick scraps from your other boxes, the Inbox first) and New box inside. A search or filter that finds nothing offers to clear itself, the empty All scraps and Inbox pages offer New scrap, and a search with no results says so.",
        "Plain photos: a new switch in Settings, Show photos as plain pictures, shows the photos in a scrap as normal pictures (the whole photo, rounded corners, no frame, tape or tilt) instead of taped polaroids. A single photo spans the page; with several, the next one peeks in from the side. It is off by default, so polaroids stay as they were.",
        "Link cards: when you paste a web address, the offer above the toolbar now has a Link card button next to Make it a link. It reads the page you pasted (only then) and turns the address into the page title, a short description as a quote, the preview photo among the scrap's photos and the link below. On an empty scrap the page title becomes the scrap's title. It is one undo step. It uses the page's own sharing information, not a summary, so some sites give little or nothing (X and sites behind a login or a paywall often do not share their content); then you are told and the address stays as it is.",
        "Move anything on the page. Hold a photo or a file and choose Drag (a file also has Drag in its ⋮ menu), then drag it with your finger: a line shows where it will land, and letting go puts it there. Every photo and file is its own place now, so one can sit above the text, below it, or between other photos and files. The page scrolls by itself near the top and bottom edge, and Undo moves it back. The text stays in one piece, so things go above or below it, not inside it. Arrange page in the menu still moves whole groups (it puts the photos together and the files together again). View only turns all of this off.",
        "A shorter editor menu. The 3-dot menu in the editor is now a short list: Find, Reading view, Go to…, Pin, then Add to page, Page and Share & copy (and Format when the floating pill toolbar is on), each opening a small page inside the same menu with an arrow back. Every page ends with a link to the Settings that belong to it, which opens Settings already narrowed down.",
        "Privacy. Settings > Privacy adds an app lock with a 4 to 8 digit PIN (only a salted hash of it is kept), optional fingerprint unlock, a choice of how long you can be away before it locks again, and hiding the app in Android's recent apps list. You can also hide a box: edit it and choose Hide this box. A hidden box and everything inside it disappears from every list, search, the quick switcher and the widget until you tap Hidden on the Boxes screen and enter your PIN or fingerprint. It locks again when you leave the app for longer than your chosen delay. A forgotten PIN cannot be recovered, and backup files are not encrypted.",
        "A swipe-up sheet to try: Customize home > Quick capture > Add button > Swipe-up sheet. The page gets a thin handle at the bottom and a small + (it writes a scrap). Swipe the handle up, or tap it, and a sheet rises with the ways to start a scrap (text, checklist, photo, voice, link), the scraps and boxes you opened last, and Home, Go to, Search and the menu. Drag it down, tap the page behind it or press Back to close it.",
        "One button, an arc to try: Customize home > Quick capture > Add button > One button, an arc. A tap on the round button writes a new scrap. Hold it and four places fan out along a curve (Menu, Go to…, Search, a new scrap with a photo): slide to one and let go, all in one movement. Let go on the button itself to keep the arc open and tap a place instead.",
        "A writing bar to try: Customize home > Quick capture > Add button > Writing bar puts a small card at the bottom of the page. Type a line, pick the box (Inbox, or the box you are in), tap send, and the scrap is saved and you stay where you are. The + has photo, checklist and link, the microphone starts a voice memo, the dark button opens an empty scrap, and the expand button takes what you typed into the full editor.",
        "Go to…: a quick switcher in the menu (and in the editor's 3-dot menu). Type a few letters of a scrap or a box and jump straight to it; with nothing typed it lists what you opened last. A scrap's page now shows the path to its box (Trips › Italy), each step opens that box, and holding the back arrow inside a nested box takes you Home.",
        "A new Settings switch, Show \"Saved\" in the editor, hides the small Saved text in the editor header if it distracts you. Saving itself is unchanged.",
        "Connected scraps. Every scrap now has a Connected section at the bottom: Linked from (the scraps that link to it), Links to (the scraps it links to), Could link (titles of other scraps that are written in the text but not linked yet, with a Link button that links them in one tap) and Related (scraps that share its tags, rare tags counting most). It stays hidden when a scrap has no connections, and Settings can turn the two kinds of suggestion off. To make a link, use Link to scrap in the 3-dot menu, or type [[ in the text: a search opens with the likeliest scraps first (a title already in the text, scraps that link here, scraps sharing tags, the same box), and the one you tap becomes a link at the cursor, or the selected words become the link. Nothing is stored separately: connections are worked out from the links in your text, so older links count too, and backups need nothing new.",
        "Code: put words in `backticks` for inline code, or use the Code block button (the + button, or the Code button in the selection bubble) for a block of code. Code is shown in monospace, nothing inside it is formatted, and #words in it are not tags. In the reading view a block is a card with a Copy button and scrolls sideways instead of wrapping.",
        "Round checklist icons: an empty ring, and a filled accent circle with a check when ticked, in the editor, the reading view and the small previews. The ring is grey unless Settings says the marks use the accent color or the line's text is colored.",
        "Links in the editor: tap a link and a small Open / Edit bubble appears over it, so you can open it without leaving the editor. Written-out addresses (https:// and scrapbook://) are now underlined in the editor too. Edit link also has an Open link row.",
        "Pressing Enter at the end of a quote line starts the next quote line, like a list. Press Enter on an empty one to stop.",
        "Smart paste: after you paste into a scrap, a small offer appears above the toolbar when the text is recognized. A web address can become a link (it gets the site name, then the page title), a copied quote in quotation marks can be formatted as a quote, bulleted or boxed lines can become a list or checklist, and lines broken in the middle of sentences (from a PDF) can be joined. Nothing changes until you tap the offer, it goes away by itself or with the cross, and it is one undo step. Pasting a web address over selected text still makes it a link straight away. You can turn the offers off in Settings, under Editor.",
        "A more useful home page: the Boxes row now follows your work (the Inbox first while it has scraps, then the boxes you edited most recently, empty boxes last; Settings can bring back your own order), and Recent no longer repeats the pinned scraps or the one in the Continue card.",
        "Faster Home page and lists. The few lines shown under each scrap are now prepared once and only from the start of the text, instead of reading the whole scrap every time a card is drawn; dates, icons and the box counts are no longer rebuilt on every redraw; and the start-up clean-up waits a few seconds so the first screen is not slowed down. The release build is also optimized when it is made. Nothing about how the app works has changed.",
        "Any color, not just the ready-made ones. Page color and Accent in Page style (and the page color in the editor's Details) now end with a rainbow circle: tap it and two bars appear, one for the hue and one from dark to light, like the text color tool. The app's Accent color in Settings has a Custom color row with the same bars. Your colors are kept per scrap and in backups; the launcher icon takes the ready-made accent closest to a custom one.",
        "Toolbar: the tint behind a pressed tool is now a slightly smaller pill, so two tools that are on at once (for example Checklist and Aa) no longer touch.",
        "Reading, writing and view only. A scrap now opens as a plain page with no toolbar. Tap the text to start writing right where you tapped (the toolbar slides up and the keyboard opens); tap a link to open it. The book button in the header turns on view only: the page is locked and nothing changes until you tap the book again, and Scrapbook remembers that for that scrap, so it opens locked next time. The header no longer jumps between the modes: the title and the page stay put, the add-image button slides in and out, and the toolbar slides.",
        "Arrange page (3-dot menu): choose where the photos, the files and the text sit on a scrap, from the top down. The page is the same while reading and writing, instead of files and photos swapping places. The order is saved with the scrap and in backups. The old reading page is in the menu as Reading view.",
        "Editor extras. The 3-dot menu now has Share and Copy text (they send clean text: no formatting codes, lists keep their markers, links keep their address), Duplicate, and Text tools: move the current line or the selected lines up or down, tidy a checklist (ticked items to the bottom, untick all, clear ticked), and insert today's date. Find in a scrap can now replace the current match or all of them (tap Replace… under the find bar). The first letter of each sentence is capitalized as you type, and the 3-dot menu scrolls on small screens.",
        "Text colors: bullets, checkboxes and quote bars now have the normal text color instead of the accent, and follow the text when you color it with the text color tool. #hashtags and links keep the accent color, and a hashtag you color yourself keeps that color. In Settings, under Editor, three switches bring the accent back on list marks or take it off hashtags and links. This applies to the editor and to the reading view.",
        "Hashtags: type #idea in a scrap and idea is added to its tags, like on social media. A hashtag is a # at the start of a word followed by a letter, so headings, C# and #12 are left alone. #words that count are shown in the accent color, the word you are still typing waits until you move on, and your text is never changed. Taking a tag off with its cross sticks, and deleting the #word does not remove the tag. You can turn it off in Settings, under Editor.",
        "Links to scraps. Every scrap now has a permanent id, and its 3-dot menu (in the editor and the reading view) has Copy link to scrap. Paste that link into another app, or into another scrap, and tapping it opens the scrap; in a note it reads as the scrap's current title. Links keep working after a backup restore or a reinstall, as long as the backup was made from this version on (older backups have no ids, so those scraps get new ones). A link to a deleted scrap says so instead of failing.",
        "Find in a scrap now works in the reading view too, the same way as in the editor: hold the back button (or use the 3-dot menu, as set in Settings), type, and every match on the page is highlighted with the current one stronger, scrolled into view, with next, previous and a match counter. It searches the body text, not the title, and not the Quote layout.",
        "Boxes, reworked. Edit a box and use Location to move it into another box or back to the main page; the list shows your boxes as a tree and a box can never be moved into itself or into something inside it. Two boxes can now share a name as long as they sit in different boxes (a \u201ctests\u201d in Binder and another in Scrapbook). Renaming a box never touches its scraps. A box on a box screen shows the way to it (Trips \u203a Italy) and each step is a tap away; boxes with boxes inside say so (\u201c3 scraps \u00b7 2 boxes\u201d), and an empty box that has boxes inside no longer says \u201cNothing here yet\u201d. Add to box now uses the same indented tree. Inbox, All, Pinned and Recent can no longer be used as a box name.",
        "Search inside a box now also looks in the boxes inside it (a line under the search bar says so). The Search page remembers your last 8 searches: with the field empty they are listed at the top; tap one to run it again, X to forget it, Clear to wipe them all. A search is remembered when you press the keyboard's search key or open a result.",
        "Tags that work across boxes: tap a tag in the editor header to see every scrap with it, in any box. Scraps show their tags on the card, and in the editor's Details the tags are pills you can remove, with a field to add more and suggestions from the tags you already use. A tag can not be added twice, and a new one takes the spelling of an existing one.",
        "Filter: a new Filter button on All scraps, inside boxes and in Search narrows the list by type, box, tags (a scrap needs all the chosen tags) and date (today, 7 or 30 days, past year, by edited or created). The big button shows how many scraps match.",
        "Reopening a scrap now also remembers where you were when you went to Reading view or Change layout and came back, not only when you left the app. Page style closes the keyboard so the whole sheet fits.",
        "Find in a scrap: in the editor, hold the back button for a moment. A ring fills around it, it vibrates and turns into a search button for a few seconds; tap it to search inside the scrap. Every match is highlighted, the current one stronger and scrolled into view, with next and previous buttons and a match counter. If you would rather not use the gesture, Settings > Editor > Find in a scrap puts it in the 3-dot menu instead, or in both places.",
        "Better search: type several words and a scrap matches when it has all of them, in any order. Every match is highlighted, results show the part of the text around the first match instead of always the first lines, and a small line shows the tags or attachment names that matched. The search bar inside a box highlights and shows matches the same way.",
        "Scrapbook remembers where you were. A scrap reopens with the cursor and the page exactly where you left them, and if you were typing the keyboard comes back too. The app opens in the box you were last in again, and your sorting stays as you set it.",
        "A livelier feel: a light vibration when you tick a task, pin or unpin a scrap, file a scrap in a box or flip a switch. Pinning pops the star in, ticking a task in the reading view fills the box with a little spring, Sort Inbox cards fade in one by one, and the editor shows a small \u201cSaved\u201d beside the box name after each autosave. Turn the vibration off in Settings, under Feedback.",
        "Attach any file to a scrap: a PDF, a zip, a document, a recording, anything. Open the editor's 3-dot menu and choose Attach file, or share a file to Scrapbook from another app and it becomes a new scrap with the file attached. PDFs show their first page and page count; other files show their type. Tap a file to open it in another app, or use the share button on the scrap's page to send it elsewhere. File names are searchable, files are included in backups, and each file can be up to 100 MB.",
        "Photos open full screen: tap a photo in the editor or on a scrap's page to see it large. Swipe to move between a scrap's photos, pinch or double-tap to zoom, drag to look around, tap once to hide the buttons. Back or the X closes it.",
        "Select several scraps at once: on All scraps and inside any box, long-press a scrap to start picking, then tap more (the ring in a card's corner fills with a check). Select all or none from the header. The bar at the bottom adds the picked scraps to a box (Inbox too), pins or unpins them, adds tags to all of them, or moves them to the Bin, and every action can be undone in one tap. Long-press no longer opens the delete sheet on those pages; on Home it still does.",
        "Sort Inbox: when scraps are waiting in Inbox, Home shows a To sort card. It takes you through them one at a time, oldest first: add one to a box, keep it close (pin it), delete it or leave it for later. Nothing happens by itself and nothing nags. You can also start it from Inbox's 3-dot menu.",
        "Inbox now comes back by itself when a scrap lands in it after you removed it, so new scraps are never filed in a box you cannot open.",
        "Scraps dress the way you styled them: the accent color shows as a bar on the card, the page color as a soft tint, and a cover image sits on top of the card (in the grid it replaces the little drawing). Every layout gets the same treatment.",
        "Icons: give a scrap an emoji that shows in front of its title in lists, search, the Bin, Rediscover and the page. Pick one from the list or type any emoji. Page style is now also in the editor's menu, and the editor shows the cover and uses the scrap's accent color.",
        "Sort by date created: scraps now remember when they were first made, so you can sort by Date edited, Date created or Title, on All scraps, in boxes and in Settings (one shared choice). The details of a scrap show both dates, and Rediscover now counts from when you saved it, not from your last edit. Scraps from before this update use their earliest known date.",
        "Photos nothing uses any more (from scraps deleted for good, or taken off a scrap) are now cleaned up, so they stop taking space on your phone.",
        "A Bin: deleted scraps now wait there for 30 days instead of vanishing. Restore one or delete it for good from Menu, then Bin (or Settings). Deleting a box together with its scraps goes to the Bin as well, and the Undo snackbar still works.",
        "Version history: while you edit, earlier texts of a scrap are kept automatically (about every five minutes, and whenever a big chunk of text disappears). Open a scrap's 3-dot menu, then Version history, to bring one back. The current text is kept too, so you can always go back again.",
        "A new scrap now also comes back with its text if Android closes the app while you are writing it, instead of an empty page.",
        "Undo and redo now cover everything in the editor, not just the text: the title, photos you add or remove, color, type, box, tags and source. Typing is undone a sentence or two at a time. Hold the undo button for a bubble with Undo, Redo (each says what it would change) and Revert all changes, which goes back to how the scrap was when you opened it.",
        "Sturdier autosave: if Android closes Scrapbook while you are away, the scrap you were editing now reopens with all its text instead of an empty page, and what you typed in the last moment is saved the instant you leave the app.",
        "Every window now matches the rest of the app: the pop-up menus, the sheets (Add to box, Tags, New and Edit box, Customize page, Delete, the Inbox color), the Details panel in the editor, the headers of the Box, Boxes, Search and Rediscover screens, Save to Scrapbook, the crash screen, the widget and the launch screen.",
        "A new app icon: two glass pages on a soft gradient. It comes in all seven accent colors and changes with the accent you choose in Settings (you'll see it the next time you leave the app). Turn it off with Icon matches accent.",
        "A new Blue accent color.",
        "Light animations: screens fade and slide in, lists fade up as they appear, cards and buttons press in, and sheets, switches and the accent color glide instead of snapping.",
        "Four new looks for the Boxes screen: Nested (boxes inside their parent), Shelf (compact rows), Cover (bold color covers) and Stack (layered cards). Pick one with the switcher at the right of the Inbox chip.",
        "A new Home page is where the app starts: a quick way to write something down, the scrap you edited last, your boxes, pinned scraps and the latest ones. The full list is now the All scraps page, with its title under the menu button.",
        "Opening the last box on launch is now off by default, since Home has a Continue card. You can turn it back on in Settings.",
        "A redesigned Settings page: a summary card showing how much of your archive is filed in boxes, icon rows with the current choice, and pickers instead of inline switches.",
        "New editor tools: Text options (lists, alignment, bold, italic, underline, strikethrough, indent), font color with any color you like, and a font size picker.",
        "The editor now hides the markdown marks as you write. Double tap selects a word, triple tap a line, four taps everything. Tap a checkbox to tick it.",
        "Quotes and notes sent from the Paperback app land in a \"Paperback\" box, and the \"Open in Paperback\" link in them opens the book at that passage.",
        "A new Settings page with theme, background, accent color, header size, list options, boxes and backup in one place.",
        "White is now the default background. Soft grey is still there if you prefer it.",
        "Seven box styles: Tabbed, Paper stack, Tinted tiles, Folder tabs, Chips, List rows and Notebook covers.",
        "A single round menu button: tap it for the menu, hold it to pop out the + button.",
        "A redesigned editor header, with the box and tags under the title and a cleaner 3-dot menu.",
        "Scrapbook now opens in the box you were last in, instead of the main page. You can turn this off in Settings.",
        "The search bar inside a box can now be hidden, from the box's 3-dot menu or in Settings.",
        "A tidier menu, and this About page.",
    )),
)

@Composable
fun WhatsNewScreen(nav: NavController) {
    val t = LocalSb.current
    Scaffold(containerColor = t.paper) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            PageHeader("What's new", nav)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                RELEASES.forEachIndexed { i, r ->
                    SectionLabel(r.title, i == 0)
                    GroupCard {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            r.notes.forEach { n ->
                                Row(verticalAlignment = Alignment.Top) {
                                    Box(Modifier.padding(top = 8.dp).size(6.dp).clip(CircleShape).background(t.acc))
                                    Spacer(Modifier.width(12.dp))
                                    Text(n, fontSize = 15.sp, lineHeight = 22.sp)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

private class Library(val name: String, val license: String, val note: String? = null)

/** What the app is built with (see app/build.gradle.kts). Add a line here when you add a library. */
private val LIBRARIES = listOf(
    Library("Jetpack Compose and AndroidX", "Apache License 2.0", "Compose, Material 3, Activity, Navigation, Lifecycle, DataStore, Room, Core KTX and Glance"),
    Library("Coil", "Apache License 2.0", "Image loading"),
    Library("Kotlin and kotlinx.coroutines", "Apache License 2.0"),
)

@Composable
fun LicensesScreen(nav: NavController) {
    val t = LocalSb.current
    Scaffold(containerColor = t.paper) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            PageHeader("Open-source licenses", nav)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                SectionLabel("Built with", true)
                GroupCard {
                    LIBRARIES.forEachIndexed { i, lib ->
                        if (i > 0) RowDivider()
                        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp)) {
                            Text(lib.name, fontSize = 16.sp)
                            Text(lib.license, Modifier.padding(top = 2.dp), fontSize = 14.sp, color = Sb.mute)
                            if (lib.note != null) Text(lib.note, Modifier.padding(top = 2.dp), fontSize = 13.sp, color = Sb.mute)
                        }
                    }
                }
                Text("The full Apache License 2.0 text is at apache.org/licenses/LICENSE-2.0.", Modifier.padding(start = 24.dp, end = 24.dp, top = 12.dp), fontSize = 13.sp, color = Sb.mute)
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}
