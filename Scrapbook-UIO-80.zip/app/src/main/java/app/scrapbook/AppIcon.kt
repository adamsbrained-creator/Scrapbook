package app.scrapbook

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * The launcher icon is one you choose (Settings > Look & Feel > App's icon): one of [choices], six flat icons (an S or a page, each on an ink, paper or smoke tile).
 * Android can't change an icon in place, so the manifest has one <activity-alias> per icon (".IconSInk", ".IconSPaper", ".IconPageInk", ...), each with its own icon,
 * and exactly one is enabled at a time. The S on ink is the default and starts enabled in the manifest. The names here are the ones in the manifest
 * and in the resources (ic_<res>_background/foreground/monochrome, icon_preview_<res>).
 */
object AppIcon {
    /** One icon you can choose. [key] is the end of the name of its launcher entry (Icon + key); [res] is the middle of the names of its resources. */
    class Choice(val key: String, val label: String, val about: String, val res: String)

    val choices = listOf(
        Choice("SInk", "S, ink", "A ribbon S, light on near-black.", "s_ink"),
        Choice("SPaper", "S, paper", "The same S in black on white.", "s_paper"),
        Choice("SSmoke", "S, smoke", "A pale S on mid-grey.", "s_smoke"),
        Choice("PageInk", "Page, ink", "A light page on a near-black tile.", "page_ink"),
        Choice("PagePaper", "Page, paper", "A dark page on a white tile.", "page_paper"),
        Choice("PageSmoke", "Page, smoke", "A pale page on a mid-grey tile.", "page_smoke"),
    )

    const val DEFAULT_KEY = "SInk"

    /** [key] if it is one of the icons, otherwise the default one (also for the keys of the older icons, which are gone). */
    fun keyOrDefault(key: String?): String = choices.firstOrNull { it.key == key }?.key ?: DEFAULT_KEY

    /** The name of the launcher entry (the alias in the manifest) for an icon. */
    fun alias(key: String): String = "Icon" + keyOrDefault(key)

    /** Every launcher entry there is: one for each icon. */
    val aliases: List<String> get() = choices.map { alias(it.key) }

    /** The picture of an icon for the picker (icon_preview_<res> as a small image). */
    fun preview(key: String): Int = when (keyOrDefault(key)) {
        "SPaper" -> R.drawable.icon_preview_s_paper
        "SSmoke" -> R.drawable.icon_preview_s_smoke
        "PageInk" -> R.drawable.icon_preview_page_ink
        "PagePaper" -> R.drawable.icon_preview_page_paper
        "PageSmoke" -> R.drawable.icon_preview_page_smoke
        else -> R.drawable.icon_preview_s_ink
    }

    /** Shows the icon [key] and hides the others. Does nothing if it is already showing. */
    fun apply(ctx: Context, key: String) {
        val pm = ctx.packageManager
        val want = alias(key)
        val start = alias(DEFAULT_KEY)
        fun comp(name: String) = ComponentName(ctx.packageName, "app.scrapbook.$name")
        fun on(name: String): Boolean = when (pm.getComponentEnabledSetting(comp(name))) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> false
            else -> name == start // never touched: the manifest starts with the default enabled and the rest disabled
        }
        runCatching {
            // Turn the new one on first, so there is never a moment with no launcher icon at all.
            if (!on(want)) pm.setComponentEnabledSetting(comp(want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            aliases.filter { it != want && on(it) }.forEach {
                pm.setComponentEnabledSetting(comp(it), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
