package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppIconTest {
    @Test fun thereAreSixIconsWithDistinctKeysNamesAndResources() {
        assertEquals(6, AppIcon.choices.size)
        assertEquals(6, AppIcon.choices.map { it.key }.toSet().size)
        assertEquals(6, AppIcon.choices.map { it.label }.toSet().size)
        assertEquals(6, AppIcon.choices.map { it.res }.toSet().size)
        AppIcon.choices.forEach { assertTrue(it.key, it.about.isNotBlank()) }
        assertEquals(listOf("S, ink", "S, paper", "S, smoke", "Page, ink", "Page, paper", "Page, smoke"), AppIcon.choices.map { it.label })
    }

    @Test fun everyIconHasOneLauncherEntry() {
        assertEquals(6, AppIcon.aliases.size)
        assertEquals(6, AppIcon.aliases.toSet().size)
        assertEquals("IconSInk", AppIcon.alias("SInk"))
        assertEquals("IconPageSmoke", AppIcon.alias("PageSmoke"))
    }

    @Test fun theSOnInkIsTheDefault() {
        assertEquals("SInk", AppIcon.DEFAULT_KEY)
        assertEquals("IconSInk", AppIcon.alias(AppIcon.DEFAULT_KEY))
        assertEquals(AppIcon.DEFAULT_KEY, AppIcon.choices.first().key)
        assertEquals("S, ink", AppIcon.choices.first().label)
    }

    @Test fun anUnknownMissingOrOlderIconIsTheDefault() {
        assertEquals("SInk", AppIcon.keyOrDefault(null))
        assertEquals("SInk", AppIcon.keyOrDefault(""))
        assertEquals("SInk", AppIcon.keyOrDefault("Teal"))
        // the four older icons (and the glassy or flat choice that went with them) are gone, so anyone who had one lands on the default
        listOf("Wordmark", "Cutout", "Sticky", "Ripped").forEach { assertEquals(it, "SInk", AppIcon.keyOrDefault(it)) }
        assertEquals("PagePaper", AppIcon.keyOrDefault("PagePaper"))
        assertEquals("IconSInk", AppIcon.alias("nonsense"))
    }

    @Test fun theOlderLauncherEntriesAreGone() {
        listOf("Wordmark", "Cutout", "Sticky", "Ripped").forEach { k ->
            listOf("Glassy", "Flat").forEach { style -> assertFalse("Icon$k$style", AppIcon.aliases.contains("Icon$k$style")) }
        }
        listOf("Coral", "Teal", "Amber", "Violet", "Green", "Pink", "Blue").forEach { assertFalse(it, AppIcon.aliases.contains("Icon$it")) }
    }

    @Test fun theManifestHasEveryAliasAndOnlyTheDefaultStartsEnabled() {
        val manifest = java.io.File("src/main/AndroidManifest.xml").takeIf { it.exists() }?.readText() ?: return
        AppIcon.aliases.forEach { assertTrue(it, manifest.contains("android:name=\".$it\"")) }
        val enabled = Regex("""<activity-alias android:name="\.(Icon\w+)"[^>]*android:enabled="true"""").findAll(manifest).map { it.groupValues[1] }.toList()
        assertEquals(listOf(AppIcon.alias(AppIcon.DEFAULT_KEY)), enabled)
        // the app's own icon is the default one, and every alias points at its own icon
        val def = AppIcon.choices.first { it.key == AppIcon.DEFAULT_KEY }.res
        assertTrue(manifest.contains("android:icon=\"@mipmap/ic_$def\" android:roundIcon=\"@mipmap/ic_${def}_round\" android:supportsRtl"))
        AppIcon.choices.forEach { c ->
            assertTrue(c.key, manifest.contains("android:name=\".Icon${c.key}\"") && manifest.contains("android:icon=\"@mipmap/ic_${c.res}\" android:roundIcon=\"@mipmap/ic_${c.res}_round\">"))
        }
    }

    @Test fun everyIconHasItsResourcesAndTheOldOnesAreGone() {
        val res = java.io.File("src/main/res").takeIf { it.exists() } ?: return
        AppIcon.choices.forEach { c ->
            val n = "ic_${c.res}"
            listOf("background", "foreground", "monochrome").forEach { layer -> assertTrue("$n $layer", java.io.File(res, "drawable-nodpi/${n}_$layer.png").exists()) }
            assertTrue(n, java.io.File(res, "mipmap-anydpi-v26/$n.xml").exists())
            assertTrue("${n}_round", java.io.File(res, "mipmap-anydpi-v26/${n}_round.xml").exists())
            assertTrue("preview $n", java.io.File(res, "drawable-nodpi/icon_preview_${c.res}.png").exists())
        }
        val old = listOf("wordmark", "cutout", "sticky", "ripped").flatMap { k -> listOf("glassy", "flat").map { "ic_${k}_$it" } }
        old.forEach { n ->
            assertFalse(n, java.io.File(res, "drawable-nodpi/${n}_foreground.png").exists())
            assertFalse(n, java.io.File(res, "mipmap-anydpi-v26/$n.xml").exists())
        }
    }
}
