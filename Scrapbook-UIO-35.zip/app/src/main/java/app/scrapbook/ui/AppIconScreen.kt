package app.scrapbook.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

// The app's icon (Settings > Look & Feel > App's icon): a list of the icons you can choose, each shown in the style you have chosen (normal or glassy), so changing the style
// changes every picture at once. Choosing saves at once; the launcher itself changes when you leave the app (see AppIcon.kt and ArchiveViewModel.syncIcon).

/** The row in Look & Feel, made like the others in the list (a tile with a simple icon): the icon you have, by name and style, and a way to the page. */
@Composable
internal fun AppIconRow(key: String, glassy: Boolean, onClick: () -> Unit) {
    val choice = AppIcon.choices.first { it.key == AppIcon.keyOrDefault(key) }
    Row(Modifier.fillMaxWidth().height(64.dp).tap("App's icon, ${choice.label}, ${if (glassy) "glassy" else "normal"}", onClick).padding(horizontal = 16.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        IconTile("appicon")
        Text("App's icon", Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(choice.label + " \u00B7 " + (if (glassy) "Glassy" else "Normal"), fontSize = 15.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Ic("chevron", 20.dp, Sb.mute)
    }
}

@Composable
fun AppIconScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current
    val haptics = LocalHaptics.current
    val key by vm.appIconKey.collectAsState()
    val glassy by vm.appIconGlassy.collectAsState()
    val chosen = AppIcon.choices.first { it.key == key }
    Scaffold(containerColor = t.page) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                CircleBtn("Go back", { nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
                Box(Modifier.weight(1f), Alignment.Center) {
                    Text("scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp, maxLines = 1)
                }
                Spacer(Modifier.size(44.dp))
            }
            Text("App's icon", Modifier.padding(start = 28.dp, top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SettingsCard {
                    Column(Modifier.fillMaxWidth().padding(vertical = 22.dp, horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Image(painterResource(AppIcon.preview(chosen.key, glassy)), null, Modifier.size(112.dp).clip(RoundedCornerShape(28.dp)))
                        Spacer(Modifier.height(6.dp))
                        Text(chosen.label, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 22.sp)
                        Text(chosen.about, fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute, textAlign = TextAlign.Center)
                    }
                }
                ChoiceCard("Style", listOf("Normal", "Glassy"), if (glassy) 1 else 0,
                    if (glassy) "A glossy rim, a soft gradient and a beveled silver shape." else "Flat: plain white on the blue of the app.") { vm.setAppIconGlassy(it == 1) }
                SectionLabel("Icons")
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppIcon.choices.forEach { c ->
                        val on = c.key == key
                        SettingsCard {
                            Row(Modifier.fillMaxWidth().tap(if (on) "${c.label}, chosen" else "Choose ${c.label}") { if (!on) { haptics.confirm(); vm.setAppIcon(c.key) } }
                                .semantics { selected = on }.padding(start = 14.dp, end = 18.dp, top = 12.dp, bottom = 12.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                Image(painterResource(AppIcon.preview(c.key, glassy)), null, Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)))
                                Column(Modifier.weight(1f)) {
                                    Text(c.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(c.about, fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                                if (on) Ic("check", 24.dp, accentText(LocalSb.current.acc))
                            }
                        }
                    }
                }
                HomeFooter("The new icon shows on your home screen when you leave Scrapbook. Some launchers take a few seconds, and a few close the app when the icon changes. The icons do not follow the accent color.")
            }
        }
    }
}
