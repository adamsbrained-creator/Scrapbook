package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.ui.graphics.Brush
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// The Settings page follows the shared Settings mockup used across the apps: a round-button top bar, a summary card with a
// progress ring, small uppercase section labels, and grouped cards of rows (icon tile, label, value, chevron or switch).
// Choices open a picker sheet. The dark theme uses the same structure with dark tokens.

/** Switch track when off. */
private val trackOff get() = if (Sb.dark) Color(0xFF3A3A3A) else Color(0xFFCFCFCF)

/** One setting. label and keywords are what the search box matches. */
private class Setting(val label: String, val keywords: String = "", val content: @Composable () -> Unit)
private class SettingGroup(val title: String, val items: List<Setting>, val footer: String? = null)

/**
 * A page of settings: the main Settings page lists these, and each opens as its own page. [key] is what the rest of the app uses to open it, [blurb] the
 * grey line under its name, [value] an optional status on the right, and [groupTitles] which groups of settings it shows, in order.
 */
private class Category(val key: String, val title: String, val icon: String, val blurb: String, val groupTitles: List<String>, val value: String = "")

/** A row on the main Settings page that opens a page of settings: icon, name, a grey line saying what is inside, and an optional status. */
@Composable
private fun CategoryRow(icon: String, title: String, sub: String, value: String = "", onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(72.dp).tap(title, onClick).padding(horizontal = 16.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        IconTile(icon)
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (value.isNotEmpty()) Text(value, fontSize = 15.sp, color = Sb.mute)
        Ic("chevron", 20.dp, Sb.mute)
    }
}

/** A round 40dp button inside a 44dp touch target, used in the headers of Settings and About. */
@Composable
internal fun CircleBtn(desc: String, onClick: () -> Unit, onHold: (() -> Unit)? = null, holdLabel: String? = null, content: @Composable () -> Unit) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    Box(Modifier.pressScale(.9f).size(44.dp).then(if (onHold == null) Modifier.tap(desc, onClick)
        else Modifier.tapOrHold(desc, holdLabel, { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); onHold() }, onClick)), Alignment.Center) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Sb.card), Alignment.Center) { content() }
    }
}

/** The small "| Scrapbook" mark in the middle of the header. */
@Composable
internal fun BrandBar() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(2.dp).height(21.dp).clip(RoundedCornerShape(1.dp)).background(LocalSb.current.acc))
        Spacer(Modifier.width(3.dp))
        Text("Scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 22.sp, letterSpacing = (-0.02).em, maxLines = 1)
    }
}

/** The big page title under the header. */
@Composable
internal fun PageTitle(text: String) {
    Text(text, Modifier.padding(start = 24.dp, end = 24.dp, top = 10.dp), fontFamily = headFont(), fontWeight = FontWeight.Medium,
        fontSize = 34.sp, lineHeight = 39.sp, letterSpacing = (-0.02).em)
}

/** A row that opens something. value is shown in grey before the icon, which is a chevron, or "external" for a link that leaves the app. */
@Composable
internal fun NavRow(label: String, value: String = "", icon: String = "chevron", onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp).tap(label, onClick).padding(start = 18.dp, end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 16.sp)
        if (value.isNotEmpty()) Text(value, fontSize = 15.sp, color = Sb.mute)
        Spacer(Modifier.width(8.dp))
        Ic(icon, 18.dp, Sb.mute)
    }
}

/** A rounded grey card holding a group of rows. Put a RowDivider between rows. */
@Composable
internal fun GroupCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.card), content = content)
}

@Composable
internal fun RowDivider() {
    Box(Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(1.dp).background(Sb.line))
}

/** A card with 32dp corners: with 64dp rows that makes a pill. */
@Composable
internal fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(Sb.card), content = content)
}

/** [count] rows, each on a rounded card of its own (like the About row), with a small gap between the cards. [row] draws the row with the given index. */
@Composable
private fun CardStack(count: Int, row: @Composable (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(count) { i -> SettingsCard { row(i) } }
    }
}

/** Small uppercase label above a card. */
@Composable
internal fun SectionLabel(title: String) {
    Text(title.uppercase(), Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 12.dp).asHeading(), fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.4.sp, color = Sb.mute)
}

/** The 40dp rounded tile behind a row's icon. It takes the page color, so it sits slightly below the card. */
@Composable
internal fun IconTile(icon: String) {
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(Sb.paper), Alignment.Center) { Ic(icon, 20.dp, Sb.ink) }
}

/** A row that shows the current choice in grey (with an optional color dot) and opens a picker or page when tapped. */
@Composable
internal fun IconRow(icon: String, label: String, value: String = "", dot: Color? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(64.dp).tap(label, onClick).padding(horizontal = 16.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        IconTile(icon)
        Text(label, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (dot != null || value.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (dot != null) Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
            if (value.isNotEmpty()) Text(value, fontSize = 15.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Ic("chevron", 20.dp, Sb.mute)
    }
}

/** A row with an on/off switch instead of a chevron. */
@Composable
internal fun SwitchRow(icon: String, label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val acc = LocalSb.current.acc; val haptics = LocalHaptics.current
    Row(Modifier.fillMaxWidth().height(64.dp).toggleable(value = on, role = Role.Switch, onValueChange = { haptics.toggle(it); onChange(it) }).padding(horizontal = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        IconTile(icon)
        Text(label, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        // The thumb glides across (the track is 50dp wide, the thumb 24dp with 3dp around it, so it travels 20dp) and the track fades to the accent.
        val thumb by animateDpAsState(if (on) 20.dp else 0.dp, spring(dampingRatio = .75f, stiffness = Spring.StiffnessMedium), label = "thumb")
        val track by animateColorAsState(if (on) acc else trackOff, tween(180), label = "track")
        Box(Modifier.size(50.dp, 30.dp).clip(CircleShape).background(track), Alignment.CenterStart) {
            Box(Modifier.padding(3.dp).offset(x = thumb).size(24.dp).shadow(1.dp, CircleShape).clip(CircleShape).background(Color.White))
        }
    }
}

/** A row with an icon, a label, the current number and a slider under it. [onLive] follows the finger (so a preview changes at once); [onDone] saves when the finger lifts. */
@Composable
internal fun SliderRow(icon: String, label: String, value: Int, range: IntRange, onLive: (Int) -> Unit, onDone: (Int) -> Unit) {
    val acc = LocalSb.current.acc
    var live by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon)
            Text(label, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${live.roundToInt()}", fontSize = 15.sp, color = Sb.mute)
        }
        Slider(live, { live = it; onLive(it.roundToInt()) }, Modifier.fillMaxWidth(), valueRange = range.first.toFloat()..range.last.toFloat(),
            onValueChangeFinished = { onDone(live.roundToInt()) }, colors = SliderDefaults.colors(thumbColor = acc, activeTrackColor = acc, inactiveTrackColor = Sb.line))
    }
}

/** The card at the top: a ring showing how much of the archive is filed in boxes, a line of text and a button to the boxes. */
@Composable
private fun SummaryCard(filed: Int, total: Int, onView: () -> Unit) {
    val acc = LocalSb.current.acc
    val target = if (total == 0) 0f else filed.toFloat() / total
    // The ring fills (and the number counts up) when the page opens.
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val frac by animateFloatAsState(if (go) target else 0f, tween(900, easing = FastOutSlowInEasing), label = "ring")
    val track = Sb.ink.copy(alpha = .12f)
    Row(Modifier.appear("summary").padding(horizontal = 20.dp).fillMaxWidth().height(112.dp).clip(RoundedCornerShape(32.dp)).background(Sb.card).padding(horizontal = 18.dp),
        Arrangement.spacedBy(18.dp), Alignment.CenterVertically) {
        Box(Modifier.size(76.dp), Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 8.dp.toPx(); val r = 31.dp.toPx(); val tl = Offset(size.width / 2 - r, size.height / 2 - r); val sz = Size(2 * r, 2 * r)
                drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
                if (frac > 0f) drawArc(acc, -90f, 360f * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            Text("${(frac * 100).roundToInt()}%", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Organized", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(if (total == 0) "No scraps yet" else "$filed of $total in boxes", fontSize = 14.sp, color = Sb.mute)
        }
        Box(Modifier.height(48.dp).clip(CircleShape).background(Sb.ink).tap("Open boxes", onView).padding(horizontal = 22.dp), Alignment.Center) {
            Text("Boxes", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.paper)
        }
    }
}

/** What a picker sheet needs: the title, the choices, the current one, and what to do when one is chosen. dots shows a color next to each choice. */
internal class SettingPick(val title: String, val options: List<String>, val sel: Int, val dots: List<Color>? = null, val note: String? = null,
                          val custom: CustomPick? = null, val onPick: (Int) -> Unit)

/** An extra "Custom color" choice under the list: [rgb] is the color in use (null while one of the listed choices is), [onPick] saves a color chosen with the bars. */
internal class CustomPick(val rgb: Int?, val onPick: (Int) -> Unit)

/** Pick one of a few options. Choosing one applies it and closes the sheet. */
@Composable
internal fun PickerSheet(p: SettingPick, onDone: () -> Unit) {
    val acc = LocalSb.current.acc
    Sheet(p.title, onDone, doneLabel = "Cancel", soft = true) {
        p.options.forEachIndexed { i, o ->
            Row(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Sb.line.copy(alpha = .5f))
                .tap(o) { p.onPick(i); onDone() }.semantics { selected = i == p.sel }.padding(horizontal = 20.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    p.dots?.getOrNull(i)?.let { Box(Modifier.size(16.dp).clip(CircleShape).background(it)) }
                    Text(o, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
                if (i == p.sel) Ic("check", 22.dp, accentText(acc))
            }
        }
        p.custom?.let { cp ->
            var open by remember { mutableStateOf(false) }; var live by remember { mutableStateOf<Int?>(null) }
            Row(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Sb.line.copy(alpha = .5f))
                .tap("Custom color") { if (cp.rgb == null) cp.onPick(CustomColors.START_RGB); open = !open || cp.rgb == null }.semantics { selected = cp.rgb != null }.padding(horizontal = 20.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    val shown = live ?: cp.rgb
                    Box(Modifier.size(16.dp).clip(CircleShape).then(if (shown != null) Modifier.background(rgbColor(shown)) else Modifier.background(Brush.sweepGradient(listOf(Color(0xFFFF3B30), Color(0xFFFFCC00), Color(0xFF34C759), Color(0xFF00C7BE), Color(0xFF0A84FF), Color(0xFFBF5AF2), Color(0xFFFF3B30))))))
                    Text("Custom color", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
                if (cp.rgb != null) Ic("check", 22.dp, accentText(acc))
            }
            AnimatedVisibility(open, enter = fadeIn(tween(160)) + expandVertically(tween(200)), exit = fadeOut(tween(120)) + shrinkVertically(tween(160))) {
                Box(Modifier.padding(horizontal = 6.dp)) { RgbSliders(cp.rgb, { live = it }, { cp.onPick(it) }) }
            }
        }
        if (p.note != null) Text(p.note, Modifier.padding(horizontal = 6.dp), fontSize = 12.sp, color = Sb.mute)
    }
}

@Composable
fun SettingsScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val mode by vm.darkMode.collectAsState(); val grey by vm.greyBg.collectAsState(); val appBg by vm.appBackground.collectAsState();
    val defaultLayout by vm.defaultLayout.collectAsState(); val sortMode by vm.sortMode.collectAsState(); val sortAsc by vm.sortAsc.collectAsState()
    val boxStyle by vm.boxStyle.collectAsState(); val showPreview by vm.showPreview.collectAsState();
    val plainPhotoPref by vm.plainPhotos.collectAsState(); val hashtagPref by vm.hashtagTags.collectAsState(); val linkSuggest by vm.linkSuggestions.collectAsState(); val showSavedPref by vm.showSaved.collectAsState(); val pasteOfferPref by vm.pasteOffers.collectAsState(); val marksAcc by vm.marksAccent.collectAsState(); val linksAcc by vm.linksAccent.collectAsState(); val hashAcc by vm.hashtagsAccent.collectAsState(); val reopenLast by vm.reopenLastBox.collectAsState(); val iconKey by vm.appIconKey.collectAsState(); val iconGlassy by vm.appIconGlassy.collectAsState()
    val boxSearch by vm.showBoxSearch.collectAsState(); val accentCustom by vm.accentCustom.collectAsState(); val autoKeyPref by vm.autoKeyboard.collectAsState(); val followSpeed by vm.followSpeed.collectAsState()
    val hapticsOn by vm.haptics.collectAsState(); val view = LocalView.current
    val pinSet by vm.pinSet.collectAsState(); val lockOn by vm.lockOn.collectAsState(); val bioOn by vm.biometricOn.collectAsState()
    val lockDelay by vm.lockDelay.collectAsState(); val hideRecents by vm.hideRecents.collectAsState()
    val hiddenOpen by vm.hiddenUnlocked.collectAsState(); val hasHidden by vm.hasHiddenBoxes.collectAsState()
    val activity = remember(ctx) { ctx.fragmentActivity() }; val bioAvailable = remember(ctx) { biometricAvailable(ctx) }
    val editorMode by vm.editorStyle.collectAsState(); val findMode by vm.findEntry.collectAsState()
    val shelves by vm.shelves.collectAsState(); val scraps by vm.items.collectAsState(); val bin by vm.bin.collectAsState()
    var msg by remember { mutableStateOf("") }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty() }
    var picker by remember { mutableStateOf<String?>(null) }
    val account by vm.account.collectAsState()
    // Opened from a link in the editor's menu: the search is already filled in (and the keyboard stays down).
    // The main page lists a few pages, each with its own settings (the groups below say what goes where; the footers and search still use the groups).
    val categories = listOf(
        Category("look", "Look & Feel", "palette", "Theme, accent, app icon, haptics", listOf("Look", "Feedback")),
        Category("home", "Home and lists", "grid", "View, sorting, box style, Customize home and menu", listOf("Home and lists")),
        Category("boxes", "Boxes", "folder", "Manage boxes, order, search", listOf("Boxes")),
        Category("editor", "Editor", "edit", "Pasting, #tags, links, toolbar, find", listOf("Editor")),
        Category("privacy", "Privacy", "lock", "PIN, fingerprint, hidden boxes", listOf("Privacy"), value = if (lockOn) "On" else "Off"),
        Category("data", "Data and backup", "backup", "Bin, back up, restore, import", listOf("Data")),
    )
    // Opened from a link in the editor's menu: a page's name ("Look", "Editor", "Data") opens that page, anything else fills in the search (and the keyboard stays down).
    val preset = remember { vm.settingsSearch.also { vm.settingsSearch = "" } }
    val presetPage = categories.firstOrNull { it.key.equals(preset, true) }?.key
    var page by rememberSaveable { mutableStateOf(presetPage) }
    val presetSearch = if (presetPage == null) preset else ""
    var searching by remember { mutableStateOf(presetSearch.isNotEmpty()) }; var q by remember { mutableStateOf(presetSearch) }
    val focus = remember { FocusRequester() }
    var skipFocus by remember { mutableStateOf(presetSearch.isNotEmpty()) }
    LaunchedEffect(searching) { if (searching) { if (skipFocus) skipFocus = false else focus.requestFocus() } }
    BackHandler(page != null) { page = null }   // first, so that closing the search (below) comes before leaving the page
    BackHandler(searching) { searching = false; q = "" }

    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.restoreBackup(u) { n -> msg = if (n < 0) "Couldn't read that file." else "Restored $n new items." }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        if (us.isNotEmpty()) vm.importTexts(us) { r -> msg = r.message() }
    }
    val folderImporter = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) vm.importFolder(u) { r -> msg = r.message() }
    }
    val importStatus by vm.importStatus.collectAsState()

    // Sorting. Choosing a sort field also resets the order to that field's natural one (newest first, A to Z).
    val sortTitle = sortMode == SortMode.Title
    val orderOptions = if (sortTitle) listOf("A to Z", "Z to A") else listOf("Newest first", "Oldest first")
    val orderIndex = if (sortTitle) (if (sortAsc) 0 else 1) else (if (sortAsc) 1 else 0)
    val boxStyles = BOX_STYLES
    val cornerIndex = when (t.radius.value.toInt()) { 4 -> 0; 24 -> 2; else -> 1 }
    val themeOptions = listOf("System", "Light", "Dark"); val sizeOptions = listOf("Compact", "Regular", "Large")
    val editorOptions = listOf("Selection bubble", "Floating pill"); val findOptions = listOf("Hold the back button", "3-dot menu", "Both")
    val bgOptions = listOf("White", "Soft grey"); val viewOptions = ListLayout.entries.map { it.label }; val headingOptions = listOf("Serif", "Sans"); val cornerOptions = listOf("Sharp", "Soft", "Round")

    // Every choice opens one of these sheets.
    val picks = mapOf(
        "theme" to SettingPick("Theme", themeOptions, mode) { vm.setDark(it) },
        "accent" to SettingPick("Accent color", Themes.map { it.name }, if (accentCustom != null) -1 else Themes.indexOfFirst { it.name == t.name }, dots = Themes.map { it.acc },
            note = "The launcher icon follows the ready-made accents; a color of your own gets the icon closest to it.", custom = CustomPick(accentCustom) { vm.setAccentCustom(it) }) { vm.setAccent(it) },
        "bg" to SettingPick("Background", bgOptions, if (grey) 1 else 0, note = "The dark theme always uses a black background.") { vm.setGreyBg(it == 1) },
        "headings" to SettingPick("Headings", headingOptions, if (t.serif) 0 else 1) { vm.setSerif(it == 0) },
        "corners" to SettingPick("Corners", cornerOptions, cornerIndex) { vm.setRadius(listOf(4, 14, 24)[it]) },
        "view" to SettingPick("Default view", viewOptions, defaultLayout.ordinal) { vm.setDefaultLayout(ListLayout.entries[it]) },
        "sortBy" to SettingPick("Sort by", SortMode.entries.map { it.label }, sortMode.ordinal) { i -> SortMode.entries[i].let { if (it != sortMode) vm.setSort(it) } },
        "sortOrder" to SettingPick("Sort order", orderOptions, orderIndex) { i -> vm.setSortAsc(if (sortTitle) i == 0 else i == 1) },
        "boxStyle" to SettingPick("Box style", boxStyles, boxStyle.coerceIn(0, boxStyles.lastIndex)) { vm.setBoxStyle(it) },
        "editor" to SettingPick("Editor toolbar", editorOptions, editorMode) { vm.setEditorStyle(it) },
        "lockDelay" to SettingPick("Lock after leaving the app", LOCK_DELAY_LABELS, lockDelay, note = "How long you can be away before the app lock and the hidden boxes lock again.") { vm.setLockDelay(it) },
        "follow" to SettingPick("Scrolling while you type", CaretFollow.SPEEDS, followSpeed, note = "How fast the page moves to keep the cursor in view as you write. Calm and Normal glide, Quick keeps up with fast typing, and Instant jumps at once. It never moves while a finger is on the page.") { vm.setFollowSpeed(it) },
        "find" to SettingPick("Find in a scrap", findOptions, findMode.coerceIn(0, 2), note = "Hold the back button for a moment, in the editor or the reading view: it turns into a search button. Or add a Find in scrap row to the 3-dot menu.") { vm.setFindEntry(it) },
    )

    val groups = listOf(
        SettingGroup("Look", listOf(
            Setting("Theme", "appearance mode light dark system") { IconRow("palette", "Theme", themeOptions[mode.coerceIn(0, 2)]) { picker = "theme" } },
            Setting("Accent color", "colour theme coral teal amber violet green pink blue custom rgb") { IconRow("accent", "Accent color", t.name, dot = t.acc) { picker = "accent" } },
            Setting("App's icon", "app icon launcher home screen logo glassy normal flat wordmark scrap cut-out sticky ripped") { AppIconRow(iconKey, iconGlassy) { nav.navigate("appicon") } },
            Setting("Background", "page white grey gray gradient glow animated color rgb wallpaper blue") { IconRow("page", "Background", when (appBg.kind) { 1 -> "Gradient"; 2 -> "Glow"; else -> bgOptions[if (grey) 1 else 0] }) { nav.navigate("background") } },
            Setting("Headings", "font serif sans type") { IconRow("headsize", "Headings", headingOptions[if (t.serif) 0 else 1]) { picker = "headings" } },
            Setting("Corners", "radius sharp soft round") { IconRow("corner", "Corners", cornerOptions[cornerIndex]) { picker = "corners" } },
        )),
        SettingGroup("Account", listOf(
            Setting("Account", "profile name nickname picture photo avatar about me birthday pronouns") { IconRow("person", "Account", account.callName) { nav.navigate("account") } },
        )),
        SettingGroup("Home and lists", listOf(
            Setting("Customize home", "header size layout wordmark add button pill bottom bar writing bar boxes order activity show hide greeting parts drag design capture pinned recent continue skin skins schedule look corners cards space tint accent color section quote counter button gestures") {
                // Home's own settings (header, add button, order of the boxes, designs) live in Customize home: this opens it.
                IconRow("grid", "Customize home", "Header, add button, boxes…") { vm.pendingCustomize = true; if (!nav.popBackStack("home", false)) nav.navigate("home") }
            },
            Setting("Draw gestures", "draw gesture gestures shape letter symbol open box scrap two fingers teach bind") {
                // A shape drawn with two fingers opens a box or a scrap, from any page (see DrawGestures.kt).
                IconRow("edit", "Draw gestures", "Open a box or a scrap by drawing") { nav.navigate("draw") }
            },
            Setting("Customize menu", "menus menu skin skins style float classic minimal bento sheet windows rearrange order hide show remove drag group buttons dim icons rows rename name title shortcut shortcuts binder preset presets setup profile button close accent footer line undo") {
                // The menu's own settings (its skin, what it holds and in what order) live on their own page.
                IconRow("menu", "Customize menu", "Skin, entries, order…") { nav.navigate("menus") }
            },
            Setting("Default view", "layout view cards list grid") { IconRow(defaultLayout.icon, "Default view", defaultLayout.label) { picker = "view" } },
            Setting("Sort by", "order title date edited created") { IconRow("sort", "Sort by", sortMode.label) { picker = "sortBy" } },
            Setting("Sort order", "newest oldest first a to z") { IconRow("down", "Sort order", orderOptions[orderIndex]) { picker = "sortOrder" } },
            Setting("Box style", "boxes tiles paper stack tabbed tinted folder chips list rows notebook covers") { IconRow("layout", "Box style", boxStyles[boxStyle.coerceIn(0, boxStyles.lastIndex)]) { picker = "boxStyle" } },
            Setting("Show note preview", "text snippet lines") { SwitchRow("list", "Show note preview", showPreview) { vm.setShowPreview(it) } },
        )),
        SettingGroup("Boxes", listOf(
            Setting("Manage boxes", "collections folders create delete") {
                IconRow("folder", "Manage boxes", when (shelves.size) { 0 -> "No boxes"; 1 -> "1 box"; else -> "${shelves.size} boxes" }) { nav.navigate("collections") }
            },
            Setting("Show search in boxes", "search bar field find hide clean") { SwitchRow("search", "Show search in boxes", boxSearch) { vm.setShowBoxSearch(it) } },
            Setting("Open last box on launch", "start startup reopen remember resume folder") { SwitchRow("clock", "Open last box on launch", reopenLast) { vm.setReopenLastBox(it) } },
        )),
        SettingGroup("Editor", listOf(
            Setting("Show photos as plain pictures", "photo photos picture polaroid frame tape normal plain image style") { SwitchRow("image", "Show photos as plain pictures", plainPhotoPref) { vm.setPlainPhotos(it) } },
            Setting("Offer to format pasted text", "paste smart link url quote list checklist clipboard format") { SwitchRow("edit", "Offer to format pasted text", pasteOfferPref) { vm.setPasteOffers(it) } },
            Setting("Turn #words into tags", "hashtag tag hash social media write type") { SwitchRow("tag", "Turn #words into tags", hashtagPref) { vm.setHashtagTags(it) } },
            Setting("Open the keyboard automatically", "keyboard focus open pops up appears edit write type tap start automatically auto") { SwitchRow("edit", "Open the keyboard automatically", autoKeyPref) { vm.setAutoKeyboard(it) } },
            Setting("Show \"Saved\" in the editor", "saved indicator header blink distracting hide text") { SwitchRow("check", "Show \"Saved\" in the editor", showSavedPref) { vm.setShowSaved(it) } },
            Setting("Suggest links between scraps", "connected backlinks link suggestions related mentions") { SwitchRow("link", "Suggest links between scraps", linkSuggest) { vm.setLinkSuggestions(it) } },
            Setting("Accent color on #hashtags", "hashtag color accent colour normal text") { SwitchRow("accent", "Accent color on #hashtags", hashAcc) { vm.setHashtagsAccent(it) } },
            Setting("Accent color on list marks", "bullets checkboxes boxes quote bar color accent colour normal text") { SwitchRow("palette", "Accent color on list marks", marksAcc) { vm.setMarksAccent(it) } },
            Setting("Accent color on links", "links link color accent colour normal text underline") { SwitchRow("link", "Accent color on links", linksAcc) { vm.setLinksAccent(it) } },
            Setting("Scrolling while you type", "scroll scrolling follow cursor typing speed smooth fast slow auto page caret") { IconRow("down", "Scrolling while you type", CaretFollow.SPEEDS[followSpeed]) { picker = "follow" } },
            Setting("Editor toolbar", "editor selection bubble floating pill") { IconRow("edit", "Editor toolbar", editorOptions[editorMode.coerceIn(0, 1)]) { picker = "editor" } },
            Setting("Find in a scrap", "search find inside note editor hold back button menu text") { IconRow("search", "Find in a scrap", findOptions[findMode.coerceIn(0, 2)]) { picker = "find" } },
        )),
        SettingGroup("Feedback", listOf(
            // Turning haptics on gives one right away so you can feel what it is; turning them off stays quiet.
            Setting("Haptic feedback", "vibration vibrate tick buzz touch feel") { SwitchRow("vibrate", "Haptic feedback", hapticsOn) { vm.setHaptics(it); if (it) Haptics(view, true).confirm() } },
        ), footer = "A light tick when you check a task, pin a scrap or file it in a box. Android's own touch feedback setting still applies."),
        SettingGroup("Privacy", buildList {
            add(Setting("App lock", "pin password passcode lock security private biometric fingerprint") {
                SwitchRow("lock", "App lock", lockOn) { on ->
                    if (on) { if (pinSet) vm.setLockOn(true) else vm.pinFlow.value = PinFlow.Create("Choose a PIN") { vm.setLockOn(true) } }
                    else vm.pinFlow.value = PinFlow.Verify("Enter your PIN to turn off the lock") { vm.setLockOn(false) }
                }
            })
            if (pinSet && bioAvailable) add(Setting("Unlock with fingerprint", "biometric fingerprint face touch unlock") {
                SwitchRow("fingerprint", "Unlock with fingerprint", bioOn) { on ->
                    if (on) activity?.let { a -> promptBiometric(a, "Turn on fingerprint unlock") { vm.setBiometricOn(true) } } else vm.setBiometricOn(false)
                }
            })
            add(Setting("Lock after leaving the app", "lock delay timeout minutes immediately away") { IconRow("clock", "Lock after leaving the app", LOCK_DELAY_LABELS[lockDelay]) { picker = "lockDelay" } })
            add(Setting("Hide in recent apps", "recent apps screenshots screen capture hide private") { SwitchRow("eye", "Hide in recent apps", hideRecents) { vm.setHideRecents(it) } })
            if (pinSet) add(Setting("Change PIN", "pin password passcode change") {
                IconRow("lock", "Change PIN") { vm.pinFlow.value = PinFlow.Verify("Enter your current PIN") { vm.pinFlow.value = PinFlow.Create("Choose a new PIN") } }
            })
            if (hiddenOpen) add(Setting("Lock hidden boxes now", "hidden boxes lock") { IconRow("lock", "Lock hidden boxes now") { vm.lockHiddenNow() } })
            if (pinSet) add(Setting("Remove PIN", "pin password passcode remove delete") {
                IconRow("close", "Remove PIN") {
                    vm.pinFlow.value = PinFlow.Verify(if (hasHidden) "Enter your PIN. Removing it shows your hidden boxes again." else "Enter your PIN to remove it") { vm.removePin() }
                }
            })
        }, footer = "One PIN does it all: the app lock, fingerprint unlock and your hidden boxes (hide a box when you edit it). A forgotten PIN cannot be recovered. Backup files are not encrypted."),
        SettingGroup("Data", listOf(
            Setting("Bin", "trash deleted recycle restore undo") {
                IconRow("trash", "Bin", when (bin.size) { 0 -> "Empty"; 1 -> "1 scrap"; else -> "${bin.size} scraps" }) { nav.navigate("bin") }
            },
            Setting("Back up archive", "export save zip") {
                IconRow("backup", "Back up archive") {
                    scope.launch {
                        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", vm.buildBackup())
                        ctx.startActivity(android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_SEND)
                            .apply { type = "application/zip"; putExtra(android.content.Intent.EXTRA_STREAM, uri); addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Back up archive"))
                    }
                }
            },
            Setting("Restore from backup", "import zip") { IconRow("restore", "Restore from backup") { restore.launch(arrayOf("application/zip", "application/octet-stream")) } },
            Setting("Import scraps", "text markdown word docx zip files") {
                IconRow("newfile", "Import scraps") { importer.launch(arrayOf("text/*", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/zip", "application/octet-stream")) }
            },
            Setting("Import a folder of notes", "samsung notes sdocx docx word folder bulk migrate move") {
                IconRow("newfile", "Import a folder of notes") { folderImporter.launch(null) }
            },
        ), footer = importStatus.ifEmpty { msg.ifEmpty { "A backup is one zip with every scrap and photo. To bring in Samsung Notes: select notes there, tap Share > Samsung Notes file, copy the files it saves (its files/share folder) to a normal folder, then pick that folder here." } }),
        // No label: the About page sits on its own card at the very end, like in the other apps.
        SettingGroup("", listOf(
            Setting("About Scrapbook", "about version what's new licenses feedback info") { IconRow("info", "About Scrapbook", version) { nav.navigate("about") } },
        )),
    )

    val query = q.trim()
    val visible = groups.map { g ->
        g to g.items.filter { s -> query.isEmpty() || g.title.contains(query, true) || s.label.contains(query, true) || s.keywords.contains(query, true) }
    }.filter { it.second.isNotEmpty() }

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.page) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
                Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(if (page != null && !searching) "Back to settings" else "Go back", { if (page != null && !searching) page = null else nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
                    Box(Modifier.weight(1f), Alignment.Center) {
                        Text("scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp, maxLines = 1)
                    }
                    if (searching) CircleBtn("Close search", { searching = false; q = "" }) { Ic("close", 22.dp, Sb.ink) }
                    else CircleBtn("Search settings", { searching = true }) { Ic("search", 22.dp, Sb.ink) }
                }
                if (searching) {
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp).clip(RoundedCornerShape(28.dp)).background(Sb.card).padding(horizontal = 16.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Ic("search", 22.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                        BasicTextField(q, { q = it }, Modifier.weight(1f).focusRequester(focus), singleLine = true, textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(t.acc),
                            decorationBox = { inner -> Box { if (q.isEmpty()) Text("Search settings", color = Sb.mute, fontSize = 16.sp); inner() } })
                    }
                } else Text(categories.firstOrNull { it.key == page }?.title ?: "Settings", Modifier.padding(start = 28.dp, top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                // Searching shows matching settings from every page; otherwise it is the list of pages, or the settings of the page that is open.
                Crossfade(if (searching) "~search" else page ?: "~main", Modifier.weight(1f), animationSpec = tween(180), label = "settingsPage") { shown ->
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        val cat = categories.firstOrNull { it.key == shown }
                        when {
                            shown == "~search" -> {
                                visible.forEach { (g, items) ->
                                    Column(Modifier.appear("group-${g.title}")) {
                                        if (g.title.isNotEmpty()) SectionLabel(g.title) else Spacer(Modifier.height(12.dp))
                                        CardStack(items.size) { ii -> items[ii].content() }
                                        if (g.footer != null) Text(g.footer, Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp), fontSize = 12.sp, color = Sb.mute)
                                    }
                                }
                                if (visible.isEmpty()) Text("No settings match “$query”.", Modifier.padding(24.dp), fontSize = 15.sp, color = Sb.mute)
                            }
                            cat != null -> {
                                val gs = cat.groupTitles.mapNotNull { gt -> groups.firstOrNull { it.title == gt } }
                                if (gs.size == 1) Spacer(Modifier.height(14.dp))
                                gs.forEach { g ->
                                    Column(Modifier.appear("page-${cat.key}-${g.title}")) {
                                        if (gs.size > 1) SectionLabel(g.title)
                                        CardStack(g.items.size) { ii -> g.items[ii].content() }
                                        if (g.footer != null) Text(g.footer, Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp), fontSize = 12.sp, color = Sb.mute)
                                    }
                                }
                            }
                            else -> {
                                Spacer(Modifier.height(14.dp))
                                SummaryCard(scraps.count { it.collection.isNotBlank() && it.collection != "Inbox" }, scraps.size) { nav.navigate("collections") }
                                Spacer(Modifier.height(14.dp))
                                Column(Modifier.appear("pages")) {
                                    CardStack(categories.size) { i -> val c = categories[i]; CategoryRow(c.icon, c.title, c.blurb, c.value) { page = c.key } }
                                    Spacer(Modifier.height(20.dp))
                                    AccountCard(account) { nav.navigate("account") }
                                    Spacer(Modifier.height(10.dp))
                                    // The About page sits on its own card, like in the other apps.
                                    SettingsCard { groups.first { it.title.isEmpty() }.items.forEach { it.content() } }
                                }
                            }
                        }
                        Spacer(Modifier.height(32.dp))
                    }
                }
            }
        }
        picker?.let { key -> picks[key]?.let { PickerSheet(it) { picker = null } } }
    }
}
