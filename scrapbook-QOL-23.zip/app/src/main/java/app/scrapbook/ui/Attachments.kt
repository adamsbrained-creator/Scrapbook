package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import app.scrapbook.*
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** The first page of a PDF as a small picture, and how many pages it has. */
private class PdfPreview(val page: ImageBitmap, val pages: Int)

/** A few recent previews, so scrolling back to a note does not draw them again. */
private val pdfCache = android.util.LruCache<String, PdfPreview>(16)

/** Draws page one at [widthPx] wide with Android's own PDF renderer. Null if the file cannot be read (damaged, or locked with a password). */
private fun renderPdf(file: File, widthPx: Int): PdfPreview? = try {
    val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    try {
        val r = PdfRenderer(fd)
        try {
            val pages = r.pageCount
            if (pages == 0) null else {
                val page = r.openPage(0)
                try {
                    val h = (widthPx * page.height.toFloat() / page.width).toInt().coerceIn(1, widthPx * 3)
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    PdfPreview(bmp.asImageBitmap(), pages)
                } finally { page.close() }
            }
        } finally { r.close() }
    } finally { fd.close() }
} catch (e: Throwable) { null }

@Composable
private fun pdfPreview(a: Attachment): PdfPreview? {
    val state = produceState<PdfPreview?>(pdfCache.get(a.path), a.path) {
        if (value == null) value = withContext(Dispatchers.IO) { renderPdf(a.file(), 220)?.also { pdfCache.put(a.path, it) } }
    }
    return state.value
}

private fun uriFor(ctx: Context, a: Attachment) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", a.file())

/** Opens the file in whatever app on the phone can show it. If there is none, offers to send it somewhere instead (Files, Drive...). */
fun openAttachment(ctx: Context, a: Attachment) {
    if (!a.file().exists()) { Toast.makeText(ctx, "This file is no longer on the phone.", Toast.LENGTH_SHORT).show(); return }
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(ctx, a), a.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(view) }
    catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app here can open this file. Choose where to send it instead.", Toast.LENGTH_LONG).show()
        shareAttachment(ctx, a)
    }
}

/** The share sheet for the file, so it can be saved to Files, sent to a friend, and so on. */
fun shareAttachment(ctx: Context, a: Attachment) {
    if (!a.file().exists()) { Toast.makeText(ctx, "This file is no longer on the phone.", Toast.LENGTH_SHORT).show(); return }
    try {
        val uri = uriFor(ctx, a)
        val send = Intent(Intent.ACTION_SEND).setType(a.mime.ifBlank { "*/*" }).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = ClipData.newRawUri(a.name, uri)
        ctx.startActivity(Intent.createChooser(send, a.name))
    } catch (e: Exception) {
        Toast.makeText(ctx, "This file could not be shared.", Toast.LENGTH_SHORT).show()
    }
}

/** The small picture at the left of a card: page one for a PDF, the picture itself for an image, otherwise the file type in the accent color. */
@Composable
private fun AttachmentThumb(a: Attachment, pdf: PdfPreview?) {
    val t = LocalSb.current; val shape = RoundedCornerShape(10.dp)
    val m = Modifier.size(52.dp, 68.dp).clip(shape)
    when {
        pdf != null -> Image(pdf.page, null, m.background(Color.White).border(1.dp, Sb.line, shape), alignment = Alignment.TopCenter, contentScale = ContentScale.Crop)
        a.isImage -> AsyncImage(a.path, a.name, m, contentScale = ContentScale.Crop)
        else -> Box(m.background(t.acc.copy(alpha = .16f)), Alignment.Center) { Text(a.typeLabel, color = t.acc, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
    }
}

/**
 * One attached file: a thumbnail, its name, and what it is (type, pages for a PDF, size). Tap opens it, and holding it opens the share sheet (in the editor, the reading page and the save screen alike). In the editor [onRemove] puts an X
 * at the right to take it off the scrap; without it (the reading page) there is a share button instead.
 */
@Composable
fun AttachmentCard(a: Attachment, onRemove: (() -> Unit)? = null) {
    val ctx = LocalContext.current; val t = LocalSb.current; val haptic = LocalHapticFeedback.current
    val missing = remember(a.path) { !a.file().exists() }
    val pdf = if (a.isPdf && !missing) pdfPreview(a) else null
    val sub = buildList {
        add(a.typeLabel)
        if (pdf != null) add(if (pdf.pages == 1) "1 page" else "${pdf.pages} pages")
        add(if (missing) "missing" else formatSize(a.size))
    }.joinToString(" · ")
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(minOf(t.radius, 18.dp))).background(Sb.card)
            .tapOrHold("Open ${a.name}", "Share ${a.name}", onHold = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); shareAttachment(ctx, a) }) { openAttachment(ctx, a) }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AttachmentThumb(a, pdf)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.name, color = Sb.ink, fontFamily = headFont(), fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Sb.mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
        if (onRemove != null) Box(Modifier.size(40.dp).clip(CircleShape).tap("Remove ${a.name}", onRemove), Alignment.Center) { Ic("close", 18.dp, Sb.mute) }
        else Box(Modifier.size(40.dp).clip(CircleShape).tap("Share ${a.name}") { shareAttachment(ctx, a) }, Alignment.Center) { Ic("share", 18.dp, Sb.mute) }
    }
}

/** All of a scrap's files, one card each, with a little room between. Nothing is drawn when there are none. */
@Composable
fun AttachmentList(files: List<Attachment>, modifier: Modifier = Modifier, onRemove: ((Attachment) -> Unit)? = null) {
    if (files.isEmpty()) return
    Column(modifier, Arrangement.spacedBy(8.dp)) {
        files.forEach { a -> key(a.path) { AttachmentCard(a, if (onRemove == null) null else ({ onRemove(a) })) } }
    }
}
