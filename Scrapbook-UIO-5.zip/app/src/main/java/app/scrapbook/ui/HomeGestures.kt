package app.scrapbook.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlin.math.roundToInt

// New gestures on Home (UIO 4).
//
//  Hold      Hold a box, a scrap, a section title or the greeting for a moment: it lifts a little and, when you let go, a small menu pops up next to it.
//  Drag      Keep holding and move: the thing comes along with your finger over the whole page (not only inside its own row). Let go and
//              - on a box: a scrap dropped on a box is filed in it;
//              - on one of your sections: it is added there;
//              - anywhere else: a new section is made at that spot, holding it. A section is a row of shortcuts you can rename, lay out and fill.
//
// One listener watches the whole Home page (dragHost), instead of each card listening for itself. That is what lets a dragged thing keep going when the
// page scrolls under it (the card it started from may have scrolled out of sight), and it never gets in the way of taps or of scrolling: it only
// takes over once a finger has stayed put for the hold time.

/** What is being carried. [sourceKey] is the block of the page it came from (dropping it back there does nothing); [sourceSection] is the section it was taken from, if any. */
class DragPayload(val id: String, val ref: SectionRef, val label: String, val dot: Color?, val sourceKey: String, val sourceSection: String? = null)

/** What letting go would do right now. */
sealed class DropTarget {
    object None : DropTarget()
    /** A scrap dropped on the box with this key: it is filed there. */
    class File(val box: String) : DropTarget()
    /** Dropped on one of your sections. */
    class Into(val section: String) : DropTarget()
    /** Dropped in the open: a new section, right after the block [after] (null = at the very top). */
    class NewAt(val after: String?) : DropTarget()
}

/** The state of one Home page's gestures: what can be held, where the drop places are, and what is being carried. */
@Stable
class HomeDrag {
    /** Something that can be held (and maybe carried). [payload] null means it can only be held, for its menu. */
    class Spot(val id: String, val rect: Rect, val payload: DragPayload?, val onHold: () -> Unit)

    private val spots = HashMap<String, Spot>()
    private val rects = HashMap<String, Rect>()

    /** Where the page's gesture area is on the screen, so a finger position can be turned into a screen position. */
    var hostOrigin: Offset = Offset.Zero
    var hostHeight: Float = 0f
    var fileOn: Boolean = true

    /** What is being carried (null when nothing is), and where the finger is on the screen. */
    var active: DragPayload? by mutableStateOf(null)
        private set
    var pos: Offset by mutableStateOf(Offset.Zero)
        private set
    /** The id of the thing that has been held and lifted, before it starts to move. */
    var held: String? by mutableStateOf(null)

    fun putSpot(s: Spot) { spots[s.id] = s }
    fun forgetSpot(id: String) { spots.remove(id) }
    fun putRect(key: String, r: Rect) { rects[key] = r }
    fun forgetRect(key: String) { rects.remove(key) }
    fun rectOf(key: String): Rect? = rects[key]

    /** The smallest thing that can be held at this screen position. */
    fun spotAt(p: Offset): Spot? = spots.values.filter { it.rect.contains(p) }.minByOrNull { it.rect.width * it.rect.height }

    fun begin(p: DragPayload, at: Offset) { active = p; pos = at; held = null }
    fun move(at: Offset) { pos = at }
    fun end() { active = null; held = null }

    /** The top of the highest block of the page that is on screen. */
    fun topOfBlocks(): Float? = rects.filterKeys { !it.startsWith("box:") }.values.minOfOrNull { it.top }

    /** What letting go of [p] at screen position [at] would do. */
    fun resolve(p: DragPayload, at: Offset): DropTarget {
        if (!p.ref.box && fileOn) {
            for ((k, r) in rects) if (k.startsWith("box:") && r.contains(at)) return DropTarget.File(k.removePrefix("box:").substringBefore('\u0001'))
        }
        for ((k, r) in rects) {
            if (k.startsWith("section:") && r.contains(at)) {
                val id = k.removePrefix("section:")
                return if (id == p.sourceSection) DropTarget.None else DropTarget.Into(id)
            }
        }
        if (rects[p.sourceKey]?.contains(at) == true) return DropTarget.None
        val blocks = rects.filterKeys { !it.startsWith("box:") }.map { (k, r) -> BlockSpan(k, r.top, r.bottom) }
        val after = HomeSections.dropAfter(blocks, at.y) ?: (if (rects.containsKey("header")) "header" else null)
        return DropTarget.NewAt(after)
    }
}

/** Makes a thing holdable: it reports where it is, grows a little while held and fades while it is being carried. [onHold] is what the hold does (opens its menu). Put it first in the chain. */
@Composable
fun Modifier.pickUp(state: HomeDrag, id: String, payload: DragPayload?, onHold: () -> Unit): Modifier {
    val hold by rememberUpdatedState(onHold)
    val load by rememberUpdatedState(payload)
    DisposableEffect(id) { onDispose { state.forgetSpot(id) } }
    val scale by animateFloatAsState(if (state.held == id) 1.05f else 1f, spring(dampingRatio = .6f, stiffness = 500f), label = "pickUp")
    return this
        .onGloballyPositioned { state.putSpot(HomeDrag.Spot(id, it.boundsInRoot(), load, { hold() })) }
        .graphicsLayer { scaleX = scale; scaleY = scale; alpha = if (state.active?.id == id) .3f else 1f }
}

/** Reports where a block of the page, a section or a box is, so a dropped thing can find it. [key] is the part's key, "section:<id>" or "box:<name>". */
@Composable
fun Modifier.dropRect(state: HomeDrag, key: String): Modifier {
    DisposableEffect(key) { onDispose { state.forgetRect(key) } }
    return this.onGloballyPositioned { state.putRect(key, it.boundsInRoot()) }
}

/**
 * Wraps something on Home so it can be held: [menu] is the pop-up that opens next to it. With [payload] it can also be picked up and carried.
 * [menu] gets a function that closes the pop-up.
 */
@Composable
fun HoldSlot(state: HomeDrag, id: String, payload: DragPayload?, modifier: Modifier = Modifier, menu: @Composable ColumnScope.(close: () -> Unit) -> Unit, content: @Composable () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier.pickUp(state, id, payload) { open = true }) {
        content()
        PopupMenu(open, { open = false }) { menu { open = false } }
    }
}

/**
 * Put on the Home page's content: watches every finger that lands on something holdable. A tap or a scroll is left completely alone. A finger that stays put for the hold time
 * lifts the thing; then, if the finger moves, the thing is carried ([onDrop] gets it, and the screen position, when the finger lifts); if it does not move, the thing's menu opens
 * when the finger lifts (at once, if the thing cannot be carried).
 */
@Composable
fun Modifier.dragHost(state: HomeDrag, holdOn: Boolean, dragOn: Boolean, onDrop: (DragPayload, Offset) -> Unit): Modifier {
    val haptics = LocalHaptics.current
    val dropIt by rememberUpdatedState(onDrop)
    return this
        .onGloballyPositioned { state.hostOrigin = it.positionInRoot(); state.hostHeight = it.size.height.toFloat() }
        .pointerInput(state, holdOn, dragOn) {
            if (!holdOn && !dragOn) return@pointerInput
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val spot = state.spotAt(down.position + state.hostOrigin) ?: return@awaitEachGesture
                val pl = spot.payload
                val canDrag = dragOn && pl != null
                if (!canDrag && !holdOn) return@awaitEachGesture
                val slop = viewConfiguration.touchSlop
                // Wait for the hold time. A finger that moves or lifts before then is an ordinary tap or scroll: nothing is touched.
                val early = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                    var out = false
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val c = ev.changes.firstOrNull { it.id == down.id }
                        if (c == null || !c.pressed || (c.position - down.position).getDistance() > slop) { out = true; break }
                    }
                    out
                }
                if (early != null) return@awaitEachGesture
                haptics.tick()
                state.held = spot.id
                if (!canDrag) spot.onHold()
                var dragging = false
                var released = false
                try {
                    // From here on the gesture is ours: nothing underneath scrolls or taps.
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!c.pressed) { c.consume(); released = true; break }
                        if (!dragging && pl != null && canDrag && (c.position - down.position).getDistance() > slop) {
                            dragging = true
                            state.begin(pl, c.position + state.hostOrigin)
                        }
                        if (dragging) state.move(c.position + state.hostOrigin)
                        c.consume()
                    }
                    if (released) {
                        if (dragging) state.active?.let { dropIt(it, state.pos) }
                        else if (canDrag && holdOn) spot.onHold()
                    }
                } finally {
                    state.end()
                }
            }
        }
}

/** The look of the carried thing and of the place it would land: drawn over the whole page while something is being carried. */
@Composable
fun DragOverlay(state: HomeDrag, modifier: Modifier = Modifier) {
    val p = state.active ?: return
    val at = state.pos
    val acc = LocalSb.current.acc
    val d = LocalDensity.current
    val origin = state.hostOrigin
    val target = state.resolve(p, at)
    Box(modifier.fillMaxSize()) {
        when (target) {
            is DropTarget.File -> state.rectOf("box:${target.box}")?.let { TargetFrame(it, origin, acc) }
            is DropTarget.Into -> state.rectOf("section:${target.section}")?.let { TargetFrame(it, origin, acc) }
            is DropTarget.NewAt -> {
                val line = (target.after?.let { state.rectOf(it)?.bottom } ?: state.topOfBlocks()?.let { it - with(d) { 18.dp.toPx() } }) ?: at.y
                val y = line + with(d) { 9.dp.toPx() } - origin.y
                Box(Modifier.offset { IntOffset(0, (y - 3.dp.toPx()).roundToInt()) }.fillMaxWidth().padding(horizontal = 24.dp).height(6.dp).clip(CircleShape).background(acc))
                Text("New section here", Modifier.align(Alignment.TopCenter).offset { IntOffset(0, (y - 38.dp.toPx()).roundToInt()) }.clip(CircleShape).background(acc).padding(horizontal = 14.dp, vertical = 6.dp),
                    color = onAccent(acc), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            else -> {}
        }
        Ghost(p, Modifier.offset { IntOffset((at.x - origin.x).roundToInt(), (at.y - origin.y).roundToInt()) })
    }
}

/** A frame around the place the carried thing would land. */
@Composable
private fun TargetFrame(r: Rect, origin: Offset, acc: Color) {
    val d = LocalDensity.current
    Box(Modifier.offset { IntOffset((r.left - origin.x).roundToInt(), (r.top - origin.y).roundToInt()) }
        .size(with(d) { r.width.toDp() }, with(d) { r.height.toDp() }).border(3.dp, acc, RoundedCornerShape(24.dp)))
}

/** The carried thing: a small floating card with its name, held just above the finger so the finger does not hide it. */
@Composable
private fun Ghost(p: DragPayload, modifier: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Row(modifier.graphicsLayer { translationX = -size.width / 2f; translationY = -size.height - 14.dp.toPx(); scaleX = 1.04f; scaleY = 1.04f }
        .shadow(16.dp, shape).background(Sb.raised, shape).padding(horizontal = 16.dp, vertical = 12.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        if (p.dot != null) Box(Modifier.size(14.dp).clip(CircleShape).background(p.dot)) else Ic("page", 18.dp, Sb.mute)
        Text(p.label, Modifier.widthIn(max = 200.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** What Home's parts need to be held: given to the page with [LocalHomeGestures]. Where it is not given (the previews in Customize home) nothing can be held. */
class HomeGestureEnv(val drag: HomeDrag, val vm: ArchiveViewModel, val actions: HomeActions, val holdOn: Boolean, val dragOn: Boolean)

val LocalHomeGestures = compositionLocalOf<HomeGestureEnv?> { null }

/** The title row of a part (Boxes, Pinned, Recent) can be held for its own menu. [id] must be different for each part. */
class PartHold(val id: String, val menu: @Composable ColumnScope.(close: () -> Unit) -> Unit)

/** Reports where a part of the page is, so a dropped thing can be placed between parts. [key] is the part's key (see HomeElement). Does nothing where nothing can be held. */
@Composable
fun Modifier.homeBlock(key: String): Modifier {
    val g = LocalHomeGestures.current ?: return this
    return dropRect(g.drag, key)
}

/** A scrap on Home, in whatever design: hold it for its menu, keep holding and move to carry it. [where] is the part it is shown in ("pinned", "recent", "continue"). */
@Composable
fun HeldScrap(n: Item, where: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val g = LocalHomeGestures.current
    if (g == null) { Box(modifier) { content() }; return }
    val id = "$where:${n.uid}"
    HoldSlot(g.drag, id, DragPayload(id, SectionRef(false, n.uid), n.displayTitle, null, where), modifier, menu = { close -> ScrapMenu(n, g.actions, g.vm, close) }, content = content)
}

/** A box on Home, in whatever design: hold it for its menu, carry it, or drop a scrap on it to file the scrap there. [name] is the box's key, [label] what it is called. */
@Composable
fun HeldBox(name: String, label: String, dot: Color, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val g = LocalHomeGestures.current
    if (g == null) { Box(modifier) { content() }; return }
    val id = "boxspot:$name"
    HoldSlot(g.drag, id, DragPayload(id, SectionRef(true, name), label, dot, "boxes"), modifier.dropRect(g.drag, "box:$name"), menu = { close -> BoxMenu(name, g.actions, close) }, content = content)
}

/** Customize home > the gestures: three switches, under the list of parts. */
@Composable
fun GestureSettings(prefs: GesturePrefs, onChange: (GesturePrefs) -> Unit) {
    SectionLabel("Gestures")
    SettingsCard {
        SwitchRow("grip", "Hold for a menu", prefs.hold) { onChange(prefs.copy(hold = it)) }
        SwitchRow("layout", "Hold and drag to move", prefs.drag) { onChange(prefs.copy(drag = it)) }
        SwitchRow("folder", "Drop a scrap on a box to file it", prefs.file) { onChange(prefs.copy(file = it)) }
    }
    HomeFooter("Hold a box, a scrap, a part's title or the greeting. Keep holding and move to carry a box or a scrap: drop it on a box to file a scrap there, on one of your sections to add it, or on an empty spot of Home to start a new section.")
}

// ---------------------------------------------------------------------------------------------------------------------------------
// What the hold menus can do. Home gives each action; the menus only decide which ones to offer.
// ---------------------------------------------------------------------------------------------------------------------------------

class HomeActions(
    val open: (Item) -> Unit,
    val openBox: (String) -> Unit,
    val newScrapIn: (String) -> Unit,
    val editBox: (String) -> Unit,
    val newBoxIn: (String) -> Unit,
    val deleteBox: (String) -> Unit,
    val inboxColor: () -> Unit,
    val sortInbox: () -> Unit,
    val moveScrap: (Item) -> Unit,
    val tagScrap: (Item) -> Unit,
    val deleteScrap: (Item) -> Unit,
    val toSection: (SectionRef) -> Unit,
    val customize: () -> Unit,
    val account: () -> Unit,
)

/** The menu of a scrap. Inside a section it can also take the scrap out of that section (it is only a shortcut: the scrap itself stays). */
@Composable
fun ColumnScope.ScrapMenu(n: Item, a: HomeActions, vm: ArchiveViewModel, close: () -> Unit, inSection: Boolean = false, onRemove: () -> Unit = {}) {
    val haptics = LocalHaptics.current
    PopupItem("Open", "arrow") { close(); a.open(n) }
    PopupItem(if (n.pinned) "Unpin" else "Pin", if (n.pinned) "star" else "starline") { close(); haptics.tick(); vm.togglePin(n) }
    PopupItem("Add to box", "folder") { close(); a.moveScrap(n) }
    PopupItem("Add to a section", "plus") { close(); a.toSection(SectionRef(false, n.uid)) }
    if (inSection) PopupItem("Remove from this section", "close") { close(); onRemove() }
    PopupItem("Tags", "tag") { close(); a.tagScrap(n) }
    PopupItem("Duplicate", "copy") { close(); vm.duplicate(n) }
    PopupDivider()
    PopupItem("Delete", "trash", tint = Sb.danger) { close(); a.deleteScrap(n) }
}

/** The menu of a box (Inbox has its own short list, because it is built in). */
@Composable
fun ColumnScope.BoxMenu(name: String, a: HomeActions, close: () -> Unit, inSection: Boolean = false, onRemove: () -> Unit = {}) {
    val inbox = name == "Inbox"
    PopupItem("Open", "folder") { close(); a.openBox(name) }
    PopupItem("New scrap here", "plus") { close(); a.newScrapIn(name) }
    if (inbox) {
        PopupItem("Sort Inbox", "sort") { close(); a.sortInbox() }
        PopupItem("Inbox color", "palette") { close(); a.inboxColor() }
    } else {
        PopupItem("Edit box", "edit") { close(); a.editBox(name) }
        PopupItem("New box inside", "newfile") { close(); a.newBoxIn(name) }
    }
    PopupItem("Add to a section", "layout") { close(); a.toSection(SectionRef(true, name)) }
    if (inSection) PopupItem("Remove from this section", "close") { close(); onRemove() }
    PopupDivider()
    PopupItem(if (inbox) "Remove Inbox" else "Delete box", "trash", tint = Sb.danger) { close(); a.deleteBox(name) }
}

/** The menu of a part's title on Home (Boxes, Pinned, Recent): move it, hide it, or open Customize home. */
@Composable
fun ColumnScope.PartMenu(e: HomeElement, layout: HomeLayout, onLayout: (HomeLayout) -> Unit, a: HomeActions, close: () -> Unit) {
    val up = layout.shifted(e, -1); val down = layout.shifted(e, 1)
    if (up != layout) PopupItem("Move up", "up") { close(); onLayout(up) }
    if (down != layout) PopupItem("Move down", "down") { close(); onLayout(down) }
    PopupItem("Hide ${e.label}", "eyeoff") { close(); onLayout(layout.withHidden(e, true)) }
    PopupItem("Customize home", "sliders") { close(); a.customize() }
}

/** The menu of the greeting: its options live in Customize home now, so that is where this leads. */
@Composable
fun ColumnScope.GreetingMenu(a: HomeActions, close: () -> Unit) {
    PopupItem("Customize home", "sliders") { close(); a.customize() }
    PopupItem("Account", "person") { close(); a.account() }
}
