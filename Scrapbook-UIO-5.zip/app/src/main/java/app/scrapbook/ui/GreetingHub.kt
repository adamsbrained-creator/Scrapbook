package app.scrapbook.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.Date
import kotlin.random.Random

// The greeting at the top of Home: a line that fits the time of day (and now and then the day, your scraps or your birthday), your name from the Account page and your
// picture. It changes by itself every so often (the greeting options in Customize home), and a tap shows another one straight away. The rules for which lines exist and which fit are in
// Greetings.kt; this file only shows them.

private data class HubStats(val scraps: Int, val inbox: Int, val pinned: Int)

@Composable
fun GreetingHub(
    account: Account, prefs: GreetingPrefs, scraps: Int, inbox: Int, pinned: Int, modifier: Modifier = Modifier,
    /** The design (Customize home > Greeting): 0 classic, 1 centered, 2 on a card. With [picLeft] the picture comes before the text. The sizes are the greeting's own sliders. */
    style: Int = 0, picLeft: Boolean = false, onProfile: () -> Unit,
) {
    val haptics = LocalHaptics.current
    val acc = LocalSb.current.acc
    val stats by rememberUpdatedState(HubStats(scraps, inbox, pinned))
    val acct by rememberUpdatedState(account)
    val filter = prefs.filter()
    // Everything that makes the current line wrong when it changes: a new greeting is picked at once.
    val inputs = listOf(account.callName, account.birthMonth, account.birthDay, filter)

    /** Picks a greeting for this moment, remembers it as shown, and returns it with the name and counts filled in. */
    fun pickNow(): String {
        val cal = Calendar.getInstance()
        val a = acct; val s = stats
        val month = cal.get(Calendar.MONTH) + 1; val day = cal.get(Calendar.DAY_OF_MONTH)
        val ctx = GreetingContext(
            name = a.callName, hour = cal.get(Calendar.HOUR_OF_DAY), dayOfWeek = cal.get(Calendar.DAY_OF_WEEK), month = month, day = day,
            inbox = s.inbox, scraps = s.scraps, pinned = s.pinned, birthday = a.isBirthday(month, day, Account.isLeap(cal.get(Calendar.YEAR))),
        )
        val g = Greetings.pick(ctx, filter, GreetingHistory.recent(), Random.Default)
        GreetingHistory.add(g.id)
        return Greetings.render(g, ctx)
    }

    var text by remember(inputs) { mutableStateOf(pickNow()) }
    LaunchedEffect(inputs, prefs.everySec) {
        if (prefs.everySec > 0) while (true) { delay(prefs.everySec * 1000L); text = pickNow() }
    }

    val date = remember(text) { Fmt.of("EEEE, d MMMM").format(Date()) }
    val sub = when (prefs.sub) {
        0 -> date
        1 -> account.about.lineSequence().firstOrNull().orEmpty().ifBlank { date }
        2 -> when { scraps == 0 -> "Nothing saved yet"; inbox > 0 -> "${Greetings.count(scraps)} · $inbox in Inbox"; else -> Greetings.count(scraps) }
        else -> ""
    }

    val textSp = prefs.textSize.coerceIn(GreetingPrefs.TEXT_MIN, GreetingPrefs.TEXT_MAX)
    val picDp = prefs.picSize.coerceIn(GreetingPrefs.PIC_MIN, GreetingPrefs.PIC_MAX)
    val center = style == 1
    val align = if (center) TextAlign.Center else TextAlign.Start

    @Composable
    fun TextBlock(m: Modifier) {
        Column(m.tap("Show another greeting") { haptics.tick(); text = pickNow() }, horizontalAlignment = if (center) Alignment.CenterHorizontally else Alignment.Start) {
            if (sub.isNotEmpty()) Text(sub, fontSize = (textSp * .5f).coerceIn(11f, 15f).sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align)
            AnimatedContent(text, transitionSpec = { fadeIn(tween(380)) togetherWith fadeOut(tween(220)) }, label = "greeting") { line ->
                Text(line, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = textSp.sp, lineHeight = (textSp * 1.2f).sp, letterSpacing = (-textSp * .013f).sp, textAlign = align)
            }
            if (!account.hasName) Text("Tell me your name", Modifier.tap("Open your account", onProfile).padding(top = 6.dp, bottom = 4.dp), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = accentText(acc))
        }
    }

    // A small picture still gets a 44dp touch area.
    @Composable
    fun Picture() {
        if (prefs.avatar) Box(Modifier.sizeIn(minWidth = 44.dp, minHeight = 44.dp).tap("Open your account", onProfile), Alignment.Center) { AvatarView(account, picDp.dp) }
    }

    @Composable
    fun Line() {
        if (center) Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp), Alignment.CenterHorizontally) { Picture(); TextBlock(Modifier.fillMaxWidth()) }
        else Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
            if (picLeft) Picture()
            TextBlock(Modifier.weight(1f))
            if (!picLeft) Picture()
        }
    }

    if (style == 2) Box(modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card).padding(horizontal = 20.dp, vertical = 16.dp)) { Line() }
    } else Box(modifier.fillMaxWidth().padding(horizontal = 24.dp)) { Line() }
}
