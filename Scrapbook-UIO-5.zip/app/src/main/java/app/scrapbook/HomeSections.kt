package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder

// Home sections: your own rows on the Home page, made by dragging a scrap or a box out of Home and letting go (see ui/HomeGestures.kt).
// A section only POINTS at things: it never moves, copies or deletes a scrap or a box, so removing a section (or an item from it) is always safe.
// This file holds only the rules (where a section sits, what it holds, how it is saved), so they are tested on their own (HomeSectionsTest).

/** How a section lays out what it holds. [key] is what is saved, so never rename one. */
enum class SectionLayout(val key: String, val label: String, val icon: String) {
    Cards("cards", "Cards", "layout"),
    Chips("chips", "Chips", "tag"),
    Rows("rows", "Rows", "list"),
    Grid("grid", "Grid", "grid");

    companion object {
        fun of(key: String?): SectionLayout = entries.firstOrNull { it.key == key } ?: Cards
    }
}

/** One thing a section holds: a box (by its permanent key, "Inbox" included) or a scrap (by its uid, which survives a backup restore). */
data class SectionRef(val box: Boolean, val key: String)

/**
 * A section of Home. [anchor] is the key of the Home part it sits right after (see HomeElement), or "" for the very top.
 * Sections with the same anchor sit in the order of the list.
 */
data class HomeSection(
    val id: String,
    val title: String = "",
    val layout: SectionLayout = SectionLayout.Cards,
    val anchor: String = "",
    val refs: List<SectionRef> = emptyList(),
) {
    /** What the section is called on screen. */
    val name: String get() = title.ifBlank { "New section" }
    fun has(r: SectionRef): Boolean = r in refs
}

/** One block of the Home page from top to bottom: one of its parts, or one of your sections. [key] is also what the page reports its place under. */
sealed class HomeSlot {
    abstract val key: String

    data class Part(val element: HomeElement) : HomeSlot() {
        override val key: String get() = element.key
    }

    data class Sec(val section: HomeSection) : HomeSlot() {
        override val key: String get() = "section:" + section.id
    }
}

/** Where a block of the page is on the screen, top to bottom, in px. */
class BlockSpan(val key: String, val top: Float, val bottom: Float)

/** The gesture settings (Settings > Gestures). [hold] opens a menu, [drag] lets a held thing be picked up, [file] lets a scrap dropped on a box go into it. */
data class GesturePrefs(val hold: Boolean = true, val drag: Boolean = true, val file: Boolean = true)

object HomeSections {
    const val MAX_TITLE = 40

    fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(10)

    fun cleanTitle(s: String): String = s.trim().take(MAX_TITLE)

    /**
     * Every block of the page in order, hidden parts included (a hidden part keeps its place, and the sections after it stay where they are).
     * Sections that sit at the very top come first; a section whose part no longer exists goes last.
     */
    fun slots(order: List<HomeElement>, sections: List<HomeSection>): List<HomeSlot> {
        val out = ArrayList<HomeSlot>()
        val known = order.map { it.key }.toSet()
        sections.filter { it.anchor.isEmpty() }.forEach { out.add(HomeSlot.Sec(it)) }
        for (e in order) {
            out.add(HomeSlot.Part(e))
            sections.filter { it.anchor == e.key }.forEach { out.add(HomeSlot.Sec(it)) }
        }
        sections.filter { it.anchor.isNotEmpty() && it.anchor !in known }.forEach { out.add(HomeSlot.Sec(it)) }
        return out
    }

    /** The sections as the blocks say they are placed: each one now sits after the part before it. The list comes out in page order. */
    fun reanchor(slots: List<HomeSlot>): List<HomeSection> {
        val out = ArrayList<HomeSection>()
        var anchor = ""
        for (s in slots) {
            when (s) {
                is HomeSlot.Part -> anchor = s.element.key
                is HomeSlot.Sec -> out.add(s.section.copy(anchor = anchor))
            }
        }
        return out
    }

    /** Adds [section] right after the block [afterKey] (a part's key or "section:<id>"); null puts it at the very top. A key that is not on the page puts it last. */
    fun insert(order: List<HomeElement>, sections: List<HomeSection>, section: HomeSection, afterKey: String?): List<HomeSection> {
        val all = slots(order, sections).toMutableList()
        val at = if (afterKey == null) 0 else all.indexOfFirst { it.key == afterKey }.let { if (it < 0) all.size else it + 1 }
        all.add(at, HomeSlot.Sec(section))
        return reanchor(all)
    }

    /** Moves a section one place up ([dir] = -1) or down (+1) the page, past one block (hidden parts do not count). At the end of the page nothing changes. */
    fun move(order: List<HomeElement>, hidden: Set<HomeElement>, sections: List<HomeSection>, id: String, dir: Int): List<HomeSection> {
        val all = slots(order, sections).toMutableList()
        val i = all.indexOfFirst { it is HomeSlot.Sec && it.section.id == id }
        if (i < 0 || dir == 0) return sections
        var j = i + dir
        while (j in all.indices && all[j].let { it is HomeSlot.Part && it.element in hidden }) j += dir
        if (j !in all.indices) return sections
        val s = all.removeAt(i)
        all.add(j, s)
        return reanchor(all)
    }

    fun update(sections: List<HomeSection>, id: String, change: (HomeSection) -> HomeSection): List<HomeSection> =
        sections.map { if (it.id == id) change(it) else it }

    fun remove(sections: List<HomeSection>, id: String): List<HomeSection> = sections.filterNot { it.id == id }

    /** Puts [ref] in the section (nothing changes if it is already there). */
    fun withRef(sections: List<HomeSection>, id: String, ref: SectionRef): List<HomeSection> =
        update(sections, id) { if (it.has(ref)) it else it.copy(refs = it.refs + ref) }

    fun withoutRef(sections: List<HomeSection>, id: String, ref: SectionRef): List<HomeSection> =
        update(sections, id) { it.copy(refs = it.refs - ref) }

    /** Takes [ref] out of section [from] (null = it was not in a section) and puts it in section [to]. */
    fun moveRef(sections: List<HomeSection>, from: String?, to: String, ref: SectionRef): List<HomeSection> =
        withRef(if (from == null || from == to) sections else withoutRef(sections, from, ref), to, ref)

    /** The key of the block a thing dropped at height [y] would go after: the last block whose middle is above [y]. Null if it is above them all. */
    fun dropAfter(blocks: List<BlockSpan>, y: Float): String? =
        blocks.sortedBy { it.top }.lastOrNull { (it.top + it.bottom) / 2f < y }?.key

    // ----- Saved form: one line per section ("S|id|layout|anchor|title") followed by one per thing in it ("B|box key" or "N|scrap uid"). Every text is URL-encoded, so no | or line break can appear inside one. -----

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    fun encode(sections: List<HomeSection>): String = buildString {
        for (s in sections) {
            append("S|").append(enc(s.id)).append('|').append(s.layout.key).append('|').append(enc(s.anchor)).append('|').append(enc(s.title)).append('\n')
            for (r in s.refs) append(if (r.box) "B|" else "N|").append(enc(r.key)).append('\n')
        }
    }

    /** Reads what [encode] wrote. Anything that does not make sense (a thing before any section, a repeated id, a half line) is skipped, never an error. */
    fun decode(text: String?): List<HomeSection> {
        val out = ArrayList<HomeSection>()
        val seen = HashSet<String>()
        var cur: HomeSection? = null
        for (line in text.orEmpty().split('\n')) {
            val p = line.split('|')
            when (p[0]) {
                "S" -> {
                    cur?.let { out.add(it) }
                    cur = null
                    if (p.size >= 5 && p[1].isNotEmpty() && seen.add(dec(p[1]))) cur = HomeSection(dec(p[1]), dec(p[4]), SectionLayout.of(p[2]), dec(p[3]))
                }
                "B", "N" -> {
                    val c = cur
                    if (c != null && p.size >= 2 && p[1].isNotEmpty()) {
                        val r = SectionRef(p[0] == "B", dec(p[1]))
                        if (r !in c.refs) cur = c.copy(refs = c.refs + r)
                    }
                }
            }
        }
        cur?.let { out.add(it) }
        return out
    }
}

/** Moves a part one place up or down among the parts that are shown (hidden ones are stepped over). At the top or bottom nothing changes. */
fun HomeLayout.shifted(e: HomeElement, dir: Int): HomeLayout {
    val i = order.indexOf(e)
    if (i < 0 || dir == 0) return this
    var j = i + dir
    while (j in order.indices && order[j] in hidden) j += dir
    return if (j in order.indices) move(i, j) else this
}
