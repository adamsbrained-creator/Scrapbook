Scrapbook — UI Overhaul (UIO) Development Log

Project: Scrapbook
Milestone: UI Overhaul (UIO)
Status: In progress
Base: Quality of Life update (scrapbook-QOL-88)

Goal: a complete overhaul of the app's look, with more customization, built section by section.
Entries are added in the order they are built. Each one says what the feature is for and what was built.

———

Section: Home

☑ 1. New greeting: account system (Scrapbook-UIO-1)
   For: the greeting needs to know who it is talking to, and the app needs a place for the person behind it.
   Built: an Account with name, nickname, a line about you, pronouns, birthday (no year) and a profile picture (photo, or initial on a chosen color).
   Stored only on this phone. New Account page, an account card at the top of Settings, a profile icon, picture cropping and saving (Avatar.kt).

☑ 2. More greeting options and views: greeting lines and settings (Scrapbook-UIO-1)
   For: a greeting that feels alive instead of the same line every day.
   Built: 170+ greetings across time of day (late night to night), weekdays, casual lines, lines about your scraps (Inbox, pinned, empty, large archive)
   and birthday / New Year's Day lines, in friendly, playful and calm voices. {name} drops out neatly when no name is set. The greeting changes by itself
   (never, 10, 20, 40 or 90 seconds), on every tap, and avoids repeating recent lines. New Settings > Greeting page: show or hide, show my picture,
   line under the greeting (date, about me, scrap count, nothing), change interval, tone, and switches for time-of-day, casual and scrap-related lines.
   The greeting on Home now uses the account's name and picture; tapping the picture opens the Account page.

☑ 3. Greeting: smaller by default, text and picture resize freely (Scrapbook-UIO-1.5)
   For: the greeting took too much room at the top of Home, and everyone wants a different size.
   Built: the greeting now starts smaller (text 24, picture 44 instead of 30 and 56). Settings > Greeting has a live preview and two sliders:
   Text size (14 to 44) and Picture size (20 to 96). The preview follows the slider while you drag, and the size is saved when you let go.
   The line under the greeting scales with the text, and a small picture still has a 44dp touch area.

☑ 4. Account card moved down in Settings (Scrapbook-UIO-1.5)
   For: the account card at the very top pushed the settings down; it belongs with the About page.
   Built: the account card now sits right above the About page, below the list of settings pages.

☑ 5. Greeting options moved into Customize home (Scrapbook-UIO-1.6)
   For: every part of Home is meant to keep its own options next to where it is moved and hidden, so the greeting's settings belong there and not in Settings.
   Built: a row in Customize home can now have a sliders button (and tapping its name does the same) that opens that part's own options page; the Greeting row has one.
   The page keeps the live preview pinned on top and holds text size, picture size, show my picture, the line under the greeting, how often it changes, the tone and the
   three switches for the kinds of lines. The Greeting page in Settings is gone (the Account card stays). Showing or hiding the greeting is still the eye on its row.
   Other parts can get their own options the same way (withOptions and options in HomeCustomize, ui/GreetingOptions.kt).

☑ 6. Home layout: move and hide every part (Scrapbook-UIO-2)
   For: Home should look the way you want it: any part can go anywhere, or be switched off.
   Built: Home is now made of eight parts (Header, Greeting, Quick capture, Continue, To sort, Boxes, Pinned, Recent), each with a place in the order and an on/off switch.
   New Customize home in the Home menu: one short row per part with a drag handle (hold and drag to move it) and an eye (tap to hide or bring it back), a Back to the usual order
   button, and Move up / Move down actions for screen readers. Hidden parts keep their place. The order and the hidden parts are saved on this phone (HomeLayout.kt, ui/HomeEdit.kt).
   Home reads the saved layout and draws its parts in that order. The old "Show greeting" and "Show boxes on home" switches in Settings now use the same on/off state,
   and an update keeps whatever they were set to. With the header hidden, a small menu button stays so the menu can always be reached.

☑ 7. Optional designs for the parts of Home (Scrapbook-UIO-3)
   For: every part of Home can look the way you like, but only if you want it to. Nothing changes until a design is chosen; each part keeps its classic look by default.
   Built: the sliders button on a row in Customize home now opens an options page for Capture, Continue, Boxes, Pinned and Recent as well (the Greeting already had one).
   Each page has a preview of the real part with your own scraps on top, one segmented choice per design under it with a line saying what it looks like, and a
   Back to the classic look button once something is chosen. The row in Customize home shows the chosen design under the name.
   Designs: Greeting (classic, centered, on a card; picture left or right, next to its size sliders), Quick capture (classic, slim one line, icons only),
   Continue (classic, thin line, with a preview of the text), Boxes (chips, grid of two columns, list), Pinned (cards in a row in three sizes, list, grid of two columns),
   Recent (cards, compact lines; 3, 4, 6 or 8 scraps). The choices are saved on this phone (HomeStyles.kt, ui/HomeDesignOptions.kt, the part designs in ui/HomePage.kt).

☑ 8. Home settings moved into Customize home (Scrapbook-UIO-3.1)
   For: every part of Home keeps its own settings next to where it is moved, hidden and styled, so Settings no longer holds the ones that are only about Home.
   Built: the Header row in Customize home now has a sliders button too. Its page has a preview of the real header and two choices, Layout (left, center, round) and Size
   (compact, regular, large), which used to be "Main page header" and "Header size" in Settings. Quick capture's page gets the Add button choice (pill, bottom bar, writing bar,
   one button an arc, swipe-up sheet). Boxes' page gets the switch that orders the boxes by activity. They are the same settings as before and keep their values; the header and
   the add button still apply to the other main pages. "Show boxes on home" is gone from Settings (it is the eye on the Boxes row, as the greeting's switch was before it).
   Settings keeps the lists settings (default view, sorting, box style, note preview) and gets a Customize home row on the Home and lists page that opens Customize home;
   searching Settings for header, add button or order of boxes finds it. The About page's tips for the add button styles now say where to find them.

☑ 9. Hold menus on Home (Scrapbook-UIO-4)
   For: every box and scrap on Home needs its actions one touch away, without opening it first.
   Built: hold a box, a scrap (pinned, recent or the Continue card), a part's title (Boxes, Pinned, Recent) or the greeting, and when you let go a small pop-up menu opens next to it.
   Boxes: open, new scrap here, edit, new box inside, add to a section, delete (Inbox has its own short list: sort, color, remove). Scraps: open, pin or unpin, add to a box,
   add to a section, tags, duplicate, delete. A part's title: move up, move down, hide, Customize home. The greeting: Customize home, Account. It works in every design of
   every part, and holding a recent scrap now opens this menu instead of asking to delete it right away (ui/HomeGestures.kt, HeldScrap and HeldBox in the designs of ui/HomePage.kt).

☑ 10. Hold and drag to carry things over the whole page (Scrapbook-UIO-4)
   For: moving something should not stop at the edge of its own row.
   Built: keep holding a box or a scrap and move: it lifts, follows your finger over the whole page (not clipped by its row) and the page scrolls by itself near the top and
   bottom edge. While you carry it, the place it would land is marked: a frame around a box or a section, or a bar with "New section here" between two parts. One listener
   watches the whole page, so a tap or a scroll is never affected and a carried thing is not lost when the page scrolls under it (HomeDrag, dragHost, DragOverlay).
   Letting go on the place it came from does nothing.

☑ 11. Sections made by dropping (Scrapbook-UIO-4)
   For: a row of Home that is entirely yours: a few scraps and boxes you want together, wherever you want them.
   Built: drop a carried scrap or box on an empty spot of Home and a new section appears right there, holding it. A section has a name, one of four layouts (cards, chips,
   rows, grid) and whatever you put in it: drop more things on it, or open Edit (tap the word, or hold the title) to rename it, change the layout, take things out and add boxes
   and scraps from a list with search. Hold the title to move the section up or down, or delete it. Things inside a section can be held and carried too: to another section,
   to a box, or into the open for a new section. A section only holds shortcuts: taking something out or deleting a section never touches a scrap or a box. "Add to a section"
   in a hold menu does the same without dragging. Every drop can be undone from the message that appears. Saved on this phone (HomeSections.kt, ui/HomeSectionsUi.kt; test HomeSectionsTest).

☑ 12. Drop a scrap on a box to file it (Scrapbook-UIO-4)
   For: sorting a scrap into a box in one move, right from Home.
   Built: carry a scrap onto a box (in the Boxes row, in any of its designs, or inside a section) and let go: the box gets a frame while you are over it, and the scrap is
   moved into it, with a message to undo. Dropping on the box it is already in does nothing.

☑ 13. Gestures switches in Customize home (Scrapbook-UIO-4)
   For: hold and drag are new, so each one can be switched off.
   Built: under the list of parts in Customize home, a Gestures group with three switches: hold for a menu, hold and drag to move, drop a scrap on a box to file it.
   All on by default. With the menu off, holding a recent scrap asks to delete it again, as before (GesturePrefs, saved as gesture_hold, gesture_drag and gesture_file).


☑ 14. Menus overhaul: skins, arranging and a new skin (Scrapbook-UIO-5)
   For: the menu and the small windows of the app should be changeable: how they look, what the menu holds and in what order (item 5 of the Home list).
   Built: a menu system. One skin is worn by the Home menu and by every sheet, pop-up menu and group of rows in the app (MenuSkins.kt); Classic is the look the app had, and a new
   skin, Float, is built after the two references: a floating card with a centered title, outlined groups with a name on top (Browse, Discover, Manage), icon tiles, Cancel and the
   action side by side, a line under the buttons ("128 scraps · 12 boxes · all on this phone"), and an option to show the main button as a floating pill. On top of any skin:
   row size, icons on or off, how much the page dims, the footer line and the main button style. A new Customize menu page (menu > Customize menu, or Settings > Home and lists)
   has the skin cards with small pictures, the options, Try the menu (the real menu opens over the page), and the menu itself as a list: drag an entry to move it, the eye hides
   it, group breaks split the menu into cards, Back to the usual menu undoes it. Settings can never be hidden. Saved on this phone (MenuLayout.kt, MenuStyle.kt,
   ui/MenuSkins.kt, ui/MenuEdit.kt; tests MenuLayoutTest).
