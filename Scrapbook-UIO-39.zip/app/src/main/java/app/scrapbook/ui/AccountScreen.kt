package app.scrapbook.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import coil.compose.AsyncImage

// The account: your name, a picture and a few things about you. It is only used for the greeting on Home and lives only on this phone.
// This file has the round picture that is shown everywhere (AvatarView), the card on the Settings page (AccountCard) and the Account page itself.

/** The shapes the greeting's picture can have, in the order of the Picture shape choice: circle, squircle, leaf. */
fun avatarShape(index: Int): Shape = when (index) {
    1 -> RoundedCornerShape(percent = 30)
    2 -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 14, bottomEndPercent = 50, bottomStartPercent = 14)
    else -> CircleShape
}

/** Your picture in a circle (or another [shape]): the photo if you chose one, otherwise your initial on a color, otherwise a plain head-and-shoulders. */
@Composable
fun AvatarView(account: Account, size: Dp, modifier: Modifier = Modifier, shape: Shape = CircleShape) {
    val fill = if (account.avatarColor in AVATAR_COLORS.indices) Color(AVATAR_COLORS[account.avatarColor]) else LocalSb.current.acc
    val ink = onAccent(fill)
    Box(modifier.size(size).clip(shape).background(fill), Alignment.Center) {
        val uri = account.avatarUri
        if (uri != null) AsyncImage(uri, "Your profile picture", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else if (account.initial.isNotEmpty()) Text(account.initial, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = (size.value * .42f).sp, color = ink)
        else Ic("person", size * .52f, ink)
    }
}

/** The card at the top of the main Settings page: your picture and name, opening the Account page. */
@Composable
fun AccountCard(account: Account, onClick: () -> Unit) {
    Row(Modifier.appear("account").padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(Sb.card).tap("Account", onClick)
        .padding(horizontal = 18.dp, vertical = 16.dp), Arrangement.spacedBy(16.dp), Alignment.CenterVertically) {
        AvatarView(account, 56.dp)
        Column(Modifier.weight(1f)) {
            Text(if (account.hasName) account.callName else "Set up your profile", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(account.about.lineSequence().firstOrNull().orEmpty().ifBlank { "Name, picture and a few things about you" }, fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Ic("chevron", 20.dp, Sb.mute)
    }
}

/** A labelled text box on a rounded card. The text is kept by the caller and saved on every change. */
@Composable
private fun ProfileField(label: String, value: String, hint: String, singleLine: Boolean = true, caps: KeyboardCapitalization = KeyboardCapitalization.Words, onChange: (String) -> Unit) {
    val t = LocalSb.current
    Column(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.card).padding(horizontal = 20.dp, vertical = 14.dp)) {
        Text(label.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
        BasicTextField(value, onChange, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = singleLine, maxLines = if (singleLine) 1 else 4,
            textStyle = TextStyle(fontSize = 17.sp, color = Sb.ink), cursorBrush = SolidColor(t.acc), keyboardOptions = KeyboardOptions(capitalization = caps),
            decorationBox = { inner -> Box { if (value.isEmpty()) Text(hint, fontSize = 17.sp, color = Sb.mute); inner() } })
    }
}

/** The Account page. */
@Composable
fun AccountScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current
    val account by vm.account.collectAsState()
    var photoSheet by remember { mutableStateOf(false) }
    var birthdaySheet by remember { mutableStateOf(false) }
    // A picked photo is first shown in the cropper, where it can be moved and zoomed; only then is it saved.
    var cropUri by remember { mutableStateOf<Uri?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) cropUri = u }

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.page) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
                Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn("Go back", { nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
                    Box(Modifier.weight(1f), Alignment.Center) {
                        Text("scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp, maxLines = 1)
                    }
                    Spacer(Modifier.size(44.dp))
                }
                Text("Account", Modifier.padding(start = 28.dp, top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                // The saved account is read a moment after the app starts; the boxes below start from it, so they wait for it.
                if (account.loaded) AccountForm(vm, account, Modifier.weight(1f), { photoSheet = true }, { birthdaySheet = true })
            }
        }
        if (photoSheet) Sheet("Profile picture", { photoSheet = false }, doneLabel = "Cancel", soft = true) {
            ActionRow("image", "Choose from photos") { photoSheet = false; pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            if (account.avatarUri != null) ActionRow("trash", "Remove photo", danger = true) { photoSheet = false; vm.removeAvatar() }
        }
        if (birthdaySheet) BirthdaySheet(vm, account) { birthdaySheet = false }
        cropUri?.let { u -> AvatarCropper(u, onCancel = { cropUri = null }) { crop -> vm.setAvatar(u, crop); cropUri = null } }
    }
}

@Composable
private fun AccountForm(vm: ArchiveViewModel, account: Account, modifier: Modifier, onPhoto: () -> Unit, onBirthday: () -> Unit) {
    var name by remember { mutableStateOf(account.name) }
    var nick by remember { mutableStateOf(account.nickname) }
    var about by remember { mutableStateOf(account.about) }
    var pronouns by remember { mutableStateOf(account.pronouns) }
    Column(modifier.verticalScroll(rememberScrollState()).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.pressScale(.95f).size(120.dp).tap("Change profile picture", onPhoto)) {
                AvatarView(account, 120.dp)
                Box(Modifier.align(Alignment.BottomEnd).size(38.dp).clip(CircleShape).background(Sb.ink), Alignment.Center) { Ic("camera", 20.dp, Sb.paper) }
            }
            Text(if (account.hasName) account.callName else "Your profile", Modifier.padding(top = 14.dp), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 26.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Only on this phone. Used for the greeting on Home.", Modifier.padding(top = 2.dp), fontSize = 13.sp, color = Sb.mute)
        }
        ProfileField("Name", name, "What should I call you?") { name = Account.clean(it, Account.MAX_NAME); vm.setAccountName(name) }
        ProfileField("Nickname", nick, "Optional. Greetings use this instead") { nick = Account.clean(it, Account.MAX_NAME); vm.setAccountNick(nick) }
        ProfileField("About you", about, "A line or two about you", singleLine = false, caps = KeyboardCapitalization.Sentences) { about = Account.cleanAbout(it); vm.setAccountAbout(about) }
        ProfileField("Pronouns", pronouns, "Optional, like she/her or they/them", caps = KeyboardCapitalization.None) { pronouns = Account.clean(it, Account.MAX_PRONOUNS); vm.setAccountPronouns(pronouns) }
        Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.card).tap("Birthday", onBirthday).padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("BIRTHDAY", fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
                val set = account.hasBirthday
                Text(if (set) "${account.birthDay} ${Account.MONTH_NAMES[account.birthMonth - 1]}" else "Not set", Modifier.padding(top = 6.dp), fontSize = 17.sp, color = if (set) Sb.ink else Sb.mute)
            }
            Ic("chevron", 20.dp, Sb.mute)
        }
        Column(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.card).padding(horizontal = 20.dp, vertical = 14.dp)) {
            Text("COLOR WITHOUT A PICTURE", fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
            Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), Arrangement.spacedBy(2.dp)) {
                for (i in -1 until AVATAR_COLORS.size) {
                    val c = if (i < 0) LocalSb.current.acc else Color(AVATAR_COLORS[i])
                    val sel = account.avatarColor == i
                    Box(Modifier.size(44.dp).tap(if (i < 0) "Accent color" else "Color ${i + 1}") { vm.setAvatarColor(i) }, Alignment.Center) {
                        Box(Modifier.size(36.dp).border(2.dp, if (sel) Sb.ink else Color.Transparent, CircleShape).padding(4.dp).clip(CircleShape).background(c))
                    }
                }
            }
        }
    }
}

/** Pick the month and the day. Saved as soon as both are chosen. */
@Composable
private fun BirthdaySheet(vm: ArchiveViewModel, account: Account, onDone: () -> Unit) {
    var month by remember { mutableIntStateOf(account.birthMonth) }
    var day by remember { mutableIntStateOf(account.birthDay) }
    Sheet("Birthday", onDone) {
        SheetLabel("Month")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), Arrangement.spacedBy(8.dp)) {
            Account.MONTH_NAMES.forEachIndexed { i, n ->
                Chip(n.take(3), month == i + 1) {
                    month = i + 1
                    if (day > Account.DAYS_IN_MONTH[i]) day = Account.DAYS_IN_MONTH[i]
                    if (day > 0) vm.setBirthday(month, day)
                }
            }
        }
        SheetLabel("Day")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), Arrangement.spacedBy(8.dp)) {
            val last = if (month in 1..12) Account.DAYS_IN_MONTH[month - 1] else 31
            for (d in 1..last) Chip("$d", day == d) { day = d; if (month > 0) vm.setBirthday(month, day) }
        }
        SheetNote("Used for a birthday greeting on Home. Only on this phone, and it has no year.")
        if (month > 0 || day > 0) ActionRow("trash", "Clear birthday", danger = true) { month = 0; day = 0; vm.setBirthday(0, 0) }
    }
}
