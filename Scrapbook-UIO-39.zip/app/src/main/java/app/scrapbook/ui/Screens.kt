package app.scrapbook.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

@Composable
private fun GBar(w: Float, h: Int, c: Color) { Box(Modifier.fillMaxWidth(w).height(h.dp).clip(RoundedCornerShape(2.dp)).background(c)) }

/** A tiny wireframe of each page layout. */
@Composable
private fun LayoutGlyph(l: Layout) {
    val t = LocalSb.current; val bar = Sb.mute.copy(alpha = .55f); val ln = Sb.mute.copy(alpha = .3f); val img = t.acc.copy(alpha = .4f)
    Column(Modifier.size(58.dp, 44.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        when (l) {
            Layout.Classic -> { GBar(.6f, 5, bar); GBar(1f, 3, ln); GBar(1f, 3, ln); GBar(.7f, 3, ln) }
        }
    }
}

private fun shortLabel(l: Layout) = l.label

/** Pick how a note's page is laid out. The preview updates as you tap; nothing is lost when you switch. */
@Composable
fun LayoutScreen(vm: ArchiveViewModel, nav: NavController, id: Long) {
    val t = LocalSb.current; val list by vm.items.collectAsState()
    val item = list.firstOrNull { it.id == id } ?: list.firstOrNull()
    Scaffold(containerColor = t.page) { pad ->
        if (item != null) Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
            ScreenHeader({ nav.popBackStack() }, title = "Choose a layout", pad = 2.dp)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(28.dp)).background(pageTint(item.color) ?: Sb.card).padding(18.dp)) { ItemPage(item, list) }
            Spacer(Modifier.height(16.dp))
            Layout.entries.chunked(4).forEach { row ->
                Row(Modifier.padding(bottom = 8.dp), Arrangement.spacedBy(8.dp)) {
                    row.forEach { l ->
                        val on = l == item.layout
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Sb.card)
                            .border(if (on) 2.dp else 1.dp, if (on) Sb.ink else Sb.line, RoundedCornerShape(24.dp)).tap(l.label) { vm.setLayout(item.id, l) }.padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            LayoutGlyph(l)
                            Text(shortLabel(l), fontSize = 12.sp, maxLines = 1, color = if (on) Sb.ink else Sb.mute, fontWeight = if (on) FontWeight.Medium else FontWeight.Normal)
                        }
                    }
                }
            }
            SheetLabel("Spacing", start = 4.dp)
            Spacer(Modifier.height(6.dp))
            Seg(listOf("Airy", "Cozy", "Compact"), item.density) { vm.save(item.copy(density = it)) }
            Spacer(Modifier.weight(1f))
            Text("Use ${item.layout.label}", Modifier.fillMaxWidth().padding(vertical = 12.dp).clip(RoundedCornerShape(28.dp)).background(Sb.ink).tap("Done") {
                    // The editor is a plain writing screen, so after choosing a layout from there, open the page that shows it.
                    val fromEditor = nav.previousBackStackEntry?.destination?.route == "edit/{id}"
                    nav.popBackStack()
                    if (fromEditor) nav.navigate("item/${item.id}")
                }.padding(vertical = 16.dp),
                color = Sb.card, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
        }
    }
}
