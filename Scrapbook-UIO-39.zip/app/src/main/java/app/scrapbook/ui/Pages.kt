package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.activity.compose.BackHandler
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextLayoutResult
import app.scrapbook.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class PageStyle(val family: FontFamily?, val gap: Dp, val line: TextUnit, val showMeta: Boolean)
val LocalPage = compositionLocalOf { PageStyle(null, 10.dp, 22.sp, true) }
/** Text metrics shared by the editor and the reading view, so a note looks the same in both. */
fun pageFont(font: Int): FontFamily? = when (font) { 1 -> FontFamily.Serif; 2 -> FontFamily.SansSerif; 3 -> FontFamily.Monospace; else -> null }
fun pageLine(density: Int): TextUnit = when (density) { 0 -> 30.sp; 2 -> 23.sp; else -> 27.sp }
private fun Item.style() = PageStyle(pageFont(font), when (density) { 0 -> 16.dp; 2 -> 6.dp; else -> 10.dp }, pageLine(density), showMeta)

private fun date(ms: Long) = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(ms))
@Composable private fun Title(text: String, size: TextUnit = 26.sp, align: TextAlign = TextAlign.Start) =
    Text(text, fontFamily = LocalPage.current.family ?: headFont(), fontWeight = FontWeight.SemiBold, fontSize = size, lineHeight = size * 1.15f, textAlign = align, modifier = Modifier.semantics { heading() })
private val NUM_LINE = Regex("^(\\d+)\\. ")
private val RICH = Regex("\\*\\*(.+?)\\*\\*|~~(.+?)~~|==(.+?)==|\\*(.+?)\\*|\\[([^\\]\\n]+)\\]\\(((?:https?|readest|scrapbook|binder)://[^)\\s]+)\\)|(?:https?|scrapbook|binder)://[^\\s]+|\\{((?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2})\\|(.+?)\\}|`([^`\\n]+)`")

/** Inline formatting (bold, italic, strike, highlight, color, size, underline), [text](url) links and tappable web links. */
@Composable
private fun linkify(text: String): AnnotatedString {
    val acc = LocalSb.current.acc
    val ctx = LocalContext.current
    val titleOf = LocalLinkTitle.current; val tc = LocalTextColors.current
    val link = if (tc.linksAccent) accentText(acc) else Color.Unspecified; val tag = if (tc.colorHashtags) accentText(acc) else null
    val hl = markerStyle(acc, LocalMarker.current, Sb.paper)   // the highlighter: its color and strength are set in the editor's color panel
    return buildAnnotatedString { appendRich(text, hl, link, tag, titleOf) { openAppLink(ctx, it) } }
}

/** The current title of the scrap with this permanent id, for a pasted scrapbook://scrap/<id> link to show instead of the raw address. Null when there is none. */
val LocalLinkTitle = compositionLocalOf<(String) -> String?> { { null } }

/** Opens a link that belongs to another app (a readest:// link opens Paperback). Says so instead of crashing when that app is not installed. */
private fun openAppLink(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, if (url.startsWith("binder://")) "Binder isn't installed on this phone" else "Paperback isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/** Plain text, with its #hashtags drawn in [tag] when that is not null. */
private fun AnnotatedString.Builder.appendPlain(s: String, tag: Color?) {
    if (tag == null) { append(s); return }
    var i = 0
    for (r in hashtagRanges(s)) { append(s.substring(i, r.first)); withStyle(SpanStyle(color = tag)) { append(s.substring(r.first, r.last + 1)) }; i = r.last + 1 }
    append(s.substring(i))
}

/** [hl] is the look of highlights, [link] the color of links (unspecified = the text color), [tag] the color of #hashtags (null = none). */
private fun AnnotatedString.Builder.appendRich(text0: String, hl: SpanStyle, link: Color, tag: Color?, titleOf: (String) -> String?, openApp: (String) -> Unit) {
    val text = withoutEmptyMarks(text0)   // marks with nothing inside (left by deleting the last letter) are never drawn
    var i = 0
    for (m in RICH.findAll(text)) {
        appendPlain(text.substring(i, m.range.first), tag)
        val g = m.groupValues
        when {
            g[1].isNotEmpty() -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { appendRich(g[1], hl, link, tag, titleOf, openApp) }
            g[2].isNotEmpty() -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { appendRich(g[2], hl, link, tag, titleOf, openApp) }
            g[3].isNotEmpty() -> withStyle(hl) { appendRich(g[3], hl, link, tag, titleOf, openApp) }
            g[4].isNotEmpty() -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { appendRich(g[4], hl, link, tag, titleOf, openApp) }
            g[7].isNotEmpty() -> {
                val a = parseSpanAttrs(g[7])
                withStyle(SpanStyle(color = a.color?.let { hexColor(it) } ?: Color.Unspecified, fontSize = a.size?.sp ?: TextUnit.Unspecified,
                    textDecoration = if (a.underline) TextDecoration.Underline else null)) { appendRich(g[8], hl, link, if (a.color != null) null else tag, titleOf, openApp) }
            }
            g[9].isNotEmpty() -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace, fontSize = 15.sp, background = Sb.mute.copy(alpha = .18f))) { append(g[9]) }   // `code`: literal, nothing inside is formatting
            g[5].isNotEmpty() -> {
                val style = TextLinkStyles(SpanStyle(color = link, textDecoration = TextDecoration.Underline))
                val link = if (g[6].startsWith("readest://") || g[6].startsWith("binder://")) LinkAnnotation.Clickable("app-link", style) { openApp(g[6]) } else LinkAnnotation.Url(g[6], style)
                withLink(link) { append(g[5]) }
            }
            else -> {
                val raw = m.value; val url = raw.trimEnd('.', ',', ';', ':', '!', '?', ')', '"', '”', '\'')
                // A link to another scrap reads as that scrap's title (its current one), not as the raw address.
                val label = parseScrapLink(url)?.let { titleOf(it) ?: "Linked scrap" } ?: url
                withLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = link, textDecoration = TextDecoration.Underline)))) { append(label) }
                append(raw.substring(url.length))
            }
        }
        i = m.range.last + 1
    }
    appendPlain(text.substring(i), tag)
}

/** Lets a tapped checklist line rewrite the note body: (oldLine, newLine). */
val LocalToggle = compositionLocalOf<(String, String) -> Unit> { { _, _ -> } }

/**
 * The round checklist icon in the reading view, the same as in the editor: a ring when open, the accent color filled with a check when done. When you tick it
 * the color fills in, the check fades in and the circle gives a small springy pop; unticking just fades it out. One that is already ticked when the page opens simply shows.
 */
@Composable
private fun TaskBox(done: Boolean, ring: Color, acc: Color) {
    val fill by animateColorAsState(if (done) acc else acc.copy(alpha = 0f), tween(160), label = "taskFill")
    val edge by animateColorAsState(if (done) acc else ring, tween(160), label = "taskEdge")
    val tick by animateFloatAsState(if (done) 1f else 0f, tween(160), label = "taskTick")
    val pop = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(done) {
        if (first) { first = false; return@LaunchedEffect }
        if (done) { pop.snapTo(.78f); pop.animateTo(1f, spring(dampingRatio = .38f, stiffness = Spring.StiffnessMedium)) }
    }
    val tickColor = if (acc.luminance() > .5f) Color(0xFF1A1A1A) else Color.White
    Canvas(Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }.size(20.dp)) {
        val sw = 1.6.dp.toPx(); val r = size.minDimension / 2f; val d = size.minDimension
        if (fill.alpha > 0f) drawCircle(fill, r)
        drawCircle(edge, r - sw / 2f, style = Stroke(sw))
        if (tick > 0f) {
            val p = Path().apply { moveTo(d * .27f, d * .52f); lineTo(d * .43f, d * .68f); lineTo(d * .74f, d * .34f) }
            drawPath(p, tickColor.copy(alpha = tick), style = Stroke(width = sw * 1.15f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/**
 * Find in the reading view. [query] is what is searched for and [current] the number of the current match across the whole page. The page's body is
 * drawn as lines of text (in one or more Body blocks); [lineStart] says how many matches come before each line and [blockBase] how many lines come
 * before each block, so every line can tell which of its matches (if any) is the current one.
 */
class FindState(
    val query: String, val current: Int, val lineStart: IntArray, val blockBase: IntArray,
    /** The page content, so a match's position can be measured the same way however far the page is scrolled. */
    val container: () -> LayoutCoordinates?,
    /** Scrolls so the stretch from [top] to [bottom] (in page content coordinates) is comfortably in view. */
    val reveal: (Float, Float) -> Unit,
) { companion object { val None = FindState("", -1, IntArray(0), IntArray(0), { null }, { _, _ -> }) } }
val LocalFind = compositionLocalOf { FindState.None }

/** The pieces of body text the layout draws with Body(), in drawing order. */
private fun bodyBlocks(item: Item): List<String> = listOf(withoutTitleLine(item).body)

/** The text a body line shows (no heading, list, checkbox, layout or formatting marks): what find searches, matching what Body draws. */
private fun displayText(raw: String, titleOf: (String) -> String?): String {
    val pfx = LINE_PREFIX_RE.find(raw)?.value ?: ""
    val tm = LINE_TAGS.find(raw.substring(pfx.length))!!
    val l = pfx + raw.substring(pfx.length + tm.value.length)
    val content = when {
        l.startsWith("## ") -> l.drop(3)
        l.startsWith("# ") -> l.drop(2)
        l.startsWith("> ") -> l.drop(2)
        l == "---" -> ""
        l.startsWith("- [ ] ") || l.startsWith("- [x] ") -> l.drop(6)
        NUM_LINE.containsMatchIn(l) -> l.drop(NUM_LINE.find(l)!!.value.length)
        l.startsWith("- ") -> l.drop(2)
        l.isBlank() -> ""
        else -> l
    }
    return buildAnnotatedString { appendRich(content, SpanStyle(), Color.Unspecified, null, titleOf) { } }.text
}

/**
 * One line of body text. While finding, every match in it is marked (the current one strongly), and the line with the current match reports where
 * that match sits so the page can scroll to it. [line] is the line's number across the whole page (see [FindState]).
 */
@Composable
private fun FText(content: String, line: Int, modifier: Modifier = Modifier, fontFamily: FontFamily? = null, fontStyle: FontStyle? = null, fontWeight: FontWeight? = null,
                  fontSize: TextUnit = TextUnit.Unspecified, lineHeight: TextUnit = TextUnit.Unspecified, color: Color = Color.Unspecified, textDecoration: TextDecoration? = null,
                  literal: Boolean = false) {
    val find = LocalFind.current; val acc = LocalSb.current.acc
    val base = if (literal) AnnotatedString(content) else linkify(content)   // literal: code, where nothing is formatting and no address is a link
    val local = remember(base.text, find.query) { if (find.query.isBlank()) emptyList<IntRange>() else findMatches(base.text, find.query) }
    val cur = find.current - find.lineStart.getOrElse(line) { 0 }
    val hasCur = cur in local.indices
    var lay by remember { mutableStateOf<TextLayoutResult?>(null) }
    var top by remember { mutableFloatStateOf(-1f) }
    val shown = if (local.isEmpty()) base else buildAnnotatedString {
        append(base)
        local.forEachIndexed { j, r -> addStyle(SpanStyle(background = acc.copy(alpha = if (j == cur) .6f else .28f)), r.first, r.last + 1) }
    }
    LaunchedEffect(hasCur, find.current, find.query, lay, top) {
        val l = lay ?: return@LaunchedEffect
        if (!hasCur || top < 0f) return@LaunchedEffect
        val ln = l.getLineForOffset(local[cur].first.coerceIn(0, (l.layoutInput.text.length - 1).coerceAtLeast(0)))
        find.reveal(top + l.getLineTop(ln), top + l.getLineBottom(ln))
    }
    Text(shown, if (hasCur) modifier.onGloballyPositioned { c -> val box = find.container(); if (box != null && box.isAttached && c.isAttached) top = box.localPositionOf(c, Offset.Zero).y } else modifier,
        color = color, fontSize = fontSize, fontStyle = fontStyle, fontWeight = fontWeight, fontFamily = fontFamily, textDecoration = textDecoration, lineHeight = lineHeight,
        onTextLayout = { lay = it })
}

/**
 * Body text with light formatting: # heading, ## subheading, > quote, - bullet, - [ ] checklist, --- divider.
 * Sizes and line heights match the editor, so a note looks the same while writing and while reading.
 */
@Composable
private fun Body(text: String, block: Int = 0) {
    val st = LocalPage.current; val toggle = LocalToggle.current; val acc = LocalSb.current.acc; val haptics = LocalHaptics.current; val tc = LocalTextColors.current
    // Bullets, boxes and quote bars have the color of the line's text unless Settings says accent. [dim] is the color for ticked or quoted lines.
    fun markColor(lineText: String, dim: Boolean) = if (tc.marksAccent) accentText(acc) else leadingTextColor(lineText)?.let { hexColor(it) } ?: if (dim) Sb.mute else Sb.ink
    val fam = st.family ?: headFont(); val lineDp = with(LocalDensity.current) { st.line.toDp() }
    val lineBase = LocalFind.current.blockBase.getOrElse(block) { 0 }
    val lines = text.lines(); val cs = codeLineStates(lines)
    Column {
        lines.forEachIndexed { li, raw ->
            // A fenced code block is one card, drawn at its opening fence; the lines after it are part of that card.
            if (cs[li] == CodeLine.OPEN) {
                val inside = ((li + 1) until lines.size).takeWhile { cs[it] == CodeLine.BODY }
                CodeCard(raw.drop(3).trim(), inside.joinToString("\n") { lines[it] }, inside.map { lineBase + it to lines[it] })
            } else if (cs[li] == CodeLine.NONE) {
            // Layout tags sit after the prefix: {i:2} indents, {a:c} / {a:r} centers or right-aligns.
            val pfx = LINE_PREFIX_RE.find(raw)?.value ?: ""
            val tm = LINE_TAGS.find(raw.substring(pfx.length))!!
            val l = pfx + raw.substring(pfx.length + tm.value.length)
            val indent = tm.groupValues[1].toIntOrNull() ?: 0
            val ta = when (tm.groupValues[2]) { "c" -> TextAlign.Center; "r" -> TextAlign.End; else -> TextAlign.Unspecified }
            val big = SPAN_RE.findAll(l).maxOfOrNull { parseSpanAttrs(it.groupValues[1]).size ?: 0 } ?: 0
            val lh = if (big * 1.3f > st.line.value) (big * 1.3f).sp else st.line
            Box(Modifier.padding(start = (24 * indent).dp)) { ProvideTextStyle(LocalTextStyle.current.copy(textAlign = ta)) {
            when {
                l.startsWith("## ") -> FText(l.drop(3), lineBase + li, fontFamily = fam, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = lh)
                l.startsWith("# ") -> FText(l.drop(2), lineBase + li, fontFamily = fam, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = lh)
                l.startsWith("> ") -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(markColor(l.drop(2), true))); Spacer(Modifier.width(10.dp))
                    FText(l.drop(2), lineBase + li, Modifier.weight(1f), fontFamily = fam, fontStyle = FontStyle.Italic, fontSize = 17.sp, lineHeight = lh)
                }
                l == "---" -> Box(Modifier.fillMaxWidth().height(lineDp), Alignment.Center) { Box(Modifier.fillMaxWidth().height(1.dp).background(Sb.line)) }
                l.startsWith("- [ ] ") || l.startsWith("- [x] ") -> {
                    val done = l.startsWith("- [x] ")
                    Row(Modifier.fillMaxWidth().tap { haptics.toggle(!done); toggle(raw, (if (done) "- [ ] " else "- [x] ") + raw.drop(6)) }, Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                        TaskBox(done, if (tc.marksAccent) acc else leadingTextColor(l.drop(6))?.let { hexColor(it) } ?: Sb.mute, acc)
                        FText(l.drop(6), lineBase + li, Modifier.weight(1f), fontFamily = fam, fontSize = 17.sp, lineHeight = lh, color = if (done) Sb.mute else Sb.ink, textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None)
                    }
                }
                NUM_LINE.containsMatchIn(l) -> {
                    val nm = NUM_LINE.find(l)!!
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                        Text(nm.groupValues[1] + ".", fontFamily = fam, fontSize = 17.sp, lineHeight = lh)
                        FText(l.drop(nm.value.length), lineBase + li, Modifier.weight(1f), fontFamily = fam, fontSize = 17.sp, lineHeight = lh)
                    }
                }
                l.startsWith("- ") -> Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                    Text("•", fontSize = 17.sp, lineHeight = lh, color = markColor(l.drop(2), false), fontWeight = FontWeight.Bold)
                    FText(l.drop(2), lineBase + li, Modifier.weight(1f), fontFamily = fam, fontSize = 17.sp, lineHeight = lh)
                }
                l.isBlank() -> Spacer(Modifier.height(lineDp))
                else -> FText(l, lineBase + li, fontFamily = fam, fontSize = 17.sp, lineHeight = lh)
            }
            } }
            }
        }
    }
}

/** A fenced code block: a tinted card with the language (if given) and a Copy button on top, the code in monospace below, scrolling sideways instead of wrapping. */
@Composable
private fun CodeCard(label: String, code: String, rows: List<Pair<Int, String>>) {
    val clipboard = LocalClipboardManager.current; var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Sb.mute.copy(alpha = .14f))) {
        Row(Modifier.fillMaxWidth().padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label.ifBlank { "Code" }, Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
            Row(Modifier.clip(RoundedCornerShape(12.dp)).tap("Copy code") { clipboard.setText(AnnotatedString(code)); copied = true }.padding(horizontal = 12.dp, vertical = 10.dp),
                Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
                Ic("copy", 15.dp, Sb.mute); Text(if (copied) "Copied" else "Copy", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
            }
        }
        Column(Modifier.horizontalScroll(rememberScrollState()).padding(start = 14.dp, end = 14.dp, bottom = 14.dp)) {
            rows.forEach { (n, text) -> FText(text.ifEmpty { " " }, n, fontFamily = FontFamily.Monospace, fontSize = 14.sp, lineHeight = 20.sp, literal = true) }
        }
    }
}

/** One item, rendered by its layout. Content is shared across layouts, so switching never loses anything. Only Classic is built for now. */
@Composable
fun ItemPage(item: Item, all: List<Item>) {
    val t = LocalSb.current; val acc = pageAccent(item.accent) ?: t.acc
    CompositionLocalProvider(LocalPage provides item.style(), LocalSb provides t.copy(acc = acc), LocalMarker provides Marker(item.hlColor, item.hlOpacity)) {   // the page's own highlighter
        Column {
            if (item.cover != null) {
                ItemImage(item.copy(imageUri = item.cover), Modifier.fillMaxWidth().height(150.dp), t.radius)
                Spacer(Modifier.height(12.dp))
            }
            PageBody(withoutTitleLine(item).let { it.copy(title = it.displayTitle) }, all); InlineImages(item); InlineFiles(item)
        }
    }
}

/** The page skips a first line that only repeats the title. */
private fun withoutTitleLine(item: Item): Item = item.copy(body = bodyWithoutTitle(item.title, item.body))

/** Files attached to a note appear as cards under its text and photos, on every layout. */
@Composable
private fun InlineFiles(item: Item) {
    val files = item.attachments()
    if (files.isEmpty()) return
    AttachmentList(files, Modifier.padding(top = LocalPage.current.gap + 6.dp))
}

/** Images attached to a note appear under its text. */
@Composable
private fun InlineImages(item: Item) {
    val all = item.allImages(); var viewAt by remember { mutableStateOf<Int?>(null) }
    all.forEachIndexed { i, u -> ItemImage(item.copy(imageUri = u), Modifier.fillMaxWidth().height(200.dp).padding(top = LocalPage.current.gap).tap("Open photo") { viewAt = i }) }
    viewAt?.let { at -> PhotoViewer(all, at) { viewAt = null } }
}

@Composable
private fun PageBody(item: Item, all: List<Item>) {
    val gap = LocalPage.current.gap
    when (item.layout) {
        Layout.Classic -> Column(verticalArrangement = Arrangement.spacedBy(gap)) { Title(item.title); Body(item.body) }
    }
}

/** Reading view: a quiet page. Edit and share sit in the top bar, everything else in the menu. */
@Composable
fun ItemScreen(vm: ArchiveViewModel, nav: NavController, id: Long) {
    val t = LocalSb.current; val list by vm.items.collectAsState(); val haptics = LocalHaptics.current
    val item = list.firstOrNull { it.id == id }
    LaunchedEffect(id, item != null) { if (item != null) vm.opened(Recents.scrap(id)) }   // feeds the quick switcher's "Recently opened"
    var sheet by remember { mutableStateOf(false) }; var menu by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<Attachment?>(null) }   // the attached file whose new name is being asked for
    val ctx = LocalContext.current; val clipboard = LocalClipboardManager.current
    // Find in scrap (reading view): the same find bar, hold-the-back-button gesture and setting as the editor. It searches the body text as the page draws it
    // (without list or formatting marks) on every layout that draws its text through Body; the Quote layout is left out. Matches are numbered across the page.
    val findEntry by vm.findEntry.collectAsState()
    var finding by remember { mutableStateOf(false) }; var findQ by remember { mutableStateOf("") }; var findAt by remember { mutableIntStateOf(0) }
    val scroll = rememberScrollState(); var viewportH by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope(); val padTop = with(LocalDensity.current) { 16.dp.toPx() }
    val containerRef = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val blocks = remember(item?.body, item?.title, item?.layout) { item?.let { bodyBlocks(it) } ?: emptyList() }
    val titleOf = remember(list) { { uid: String -> list.firstOrNull { it.deletedAt == 0L && it.uid.equals(uid, true) }?.displayTitle } }
    val lineTexts = remember(blocks, titleOf) {
        blocks.flatMap { b ->
            val ls = b.lines(); val cs = codeLineStates(ls)
            // A code block is drawn as a card: its fences are not shown, and its lines are shown exactly as written.
            ls.mapIndexed { i, l -> when (cs[i]) { CodeLine.OPEN, CodeLine.CLOSE -> ""; CodeLine.BODY -> l; else -> displayText(l, titleOf) } }
        }
    }
    val blockBase = remember(blocks) { runningStart(blocks.map { it.lines().size }) }
    val counts = remember(lineTexts, findQ, finding) { if (finding && findQ.isNotBlank()) lineTexts.map { findMatches(it, findQ).size } else emptyList<Int>() }
    val total = counts.sum(); val findCur = if (total == 0) -1 else findAt.coerceIn(0, total - 1)
    val find = remember(finding, findQ, findCur, counts, blockBase) {
        FindState(if (finding) findQ else "", findCur, runningStart(counts), blockBase, { containerRef[0] }) { top, bottom ->
            scope.launch {
                val a = padTop + top; val b = padTop + bottom
                if (a < scroll.value + 16 || b > scroll.value + viewportH - 16) scroll.animateScrollTo((a - viewportH / 3f).toInt().coerceIn(0, scroll.maxValue))
            }
        }
    }
    BackHandler(finding) { finding = false; findQ = ""; findAt = 0 }
    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.page) { pad ->
            if (item != null) Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).background(pageTint(item.color) ?: Color.Transparent).imePadding()) {
                // Same header as the editor: round back button, a big line with a small line under it, and one pill with the actions.
                // The page below already shows the note's title, so the header names the box and the kind and date instead.
                if (finding) FindBar(findQ, { findQ = it; findAt = 0 }, total, findCur, { findAt = nextMatch(findCur, total, true) },
                    { findAt = nextMatch(findCur, total, false) }, { finding = false; findQ = ""; findAt = 0 })
                else Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                    // Tap goes back. Held, it turns into a search button (unless Settings keeps find in the 3-dot menu only).
                    BackFindButton(findEntry != 1, { nav.popBackStack() }, { finding = true; menu = false })
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        // The box the scrap is in. When that box sits inside others they come first, small, each one a tap away ("Trips › Italy"); the box itself opens too.
                        val allShelves = LocalShelves.current
                        val trail = remember(item.collection, allShelves) { allShelves.pathTo(item.collection) }
                        val crumbScroll = rememberScrollState()
                        LaunchedEffect(trail) { crumbScroll.scrollTo(crumbScroll.maxValue) }
                        Row(Modifier.horizontalScroll(crumbScroll), verticalAlignment = Alignment.CenterVertically) {
                            trail.dropLast(1).forEach { a ->
                                Text(a.label, color = Sb.mute, fontSize = 14.sp, maxLines = 1, modifier = Modifier.clip(RoundedCornerShape(8.dp)).tap("Open ${a.label}") { nav.openBox(a.name) }.padding(vertical = 4.dp))
                                Text("  ›  ", color = Sb.mute, fontSize = 14.sp)
                            }
                            Text(allShelves.displayName(item.collection), color = Sb.ink, fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp, fontFamily = headFont(), fontWeight = FontWeight.Medium,
                                maxLines = 1, modifier = if (item.collection.isBlank()) Modifier else Modifier.clip(RoundedCornerShape(8.dp)).tap("Open ${allShelves.displayName(item.collection)}") { nav.openBox(item.collection) })
                        }
                        Text("${item.kind.label} · ${date(item.savedAt)}", fontSize = 12.5.sp, lineHeight = 16.sp, color = Sb.mute, fontFamily = LocalFonts.current.second, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Row(Modifier.height(44.dp).clip(CircleShape).background(Sb.card).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        HeaderBtn("Edit", {
                            vm.pendingEdit = true
                            // Back to the editor underneath only when it is this very scrap's (you came from it). After following a link from another scrap's
                            // editor, the one underneath is a different scrap, and going back to it was opening the wrong one.
                            val under = nav.previousBackStackEntry
                            if (under?.destination?.route == "edit/{id}" && under.arguments?.getLong("id") == item.id) nav.popBackStack() else nav.navigate("edit/${item.id}")
                        }) { Ic("edit", 22.dp, accentText(t.acc)) }
                        HeaderBtn("Share", {
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, item.title); putExtra(Intent.EXTRA_TEXT, plainText(item.title, item.body))
                            }, "Share scrap"))
                        }) { Ic("share", 22.dp, Sb.ink) }
                        HeaderBtn("More options", { menu = true }) { Ic("more", 22.dp, Sb.ink) }
                    }
                }
                Column(Modifier.weight(1f).onSizeChanged { viewportH = it.height }.verticalScroll(scroll).padding(horizontal = 20.dp, vertical = 16.dp)) {
                    CompositionLocalProvider(LocalToggle provides { a, b -> vm.save(item.copy(body = item.body.replaceFirst(a, b))) },
                        LocalFind provides find, LocalLinkTitle provides titleOf,
                        LocalAttachmentRename provides { a: Attachment -> renaming = a }) {
                        Box(Modifier.onGloballyPositioned { containerRef[0] = it }) { ItemPage(item, list) }
                    }
                    val suggestLinks by vm.linkSuggestions.collectAsState()
                    val connectionsOpen by vm.connectionsOpen.collectAsState()
                    val connections = rememberConnections(item.body, item.tags, item.uid, list, suggestLinks)
                    ConnectionsSection(connections, connectionsOpen, { vm.setConnectionsOpen(!connectionsOpen) }, { uid -> vm.linkRequest.value = uid }, null, Modifier.padding(bottom = 24.dp))
                }
            }
        }
        if (item != null) HeaderMenu(menu, { menu = false }) {
            if (findEntry != 0) MenuRow("search", "Find in scrap", "Search inside this scrap") { menu = false; finding = true }
            MenuRow(if (item.pinned) "star" else "starline", if (item.pinned) "Unpin" else "Pin", iconColor = if (item.pinned) t.acc else Sb.ink) { menu = false; haptics.toggle(!item.pinned); vm.togglePin(item) }
            MenuRow("copy", "Duplicate") { menu = false; vm.duplicate(item) { vm.pendingEdit = true; nav.navigate("edit/$it") } }
            MenuRow("folder", "Add to box") { menu = false; panel = "move" }
            MenuRow("tag", "Tags") { menu = false; panel = "tags" }
            MenuRow("link", "Copy link to scrap", "To paste into another app or scrap") { menu = false; clipboard.setText(AnnotatedString(scrapLink(item.uid))); Toast.makeText(ctx, "Link copied", Toast.LENGTH_SHORT).show() }
            BinderMenuRows(item.uid, item.title, item.body) { menu = false }   // [binder hook 3]
            if (Layout.entries.size > 1) MenuRow("layout", "Change layout") { menu = false; nav.navigate("layouts/${item.id}") }   // nothing to choose between while Classic is the only layout
            MenuRow("sliders", "Page style") { menu = false; sheet = true }
            MenuDivider()
            MenuRow("trash", "Delete", tint = Sb.danger) { menu = false; vm.delete(item); nav.backToLists() }
        }
        if (item != null) {
            if (sheet) CustomizeSheet(item, vm, onDone = { sheet = false })
            renaming?.let { a -> RenameSheet(a.name, { n -> vm.save(item.copy(files = item.attachments().withName(a.path, n).encodeAll())) }, { renaming = null }) }
            if (panel == "move") MoveSheet(item, vm) { panel = null }
            if (panel == "tags") TagSheet(item, vm) { panel = null }
        }
    }
}
