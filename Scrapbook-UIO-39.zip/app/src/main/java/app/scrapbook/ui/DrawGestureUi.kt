package app.scrapbook.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

// Draw gestures (UIO 12): draw a shape with TWO fingers moving together, on any page, and what you bound to it opens. Teach a shape on the Draw gestures page (Settings > Home and lists).
// Two fingers, because one finger already means tap, scroll and swipe everywhere. Only two fingers that stay the same distance apart and travel together count: a pinch or a turn,
// and anything that starts with one finger moving, is left alone. The rules for comparing shapes are in DrawGestures.kt.

/** The line being drawn (and, for a moment after, fading out), and the short message that says what it was. */
@Stable
class DrawTrail {
    var points by mutableStateOf<List<Offset>>(emptyList())
        private set
    var alpha by mutableFloatStateOf(0f)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    private var job: Job? = null

    fun update(p: List<Offset>) { job?.cancel(); points = p; alpha = 1f; message = null }

    /** The drawing is over: say [msg] (if any), then let the line fade away. */
    fun finish(scope: CoroutineScope, msg: String?) {
        job?.cancel()
        message = msg
        job = scope.launch {
            delay(if (msg != null) 800L else 150L)
            animate(alpha, 0f, animationSpec = tween(300)) { v, _ -> alpha = v }
            points = emptyList(); message = null
        }
    }

    fun clear() { job?.cancel(); points = emptyList(); alpha = 0f; message = null }
}

/**
 * Watches the whole page for two fingers that go down together and move together. Nothing is touched until that is clear (a finger that moves alone, or two that pinch, are an
 * ordinary scroll or zoom and are left completely alone); from then on the fingers belong to the drawing. [onStroke] gets the line (the middle of the two fingers) when they lift.
 */
@Composable
private fun Modifier.twoFingerDraw(enabled: Boolean, trail: DrawTrail, onStroke: (List<Offset>) -> Unit): Modifier {
    if (!enabled) return this
    val done by rememberUpdatedState(onStroke)
    return this.pointerInput(Unit) {
        awaitEachGesture {
            val first = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val slop = viewConfiguration.touchSlop
            // The second finger must come soon, while the first one is still.
            var secondId: PointerId? = null
            var p0 = first.position
            var q0 = first.position
            val got = withTimeoutOrNull(350L) {
                var ok = false
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    val f = ev.changes.firstOrNull { it.id == first.id } ?: break
                    if (!f.pressed || (f.position - first.position).getDistance() > slop) break
                    val other = ev.changes.firstOrNull { it.id != first.id && it.pressed }
                    if (other != null) { secondId = other.id; p0 = f.position; q0 = other.position; ok = true; break }
                }
                ok
            }
            val sid = secondId
            if (got != true || sid == null) return@awaitEachGesture
            val m0 = (p0 + q0) / 2f
            val sep0 = (p0 - q0).getDistance()
            val pts = ArrayList<Offset>()
            var drawing = false
            var finished = false
            try {
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    val a = ev.changes.firstOrNull { it.id == first.id }
                    val b = ev.changes.firstOrNull { it.id == sid }
                    if (a == null || b == null || !a.pressed || !b.pressed) {
                        if (drawing) { ev.changes.forEach { it.consume() }; finished = true }
                        break
                    }
                    val m = (a.position + b.position) / 2f
                    if (!drawing && (m - m0).getDistance() > slop * .75f) {
                        // Moving together keeps the distance between the fingers; a pinch or a turn does not.
                        val sep = (a.position - b.position).getDistance()
                        if (abs(sep - sep0) <= max(slop, sep0 * .25f)) { drawing = true; pts.add(m0) } else break
                    }
                    if (drawing) {
                        pts.add(m)
                        trail.update(pts.toList())
                        ev.changes.forEach { it.consume() }
                    }
                }
            } finally {
                if (drawing && !finished) trail.clear()
            }
            if (drawing && finished) done(pts)
        }
    }
}

/**
 * The whole app's draw gestures: put around the screens. While [enabled], two fingers drawing together are recognized against [gestures]; a match gives a small buzz and calls
 * [onMatch] (which knows the screens), no match gives a lighter one and says so. The line is drawn over everything while it is being drawn.
 */
@Composable
fun DrawGestureLayer(gestures: List<DrawGesture>, enabled: Boolean, onMatch: (DrawGesture) -> Unit, content: @Composable () -> Unit) {
    val haptics = LocalHaptics.current
    val trail = remember { DrawTrail() }
    val scope = rememberCoroutineScope()
    val minLength = with(LocalDensity.current) { 56.dp.toPx() }
    val current by rememberUpdatedState(gestures)
    val fire by rememberUpdatedState(onMatch)
    fun ended(points: List<Offset>) {
        val raw = points.map { Pt(it.x, it.y) }
        if (raw.size < DrawGestures.MIN_POINTS || Strokes.length(raw) < minLength) { trail.finish(scope, null); return }
        val m = DrawGestures.match(raw, current)
        if (m != null) { haptics.confirm(); trail.finish(scope, m.gesture.label); fire(m.gesture) }
        else { haptics.tick(); trail.finish(scope, "No gesture matches") }
    }
    Box(Modifier.fillMaxSize().twoFingerDraw(enabled && gestures.isNotEmpty(), trail) { ended(it) }) {
        content()
        DrawTrailView(trail)
    }
}

/** The line and the message, over the page. It takes no touches. */
@Composable
private fun DrawTrailView(trail: DrawTrail) {
    val points = trail.points
    val alpha = trail.alpha
    if (points.size < 2 && trail.message == null) return
    val acc = LocalSb.current.acc
    val width = with(LocalDensity.current) { 6.dp.toPx() }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            if (points.size >= 2) {
                val path = Path().apply { moveTo(points[0].x, points[0].y); for (i in 1 until points.size) lineTo(points[i].x, points[i].y) }
                drawPath(path, acc.copy(alpha = .85f * alpha), style = Stroke(width = width, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
        trail.message?.let { msg ->
            Text(msg, Modifier.align(Alignment.Center).graphicsLayer { this.alpha = alpha }.clip(CircleShape).background(Sb.raised).padding(horizontal = 18.dp, vertical = 10.dp),
                fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// The Draw gestures page
// ---------------------------------------------------------------------------------------------------------------------------------

/** A place to draw with one finger (the page is for teaching and trying shapes, so it needs no second finger). [resetKey] changing clears the line; [onStroke] gets the line when the finger lifts. */
@Composable
private fun StrokePad(modifier: Modifier, hint: String, resetKey: Any?, onStroke: (List<Offset>) -> Unit) {
    var pts by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val acc = LocalSb.current.acc
    val width = with(LocalDensity.current) { 6.dp.toPx() }
    val done by rememberUpdatedState(onStroke)
    LaunchedEffect(resetKey) { pts = emptyList() }
    Box(modifier.clip(RoundedCornerShape(28.dp)).background(Sb.card).pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { pts = listOf(it) },
            onDrag = { change, _ -> change.consume(); pts = pts + change.position },
            onDragCancel = { pts = emptyList() },
            onDragEnd = { done(pts) },
        )
    }, Alignment.Center) {
        if (pts.isEmpty()) Text(hint, color = Sb.mute, fontSize = 15.sp)
        Canvas(Modifier.fillMaxSize()) {
            if (pts.size >= 2) {
                val path = Path().apply { moveTo(pts[0].x, pts[0].y); for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y) }
                drawPath(path, acc, style = Stroke(width = width, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

/** A small picture of a taught shape. */
@Composable
private fun ShapePreview(shape: List<Pt>, size: androidx.compose.ui.unit.Dp) {
    val ink = Sb.ink
    Canvas(Modifier.size(size).clip(RoundedCornerShape(14.dp)).background(Sb.card)) {
        if (shape.size < 2) return@Canvas
        val minX = shape.minOf { it.x }; val maxX = shape.maxOf { it.x }; val minY = shape.minOf { it.y }; val maxY = shape.maxOf { it.y }
        val side = max(max(maxX - minX, maxY - minY), 1e-3f)
        val inner = this.size.width * .72f
        val ox = (this.size.width - inner * (maxX - minX) / side) / 2f
        val oy = (this.size.height - inner * (maxY - minY) / side) / 2f
        val path = Path()
        shape.forEachIndexed { i, p ->
            val x = ox + inner * (p.x - minX) / side
            val y = oy + inner * (p.y - minY) / side
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, ink, style = Stroke(width = this.size.width * .06f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** What a gesture opens, in words. */
private fun describe(action: String, shelves: List<Shelf>, items: List<Item>): String {
    val box = DrawActions.boxOf(action)
    val uid = DrawActions.scrapOf(action)
    return when {
        action == DrawActions.NEW -> "New scrap"
        action == DrawActions.CHECKLIST -> "New checklist"
        action == DrawActions.SEARCH -> "Search"
        box != null -> "Box: " + (if (box == "Inbox" || box == "Pinned") box else if (shelves.any { it.name == box }) shelves.labelOf(box) else "(hidden or gone)")
        uid != null -> "Scrap: " + (items.firstOrNull { it.uid == uid }?.displayTitle ?: "(gone)")
        else -> action
    }
}

@Composable
fun DrawGesturesScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current
    val list by vm.drawGestures.collectAsState()
    val on by vm.drawOn.collectAsState()
    val shelves by vm.shelves.collectAsState()
    val scraps by vm.items.collectAsState()
    val haptics = LocalHaptics.current
    var adding by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<DrawGesture?>(null) }
    var tryResult by remember { mutableStateOf<String?>(null) }
    var tryKey by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.page) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
                Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn("Go back", { nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
                    Box(Modifier.weight(1f), Alignment.Center) {
                        Text("scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp, maxLines = 1)
                    }
                    Spacer(Modifier.size(44.dp))
                }
                Text("Draw gestures", Modifier.padding(start = 28.dp, top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        Text("Draw a shape on any page with two fingers moving together, and a box or a scrap opens. Teach a shape here first: draw it three times, then choose what it opens.",
                            fontSize = 15.sp, lineHeight = 21.sp, color = Sb.mute, modifier = Modifier.padding(horizontal = 8.dp))
                    }
                    item { SettingsCard { SwitchRow("edit", "Draw gestures", on) { vm.setDrawOn(it) } } }
                    if (list.isNotEmpty()) item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            SectionLabel("Try it")
                            StrokePad(Modifier.fillMaxWidth().height(170.dp), "Draw a shape here with one finger", tryKey) { pts ->
                                val raw = pts.map { Pt(it.x, it.y) }
                                val ranked = DrawGestures.ranked(raw, list)
                                val best = ranked.firstOrNull()
                                val m = DrawGestures.match(raw, list)
                                tryResult = when {
                                    best == null -> "Draw a longer line."
                                    m != null -> { haptics.confirm(); "That is “${m.gesture.label}” (${(m.score * 100).roundToInt()}%)." }
                                    else -> "No match. The closest is “${best.gesture.label}” (${(best.score * 100).roundToInt()}%), but it needs ${(DrawGestures.MIN_SCORE * 100).roundToInt()}%."
                                }
                            }
                            Text(tryResult ?: "The result shows here. Nothing opens on this page.", Modifier.padding(horizontal = 8.dp), fontSize = 14.sp, color = Sb.mute)
                        }
                    }
                    item { SectionLabel("Your gestures") }
                    if (list.isEmpty()) item { Text("None yet.", Modifier.padding(horizontal = 8.dp), fontSize = 15.sp, color = Sb.mute) }
                    items(list, key = { it.id }) { g ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card).padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
                            Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                            ShapePreview(g.samples.first(), 56.dp)
                            Column(Modifier.weight(1f)) {
                                Text(describe(g.action, shelves, scraps), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${g.samples.size} tries", fontSize = 13.sp, color = Sb.mute)
                            }
                            Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Delete this gesture") { removing = g }, Alignment.Center) { Ic("trash", 22.dp, Sb.mute) }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth().height(56.dp).clip(CircleShape).background(LocalSb.current.acc).tap("Add a gesture") { adding = true },
                            Arrangement.Center, Alignment.CenterVertically) {
                            Ic("plus", 22.dp, onAccent(LocalSb.current.acc))
                            Spacer(Modifier.width(8.dp))
                            Text("Add a gesture", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = onAccent(LocalSb.current.acc))
                        }
                    }
                }
            }
        }
        if (adding) DrawEditor(vm, list, shelves, scraps) { adding = false; tryKey++ }
        removing?.let { g ->
            Sheet("Delete this gesture?", { removing = null }, doneLabel = "Cancel", soft = true) {
                ActionRow("trash", "Delete", sub = describe(g.action, shelves, scraps), danger = true) { vm.setDrawGestures(list.filter { it.id != g.id }); removing = null }
            }
        }
    }
}

/** Teaching a new gesture: draw it three times, then choose what it opens. */
@Composable
private fun DrawEditor(vm: ArchiveViewModel, existing: List<DrawGesture>, shelves: List<Shelf>, items: List<Item>, onDone: () -> Unit) {
    val t = LocalSb.current
    val haptics = LocalHaptics.current
    val samples = remember { mutableStateListOf<List<Pt>>() }
    var message by remember { mutableStateOf<String?>(null) }
    var padKey by remember { mutableIntStateOf(0) }
    var choosing by remember { mutableStateOf(false) }
    var picker by remember { mutableIntStateOf(0) }       // 0 what kind, 1 which box, 2 which scrap
    var query by remember { mutableStateOf("") }
    fun save(action: String) {
        val g = DrawGesture(DrawGestures.newId(), describe(action, shelves, items), action, samples.toList())
        vm.setDrawGestures(existing + g)
        haptics.confirm()
        onDone()
    }
    Box(Modifier.fillMaxSize().background(t.paper)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircleBtn("Cancel", onDone) { Ic("close", 22.dp, Sb.ink) }
                Text("New gesture", Modifier.padding(start = 14.dp), fontSize = 18.sp, fontWeight = FontWeight.Medium, fontFamily = headFont())
            }
            Text(if (samples.size >= DrawGestures.SAMPLES) "Good. Now choose what it opens." else "Draw your shape, try ${samples.size + 1} of ${DrawGestures.SAMPLES}. Lift your finger between tries, and draw it the same way each time.",
                fontSize = 15.sp, lineHeight = 21.sp, color = Sb.mute)
            StrokePad(Modifier.fillMaxWidth().aspectRatio(1f), "Draw here", padKey) { pts ->
                if (samples.size >= DrawGestures.SAMPLES) return@StrokePad
                val raw = pts.map { Pt(it.x, it.y) }
                if (raw.size < DrawGestures.MIN_POINTS || Strokes.length(raw) < 120f) { message = "Draw a bigger shape."; padKey++; return@StrokePad }
                val n = Strokes.normalize(raw)
                if (samples.isNotEmpty() && Strokes.score(n, samples[0]) < DrawGestures.SAME_TRY) { message = "That looks different from your first try. Draw the same shape again."; padKey++; return@StrokePad }
                samples.add(n); message = null; haptics.tick(); padKey++
            }
            message?.let { Text(it, fontSize = 14.sp, color = Sb.danger) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                samples.forEach { ShapePreview(it, 56.dp) }
                if (samples.isNotEmpty()) Text("Undo last", Modifier.tap("Undo the last try") { samples.removeAt(samples.lastIndex); message = null }.padding(12.dp), fontSize = 15.sp, color = Sb.mute)
            }
            Spacer(Modifier.weight(1f))
            val ready = samples.size >= DrawGestures.SAMPLES
            Row(Modifier.fillMaxWidth().height(56.dp).clip(CircleShape).background(if (ready) LocalSb.current.acc else Sb.card)
                .then(if (ready) Modifier.tap("Next") {
                    val clash = DrawGestures.clash(samples.toList(), existing)
                    if (clash != null) { message = "Too close to “${describe(clash.gesture.action, shelves, items)}”. Draw a different shape."; samples.clear(); padKey++ }
                    else { choosing = true; picker = 0 }
                } else Modifier), Arrangement.Center, Alignment.CenterVertically) {
                Text("Next", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = if (ready) onAccent(LocalSb.current.acc) else Sb.mute)
            }
        }
        if (choosing) {
            Sheet(if (picker == 0) "What should it open?" else if (picker == 1) "Which box?" else "Which scrap?", { if (picker != 0) picker = 0 else choosing = false }, doneLabel = "Back") {
                if (picker == 0) {
                    SheetGroup {
                        ActionRow("folder", "A box", "Choose which one") { picker = 1 }
                        SheetDivider(18.dp)
                        ActionRow("page", "A scrap", "Choose which one") { picker = 2 }
                    }
                    SheetGroup {
                        ActionRow("edit", "New scrap") { save(DrawActions.NEW) }
                        SheetDivider(18.dp)
                        ActionRow("check", "New checklist") { save(DrawActions.CHECKLIST) }
                        SheetDivider(18.dp)
                        ActionRow("search", "Search") { save(DrawActions.SEARCH) }
                    }
                } else if (picker == 1) {
                    SheetGroup {
                        OptionRow("Inbox", false) { save(DrawActions.box("Inbox")) }
                        SheetDivider(46.dp)
                        OptionRow("Pinned", false) { save(DrawActions.box("Pinned")) }
                        BoxTreeRows(shelves, null) { s -> save(DrawActions.box(s.name)) }
                    }
                } else {
                    InputBox { Field(query, { query = it }, "Search your scraps", 16.sp, headFont()) }
                    val shown = remember(items, query) {
                        val q = query.trim()
                        items.filter { q.isEmpty() || it.title.contains(q, true) || it.body.contains(q, true) }.sortedByDescending { it.savedAt }.take(25)
                    }
                    if (shown.isEmpty()) SheetNote("No scraps match.")
                    else SheetGroup {
                        shown.forEachIndexed { i, n ->
                            if (i > 0) SheetDivider(18.dp)
                            OptionRow(n.displayTitle, false, sub = LocalShelves.current.displayName(n.collection)) { save(DrawActions.scrap(n.uid)) }
                        }
                    }
                }
            }
        }
    }
}
