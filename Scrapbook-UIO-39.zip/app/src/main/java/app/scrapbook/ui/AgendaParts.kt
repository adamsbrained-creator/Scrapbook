package app.scrapbook.ui

import android.text.format.DateFormat as AndroidDateFormat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import java.util.Date

// The pieces of the Agenda skin, each usable on its own in any skin (see Agenda.kt and SectionTabs.kt for the rules):
//  - AgendaShape: the Agenda layout of a section (and of the Pinned and Recent parts): scraps under a heading for each day, each as a soft row.
//  - PillTabs: a floating pill of tabs, the chosen one raised.
//  - HeadPill: the small round-ended buttons (Edit, Add) of a title row.
//  - TabsFrame: what a tabs card puts around its list (the title row and the pill tabs); HomeSectionsUi.kt draws it.

/** The height the pill tabs take (the bar and the space around it), in dp. A section that fills the page gives its list that much less. */
internal const val TAB_BAR_DP = 66

/** The room Home keeps clear at the bottom while the pill tabs are docked to the screen: the bar (54dp), the space under it and a little air above it, in dp. */
internal const val DOCK_ROOM_DP = 84

/**
 * What a tabs card adds around its body. [labels] are the tabs, [current] the one shown, [head] whether the big name with the Edit and Add pills shows, [barTop] whether the pill tabs sit above the list,
 * and [dock] whether they are docked to the screen instead (Home draws them, see [TabsDock], so the section draws no bar of its own).
 */
internal class TabsFrame(val labels: List<String>, val current: Int, val onTab: (Int) -> Unit, val head: Boolean, val barTop: Boolean, val title: String, val onAdd: () -> Unit, val dock: Boolean = false)

/** A small button with a round end: soft (Edit) or in the accent color (Add). */
@Composable
internal fun HeadPill(text: String, accent: Boolean, desc: String? = null, onClick: () -> Unit) {
    val acc = LocalSb.current.acc
    val bg = if (accent) acc else Sb.card
    val fg = if (accent) onAccent(acc) else Sb.ink
    Box(Modifier.pressScale(.94f).minimumInteractiveComponentSize().clip(CircleShape).background(bg).tap(desc ?: text, onClick).padding(horizontal = 18.dp, vertical = 10.dp), Alignment.Center) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = fg, maxLines = 1)
    }
}

/** A floating pill holding [labels]; the one at [current] sits raised in a lighter pill of its own. With [fill] the tabs share the width they are given equally (a name too long for its share is cut short). */
@Composable
internal fun PillTabs(labels: List<String>, current: Int, modifier: Modifier = Modifier, fill: Boolean = false, onSelect: (Int) -> Unit) {
    val haptics = LocalHaptics.current
    val container = if (Sb.greyBg && !Sb.dark) Sb.line else Sb.card
    Row(modifier.shadow(4.dp, CircleShape).clip(CircleShape).background(container).padding(5.dp), Arrangement.spacedBy(2.dp), Alignment.CenterVertically) {
        labels.forEachIndexed { i, label ->
            val on = i == current
            val bg by animateColorAsState(if (on) (if (Sb.dark) Sb.menu else Color.White) else Color.Transparent, tween(180), label = "pillTab")
            Box(Modifier.then(if (fill) Modifier.weight(1f) else Modifier).heightIn(min = 44.dp).clip(CircleShape).background(bg).semantics { selected = on }
                .tap(label) { if (!on) { haptics.tick(); onSelect(i) } }.padding(horizontal = if (fill) 8.dp else 18.dp), Alignment.Center) {
                Text(label, fontSize = 15.sp, fontWeight = if (on) FontWeight.Medium else FontWeight.Normal, color = if (on) (if (Sb.dark) Sb.ink else Color(0xFF1C1C1C)) else Sb.ink.copy(alpha = .75f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/**
 * The pill tabs docked to the bottom of the screen, like a navigation bar, in the Box that holds the page: they stay where they are while the page's list moves. With [addButton] the round
 * New scrap button sits beside them ([onAdd] starts the scrap); without it the page's own add control is somewhere else. [startRoom] and [endRoom] keep the bar clear of a round button at that
 * side of the screen, and [lift] raises it over a bar that takes the bottom (the Writing bar).
 */
@Composable
internal fun BoxScope.TabsDock(labels: List<String>, current: Int, onTab: (Int) -> Unit, startRoom: Dp, endRoom: Dp, lift: Dp, addButton: Boolean, onAdd: () -> Unit) {
    Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 16.dp + startRoom, end = 16.dp + endRoom, bottom = 18.dp + lift), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        PillTabs(labels, current, Modifier.weight(1f), true, onTab)
        if (addButton) AddHold(Modifier) { DockAddButton(onAdd) }
    }
}

/** The round New scrap button that sits beside docked tabs, in the accent color of Home. */
@Composable
internal fun DockAddButton(onAdd: () -> Unit) {
    val acc = LocalSb.current.acc
    Box(Modifier.pressScale(.95f).size(56.dp).shadow(6.dp, CircleShape).clip(CircleShape).background(acc).tap("New scrap", onAdd), Alignment.Center) {
        Ic("edit", 24.dp, onAccent(acc))
    }
}

// ----- The Agenda layout -----

/** The heading over a day: "13 Feb, Mon". */
@Composable
private fun AgendaHeading(text: String, first: Boolean) {
    Text(text, Modifier.padding(start = 6.dp, top = if (first) 0.dp else 14.dp).asHeading(), fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

/** The line under a row's title, as the section's style says: the time, the box, the start of the text, or nothing. */
@Composable
private fun agendaSub(e: Entry, style: SectionStyle, timePattern: String): String {
    val n = e.scrap
    return when (style.agSub) {
        0 -> if (n != null) Fmt.of(timePattern).format(Date(n.savedAt)) else countText(e.count)
        1 -> if (n != null) LocalShelves.current.displayName(n.collection) else "Box"
        2 -> if (n != null) remember(n.title, n.body) { previewHead(n.title, n.body, 90).replace('\n', ' ') } else countText(e.count)
        else -> ""
    }
}

/** One row: the tile (an emoji or an icon), the title with its line under it, and an arrow, on a soft card in the look of Home. */
@Composable
private fun AgendaRow(e: Entry, style: SectionStyle, timePattern: String, onClick: () -> Unit) {
    val n = e.scrap
    val sub = agendaSub(e, style, timePattern)
    // The scrap's own emoji is in the tile, so the title leaves it out there.
    val title = if (n != null && style.agTile == 0 && n.icon.isNotBlank()) n.title.ifBlank { e.label } else e.label
    // The tile is lighter than the card it sits on: white on the light card, the page color on the dark one, and the card color when the card is only a line or nothing.
    val tileColor = if (LocalHomeLook.current.card == 1 || LocalHomeLook.current.card == 3) Sb.card else if (Sb.dark) Sb.paper else Sb.raised
    Row(Modifier.pressScale(.98f).fillMaxWidth().homeCard(26.dp).tap("Open ${e.label}", onClick).padding(start = 10.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        when (style.agTile) {
            0 -> Box(Modifier.size(46.dp).clip(RoundedCornerShape(LocalHomeLook.current.radius(15f).dp)).background(tileColor), Alignment.Center) { NodeGlyph(e, style, Sb.ink, 46.dp) }
            1 -> Box(Modifier.padding(start = 8.dp).size(12.dp).clip(CircleShape).background(e.dot ?: LocalSb.current.acc))
            else -> Spacer(Modifier.width(6.dp))
        }
        Column(Modifier.weight(1f), Arrangement.spacedBy(2.dp)) {
            Text(title, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 21.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) Text(sub, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (n != null && n.pinned && style.agStar) Ic("star", 14.dp, Color(0xFFFFB400))
        if (style.agChevron) Ic("chevron", 18.dp, Sb.mute)
    }
}

/**
 * The Agenda layout: [entries] under a heading for each day they were last edited (boxes first, under "Boxes"), each as a soft row. [style] says whether the headings show, what sits under a
 * title, what is before it, whether the arrow shows and the order. With a height of its own ([h] more than 0) the list scrolls inside it. [pad] is the page margin the layout adds itself.
 */
@Composable
internal fun AgendaShape(entries: List<Entry>, style: SectionStyle, h: Int, pad: Dp, held: HeldWrap, open: (Entry) -> Unit) {
    val pattern = if (AndroidDateFormat.is24HourFormat(LocalContext.current)) "HH:mm" else "h:mm a"
    val groups = Agenda.groups(entries.map { it.scrap?.savedAt }, style.agOldFirst)
    val scroll = rememberScrollState()
    Column(Modifier.fillMaxWidth().then(if (h > 0) Modifier.fillMaxHeight().verticalScroll(scroll) else Modifier).padding(horizontal = pad), Arrangement.spacedBy(10.dp)) {
        if (style.agDays) {
            groups.forEachIndexed { gi, g ->
                AgendaHeading(g.heading, gi == 0)
                g.indices.forEach { i -> val e = entries[i]; held(e, Modifier.fillMaxWidth()) { AgendaRow(e, style, pattern) { open(e) } } }
            }
        } else {
            Agenda.flat(groups).forEach { i -> val e = entries[i]; held(e, Modifier.fillMaxWidth()) { AgendaRow(e, style, pattern) { open(e) } } }
        }
    }
}
