package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppBackgroundTest {
    @Test fun noChoicesIsThePlainPageAndSavesNothing() {
        val b = AppBackground()
        assertTrue(b.isDefault)
        assertFalse(b.active)
        assertEquals("", b.encode())
        assertEquals(b, AppBackground.decode(null))
        assertEquals(b, AppBackground.decode(""))
    }

    @Test fun everyChoiceIsSavedAndReadBack() {
        val b = AppBackground(kind = AppBackground.GLOW, top = 0x6B5A4E, bottom = 0x101820, direction = 2, glow = 0xFF6FB1, mix = 0, strength = 2, speed = 3, glass = true, inEditor = true)
        assertEquals(b, AppBackground.decode(b.encode()))
        assertTrue(b.active)
    }

    @Test fun onlyWhatIsNotTheUsualIsWritten() {
        assertEquals("k=1", AppBackground(kind = AppBackground.GRADIENT).encode())
        assertEquals("k=1;t=6B5A4E;gl=1", AppBackground(kind = 1, top = 0x6B5A4E, glass = true).encode())
    }

    @Test fun numbersAndColorsAreKeptInTheirLimits() {
        val b = AppBackground.decode("k=9;d=7;m=3;s=-4;p=99;t=1FFFFFFF")
        assertEquals(2, b.kind)
        assertEquals(2, b.direction)
        assertEquals(1, b.mix)
        assertEquals(0, b.strength)
        assertEquals(3, b.speed)
        assertEquals(AppBackground.DEFAULT_TOP, b.top)   // a number that is not a color is skipped
    }

    @Test fun nonsenseIsSkipped() {
        val b = AppBackground.decode("junk;=3;k=abc;t=zzz;b=12;g=;gl=1;ed=0;q=1")
        assertEquals(AppBackground(glass = true), b)
    }

    @Test fun aColorIsWrittenAsSixHexDigits() {
        assertEquals("1D4E89", AppBackgrounds.hex(0x1D4E89))
        assertEquals("00000F", AppBackgrounds.hex(0xF))
        assertEquals("FFFFFF", AppBackgrounds.hex(-1))
    }

    @Test fun hexIsReadInTheUsualWays() {
        assertEquals(0x1D4E89, AppBackgrounds.parseHex("#1D4E89"))
        assertEquals(0x1D4E89, AppBackgrounds.parseHex(" 1d4e89 "))
        assertEquals(0x1144EE, AppBackgrounds.parseHex("#14e"))
        assertNull(AppBackgrounds.parseHex(""))
        assertNull(AppBackgrounds.parseHex("#12345"))
        assertNull(AppBackgrounds.parseHex("#GGGGGG"))
        assertNull(AppBackgrounds.parseHex("1D4E89A"))
    }

    @Test fun lightnessGoesFromBlackToWhite() {
        assertEquals(0f, AppBackgrounds.luminance(0x000000), 1e-4f)
        assertEquals(1f, AppBackgrounds.luminance(0xFFFFFF), 1e-4f)
        assertEquals(0.299f, AppBackgrounds.luminance(0xFF0000), 1e-3f)
        assertTrue(AppBackgrounds.luminance(0xFFFF00) > AppBackgrounds.luminance(0x0000FF))
    }

    @Test fun theNeighborsOnTheColorWheelAreFortyDegreesAway() {
        assertEquals(0xFFAA00 to 0xFF00AA, AppBackgrounds.companions(0xFF0000))
        // A grey has no color to turn: its neighbors are the same grey.
        assertEquals(0x808080 to 0x808080, AppBackgrounds.companions(0x808080))
    }

    @Test fun darkTextNeedsALightBackgroundAndTheOtherWayRound() {
        val dark = AppBackground(kind = 1, top = 0x1D4E89, bottom = 0x0B0B0B)
        val pale = AppBackground(kind = 1, top = 0xF4E9C9, bottom = 0xFFFFFF)
        assertTrue(dark.readable(true))
        assertFalse(dark.readable(false))
        assertFalse(pale.readable(true))
        assertTrue(pale.readable(false))
        assertTrue(AppBackground().readable(true) && AppBackground().readable(false))
    }

    @Test fun aGlowIsJudgedByHowMuchOfItIsDrawn() {
        val soft = AppBackground(kind = 2, glow = 0xFFFFFF, strength = 0)
        val strong = AppBackground(kind = 2, glow = 0xFFFFFF, strength = 2)
        assertTrue(soft.readable(true))
        assertFalse(strong.readable(true))
        assertTrue(AppBackground(kind = 2, glow = 0x4DA3FF).readable(true))
    }

    @Test fun glowSpeedsAreSlowerToFaster() {
        assertEquals(0, AppBackgrounds.periodMs(0))
        assertTrue(AppBackgrounds.periodMs(1) > AppBackgrounds.periodMs(2) && AppBackgrounds.periodMs(2) > AppBackgrounds.periodMs(3))
        assertTrue(AppBackgrounds.strengthFactor(0) < AppBackgrounds.strengthFactor(1) && AppBackgrounds.strengthFactor(1) < AppBackgrounds.strengthFactor(2))
    }
}
