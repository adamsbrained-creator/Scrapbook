package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// Customize home: every part of the Home page as one row. Drag the handle to move a part, tap the eye to hide or show it.
// The rows are short on purpose: the whole page fits on the screen, so a part can travel from the top to the bottom in one drag.
// What is saved is only the order and which parts are hidden (see HomeLayout.kt); no scrap or box is touched.

private fun iconOf(e: HomeElement) = when (e) {
    HomeElement.Header -> "menu"
    HomeElement.Greeting -> "sparkle"
    HomeElement.Capture -> "edit"
    HomeElement.Continue -> "arrow"
    HomeElement.Sort -> "sort"
    HomeElement.Boxes -> "folder"
    HomeElement.Pinned -> "star"
    HomeElement.Recent -> "clock"
}

/**
 * The screen that takes the place of Home while it is being customized. [notes] is the line under each part's name. [onChange] gets every new layout straight away.
 * A part in [withOptions] gets a sliders button on its row; it opens [options], a page of that part's own settings that takes the place of this list until it calls its back button.
 */
@Composable
fun HomeCustomize(
    layout: HomeLayout, notes: Map<HomeElement, String>, onChange: (HomeLayout) -> Unit, onDone: () -> Unit,
    withOptions: Set<HomeElement> = emptySet(), options: @Composable (HomeElement, () -> Unit) -> Unit = { _, _ -> },
) {
    val haptics = LocalHaptics.current
    val drag = remember { DragReorder(vertical = true) }
    // Several swaps can happen in one drag event, before the screen has had time to show the first: each one starts from the layout the last one made.
    val live = remember { arrayOf(layout) }
    SideEffect { live[0] = layout }
    fun commit(next: HomeLayout) { live[0] = next; onChange(next) }
    val move: (Int, Int) -> Unit = { from, to -> commit(live[0].move(from, to)) }
    BackHandler { onDone() }
    var page by remember { mutableStateOf<HomeElement?>(null) }
    val open = page
    if (open != null) { options(open) { page = null }; return }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 16.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
            Text("Customize home", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
            Text("Done", Modifier.pressScale(.94f).clip(CircleShape).background(Sb.ink).tap("Done", onDone).padding(horizontal = 22.dp, vertical = 12.dp),
                color = Sb.card, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Text("Hold the handle and drag a part to move it. Tap the eye to hide it or bring it back." + if (withOptions.isNotEmpty()) " Parts with a sliders button have their own options." else "", Modifier.padding(horizontal = 24.dp, vertical = 10.dp), fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute)

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp), userScrollEnabled = drag.active == null) {
            items(layout.order, key = { it.key }) { el ->
                val i = layout.order.indexOf(el)
                val hidden = layout.isHidden(el)
                val dragging = drag.active == el
                // The row being dragged follows the finger, so it must not also slide to its new place; the others do.
                Box(Modifier.animateItem(placementSpec = if (dragging) null else tween(220)).reorderLayer(drag, el).fillMaxWidth().height(80.dp).padding(vertical = 4.dp)
                    .semantics {
                        customActions = listOf(
                            CustomAccessibilityAction("Move ${el.label} up") { if (i > 0) { haptics.tick(); move(i, i - 1); true } else false },
                            CustomAccessibilityAction("Move ${el.label} down") { if (i < layout.order.lastIndex) { haptics.tick(); move(i, i + 1); true } else false },
                        )
                    }) {
                    Row(Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)).background(Sb.card).padding(start = 18.dp, end = 4.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        Row(Modifier.weight(1f).alpha(if (hidden) .4f else 1f).then(if (el in withOptions) Modifier.tap("${el.label} options") { page = el } else Modifier), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                            Ic(iconOf(el), 24.dp, Sb.ink)
                            Column(Modifier.weight(1f)) {
                                Text(el.label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (hidden) "Hidden" else notes[el].orEmpty(), fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (el in withOptions) Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("${el.label} options") { page = el }, Alignment.Center) { Ic("sliders", 22.dp, Sb.ink) }
                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon(if (hidden) "Show ${el.label}" else "Hide ${el.label}") {
                            haptics.toggle(hidden); commit(live[0].withHidden(el, !hidden))
                        }, Alignment.Center) { Ic(if (hidden) "eyeoff" else "eye", 22.dp, if (hidden) Sb.mute else Sb.ink) }
                        Box(Modifier.size(48.dp).reorderGesture(drag, el, layout.order, true, move, handle = true).semantics { contentDescription = "Drag ${el.label}" }, Alignment.Center) {
                            Ic("grip", 22.dp, Sb.mute)
                        }
                    }
                }
            }
            if (layout != HomeLayout.Default) item(key = "reset") {
                Text("Back to the usual order", Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f))
                    .tap("Put every part back where it was and show them all") { haptics.confirm(); commit(HomeLayout.Default) }.padding(vertical = 16.dp),
                    color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            }
        }
    }
}
