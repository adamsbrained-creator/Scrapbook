package app.scrapbook.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.onLongClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.findCounter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Find in scrap (editor only): the find bar, the back button that turns into a search button when held, and the highlights.

/** How long the back button is held before it turns into the search button. Long enough that a slow tap never does it by accident. */
private const val FIND_HOLD_MS = 650

/** How long the search button stays before it turns back into the back button. */
private const val FIND_ARMED_MS = 5000L

/**
 * The editor's round back button. A tap saves and goes back. Hold it ([holdToFind]): a ring fills around it, it vibrates and turns into a search
 * button for a few seconds, and tapping that opens find. Not tapped, it turns back by itself.
 */
@Composable
fun BackFindButton(holdToFind: Boolean, onBack: () -> Unit, onFind: () -> Unit) {
    val acc = LocalSb.current.acc; val haptics = LocalHaptics.current; val scope = rememberCoroutineScope()
    var armed by remember { mutableStateOf(false) }
    var holdDone by remember { mutableStateOf(false) }
    val ring = remember { Animatable(0f) }
    val morph by animateFloatAsState(if (armed) 1f else 0f, spring(dampingRatio = .55f, stiffness = Spring.StiffnessMedium), label = "findMorph")
    LaunchedEffect(armed) { if (armed) { delay(FIND_ARMED_MS); armed = false } }
    val backNow by rememberUpdatedState(onBack); val findNow by rememberUpdatedState(onFind)
    fun tapped() { if (armed) { armed = false; findNow() } else backNow() }
    Box(Modifier.size(44.dp).clip(CircleShape).background(lerp(Sb.card, acc.copy(alpha = .3f), morph.coerceIn(0f, 1f)))
        .semantics(mergeDescendants = true) {
            role = Role.Button; contentDescription = if (armed) "Find in scrap" else "Save and go back"
            onClick(if (armed) "Find in scrap" else "Save and go back") { tapped(); true }
            if (holdToFind) onLongClick("Find in scrap") { findNow(); true }
        }
        .pointerInput(holdToFind) {
            detectTapGestures(
                onPress = {
                    if (holdToFind && !armed) {
                        holdDone = false
                        val job = scope.launch { ring.animateTo(1f, tween(FIND_HOLD_MS, easing = LinearEasing)); holdDone = true; armed = true; haptics.toggle(true) }
                        tryAwaitRelease()
                        if (!holdDone) job.cancel()
                        scope.launch { ring.snapTo(0f) }
                    }
                },
                // A hold that finished turned the button into search; letting go afterwards must not also count as a tap.
                onTap = { if (holdDone) holdDone = false else tapped() },
            )
        }, Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            if (ring.value > 0f) {
                val w = 2.5.dp.toPx()
                drawArc(acc, -90f, 360f * ring.value, false, Offset(w / 2, w / 2), Size(size.width - w, size.height - w), style = Stroke(w, cap = StrokeCap.Round))
            }
        }
        Box(Modifier.graphicsLayer { alpha = (1f - morph).coerceIn(0f, 1f); rotationZ = -90f * morph; scaleX = 1f - .4f * morph; scaleY = 1f - .4f * morph }) { Ic("back", 26.dp, Sb.ink) }
        Box(Modifier.graphicsLayer { alpha = morph.coerceIn(0f, 1f); rotationZ = 90f * (1f - morph); scaleX = .6f + .4f * morph; scaleY = .6f + .4f * morph }) { Ic("search", 24.dp, acc) }
    }
}

/** Replaces the editor's header while finding: back (closes find), the field with the match counter and a clear button, then next and previous. */
@Composable
fun FindBar(query: String, onQuery: (String) -> Unit, count: Int, current: Int, onNext: () -> Unit, onPrev: () -> Unit, onClose: () -> Unit) {
    val t = LocalSb.current; val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Sb.card).tap("Close find", onClose), Alignment.Center) { Ic("back", 26.dp, Sb.ink) }
        Row(Modifier.weight(1f).height(44.dp).clip(CircleShape).background(Sb.card).padding(start = 16.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(query, onQuery, Modifier.weight(1f).focusRequester(focus), singleLine = true, textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(t.acc),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { onNext() }),
                decorationBox = { inner -> Box { if (query.isEmpty()) Text("Find in scrap", color = Sb.mute, fontSize = 16.sp, maxLines = 1); inner() } })
            val label = findCounter(current, count, query)
            if (label.isNotEmpty()) Text(label, Modifier.padding(horizontal = 6.dp), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
            if (query.isNotEmpty()) Box(Modifier.size(36.dp).clip(CircleShape).tap("Clear") { onQuery("") }, Alignment.Center) { Ic("close", 18.dp, Sb.mute) }
        }
        Row(Modifier.height(44.dp).clip(CircleShape).background(Sb.card).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            HeaderBtn("Next match", onNext) { Ic("down", 22.dp, if (count > 0) Sb.ink else Sb.mute) }
            HeaderBtn("Previous match", onPrev) { Ic("up", 22.dp, if (count > 0) Sb.ink else Sb.mute) }
        }
    }
}

/** The editor's text with every match marked softly and the current one strongly. The match ranges are in shown (not saved) positions. */
fun withFindMarks(out: TransformedText, ranges: List<IntRange>, current: Int, acc: Color): TransformedText {
    val len = out.text.length
    val text = buildAnnotatedString {
        append(out.text)
        ranges.forEachIndexed { i, r ->
            val a = r.first.coerceIn(0, len); val b = (r.last + 1).coerceIn(0, len)
            if (b > a) addStyle(SpanStyle(background = acc.copy(alpha = if (i == current) .6f else .28f)), a, b)
        }
    }
    return TransformedText(text, out.offsetMapping)
}
