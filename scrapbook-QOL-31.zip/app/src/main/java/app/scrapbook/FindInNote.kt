package app.scrapbook

// The plain rules behind "Find in scrap" in the editor.

/**
 * Where [q] occurs in the [shown] text (what you see in the editor, without the hidden formatting marks), as ranges of character positions.
 * Ignores case, and ignores spaces typed at either end: a phone keyboard adds one after every suggestion, which would hide words at the end of a line.
 * Matches never overlap: "aa" in "aaaa" is found twice.
 */
fun findMatches(shown: String, q: String): List<IntRange> {
    val t = q.trim()
    if (t.isEmpty()) return emptyList()
    val out = ArrayList<IntRange>(); var i = 0
    while (i <= shown.length - t.length) {
        if (shown.regionMatches(i, t, 0, t.length, ignoreCase = true)) { out += i until i + t.length; i += t.length } else i++
    }
    return out
}

/** The match after (or before) [current], wrapping around at both ends. */
fun nextMatch(current: Int, count: Int, forward: Boolean): Int =
    if (count <= 0) 0 else if (forward) (current + 1) % count else (current - 1 + count) % count

/** "3/12", "No matches", or nothing while the field is empty. [current] counts from 0. */
fun findCounter(current: Int, count: Int, q: String): String = when {
    q.isBlank() -> ""
    count == 0 -> "No matches"
    else -> "${current.coerceIn(0, count - 1) + 1}/$count"
}
