package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class FindInNoteTest {
    @Test fun findsEveryMatchIgnoringCase() = assertEquals(listOf(0..3, 9..12), findMatches("Goal and goal", "GOAL"))

    @Test fun matchesNeverOverlap() {
        assertEquals(listOf(0..1, 2..3), findMatches("aaaa", "aa"))
        assertEquals(listOf(0..1, 2..3), findMatches("abab", "ab"))
    }

    @Test fun spacesAtTheEndsOfTheQueryAreIgnored() = assertEquals(listOf(4..7), findMatches("the goal", "  goal "))

    @Test fun spacesInsideTheQueryCount() {
        assertEquals(listOf(0..6), findMatches("red car, blue car", "red car"))
        assertEquals(emptyList<IntRange>(), findMatches("red   car", "red car"))
    }

    @Test fun emptyQueryOrNoMatchFindsNothing() {
        assertEquals(emptyList<IntRange>(), findMatches("hello", ""))
        assertEquals(emptyList<IntRange>(), findMatches("hello", "   "))
        assertEquals(emptyList<IntRange>(), findMatches("hello", "xyz"))
        assertEquals(emptyList<IntRange>(), findMatches("", "a"))
    }

    @Test fun positionsStayCorrectAfterLettersThatChangeLengthWhenLowercased() = assertEquals(listOf(9..12), findMatches("İstanbul city", "city"))

    @Test fun nextAndPreviousWrapAround() {
        assertEquals(1, nextMatch(0, 3, true)); assertEquals(0, nextMatch(2, 3, true))
        assertEquals(2, nextMatch(0, 3, false)); assertEquals(0, nextMatch(1, 3, false))
        assertEquals(0, nextMatch(0, 0, true)); assertEquals(0, nextMatch(0, 1, false))
    }

    @Test fun counterText() {
        assertEquals("", findCounter(0, 0, ""))
        assertEquals("", findCounter(0, 5, "  "))
        assertEquals("No matches", findCounter(0, 0, "zzz"))
        assertEquals("3/12", findCounter(2, 12, "a"))
        assertEquals("12/12", findCounter(40, 12, "a"))
    }
}
