# Scrapbook (v0.1)

A personal notes and archive app for Android: notes, quotes, links and photos with eight page layouts,
collections, search, a Rediscover swipe, per-page styling, a Settings page (theme, white or soft grey background,
accent, lists, boxes, backup/restore; seven box styles: Tabbed, Paper stack, Tinted tiles, Folder tabs, Chips, List rows, Notebook covers; and five looks for the Boxes screen: Default, Nested, Shelf, Cover, Stack), an About page (version, What's new, feedback, licenses, and links to the other apps in the family), a home-screen widget, and sharing into the app from other apps. The app reopens in the box you were last in (switch off in Settings). A scrap reopens with the cursor and scroll where you left them, and with the keyboard up if you were typing (`EditorSpots.kt`: view state kept on the phone, never inside the scrap). Deleted scraps go to a Bin for 30 days (Menu, then Bin) and every scrap keeps earlier versions of its text (3-dot menu, then Version history); every scrap can have its own icon, accent, page color, cover and layout (3-dot menu, then Page style), and its card in the lists is dressed to match (`NoteRow` and `NoteTile` in `ui/Home.kt`); both are plain Room tables, see `Versions.kt` for the rules. Inbox is where quick captures land; when scraps are waiting there, Home shows a To sort card that opens Sort Inbox (`ui/SortInbox.kt`: add to a box, keep close, delete or later, oldest first; the rules are in `Inbox.kt`). A scrap arriving in a hidden Inbox brings it back. Long-press a scrap on All scraps or in a box to pick several: `ui/Selecting.kt` has the toolbar (add to box, pin, tags, delete, each with one Undo), `Selection.kt` the plain rules, and the batch queries live in `Data.kt` and `ArchiveViewModel.kt`.

**Attachments:** photos (tap one to open the full-screen viewer, `ui/PhotoViewer.kt`) and files of any kind, up to 100 MB each. The editor's 3-dot menu has Attach file; files shared into the app from other apps are attached to a new scrap. A file is copied into `files/attachments/<id>/` and listed in the scrap's `files` column (`Attachments.kt` has the format); PDFs get a first-page thumbnail (`ui/Attachments.kt`, Android's own `PdfRenderer`). They are included in backups, searchable by file name, and cleaned up like photos when nothing uses them any more.

**Tags and filters:** a tag is a word on a scrap, independent of its box, so one tag can sit on scraps in any boxes (`Tags.kt`: tidying, counting, spelling and the card line). Tags are edited as pills in the editor's Details (`ui/TagEditor.kt`) and a tag in the editor header opens Search filtered to it. `Filters.kt` holds the one filter every list uses (type, box, tags, date; a scrap must pass all of them) and `ui/FilterSheet.kt` the Filter button and sheet; All scraps, boxes and Search each keep their own filter.

## Get it on your phone

**Easiest, no tools to install (GitHub):**
1. Create a GitHub repository and push this folder to it (branch `main`).
2. Do the one-time key setup in `SIGNING.md` (about 10 minutes). This is what lets every new version
   install over the old one without deleting the app.
3. Open the repo's **Actions** tab, open the latest **Android CI** run, and download the
   `scrapbook-release-apk` artifact (a zip containing `app-release.apk`).
4. Copy the APK to your phone and open it. Android will ask you to allow installing from that source.

**With Android Studio:** open this folder, let Gradle sync, plug in a phone (USB debugging on) or start an
emulator, and press Run.

**From a phone, with a zip:** keep one zip of the whole project at the top of the repo, plus
`.github/workflows/scrapbook-zip.yml`. Uploading a new zip starts **Scrapbook (from zip)**, which unpacks it and builds
the signed APK (same key setup, see `SIGNING.md`). If there is more than one zip, the one uploaded last is built.

`scrapbook-debug-apk` is also built and signed with the same key, but use the release one day to day.
**App icon:** a glass-pages icon in seven colors, one per accent (Coral, Teal, Amber, Violet, Green, Pink, Blue). The launcher entry is an
`<activity-alias>` per accent in `AndroidManifest.xml` (`.IconCoral` and so on); `AppIcon.kt` enables the one that matches the accent when the app
is left, and Settings has an "Icon matches accent" switch. To add an accent, add it to `Themes`, to `AppIcon.names`, and add an alias plus
`ic_launcher_<name>.xml` and `ic_launcher_bg_<name>.xml` (a unit test checks the lists agree).
**Motion:** `ui/Motion.kt` holds the small animation helpers (`pressScale`, `appear`); screen transitions are set on the `NavHost` in `MainActivity.kt`.

Fonts: see `FONTS.md`. Widget: long-press your home screen, Widgets, Scrapbook.

Search (`Search.kt`, `ui/Highlight.kt`): every typed word must appear somewhere in a scrap, in any order; matches are found in the original text (never a lowercased copy) so highlights cannot drift; results show a snippet around the first match. Used by the Search screen and the search bar inside a box.

Find in scrap (editor only): `FindInNote.kt` has the plain rules, `ui/FindBar.kt` the find bar, the back button that turns into a search button when held, and the highlight. Matches are searched in the shown text (without hidden marks), so they line up with what is drawn. Where it starts from is a setting (`findEntry`: hold back, 3-dot menu, or both).
