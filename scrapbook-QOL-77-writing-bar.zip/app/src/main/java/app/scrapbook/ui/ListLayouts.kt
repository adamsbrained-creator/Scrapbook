package app.scrapbook.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import java.util.Date

/**
 * How a page lists its scraps. The layout picker (top right of the list controls) switches between these, and Settings > Default view picks the one a page starts in.
 * To add a layout: add an entry here, an icon in Icons.kt, and a branch in [scrapLayout] below. The picker and the setting follow by themselves.
 * Grid is the old two-column view; it stays until the new layouts are all in.
 */
enum class ListLayout(val key: String, val label: String, val icon: String) {
    Cards("cards", "Cards", "l_cards"),
    Compact("compact", "Compact", "l_compact"),
    Timeline("timeline", "Timeline", "l_timeline"),
    Snippets("snippets", "Snippets", "l_snippets"),
    Stack("stack", "Stack", "l_stack"),
    Table("table", "Table", "l_table"),
    Sorted("sorted", "Sorted", "l_sorted"),
    Grid("grid", "Grid", "grid");

    companion object { fun of(key: String?): ListLayout = entries.firstOrNull { it.key == key } ?: Cards }
}

/** The color of a box's dot: the box's own color, the Inbox color, or grey for a scrap that is not in a box. */
@Composable
fun boxDotColor(collection: String): Color {
    val inbox = LocalInboxColor.current
    if (collection == "Inbox") return if (inbox < 0) TAB_GRAY else TAB_COLORS[inbox % TAB_COLORS.size]
    val shelf = LocalShelves.current.firstOrNull { it.name == collection } ?: return TAB_GRAY
    return TAB_COLORS[shelf.color % TAB_COLORS.size]
}

/**
 * Draws [shown] in the chosen [layout]. Used inside a LazyColumn by the All scraps page and by every box.
 * [sort] and [asc] are the page's sort settings; the Timeline layout groups by the date the page is sorted by.
 * [pickFor] gives the selection state of a scrap while picking, [onSelect] starts picking (long press).
 */
fun LazyListScope.scrapLayout(layout: ListLayout, shown: List<Item>, nav: NavController, terms: List<String>, sort: SortMode, asc: Boolean, pickFor: (Item) -> Pick?, onSelect: (Item) -> Unit) {
    when (layout) {
        ListLayout.Cards -> items(shown, key = { it.id }) { n -> NoteRow(n, nav, Modifier.animateItem(), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
        ListLayout.Compact -> items(shown, key = { it.id }) { n -> CompactRow(n, nav, Modifier.animateItem(), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
        ListLayout.Timeline -> timelineGroups(shown, sort, asc).forEach { (key, at, list) ->
            item(key = "day-$key") {
                Column(Modifier.fillMaxWidth()) {
                    Text(dayLabel(at).uppercase(), Modifier.padding(start = 4.dp, bottom = 12.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp, color = Sb.mute)
                    list.forEachIndexed { i, n -> TimelineEntry(n, nav, n.timelineAt(timelineField(sort)), i == list.lastIndex, pickFor(n), terms) { onSelect(n) } }
                }
            }
        }
        ListLayout.Snippets -> items(shown, key = { it.id }) { n -> SnippetRow(n, nav, Modifier.animateItem(), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
        ListLayout.Stack -> itemsIndexed(shown, key = { _, n -> n.id }) { i, n -> StackRow(n, nav, i == shown.lastIndex, Modifier.animateItem(), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
        ListLayout.Table -> {
            item(key = "table-head") { TableHead() }
            items(shown, key = { it.id }) { n -> TableRow(n, nav, Modifier.animateItem(), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
        }
        ListLayout.Sorted -> sortedSections(shown, sort).forEachIndexed { i, (label, list) ->
            item(key = "sec-$i-$label") { Text(label, Modifier.padding(start = 4.dp, top = if (i == 0) 0.dp else 8.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = .5.sp, color = Sb.mute) }
            items(list, key = { it.id }) { n ->
                val trailing = if (sort == SortMode.Title) LocalShelves.current.displayName(n.collection).ifBlank { "Inbox" } else fmtDate(n.timelineAt(timelineField(sort)), false)
                CompactRow(n, nav, Modifier.animateItem(), "Select scrap", pickFor(n), terms = terms, trailing = trailing) { onSelect(n) }
            }
        }
        ListLayout.Grid -> items(shown.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { n -> NoteTile(n, nav, Modifier.weight(1f), "Select scrap", pickFor(n), terms = terms) { onSelect(n) } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/**
 * Compact: every scrap in its own rounded container, on one line: the box's color dot, the title, the pin and the date.
 * It keeps the scrap's page color and accent edge, selection and search highlighting like the other layouts, and leaves out the preview, cover and photos.
 * [trailing] replaces the date on the right (the Sorted layout shows the box there).
 */
@Composable
fun CompactRow(n: Item, nav: NavController, modifier: Modifier = Modifier, holdLabel: String = "Delete scrap", pick: Pick? = null, terms: List<String> = emptyList(), trailing: String? = null, onHold: () -> Unit = {}) {
    val mark = LocalSb.current.acc.copy(alpha = .28f)
    val open = { nav.navigate("edit/${n.id}") }
    Row(modifier.appear("n${n.id}").pressScale(.98f).fillMaxWidth().heightIn(min = 60.dp).clip(RoundedCornerShape(22.dp)).selectMark(pick != null, pick?.selected == true, 22.dp)
        .background(Sb.card).background(pageTint(n.color) ?: Color.Transparent).accentEdge(n.accent)
        .tapOrHold(if (pick != null) "Select ${n.title}" else "Open ${n.title}", holdLabel, onHold, pick?.onToggle ?: open)
        .padding(horizontal = 20.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(boxDotColor(n.collection)))
        Text(hlTerms(n.displayTitle, terms, mark), Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (n.pinned) PinStar(14.dp, justTurnedOn(n.pinned))
        Text(trailing ?: fmtDate(n.savedAt, false), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
    }
}

private fun timelineField(sort: SortMode) = if (sort == SortMode.Created) TimelineField.Created else TimelineField.Edited

/**
 * Sorted: the scraps under headings that follow the page's sort. By title the headings are letters (# for numbers and symbols); by date edited or created
 * they are Today, Yesterday, Last 7 days and then months. Pinned scraps, which every sort puts first, get a "Pinned" heading. Each scrap is a Compact row.
 * [shown] is already in the sort order, so the sections are runs of neighbours that share a heading.
 */
private fun sortedSections(shown: List<Item>, sort: SortMode): List<Pair<String, List<Item>>> {
    val field = timelineField(sort); val now = System.currentTimeMillis()
    fun heading(n: Item): String = when {
        n.pinned -> "Pinned"
        sort == SortMode.Title -> n.title.trim().firstOrNull()?.takeIf { it.isLetter() }?.uppercaseChar()?.toString() ?: "#"
        else -> periodLabel(n.timelineAt(field), now)
    }
    val out = ArrayList<Pair<String, MutableList<Item>>>()
    for (n in shown) { val h = heading(n); if (out.isEmpty() || out.last().first != h) out.add(h to mutableListOf(n)) else out.last().second.add(n) }
    return out
}

private fun periodLabel(ms: Long, now: Long): String {
    val day = Fmt.of("yyyyMMdd"); val k = day.format(Date(ms))
    return when {
        k == day.format(Date(now)) -> "Today"
        k == day.format(Date(now - 86_400_000L)) -> "Yesterday"
        ms > now - 7 * 86_400_000L -> "Last 7 days"
        Fmt.of("yyyy").format(Date(ms)) == Fmt.of("yyyy").format(Date(now)) -> Fmt.of("MMMM").format(Date(ms))
        else -> Fmt.of("MMMM yyyy").format(Date(ms))
    }
}

/** The scraps split by day (the day of the date the page is sorted by), newest day first, or oldest first when the order is reversed. Title sorting groups by date edited. */
private fun timelineGroups(shown: List<Item>, sort: SortMode, asc: Boolean): List<Triple<String, Long, List<Item>>> {
    val field = timelineField(sort); val day = Fmt.of("yyyyMMdd")
    val groups = shown.groupBy { day.format(Date(it.timelineAt(field))) }.entries
    val ordered = if (sort != SortMode.Title && asc) groups.sortedBy { it.key } else groups.sortedByDescending { it.key }
    return ordered.map { e -> Triple(e.key, e.value.first().timelineAt(field), if (sort == SortMode.Title) e.value.sortedByDescending { it.timelineAt(field) } else e.value) }
}

/** "Today", "Yesterday", or "Sun, Oct 18" (with the year when it is not this year). */
private fun dayLabel(ms: Long): String {
    val now = System.currentTimeMillis(); val day = Fmt.of("yyyyMMdd"); val k = day.format(Date(ms))
    return when {
        k == day.format(Date(now)) -> "Today"
        k == day.format(Date(now - 86_400_000L)) -> "Yesterday"
        Fmt.of("yyyy").format(Date(ms)) == Fmt.of("yyyy").format(Date(now)) -> Fmt.of("EEE, MMM d").format(Date(ms))
        else -> Fmt.of("EEE, MMM d, yyyy").format(Date(ms))
    }
}

/**
 * Timeline: one scrap on a rail, the time on the left, a dot in the box's color, then the title with the pin and a line with the box and the start of the text.
 * Each day is one block under its heading. The scrap's page color shows as a soft background behind its text.
 */
@Composable
private fun TimelineEntry(n: Item, nav: NavController, at: Long, last: Boolean, pick: Pick?, terms: List<String>, onHold: () -> Unit) {
    val mark = LocalSb.current.acc.copy(alpha = .28f); val showPreview = LocalShowPreview.current
    val preview = remember(n.title, n.body, terms, showPreview) {
        if (!showPreview) "" else if (terms.isEmpty()) previewHead(n.title, n.body, 160) else snippet(cachedPreview(n.title, n.body), terms)
    }.replace('\n', ' ').trim()
    val box = LocalShelves.current.displayName(n.collection).ifBlank { "Inbox" }
    val open = { nav.navigate("edit/${n.id}") }
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).appear("n${n.id}"), Arrangement.spacedBy(12.dp)) {
        Text(Fmt.of("h:mm a").format(Date(at)), Modifier.width(60.dp).padding(top = 9.dp), textAlign = TextAlign.End, fontSize = 13.sp, color = Sb.mute)
        Column(Modifier.fillMaxHeight().padding(top = 11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(boxDotColor(n.collection)))
            if (!last) Box(Modifier.padding(top = 4.dp).width(2.dp).weight(1f).background(Sb.line))
        }
        Column(Modifier.weight(1f).padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).selectMark(pick != null, pick?.selected == true, 16.dp)
            .background(pageTint(n.color) ?: Color.Transparent)
            .tapOrHold(if (pick != null) "Select ${n.title}" else "Open ${n.title}", "Select scrap", onHold, pick?.onToggle ?: open)
            .padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(hlTerms(n.displayTitle, terms, mark), Modifier.weight(1f, fill = false), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (n.pinned) { Spacer(Modifier.width(8.dp)); PinStar(14.dp, justTurnedOn(n.pinned)) }
            }
            Text(hlTerms(if (preview.isBlank()) box else "$box · $preview", terms, mark), Modifier.padding(top = 2.dp), fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * Snippets: the text comes first, large, with the title as a small label above it and the box and date below.
 * A scrap with no text shows its title large instead. It keeps the card dressing of Cards: page color, accent edge, cover image, selection and search highlighting.
 */
@Composable
fun SnippetRow(n: Item, nav: NavController, modifier: Modifier = Modifier, holdLabel: String = "Delete scrap", pick: Pick? = null, terms: List<String> = emptyList(), onHold: () -> Unit = {}) {
    val mark = LocalSb.current.acc.copy(alpha = .28f); val showPreview = LocalShowPreview.current
    val preview = remember(n.title, n.body, terms, showPreview) {
        if (!showPreview) "" else if (terms.isEmpty()) previewHead(n.title, n.body, 240) else snippet(cachedPreview(n.title, n.body), terms)
    }.trim()
    val box = LocalShelves.current.displayName(n.collection).ifBlank { "Inbox" }
    val open = { nav.navigate("edit/${n.id}") }
    val coverH = 88.dp
    Column(modifier.appear("n${n.id}").pressScale(.98f).fillMaxWidth().clip(RoundedCornerShape(28.dp)).selectMark(pick != null, pick?.selected == true)
        .background(Sb.card).background(pageTint(n.color) ?: Color.Transparent).accentEdge(n.accent, if (n.cover != null) coverH else 0.dp)
        .tapOrHold(if (pick != null) "Select ${n.title}" else "Open ${n.title}", holdLabel, onHold, pick?.onToggle ?: open)) {
        if (n.cover != null) ItemImage(n.copy(imageUri = n.cover), Modifier.fillMaxWidth().height(coverH), 0.dp)
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(boxDotColor(n.collection)))
                Spacer(Modifier.width(8.dp))
                Text(hlTerms(if (preview.isBlank()) box else n.displayTitle, terms, mark), Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (n.pinned) PinStar(14.dp, justTurnedOn(n.pinned))
            }
            Text(hlTerms(preview.ifBlank { n.displayTitle }, terms, mark), Modifier.padding(top = 10.dp), fontSize = 20.sp, lineHeight = 27.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
            Text(if (preview.isBlank()) fmtDate(n.savedAt, true) else "$box · ${fmtDate(n.savedAt, false)}", Modifier.padding(top = 12.dp), fontSize = 12.sp, color = Sb.mute)
        }
    }
}

/** The start of a scrap's text for a one-line preview: what is searched around while searching, otherwise the head of the text. Empty when previews are off. */
@Composable
private fun scrapPreview(n: Item, terms: List<String>, limit: Int): String {
    val showPreview = LocalShowPreview.current
    return remember(n.title, n.body, terms, showPreview) {
        if (!showPreview) "" else if (terms.isEmpty()) previewHead(n.title, n.body, limit) else snippet(cachedPreview(n.title, n.body), terms)
    }.trim()
}

/** How tall a Stack card is, and how much of it the next card covers. The strip left showing is STACK_H - STACK_COVER, plus the list's 12dp gap. */
private val STACK_H = 112.dp
private val STACK_COVER = 60.dp

/**
 * Stack: the cards overlap like a pile, each showing only its top strip (box, date and title) with the next card lying over the rest. The last card is shown whole.
 * The cards keep their keys and slide with animateItem, so changing from another layout shifts them into the pile. A card's height is reported shorter, so the list overlaps them by itself.
 */
@Composable
fun StackRow(n: Item, nav: NavController, last: Boolean, modifier: Modifier = Modifier, holdLabel: String = "Delete scrap", pick: Pick? = null, terms: List<String> = emptyList(), onHold: () -> Unit = {}) {
    val mark = LocalSb.current.acc.copy(alpha = .28f)
    val preview = scrapPreview(n, terms, 160)
    val box = LocalShelves.current.displayName(n.collection).ifBlank { "Inbox" }
    val open = { nav.navigate("edit/${n.id}") }
    val shape = RoundedCornerShape(24.dp)
    Column(modifier.appear("n${n.id}").layout { m, c ->
        val p = m.measure(c); val cut = if (last) 0 else STACK_COVER.roundToPx()
        layout(p.width, p.height - cut) { p.place(0, 0) }
    }.fillMaxWidth().heightIn(min = STACK_H).shadow(8.dp, shape).clip(shape).selectMark(pick != null, pick?.selected == true, 24.dp)
        .background(Sb.card).background(pageTint(n.color) ?: Color.Transparent).accentEdge(n.accent)
        .tapOrHold(if (pick != null) "Select ${n.title}" else "Open ${n.title}", holdLabel, onHold, pick?.onToggle ?: open)
        .padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(boxDotColor(n.collection)))
            Spacer(Modifier.width(8.dp))
            Text(box, Modifier.weight(1f), fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(fmtDate(n.savedAt, false), fontSize = 12.sp, color = Sb.mute)
        }
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(hlTerms(n.displayTitle, terms, mark), Modifier.weight(1f, fill = false), fontFamily = headFont(), fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n.pinned) { Spacer(Modifier.width(8.dp)); PinStar(16.dp, justTurnedOn(n.pinned)) }
        }
        if (preview.isNotBlank()) Text(hlTerms(preview, terms, mark), fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

private val TABLE_BOX = 92.dp
private val TABLE_DATE = 64.dp

/** The column names above the Table layout, lined up with the columns of [TableRow]. */
@Composable
private fun TableHead() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
        listOf("Title" to Modifier.weight(1f), "Box" to Modifier.width(TABLE_BOX), "Date" to Modifier.width(TABLE_DATE)).forEachIndexed { i, (label, m) ->
            Text(label.uppercase(), m, fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp, color = Sb.mute, textAlign = if (i == 2) TextAlign.End else TextAlign.Start)
        }
    }
}

/**
 * Table: every scrap in its own rounded container, laid out in columns: the title with its pin, the box (color dot and name) and the date.
 * It keeps the scrap's page color and accent edge, selection and search highlighting, and leaves out the preview, cover and photos.
 */
@Composable
fun TableRow(n: Item, nav: NavController, modifier: Modifier = Modifier, holdLabel: String = "Delete scrap", pick: Pick? = null, terms: List<String> = emptyList(), onHold: () -> Unit = {}) {
    val mark = LocalSb.current.acc.copy(alpha = .28f)
    val box = LocalShelves.current.displayName(n.collection).ifBlank { "Inbox" }
    val open = { nav.navigate("edit/${n.id}") }
    Row(modifier.appear("n${n.id}").pressScale(.98f).fillMaxWidth().heightIn(min = 60.dp).clip(RoundedCornerShape(22.dp)).selectMark(pick != null, pick?.selected == true, 22.dp)
        .background(Sb.card).background(pageTint(n.color) ?: Color.Transparent).accentEdge(n.accent)
        .tapOrHold(if (pick != null) "Select ${n.title}" else "Open ${n.title}", holdLabel, onHold, pick?.onToggle ?: open)
        .padding(horizontal = 20.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Text(hlTerms(n.displayTitle, terms, mark), Modifier.weight(1f, fill = false), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n.pinned) { Spacer(Modifier.width(6.dp)); PinStar(14.dp, justTurnedOn(n.pinned)) }
        }
        Row(Modifier.width(TABLE_BOX), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(boxDotColor(n.collection)))
            Spacer(Modifier.width(6.dp))
            Text(box, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(fmtDate(n.savedAt, false), Modifier.width(TABLE_DATE), fontSize = 13.sp, color = Sb.mute, textAlign = TextAlign.End, maxLines = 1)
    }
}

/**
 * The layout picker: a pill with the current layout's icon and a chevron. Tapping it opens a small floating menu under it
 * (icon, name, a dot on the current one), in the style of the main menu in Paperback but narrower.
 */
@Composable
fun LayoutPicker(current: ListLayout, onPick: (ListLayout) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val bg by animateColorAsState(if (open) LocalSb.current.tint else Sb.card, tween(150), label = "layoutPill")
    Box {
        Row(Modifier.height(44.dp).clip(CircleShape).background(bg).tap("Change layout, now ${current.label}") { open = true }.padding(start = 14.dp, end = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Ic(current.icon, 22.dp, Sb.ink); Ic("chevdown", 18.dp, Sb.mute)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.width(200.dp),
            shape = RoundedCornerShape(30.dp), containerColor = Sb.card, tonalElevation = 0.dp, shadowElevation = 18.dp, border = BorderStroke(1.dp, Sb.menuLine)) {
            ListLayout.entries.forEach { l -> LayoutRow(l, l == current) { open = false; onPick(l) } }
        }
    }
}

@Composable
private fun LayoutRow(l: ListLayout, selected: Boolean, onClick: () -> Unit) {
    val sans = LocalFonts.current.second
    val bg by animateColorAsState(if (selected) Sb.line else Color.Transparent, tween(150), label = "layoutRow")
    Row(Modifier.pressScale(.97f).fillMaxWidth().padding(horizontal = 6.dp).height(52.dp).clip(RoundedCornerShape(26.dp)).background(bg).tap(l.label, onClick).padding(horizontal = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic(l.icon, 22.dp, Sb.ink)
        Text(l.label, Modifier.weight(1f), fontFamily = sans, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
        if (selected) Box(Modifier.size(9.dp).clip(CircleShape).background(LocalSb.current.acc))
    }
}
