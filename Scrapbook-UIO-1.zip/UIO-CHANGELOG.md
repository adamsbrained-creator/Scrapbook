Scrapbook — UI Overhaul (UIO) Development Log

Project: Scrapbook
Milestone: UI Overhaul (UIO)
Status: In progress
Base: Quality of Life update (scrapbook-QOL-88)

Goal: a complete overhaul of the app's look, with more customization, built section by section.
Entries are added in the order they are built. Each one says what the feature is for and what was built.

———

Section: Home

☑ 1. New greeting: account system (Scrapbook-UIO-1)
   For: the greeting needs to know who it is talking to, and the app needs a place for the person behind it.
   Built: an Account with name, nickname, a line about you, pronouns, birthday (no year) and a profile picture (photo, or initial on a chosen color).
   Stored only on this phone. New Account page, an account card at the top of Settings, a profile icon, picture cropping and saving (Avatar.kt).

☑ 2. More greeting options and views: greeting lines and settings (Scrapbook-UIO-1)
   For: a greeting that feels alive instead of the same line every day.
   Built: 170+ greetings across time of day (late night to night), weekdays, casual lines, lines about your scraps (Inbox, pinned, empty, large archive)
   and birthday / New Year's Day lines, in friendly, playful and calm voices. {name} drops out neatly when no name is set. The greeting changes by itself
   (never, 10, 20, 40 or 90 seconds), on every tap, and avoids repeating recent lines. New Settings > Greeting page: show or hide, show my picture,
   line under the greeting (date, about me, scrap count, nothing), change interval, tone, and switches for time-of-day, casual and scrap-related lines.
   The greeting on Home now uses the account's name and picture; tapping the picture opens the Account page.
