package app.scrapbook

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Layout(val label: String) {
    Classic("Classic"), Journal("Journal"), Gallery("Gallery"), TwoColumn("Two Column"),
    Quote("Quote"), Reference("Reference"), Collection("Box"), Blank("Blank Canvas")
}

enum class Kind { Note, Image, Quote, Link, Voice }

/** Content lives on the item; layout is only a view of it, so switching layouts never loses anything. */
@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val body: String, val kind: Kind, val collection: String,
    val tags: List<String> = emptyList(), val layout: Layout = Layout.Classic,
    val color: Int = 0, val pinned: Boolean = false, val savedAt: Long = System.currentTimeMillis(),
    val font: Int = 0, val density: Int = 1, val showMeta: Boolean = true,
    val imageUri: String? = null,
    val canvas: String = "",
    val source: String = "",
    val images: String = "",
    val accent: Int = 0, val cover: String? = null,
    /** 0 = a normal scrap. Otherwise the time it was deleted: it sits in the Bin until it is restored or BIN_DAYS have passed. */
    val deletedAt: Long = 0,
    /** When the scrap was first made. savedAt moves on every edit; this never does. Scraps from before this existed carry their earliest known date. */
    val createdAt: Long = System.currentTimeMillis(),
    /** One optional emoji (or other single character) shown in front of the title. "" = none. */
    val icon: String = "",
)

/** An earlier text of a scrap (title and body), kept so a note can be taken back to how it was. savedAt is when that text was written, takenAt when it was put aside. */
@Entity(tableName = "item_versions")
data class ItemVersion(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long, val takenAt: Long, val savedAt: Long, val title: String, val body: String,
)

/** A user-made collection. Notes join it by name (Item.collection). "Inbox" and "All" are built in. A box can sit inside another box: parent is that box's name ("" = main page). */
@Entity(tableName = "collections")
data class Shelf(@PrimaryKey val name: String, val description: String = "", val color: Int = 0, val coverUri: String? = null, val parent: String = "")

fun itemsLabel(n: Int) = if (n == 1) "1 item" else "$n items"

/** Main image first, then any extra images added to the note. */
fun Item.allImages(): List<String> = listOfNotNull(imageUri) + images.split("\n").filter { it.isNotBlank() }

/** What a type is called on screen: a plain note is a "Scrap". */
val Kind.label: String get() = if (this == Kind.Note) "Scrap" else name

/** Boxes that show on the main page: no parent, or a parent that no longer exists (so nothing can get lost). */
fun List<Shelf>.topLevel(): List<Shelf> { val names = map { it.name }.toSet(); return filter { it.parent.isBlank() || it.parent !in names } }

/** The boxes directly inside the box called name. */
fun List<Shelf>.childrenOf(name: String): List<Shelf> = filter { it.parent == name && it.name != name }

/** Every box inside name, at any depth (not including name itself). */
fun List<Shelf>.descendantsOf(name: String): List<Shelf> {
    val out = mutableListOf<Shelf>(); val seen = mutableSetOf(name); val queue = ArrayDeque(listOf(name))
    while (queue.isNotEmpty()) { val n = queue.removeFirst(); childrenOf(n).forEach { if (seen.add(it.name)) { out += it; queue += it.name } } }
    return out
}

/** Every box in reading order for the Shelf view: each main-page box, then the boxes inside it (and inside those), with how deep each one sits (0 = main page). Nothing is ever left out. */
fun List<Shelf>.inTreeOrder(): List<Pair<Shelf, Int>> {
    val out = mutableListOf<Pair<Shelf, Int>>(); val seen = mutableSetOf<String>()
    fun walk(s: Shelf, depth: Int) {
        if (!seen.add(s.name)) return
        out += s to depth
        childrenOf(s.name).forEach { walk(it, depth + 1) }
    }
    topLevel().forEach { walk(it, 0) }
    forEach { walk(it, 0) }
    return out
}

/** What a list of scraps can be sorted by. The order of this list is the order the pickers show. */
enum class SortMode(val label: String, val short: String) { Edited("Date edited", "Edited"), Created("Date created", "Created"), Title("Title", "Title") }

/** The natural direction for a field: newest first for dates, A to Z for titles. `asc` below means oldest first or A to Z. */
val SortMode.naturalAsc: Boolean get() = this == SortMode.Title

/** Sorted by [mode], reversed unless [asc], and pinned scraps always first (the order inside each group is kept). */
fun List<Item>.sortedFor(mode: SortMode, asc: Boolean): List<Item> {
    val base = when (mode) {
        SortMode.Title -> sortedBy { it.title.lowercase() }
        SortMode.Created -> sortedBy { it.createdAt }
        SortMode.Edited -> sortedBy { it.savedAt }
    }
    return (if (asc) base else base.reversed()).sortedByDescending { it.pinned }
}

/** The title as it shows in lists and headers: the icon, if there is one, then the title. */
val Item.displayTitle: String get() = if (icon.isBlank()) title else "$icon $title".trim()

/** The first thing a person would call one character of [s]: an emoji with its modifiers counts as one. "" for an empty string. */
fun firstGlyph(s: String): String {
    if (s.isEmpty()) return ""
    val bi = java.text.BreakIterator.getCharacterInstance(); bi.setText(s)
    val end = bi.next()
    return s.substring(0, if (end == java.text.BreakIterator.DONE) s.length else end)
}
