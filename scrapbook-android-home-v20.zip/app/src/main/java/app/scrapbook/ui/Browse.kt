package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlin.math.roundToInt

private const val FOLD = 40f
private val FoldShape = GenericShape { s, _ ->
    moveTo(0f, 0f); lineTo(s.width, 0f); lineTo(s.width, s.height - FOLD); lineTo(s.width - FOLD, s.height); lineTo(0f, s.height); close()
}

/** Sticky note with a flat folded corner. */
@Composable
fun Sticky(item: Item, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(FoldShape).background(Sb.notes[item.color % 5])
        .drawWithContent {
            drawContent()
            val p = Path().apply { moveTo(size.width - FOLD, size.height - FOLD); lineTo(size.width, size.height - FOLD); lineTo(size.width - FOLD, size.height); close() }
            drawPath(p, Color(0x22000000))
        }.tap(onClick = onClick).padding(start = 10.dp, top = 10.dp, end = 10.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (item.kind == Kind.Image) ItemImage(item, Modifier.fillMaxWidth().height(70.dp), 8.dp)
        Text(item.displayTitle, fontFamily = headFont(), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(plainPreview(item.body), fontSize = 10.5.sp, lineHeight = 14.sp, maxLines = 6, color = Sb.ink.copy(alpha = .75f))
    }
}

/** A small pill that opens a menu: the current choice and a chevron. */
@Composable
private fun FilterPill(text: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.height(44.dp).clip(CircleShape).background(Sb.card).tap(desc, onClick).padding(start = 16.dp, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium); Spacer(Modifier.width(2.dp)); Ic("chevdown", 18.dp, Sb.mute)
    }
}

/** A collection (or "All" / "Inbox"): title and count, search inside it, filters, then its notes. */
@Composable
fun ShelfScreen(vm: ArchiveViewModel, nav: NavController, name: String) {
    val t = LocalSb.current; val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    val shelf = shelves.firstOrNull { it.name == name }
    val navStyle by vm.navStyle.collectAsState(); var menuSheet by remember { mutableStateOf(false) }; val showSearch by vm.showBoxSearch.collectAsState()
    var editing by remember { mutableStateOf(false) }; var inboxSheet by remember { mutableStateOf(false) }; var existed by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }; var creatingSub by remember { mutableStateOf(false) }; var deletingSub by remember { mutableStateOf<String?>(null) }
    var deletingScrap by remember { mutableStateOf<Item?>(null) }; val deleted by vm.deleted.collectAsState(); val snack = remember { SnackbarHostState() }
    var q by remember { mutableStateOf("") }; var kind by remember { mutableStateOf<Kind?>(null) }
    var kindMenu by remember { mutableStateOf(false) }; var sortMenu by remember { mutableStateOf(false) }; var more by remember { mutableStateOf(false) }
    val sortMode by vm.sortMode.collectAsState(); val sortAsc by vm.sortAsc.collectAsState(); var grid by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(shelf) { if (shelf != null) existed = true else if (existed) nav.popBackStack() }
    LaunchedEffect(deleted) {
        if (deleted != null) { val r = snack.showSnackbar("Scrap deleted", "Undo", duration = SnackbarDuration.Long); if (r == SnackbarResult.ActionPerformed) vm.undoDelete() else vm.clearDeleted() }
    }
    val subs = if (shelf != null) shelves.childrenOf(name) else emptyList()
    val inShelf = all.filter { name == "All" || (name == "Pinned" && it.pinned) || (name == "Recent" && it.savedAt > System.currentTimeMillis() - 7L * 86_400_000L) || it.collection == name }
    val query = if (showSearch) q else ""
    val shown = inShelf.filter { n -> (kind == null || n.kind == kind) && (query.isBlank() || listOf(n.title, n.body, n.tags.joinToString(" ")).any { it.contains(query, true) }) }
        .sortedFor(sortMode, sortAsc)
    // Selection toolbar: long-press a scrap to start picking (see Selecting.kt). Picks that leave the list (filtered out, moved, deleted) drop out by themselves.
    var picked by rememberSaveable { mutableStateOf(emptyList<Long>()) }
    var batchSheet by remember { mutableIntStateOf(0) }   // 0 none, 1 Add to box, 2 Tags
    val scope = rememberCoroutineScope()
    val selecting = picked.isNotEmpty(); val shownIds = shown.map { it.id }; val chosen = shown.filter { it.id in picked }
    fun pickFor(n: Item): Pick? = if (selecting) Pick(n.id in picked) { picked = picked.toggled(n.id) } else null
    LaunchedEffect(shownIds) { picked = picked.stillShown(shownIds) }
    BackHandler(enabled = selecting) { picked = emptyList() }

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.paper, snackbarHost = { SnackbarHost(snack) { d -> SwipeAway({ d.dismiss() }) { Snackbar(d, shape = RoundedCornerShape(20.dp), containerColor = Sb.ink, contentColor = Sb.card, actionColor = t.acc) } } }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        if (selecting) SelectionHeader(chosen.size, shownIds.size, { picked = emptyList() }, { picked = if (chosen.size >= shownIds.size) emptyList() else shownIds }) else
                        ScreenHeader({ nav.popBackStack() }, pad = 2.dp, trailing = {
                            Box {
                                CircleBtn("More options", { more = true }) { Ic("more", 22.dp, Sb.ink) }
                                PopupMenu(more, { more = false }) {
                                    if (shelf != null) PopupItem("New box inside", "plus") { more = false; creatingSub = true }
                                    if (shelf != null) PopupItem("Edit box", "edit") { more = false; editing = true }
                                    if (name == "Inbox") PopupItem("Sort Inbox", "check") { more = false; nav.navigate("sort") }
                                    if (name == "Inbox") PopupItem("Change color", "palette") { more = false; inboxSheet = true }
                                    PopupItem(if (showSearch) "Hide search bar" else "Show search bar", "search") { more = false; vm.setShowBoxSearch(!showSearch) }
                                    PopupItem("All boxes", "folder") { more = false; nav.navigate("collections") }
                                    if (shelf != null || name == "Inbox") {
                                        PopupDivider()
                                        PopupItem(if (name == "Inbox") "Remove Inbox" else "Delete box", "trash", tint = Sb.danger) { more = false; deleting = true }
                                    }
                                }
                            }
                        })
                    }
                    item {
                        Column {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(name, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 36.sp, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                                Text("  " + (if (inShelf.size == 1) "1 scrap" else "${inShelf.size} scraps"), fontSize = 14.sp, color = Sb.mute, modifier = Modifier.padding(bottom = 7.dp))
                            }
                            if (shelf != null && shelf.parent.isNotBlank()) Text("in ${shelf.parent}", fontSize = 14.sp, color = Sb.mute, modifier = Modifier.padding(top = 2.dp))
                            if (shelf != null && shelf.description.isNotBlank()) Text(shelf.description, fontSize = 14.sp, color = Sb.mute, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                    if (shelf?.coverUri != null) item {
                        ItemImage(Item(title = "", body = "", kind = Kind.Image, collection = "", imageUri = shelf.coverUri, color = shelf.color), Modifier.fillMaxWidth().height(120.dp), 24.dp)
                    }
                    if (shelf != null) item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            BoxGrid(subs.map { BoxTile(it.name, all.count { n -> n.collection == it.name }, TAB_COLORS[it.color % TAB_COLORS.size]) },
                                onHold = { deletingSub = it }, onNew = { creatingSub = true }) { nav.navigate("shelf/$it") }
                            // Chips and Notebook covers draw their own dashed "New box" button inside the grid.
                            if (LocalBoxStyle.current != 4 && LocalBoxStyle.current != 6) NewBoxPill("New box inside") { creatingSub = true }
                        }
                    }
                    if (showSearch) item {
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Ic("search", 22.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                            BasicTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(t.acc),
                                decorationBox = { inner -> Box { if (q.isEmpty()) Text("Search in $name", color = Sb.mute, fontSize = 16.sp); inner() } })
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box {
                                    FilterPill(kind?.let { it.label + "s" } ?: "All scraps", "Filter by type") { kindMenu = true }
                                    PopupMenu(kindMenu, { kindMenu = false }) {
                                        PopupItem("All scraps", checked = kind == null) { kindMenu = false; kind = null }
                                        Kind.entries.forEach { k -> PopupItem(k.label + "s", checked = kind == k) { kindMenu = false; kind = k } }
                                    }
                                }
                                Box {
                                    FilterPill(sortMode.short, "Change sort order") { sortMenu = true }
                                    PopupMenu(sortMenu, { sortMenu = false }) {
                                        PopupItem("Date edited", "clock", checked = sortMode == SortMode.Edited) { sortMenu = false; vm.setSort(SortMode.Edited) }
                                        PopupItem("Date created", "newfile", checked = sortMode == SortMode.Created) { sortMenu = false; vm.setSort(SortMode.Created) }
                                        PopupItem("Title", "sort", checked = sortMode == SortMode.Title) { sortMenu = false; vm.setSort(SortMode.Title) }
                                        PopupItem("Reverse order", if (sortAsc) "up" else "down", sub = if (sortMode == SortMode.Title) (if (sortAsc) "A to Z" else "Z to A") else (if (sortAsc) "Oldest first" else "Newest first")) { sortMenu = false; vm.setSortAsc(!sortAsc) }
                                    }
                                }
                            }
                            Row(Modifier.clip(RoundedCornerShape(26.dp)).background(Sb.line.copy(alpha = .6f)).padding(4.dp)) {
                                SegIcon("list", !grid) { grid = false }; SegIcon("grid", grid) { grid = true }
                            }
                        }
                    }
                    if (shown.isEmpty()) item { Text(if (query.isNotBlank() || kind != null) "Nothing matches." else (if (navStyle == 1) "Nothing here yet. Hold the menu button to add the first one." else "Nothing here yet. Tap New scrap to add the first one."), color = Sb.mute, fontSize = 15.sp, modifier = Modifier.padding(vertical = 30.dp)) }
                    else if (grid) items(shown.chunked(2)) { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            pair.forEach { n -> NoteTile(n, nav, Modifier.weight(1f), "Select scrap", pickFor(n)) { picked = picked.added(n.id) } }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    } else items(shown, key = { it.id }) { n -> NoteRow(n, nav, Modifier.animateItem(), "Select scrap", pickFor(n)) { picked = picked.added(n.id) } }
                }
                val addScrap = { vm.pendingShelf = if (shelf != null) name else null; nav.navigate("edit/0") }
                if (selecting) SelectionBar(Modifier.align(Alignment.BottomCenter), allPinned(chosen), { batchSheet = 1 },
                    { batchPin(vm, chosen, scope, snack); picked = emptyList() }, { batchSheet = 2 }, { batchDelete(vm, chosen, scope, snack); picked = emptyList() })
                else if (navStyle == 1) BottomNav(Modifier.matchParentSize(), { menuSheet = true }, addScrap)
                else NewScrapPill(Modifier.align(Alignment.BottomEnd), addScrap)
            }
        }
        if (editing && shelf != null) ShelfSheet(vm, shelf, onDone = { editing = false })
        if (creatingSub && shelf != null) ShelfSheet(vm, null, { creatingSub = false }, parent = name)
        deletingSub?.let { n -> DeleteBoxSheet(n, vm, { deletingSub = null }) }
        deletingScrap?.let { n -> DeleteScrapSheet(n, vm) { deletingScrap = null } }
        if (batchSheet == 1) PickBoxSheet(vm, { box -> batchMove(vm, chosen, box, scope, snack); picked = emptyList() }, { batchSheet = 0 }, withInbox = true, subtitle = scrapsLabel(chosen.size))
        if (batchSheet == 2) AddTagsSheet(vm, chosen.size, { tags -> batchTag(vm, chosen, tags, scope, snack); picked = emptyList() }, { batchSheet = 0 })
        if (inboxSheet) InboxSheet(vm) { inboxSheet = false }
        if (deleting) DeleteBoxSheet(name, vm, { deleting = false }) { if (name == "Inbox") nav.popBackStack() }
        if (menuSheet) MenuSheet(nav, { menuSheet = false }) { vm.pendingShelf = null }
    }
}

private fun hl(text: String, q: String, mark: Color): AnnotatedString = buildAnnotatedString {
    if (q.isBlank()) { append(text); return@buildAnnotatedString }
    val lo = text.lowercase(); val ql = q.lowercase(); var i = 0
    while (true) {
        val j = lo.indexOf(ql, i)
        if (j < 0) { append(text.substring(i)); break }
        append(text.substring(i, j)); withStyle(SpanStyle(background = mark)) { append(text.substring(j, j + q.length)) }; i = j + q.length
    }
}

/** Search across titles, text, tags and collections, with type filters and highlighted matches. */
@Composable
fun SearchScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    var q by remember { mutableStateOf("") }; var kind by remember { mutableStateOf<Kind?>(null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    val res = all.filter { n -> (kind == null || n.kind == kind) && (q.isBlank() || listOf(n.title, n.body, n.collection, n.tags.joinToString(" ")).any { it.contains(q, true) }) }
        .sortedByDescending { it.savedAt }
    val shelfHits = if (q.isBlank()) emptyList() else shelves.filter { it.name.contains(q, true) || it.description.contains(q, true) }
    val mark = t.acc.copy(alpha = .28f)
    Scaffold(containerColor = t.paper) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                CircleBtn("Go back", { nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
                Spacer(Modifier.width(8.dp))
                Row(Modifier.weight(1f).height(44.dp).clip(CircleShape).background(Sb.card).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ic("search", 22.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                    BasicTextField(q, { q = it }, Modifier.weight(1f).focusRequester(focus), singleLine = true, textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(t.acc),
                        decorationBox = { inner -> Box { if (q.isEmpty()) Text("Search scraps, tags, boxes", color = Sb.mute, fontSize = 16.sp); inner() } })
                    if (q.isNotEmpty()) Box(Modifier.size(32.dp).tap("Clear search") { q = "" }, Alignment.Center) { Ic("close", 18.dp, Sb.mute) }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), Arrangement.spacedBy(8.dp)) {
                Chip("All", kind == null) { kind = null }
                Kind.entries.forEach { k -> Chip(k.label + "s", kind == k) { kind = k } }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (shelfHits.isNotEmpty()) item {
                    Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                        Text("Boxes", fontSize = 13.sp, color = Sb.mute)
                        shelfHits.forEach { s -> Chip(s.name) { nav.navigate("shelf/${s.name}") } }
                    }
                }
                item { Text(if (res.size == 1) "1 result" else "${res.size} results", fontSize = 13.sp, color = Sb.mute) }
                items(res, key = { it.id }) { n ->
                    Column(Modifier.animateItem().fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Open ${n.title}") { nav.navigate("edit/${n.id}") }.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(hl(n.displayTitle, q, mark), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 18.sp)
                        Text(hl(plainPreview(bodyWithoutTitle(n.title, n.body)), q, mark), fontSize = 14.sp, color = Sb.mute, maxLines = 2)
                        Text("${n.collection} · ${n.kind.label}", fontSize = 12.sp, color = Sb.mute, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

private fun ago(ms: Long): String {
    val d = (System.currentTimeMillis() - ms) / 86_400_000L
    return when { d < 1 -> "today"; d < 30 -> "$d days ago"; else -> "${d / 30} months ago" }
}

/** Swipe through old finds: right keeps one close (pins it), left lets it rest. No notifications, no pressure. */
@Composable
fun RediscoverScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val all by vm.items.collectAsState()
    val queue = remember(all.isNotEmpty()) { all.sortedBy { it.createdAt } }
    var i by remember { mutableIntStateOf(0) }; var x by remember { mutableFloatStateOf(0f) }
    fun next(keep: Boolean) { queue.getOrNull(i)?.let { if (keep && !it.pinned) vm.togglePin(it) }; i++; x = 0f }
    val cur = queue.getOrNull(i)
    Scaffold(containerColor = t.paper) { pad ->
        Column(Modifier.padding(pad).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            ScreenHeader({ nav.popBackStack() }, title = "From your archive", backIcon = "close", backDesc = "Close")
            if (queue.isNotEmpty()) Text("${minOf(i + 1, queue.size)} of ${queue.size}", Modifier.padding(top = 14.dp).clip(CircleShape).background(Sb.card).padding(horizontal = 14.dp, vertical = 6.dp), fontSize = 13.sp, color = Sb.mute)
            Spacer(Modifier.height(24.dp))
            if (cur == null) Text(if (queue.isEmpty()) "Nothing saved yet. Old scraps will show up here." else "That's everything for now.", fontFamily = headFont(), fontSize = 20.sp,
                textAlign = TextAlign.Center, modifier = Modifier.padding(top = 80.dp))
            else Box(Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(330.dp)) {
                Box(Modifier.matchParentSize().padding(horizontal = 10.dp).rotate(-5f).clip(RoundedCornerShape(32.dp)).background(Sb.line))
                Box(Modifier.matchParentSize().padding(horizontal = 10.dp).rotate(4f).clip(RoundedCornerShape(32.dp)).background(Sb.line.copy(alpha = .6f)))
                Column(Modifier.matchParentSize().offset { IntOffset(x.roundToInt(), 0) }.rotate(x / 25f).shadow(8.dp, RoundedCornerShape(32.dp)).clip(RoundedCornerShape(32.dp)).background(Sb.card)
                    .pointerInput(i) { detectDragGestures(onDragEnd = { if (x > 200f) next(true) else if (x < -200f) next(false) else x = 0f }) { c, d -> c.consume(); x += d.x } }
                    .padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${cur.collection} · ${cur.kind.label}", fontSize = 13.sp, color = Sb.mute)
                    Text(cur.displayTitle, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 26.sp, lineHeight = 30.sp)
                    Text(plainPreview(bodyWithoutTitle(cur.title, cur.body), "\n"), fontFamily = headFont(), fontSize = 16.sp, lineHeight = 24.sp, color = Sb.ink.copy(alpha = .8f), maxLines = 8)
                }
            }
            if (cur != null) {
                Text("You saved this ${ago(cur.createdAt)}.", fontSize = 15.sp, color = Sb.mute, modifier = Modifier.padding(top = 24.dp))
                Row(Modifier.padding(top = 18.dp), Arrangement.spacedBy(36.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(Sb.card).tap("Let it rest") { next(false) }, Alignment.Center) { Ic("close", 26.dp, Sb.ink) }
                        Text("Let it rest", fontSize = 12.sp, color = Sb.mute)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(Sb.ink).tap("Keep close") { next(true) }, Alignment.Center) { Ic("check", 28.dp, Sb.card) }
                        Text("Keep close", fontSize = 12.sp, color = Sb.mute)
                    }
                }
            }
        }
    }
}
