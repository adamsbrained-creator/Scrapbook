package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import kotlin.math.sqrt
import java.io.File
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.Lifecycle
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.Crossfade
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.provider.Settings
import android.net.Uri
import android.content.pm.PackageManager
import android.content.Intent
import android.Manifest
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.layout.Layout as ComposeLayout
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.draw.clipToBounds
import kotlin.math.abs
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.draw.drawBehind
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.ui.layout.layout
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.delay

// The ways to add a scrap and reach the menu from the main pages (Settings > Add button). 0 Pill and 1 Bottom bar live in Home.kt; the newer ones are here:
// 2 Writing bar (a slim pill that opens into a small composer: type, pick a box and tags, send), 3 One button with an arc, 4 Swipe-up sheet.

/** How far the list needs to stay clear of the bottom so its last scrap is not hidden under the add control. */
fun navClearance(style: Int, normal: Dp): Dp = if (style == 2) 140.dp else normal

/**
 * Draws the add control the Settings choice asks for, inside the screen's Box. [box] is where a scrap written here is filed (the box on screen, Inbox on the
 * main pages); [onMenu] opens the menu sheet and [onAdd] opens an empty editor in that box.
 */
@Composable
fun BoxScope.AddNav(style: Int, vm: ArchiveViewModel, nav: NavController, box: String, onMenu: () -> Unit, onAdd: () -> Unit) {
    when (style) {
        1 -> BottomNav(Modifier.matchParentSize(), onMenu, onAdd)
        2 -> WriteBar(vm, nav, box)
        3 -> ArcButton(vm, nav, box, onMenu, onAdd)
        4 -> SwipeSheet(vm, nav, box, onMenu, onAdd)
        else -> NewScrapPill(Modifier.align(Alignment.BottomEnd), onAdd)
    }
}

/** Where a scrap from the writing bar goes: Inbox, or any box. */
@Composable
private fun BoxPickSheet(current: String, vm: ArchiveViewModel, onPick: (String) -> Unit, onDone: () -> Unit) = Sheet("Save to", onDone, doneLabel = "Cancel", soft = true) {
    val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    SheetGroup {
        OptionRow("Inbox", current == "Inbox", dot = if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) { onPick("Inbox"); onDone() }
        BoxTreeRows(shelves, current) { s -> onPick(s.name); onDone() }
    }
    if (shelves.isEmpty()) SheetNote("No boxes yet. Create one from the Boxes screen.")
}

/** A pill in the resting bar: drawn 34dp tall so the bar can be slim, but its touch area is the whole 40dp row. */
@Composable
private fun BarPill(desc: String, color: Color, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    Box(Modifier.pressScale(.96f).heightIn(min = 40.dp).clip(CircleShape).tap(desc, onClick), Alignment.Center) {
        Row(Modifier.heightIn(min = 34.dp).clip(CircleShape).background(color).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp), content = content)
    }
}

/** A floating pill above the bar while a voice memo is being made: a raised soft pill, or the accent one for the main choice. */
@Composable
private fun FloatPill(icon: String, label: String, primary: Boolean = false, onClick: () -> Unit) {
    val t = LocalSb.current
    val onAcc = Color.White
    Row(Modifier.pressScale(.95f).shadow(8.dp, CircleShape).clip(CircleShape).background(if (primary) t.acc else Sb.raised)
        .border(1.dp, if (primary) Color.Transparent else Sb.line, CircleShape).heightIn(min = 40.dp).tap(label, onClick).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Ic(icon, 18.dp, if (primary) onAcc else Sb.ink)
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (primary) onAcc else Sb.ink, maxLines = 1)
    }
}

/** The soft blinking dot that says the microphone is on. */
@Composable
private fun PulseDot(color: Color) {
    val a by rememberInfiniteTransition(label = "recording").animateFloat(.35f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "recordingDot")
    Box(Modifier.size(12.dp).graphicsLayer { alpha = a }.background(color, CircleShape))
}

/** The running time of a recording. [ms] is read here, so only this small piece redraws every tenth of a second. */
@Composable
private fun RecTime(ms: () -> Long, color: Color) = Text(formatDuration(ms()), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = color, maxLines = 1)

/** Little bars that follow how loud it is while recording, the newest on the right. [levels] is read while drawing, so nothing but the drawing is redone. */
@Composable
private fun LevelStrip(levels: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(26.dp)) {
        val bw = 3.dp.toPx(); val gap = 3.dp.toPx(); val minH = 4.dp.toPx()
        val n = ((size.width + gap) / (bw + gap)).toInt().coerceAtLeast(1)
        val shown = levels.takeLast(n)
        shown.forEachIndexed { i, v ->
            val k = shown.size - 1 - i
            val h = (minH + sqrt(v) * (size.height - minH)).coerceAtMost(size.height)
            drawRoundRect(color, Offset(size.width - (k + 1) * bw - k * gap, (size.height - h) / 2f), Size(bw, h), CornerRadius(bw / 2f))
        }
    }
}

/** The take, once recorded: where the playback is and how long it is, with a thin line that fills as it plays. */
@Composable
private fun TakeProgress(player: AudioPlayer, key: String, totalMs: Long) {
    val t = LocalSb.current
    val mine = key.isNotEmpty() && player.loadedKey == key
    val pos = if (mine) player.position.toLong() else 0L
    val frac = if (totalMs > 0) (pos.toFloat() / totalMs).coerceIn(0f, 1f) else 0f
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("${formatDuration(pos)} / ${formatDuration(totalMs)}", fontSize = 14.sp, color = Sb.ink, maxLines = 1)
        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Sb.line)) { Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(t.acc)) }
    }
}

/**
 * The writing bar, in two states, with a voice memo recorder built in.
 *
 * Three sizes, with one quick animation between them. The mini bar is one slim pill: a + (Camera, Photos, Files, Checklist, Link), "Write…", a dot
 * in the color of the box the scrap will be filed in (tap it to choose another box) and a small blue Record pill. Tap the line and it becomes the middle bar:
 * it gets wider, the hint grows to "Write something…", Record shrinks to just its round icon, and the dot grows into the box's name ("apps"), still tappable to pick another box. When the text needs
 * more than a line the bar grows into the big one: the text on top over the full width, growing with it, and a row under it with the + , the box chip, the tags
 * (picked ones and #words, and a #tag chip to add more) and the blue button. Once something is typed that button is the send arrow, and in the big bar an expand
 * button appears beside it.
 * The bar folds back when you tap the page behind it or press Back with nothing typed; a draft stays open until you send it. Sending saves the scrap at once
 * (title from its first line, #words and the picked tags as tags) and leaves you where you are; "Open" in the confirmation, or the expand button, opens
 * it in the editor. What you have typed is kept while you look around.
 *
 * Record starts the microphone at once, right here. The bar shows how loud it is and the time, and the button becomes Stop. Then the take can be played,
 * and floating pills above the bar ask what to do with it: Attach (a new scrap in the chosen box holding just the memo), Record again or Remove.
 * Leaving the screen throws an unattached take away, like closing the Record audio sheet does.
 */
@Composable
fun BoxScope.WriteBar(vm: ArchiveViewModel, nav: NavController, startBox: String) {
    val t = LocalSb.current; val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    val focus = LocalFocusManager.current; val haptics = LocalHaptics.current; val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current; val view = LocalView.current
    val field = remember { FocusRequester() }
    var text by rememberSaveable { mutableStateOf("") }
    var tagsText by rememberSaveable { mutableStateOf("") }
    var chosen by rememberSaveable(startBox) { mutableStateOf(startBox) }
    val box = if (chosen == "Inbox" || shelves.any { it.name == chosen }) chosen else "Inbox"
    val tagList = remember(tagsText) { parseTags(tagsText) }
    val idle = text.isBlank() && tagList.isEmpty()
    var open by remember { mutableStateOf(false) }      // the bar was tapped open; a draft or picked tags keep it open too
    val expanded = open || text.isNotEmpty() || tagList.isNotEmpty()
    var focused by remember { mutableStateOf(false) }
    var tallLatch by remember { mutableStateOf(false) }   // the text needed more than one line: the bar stays big until it is emptied
    val tall = expanded && (tallLatch || tagList.isNotEmpty() || '\n' in text)
    var plus by remember { mutableStateOf(false) }; var picking by remember { mutableStateOf(false) }; var tagging by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf<Pair<Long, String>?>(null) }
    var notice by remember { mutableStateOf<Pair<String, Boolean>?>(null) }   // a short message in the bar; true = it also offers the phone's Settings
    LaunchedEffect(saved) { if (saved != null) { delay(5000); saved = null } }
    LaunchedEffect(notice) { if (notice != null) { delay(6000); notice = null } }
    LaunchedEffect(expanded) { if (!expanded) focused = false }
    LaunchedEffect(text, tagList.isEmpty()) { if (text.isBlank() && tagList.isEmpty()) tallLatch = false }
    // Opening the bar puts the cursor in it, and so does coming back from the box or tag window.
    LaunchedEffect(open, picking, tagging) { if (open && !picking && !tagging) try { field.requestFocus() } catch (_: Exception) { } }
    fun settle() { focus.clearFocus(); if (idle) open = false }
    BackHandler(focused || (open && idle)) { settle() }
    val boxName = if (box == "Inbox") "Inbox" else shelves.displayName(box)
    val boxDot = if (box == "Inbox") (if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) else shelves.firstOrNull { it.name == box }?.let { TAB_COLORS[it.color % TAB_COLORS.size] } ?: TAB_GRAY
    val onAcc = Color.White

    // The voice memo: rec is 0 nothing, 1 recording, 2 a take is ready to play, attach or throw away.
    val recorder = remember { AudioRecorder(ctx) }
    val player = rememberAudioPlayer()
    var rec by remember { mutableIntStateOf(0) }
    var take by remember { mutableStateOf<File?>(null) }
    var takeMs by remember { mutableLongStateOf(0L) }
    val elapsed = remember { mutableLongStateOf(0L) }       // read only by the small pieces that show it
    val levels = remember { mutableStateListOf<Float>() }
    fun beginTake() {
        if (recorder.start()) { levels.clear(); elapsed.longValue = 0L; rec = 1 } else notice = "Could not start the recording" to false
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) beginTake() else notice = "The microphone is off for Scrapbook" to true }
    fun startTake() {
        focus.clearFocus(); focused = false
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginTake() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun stopTake() {
        val f = recorder.stop()
        if (f == null) { rec = 0; notice = "That was too short to keep" to false }
        else { take = f; takeMs = Recordings.durationMs(f).takeIf { it > 0 } ?: elapsed.longValue; rec = 2 }
    }
    fun dropTake() { player.release(); recorder.cancel(); take = null; rec = 0 }
    fun attachTake() {
        val f = recorder.keep() ?: return
        player.release(); haptics.confirm()
        val a = Recordings.attachment(f); val to = box
        take = null; rec = 0; if (idle) open = false
        vm.addRecording(a, to) { id -> saved = id to to }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel() } }
    // The microphone goes quiet when the screen turns off, so the screen stays on while recording.
    DisposableEffect(rec) { view.keepScreenOn = rec == 1; onDispose { view.keepScreenOn = false } }
    // Leaving the app while recording ends the take there (Android would record silence from then on) and keeps what was said so far.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP && rec == 1) stopTake() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(rec) {
        while (rec == 1) {
            elapsed.longValue = recorder.elapsedMs()
            levels.add((recorder.level() / 32768f).coerceIn(0f, 1f)); if (levels.size > 80) levels.removeAt(0)
            if (elapsed.longValue >= 20 * 60 * 1000L) { stopTake(); break }
            delay(100)
        }
    }
    BackHandler(rec != 0) { if (rec == 1) stopTake() else dropTake() }
    val lastRec = remember { intArrayOf(1) }; if (rec != 0) lastRec[0] = rec
    val pillPhase = lastRec[0]

    /** Hands what is typed (the chosen box and tags too) to a new editor. [image], [record], [file], [camera] and [body] are the editor's usual quick starts. */
    fun toEditor(image: Boolean = false, record: Boolean = false, file: Boolean = false, camera: Boolean = false, body: String? = null) {
        vm.pendingShelf = box; vm.pendingBody = body ?: text.ifBlank { null }; vm.pendingImage = image; vm.pendingRecord = record
        vm.pendingFile = file; vm.pendingCamera = camera; vm.pendingTags = tagsText.ifBlank { null }
        text = ""; tagsText = ""; tallLatch = false; open = false; focus.clearFocus(); nav.navigate("edit/0")
    }
    fun send() {
        val s = text.trim(); if (s.isEmpty()) return
        haptics.confirm(); val to = box; val tags = tagList
        vm.addQuick(s, to, tags) { id -> saved = id to to }
        text = ""; tagsText = ""; tallLatch = false; open = false; focus.clearFocus()
    }

    // While you are typing the page behind goes quiet, and a tap on it puts the keyboard away.
    AnimatedVisibility(focused && rec == 0, Modifier.matchParentSize(), enter = fadeIn(tween(160)), exit = fadeOut(tween(120))) {
        Box(Modifier.fillMaxSize().background(t.paper.copy(alpha = .78f)).pointerInput(idle) { detectTapGestures { settle() } })
    }
    val shape = RoundedCornerShape(30.dp)
    val ease = tween<Float>(280, easing = FastOutSlowInEasing)
    val side by animateDpAsState(if (expanded) 10.dp else 20.dp, tween(280, easing = FastOutSlowInEasing), label = "barSide")   // the open bar is wider than the resting one
    // open: 0 mini bar .. 1 middle bar (wider, Record shrinks to its icon, the box dot grows into its name); tall: 0 one line .. 1 the big bar (text on top, buttons under it).
    val openAnim = animateFloatAsState(if (expanded) 1f else 0f, ease, label = "barOpen")
    val tallAnim = animateFloatAsState(if (tall) 1f else 0f, ease, label = "barTall")
    val hashOn by vm.hashtagTags.collectAsState()
    val shownTags = remember(text, tagList, hashOn, tall) { (tagList + if (tall && hashOn) hashtagsIn(text, text.length) else emptyList()).distinctBy { it.lowercase() } }
    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().consumeWindowInsets(WindowInsets.navigationBars).imePadding().padding(start = side, end = side, bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // What to do with the memo, floating just above the Record button.
        AnimatedVisibility(rec != 0, Modifier.align(Alignment.End), enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 2 }, exit = fadeOut(tween(120)) + slideOutVertically(tween(160)) { it / 2 }) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (pillPhase == 1) FloatPill("close", "Cancel") { dropTake() }
                else {
                    FloatPill("trash", "Remove") { dropTake() }
                    FloatPill("undo", "Record again") { dropTake(); startTake() }
                    FloatPill("clip", "Attach", primary = true) { attachTake() }
                }
            }
        }
        Column(Modifier.fillMaxWidth().shadow(10.dp, shape).clip(shape).background(Sb.raised).border(1.dp, Sb.line, shape).padding(4.dp)) {
            Crossfade(rec, animationSpec = tween(160), label = "barRecording") { phase ->
                if (phase == 0) {
                    // Mini: + , the line to tap, the box dot and Record. Middle: the same, wider, with the box name and the round button. Big: the text on top, under it + , the box chip, the tags and the button.
                    WriteBarLayout(openAnim, tallAnim, text.isNotBlank(), Modifier.fillMaxWidth()) {
                        Box(Modifier.layoutId("plus")) {
                            Box(Modifier.pressScale(.9f).size(40.dp).clip(CircleShape).tapIcon("More ways to write") { plus = true }, Alignment.Center) { Ic("plus", 22.dp, Sb.ink) }
                            PopupMenu(plus, { plus = false }) {
                                PopupItem("Camera", "camera") { plus = false; toEditor(camera = true) }
                                PopupItem("Photos", "image") { plus = false; toEditor(image = true) }
                                PopupItem("Files", "file") { plus = false; toEditor(file = true) }
                                // The + is also there while a draft is typed, so these add to it instead of replacing it.
                                PopupItem("Checklist", "check") { plus = false; toEditor(body = text.trimEnd().let { if (it.isEmpty()) "- [ ] " else "$it\n- [ ] " }) }
                                PopupItem("Link", "link") {
                                    plus = false
                                    val c = clipboard.getText()?.text?.trim().orEmpty()
                                    val url = if (Regex("^https?://\\S+$").matches(c)) c else "https://"
                                    toEditor(body = text.trimEnd().let { if (it.isEmpty()) url else "$it\n$url" })
                                }
                            }
                        }
                        // The line: the hint, a saved or error message while resting; the real text field once open (it is always here, so it can grow in place).
                        Box(Modifier.layoutId("field").heightIn(min = 40.dp)) {
                            BasicTextField(text, { text = it }, Modifier.fillMaxWidth().focusRequester(field).onFocusChanged { focused = it.isFocused; if (it.isFocused) open = true }.padding(horizontal = 8.dp, vertical = 7.dp),
                                enabled = expanded,
                                textStyle = TextStyle(fontSize = 18.sp, lineHeight = 26.sp, fontFamily = headFont(), color = Sb.ink), cursorBrush = SolidColor(t.acc), maxLines = 6,
                                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                                onTextLayout = { r -> if (r.lineCount > 1) tallLatch = true },
                                decorationBox = { inner ->
                                    Box {
                                        if (text.isEmpty() && expanded) WriteHint(openAnim, 26.sp)
                                        inner()
                                    }
                                })
                            if (!expanded) Box(Modifier.matchParentSize().clip(RoundedCornerShape(16.dp)).tap("Write something") { saved = null; notice = null; open = true }.padding(horizontal = 8.dp), Alignment.CenterStart) {
                                val n = notice; val s = saved
                                if (n != null) Row(Modifier.then(if (n.second) Modifier.tap("Open the phone settings for Scrapbook") {
                                    runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }
                                } else Modifier), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Ic("info", 18.dp, accentText(t.acc))
                                    Text(n.first, fontSize = 14.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                    if (n.second) Text("Settings", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = accentText(t.acc))
                                } else if (s != null) Row(Modifier.tap("Open the new scrap") { nav.navigate("edit/${s.first}") }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Ic("check", 18.dp, accentText(t.acc))
                                    Text("Saved to ${if (s.second == "Inbox") "Inbox" else shelves.displayName(s.second)}", fontSize = 16.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                    Text("Open", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = accentText(t.acc))
                                } else WriteHint(openAnim, 22.sp)
                            }
                        }
                        BarBoxChip(openAnim, boxName, boxDot, "Saves to $boxName. Choose a box", Modifier.layoutId("chip")) { if (expanded) focus.clearFocus(); picking = true }
                        val canSend = text.isNotBlank()
                        BarActionButton(openAnim, canSend, Modifier.layoutId("rec")) { if (canSend) send() else startTake() }
                        Box(Modifier.layoutId("expand").size(40.dp).clip(CircleShape).tapIcon("Open in the editor") { toEditor() }, Alignment.Center) { Ic("expand", 18.dp, Sb.mute) }
                        // The tags: the picked ones and the #words in the text, and a button to add more.
                        Row(Modifier.layoutId("tags").horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                            shownTags.forEach { tag ->
                                Box(Modifier.pressScale(.96f).heightIn(min = 32.dp).clip(CircleShape).background(Sb.card).tap("Tag $tag. Edit tags") { focus.clearFocus(); tagging = true }.padding(horizontal = 14.dp), Alignment.Center) {
                                    Text("#$tag", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 140.dp))
                                }
                            }
                            Row(Modifier.pressScale(.96f).heightIn(min = 32.dp).clip(CircleShape).background(Sb.card).tap("Add tags") { focus.clearFocus(); tagging = true }.padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Ic("plus", 14.dp, Sb.mute)
                                Text(if (shownTags.isEmpty()) "#tag" else "tag", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.mute, maxLines = 1)
                            }
                        }
                    }
                } else {
                    // Recording (the level of the voice, the time, Stop) or listening to the take (where it is, its length, Play).
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).semantics { contentDescription = if (phase == 1) "Recording" else "Voice memo" }, Alignment.Center) {
                            if (phase == 1) PulseDot(t.acc) else Ic("wave", 20.dp, accentText(t.acc))
                        }
                        Box(Modifier.weight(1f).heightIn(min = 40.dp).padding(horizontal = 4.dp), Alignment.CenterStart) {
                            if (phase == 1) LevelStrip(levels, t.acc) else TakeProgress(player, take?.absolutePath ?: "", takeMs)
                        }
                        Box(Modifier.pressScale(.9f).size(40.dp).clip(CircleShape).tap("Saves to $boxName. Choose a box") { picking = true }, Alignment.Center) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(boxDot))
                        }
                        val playingNow = player.playing && take != null && player.loadedKey == take?.absolutePath
                        BarPill(if (phase == 1) "Stop recording" else if (playingNow) "Pause the recording" else "Play the recording", t.acc, {
                            if (phase == 1) stopTake() else take?.let { player.toggle(it.absolutePath, it) }
                        }) {
                            if (phase == 1) {
                                Box(Modifier.size(12.dp).background(onAcc, RoundedCornerShape(3.dp)))
                                RecTime({ elapsed.longValue }, onAcc)
                            } else {
                                Ic(if (playingNow) "pause" else "play", 16.dp, onAcc)
                                Text(if (playingNow) "Pause" else "Play", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = onAcc, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
    if (picking) BoxPickSheet(box, vm, { chosen = it }) { picking = false }
    if (tagging) Sheet("Tags", { tagging = false }) {
        // Only while this window is open does the bar watch every scrap, to suggest tags that are already in use.
        val items by vm.items.collectAsState()
        val known = remember(items) { tagCounts(items) }
        TagEditor(tagsText, known, { tagsText = it })
    }
}

private fun wbMix(a: Float, b: Float, f: Float) = a + (b - a) * f
private fun wbMixDp(a: Dp, b: Dp, f: Float): Dp = a + (b - a) * f

/** Shows its content at [frac] of its width (0 = gone, 1 = whole), fading with it: how a label slides away or in. */
private fun Modifier.wbReveal(frac: Float): Modifier = this
    .layout { m, c ->
        val pl = m.measure(Constraints())
        val w = (pl.width * frac).roundToInt()
        layout(w, pl.height) { pl.place(0, 0) }
    }
    .clipToBounds()
    .graphicsLayer { alpha = frac }

/** The hint in the bar's line: "Write…" in the mini bar; as the bar opens the word "something" grows in, so the middle bar says "Write something…". */
@Composable
private fun WriteHint(open: State<Float>, lineHeight: TextUnit) {
    val f = open.value.coerceIn(0f, 1f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Write", fontSize = 16.sp, lineHeight = lineHeight, fontFamily = headFont(), color = Sb.mute, maxLines = 1, softWrap = false)
        Box(Modifier.wbReveal(f)) { Text(" something", fontSize = 16.sp, lineHeight = lineHeight, fontFamily = headFont(), color = Sb.mute, maxLines = 1, softWrap = false) }
        Text("…", fontSize = 16.sp, lineHeight = lineHeight, fontFamily = headFont(), color = Sb.mute, maxLines = 1, softWrap = false)
    }
}

/**
 * The blue button at the right of the writing bar. [open] runs from 0 (a pill that says Record) to 1 (just a round button with the wave icon). Once the bar is
 * open and something is typed it becomes the send arrow, in the same place.
 */
@Composable
private fun BarActionButton(open: State<Float>, canSend: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val t = LocalSb.current; val f = open.value.coerceIn(0f, 1f)
    val sending = canSend && f > .5f
    Box(modifier.pressScale(.94f).defaultMinSize(40.dp, 40.dp).clip(CircleShape).tap(if (sending) "Save the scrap" else "Record a voice memo", onClick), Alignment.Center) {
        Row(Modifier.height(30.dp).clip(CircleShape).background(t.acc).padding(horizontal = wbMixDp(12.dp, 7.dp, f)), verticalAlignment = Alignment.CenterVertically) {
            Crossfade(sending, animationSpec = tween(140), label = "barAction") { send -> Ic(if (send) "send" else "wave", 16.dp, Color.White) }
            Box(Modifier.wbReveal(1f - f)) { Text("Record", Modifier.padding(start = 6.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White, maxLines = 1, softWrap = false) }
        }
    }
}

/** The box the scrap is filed in. [open] runs from 0 (just its colored dot) to 1 (a chip with the dot, the name and a chevron). */
@Composable
private fun BarBoxChip(open: State<Float>, name: String, dot: Color, desc: String, modifier: Modifier, onClick: () -> Unit) {
    val f = open.value.coerceIn(0f, 1f)
    Box(modifier.pressScale(.94f).defaultMinSize(40.dp, 40.dp).clip(CircleShape).tap(desc, onClick), Alignment.Center) {
        Row(Modifier.height(36.dp).clip(CircleShape).background(Sb.card.copy(alpha = f)).padding(start = wbMixDp(15.dp, 12.dp, f), end = wbMixDp(15.dp, 10.dp, f)),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(wbMixDp(10.dp, 9.dp, f)).clip(CircleShape).background(dot))
            Row(Modifier.wbReveal(f), verticalAlignment = Alignment.CenterVertically) {
                Text(name, Modifier.padding(start = 8.dp).widthIn(max = 84.dp), fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Box(Modifier.padding(start = 4.dp)) { Ic("chevdown", 16.dp, Sb.mute) }
            }
        }
    }
}

/**
 * Places the writing bar's parts, so they can slide from one state to the next instead of swapping. Children are found by layoutId:
 * plus, field (the line / the text), chip (box dot or name), rec (the blue button), expand and tags.
 * [open] 0 = the mini bar: + at the left, the line, the box dot and the Record pill at the right.
 * 1 = the middle bar: wider, the same row, but the pill has shrunk to its round icon and the dot has grown into the box's name.
 * [tall] 0 = one line .. 1 = the big bar: the text on top over the full width and, under it, a row with + , the box chip, the tags, (expand) and the blue button.
 * The numbers are read here, while measuring, so an animation redoes the layout and not the whole bar.
 */
@Composable
private fun WriteBarLayout(open: State<Float>, tall: State<Float>, hasText: Boolean, modifier: Modifier, content: @Composable () -> Unit) {
    ComposeLayout(content, modifier) { ms, c ->
        val p = open.value.coerceIn(0f, 1f); val q = tall.value.coerceIn(0f, 1f)
        val w = c.maxWidth
        val row = 40.dp.roundToPx(); val tagsH = 36.dp.roundToPx(); val gap = 4.dp.roundToPx(); val top = 6.dp.roundToPx()
        fun child(id: String) = ms.first { it.layoutId == id }
        val plus = child("plus").measure(Constraints.fixed(row, row))
        val chip = child("chip").measure(Constraints(maxWidth = w))
        val rec = child("rec").measure(Constraints(maxWidth = w))
        val expandP = child("expand").measure(Constraints.fixed(row, row))
        // The Record pill is 30dp tall in a 48dp bar, so it is 9dp from the top and bottom edge: keep the same 9dp (4dp bar padding + 5dp) from the right edge.
        val recInset = 5.dp.roundToPx()
        val recX = w - recInset - rec.width
        // In one line the box chip sits just left of the blue button (a little apart once it shows its name); in the big bar it is on the buttons' row, after the +.
        val lineChipX = recX - chip.width - gap * p
        val chipX = wbMix(lineChipX, (plus.width + gap).toFloat(), q)
        val fieldLeft = wbMix(plus.width.toFloat(), 0f, q); val fieldRight = wbMix(lineChipX, w.toFloat(), q)
        val fieldW = (fieldRight - fieldLeft).roundToInt().coerceAtLeast(0)
        val fieldMin = wbMix(row.toFloat(), 72.dp.roundToPx().toFloat(), q).roundToInt()
        val field = child("field").measure(Constraints(minWidth = fieldW, maxWidth = fieldW, minHeight = fieldMin, maxHeight = maxOf(fieldMin, 170.dp.roundToPx())))
        val ctrlY = (q * (top + field.height + gap)).roundToInt()
        val h = ctrlY + row
        // The tags take what is left of the buttons' row, between the box chip and the blue button (and the expand button, when there is text).
        val tagsLeft = (chipX + chip.width + gap).roundToInt()
        val tagsRight = recX - gap - (if (hasText) expandP.width else 0)
        val tags = child("tags").measure(Constraints.fixed((tagsRight - tagsLeft).coerceAtLeast(0), tagsH))
        layout(w, h) {
            field.place(fieldLeft.roundToInt(), (top * q).roundToInt())
            plus.place(0, ctrlY)
            chip.place(chipX.roundToInt(), ctrlY + (row - chip.height) / 2)
            rec.place(recX, ctrlY + (row - rec.height) / 2)
            if (q > .01f && hasText) expandP.placeWithLayer(recX - expandP.width, ctrlY) { alpha = q }
            if (q > .01f) tags.placeWithLayer(tagsLeft, ctrlY + (row - tagsH) / 2) { alpha = q }
        }
    }
}

/** A place on the arc: its icon, what it is called, and what it does. */
private class ArcStop(val icon: String, val label: String, val go: () -> Unit)

/**
 * One round button. A tap writes (an empty scrap in [box]). Hold it and four places fan out along a quarter circle: slide to one and let go, in a single
 * movement. Let go on the button itself and the arc stays open, so each place can also just be tapped; tap anywhere else to put it away.
 */
@Composable
fun BoxScope.ArcButton(vm: ArchiveViewModel, nav: NavController, box: String, onMenu: () -> Unit, onAdd: () -> Unit) {
    val t = LocalSb.current; val haptic = LocalHapticFeedback.current
    var open by remember { mutableStateOf(false) }; var hover by remember { mutableIntStateOf(-1) }
    val pop by animateFloatAsState(if (open) 1f else 0f, spring(dampingRatio = .62f, stiffness = Spring.StiffnessMedium), label = "arcPop")
    val stops = listOf(
        ArcStop("menu", "Menu") { onMenu() },
        ArcStop("jump", "Go to…") { vm.switcherOpen.value = true },
        ArcStop("search", "Search") { nav.navigate("search") },
        ArcStop("image", "New scrap with a photo") { vm.pendingShelf = box; vm.pendingBody = null; vm.pendingImage = true; nav.navigate("edit/0") },
    )
    val radius = 128.dp; val stepDeg = 30f
    val stopsNow by rememberUpdatedState(stops); val onAddNow by rememberUpdatedState(onAdd)
    fun run(i: Int) { open = false; hover = -1; stopsNow[i].go() }

    // While the arc is out the page goes quiet, and a tap on it puts the arc away.
    if (pop > 0.01f) Box(Modifier.matchParentSize().graphicsLayer { alpha = pop.coerceIn(0f, 1f) }.background(t.paper.copy(alpha = .8f))
        .pointerInput(open) { if (open) detectTapGestures { open = false; hover = -1 } })
    // The quarter circle the places sit on.
    val track = Sb.ink.copy(alpha = .07f)
    Canvas(Modifier.matchParentSize().graphicsLayer { alpha = pop.coerceIn(0f, 1f) }) {
        val c = Offset(size.width - 16.dp.toPx() - 29.dp.toPx(), size.height - 18.dp.toPx() - 29.dp.toPx()); val r = radius.toPx()
        drawArc(track, 180f, 90f, false, Offset(c.x - r, c.y - r), Size(2 * r, 2 * r), style = Stroke(70.dp.toPx(), cap = StrokeCap.Round))
    }
    Box(Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 18.dp)) {
        stops.forEachIndexed { i, st ->
            val a = Math.toRadians((i * stepDeg).toDouble())
            val dx = (-radius.value * sin(a)).toFloat(); val dy = (-radius.value * cos(a)).toFloat()
            val on = hover == i
            Box(Modifier.align(Alignment.BottomEnd).offset((dx * pop - 4).dp, (dy * pop - 4).dp).size(50.dp)
                .graphicsLayer { alpha = pop.coerceIn(0f, 1f); val k = (.4f + .6f * pop) * (if (on) 1.2f else 1f); scaleX = k; scaleY = k }
                .shadow(if (on) 8.dp else 4.dp, CircleShape).clip(CircleShape).background(if (on) Sb.ink else Sb.raised).border(1.dp, Sb.line, CircleShape)
                .then(if (open) Modifier.tap(st.label) { run(i) } else Modifier), Alignment.Center) {
                Ic(st.icon, 24.dp, if (on) Sb.paper else Sb.ink)
                if (on) Box(Modifier.align(Alignment.CenterEnd).wrapContentWidth(Alignment.End, unbounded = true).offset(x = (-62).dp)
                    .clip(CircleShape).background(Sb.ink).padding(horizontal = 18.dp, vertical = 11.dp)) {
                    Text(st.label, color = Sb.paper, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
        }
        Box(Modifier.align(Alignment.BottomEnd).size(58.dp).shadow(8.dp, CircleShape).clip(CircleShape).background(Sb.ink)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    var released = false
                    val early = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) { released = waitForUpOrCancellation() != null; true }
                    if (early != null) {
                        // A tap: write, or (with the arc left open) put the arc away.
                        if (released) { if (open) { open = false; hover = -1 } else onAddNow() }
                        return@awaitEachGesture
                    }
                    open = true; haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val cx = size.width / 2f; val cy = size.height / 2f
                    val near = 44.dp.toPx(); val far = (radius + 70.dp).toPx()
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        val vx = ch.position.x - cx; val vy = ch.position.y - cy; val dist = hypot(vx, vy)
                        // The angle from straight up, turning towards the left: 0 is Menu, 90 is the last place.
                        val deg = Math.toDegrees(atan2((-vx).toDouble(), (-vy).toDouble())).toFloat()
                        val i = (deg / stepDeg).roundToInt()
                        val now = if (dist in near..far && i in 0..stopsNow.lastIndex && kotlin.math.abs(deg - i * stepDeg) < stepDeg / 2f + 2f) i else -1
                        if (now != hover) { hover = now; if (now >= 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                        ch.consume()
                        if (!ch.pressed) {
                            if (hover >= 0) run(hover) else if (dist > near * 1.4f) { open = false; hover = -1 }
                            break
                        }
                    }
                }
            }
            .semantics(mergeDescendants = true) {
                contentDescription = "New scrap"; role = Role.Button
                onClick("New scrap") { onAddNow(); true }
                customActions = stops.mapIndexed { i, st -> CustomAccessibilityAction(st.label) { run(i); true } }
            }, Alignment.Center) { Box(Modifier.graphicsLayer { rotationZ = 45f * pop }) { Ic("plus", 28.dp, Sb.paper) } }
    }
}

/** One of the five ways to start a scrap in the swipe-up sheet: a rounded square with an icon, and its name under it. */
@Composable
private fun TypeTile(icon: String, label: String, primary: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(64.dp).pressScale(.94f).tap(label, onClick), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Box(Modifier.size(62.dp).clip(RoundedCornerShape(22.dp)).background(if (primary) Sb.ink else Sb.card), Alignment.Center) { Ic(icon, 26.dp, if (primary) Sb.paper else Sb.ink) }
        Text(label, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1)
    }
}

/** A small rounded button along the bottom of the swipe-up sheet. */
@Composable
private fun SheetChip(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.pressScale(.96f).heightIn(min = 46.dp).clip(CircleShape).background(Sb.card).tap(label, onClick), Arrangement.Center, Alignment.CenterVertically) {
        Ic(icon, 18.dp, Sb.ink); Spacer(Modifier.width(7.dp)); Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1)
    }
}

/**
 * A thin handle at the bottom of the page and a small + beside it. The + writes. Swipe the handle up (or tap it) and a sheet rises with the ways to start a
 * scrap (text, checklist, photo, voice, link), the places you opened last, and Home, Go to, Search and the menu. It follows your finger, and flicks open or
 * shut. Drag it down, tap the page behind it or press Back to put it away.
 */
@Composable
fun BoxScope.SwipeSheet(vm: ArchiveViewModel, nav: NavController, box: String, onMenu: () -> Unit, onAdd: () -> Unit) {
    val t = LocalSb.current; val scope = rememberCoroutineScope(); val haptic = LocalHapticFeedback.current
    val prog = remember { Animatable(0f) }   // 0 only the handle shows, 1 fully open
    val open by remember { derivedStateOf { prog.value > .001f } }
    val items by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState(); val recents by vm.recentPlaces.collectAsState(); val inboxHidden by vm.inboxHidden.collectAsState()
    val clipboard = LocalClipboardManager.current
    val route by nav.currentBackStackEntryAsState()
    val onHome = route?.destination?.route == "home"
    val places = remember(open, items, shelves, inboxHidden) { if (open) placesOf(items, shelves, inboxHidden) else emptyList() }
    val latest = remember(places, recents) { Switcher.find("", places, recents, 3) }
    BackHandler(open) { scope.launch { prog.animateTo(0f, spring(stiffness = Spring.StiffnessMediumLow)) } }
    fun settle(to: Float) { scope.launch { prog.animateTo(to, spring(dampingRatio = .85f, stiffness = Spring.StiffnessMediumLow)) } }
    /** Closes the sheet at once (the screen is about to change) and runs what was asked. */
    fun go(run: () -> Unit) { scope.launch { prog.snapTo(0f) }; run() }
    fun start(body: String? = null, image: Boolean = false, record: Boolean = false) = go {
        vm.pendingShelf = box; vm.pendingBody = body; vm.pendingImage = image; vm.pendingRecord = record; nav.navigate("edit/0")
    }

    BoxWithConstraints(Modifier.matchParentSize()) {
        val sheetH = (maxHeight - 56.dp).coerceIn(300.dp, 470.dp)
        val peek = 30.dp
        val hPx = with(androidx.compose.ui.platform.LocalDensity.current) { (sheetH - peek).toPx() }
        // The page behind goes quiet while the sheet is up; a tap on it puts the sheet away.
        if (open) Box(Modifier.fillMaxSize().graphicsLayer { alpha = prog.value.coerceIn(0f, 1f) }.background(Color.Black.copy(alpha = .22f))
            .pointerInput(Unit) { detectTapGestures { settle(0f) } })
        // The small + (it fades out as the sheet comes up).
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 30.dp).graphicsLayer { alpha = (1f - prog.value * 2f).coerceIn(0f, 1f) }
            .size(50.dp).shadow(8.dp, CircleShape).clip(CircleShape).background(Sb.ink).then(if (open) Modifier else Modifier.tap("New scrap", onAdd)), Alignment.Center) { Ic("plus", 25.dp, Sb.paper) }
        val shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(sheetH)
            .graphicsLayer { translationY = (1f - prog.value) * hPx }
            .draggable(rememberDraggableState { d -> scope.launch { prog.snapTo((prog.value - d / hPx).coerceIn(0f, 1f)) } }, Orientation.Vertical,
                onDragStopped = { v -> settle(if (v < -900f) 1f else if (v > 900f) 0f else if (prog.value > .35f) 1f else 0f) })
            .clip(shape).drawBehind { drawRect(Sb.raised.copy(alpha = prog.value.coerceIn(0f, 1f))) }) {
            // The handle: all that shows at rest. Tapping it opens the sheet too.
            Box(Modifier.fillMaxWidth().height(peek).tap(if (open) "Close the quick sheet" else "Open the quick sheet") { settle(if (prog.value > .5f) 0f else 1f) }, Alignment.TopCenter) {
                Box(Modifier.padding(top = 12.dp).size(width = 56.dp, height = 5.dp).clip(CircleShape).background(Sb.mute.copy(alpha = .55f)))
            }
            Column(Modifier.fillMaxWidth().graphicsLayer { alpha = ((prog.value - .2f) / .6f).coerceIn(0f, 1f) }.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceBetween) {
                    TypeTile("edit", "Text", true) { go(onAdd) }
                    TypeTile("check", "Checklist", false) { start("- [ ] ") }
                    TypeTile("image", "Photo", false) { start(image = true) }
                    TypeTile("mic", "Voice", false) { start(record = true) }
                    TypeTile("link", "Link", false) {
                        val c = clipboard.getText()?.text?.trim().orEmpty()
                        start(if (Regex("^https?://\\S+$").matches(c)) c else "https://")
                    }
                }
                if (latest.isNotEmpty()) Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(if (recents.isEmpty()) "NEWEST" else "RECENTLY OPENED", Modifier.padding(start = 6.dp, bottom = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
                    latest.forEach { p -> PlaceRow(p) { routeOf(p.key)?.let { r -> go { nav.navigate(r) } } } }
                }
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                    if (!onHome) SheetChip("home", "Home", Modifier.weight(1f)) { go { nav.popBackStack("home", false) } }
                    SheetChip("jump", "Go to", Modifier.weight(1f)) { go { vm.switcherOpen.value = true } }
                    SheetChip("search", "Search", Modifier.weight(1f)) { go { nav.navigate("search") } }
                    SheetChip("menu", "Menu", Modifier.weight(1f)) { go(onMenu) }
                }
            }
        }
    }
}
