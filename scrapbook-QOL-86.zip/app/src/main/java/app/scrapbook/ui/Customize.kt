package app.scrapbook.ui

import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.line.copy(alpha = .6f)).padding(4.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == sel
            val bg by animateColorAsState(if (on) Sb.ink else Sb.ink.copy(alpha = 0f), tween(180), label = "seg")
            val fg by animateColorAsState(if (on) Sb.card else Sb.ink, tween(180), label = "segText")
            Text(o, Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(bg)
                .tap { onSel(i) }.semantics { selected = on }.padding(vertical = 10.dp),
                fontSize = 14.sp, textAlign = TextAlign.Center, color = fg)
        }
    }
}

/** A rounded grey box around a text field. */
@Composable
fun InputBox(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Sb.line.copy(alpha = .5f)).padding(horizontal = 18.dp, vertical = 15.dp)) { content() }
}

/**
 * The bottom sheet every small window uses: the page dims, the sheet slides up with a drag handle, a title (and an optional line under it),
 * the content, and one big button. Tapping outside or Back closes it. primary is what the big button does (the default is onDone),
 * soft turns the button into a quiet grey one for Cancel.
 */
@Composable
fun Sheet(title: String, onDone: () -> Unit, doneLabel: String = "Done", primary: (() -> Unit)? = null, enabled: Boolean = true,
          soft: Boolean = false, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    // The sheet slides up when it opens and down when it is dismissed. The caller removes it, so a dismiss waits for the slide to finish first.
    var shown by remember { mutableStateOf(false) }
    var closing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val doneNow by rememberUpdatedState(onDone)
    LaunchedEffect(Unit) { shown = true }
    val p by animateFloatAsState(if (shown) 1f else 0f, tween(if (shown) 280 else 180, easing = FastOutSlowInEasing), label = "sheet")
    val dismiss: () -> Unit = { if (!closing) { closing = true; shown = false; scope.launch { delay(180); doneNow() } } }
    BackHandler { dismiss() }
    Box(Modifier.fillMaxSize()) {
        // The dimmed backdrop is a button of its own (tap outside to close), not the parent of the sheet, so a screen reader sees each part of the sheet separately.
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .4f * p)).tapIcon("Close $title", dismiss))
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = 680.dp)
            .graphicsLayer { translationY = (1f - p) * size.height }
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(Sb.raised)
            .pointerInput(Unit) { detectTapGestures { } }.semantics { paneTitle = title }.navigationBarsPadding().imePadding().padding(horizontal = 20.dp, vertical = 14.dp)) {
            Box(Modifier.align(Alignment.CenterHorizontally).width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Sb.line))
            Text(title, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 22.sp, modifier = Modifier.asHeading().padding(top = 14.dp, bottom = if (subtitle == null) 4.dp else 0.dp))
            if (subtitle != null) Text(subtitle, fontSize = 14.sp, color = Sb.mute, modifier = Modifier.padding(top = 2.dp, bottom = 6.dp))
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
            Text(doneLabel, Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(28.dp))
                .background(if (soft) Sb.line.copy(alpha = .6f) else Sb.ink.copy(alpha = if (enabled) 1f else .35f))
                .tap(doneLabel) { if (enabled) (primary ?: dismiss)() }.padding(vertical = 16.dp),
                color = if (soft) Sb.ink else Sb.card, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
        }
    }
}

/** Icons offered in the picker. Anything else can be typed in. */
private val SCRAP_ICONS = listOf("📝", "📌", "⭐", "💡", "🎯", "📚", "🔖", "💬", "🔗", "🖼️", "🎵", "🎬", "🍳", "🛒", "✈️", "🏠", "💼", "🎁", "🧠", "❤️", "🌱", "☕", "🔥", "✅", "📅", "💰", "🧩", "🎨", "🔒", "🌙")

@Composable
private fun IconCell(glyph: String, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(if (on) Sb.ink.copy(alpha = .1f) else Color.Transparent)
        .border(if (on) 2.dp else 0.dp, if (on) Sb.ink else Color.Transparent, RoundedCornerShape(14.dp))
        .tap(glyph.ifEmpty { "No icon" }, onClick).semantics { selected = on }, Alignment.Center) {
        if (glyph.isEmpty()) Ic("none", 22.dp, Sb.mute) else Text(glyph, fontSize = 22.sp)
    }
}

/** None, the ready-made icons, a cell for a custom one when it is in use, and a field to type or paste any emoji. */
@Composable
private fun IconPicker(current: String, onPick: (String) -> Unit) {
    val cells = listOf("") + (if (current.isNotBlank() && current !in SCRAP_ICONS) listOf(current) else emptyList()) + SCRAP_ICONS
    var typed by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        cells.chunked(6).forEach { row ->
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                row.forEach { g -> IconCell(g, g == current) { onPick(g) } }
                repeat(6 - row.size) { Spacer(Modifier.size(44.dp)) }
            }
        }
        InputBox {
            BasicTextField(typed, { v ->
                val g = firstGlyph(v.trim())
                if (g.isNotEmpty()) { onPick(g); typed = "" } else typed = v
            }, Modifier.fillMaxWidth(), singleLine = true, textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(Sb.ink),
                decorationBox = { inner -> Box { if (typed.isEmpty()) Text("Or type any emoji", color = Sb.mute, fontSize = 16.sp); inner() } })
        }
    }
}

/**
 * Per-page style: icon, color, accent, cover, type, density, visible metadata, layout. Saved on the item itself.
 * The editor keeps its own copy of the page color (it is part of its undo), so it passes [color] and [onColor] and the color goes through it.
 */
@Composable
fun CustomizeSheet(item: Item, vm: ArchiveViewModel, onDone: () -> Unit, color: Int = item.color, onColor: ((Int) -> Unit)? = null) = Sheet("Page style", onDone, subtitle = "Changes only this page") {
    SheetLabel("Icon")
    SheetGroup { Box(Modifier.padding(14.dp)) { IconPicker(item.icon) { g -> vm.save(item.copy(icon = g)) } } }
    SheetLabel("Page color")
    SheetGroup { Box(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) { ColorDots(color) { if (onColor != null) onColor(it) else vm.save(item.copy(color = it)) } } }
    SheetLabel("Accent")
    SheetGroup { Box(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) { AccentDots(item.accent) { vm.save(item.copy(accent = it)) } } }
    SheetLabel("Cover image")
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) vm.importImage(u) { p -> vm.items.value.firstOrNull { it.id == item.id }?.let { cur -> vm.save(cur.copy(cover = p)) } }
    }
    SheetGroup {
        ActionRow("image", if (item.cover == null) "Choose cover" else "Change cover") { pickCover.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        if (item.cover != null) { SheetDivider(56.dp); ActionRow("close", "Remove cover") { vm.save(item.copy(cover = null)) } }
    }
    SheetLabel("Type"); Seg(listOf("Theme", "Serif", "Sans", "Mono"), item.font) { vm.save(item.copy(font = it)) }
    SheetLabel("Density"); Seg(listOf("Airy", "Cozy", "Compact"), item.density) { vm.save(item.copy(density = it)) }
    SheetLabel("Show")
    SheetGroup {
        ToggleRow("eye", "Metadata", item.showMeta) { vm.save(item.copy(showMeta = it)) }
        SheetDivider(56.dp)
        ToggleRow("starline", "Pinned", item.pinned) { vm.togglePin(item) }
    }
    SheetLabel("Layout")
    Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
        Layout.entries.forEach { l -> SoftChip(l.label, item.layout == l) { vm.setLayout(item.id, l) } }
    }
}

/** One line of the welcome sheet: an icon, a short title and a few words under it. */
@Composable
private fun WelcomeRow(icon: String, title: String, body: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), Arrangement.spacedBy(14.dp), Alignment.Top) {
        Ic(icon, 24.dp, Sb.ink)
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(body, fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute)
        }
    }
}

/** Shown once on first launch. */
@Composable
fun Welcome(onDone: () -> Unit, onExamples: () -> Unit) = Sheet("Welcome to Scrapbook", onDone, doneLabel = "Get started", subtitle = "Quick notes, tidy boxes.") {
    SheetGroup {
        WelcomeRow("edit", "Tap New scrap to start writing", "Select text to format it, and use the bar at the bottom for lists, quotes and checklists. It saves as you type.")
        SheetDivider(56.dp)
        WelcomeRow("layout", "Every page can change", "Pick another layout or style for a page without losing a word.")
        SheetDivider(56.dp)
        WelcomeRow("sliders", "Make it yours", "Open the menu, then Settings, to restyle the app or back it up.")
    }
    SheetGroup { ActionRow("sparkle", "Add a few example scraps") { onExamples(); onDone() } }
}
