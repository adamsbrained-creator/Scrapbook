package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.draw.drawBehind
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.ui.layout.layout
import kotlinx.coroutines.launch
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.delay

// The ways to add a scrap and reach the menu from the main pages (Settings > Add button). 0 Pill and 1 Bottom bar live in Home.kt; the newer ones are here:
// 2 Writing bar (a small composer at the bottom: type, pick a box, send), 3 One button with an arc, 4 Swipe-up sheet.

/** How far the list needs to stay clear of the bottom so its last scrap is not hidden under the add control. */
fun navClearance(style: Int, normal: Dp): Dp = if (style == 2) 200.dp else normal

/**
 * Draws the add control the Settings choice asks for, inside the screen's Box. [box] is where a scrap written here is filed (the box on screen, Inbox on the
 * main pages); [onMenu] opens the menu sheet and [onAdd] opens an empty editor in that box.
 */
@Composable
fun BoxScope.AddNav(style: Int, vm: ArchiveViewModel, nav: NavController, box: String, onMenu: () -> Unit, onAdd: () -> Unit) {
    when (style) {
        1 -> BottomNav(Modifier.matchParentSize(), onMenu, onAdd)
        2 -> WriteBar(vm, nav, box)
        3 -> ArcButton(vm, nav, box, onMenu, onAdd)
        4 -> SwipeSheet(vm, nav, box, onMenu, onAdd)
        else -> NewScrapPill(Modifier.align(Alignment.BottomEnd), onAdd)
    }
}

/** A round button of the writing bar. */
@Composable
private fun BarBtn(icon: String, desc: String, dark: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.pressScale(.9f).size(44.dp).clip(CircleShape).background(if (dark) Sb.ink else Sb.card).tap(desc, onClick), Alignment.Center) {
        Ic(icon, 22.dp, if (dark) Sb.paper else Sb.ink)
    }
}

/** Where a scrap from the writing bar goes: Inbox, or any box. */
@Composable
private fun BoxPickSheet(current: String, vm: ArchiveViewModel, onPick: (String) -> Unit, onDone: () -> Unit) = Sheet("Save to", onDone, doneLabel = "Cancel", soft = true) {
    val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    SheetGroup {
        OptionRow("Inbox", current == "Inbox", dot = if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) { onPick("Inbox"); onDone() }
        BoxTreeRows(shelves, current) { s -> onPick(s.name); onDone() }
    }
    if (shelves.isEmpty()) SheetNote("No boxes yet. Create one from the Boxes screen.")
}

/**
 * The writing bar: a small card at the bottom of the page with a line to type in, a + for photo, checklist, link and voice, the box the scrap will be filed in
 * and a send button. Sending saves the scrap at once (title from its first line, #words as tags) and leaves you where you are; "Open" in the confirmation, or
 * the expand button, opens it in the editor. With nothing typed the dark button opens an empty editor. What you have typed is kept while you look around.
 */
@Composable
fun BoxScope.WriteBar(vm: ArchiveViewModel, nav: NavController, startBox: String) {
    val t = LocalSb.current; val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    val focus = LocalFocusManager.current; val haptics = LocalHaptics.current; val clipboard = LocalClipboardManager.current
    var text by rememberSaveable { mutableStateOf("") }
    var chosen by rememberSaveable(startBox) { mutableStateOf(startBox) }
    val box = if (chosen == "Inbox" || shelves.any { it.name == chosen }) chosen else "Inbox"
    var focused by remember { mutableStateOf(false) }
    var plus by remember { mutableStateOf(false) }; var picking by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf<Pair<Long, String>?>(null) }
    LaunchedEffect(saved) { if (saved != null) { delay(5000); saved = null } }
    BackHandler(focused) { focus.clearFocus() }
    val boxName = if (box == "Inbox") "Inbox" else shelves.displayName(box)
    val boxDot = if (box == "Inbox") (if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) else shelves.firstOrNull { it.name == box }?.let { TAB_COLORS[it.color % TAB_COLORS.size] } ?: TAB_GRAY

    /** Hands what is typed (and the chosen box) to a new editor. [image], [record] and [body] are the editor's usual quick starts. */
    fun toEditor(image: Boolean = false, record: Boolean = false, body: String? = null) {
        vm.pendingShelf = box; vm.pendingBody = body ?: text.ifBlank { null }; vm.pendingImage = image; vm.pendingRecord = record
        text = ""; focus.clearFocus(); nav.navigate("edit/0")
    }
    fun send() {
        val s = text.trim(); if (s.isEmpty()) return
        haptics.confirm(); val to = box
        vm.addQuick(s, to) { id -> saved = id to to }
        text = ""; focus.clearFocus()
    }

    // While you are typing the page behind goes quiet, and a tap on it puts the keyboard away.
    AnimatedVisibility(focused, Modifier.matchParentSize(), enter = fadeIn(tween(160)), exit = fadeOut(tween(120))) {
        Box(Modifier.fillMaxSize().background(t.paper.copy(alpha = .78f)).pointerInput(Unit) { detectTapGestures { focus.clearFocus() } })
    }
    val shape = RoundedCornerShape(28.dp)
    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().consumeWindowInsets(WindowInsets.navigationBars).imePadding().padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
        .shadow(10.dp, shape).clip(shape).background(Sb.raised).border(1.dp, Sb.line, shape).padding(start = 20.dp, end = 10.dp, top = 14.dp, bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().padding(end = 6.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.weight(1f).padding(top = 3.dp)) {
                BasicTextField(text, { text = it }, Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
                    textStyle = TextStyle(fontSize = 18.sp, lineHeight = 26.sp, fontFamily = headFont(), color = Sb.ink), cursorBrush = SolidColor(t.acc), maxLines = 6,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    decorationBox = { inner ->
                        Box {
                            if (text.isEmpty()) {
                                val s = saved
                                if (s != null) Row(Modifier.tap("Open the new scrap") { nav.navigate("edit/${s.first}") }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Ic("check", 18.dp, t.acc)
                                    Text("Saved to ${if (s.second == "Inbox") "Inbox" else shelves.displayName(s.second)}", fontSize = 16.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                    Text("Open", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = t.acc)
                                } else Text("Write something…", fontSize = 18.sp, lineHeight = 26.sp, fontFamily = headFont(), color = Sb.mute)
                            }
                            inner()
                        }
                    })
            }
            if (text.isNotBlank()) Box(Modifier.size(34.dp).clip(CircleShape).tap("Open in the editor") { toEditor() }, Alignment.Center) { Ic("expand", 18.dp, Sb.mute) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                BarBtn("plus", "More ways to write") { plus = true }
                PopupMenu(plus, { plus = false }) {
                    PopupItem("Photo", "image") { plus = false; toEditor(image = true) }
                    PopupItem("Checklist", "check") { plus = false; toEditor(body = if (text.isBlank()) "- [ ] " else text.trimEnd() + "\n- [ ] ") }
                    PopupItem("Link", "link") {
                        plus = false
                        val c = clipboard.getText()?.text?.trim().orEmpty()
                        toEditor(body = if (Regex("^https?://\\S+$").matches(c)) c else "https://")
                    }
                }
            }
            Row(Modifier.pressScale(.96f).height(44.dp).clip(CircleShape).background(Sb.card).tap("Saves to $boxName. Choose a box") { focus.clearFocus(); picking = true }.padding(start = 14.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(boxDot))
                Text(boxName, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
                Ic("chevdown", 16.dp, Sb.mute)
            }
            Spacer(Modifier.weight(1f))
            BarBtn("mic", "Record a voice memo") { toEditor(record = true) }
            if (text.isBlank()) BarBtn("edit", "Open an empty scrap", dark = true) { toEditor() } else BarBtn("send", "Save the scrap", dark = true) { send() }
        }
    }
    if (picking) BoxPickSheet(box, vm, { chosen = it }) { picking = false }
}

/** A place on the arc: its icon, what it is called, and what it does. */
private class ArcStop(val icon: String, val label: String, val go: () -> Unit)

/**
 * One round button. A tap writes (an empty scrap in [box]). Hold it and four places fan out along a quarter circle: slide to one and let go, in a single
 * movement. Let go on the button itself and the arc stays open, so each place can also just be tapped; tap anywhere else to put it away.
 */
@Composable
fun BoxScope.ArcButton(vm: ArchiveViewModel, nav: NavController, box: String, onMenu: () -> Unit, onAdd: () -> Unit) {
    val t = LocalSb.current; val haptic = LocalHapticFeedback.current
    var open by remember { mutableStateOf(false) }; var hover by remember { mutableIntStateOf(-1) }
    val pop by animateFloatAsState(if (open) 1f else 0f, spring(dampingRatio = .62f, stiffness = Spring.StiffnessMedium), label = "arcPop")
    val stops = listOf(
        ArcStop("menu", "Menu") { onMenu() },
        ArcStop("jump", "Go to…") { vm.switcherOpen.value = true },
        ArcStop("search", "Search") { nav.navigate("search") },
        ArcStop("image", "New scrap with a photo") { vm.pendingShelf = box; vm.pendingBody = null; vm.pendingImage = true; nav.navigate("edit/0") },
    )
    val radius = 128.dp; val stepDeg = 30f
    val stopsNow by rememberUpdatedState(stops); val onAddNow by rememberUpdatedState(onAdd)
    fun run(i: Int) { open = false; hover = -1; stopsNow[i].go() }

    // While the arc is out the page goes quiet, and a tap on it puts the arc away.
    if (pop > 0.01f) Box(Modifier.matchParentSize().graphicsLayer { alpha = pop.coerceIn(0f, 1f) }.background(t.paper.copy(alpha = .8f))
        .pointerInput(open) { if (open) detectTapGestures { open = false; hover = -1 } })
    // The quarter circle the places sit on.
    val track = Sb.ink.copy(alpha = .07f)
    Canvas(Modifier.matchParentSize().graphicsLayer { alpha = pop.coerceIn(0f, 1f) }) {
        val c = Offset(size.width - 16.dp.toPx() - 29.dp.toPx(), size.height - 18.dp.toPx() - 29.dp.toPx()); val r = radius.toPx()
        drawArc(track, 180f, 90f, false, Offset(c.x - r, c.y - r), Size(2 * r, 2 * r), style = Stroke(70.dp.toPx(), cap = StrokeCap.Round))
    }
    Box(Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 18.dp)) {
        stops.forEachIndexed { i, st ->
            val a = Math.toRadians((i * stepDeg).toDouble())
            val dx = (-radius.value * sin(a)).toFloat(); val dy = (-radius.value * cos(a)).toFloat()
            val on = hover == i
            Box(Modifier.align(Alignment.BottomEnd).offset((dx * pop - 4).dp, (dy * pop - 4).dp).size(50.dp)
                .graphicsLayer { alpha = pop.coerceIn(0f, 1f); val k = (.4f + .6f * pop) * (if (on) 1.2f else 1f); scaleX = k; scaleY = k }
                .shadow(if (on) 8.dp else 4.dp, CircleShape).clip(CircleShape).background(if (on) Sb.ink else Sb.raised).border(1.dp, Sb.line, CircleShape)
                .then(if (open) Modifier.tap(st.label) { run(i) } else Modifier), Alignment.Center) {
                Ic(st.icon, 24.dp, if (on) Sb.paper else Sb.ink)
                if (on) Box(Modifier.align(Alignment.CenterEnd).wrapContentWidth(Alignment.End, unbounded = true).offset(x = (-62).dp)
                    .clip(CircleShape).background(Sb.ink).padding(horizontal = 18.dp, vertical = 11.dp)) {
                    Text(st.label, color = Sb.paper, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
        }
        Box(Modifier.align(Alignment.BottomEnd).size(58.dp).shadow(8.dp, CircleShape).clip(CircleShape).background(Sb.ink)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    var released = false
                    val early = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) { released = waitForUpOrCancellation() != null; true }
                    if (early != null) {
                        // A tap: write, or (with the arc left open) put the arc away.
                        if (released) { if (open) { open = false; hover = -1 } else onAddNow() }
                        return@awaitEachGesture
                    }
                    open = true; haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val cx = size.width / 2f; val cy = size.height / 2f
                    val near = 44.dp.toPx(); val far = (radius + 70.dp).toPx()
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        val vx = ch.position.x - cx; val vy = ch.position.y - cy; val dist = hypot(vx, vy)
                        // The angle from straight up, turning towards the left: 0 is Menu, 90 is the last place.
                        val deg = Math.toDegrees(atan2((-vx).toDouble(), (-vy).toDouble())).toFloat()
                        val i = (deg / stepDeg).roundToInt()
                        val now = if (dist in near..far && i in 0..stopsNow.lastIndex && kotlin.math.abs(deg - i * stepDeg) < stepDeg / 2f + 2f) i else -1
                        if (now != hover) { hover = now; if (now >= 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                        ch.consume()
                        if (!ch.pressed) {
                            if (hover >= 0) run(hover) else if (dist > near * 1.4f) { open = false; hover = -1 }
                            break
                        }
                    }
                }
            }
            .semantics(mergeDescendants = true) {
                contentDescription = "New scrap"; role = Role.Button
                onClick("New scrap") { onAddNow(); true }
                customActions = stops.mapIndexed { i, st -> CustomAccessibilityAction(st.label) { run(i); true } }
            }, Alignment.Center) { Box(Modifier.graphicsLayer { rotationZ = 45f * pop }) { Ic("plus", 28.dp, Sb.paper) } }
    }
}

/** One of the five ways to start a scrap in the swipe-up sheet: a rounded square with an icon, and its name under it. */
@Composable
private fun TypeTile(icon: String, label: String, primary: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(64.dp).pressScale(.94f).tap(label, onClick), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Box(Modifier.size(62.dp).clip(RoundedCornerShape(22.dp)).background(if (primary) Sb.ink else Sb.card), Alignment.Center) { Ic(icon, 26.dp, if (primary) Sb.paper else Sb.ink) }
        Text(label, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1)
    }
}

/** A small rounded button along the bottom of the swipe-up sheet. */
@Composable
private fun SheetChip(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.pressScale(.96f).height(46.dp).clip(CircleShape).background(Sb.card).tap(label, onClick), Arrangement.Center, Alignment.CenterVertically) {
        Ic(icon, 18.dp, Sb.ink); Spacer(Modifier.width(7.dp)); Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1)
    }
}

/**
 * A thin handle at the bottom of the page and a small + beside it. The + writes. Swipe the handle up (or tap it) and a sheet rises with the ways to start a
 * scrap (text, checklist, photo, voice, link), the places you opened last, and Home, Go to, Search and the menu. It follows your finger, and flicks open or
 * shut. Drag it down, tap the page behind it or press Back to put it away.
 */
@Composable
fun BoxScope.SwipeSheet(vm: ArchiveViewModel, nav: NavController, box: String, onMenu: () -> Unit, onAdd: () -> Unit) {
    val t = LocalSb.current; val scope = rememberCoroutineScope(); val haptic = LocalHapticFeedback.current
    val prog = remember { Animatable(0f) }   // 0 only the handle shows, 1 fully open
    val open by remember { derivedStateOf { prog.value > .001f } }
    val items by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState(); val recents by vm.recentPlaces.collectAsState(); val inboxHidden by vm.inboxHidden.collectAsState()
    val clipboard = LocalClipboardManager.current
    val route by nav.currentBackStackEntryAsState()
    val onHome = route?.destination?.route == "home"
    val places = remember(open, items, shelves, inboxHidden) { if (open) placesOf(items, shelves, inboxHidden) else emptyList() }
    val latest = remember(places, recents) { Switcher.find("", places, recents, 3) }
    BackHandler(open) { scope.launch { prog.animateTo(0f, spring(stiffness = Spring.StiffnessMediumLow)) } }
    fun settle(to: Float) { scope.launch { prog.animateTo(to, spring(dampingRatio = .85f, stiffness = Spring.StiffnessMediumLow)) } }
    /** Closes the sheet at once (the screen is about to change) and runs what was asked. */
    fun go(run: () -> Unit) { scope.launch { prog.snapTo(0f) }; run() }
    fun start(body: String? = null, image: Boolean = false, record: Boolean = false) = go {
        vm.pendingShelf = box; vm.pendingBody = body; vm.pendingImage = image; vm.pendingRecord = record; nav.navigate("edit/0")
    }

    BoxWithConstraints(Modifier.matchParentSize()) {
        val sheetH = (maxHeight - 56.dp).coerceIn(300.dp, 470.dp)
        val peek = 30.dp
        val hPx = with(androidx.compose.ui.platform.LocalDensity.current) { (sheetH - peek).toPx() }
        // The page behind goes quiet while the sheet is up; a tap on it puts the sheet away.
        if (open) Box(Modifier.fillMaxSize().graphicsLayer { alpha = prog.value.coerceIn(0f, 1f) }.background(Color.Black.copy(alpha = .22f))
            .pointerInput(Unit) { detectTapGestures { settle(0f) } })
        // The small + (it fades out as the sheet comes up).
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 30.dp).graphicsLayer { alpha = (1f - prog.value * 2f).coerceIn(0f, 1f) }
            .size(50.dp).shadow(8.dp, CircleShape).clip(CircleShape).background(Sb.ink).then(if (open) Modifier else Modifier.tap("New scrap", onAdd)), Alignment.Center) { Ic("plus", 25.dp, Sb.paper) }
        val shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(sheetH)
            .graphicsLayer { translationY = (1f - prog.value) * hPx }
            .draggable(rememberDraggableState { d -> scope.launch { prog.snapTo((prog.value - d / hPx).coerceIn(0f, 1f)) } }, Orientation.Vertical,
                onDragStopped = { v -> settle(if (v < -900f) 1f else if (v > 900f) 0f else if (prog.value > .35f) 1f else 0f) })
            .clip(shape).drawBehind { drawRect(Sb.raised.copy(alpha = prog.value.coerceIn(0f, 1f))) }) {
            // The handle: all that shows at rest. Tapping it opens the sheet too.
            Box(Modifier.fillMaxWidth().height(peek).tap(if (open) "Close the quick sheet" else "Open the quick sheet") { settle(if (prog.value > .5f) 0f else 1f) }, Alignment.TopCenter) {
                Box(Modifier.padding(top = 12.dp).size(width = 56.dp, height = 5.dp).clip(CircleShape).background(Sb.mute.copy(alpha = .55f)))
            }
            Column(Modifier.fillMaxWidth().graphicsLayer { alpha = ((prog.value - .2f) / .6f).coerceIn(0f, 1f) }.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceBetween) {
                    TypeTile("edit", "Text", true) { go(onAdd) }
                    TypeTile("check", "Checklist", false) { start("- [ ] ") }
                    TypeTile("image", "Photo", false) { start(image = true) }
                    TypeTile("mic", "Voice", false) { start(record = true) }
                    TypeTile("link", "Link", false) {
                        val c = clipboard.getText()?.text?.trim().orEmpty()
                        start(if (Regex("^https?://\\S+$").matches(c)) c else "https://")
                    }
                }
                if (latest.isNotEmpty()) Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(if (recents.isEmpty()) "NEWEST" else "RECENTLY OPENED", Modifier.padding(start = 6.dp, bottom = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
                    latest.forEach { p -> PlaceRow(p) { routeOf(p.key)?.let { r -> go { nav.navigate(r) } } } }
                }
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                    if (!onHome) SheetChip("home", "Home", Modifier.weight(1f)) { go { nav.popBackStack("home", false) } }
                    SheetChip("jump", "Go to", Modifier.weight(1f)) { go { vm.switcherOpen.value = true } }
                    SheetChip("search", "Search", Modifier.weight(1f)) { go { nav.navigate("search") } }
                    SheetChip("menu", "Menu", Modifier.weight(1f)) { go(onMenu) }
                }
            }
        }
    }
}
