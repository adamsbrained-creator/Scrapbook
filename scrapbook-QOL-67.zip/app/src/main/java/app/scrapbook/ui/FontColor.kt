package app.scrapbook.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.hexToRgb
import app.scrapbook.parseColorText
import app.scrapbook.rgbToHex

/** The ready colors in the font color panel: red, orange, yellow, green, blue. Every other color is in the rainbow choice, the hex box or the Recent row. */
val FONT_COLOR_PRESETS = listOf("ff3b30", "ff9500", "ffcc00", "34c759", "0a84ff")

/**
 * The font color panel, in the same minimal style as the page color and accent pickers: the default color (the crossed circle), five popular colors and a rainbow
 * choice that opens the two color bars plus a box for pasting a hex or RGB color. Under them, the colors you used most recently, so the same color can go on other text.
 *
 * [current] is the color of the text now (null = default). [onPick] puts a color on the text (null = the default). A color of your own is passed to [onRemember]
 * when the panel closes, so the Recent row has it next time, even in another scrap; the five ready colors are not repeated there.
 */
@Composable
fun FontColorPanel(current: String?, recent: List<String>, onPick: (String?) -> Unit, onRemember: (String) -> Unit, onClose: () -> Unit) {
    val t = LocalSb.current
    val cur = current?.lowercase()
    val isCustom = cur != null && cur !in FONT_COLOR_PRESETS
    var open by remember { mutableStateOf(false) }                 // the color bars and the hex box
    var live by remember { mutableStateOf<Int?>(null) }            // the color under a finger on the bars, before it is put on the text
    var text by remember { mutableStateOf(cur?.let { "#$it" } ?: "") }
    var base by remember { mutableStateOf<Int?>(if (isCustom) cur?.let { hexToRgb(it) } else null) }
    var barsKey by remember { mutableIntStateOf(0) }               // changes when a pasted color should move the bars
    var lastCustom by remember { mutableStateOf<String?>(null) }
    val keep = rememberUpdatedState(onRemember)
    DisposableEffect(Unit) { onDispose { lastCustom?.let { keep.value(it) } } }

    fun choose(hex: String?) { if (hex != null && hex !in FONT_COLOR_PRESETS) lastCustom = hex; onPick(hex) }
    val parsed = parseColorText(text)
    fun usePasted() {
        val hex = parsed ?: return
        base = hexToRgb(hex); barsKey++; live = null
        choose(hex); onClose()
    }

    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().shadow(18.dp, shape, ambientColor = Color.Black, spotColor = Color.Black).clip(shape).background(Sb.menu).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            val none = cur == null
            Box(Modifier.size(34.dp).clip(CircleShape).background(Sb.paper).border(if (none) 2.5.dp else 1.dp, if (none) Sb.ink else Sb.line, CircleShape)
                .tap("Default color") { choose(null); onClose() }.semantics { selected = none }, Alignment.Center) { Ic("none", 20.dp, Sb.mute) }
            FONT_COLOR_PRESETS.forEach { hex ->
                val on = cur == hex
                Box(Modifier.size(34.dp).clip(CircleShape).background(hexColor(hex)).border(if (on) 2.5.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape)
                    .tap("Color $hex") { choose(hex); onClose() }.semantics { selected = on }, Alignment.Center) { if (on) Ic("check", 18.dp, Color.White) }
            }
            RgbDot(live ?: if (isCustom) cur?.let { hexToRgb(it) } else null, { open = !open })
        }
        if (recent.isNotEmpty()) Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Recent", fontSize = 12.sp, color = Sb.mute)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                recent.forEach { hex ->
                    val on = cur == hex
                    Box(Modifier.size(30.dp).clip(CircleShape).background(hexColor(hex)).border(if (on) 2.5.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape)
                        .tap("Recent color $hex") { choose(hex); onClose() }.semantics { selected = on }, Alignment.Center) { if (on) Ic("check", 16.dp, Color.White) }
                }
            }
        }
        AnimatedVisibility(open, enter = fadeIn(tween(160)) + expandVertically(tween(200)), exit = fadeOut(tween(120)) + shrinkVertically(tween(160))) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                androidx.compose.runtime.key(barsKey) {
                    RgbSliders(base, { live = it; text = "#" + rgbToHex(it) }, { c -> live = null; text = "#" + rgbToHex(c); choose(rgbToHex(c)) })
                }
                val preview = parsed?.let { hexColor(it) } ?: live?.let { rgbColor(it) } ?: cur?.let { hexColor(it) } ?: Sb.paper
                Row(Modifier.fillMaxWidth().height(46.dp).clip(CircleShape).background(Sb.ink.copy(alpha = .07f)).padding(start = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(30.dp).clip(CircleShape).background(preview).border(1.dp, Sb.line, CircleShape))
                    Spacer(Modifier.width(10.dp))
                    BasicTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, textStyle = TextStyle(fontSize = 15.sp, color = Sb.ink), cursorBrush = SolidColor(t.acc),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { usePasted() }),
                        decorationBox = { inner -> Box { if (text.isEmpty()) Text("Paste #hex or RGB", color = Sb.mute, fontSize = 14.sp, maxLines = 1); inner() } })
                    val can = parsed != null
                    Box(Modifier.height(38.dp).clip(CircleShape).background(if (can) t.acc else Sb.line).tap("Use this color") { usePasted() }.padding(horizontal = 16.dp), Alignment.Center) {
                        Text("Use", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (can) Color.White else Sb.mute)
                    }
                }
            }
        }
    }
}
