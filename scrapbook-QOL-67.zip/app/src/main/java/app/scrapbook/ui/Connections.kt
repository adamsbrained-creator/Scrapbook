package app.scrapbook.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// The "Connected" part of a scrap: the scraps it links to, the scraps that link to it, titles it mentions without linking them (one tap links them),
// and scraps that share its tags. The rules are in Connections.kt; this file draws them, and the picker used by "Link to scrap" and by typing [[.

/** The facts the connection rules need about a scrap. */
fun Item.asScrap() = ScrapInfo(id, uid, title, body, tags, collection, savedAt, icon, kind.name)

/** Everything the Connected section shows, worked out for one scrap. */
class ConnectionSet(val linksTo: List<ScrapInfo>, val linkedFrom: List<ScrapInfo>, val mentions: List<Mention>, val related: List<ConnectionPick>, val broken: Int, val ready: Boolean = true) {
    val isEmpty get() = linksTo.isEmpty() && linkedFrom.isEmpty() && mentions.isEmpty() && related.isEmpty() && broken == 0
    val count get() = linksTo.size + linkedFrom.size

    companion object { val NONE = ConnectionSet(emptyList(), emptyList(), emptyList(), emptyList(), 0, ready = false) }
}

/**
 * The connections of the scrap whose id is [selfUid] and whose text and tags are [text] and [tags] (what is on the screen now, not only what is saved).
 * Worked out off the main thread, a moment after the text stops changing, so typing never waits for it. [suggest] turns the two kinds of suggestion
 * (titles you could link, scraps sharing tags) on or off; real links are always shown.
 */
@Composable
fun rememberConnections(text: String, tags: List<String>, selfUid: String, items: List<Item>, suggest: Boolean): ConnectionSet {
    val state = produceState(ConnectionSet.NONE, text, tags, selfUid, items, suggest) {
        if (value.ready) delay(450)
        value = withContext(Dispatchers.Default) {
            val all = items.filter { it.deletedAt == 0L }.map { it.asScrap() }
            val linksTo = Connections.linksTo(text, selfUid, all)
            val from = Connections.linkedFrom(selfUid, all)
            val linked = (linksTo.map { it.uid } + from.map { it.uid }).toSet()
            ConnectionSet(linksTo, from,
                if (suggest) Connections.mentions(text, selfUid, all, Connections.uidsIn(text).toSet()) else emptyList(),
                if (suggest) Connections.related(selfUid, tags, all, linked) else emptyList(),
                Connections.brokenLinks(text, selfUid, all))
        }
    }
    return state.value
}

/** The small round mark in front of a scrap: its own emoji icon when it has one, otherwise one for its type. */
@Composable
private fun ScrapMark(s: ScrapInfo) {
    Box(Modifier.size(38.dp).clip(CircleShape).background(Sb.ink.copy(alpha = .07f)), Alignment.Center) {
        if (s.icon.isNotBlank()) Text(s.icon, fontSize = 18.sp)
        else Ic(when (s.kind) { "Quote" -> "quote"; "Image" -> "image"; "Link" -> "link"; "Voice" -> "mic"; else -> "edit" }, 20.dp, Sb.mute)
    }
}

/** One scrap in a list of connections: tap opens it. [action] is a small button at the right (the "Link" of a suggestion). */
@Composable
private fun ConnectionRow(s: ScrapInfo, sub: String, onOpen: () -> Unit, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.card).tap("Open ${s.title}", onOpen).padding(start = 10.dp, end = 12.dp, top = 9.dp, bottom = 9.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        ScrapMark(s)
        Column(Modifier.weight(1f)) {
            Text(s.title.ifBlank { "Untitled" }, color = Sb.ink, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Sb.mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        action?.invoke()
    }
}

/** A short list under a small heading. Past [LIMIT] rows the rest wait behind "Show all". */
@Composable
private fun <T> Group(label: String, rows: List<T>, row: @Composable (T) -> Unit) {
    if (rows.isEmpty()) return
    var all by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label.uppercase(), Modifier.padding(start = 6.dp, top = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
        (if (all) rows else rows.take(LIMIT)).forEach { row(it) }
        if (rows.size > LIMIT) Text(if (all) "Show fewer" else "Show all ${rows.size}", Modifier.padding(start = 6.dp).tap(if (all) "Show fewer" else "Show all ${rows.size}") { all = !all }.padding(vertical = 8.dp, horizontal = 4.dp),
            fontSize = 13.sp, fontWeight = FontWeight.Medium, color = LocalSb.current.acc)
    }
}

private const val LIMIT = 4

/**
 * "Connected", at the bottom of a scrap. Nothing is drawn for a scrap with no connections. [onOpen] opens a scrap by its id; [onLink] (null while the page is
 * locked or read only) turns a mentioned title into a link. The heading folds the section away and back.
 */
@Composable
fun ConnectionsSection(c: ConnectionSet, onOpen: (String) -> Unit, onLink: ((Mention) -> Unit)?, modifier: Modifier = Modifier) {
    if (c.isEmpty) return
    var open by remember { mutableStateOf(true) }
    Column(modifier.fillMaxWidth().padding(top = 26.dp), Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).tap(if (open) "Hide connections" else "Show connections") { open = !open }.padding(vertical = 6.dp),
            Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
            Ic("link", 20.dp, LocalSb.current.acc)
            Text("Connected", color = Sb.ink, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 19.sp, modifier = Modifier.weight(1f))
            if (c.count > 0) Text("${c.count}", color = Sb.mute, fontSize = 14.sp)
            Ic(if (open) "chevdown" else "chevron", 20.dp, Sb.mute)
        }
        AnimatedVisibility(open, enter = fadeIn(tween(160)) + expandVertically(tween(220)), exit = fadeOut(tween(120)) + shrinkVertically(tween(180))) {
            Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                Group("Linked from", c.linkedFrom) { s -> ConnectionRow(s, listOf(s.box).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "Scrap" }, { onOpen(s.uid) }) }
                Group("Links to", c.linksTo) { s -> ConnectionRow(s, s.box.ifBlank { "Scrap" }, { onOpen(s.uid) }) }
                Group("Could link", c.mentions) { m ->
                    ConnectionRow(m.scrap, "Its title is written in this scrap", { onOpen(m.scrap.uid) }, if (onLink == null) null else ({
                        Text("Link", Modifier.clip(RoundedCornerShape(18.dp)).background(LocalSb.current.acc.copy(alpha = .16f)).tap("Link ${m.scrap.title}") { onLink(m) }.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = LocalSb.current.acc, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }))
                }
                Group("Related", c.related) { p -> ConnectionRow(p.scrap, p.why ?: p.scrap.box, { onOpen(p.scrap.uid) }) }
                if (c.broken > 0) Text(if (c.broken == 1) "1 link here leads to a scrap that no longer exists." else "${c.broken} links here lead to scraps that no longer exist.",
                    Modifier.padding(horizontal = 6.dp), fontSize = 12.5.sp, lineHeight = 17.sp, color = Sb.mute)
            }
        }
    }
}

/**
 * "Link to scrap": a search over all scraps. With nothing typed, the likeliest ones come first (a title already written in the text, scraps that link here,
 * scraps sharing tags, the same box), each with a few words on why. Tapping one calls [onPick]; the caller puts the link in.
 */
@Composable
fun LinkPickerSheet(selfUid: String, selfText: String, selfTags: List<String>, selfBox: String, items: List<Item>, onPick: (ScrapInfo) -> Unit, onDone: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val all = remember(items) { items.filter { it.deletedAt == 0L }.map { it.asScrap() } }
    val picks = remember(q, all) { Connections.picks(q, selfUid, selfText, selfTags, selfBox, all) }
    Sheet("Link to scrap", onDone, doneLabel = "Cancel", soft = true, subtitle = if (q.isBlank()) "Likely ones first" else null) {
        androidx.compose.runtime.LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) { } }
        InputBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("search", 20.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                Field(q, { q = it }, "Search your scraps", 16.sp, headFont(), modifier = Modifier.weight(1f).focusRequester(focus))
            }
        }
        if (picks.isEmpty()) SheetNote(if (q.isBlank()) "There are no other scraps to link to yet." else "No scrap matches that.")
        else Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(6.dp)) {
            picks.forEach { p ->
                ConnectionRow(p.scrap, listOfNotNull(p.why, p.scrap.box.takeIf { it.isNotBlank() && p.why != "Same box" }).joinToString(" · ").ifBlank { "Scrap" }, { onPick(p.scrap) })
            }
        }
    }
}
