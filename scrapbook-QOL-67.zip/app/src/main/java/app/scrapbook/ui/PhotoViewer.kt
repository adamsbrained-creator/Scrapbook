package app.scrapbook.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Full-screen viewer for a scrap's photos. Swipe sideways to move between photos, pinch or double-tap to zoom, drag to look around
 * when zoomed, tap once to hide or show the buttons. Back or the close button leaves. [start] is the photo that opens first.
 */
@Composable
fun PhotoViewer(images: List<String>, start: Int, onClose: () -> Unit) {
    if (images.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    val pager = rememberPagerState(initialPage = start.coerceIn(0, images.lastIndex)) { images.size }
    var chrome by remember { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        // The screen behind is black, so the clock and battery in the status bar must be light whatever the app's theme is.
        val view = LocalView.current
        SideEffect {
            val w = (view.parent as? DialogWindowProvider)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = false; isAppearanceLightNavigationBars = false }
        }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed) { i ->
                ZoomableImage(images[i], onTap = { chrome = !chrome }, onZoomed = { zoomed = it })
            }
            AnimatedVisibility(chrome, Modifier.align(Alignment.TopStart), enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier.statusBarsPadding().padding(12.dp).size(44.dp).clip(CircleShape).background(Color(0x33FFFFFF)).tap("Close photo", onClose),
                    Alignment.Center,
                ) { Ic("close", 22.dp, Color.White) }
            }
            if (images.size > 1) AnimatedVisibility(chrome, Modifier.align(Alignment.BottomCenter), enter = fadeIn(), exit = fadeOut()) {
                Text(
                    "${pager.currentPage + 1} / ${images.size}", Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 20.dp),
                    color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            }
        }
    }
}

/** One photo that can be pinched, double-tapped and dragged. It starts fitted to the screen and goes back to that when zoomed out. */
@Composable
private fun ZoomableImage(uri: String, onTap: () -> Unit, onZoomed: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    /** Keeps the photo from being dragged out of view. */
    fun clamp(o: Offset, s: Float): Offset {
        val mx = box.width * (s - 1f) / 2f; val my = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }
    LaunchedEffect(scale > 1.01f) { onZoomed(scale > 1.01f) }
    Box(
        Modifier.fillMaxSize().onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { p ->
                        if (scale > 1.01f) { scale = 1f; offset = Offset.Zero }
                        else { scale = 2.5f; offset = clamp(Offset((box.width / 2f - p.x) * 1.5f, (box.height / 2f - p.y) * 1.5f), 2.5f) }
                    },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val e = awaitPointerEvent()
                        // One finger on a fitted photo is left alone so the pager can swipe; two fingers, or a zoomed photo, are ours.
                        if (e.changes.size > 1 || scale > 1.01f) {
                            val zoom = e.calculateZoom(); val pan = e.calculatePan()
                            var ns = (scale * zoom).coerceIn(1f, 6f)
                            if (ns < 1.01f) ns = 1f
                            val centre = e.calculateCentroid(useCurrent = false)
                            offset = if (ns == 1f) Offset.Zero else {
                                val c = if (centre.isSpecified) centre - Offset(box.width / 2f, box.height / 2f) else Offset.Zero
                                clamp(c - (c - offset) * (ns / scale) + pan, ns)
                            }
                            scale = ns
                            e.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (e.changes.any { it.pressed })
                }
            },
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(uri).size(2400).build(),
            contentDescription = "Photo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y },
        )
    }
}
