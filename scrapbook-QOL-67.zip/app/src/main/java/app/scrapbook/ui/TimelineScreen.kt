package app.scrapbook.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import java.text.DateFormat
import java.text.DateFormatSymbols
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

// THE PERSONAL TIMELINE
//
// Your scraps in the order of your life: grouped by month (the heading stays at the top while you scroll), each scrap on its day, newest first.
// A switch chooses whether a scrap sits at the day it was created or the day it was last edited. The rules are in Timeline.kt (tested in TimelineTest.kt).
// The existing screens only touch this from two lines, each marked "[timeline hook N]":
//
//   1. MainActivity.kt, in the NavHost:      composable("timeline") { Visit(visits, it) { TimelineScreen(vm, nav) } }
//   2. Home.kt, MenuSheet, after Rediscover: SheetRow("book", "Timeline") { go("timeline") }

private fun boxTint(shelves: List<Shelf>, inboxColor: Int, box: String): Color {
    val s = shelves.firstOrNull { it.name == box }
    return when {
        s != null -> TAB_COLORS[s.color.mod(TAB_COLORS.size)]
        box.isBlank() || box == "Inbox" -> if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]
        else -> TAB_GRAY
    }
}

/** The small icon at the end of a scrap's title: what kind of scrap it is, or that it has a checklist. */
private fun kindIconOf(n: Item): String? = when (n.kind) {
    Kind.Link -> "link"; Kind.Image -> "image"; Kind.Voice -> "mic"; Kind.Quote -> "quote"
    else -> if ("- [ ] " in n.body || "- [x] " in n.body) "taskcheck" else null
}

/** The heading of a month: its name, how many scraps it holds, and the box most of them are in. Tapping it opens the jump list. */
@Composable
private fun MonthHeader(m: TimelineMonth, names: Array<String>, shelves: List<Shelf>, onClick: () -> Unit) {
    val mostly = m.mostlyBox()?.let { shelves.labelOf(it) }
    val count = if (m.count == 1) "1 scrap" else "${m.count} scraps"
    Row(Modifier.fillMaxWidth().background(Sb.paper).tap("Jump to another month", onClick).padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${names[m.month]} ${m.year}", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 22.sp)
            Text(if (mostly != null) "$count · mostly $mostly" else count, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Ic("chevdown", 20.dp, Sb.mute)
    }
}

/** One scrap on its day: the day number and weekday sit in the left column on the first scrap of each day. */
@Composable
private fun EntryRow(n: Item, day: TimelineDay?, mode: TimelineField, tint: Color, boxLabel: String, weekdays: Array<String>, timeFmt: DateFormat, nav: NavController) {
    val preview = remember(n.id, n.savedAt) { cachedPreview(n.title, n.body) }
    val kindIcon = remember(n.id, n.savedAt, n.kind) { kindIconOf(n) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp), Arrangement.spacedBy(12.dp)) {
        Column(Modifier.width(40.dp).padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (day != null) {
                Text("${day.day}", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp)
                Text(weekdays[day.dow], fontSize = 12.sp, color = Sb.mute)
            }
        }
        Column(Modifier.weight(1f).pressScale(.98f).clip(RoundedCornerShape(22.dp)).background(Sb.card).tap("Open ${n.title}") { nav.navigate("edit/${n.id}") }
            .padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(tint))
                Text((if (n.icon.isNotBlank()) n.icon + " " else "") + n.title.ifBlank { "Untitled" }, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (kindIcon != null) Ic(kindIcon, 15.dp, Sb.mute)
            }
            if (preview.isNotBlank()) Text(preview, fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("$boxLabel · ${timeFmt.format(Date(n.timelineAt(mode)))}", fontSize = 12.5.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** "On this day": scraps made on today's date in earlier years. Only shown when there are some. */
@Composable
private fun OnThisDayCard(items: List<Item>, nav: NavController) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ON THIS DAY", fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
        items.take(3).forEach { n ->
            Row(Modifier.fillMaxWidth().tap("Open ${n.title}") { nav.navigate("edit/${n.id}") }.padding(vertical = 4.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                Text(Fmt.of("yyyy").format(Date(n.createdAt)), Modifier.width(48.dp), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 18.sp)
                Text(n.title.ifBlank { "Untitled" }, Modifier.weight(1f), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (items.size > 3) Text("and ${items.size - 3} more", fontSize = 13.sp, color = Sb.mute)
    }
}

/** Years and months with how many scraps each holds; tapping one scrolls the timeline there. */
@Composable
private fun JumpSheet(months: List<TimelineMonth>, names: Array<String>, onPick: (TimelineMonth) -> Unit, onClose: () -> Unit) {
    Sheet("Jump to", onClose, doneLabel = "Close", soft = true) {
        months.groupBy { it.year }.forEach { (year, ms) ->
            SheetLabel("$year")
            SheetGroup {
                ms.forEachIndexed { i, m ->
                    if (i > 0) SheetDivider()
                    Row(Modifier.fillMaxWidth().tap("Go to ${names[m.month]} $year") { onPick(m) }.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(names[m.month], Modifier.weight(1f), fontSize = 16.sp)
                        Text("${m.count}", fontSize = 15.sp, color = Sb.mute)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TimelineScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current
    val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    var fieldName by rememberSaveable { mutableStateOf(TimelineField.Created.name) }
    val mode = TimelineField.valueOf(fieldName)
    var filter by rememberSaveable(stateSaver = ScrapFilterSaver) { mutableStateOf(ScrapFilter()) }
    var filterSheet by remember { mutableStateOf(false) }; var jump by remember { mutableStateOf(false) }
    val now = remember { System.currentTimeMillis() }
    val shown = remember(all, filter) { all.filteredBy(filter, now) }
    val months = remember(shown, mode) { timelineOf(shown, mode) }
    val rows = remember(months) { timelineRows(months) }
    val today = remember(shown) { onThisDay(shown, now) }
    val symbols = remember { DateFormatSymbols.getInstance(Locale.getDefault()) }
    val timeFmt = remember { DateFormat.getTimeInstance(DateFormat.SHORT) }
    val listState = rememberLazyListState(); val scope = rememberCoroutineScope()
    val lead = if (today.isNotEmpty()) 1 else 0   // the "On this day" card comes before the first month

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.paper) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
                ScreenHeader({ nav.popBackStack() }, title = "Timeline")
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                    TimelineField.entries.forEach { f -> SoftChip(f.label, mode == f) { fieldName = f.name } }
                    Spacer(Modifier.weight(1f))
                    FilterButton(filter) { filterSheet = true }
                }
                if (rows.isEmpty()) {
                    if (filter.isOn) EmptyState("search", "Nothing matches", "No scrap fits these filters.", primary = EmptyAction("Clear filters", "close") { filter = ScrapFilter() })
                    else EmptyState("book", "Your timeline starts here", "Every scrap you write lands on its day. Write the first one.",
                        primary = EmptyAction("New scrap", "edit") { vm.pendingShelf = null; nav.navigate("edit/0") })
                } else LazyColumn(Modifier.weight(1f), state = listState, contentPadding = PaddingValues(bottom = 40.dp)) {
                    if (today.isNotEmpty()) item(key = "onthisday") { OnThisDayCard(today, nav) }
                    months.forEach { m ->
                        stickyHeader(key = "m${m.year}-${m.month}") { MonthHeader(m, symbols.months, shelves) { jump = true } }
                        m.days.forEach { d ->
                            itemsIndexed(d.items, key = { _, n -> "e${n.id}" }) { i, n ->
                                EntryRow(n, if (i == 0) d else null, mode, boxTint(shelves, inboxColor, n.collection), shelves.labelOf(n.collection.ifBlank { "Inbox" }), symbols.shortWeekdays, timeFmt, nav)
                            }
                        }
                    }
                }
            }
        }
        if (jump) JumpSheet(months, symbols.months, { m -> jump = false; scope.launch { listState.animateScrollToItem(lead + rows.indexOfMonth(m.year, m.month)) } }) { jump = false }
        if (filterSheet) FilterSheet(filter, { filter = it }, all, listOf("Inbox") + shelves.map { it.name }, shown.size) { filterSheet = false }
    }
}
