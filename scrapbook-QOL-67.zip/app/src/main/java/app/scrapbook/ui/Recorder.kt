package app.scrapbook.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import app.scrapbook.*
import kotlinx.coroutines.delay
import java.io.File

/** Plays one sound at a time: the recording or file whose card was tapped last. [loadedKey] says which one (its stored path). */
class AudioPlayer {
    private var mp: MediaPlayer? = null
    var loadedKey by mutableStateOf("")
        private set
    var playing by mutableStateOf(false)
        private set
    var position by mutableIntStateOf(0)
        private set
    var duration by mutableIntStateOf(0)
        private set

    fun toggle(key: String, file: File) {
        val current = mp
        if (loadedKey == key && current != null) {
            if (current.isPlaying) { current.pause(); playing = false } else { current.start(); playing = true }
            return
        }
        release()
        try {
            val m = MediaPlayer()
            m.setDataSource(file.absolutePath)
            m.prepare()
            m.setOnCompletionListener {
                playing = false
                position = 0
                runCatching { mp?.seekTo(0) }
            }
            duration = m.duration
            position = 0
            m.start()
            mp = m
            loadedKey = key
            playing = true
        } catch (e: Exception) {
            release()
        }
    }

    fun seek(ms: Int) {
        mp?.seekTo(ms)
        position = ms
    }

    fun tick() {
        mp?.let { if (it.isPlaying) position = it.currentPosition }
    }

    fun release() {
        runCatching { mp?.release() }
        mp = null
        loadedKey = ""
        playing = false
        position = 0
        duration = 0
    }
}

/** A player that stops by itself when the screen that asked for it goes away. */
@Composable
fun rememberAudioPlayer(): AudioPlayer {
    val player = remember { AudioPlayer() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(player.playing) {
        while (player.playing) {
            player.tick()
            delay(150)
        }
    }
    return player
}

/**
 * "Record audio": Record, Stop, then listen and Attach, Record again or Cancel. Asks for the microphone the first time.
 * [onSaved] gets the finished recording as an attachment; the caller adds it to the scrap and closes the sheet.
 * Closing the sheet any other way throws the take away.
 */
@Composable
fun RecordSheet(onSaved: (Attachment) -> Unit, onDone: () -> Unit) {
    val t = LocalSb.current
    val ctx = LocalContext.current
    val recorder = remember { AudioRecorder(ctx) }
    val player = rememberAudioPlayer()
    var phase by remember { mutableIntStateOf(0) }          // 0 ready, 1 recording, 2 listen
    var elapsed by remember { mutableLongStateOf(0L) }
    var level by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf(false) }
    var take by remember { mutableStateOf<File?>(null) }
    var takeMs by remember { mutableLongStateOf(0L) }
    val onAcc = Color(0xFF141414)

    DisposableEffect(Unit) { onDispose { recorder.cancel() } }
    // The microphone goes quiet when the screen turns off, so the screen stays on while recording.
    val view = LocalView.current
    DisposableEffect(phase) { view.keepScreenOn = phase == 1; onDispose { view.keepScreenOn = false } }

    fun begin() {
        failed = false
        if (recorder.start()) phase = 1 else failed = true
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) begin() else denied = true }
    fun startRecording() {
        denied = false
        val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (has) begin() else permission.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun stopRecording() {
        val f = recorder.stop()
        if (f == null) { failed = true; phase = 0 }
        else { take = f; takeMs = Recordings.durationMs(f).takeIf { it > 0 } ?: elapsed; phase = 2 }
    }
    // Leaving the app while recording ends the take there (Android would record silence from then on) and keeps what was said so far.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP && phase == 1) stopRecording() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(phase) {
        while (phase == 1) {
            elapsed = recorder.elapsedMs()
            level = recorder.level()
            if (elapsed >= 20 * 60 * 1000L) { stopRecording(); break }
            delay(100)
        }
    }

    Sheet(if (phase == 2) "Your recording" else "Record audio", onDone,
        doneLabel = if (phase == 2) "Attach to scrap" else "Cancel", soft = phase != 2,
        primary = if (phase == 2) ({ recorder.keep()?.let { f -> onSaved(Recordings.attachment(f)) } }) else null) {
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(formatDuration(when (phase) { 1 -> elapsed; 2 -> takeMs; else -> 0L }), fontFamily = headFont(), fontWeight = FontWeight.Bold, fontSize = 40.sp,
                color = if (phase == 1) t.acc else Sb.ink)
            // The big round button: record, stop, or play the take. While recording a soft ring breathes with how loud it is.
            val pulse = if (phase == 1) 1f + (level / 32768f).coerceIn(0f, 1f) * 0.45f else 1f
            Box(Modifier.size(110.dp), Alignment.Center) {
                if (phase == 1) Box(Modifier.size(84.dp).scale(pulse).background(t.acc.copy(alpha = .22f), CircleShape))
                Box(Modifier.size(84.dp).clip(CircleShape).background(t.acc).tap(when (phase) { 0 -> "Start recording"; 1 -> "Stop recording"; else -> "Play recording" }) {
                    when (phase) {
                        0 -> startRecording()
                        1 -> stopRecording()
                        else -> take?.let { player.toggle(it.absolutePath, it) }
                    }
                }, Alignment.Center) {
                    when (phase) {
                        1 -> Box(Modifier.size(28.dp).background(onAcc, RoundedCornerShape(6.dp)))
                        2 -> Ic(if (player.playing) "pause" else "play", 36.dp, onAcc)
                        else -> Box(Modifier.size(32.dp).background(onAcc, CircleShape))
                    }
                }
            }
            Text(
                when {
                    denied -> "The microphone is switched off for Scrapbook. Allow it in your phone's Settings, under Apps, Scrapbook, Permissions, then try again."
                    failed -> "The recording could not be started. Is another app using the microphone?"
                    phase == 0 -> "Tap the round button to start, then tap again to stop."
                    phase == 1 -> "Recording… tap to stop."
                    else -> "Tap to listen. Attach adds it to this scrap."
                },
                fontSize = 13.sp, color = if (denied || failed) Sb.danger else Sb.mute, textAlign = TextAlign.Center)
            if (denied) SoftChip("Open app settings") {
                runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }
            }
            if (phase == 2) SoftChip("Record again") {
                player.release()
                recorder.cancel()
                take = null
                phase = 0
                startRecording()
            }
        }
    }
}
