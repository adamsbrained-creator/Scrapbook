package app.scrapbook.ui

import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

/**
 * Where a scrap's photos, files and text sit on its page. The order is the same while reading and while writing, and it is kept for this scrap only.
 * Hold a row and drag it to a new place, or use its arrow up and arrow down; the rows slide past each other as they swap.
 */
@Composable
fun ArrangeSheet(order: List<Block>, photos: Int, files: Int, onMove: (from: Int, to: Int) -> Unit, onDone: () -> Unit) {
    val haptics = LocalHaptics.current
    val drag = remember { DragReorder(vertical = true) }
    Sheet("Arrange page", onDone, subtitle = "Hold a part and drag it, or use the arrows. Top of the page first") {
        SheetGroup {
            LazyColumn(Modifier.fillMaxWidth().height(72.dp * order.size), userScrollEnabled = false) {
                items(order, key = { it.name }) { b ->
                    val i = order.indexOf(b)
                    // The row being dragged follows the finger, so it must not also slide to its new place; the others do.
                    val dragging = drag.active == b
                    Row(Modifier.animateItem(placementSpec = if (dragging) null else tween(220))
                        .reorderLayer(drag, b).reorderGesture(drag, b, order, true, onMove)
                        .fillMaxWidth().height(72.dp).padding(start = 18.dp, end = 10.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        Ic(when (b) { Block.Photos -> "image"; Block.Files -> "page"; Block.Text -> "edit" }, 24.dp, Sb.ink)
                        Column(Modifier.weight(1f)) {
                            Text(when (b) { Block.Photos -> "Photos"; Block.Files -> "Files"; Block.Text -> "Text" }, color = Sb.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text(when (b) {
                                Block.Photos -> if (photos == 0) "None on this scrap yet" else if (photos == 1) "1 photo" else "$photos photos"
                                Block.Files -> if (files == 0) "None on this scrap yet" else if (files == 1) "1 file" else "$files files"
                                Block.Text -> "What you write"
                            }, color = Sb.mute, fontSize = 13.sp)
                        }
                        MoveBtn("up", "Move ${b.name} up", i > 0) { haptics.tick(); onMove(i, i - 1) }
                        MoveBtn("down", "Move ${b.name} down", i < order.lastIndex) { haptics.tick(); onMove(i, i + 1) }
                    }
                }
            }
        }
        SheetNote("The cover and a quote's source always stay at the very top.")
    }
}

@Composable
private fun MoveBtn(icon: String, desc: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).alpha(if (enabled) 1f else .3f).tap(desc) { if (enabled) onClick() }, Alignment.Center) { Ic(icon, 22.dp, Sb.ink) }
}
