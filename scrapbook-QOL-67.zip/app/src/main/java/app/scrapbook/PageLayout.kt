package app.scrapbook

/**
 * What a scrap's page is made of, one place for each: the text, and every photo and every attached file on its own.
 * The page is a list of these in the order they are shown from the top down, so a single photo or file can sit above the text, below it, or between
 * other photos and files. (The cover and a quote's source always stay at the very top.)
 *
 * The list only says what kind of thing sits where. The n-th [Part.Photo] in it is the n-th photo of the scrap and the n-th [Part.File] is the n-th file,
 * so moving a photo past another photo also changes the order of the photos themselves (see [moveResult]).
 */
enum class Part { Text, Photo, File }

/** A stretch of neighbouring places of the same kind, shown together: a row of photos, a column of files, or the text. */
data class Run(val part: Part, val slot: Int, val first: Int, val count: Int)

/** Where something sits on screen (pixels, all in the same coordinate space). A line has [left] == [right] (upright) or [top] == [bottom] (flat). */
data class Cell(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val centerX: Float get() = (left + right) / 2f
}

/** What [PageLayout.moveResult] works out: the new page order, and where the moved photo or file now sits among its own kind. */
data class Moved(val layout: List<Part>, val part: Part, val fromKind: Int, val toKind: Int)

object PageLayout {
    /** What a scrap shows until you arrange it: all photos, then all files, then the text. */
    fun default(photos: Int, files: Int): List<Part> = List(photos) { Part.Photo } + List(files) { Part.File } + Part.Text

    /**
     * Reads the saved order ("Photo,Text,File,Photo"). The older saved form with whole groups ("Text,Photos,Files") is read too: a group stands for all
     * its photos or files. Anything unknown is skipped, and the result always has the right number of places for [photos] photos and [files] files.
     */
    fun parse(saved: String?, photos: Int, files: Int): List<Part> {
        if (saved.isNullOrBlank()) return default(photos, files)
        val out = ArrayList<Part>()
        var p = 0; var f = 0; var hasText = false
        for (raw in saved.split(',')) when (raw.trim()) {
            "Text" -> if (!hasText) { out.add(Part.Text); hasText = true }
            "Photo" -> if (p < photos) { out.add(Part.Photo); p++ }
            "File" -> if (f < files) { out.add(Part.File); f++ }
            "Photos" -> while (p < photos) { out.add(Part.Photo); p++ }
            "Files" -> while (f < files) { out.add(Part.File); f++ }
        }
        // what the saved order did not mention goes at the end, in the usual order
        while (p < photos) { out.add(Part.Photo); p++ }
        while (f < files) { out.add(Part.File); f++ }
        if (!hasText) out.add(Part.Text)
        return out
    }

    /**
     * [layout] made to match the real number of photos and files: places that are no longer needed are dropped (the later ones), and a new photo or
     * file goes after the last one of its kind (a first photo goes to the top, a first file below the photos). The text is always there exactly once.
     */
    fun fit(layout: List<Part>, photos: Int, files: Int): List<Part> {
        val out = ArrayList<Part>()
        var p = 0; var f = 0; var hasText = false
        for (x in layout) when (x) {
            Part.Text -> if (!hasText) { out.add(x); hasText = true }
            Part.Photo -> if (p < photos) { out.add(x); p++ }
            Part.File -> if (f < files) { out.add(x); f++ }
        }
        while (p < photos) { out.add(newPlace(out, Part.Photo), Part.Photo); p++ }
        while (f < files) { out.add(newPlace(out, Part.File), Part.File); f++ }
        if (!hasText) out.add(Part.Text)
        return out
    }

    private fun newPlace(layout: List<Part>, part: Part): Int {
        val last = layout.lastIndexOf(part)
        if (last >= 0) return last + 1
        return if (part == Part.File) layout.lastIndexOf(Part.Photo) + 1 else 0
    }

    /** The text to store. The usual order is stored as nothing at all, so scraps nobody arranged stay exactly as they were. */
    fun encode(layout: List<Part>, photos: Int, files: Int): String {
        val full = fit(layout, photos, files)
        return if (full == default(photos, files)) "" else full.joinToString(",") { it.name }
    }

    /** [layout] without the n-th photo (or file), for when that one is removed from the scrap. */
    fun without(layout: List<Part>, part: Part, n: Int): List<Part> {
        var seen = 0
        val i = layout.indexOfFirst { it == part && seen++ == n }
        return if (i < 0) layout else layout.toMutableList().also { it.removeAt(i) }
    }

    /** The place in [layout] of the n-th photo (or file), or -1. */
    fun slotOf(layout: List<Part>, part: Part, n: Int): Int {
        var seen = 0
        return layout.indexOfFirst { it == part && seen++ == n }
    }

    /** How many places of the same kind come before place [index]: which photo (or file) it is. */
    fun kindIndex(layout: List<Part>, index: Int): Int = layout.subList(0, index).count { it == layout[index] }

    /** The stretches of neighbouring photos, neighbouring files and the text, from the top down. */
    fun runs(layout: List<Part>): List<Run> {
        val out = ArrayList<Run>()
        var photo = 0; var file = 0; var i = 0
        while (i < layout.size) {
            val part = layout[i]
            var j = i + 1
            if (part != Part.Text) while (j < layout.size && layout[j] == part) j++
            val first = when (part) { Part.Photo -> photo; Part.File -> file; Part.Text -> 0 }
            out.add(Run(part, i, first, j - i))
            if (part == Part.Photo) photo += j - i else if (part == Part.File) file += j - i
            i = j
        }
        return out
    }

    /**
     * Takes the place at index [from] and puts it into the gap number [gap]. Gaps are counted in the list as it is now: 0 is above the first place,
     * the size of the list is below the last one. Null when that changes nothing.
     */
    fun moveResult(layout: List<Part>, from: Int, gap: Int): Moved? {
        if (from !in layout.indices || gap < 0 || gap > layout.size || gap == from || gap == from + 1) return null
        val part = layout[from]
        val fromKind = kindIndex(layout, from)
        val out = layout.toMutableList()
        out.removeAt(from)
        val to = if (gap > from) gap - 1 else gap
        out.add(to, part)
        return Moved(out, part, fromKind, kindIndex(out, to))
    }

    // ----- the groups of the Arrange page sheet: all photos, all files, the text

    /** The kinds of things the scrap has, in the order their first place comes. The text is always one of them. */
    fun groups(layout: List<Part>): List<Block> =
        layout.map { when (it) { Part.Photo -> Block.Photos; Part.File -> Block.Files; Part.Text -> Block.Text } }.distinct()

    /** The page with each group together, in the given order. (Arranging by group puts photos and files back together.) */
    fun regroup(order: List<Block>, photos: Int, files: Int): List<Part> {
        val out = ArrayList<Part>()
        for (b in order) when (b) {
            Block.Photos -> repeat(photos) { out.add(Part.Photo) }
            Block.Files -> repeat(files) { out.add(Part.File) }
            Block.Text -> out.add(Part.Text)
        }
        return fit(out, photos, files)
    }

    // ----- dragging a photo or file to a new place

    /**
     * The gap (see [moveResult]) closest to a finger at [x], [y] while a [dragged] photo or file is being carried. [cells] say where each place of
     * [layout] is on screen (null for one that is not drawn). Rules: over a file or the text, the upper half is above it and the lower half below it;
     * over a row of photos, a dragged photo joins the row (left or right of the photo under the finger) unless the finger is near the row's top or
     * bottom edge, and anything else goes above or below the whole row.
     */
    fun dropGap(layout: List<Part>, cells: List<Cell?>, dragged: Part, x: Float, y: Float): Int {
        if (layout.isEmpty() || cells.size != layout.size) return 0
        class Band(val start: Int, val end: Int, val part: Part, val top: Float, val bottom: Float)
        val bands = ArrayList<Band>()
        var i = 0
        while (i < layout.size) {
            var j = i + 1
            if (layout[i] == Part.Photo) while (j < layout.size && layout[j] == Part.Photo) j++
            val seen = (i until j).mapNotNull { cells[it] }
            if (seen.isNotEmpty()) bands.add(Band(i, j, layout[i], seen.minOf { it.top }, seen.maxOf { it.bottom }))
            i = j
        }
        if (bands.isEmpty()) return layout.size
        if (y < bands.first().top) return bands.first().start
        val b = bands.firstOrNull { y < it.bottom } ?: return bands.last().end
        if (y < b.top) return b.start
        if (b.part == Part.Photo && dragged == Part.Photo) {
            val h = b.bottom - b.top
            if (y < b.top + h / 4f) return b.start
            if (y > b.bottom - h / 4f) return b.end
            for (k in b.start until b.end) {
                val c = cells[k] ?: continue
                if (x < c.centerX) return k
            }
            return b.end
        }
        return if (y < (b.top + b.bottom) / 2f) b.start else b.end
    }

    /**
     * Where to draw the line that shows a drop at [gap]: an upright line (left == right) between two neighbouring photos, otherwise a flat one
     * (top == bottom) between the places above and below. Null when nothing is drawn near it.
     */
    fun dropLine(layout: List<Part>, cells: List<Cell?>, gap: Int): Cell? {
        if (cells.size != layout.size) return null
        val before = if (gap > 0) cells.getOrNull(gap - 1) else null
        val after = cells.getOrNull(gap)
        if (before != null && after != null && layout[gap - 1] == Part.Photo && layout[gap] == Part.Photo) {
            val x = (before.right + after.left) / 2f
            return Cell(x, minOf(before.top, after.top), x, maxOf(before.bottom, after.bottom))
        }
        val y = when {
            before != null && after != null -> (before.bottom + after.top) / 2f
            after != null -> after.top
            before != null -> before.bottom
            else -> return null
        }
        return Cell(0f, y, 1f, y)
    }
}

/** The list with the item at [from] moved to [to] (an index in the result). */
fun <T> List<T>.movedItem(from: Int, to: Int): List<T> =
    if (from !in indices || to !in indices || from == to) this else toMutableList().also { it.add(to, it.removeAt(from)) }
