package app.scrapbook

// Code blocks, code spans and links: the rules, kept apart from the screens so they can be tested on their own.
// The saved text is plain Markdown. A fenced block is a line with ``` (and an optional language word), the code, and a line with ```.

/** Where a line sits relative to a fenced code block. */
object CodeLine { const val NONE = 0; const val OPEN = 1; const val BODY = 2; const val CLOSE = 3 }

private val FENCE_OPEN = Regex("^```[\\w+#.-]*\\s*$")

/**
 * For every line: NONE, or OPEN / BODY / CLOSE when it belongs to a fenced block. A fence without a partner does not start a block, so the
 * rest of the note is never swallowed while you are still typing the closing fence.
 */
fun codeLineStates(lines: List<String>): IntArray {
    val st = IntArray(lines.size); var i = 0
    while (i < lines.size) {
        if (FENCE_OPEN.matches(lines[i])) {
            var j = i + 1
            while (j < lines.size && lines[j].trimEnd() != "```") j++
            if (j < lines.size) {
                st[i] = CodeLine.OPEN; for (k in i + 1 until j) st[k] = CodeLine.BODY; st[j] = CodeLine.CLOSE
                i = j + 1; continue
            }
        }
        i++
    }
    return st
}

/** The code state of the line the offset is on. */
fun codeStateAt(text: String, offset: Int): Int {
    val idx = text.take(offset.coerceIn(0, text.length)).count { it == '\n' }
    return codeLineStates(text.split("\n")).getOrElse(idx) { CodeLine.NONE }
}

/** `code` inside a line. */
val CODE_SPAN = Regex("`([^`\\n]+)`")

/** The line with every code span (backticks included) blanked out to "x", same length, so other formatting is never found inside code. */
fun maskCodeSpans(line: String): String {
    if ('`' !in line) return line
    val sb = StringBuilder(line)
    for (m in CODE_SPAN.findAll(line)) for (k in m.range) sb.setCharAt(k, 'x')
    return sb.toString()
}

/** The text with every fenced block and every code span blanked out to "x" (same length, line breaks kept), so nothing found by looking at the text, like #hashtags, is found inside code. */
fun maskCode(text: String): String {
    if ('`' !in text) return text
    val lines = text.split("\n"); val st = codeLineStates(lines)
    return lines.indices.joinToString("\n") { if (st[it] != CodeLine.NONE) "x".repeat(lines[it].length) else maskCodeSpans(lines[it]) }
}

val MD_LINK = Regex("\\[([^\\]\\n]+)\\]\\(([^)\\s]*)\\)")
private val BARE_URL = Regex("(?:https?|scrapbook)://\\S+")

/** A web address without its trailing punctuation. */
fun trimUrl(raw: String): String = raw.trimEnd('.', ',', ';', ':', '!', '?', ')', '"', '”', '\'')

/** Web addresses written out in a line (not the ones inside a [text](url) link). The line should have its code spans masked already. */
fun bareUrlRanges(line: String): List<IntRange> {
    val links = MD_LINK.findAll(line).map { it.range }.toList()
    return BARE_URL.findAll(line).mapNotNull { m ->
        if (links.any { it.first <= m.range.last && m.range.first <= it.last }) return@mapNotNull null
        val url = trimUrl(m.value)
        if (url.length <= url.indexOf("://") + 3) null else m.range.first until m.range.first + url.length
    }.toList()
}

/** A link under the caret: its address, the text people read as saved offsets, and whether it is a [text](url) link (which can be edited) or a bare address. */
data class LinkSpot(val url: String, val label: IntRange, val markdown: Boolean)

/** The link the caret is in or touching, or null. Nothing in a code block or a code span counts. */
fun linkSpotAt(text: String, caret: Int): LinkSpot? {
    val c = caret.coerceIn(0, text.length)
    if (codeStateAt(text, c) != CodeLine.NONE) return null
    val ls = text.lastIndexOf('\n', c - 1) + 1
    val le = text.indexOf('\n', c).let { if (it < 0) text.length else it }
    val raw = text.substring(ls, le); val line = maskCodeSpans(raw); val pos = c - ls
    for (m in MD_LINK.findAll(line)) {
        val from = m.range.first + 1; val to = from + m.groupValues[1].length
        if (pos in from..to) { val u = m.groups[2]!!.range; return LinkSpot(raw.substring(u.first, u.last + 1), (ls + from) until (ls + to), true) }
    }
    for (r in bareUrlRanges(line)) if (pos in r.first..(r.last + 1)) return LinkSpot(raw.substring(r.first, r.last + 1), (ls + r.first) until (ls + r.last + 1), false)
    return null
}

/** A change to the text and where the selection ends up. */
data class MarkupEdit(val text: String, val start: Int, val end: Int)

/** True when the selection is inside a `code span`. */
fun inCodeSpan(text: String, a: Int, b: Int): Boolean {
    if (a < b) return a >= 1 && b < text.length && text[a - 1] == '`' && text[b] == '`' && '`' !in text.substring(a, b)
    val ls = text.lastIndexOf('\n', a - 1) + 1; val le = text.indexOf('\n', a).let { if (it < 0) text.length else it }
    return CODE_SPAN.findAll(text.substring(ls, le)).any { a in (ls + it.range.first + 1)..(ls + it.range.last) }
}

/**
 * The Code button for words inside a line. Selected text gets backticks around it, or loses them if it already has them. With nothing selected,
 * the caret inside a code span removes that span's backticks; anywhere else it types a pair and waits between them. Null when it cannot apply (several lines).
 */
fun toggleCodeSpan(text: String, a: Int, b: Int): MarkupEdit? {
    if (a < b) {
        val inside = text.substring(a, b)
        if ('\n' in inside) return null
        if (inCodeSpan(text, a, b)) return MarkupEdit(text.removeRange(b, b + 1).removeRange(a - 1, a), a - 1, b - 1)
        if ('`' in inside) return null
        return MarkupEdit(text.substring(0, a) + "`" + inside + "`" + text.substring(b), a + 1, b + 1)
    }
    val ls = text.lastIndexOf('\n', a - 1) + 1; val le = text.indexOf('\n', a).let { if (it < 0) text.length else it }
    for (m in CODE_SPAN.findAll(text.substring(ls, le))) {
        val s0 = ls + m.range.first; val e0 = ls + m.range.last + 1
        if (a in (s0 + 1)..(e0 - 1)) return MarkupEdit(text.removeRange(e0 - 1, e0).removeRange(s0, s0 + 1), a - 1, a - 1)
    }
    return MarkupEdit(text.substring(0, a) + "``" + text.substring(a), a + 1, a + 1)
}

/**
 * The Code block button. In a block it takes the fences away and keeps the code. Selected lines get a block around them. On an empty line it makes
 * an empty block with the caret inside; on a line with text it starts a new block below that line.
 */
fun toggleCodeBlock(text: String, a: Int, b: Int): MarkupEdit {
    val lines = text.split("\n"); val st = codeLineStates(lines)
    val starts = IntArray(lines.size); var o = 0
    for (i in lines.indices) { starts[i] = o; o += lines[i].length + 1 }
    fun lineOf(off: Int): Int { var i = 0; while (i + 1 < lines.size && starts[i + 1] <= off) i++; return i }
    val la = lineOf(a); var lb = lineOf(b)
    if (st[la] != CodeLine.NONE) {
        var open = la; while (st[open] != CodeLine.OPEN) open--
        var close = la; while (st[close] != CodeLine.CLOSE) close++
        val sb = StringBuilder(text)
        sb.delete(starts[close] - 1, starts[close] + lines[close].length)   // the line break before the closing fence, and the fence
        val cut = lines[open].length + 1
        sb.delete(starts[open], starts[open] + cut)                         // the opening fence and its line break
        val na = (if (a >= starts[open] + cut) a - cut else starts[open]).coerceIn(0, sb.length)
        return MarkupEdit(sb.toString(), na, na)
    }
    if (b > a && lb > la && starts[lb] == b) lb--    // a whole line picked by triple tap ends at the start of the next one
    val ls = starts[la]; val le = starts[lb] + lines[lb].length
    if (a == b && lines[la].isNotBlank()) return MarkupEdit(text.substring(0, le) + "\n```\n\n```" + text.substring(le), le + 5, le + 5)
    if (a == b) return MarkupEdit(text.substring(0, ls) + "```\n\n```" + text.substring(le), ls + 4, ls + 4)
    val content = text.substring(ls, le)
    return MarkupEdit(text.substring(0, ls) + "```\n" + content + "\n```" + text.substring(le), ls + 4, ls + 4 + content.length)
}
