# Scrapbook (v0.1)

A personal notes and archive app for Android: notes, quotes, links and photos with eight page layouts,
collections, search, a Rediscover swipe, per-page styling, a Settings page (theme, white or soft grey background,
accent, lists, boxes, backup/restore; seven box styles: Tabbed, Paper stack, Tinted tiles, Folder tabs, Chips, List rows, Notebook covers; and five looks for the Boxes screen: Default, Nested, Shelf, Cover, Stack), an About page (version, What's new, feedback, licenses, and links to the other apps in the family), a home-screen widget, and sharing into the app from other apps. The app reopens in the box you were last in (switch off in Settings). Deleted scraps go to a Bin for 30 days (Menu, then Bin) and every scrap keeps earlier versions of its text (3-dot menu, then Version history); every scrap can have its own icon, accent, page color, cover and layout (3-dot menu, then Page style), and its card in the lists is dressed to match (`NoteRow` and `NoteTile` in `ui/Home.kt`); both are plain Room tables, see `Versions.kt` for the rules.

## Get it on your phone

**Easiest, no tools to install (GitHub):**
1. Create a GitHub repository and push this folder to it (branch `main`).
2. Do the one-time key setup in `SIGNING.md` (about 10 minutes). This is what lets every new version
   install over the old one without deleting the app.
3. Open the repo's **Actions** tab, open the latest **Android CI** run, and download the
   `scrapbook-release-apk` artifact (a zip containing `app-release.apk`).
4. Copy the APK to your phone and open it. Android will ask you to allow installing from that source.

**With Android Studio:** open this folder, let Gradle sync, plug in a phone (USB debugging on) or start an
emulator, and press Run.

**From a phone, with a zip:** keep one zip of the whole project at the top of the repo, plus
`.github/workflows/scrapbook-zip.yml`. Uploading a new zip starts **Scrapbook (from zip)**, which unpacks it and builds
the signed APK (same key setup, see `SIGNING.md`). If there is more than one zip, the one uploaded last is built.

`scrapbook-debug-apk` is also built and signed with the same key, but use the release one day to day.
**App icon:** a glass-pages icon in seven colors, one per accent (Coral, Teal, Amber, Violet, Green, Pink, Blue). The launcher entry is an
`<activity-alias>` per accent in `AndroidManifest.xml` (`.IconCoral` and so on); `AppIcon.kt` enables the one that matches the accent when the app
is left, and Settings has an "Icon matches accent" switch. To add an accent, add it to `Themes`, to `AppIcon.names`, and add an alias plus
`ic_launcher_<name>.xml` and `ic_launcher_bg_<name>.xml` (a unit test checks the lists agree).
**Motion:** `ui/Motion.kt` holds the small animation helpers (`pressScale`, `appear`); screen transitions are set on the `NavHost` in `MainActivity.kt`.

Fonts: see `FONTS.md`. Widget: long-press your home screen, Widgets, Scrapbook.
