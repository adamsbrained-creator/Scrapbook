Scrapbook — UI Overhaul (UIO) Development Log

Project: Scrapbook
Milestone: UI Overhaul (UIO)
Status: In progress
Base: Quality of Life update (scrapbook-QOL-88)

Goal: a complete overhaul of the app's look, with more customization, built section by section.
Entries are added in the order they are built. Each one says what the feature is for and what was built.

———

Section: Home

☑ 1. New greeting: account system (Scrapbook-UIO-1)
   For: the greeting needs to know who it is talking to, and the app needs a place for the person behind it.
   Built: an Account with name, nickname, a line about you, pronouns, birthday (no year) and a profile picture (photo, or initial on a chosen color).
   Stored only on this phone. New Account page, an account card at the top of Settings, a profile icon, picture cropping and saving (Avatar.kt).

☑ 2. More greeting options and views: greeting lines and settings (Scrapbook-UIO-1)
   For: a greeting that feels alive instead of the same line every day.
   Built: 170+ greetings across time of day (late night to night), weekdays, casual lines, lines about your scraps (Inbox, pinned, empty, large archive)
   and birthday / New Year's Day lines, in friendly, playful and calm voices. {name} drops out neatly when no name is set. The greeting changes by itself
   (never, 10, 20, 40 or 90 seconds), on every tap, and avoids repeating recent lines. New Settings > Greeting page: show or hide, show my picture,
   line under the greeting (date, about me, scrap count, nothing), change interval, tone, and switches for time-of-day, casual and scrap-related lines.
   The greeting on Home now uses the account's name and picture; tapping the picture opens the Account page.

☑ 3. Greeting: smaller by default, text and picture resize freely (Scrapbook-UIO-1.5)
   For: the greeting took too much room at the top of Home, and everyone wants a different size.
   Built: the greeting now starts smaller (text 24, picture 44 instead of 30 and 56). Settings > Greeting has a live preview and two sliders:
   Text size (14 to 44) and Picture size (20 to 96). The preview follows the slider while you drag, and the size is saved when you let go.
   The line under the greeting scales with the text, and a small picture still has a 44dp touch area.

☑ 4. Account card moved down in Settings (Scrapbook-UIO-1.5)
   For: the account card at the very top pushed the settings down; it belongs with the About page.
   Built: the account card now sits right above the About page, below the list of settings pages.

☑ 5. Greeting options moved into Customize home (Scrapbook-UIO-1.6)
   For: every part of Home is meant to keep its own options next to where it is moved and hidden, so the greeting's settings belong there and not in Settings.
   Built: a row in Customize home can now have a sliders button (and tapping its name does the same) that opens that part's own options page; the Greeting row has one.
   The page keeps the live preview pinned on top and holds text size, picture size, show my picture, the line under the greeting, how often it changes, the tone and the
   three switches for the kinds of lines. The Greeting page in Settings is gone (the Account card stays). Showing or hiding the greeting is still the eye on its row.
   Other parts can get their own options the same way (withOptions and options in HomeCustomize, ui/GreetingOptions.kt).

☑ 6. Home layout: move and hide every part (Scrapbook-UIO-2)
   For: Home should look the way you want it: any part can go anywhere, or be switched off.
   Built: Home is now made of eight parts (Header, Greeting, Quick capture, Continue, To sort, Boxes, Pinned, Recent), each with a place in the order and an on/off switch.
   New Customize home in the Home menu: one short row per part with a drag handle (hold and drag to move it) and an eye (tap to hide or bring it back), a Back to the usual order
   button, and Move up / Move down actions for screen readers. Hidden parts keep their place. The order and the hidden parts are saved on this phone (HomeLayout.kt, ui/HomeEdit.kt).
   Home reads the saved layout and draws its parts in that order. The old "Show greeting" and "Show boxes on home" switches in Settings now use the same on/off state,
   and an update keeps whatever they were set to. With the header hidden, a small menu button stays so the menu can always be reached.

☑ 7. Optional designs for the parts of Home (Scrapbook-UIO-3)
   For: every part of Home can look the way you like, but only if you want it to. Nothing changes until a design is chosen; each part keeps its classic look by default.
   Built: the sliders button on a row in Customize home now opens an options page for Capture, Continue, Boxes, Pinned and Recent as well (the Greeting already had one).
   Each page has a preview of the real part with your own scraps on top, one segmented choice per design under it with a line saying what it looks like, and a
   Back to the classic look button once something is chosen. The row in Customize home shows the chosen design under the name.
   Designs: Greeting (classic, centered, on a card; picture left or right, next to its size sliders), Quick capture (classic, slim one line, icons only),
   Continue (classic, thin line, with a preview of the text), Boxes (chips, grid of two columns, list), Pinned (cards in a row in three sizes, list, grid of two columns),
   Recent (cards, compact lines; 3, 4, 6 or 8 scraps). The choices are saved on this phone (HomeStyles.kt, ui/HomeDesignOptions.kt, the part designs in ui/HomePage.kt).

☑ 8. Home settings moved into Customize home (Scrapbook-UIO-3.1)
   For: every part of Home keeps its own settings next to where it is moved, hidden and styled, so Settings no longer holds the ones that are only about Home.
   Built: the Header row in Customize home now has a sliders button too. Its page has a preview of the real header and two choices, Layout (left, center, round) and Size
   (compact, regular, large), which used to be "Main page header" and "Header size" in Settings. Quick capture's page gets the Add button choice (pill, bottom bar, writing bar,
   one button an arc, swipe-up sheet). Boxes' page gets the switch that orders the boxes by activity. They are the same settings as before and keep their values; the header and
   the add button still apply to the other main pages. "Show boxes on home" is gone from Settings (it is the eye on the Boxes row, as the greeting's switch was before it).
   Settings keeps the lists settings (default view, sorting, box style, note preview) and gets a Customize home row on the Home and lists page that opens Customize home;
   searching Settings for header, add button or order of boxes finds it. The About page's tips for the add button styles now say where to find them.

☑ 9. Hold menus on Home (Scrapbook-UIO-4)
   For: every box and scrap on Home needs its actions one touch away, without opening it first.
   Built: hold a box, a scrap (pinned, recent or the Continue card), a part's title (Boxes, Pinned, Recent) or the greeting, and when you let go a small pop-up menu opens next to it.
   Boxes: open, new scrap here, edit, new box inside, add to a section, delete (Inbox has its own short list: sort, color, remove). Scraps: open, pin or unpin, add to a box,
   add to a section, tags, duplicate, delete. A part's title: move up, move down, hide, Customize home. The greeting: Customize home, Account. It works in every design of
   every part, and holding a recent scrap now opens this menu instead of asking to delete it right away (ui/HomeGestures.kt, HeldScrap and HeldBox in the designs of ui/HomePage.kt).

☑ 10. Hold and drag to carry things over the whole page (Scrapbook-UIO-4)
   For: moving something should not stop at the edge of its own row.
   Built: keep holding a box or a scrap and move: it lifts, follows your finger over the whole page (not clipped by its row) and the page scrolls by itself near the top and
   bottom edge. While you carry it, the place it would land is marked: a frame around a box or a section, or a bar with "New section here" between two parts. One listener
   watches the whole page, so a tap or a scroll is never affected and a carried thing is not lost when the page scrolls under it (HomeDrag, dragHost, DragOverlay).
   Letting go on the place it came from does nothing.

☑ 11. Sections made by dropping (Scrapbook-UIO-4)
   For: a row of Home that is entirely yours: a few scraps and boxes you want together, wherever you want them.
   Built: drop a carried scrap or box on an empty spot of Home and a new section appears right there, holding it. A section has a name, one of four layouts (cards, chips,
   rows, grid) and whatever you put in it: drop more things on it, or open Edit (tap the word, or hold the title) to rename it, change the layout, take things out and add boxes
   and scraps from a list with search. Hold the title to move the section up or down, or delete it. Things inside a section can be held and carried too: to another section,
   to a box, or into the open for a new section. A section only holds shortcuts: taking something out or deleting a section never touches a scrap or a box. "Add to a section"
   in a hold menu does the same without dragging. Every drop can be undone from the message that appears. Saved on this phone (HomeSections.kt, ui/HomeSectionsUi.kt; test HomeSectionsTest).

☑ 12. Drop a scrap on a box to file it (Scrapbook-UIO-4)
   For: sorting a scrap into a box in one move, right from Home.
   Built: carry a scrap onto a box (in the Boxes row, in any of its designs, or inside a section) and let go: the box gets a frame while you are over it, and the scrap is
   moved into it, with a message to undo. Dropping on the box it is already in does nothing.

☑ 13. Gestures switches in Customize home (Scrapbook-UIO-4)
   For: hold and drag are new, so each one can be switched off.
   Built: under the list of parts in Customize home, a Gestures group with three switches: hold for a menu, hold and drag to move, drop a scrap on a box to file it.
   All on by default. With the menu off, holding a recent scrap asks to delete it again, as before (GesturePrefs, saved as gesture_hold, gesture_drag and gesture_file).


☑ 14. Menus overhaul: skins, arranging and a new skin (Scrapbook-UIO-5)
   For: the menu and the small windows of the app should be changeable: how they look, what the menu holds and in what order (item 5 of the Home list).
   Built: a menu system. One skin is worn by the Home menu and by every sheet, pop-up menu and group of rows in the app (MenuSkins.kt); Classic is the look the app had, and a new
   skin, Float, is built after the two references: a floating card with a centered title, outlined groups with a name on top (Browse, Discover, Manage), icon tiles, Cancel and the
   action side by side, a line under the buttons ("128 scraps · 12 boxes · all on this phone"), and an option to show the main button as a floating pill. On top of any skin:
   row size, icons on or off, how much the page dims, the footer line and the main button style. A new Customize menu page (menu > Customize menu, or Settings > Home and lists)
   has the skin cards with small pictures, the options, Try the menu (the real menu opens over the page), and the menu itself as a list: drag an entry to move it, the eye hides
   it, group breaks split the menu into cards, Back to the usual menu undoes it. Settings can never be hidden. Saved on this phone (MenuLayout.kt, MenuStyle.kt,
   ui/MenuSkins.kt, ui/MenuEdit.kt; tests MenuLayoutTest).
   Outcome: works well; the menu is more minimal now and the options let you build any menu. Ticked as done.

☑ 15. Greeting looks: layouts, background, picture shape, animation (Scrapbook-UIO-1.7)
   For: the greeting should look the way you want, not only sit where you want. This finishes the greeting (item 6 of the Home list).
   Built: the greeting's Style choice in Customize home has three more layouts besides Classic, Centered and Card: Bubble (a chat bubble whose small corner points at your picture,
   with the date under it), Banner (a taller block with a color wash, a bigger greeting and two soft circles) and Minimal (one small quiet line with a tiny picture, no date).
   The styles are shown as small drawings you swipe along. New choices: Background (automatic, none, card, tint, accent, gradient, outline; automatic keeps what each style always had),
   Picture shape (circle, squircle, leaf) and New line appears (fade, slide, typing, pop; typing writes the line out letter by letter). A Back to the classic look button undoes all of them.
   Nothing changes until one is chosen (HomeStyles.kt, ui/GreetingHub.kt, ui/GreetingOptions.kt; test GreetingLooksTest).

☑ 16. The account is part of the backup (Scrapbook-UIO-1.7)
   For: restoring a backup on a new phone should bring back who you are, not only your scraps.
   Built: the manual backup zip now holds account.json (name, nickname, about, pronouns, birthday, picture color) and the profile picture. Restoring only fills in what the phone does not have yet:
   a name, a birthday or a picture that is already set is never overwritten.

☑ 17. Move and zoom the profile picture (Scrapbook-UIO-1.7)
   For: the middle of a photo is not always the part you want.
   Built: choosing a photo now opens a cropper: drag the photo to move it, pinch or use the slider to zoom, and a circle shows what will be kept. Nothing is saved until Use photo.
   The photo is turned upright first and never smaller than the circle. The rules for the cut are in AvatarCrop (Account.kt, ui/AvatarCropper.kt; test AvatarCropTest).
   The cropper fills the screen, so its header sits below the status bar and its slider above the navigation bar (Scrapbook-UIO-1.8).

☑ 18. Skins of Home: wear, make, copy, rename, reset, delete (Scrapbook-UIO-8)
   For: a whole Home you can put on and take off, so you can keep more than one arrangement and switch between them any time (item 3 of the Home list; the first round of the skins update).
   Built: a Skin card at the top of Customize home shows the skin you are wearing and opens the Skins page. Each skin is a card with a small picture of its page (one bar for each part that
   shows, in order, and a tinted bar for each section), its name and what it holds. Tap a skin to wear it: Home changes at once. A skin holds which parts show and in what order, their
   designs, your sections, the header layout and size, the add button, the boxes ordering, and the size and picture of the greeting. Classic, the look Home started with, is always first and
   stays in the list. If your Home already differed from Classic, it is kept as the skin "My home" and worn, so nothing changes when you update. What you change while wearing a skin stays
   with it (it is saved into the skin when you take it off). New skin from this Home makes a copy of the Home you have and wears it, so the one you came from stays as it was. Each skin's
   menu: wear, rename, make a copy, back to the classic look, and delete (not for Classic or the skin being worn; it asks twice). Saved on this phone (HomeSkins.kt, ui/HomeSkinsUi.kt,
   ArchiveViewModel; test HomeSkinsTest). Skins are not part of the backup zip yet.

☑ 19. Sections in Customize home (Scrapbook-UIO-9)
   For: your own sections should be arranged like every other part of Home, not only from their own menu.
   Built: the sections are now rows of Customize home, between the parts, in page order. Each shows its name, its layout and how many things it holds; tap it or the sliders button to
   edit it (the same sheet as on Home), and drag its handle to move it among the parts, or to move a part past it. A section stays after the part that was before it, so moving a part
   never leaves a section behind (HomeSections.reorderSlots, ui/HomeEdit.kt).

☑ 20. Reorder inside a section (Scrapbook-UIO-9)
   For: the things of a section should be in the order you want.
   Built: hold a thing of a section, move it over another thing of the same section and let go: it takes that place and the others make room. The thing it would replace gets a frame
   while you carry it. Works in every layout of a section (HomeSections.reorder, DropTarget.Reorder).

☑ 21. Hold an empty spot to open Customize home (Scrapbook-UIO-9)
   For: the way into Customize home should be on Home itself.
   Built: hold a finger on an empty spot of Home (nothing that can be held, no part or section, and above the strip where the add button is) and Customize home opens, with a small
   vibration (HomeDrag.isEmptyAt, dragHost).

☑ 22. Swipe a recent scrap: right pins, left deletes (Scrapbook-UIO-9)
   For: pinning or throwing away a recent scrap without opening anything.
   Built: a Recent row (the cards and the compact lines) follows the finger over a colored strip with an icon: right shows the star in the accent color and pins the scrap, left shows
   the bin and deletes it. Past the line the strip turns solid and a tick tells you to let go. Deleting shows the usual Undo message, pinning has its own. Both are also actions for
   screen readers (ui/HomeSwipes.kt, SwipeRow).

☑ 23. Quick capture gestures (Scrapbook-UIO-9)
   For: starting a checklist or a voice note straight from Home.
   Built: swipe the quick capture card up: it follows the finger and a small label says when to let go, and letting go past the line opens a new checklist. Hold the card: a new
   scrap opens and starts recording a voice note. It works with the classic, slim and icons-only designs. Dragging up from the card takes the drag, so the page does not scroll with it;
   starting anywhere else, or dragging down, scrolls as always (CaptureGestures).

☑ 24. Double tap the greeting (Scrapbook-UIO-9)
   For: getting back to your work from the top of Home with no extra tap.
   Built: a double tap on the greeting opens the scrap you edited last (the default), Inbox, or nothing, chosen under Gestures in Customize home. The taps still do what they did, so a
   greeting that changes on a tap changes twice (onDoubleTap).

☑ 25. Pull the page down to search (Scrapbook-UIO-9)
   For: search is one gesture away, wherever the page is.
   Built: at the top of Home, pull the page down: a round search button slides in from the top, fills with the accent color once letting go will open search, and a tick tells you when.
   Pulling counts half of the finger's travel, scrolling back takes the pull back first and a fling never counts (PullToSearch, PullIndicator).
   Gestures in Customize home now has a switch for each of 21, 22, 23 and 25, a Jump to choice for 24, and the footer tells how to reorder a section (GesturePrefs).

☑ 26. Swipe a pinned scrap to unpin it (Scrapbook-UIO-10)
   For: taking something off the pinned ones without opening a menu, the same way a recent scrap is pinned.
   Built: in the list design of Pinned, a row follows the finger over a colored strip with an outline star, either way, and past the line it is unpinned (with an Undo message).
   Cards and grid scroll or sit side by side, where a sideways drag belongs to scrolling, so they keep the hold menu (Unpin). It follows the same Gestures switch as the Recent swipe
   (HomeActions.unpin, PinnedDesign).

☑ 27. Hold the search button for recent searches (Scrapbook-UIO-10)
   For: searching for the same thing again without opening search first.
   Built: hold the search button in Home's header and a small menu opens: New search, your last six searches (tap one and search opens with it already typed in, and it moves to the top),
   and Clear recent searches. With none yet it says so. The search button of All scraps stays a plain button (SearchHold, RecentSearchMenu, ArchiveViewModel.pendingQuery, SearchScreen).

☑ 28. Gesture settings per skin (Scrapbook-UIO-10)
   For: a skin is a whole way of using Home, so it can have its own gestures too: a quiet one with everything off, a busy one with everything on.
   Built: a skin now holds the gesture switches and the double tap choice together with the rest of its settings (SkinKeys.GESTURES, GesturePrefs.encode and decode). Wearing a skin puts its
   gestures in; changing them while wearing it stays with it, like every other setting. A skin saved before this has the usual gestures (everything on, double tap to the Continue scrap),
   except the skin you are wearing, which keeps what you have now. The Gestures group in Customize home says the settings belong to the skin worn.


☑ 29. The look of every part: corners, cards, space (Scrapbook-UIO-8.1)
   For: a skin should be able to look different all over, not only arrange the same cards: round or sharp, filled or outlined, close together or far apart.
   Built: a Look card under the Skin card in Customize home opens the Look page: a preview of the quick capture, the Continue card and the boxes stays on top, and three choices change
   every part and section of Home at once. Corners: sharp, soft (as before) or round. Cards: filled (as before), outlined (a thin line), tinted (a wash of your accent color) or flat
   (no card, the content sits on the page). Space between parts: tight, regular (as before) or roomy. Nothing changes until one is chosen. The look belongs to the skin you wear (a new
   skin piece, SkinKeys.LOOK). It is only drawn on Home: the other pages keep the classic look, and scrap cards keep their own colors, with only their corners following the look
   (HomeLook.kt, ui/HomeLookUi.kt: LocalHomeLook and Modifier.homeCard; test HomeLookTest).

☑ 30. Ready-made skins: Minimal, Bold, Dense (Scrapbook-UIO-8.1)
   For: skins that look clearly different from Classic, to start from instead of from nothing.
   Built: a Ready-made list on the Skins page, each with its small picture and a line about it. Tap one and it is added to your skins as a copy and worn (so it can be changed, renamed or
   deleted like any other, and the ready-made one stays in the list). Minimal: thin lines instead of cards, the quiet one-line greeting, slim capture, thin Continue, boxes and pinned as
   lists, three recent scraps as short lines, a compact header, To sort hidden. Bold: round tinted cards, a banner greeting, Continue with a preview, boxes and pinned in a grid, a large
   round header and roomy space. Dense: the greeting hidden, icons-only capture, everything as short lines or a grid, eight recent scraps, sharp corners and tight space.
   They hold no sections and use the usual gestures (HomeReadySkins.kt, ArchiveViewModel.wearReadySkin; test ReadySkinsTest).

☑ 31. Smart sections (Scrapbook-UIO-11)
   For: a section that stays up to date by itself, instead of one you have to fill and keep tidy.
   Built: a section can fill itself with a rule: the scraps with a tag, the scraps in a box (and the boxes inside it), or everything edited in the last week. It shows up to eight, the
   newest edited first, in any of the four layouts, and carries the word Auto beside its Edit. Make one by holding a box and choosing Section of its scraps, by holding a scrap and
   choosing Section for its tag, or by editing any section and choosing Fill automatically; a smart one can go back to Choose the things myself, keeping the scraps it shows. Scraps in it
   can be held and carried to other sections or boxes like any other; nothing can be dropped on it, because it holds nothing of its own. Saved with the section (so it belongs to a skin
   like the rest), as one more field of its line (SectionRule, HomeSections.smartScraps, ui/HomeSectionsUi.kt; tests in HomeSectionsTest).

☑ 32. Hold the add button for a menu (Scrapbook-UIO-11)
   For: starting a checklist, a photo, a link or a voice note straight from the button you already press.
   Built: hold the New scrap button on Home and a small menu opens above it: New scrap, Checklist, Photo, Link, Voice note. Tapping the button still opens an empty scrap. The other add
   buttons already have their own way (the arc button opens on hold, the bottom bar pops the + out, the writing bar has its own + and Record), so this is for the pill; on every other page
   it is just the button (AddHold, used by AddNav).

☑ 33. Gesture hints and the gesture guide (Scrapbook-UIO-11)
   For: the gestures are invisible, so Home has to say they are there.
   Built: the first time, a small card rises above the add button a moment after Home appears ("Try holding something", with Got it and All gestures). It goes for good with Got it, with the
   guide, or with the first hold. The guide is a list of every gesture with how to do it (hold, carry, change the order, hold an empty spot, swipe a scrap, quick capture, the add button, the
   greeting, search, smart sections); it opens from the card and from Gesture guide at the top of Gestures in Customize home (ui/HomeGuide.kt, ArchiveViewModel.gestureHintSeen).

☐ 34. Menus, part 2 (Scrapbook-UIO-7)
   For: everything in the menu should be yours to change or remove, and the menu to be more customizable and polished (the follow-up to item 14).
   Built: nothing in the menu is fixed any more: Settings and Customize menu can be hidden (holding the menu's title opens Customize menu from anywhere, a question comes before the last way in is hidden,
   and the page says so), the New scrap button can be another action (New checklist, photo scrap, voice memo, Search) or none, Close can go, and the title, the card names and the line under
   the buttons can be renamed or hidden. Any entry can be renamed and given another icon. New things in the menu: shortcuts to a box, a scrap, a tag or the Binder app, and group breaks; an
   optional profile header (your picture and name); accent color for icons and buttons. Two new skins, Minimal and Bento. The Customize menu page was rebuilt with three tabs (Look,
   Entries, Setups), a live picture at the top that follows every change, Try the menu, Undo, and Setups: ready-made menus (Classic, Minimal, Everything) and your own saved ones. The menu is kept
   in the backup (menu.txt, menu-presets.txt). The editor's pop-up menus take the skin's corner (MenuLayout.kt, MenuStyle.kt, ui/MenuSkins.kt, ui/MenuEdit.kt, ui/Customize.kt, ui/Home.kt,
   BinderBridge.openBinderApp, MainActivity.menuActions; tests in MenuLayoutTest).

☑ 35. Card sections: text, quote, random scrap, counter, button (Scrapbook-UIO-8.2)
   For: a section no longer has to be a row of shortcuts. A section can be one thing of its own, so a skin can have a note, a line you like, a surprise from your archive, a number or a button.
   Built: an Add a section button in Customize home (under the parts, above Back to the usual order) opens a list of what the new section can be, adds it at the end of Home and opens it for
   editing; move it with the grip like any other. Text card: a note in your own words, shown as it is (tap it to edit). Quote card: lines you like, one on each line; Home shows one a day, in
   turn, and tapping the card shows another. Random scrap: a scrap drawn from all your scraps, or from a tag, a box or this week; a different one every time Home opens, an Another button
   draws again, tapping the scrap opens it. Counter: a big number counting all your scraps, or those with a tag, in a box or edited this week, with a line saying what it counts. Button: a
   button that opens a new scrap in the box you choose (the Inbox if you choose none), with text already written if you want (a checklist can start with - [ ] ). Every card has the same
   title row as other sections (hold it for Edit, Move up, Move down, Delete, or tap Edit), its own look from the skin's Look, and an editor sheet; nothing can be dropped onto a card, and
   a card only points at your things, so deleting one never touches a scrap or a box. Cards are saved with the skin you wear and added to the same saved text as other sections; texts saved
   by earlier versions read back unchanged (HomeSections.kt: SectionCard, matching, count, counterText, pickOne, quoteOf; ui/HomeSectionsUi.kt; test SectionCardsTest).

☑ 36. Skins in the backup (Scrapbook-UIO-8.3)
   For: a new phone, or a restore, should bring your Home back as you made it, not only your scraps.
   Built: the backup zip now holds every Home skin (home-skins.txt), with the worn one as Home is at that moment. Restoring on a phone whose Home is still as new puts the worn skin on and
   adds all the skins; restoring on a phone you have already customized only adds the skins it does not have yet (by name), next to your own, and never changes what Home looks like now.
   Scraps and boxes come back first with the same keys, so sections that point at them still work. Skins from a backup that has none (older backups) are simply skipped
   (ArchiveViewModel export and restore; HomeSkins.merged; test SkinShareTest).

☑ 37. Share a skin as a code, add one from a code (Scrapbook-UIO-8.3)
   For: send a skin to a friend, or move one to another phone, without a file.
   Built: in a skin's menu, Copy as a code to share puts one line of text on the clipboard (it starts with scrapbook-skin-v1:) that any message can carry. On the Skins page, Add a skin from a
   code takes a pasted code (it may sit inside other words), shows what skin it is and adds it next to yours without putting it on; text that is not a code is refused, and a code that is too
   long is not read. A shared skin keeps its look, parts, designs, header, add button, gestures, cards and sections that fill themselves; sections of shortcuts are left out, because they point
   at one phone's scraps and boxes. The added skin gets a name of its own (Night, then Night 2 if that is taken) (SkinShare.kt, ui/HomeSkinsUi.kt, ArchiveViewModel.importSkin; test SkinShareTest).

☑ 38. Sections with no name (Scrapbook-UIO-8.4)
   For: a clean section that is only its cards, chips or one card, without a heading above it. Before, a section with an empty name was called "New section", so a nameless one could not exist.
   Built: every section (shortcuts, smart ones and card sections) has Name on Home in its Edit window: Show the name or No name. With No name the title row is gone and the section is only its content;
   its name is kept for the lists in Customize home, where its row says "no name". Hold the section itself, on a spot that is not one of its things, for the same menu the title gives (Edit, Resize, Move up,
   Move down, Delete). Saved with the section; older saved texts read back unchanged (HomeSection.showTitle, ui/HomeSectionsUi.kt).

☑ 39. Resizable sections (Scrapbook-UIO-8.4)
   For: a section should have the size and shape you give it, not only what its layout decides. The four layouts (Cards, Chips, Rows, Grid) stay as the starting points.
   Built: Resize on Home in a section's menu (hold its title, or the section when it has no name) or in its Edit window starts resizing: a dashed frame and a round handle appear at the bottom-right
   corner of the section, drag it to any width (25 to 100 percent of the page) and height (80 to 900 dp) and tap Done; Automatic size gives the layout its say again, and Back also ends it. Edit has a Size
   part with Automatic or My size and two sliders for the same numbers. A section with a size draws to fit it: Cards are as tall as the box and a little wider than tall, Chips wrap to fill it, Rows stack, the
   Grid takes as many columns as fit and shares the height among its rows, and a card section (text, quote, random scrap, counter, button) fills the box, with a bigger number or quote in a bigger box. What does not
   fit scrolls inside the box. A scrap card shows more of its text the taller it is. Saved with the section (HomeSections.kt: width, height, widthPercent, heightDp, gridColumns, gridCellHeight, cardWidth;
   ui/HomeSectionsUi.kt: SectionFrame, cornerResize; test HomeSectionSizeTest).

☑ 40. Space below a section (Scrapbook-UIO-8.5)
   For: the space between two sections should be yours to set, not only the three steps of the Look page (Tight, Regular, Roomy), which stay as the usual space.
   Built: every section's Edit window has Space below: Automatic (the Look page's space) or My space, with a slider from 0 to 120 dp. It is the space between that section and whatever comes next on Home,
   and it can be tighter than the Look page's space as well as wider (the section only changes the height it reports, so its real place and what can be dropped on it stay as they were). Customize home says
   "own space" on the row. Saved after the size fields, only when set; older saved texts read back unchanged (HomeSection.spaceBelow, HomeSections.spaced, Modifier.moreSpaceBelow; test HomeSectionSizeTest).

☑ 41. Draw gestures: shapes that open things (Scrapbook-UIO-12)
   For: opening a box or a scrap from anywhere, with a shape of your own, without going to Home first.
   Built: draw a shape with two fingers moving together, on any page, and what you bound to it happens. A gesture can open a box (Inbox, Pinned or any box of yours), open a scrap, start a
   new scrap, start a new checklist or open search. A box that is hidden and locked is not among the boxes, so a drawing can never open it; a scrap or box that is gone says so. Boxes are
   remembered by their permanent key and scraps by their uid, so a gesture survives renaming and a backup restore. How shapes are compared (DrawGestures.kt, no Android in it): a line
   becomes 64 evenly spaced points, centered and scaled, so where and how big it was drawn does not matter, but how it was drawn does (which end first, which way round); two shapes are alike
   from the average distance of their points. It counts as a gesture from 80% alike, and only if clearly more than the next one (4 points), so two look-alikes are never mixed up.
   Saved as one line per gesture (DrawGestures.encode and decode; tests in DrawGesturesTest).

☑ 42. Two fingers, on every page (Scrapbook-UIO-12)
   For: one finger already means tap, scroll and swipe everywhere, so drawing needs a gesture of its own that never gets in the way.
   Built: one listener around all the screens (DrawGestureLayer, in MainActivity) watches for two fingers that land together and then travel together, keeping their distance. Anything else is
   left completely alone: a finger that moves first is a scroll, two fingers that pinch or turn are a zoom (full-screen photos are a separate window and never see it), and nothing is
   touched until it is clear. While drawing, a line in the accent color follows the middle of the two fingers; when they lift, a match gives a small buzz and says what it was, no match gives a
   lighter tick and says so. It is off while the app is locked, on the Draw gestures page and on the account page (whose photo cropper moves with two fingers), and when no gesture
   has been taught, so nothing changes for anyone who does not use it.

☑ 43. The Draw gestures page (Scrapbook-UIO-12)
   For: teaching a shape, trying it and managing the ones you have.
   Built: Settings > Home and lists > Draw gestures, and a row at the top of Gestures in Customize home. An on/off switch; Try it, a pad to draw on with one finger that says which gesture
   it is and how alike (and, if none, the closest and what it needed); the list of your gestures, each with a picture of its shape, what it opens and a delete button; and Add a gesture:
   draw the shape three times (a try that looks nothing like the first is refused and a short one is asked again), then choose what it opens. A shape too close to one you already have is
   refused, so the two are never mixed up. The gesture guide on Home has a line for it (ui/DrawGestureUi.kt).

☐ 44. More layouts for sections (Scrapbook-UIO-13)
   For: Edit section had four layouts (Cards, Chips, Rows, Grid); sections of boxes, scraps and smart sections needed more ways to look.
   Built: eight new layouts, for boxes, scraps and sections that fill themselves alike: Carousel (big cards that stop on each one), Hero (the first thing big, the rest as small cards under
   it), Banner (wide tinted bands with a big title), Mosaic (two columns of cards as tall as their text), Tiles (small squares, three or more across), Timeline (a line with a dot for each
   thing), Lines (a plain list with thin lines, no cards) and Compact (two columns of slim rows). Edit section now shows all twelve as small pictures, with a line about the chosen one.
   Holding and carrying things, the menus on hold and dropping a scrap on a box work in every layout; Resize works too: with a height of its own a layout scrolls (or fills it) inside the
   box. A layout is saved by its name, so skins and backups keep it, and an older version shows an unknown one as Cards (SectionLayout, SectionShapes.kt, ui/SectionLooks.kt, the picker in
   ui/HomeSectionsUi.kt; test SectionShapesTest).

☐ 45. Stack taken out of the lists (Scrapbook-UIO-13.1)
   For: the Stack layout of the lists (All scraps and every box) is not wanted.
   Built: Stack is gone from the layout picker of the lists and from Settings > Default view, with its drawing code and icon (ListLayouts.kt, Icons.kt). A page or a default view that was
   set to Stack opens as Cards. The Stack look of the Boxes screen (Nested, Shelf, Cover, Stack) is a different thing and is untouched.

☐ 46. The hold menus stay where they open (Scrapbook-UIO-13.2)
   For: holding the greeting on Home and tapping Customize home: the menu opened on the right and, a moment later, jumped to the left.
   Built: a held thing grows a little (5%) and the menu was anchored to that growing box, so its edge was a few pixels off screen and the menu was put on the right; when the finger let go
   the box shrank and the menu moved. The menu is now anchored to the box around it, which does not grow, so it opens in its place and stays there. This is for every hold menu on Home
   (the greeting, scraps, boxes, section titles, parts), since they share HoldSlot (ui/HomeGestures.kt: holdSpot and liftOnHold, which pickUp now joins).


☑ 52. Accent color and page tint for Home (Scrapbook-UIO-8.6)
   For: a skin should be able to look different in color, not only in shape.
   Built: the Look page has two more choices. Accent color: the app's own (as before) or any of the app's accent colors (coral, teal, amber, violet, green, pink, blue), as round swatches. Page tint: none (as
   before), accent (a faint wash of the accent color), warm, cool or rose, in light and in dark mode. They only change Home (its buttons, chips, add button and page), not the rest of the app, and they
   belong to the skin you wear like the rest of the Look, so each skin can have its own. Nothing changes until one is chosen, and looks saved before read back unchanged
   (HomeLook.kt: Tint, Accent; ui/HomeLookUi.kt: rememberHomeTheme, homePageColor; test SkinExtrasTest).

☑ 53. Quick switch: double tap for the next skin (Scrapbook-UIO-8.6)
   For: change the skin without opening Customize home.
   Built: Gestures in Customize home has a new choice for double tapping the greeting: Next skin. It puts on the skin after the one you wear (going round to the first after the last) and tells you which.
   The gestures belong to the skin, so give the same double tap to the skins you want to go round. The gesture guide says so (HomeSkins.following, ArchiveViewModel.nextSkin; test SkinExtrasTest).

☑ 54. Scheduled skins (Scrapbook-UIO-8.6)
   For: Minimal at night, Bold by day: Home changes skin by itself at the times you choose.
   Built: a Schedule card on the Skins page opens a list of times (up to six). Each time has a skin, a From and an Until (in half hours), and the days it applies to; Until earlier than From runs through the
   night into the next morning, and the same time twice is the whole day. Home looks at the clock when it opens and every half minute while it is on screen (not while you are customizing). Going into a time
   puts its skin on and remembers the skin you were wearing; going out of every time puts that skin back; in between, whatever you put on yourself stays on. A time whose skin was deleted does nothing, and
   deleting a time while it is on puts your skin back. Saved on this phone (it is not in the backup, because the skins of a restored backup can have new ids)
   (SkinSchedule.kt, ArchiveViewModel.tickSkinSchedule and setSkinRules, ui/HomeSkinsUi.kt: ScheduleSheet; test SkinScheduleTest).

☐ 47. Home's own parts use the new layouts (Scrapbook-UIO-13.3)
   For: the layouts were built for sections, but Continue, Boxes, Pinned and Recent, the parts Home comes with, could not use them.
   Built: in Customize home, the options of those parts end with the section layouts. Boxes and Pinned: Carousel, Hero, Banner, Mosaic, Tiles, Timeline, Lines and Compact; Recent: the same
   without Compact (it has one already); Continue: Hero and Banner (it is one scrap). They are added after the old designs, so a choice already made, a skin you saved and a backup keep
   their numbers and look the same. Holding things, their menus and carrying work in them as in the old designs; the swipe to pin or delete stays with the list designs. Boxes shows up to
   12 boxes in them and Pinned up to 10 scraps. The choices wrap onto several lines now that there are many (HomeStyles.kt, SectionShapes.kt: PartShapes, ui/SectionLooks.kt: PartShape,
   ui/HomePage.kt, ui/HomeDesignOptions.kt; tests SectionShapesTest and HomeStylesTest).


☐ 48. Holding backspace keeps repeating next to hidden marks (Scrapbook-UIO-13.4)
   For: holding the delete key in the editor sometimes stopped or slowed and had to be tapped over and over.
   Built: backspace right behind a hidden mark (bold, italic, a link, a highlight) used to rewrite the text on every single character, and every rewrite makes the keyboard restart its
   input, which ends the key repeat. It now leaves the cursor in front of those marks after the first delete, so the rest goes through the keyboard's own deleting and the hold keeps
   going; the cursor looks the same on screen (ui/Editor.kt: smartEdit).

☐ 49. Marks never show when the text inside them is deleted (Scrapbook-UIO-13.4)
   For: deleting the last letter of bold, a highlight or a color made the hidden marks appear as plain symbols ("****", "{c:34c759|}").
   Built: when a delete leaves marks with nothing inside, they are taken away with it, one inside the other as well (a color inside a highlight goes completely), so the text just
   disappears. Bold, italic, strikethrough, highlight, color, size and underline (EmptyMarks.kt, ui/Editor.kt: smartEdit; test EmptyMarksTest).

☐ 50. Enter inside formatted text, empty marks in the reading view, Edit after a link (Scrapbook-UIO-13.5)
   For: pressing Enter at the end of a highlighted title left "==" alone on the next line; marks like {c:5e5ce6|} showed in the reading view and in the editor; and Edit in the reading view
   of a scrap you reached by a link opened the editor of the scrap you came from.
   Built: Enter inside bold, italic, strikethrough, highlight, color, size or underline closes the formatting on the line above and opens it again on the new line, from the inside out,
   so at the end of the text the new line simply starts outside it and no mark is ever left alone (EmptyMarks.kt: splitMarksAtBreak, ui/Editor.kt: breakMarksAtEnter). A color, size or
   underline with nothing inside is hidden in the editor like the empty bold already was, and is left out of the reading view and the small previews (withoutEmptyMarks, ui/Pages.kt,
   Share.kt). Edit in the reading view goes back to the editor underneath only when it is the same scrap's, otherwise it opens this one (ui/Pages.kt; test SplitMarksTest).

☐ 51. More ways for marks to show, closed (Scrapbook-UIO-13.6)
   For: a look through the app for anything else that could leave bold, highlight or color marks visible as plain symbols.
   Built: (1) deleting a selection, or typing over it, that takes one end of a bold, highlight or color but not the other no longer leaves the other end behind: what is left of the pair goes
   too (EmptyMarks.kt: replaceHealingMarks, ui/Editor.kt: smartEdit). (2) Bold, italic, strikethrough or highlight on a selection over several lines now gives every line its own pair, leaves list
   marks and empty lines out, and takes them all off again when every line has them (wrapEachLine). (3) The Two Column layout of a one-line scrap no longer cuts a bold or colored run
   between the columns (balancedHalf, ui/Pages.kt). (4) The quick switcher names a scrap without a title from its first line without marks (ui/Switcher.kt). Tests: HealMarksTest, WrapLinesTest.

☑ 55. Skin pictures show the look (Scrapbook-UIO-14)
   For: a skin's small picture on the Skins page should tell skins apart by more than their order of parts.
   Built: the picture now also shows the page tint as its background, the skin's accent color for its sections, how round the bars are, how close together they sit, and whether the cards are filled,
   outlined, tinted or flat (ui/HomeSkinsUi.kt: SkinThumb). A skin without a look is drawn as before.

☑ 56. Undo for deleting or resetting a skin (Scrapbook-UIO-14)
   For: a skin is hours of work; one tap in a menu should not lose it.
   Built: after Delete or Back to the classic look on the Skins page, a bar at the bottom says what happened and offers Undo for seven seconds. Undoing a delete puts the skin back where it was in the list
   with its own id (so a schedule that used it works again), and a name taken in the meantime gets a number; undoing a reset gives the skin its pieces back, and if it is the one worn, Home goes back to them too
   (HomeSkins.restored and withValues, ArchiveViewModel.restoreSkin and restoreSkinValues; test SkinUndoTest).

☑ 57. The ready-made Bold skin on a tinted page; Settings search finds Home's settings (Scrapbook-UIO-14)
   For: the ready-made skins should show what skins can now do, and the Customize home row in Settings should be found by the new words.
   Built: Bold now has a faint wash of its accent color over the page. Searching Settings for skin, schedule, look, corners, cards, space, tint, accent color, quote, counter, button, section or gestures finds the
   Customize home row (HomeReadySkins.kt, ui/Settings.kt).

Outcome: Home (Scrapbook-UIO-1 to 14). Draft: keep it once you say Home is done, or cut it.
   Home went from one fixed page to a page that is yours. Who it greets: a greeting with your name and picture, hundreds of lines, looks and a profile that is part of the backup (1 to 5, 15 to 17).
   How it is built: eight parts you can move, hide and give another design, each with its own options and all of Home's settings in one place, Customize home (6 to 8); sections of your own that you make by
   dropping or in Customize home, that can fill themselves from a tag, a box or this week, that can be a text, a quote, a random scrap, a counter or a button, and that can be resized, reshaped and given room
   (11, 19, 20, 31, 35, 38 to 40, 44, 45). What it feels like: gestures for almost everything, each one with a switch and a guide, shapes you draw, and holds and drags that carry things around the whole page
   (9, 10, 12, 13, 21 to 28, 32, 33, 41 to 43). How it looks: skins, a whole Home you wear, copy, share as a code, keep in the backup, switch with a double tap or by the clock, with a look of their own (corners, cards,
   space, accent color, page tint) and three ready-made ones to start from (18, 29, 30, 36, 37, 52 to 57).
   Still open: Menus, part 2 (34) and the entries marked open above belong to other rounds. Skins and the look only touch Home, not the other pages. The schedule is not in the backup and is read only while Home is
   open. Everything from 8.1 on was written without a compiler to hand, so the build and the phone are the real check.

☐ 58. Holding backspace goes on through checklists, lists, quotes and headings (Scrapbook-UIO-15)
   For: holding backspace on a checklist deleted the text and the circle and then stopped; it had to be pressed again for every line. Numbered lists were fine.
   Built: the circle (or bullet, quote bar, heading mark) of an empty line used to be removed in one go, which is more than the one character the keyboard asked for, and that made
   the keyboard end the held key. Now the keyboard's own one-character deletion is taken as it is and what is left of the mark is hidden, so the hold carries straight on to the line
   above. A new press on that hidden rest still removes it together with the line break, as before, and when nothing follows it goes by itself after a moment. It is never saved
   (ui/Editor.kt: edit, emptyMarkLine, remStart / remText, mdRender).

☐ 59. A brighter highlighter, the same on light and dark pages (Scrapbook-UIO-16)
   For: the "ab" highlight was the accent at a third of its strength, so it looked pale on a light page and dull on a dark one.
   Built: the highlight is now a solid, bright version of the page's accent (vivid, full brightness, and lightened further for deep blues and purples), with dark ink on it, and it is exactly
   the same on light and dark pages, in the editor and in the reading view. Text you colored inside a highlight keeps its own color (ui/Highlight.kt: markerColor, markerStyle,
   ui/Editor.kt, ui/Pages.kt). Searching in a scrap keeps its own marks.

☐ 60. Arrange page only where there is something to arrange (Scrapbook-UIO-17)
   For: Arrange page was in the editor's menu on every scrap, also on ones that are only text, where there is nothing to arrange.
   Built: the entry shows only when the scrap has at least one photo or file. Dragging a single photo or file stays as it was (ui/Editor.kt).

☐ 61. The editor's Details panel is gone; box, tags and kind use the app's own sheets (Scrapbook-UIO-18)
   For: Details was a plain card above the toolbar that never got the look of the rest of the app, and half of it repeated Page style (the page color).
   Built: the 3-dot menu > Page now has Add to box (it names the current box) and Tags (it lists them), each opening the same kind of sheet the reading view uses; Kind is a row in Page style,
   next to the page color that was already there. The Details row, the card and its state are removed. Add to box is the one list of boxes for saved scraps and for the editor
   (ui/Shelves.kt: BoxPickSheet, ui/Customize.kt, ui/Editor.kt).

☐ 62. The Timeline layout, in the new look (Scrapbook-UIO-19)
   For: a timeline that reads like a story of what you did, with icons you choose, and that can be shaped to the page.
   Built: the Timeline layout of a section (and of the parts that use it) now has the look of the mockup: a round dot for each thing with the line fading down between them, the newest dot solid,
   the next one ringed and the rest dim, and beside each dot the title, the date and the start of the text. Each dot shows an icon: the one you chose, else the thing's own emoji, else an icon for
   what it is (note, checklist, photo, link, voice, quote; a box shows a folder in its color). Edit section > Timeline has: how wide it is (50%, 70%, 85%, full) and where it sits when narrower,
   how many things it shows (3, 5, 8, 12 or all), the space between them, the size of the dots, the line (fading, plain or dotted), how much text sits beside a dot, Share the height (every thing
   gets an equal part of the section's height; too many for that and it scrolls), and Icons, a list of the things where each one gets an icon from a set or any emoji you type or paste, or goes back to
   automatic. Saved as one more field at the end of the section's line (SectionStyle, ui/SectionLooks.kt, ui/HomeSectionsUi.kt; tests in SectionStyleTest).

☐ 63. Fill the page (Scrapbook-UIO-19)
   For: one big section that uses the whole screen, instead of a row among others.
   Built: Edit section > Size has a third choice, Fill the page, for any layout: the section is as tall as the page has room for under what is above it (the page measures every block above and
   the space between them, and keeps the strip the add button needs), and its things scroll inside it when there are more. Its width stays its own choice. It follows the page when the layout of
   Home changes, so with other parts hidden it is simply the whole screen (HomeDrag.sizes, HomeEnv.fillFor, SectionStyle.fill).

☐ 64. Where the menu button goes when the header is hidden (Scrapbook-UIO-19)
   For: a header that is hidden used to leave a menu button at the left, always.
   Built: Customize home > Header has Menu button when the header is hidden: Left (as before), Right, or None. With None the page has no button of its own; the menu is still one hold away: the
   greeting's hold menu now starts with Menu, and holding an empty spot opens Customize home, where it can be put back (HomeStyleKey.MenuButton, MenuOnlyHeader).

☐ 65. A Timeline skin, and a Timeline to add anywhere (Scrapbook-UIO-19)
   For: the whole of Home as one big timeline in one tap, and the same timeline as a piece you can put in any skin of your own.
   Built: Skins has a new ready-made skin, Timeline: the header and a quiet greeting, every other part hidden, and one section that fills itself with this week's scraps, fills the page and shares its
   height between the dots. It is an ordinary section, so it can be edited like any other (its icons, width, the number of things) and the skin changes like any skin. To use the same element in a skin of
   your own, Customize home > Add a section > Timeline adds one (this week's scraps, in the Timeline layout) at the end of the page, to be moved, resized or set to fill the page; any section can also
   be given the Timeline layout (HomeReadySkins.timeline, SectionOps.addTimeline).

☐ 66. Only the Classic page layout is left (Scrapbook-UIO-19)
   For: the other page layouts (Journal, Gallery, Quote, Two columns, Blank canvas and the rest) were built at the very start and never grew up with Classic; they are removed so new ones can be
   built from Classic, from scratch, later.
   Built: Classic is the only page layout. Scraps saved with a layout that is gone are shown as Classic, with their text, photos and everything else as it was (the layout was only a view; the
   old name is read as Classic in the database and in backups). The Change layout rows and the Layout chips in Page style are hidden while there is only one layout, and come back by themselves
   when a second one is added. The Home list, previews, the reading view and the demo scraps lose their per-layout branches. The Canvas data column stays in the database, unused, so nothing
   needs migrating (Model.kt, Data.kt, ui/Pages.kt, ui/Home.kt, ui/Screens.kt, ui/Editor.kt, ui/Customize.kt; tests in ConvertersTest).

☐ 67. The app's icon is yours to choose: four icons, normal or glassy (Scrapbook-UIO-20)
   For: the launcher icon used to be one picture that took the accent color. Now you pick the icon itself.
   Built: Look & Feel has an App's icon row (a small picture of the icon you have, its name and style) that opens a new page. At the top, the icon you have in large; under it a Style choice, Normal or
   Glassy, and a list of the icons, each with its picture drawn in the style you have chosen, so switching the style changes every picture at once. The icons are Scrap| (the app's name in its own font
   with a text cursor), Cut-out S (a letter snipped from a paper strip), Peeling sticky (a sticky note lifting at one corner) and Ripped in two (a scrap of paper torn in two), each in a flat version (white on the
   app's blue) and a glassy one (a navy-to-blue gradient with a glossy rim and beveled silver shape). The glassy Scrap| is the default icon, also for everyone who updates. The new icon shows on your home
   screen when you leave Scrapbook, as the accent icon did, and the page says so. The old icons in seven colors and the Icon matches accent switch are gone; the icon no longer follows the accent color. Each
   icon and style has its own launcher entry, adaptive layers and a themed (monochrome) layer for Android's themed icons (AppIcon.kt, AndroidManifest.xml, res, ui/AppIconScreen.kt; test AppIconTest).

☐ 68. Settings page renamed to Look & Feel (Scrapbook-UIO-20)
   For: the page is called exactly Look & Feel.
   Built: the Settings page that was called Look and feel is now Look & Feel, in the list, in its header and in the About page's description of Settings; its grey line now reads Theme, accent, app icon, haptics.
   Searching Settings for app icon, logo, glassy, wordmark, sticky or ripped finds the App's icon row (ui/Settings.kt, ui/About.kt).

☑ 69. Every part of Home can be resized, and Resize is in the hold menus (Scrapbook-UIO-21)
   For: the sections of your own could already be resized, but the parts that are always there (header, greeting, quick capture, continue, to sort, boxes, pinned, recent) could not.
   Built: every part can be given a width (25 to 100 percent of the page) and a height (80 to 900 dp). A part with a size of its own sits in a frame of that size and is drawn as its design draws it;
   what does not fit scrolls inside the frame. Resize is a new item in the menu you get by holding the title of Boxes, Pinned or Recent and by holding the greeting; it puts a dashed frame and a round
   corner handle on the part, to drag, with Done, Automatic size and Back as for sections. Every row of Customize home now has the sliders button, and its page ends with Size and shape: Automatic or My size
   with two sliders, and Resize on Home, which leads back to Home with the handle. The sizes are part of a skin, so each skin keeps its own, and they go with the share code of a skin like the rest of it
   (HomeSizes.kt, ui/PartSizes.kt: PartFrame and PartSizeSection; cornerResize gained an inset so its handle sits inside the corner of a part at the edge of the screen; test HomeSizesTest).


☐ 70. The app icons fit on the home screen (Scrapbook-UIO-22)
   For: on the home screen the icons were cropped: the letters touched the edges, the glossy rim was missing, and none of them looked like the picture in Settings.
   Built: Android shows only the middle two thirds of an icon's layers under the launcher's shape, and the first layers had their drawing sized for the whole layer. Each icon's foreground is now the
   complete icon (the same picture as in the picker, rim and all), sized to the part that stays visible, and the background carries its own gradient past the edges, so any launcher shape (a rounded
   square, a circle, a squircle) shows the whole drawing with its margins. The single-color layer of Android's themed icons is scaled the same way, so the lettering and shapes sit inside it instead
   of touching the edges (res/drawable-nodpi: ic_<icon>_<glassy|flat>_background, _foreground and _monochrome, for all four icons and both styles).

☐ 71. A simple icon for App's icon in Look & Feel (Scrapbook-UIO-22)
   For: the row looked different from the others in the list, because it showed a picture of the icon in the place of a settings icon.
   Built: App's icon now has a tile with a simple icon of its own (a rounded square with a word and a text cursor), made like the others; the icon you have is still named in grey at the end of the row
   and shown large on the page (ui/Icons.kt: appicon, ui/AppIconScreen.kt).

☐ 72. The editor's bubbles stay out of the way (Scrapbook-UIO-23)
   For: the bubble that appears by selected text (and the one on a link) sometimes stayed over the text you wanted to read, jumped about while a word was being picked, and landed on top of the
   phone's own Copy / Paste bar, so it was in the way of the very word you were trying to select.
   Built: the bubbles wait. While a finger is on the page, the page is scrolling, or the selection or the text has just changed, nothing is shown; about half a second after everything is still
   the selection bubble fades in, in place (a quarter of a second for the link bubble, which also goes away by itself after a few seconds). It sits under the selected text, past the selection
   handles, so it does not cover the words being picked; when there is no room under the text the page moves up a little, once, to make room; if it cannot, the bubble goes above the text and
   above the phone's own Copy / Paste bar, and only for a selection as tall as the screen does it sit at the bottom edge. The link bubble sits above its link, under it when there is no room
   (BubblePlace.kt: where it goes, with tests in BubblePlaceTest; ui/Editor.kt: SelectionBubble, LinkBubble, rememberCalm, the touch watcher on the text).

☐ 73. Page style in pages (Scrapbook-UIO-23)
   For: Page style was one long sheet of everything at once (icon, colors, kind, cover, type, density, switches), which looked busy and had to be scrolled.
   Built: Page style is now a short list, one quiet row for each part with what it is now (a sample of the color, the icon, a word in grey) and a chevron: Icon, Page color, Accent, Cover image;
   Type, Density; Kind, Show. A row opens a page with only that part (the icon picker, the color dots, a list of choices with the current one checked, the switches), the sheet's title
   becomes the part's name, the big button becomes Back and so does the phone's Back; the pages slide. Type, Density and Kind are lists of choices instead of a row of small buttons. The Layout
   row (and its page) comes back by itself when there is more than one layout. The Welcome sheet's line about pages no longer promises other layouts (ui/Customize.kt: CustomizeSheet, StylePage).

☐ 74. The highlighter: strength and its own color, in the toolbar (Scrapbook-UIO-24)
   For: the highlighter ("ab") could only use the page's accent, and at full strength that could be too vivid; and the A button of the toolbar only changed the color of text, so the highlighter's
   color was far away (Menu > Page > Accent).
   Built: the A button's panel now has two tabs, Text and Highlighter. Highlighter shows a sample line and has the color (the page's accent as before, yellow, green, pink, blue, orange, or any color
   of your own with the rainbow choice) and a Strength slider from 25 to 100 percent in steps of 5, which changes the highlights right away; Reset puts it back (the accent, full strength). Opening
   the panel on text that is highlighted starts on the Highlighter tab. It is one setting for the whole app, so every highlight in every scrap, in the editor and the reading view, follows it, and
   the "ab" button in the selection bubble shows the color it is set to. A highlight that is soft on a dark page keeps the text's own light color instead of dark ink, which is only used where the
   highlight is bright on the page. The first tab is the text color panel as it was (HighlightPrefs.kt with tests, ui/Highlight.kt: Marker, LocalMarker, markerStyle; ui/HighlighterPanel.kt;
   ui/FontColor.kt; ui/Editor.kt; ui/Pages.kt; MainActivity.kt; ArchiveViewModel.kt: highlightColor, highlightOpacity).

☐ 75. The highlighter belongs to each page, and the bubble stays under your finger (Scrapbook-UIO-25)
   For: in UIO-24 the highlighter's color and strength were one setting for the whole app, so choosing green on one page turned the highlights on every other page green too, where each used to follow
   its own accent. And the selection bubble hid itself the moment a finger went down on one of its own buttons, and again after every change it made, so a button had to be tapped three times.
   Built: the highlighter's color and strength are saved on the page (two new columns, hlColor and hlOpacity; pages that already exist keep the accent at full strength; they go with backups). Each
   page keeps its own, in the editor and in the reading view, and a page that has never been changed follows its own accent as it always did. They are written to the page at once, and only they (a
   small update that touches neither the text nor the order of the lists). The bubble no longer counts a finger on its own buttons as a finger on the page, so it does not fade out under it, and it
   stays after Bold, Italic and the rest have changed the text; it still waits (about half a second) after you select, and hides while you touch the text, scroll, or drag the handles. The page no
   longer scrolls by itself to make room for it: with no room under the text it goes above the text instead (Model.kt, Data.kt: MIGRATION_17_18, ui/Editor.kt, ui/Pages.kt, ArchiveViewModel.kt).

☐ 76. Smooth scrolling while you type, with a speed choice (Scrapbook-UIO-26)
   For: the page jumped in short, separate hops to keep the cursor in view (each letter started a new 0.12-second slide), a tap near the edge could move the page under your finger, and the
   speed could not be changed.
   Built: the page now glides. The cursor is kept in view the same way as before (nothing moves while it is comfortably on the screen: not nearer than about 28 dp to the top, nor 64 dp to the
   bottom, a little more room under the line you are writing), but the move is one continuous glide toward where it should be, a share of the distance left on every frame, so a new line, or
   the next letter in the middle of a glide, only bends it: no stops and starts, and fast typing is followed without lag. Settings > Editor > Scrolling while you type has Calm, Normal (the
   default), Quick and Instant (it jumps at once). It never moves while a finger is on the page, and not for the cursor a tap has just placed (you tapped where you could see); but it does
   follow typing, the keyboard opening, and the keys. A finger that starts to scroll takes over at once, and the glide stops (CaretFollow.kt with tests in CaretFollowTest, ui/Editor.kt, ui/Settings.kt,
   ArchiveViewModel.kt: followSpeed).

☐ 77. Import a folder of notes, for Samsung Notes and others (Scrapbook-UIO-27)
   For: moving hundreds of notes out of Samsung Notes. Its .sdocx files are a closed format and sharing many notes at once makes Samsung Notes crash; its Save as file > Microsoft Word file works.
   Built: Settings > Data > Import a folder of notes: pick a folder and Scrapbook reads every Word (.docx), text (.txt) and Markdown (.md) file in it and in the folders inside it. A folder becomes a
   box of that name (a folder inside a folder, a box inside that box; a box of the same name that is already there is used, not copied); files straight in the picked folder go to Inbox. From a Word
   file it keeps the text, headings (as # and ##), bullet and numbered lists with their depth, checkboxes (☐ and ☑ become checklist lines), bold, italic, strikethrough, underline, highlight and text
   color, centered and right-aligned lines, web links, tables (one line a row, the cells apart by " | "), the pictures (they become the scrap's photos, in order) and the file's own created and
   changed dates (the file's date when it has none). When a file's first line is its own name, that line is the title and is not repeated in the text; otherwise the file's name is the title.
   A note that is already in the app (the same title and text) is skipped, so a folder can be imported again, or in batches, without copies. Samsung's own .sdocx/.sdoc files are counted, not read, and
   the message says how to export them; anything else is skipped. While it runs the Data section's footer shows "Importing 37 of 480…", and at the end it says what was done. Import scraps (several
   files) takes Word files as well, and its message is the same one (NoteImport.kt, DocxReader.kt with tests in DocxReaderTest and NoteImportTest, ArchiveViewModel.kt: importFolder, importTexts,
   importStatus, ui/Settings.kt).

☐ 78. Agenda skin: day rows and pill tabs (Scrapbook-UIO-28)
   For: a task-list look from a mockup (big "Important" title, Edit and Add pills, dated headings, soft rows with an emoji tile and a chevron, a floating pill tab bar), as a skin in the skins list whose pieces other skins can use too. Built on top of UIO-27 (the note import); the number is 28 because 27 was already taken by the import.
   Built: Home > Skins > Agenda (a ready skin: Home's menu and search on top, every other part hidden, the Agenda section filling the page, Lime accent, rounded corners). The pieces are free for any skin: the Agenda layout (any section, and the Pinned, Recent, Boxes and Continue parts: rows grouped by day, with the
   tile, line under the title, arrow, day headings and order chosen in Edit section); a tabs card (Add a section > Agenda, up to 4 pill tabs, each with its own name and scraps: all, pinned, tasks to do, a tag, a box or this week; rename, move or delete a tab; the tabs can sit at the bottom or the top, the big title
   with Edit (opens the section's sheet) and Add (a new scrap in the tab's box or with its tag) can be switched off); the new Pinned and Tasks rules for any section that fills itself; the Lime accent. The tabs card is kept in skin share codes. Not checked on a phone: the UI code was written without a compiler or device, so build it
   and look at it first. The logic has tests (Agenda.kt, SectionTabs.kt, rules, style fields, ready skin: AgendaTest, HomeSections, SkinExtras, ReadySkins, Contrast tests) (Agenda.kt, SectionTabs.kt, ui/AgendaParts.kt, HomeSections.kt, SectionStyle.kt, SectionShapes.kt, HomeLook.kt, HomeReadySkins.kt, ui/Theme.kt, ui/SectionLooks.kt, ui/HomeSectionsUi.kt, ui/HomePage.kt, ui/About.kt).

☑ 79. Buttons in Customize home: the add button and the menu button, whatever parts are shown (Scrapbook-UIO-29)
   For: a skin such as Timeline hides the quick capture part, and the add button could only be changed under that part's options, so it looked like the page was stuck with the pill and no menu button.
   Built: Customize home has a Buttons group above Gestures with two rows. Add button (Pill, Bottom bar, Writing bar, One button an arc, Swipe-up sheet) is the same choice as before, now reachable from
   anywhere. Menu button is what stays of the menu while the header is hidden: Top left, Top right, None, or Bottom left, a round menu button that floats opposite the add button (with the Bottom bar it is not
   needed, because the bar has one; with the Writing bar the menu button stays at the top left). Both are saved like any other setting, so each skin has its own (ui/HomeExtras.kt ButtonsSettings, FloatingMenuButton,
   HomeStyleKey.MenuButton).

☑ 80. The Timeline has a dot shape, a color, a side and more (Scrapbook-UIO-29)
   For: a timeline that can look like anything: quiet, bold, on either side.
   Built: Edit section > Timeline now also chooses: the text size (small, usual, large), the side the line is on (left or right, the text follows), the shape of a dot (round, rounded square, or icon only with no
   dot), the color of the bright ones (the page's ink or the accent, which also colors the line), which dots are bright (the newest with the next ringed, none, or all), how thick the line is (hairline, thin, thick,
   bold) and the order (newest first or oldest first, the brightness still goes with the newest). Saved with the other timeline choices (SectionStyle, ui/SectionLooks.kt TimelineStop; tests in SectionStyleTest).

☑ 81. The word beside a section's name (Scrapbook-UIO-29)
   For: the "Auto · Edit" at the right of a section's name is not always wanted.
   Built: for any section with its name shown, Edit section > Word beside the name: Auto · Edit (as before), Edit, or None. With None the section is still edited from its hold menu on Home and from Customize home.

☐ 82. Agenda: the tabs are a navigation bar on the screen (Scrapbook-UIO-31)
   For: the Agenda skin's Important / General / Tasks tabs sat at the bottom of the section, so when the page scrolled they scrolled away or went under the New scrap button, and Home as a whole moved about instead of feeling fixed.
   Built: the pill tabs are docked to the bottom of the screen like a navigation bar, with a round New scrap button (accent color, hold it for the same menu as the pill) beside them; they never move. With the Agenda skin
   Home holds still (the header and the title stay) and only the list inside the section scrolls; when the section does not have room (something big above it) or has something after it, Home scrolls as before. The other add
   buttons (Bottom bar, Writing bar, One button an arc, Swipe-up sheet) and the floating menu button keep their own place and the tabs leave room for them. The tab you chose is shared by the bar and the list, and each tab opens
   at the top. A list of only pinned scraps (the Important tab) no longer shows a star on every row; Edit section > Agenda has Star on pinned scraps for the other lists. Edit section > Pill tabs sit: On the screen (new, the usual), Above the list,
   Under the list (what the old "At the bottom" did). Not checked on a phone (written without a compiler or device); the rules have tests (AgendaTest: dock host, page lock, star, tab bar place). (SectionTabs.kt, SectionStyle.kt,
   ui/AgendaParts.kt, ui/HomeSectionsUi.kt, ui/HomePage.kt, ui/About.kt, README.md).
\n
☐ 83. Samsung Notes files, read as Samsung writes them (Scrapbook-UIO-32)
   For: the first real Word files from Samsung Notes (share a note as Microsoft Word file; the phone writes them to Android/data/com.samsung.android.app.notes/files/share even when the share sheet
   itself fails). They showed three things the import did not know: every line carries Samsung's dark grey text color (252525), which became a {c:252525|…} around every line; the Word file's own
   date is the time of the export, not of the note; and the note's title and time are only in the file's name ("Logs_261008_122329.docx" is the note "Logs" of 8 Oct 2026, 12:23:29).
   Built: dark grey, black and white text colors are ordinary ink and are no longer written as colors; a Word file made by Apache POI (Samsung Notes) has its dates left out; a name like
   Title_yymmdd_hhmmss (also with a copy number such as _2 or (1), and Title__… for a title ending in a space) gives the scrap its title and its created and changed date; zip files are opened
   (several notes in one zip, or a text file that is really a zip) and the folders in a zip become boxes; files of the other kinds (pdf, pictures, powerpoint) are counted as skipped. Import scraps
   accepts zip files. Settings > Data tells how to bring Samsung Notes in (NoteImport.kt: splitName, parseFile; DocxReader.kt; ArchiveViewModel.kt: runImport; ui/Settings.kt; tests in
   NoteImportTest and DocxReaderTest, and the real files were run through the reader).

☐ 84. Samsung Notes files (.sdocx) are read directly (Scrapbook-UIO-33)
   For: Samsung Notes (4.4, a copy on a phone that is not a Samsung) writes Word and text files only for the first of several selected notes, and its share sheet does nothing; but Share > Samsung Notes
   file works for any number of notes and leaves the .sdocx files in Android/data/com.samsung.android.app.notes/files/share.
   Built: a reader for .sdocx (SdocxReader.kt, pure Kotlin, written from the published reverse-engineering notes of the format and checked on seven real notes). It keeps the note's title (the file's
   name when the note has none), its created and changed dates (the name's date when it has none), the text with bold, italic, underline, strikethrough, text color (Samsung's dark grey and white are
   not colors), highlight and web links, headings, bulleted lists, numbered lists (the numbers Samsung shows, also those it adds by itself), checkbox lists, depth, centered and right-aligned lines,
   and the pictures: first those in the text, in the order they stand, then any others the note carries (not the page's own picture of itself). Handwriting and drawings are not read, so a note that
   is only handwriting is counted as one that could not be read. Import a folder of notes and Import scraps take .sdocx files, alone or inside a zip; the older Samsung formats (.sdoc, .snb) are
   counted and the message says what to do. The Word reader is shared with it for the marks (ImportMarks.kt: Fmt, Seg, Marks), and light grey (d9d9d9 and lighter) is ordinary ink in Word files too
   (SdocxReader.kt, ImportMarks.kt, NoteImport.kt, DocxReader.kt, ui/Settings.kt; tests in SdocxReaderTest, which builds .sdocx files in memory, NoteImportTest and DocxReaderTest).

☑ 85. A gradient background in any two colors (Scrapbook-UIO-34)
   For: a page that is not flat, like a reference with a warm color at the top fading into dark below.
   Built: Settings > Look > Background opens a Background page with Plain, Gradient and Glow. Gradient fades a top color into a bottom color (the color holds near the top and has almost turned into
   the other by the lower third, so it reads as a fading page), running from the top down, corner to corner, or from the bottom up. Each color is chosen from a row of ready colors (a warm brown like the
   reference, blue, violet, green, rose, graphite) or any color at all: sliders for the RGB color and a box for a hex code such as #1D4E89. A preview at the top of the page follows every change, and the
   color is saved when a slider is let go. The background is drawn once behind every screen, which paint nothing as their page while one is on (SbTheme.page), so it shows through everywhere; the plain page
   is as it always was, and Soft grey stays a choice of Plain (AppBackground, ui/BackgroundUi.kt AppBackgroundLayer; tests in AppBackgroundTest).

☑ 86. The animated glow of Needle, in any color (Scrapbook-UIO-34)
   For: a living background, taken from the Needle app, in a color of your own.
   Built: Glow is Needle's drifting glow: a wash from the top left corner, three soft blobs that drift slowly with one back-and-forth movement, and the page color again at the very bottom behind the add button.
   The color can be any color (the same ready colors, sliders and hex code as the gradient). Colors: One color, or Soft mix (the color with its two neighbors on the color wheel, 40 degrees either way, the way
   Needle mixes its accent with two others); Strength: Soft, Usual, Strong; Movement: Still, Slow, Usual, Fast (a still glow costs nothing). It is drawn while painting, so the page does not recompose on each frame.

☑ 87. Glass cards, the editor, and a warning when text cannot be read (Scrapbook-UIO-34)
   For: cards that sit on a background like the reference's, and a way not to make reading harder.
   Built: Glass cards makes cards and grouped rows a thin veil over the background instead of solid (white at 9% in dark mode, black at 5% in light). The editor keeps the plain page, where long text is read, unless
   Show it in the editor too is on. Because text is near-white in dark mode and near-black in light mode, the Background page says so when the colors chosen are too light for dark mode (or too dark for light
   mode), judged from how light the two colors are (a glow from how strongly it is drawn). Back to the plain page undoes it all. While a background is on, the old and new screen overlap for a moment as one slides
   in, since neither paints a page of its own.

☐ 88. Import notes straight into a box (Scrapbook-UIO-35)
   For: every imported note landed in Inbox and had to be moved by hand, one at a time.
   Built: the menu of a box now has Import notes here and Import a folder here (on the box's page under the three dots, and in the box's hold menu on Home, Inbox included). The notes go into that box
   instead of Inbox; in a folder import, files straight in the picked folder go into the box and the folders inside it become boxes inside that box. Notes already in the app are still skipped, and the
   result ("Imported 12 scraps. 2 were already here.") shows at the bottom when it is done. A box deleted while the picker was open sends the notes to Inbox. The Settings imports are unchanged.
   Code: ArchiveViewModel.importTexts/importFolder/runImport take the target box; ui/BoxImport.kt holds the two pickers (rememberBoxImporter) and the shared list of file types.

☐ 89. Lists on every selected line, and Quick tools on the + button (Scrapbook-UIO-36)
   For: selecting several lines and tapping bullet, number or checklist only changed the first line; and the things you reach for while writing were spread over three menus.
   Built: the bullet, numbered, checklist, heading and quote buttons (the bubble bar, Text options and the pill bar) now work on every line the selection touches. If all of those lines already have the
   mark it comes off them all, otherwise every line gets it (a line with another mark is switched; a ticked line stays ticked; numbers count 1, 2, 3; blank lines and code blocks are left alone). The
   selection stays on the same text, so tapping again undoes it. Holding the + button opens Quick tools: lists, heading, quote, divider, code block and Tick all; Date, Time and Date and time; Move up and
   down, Duplicate, Delete line, Sort A-Z and Z-A, No blank lines; CAPITALS, small and Each Word for the selected words (color codes and link addresses are never changed); and Count (words, characters and
   lines, of the selection or of the whole scrap). A tap on + still opens the Add window. Text tools also has Tick all.
   Code: toggleLines, duplicateLines, deleteLines, sortLines, removeBlankLines, changeCase, textStats, timeText, dateTimeText and CheckAction.TickAll in EditorTools.kt (27 new tests); QuickToolsWindow in ui/Editor.kt.

☐ 90. Settings regrouped: fewer cards, the main setting on its own (Scrapbook-UIO-37)
   For: Settings had one rounded card for every single row, so each page was a long stack of cards. Paperback's Settings is calmer: the setting that matters most stands alone, and the others of
   the same kind share one card.
   Built: the main Settings page puts its six pages into three cards under small headings (Appearance, Your scraps, Safety and data) with thin lines between them. Each page shows its settings in
   a few cards: Look & Feel has Theme alone (System, Light, Dark as one tap, no picker), then Colors (the accent colors as a row of round swatches with a rainbow one for a color of your own,
   and Background), Style (App's icon, Headings, Corners) and Feedback; Home and lists has Customize and Lists; Boxes has Manage boxes alone, then Behavior; Editor has Writing, Smart text and
   Accent color on; Privacy has App lock alone, then Options and PIN; Data and backup has Bin alone, then Backup and Import. The settings themselves are the same, and the search still finds
   every one (each result now sits under its group's name). The deeper pages follow: Greeting (sizes, picture and line under it in one card; the greeting lines in one card), the add and menu
   buttons, the gestures list, Resize on Home with the part's frame, and the app icons in one card (RowLine, SegmentRow, AccentRow, SettingsBlock in ui/Settings.kt; ui/GreetingOptions.kt,
   ui/HomeExtras.kt, ui/HomeGestures.kt, ui/PartSizes.kt, ui/AppIconScreen.kt).

☑ 91. Smarter text selection in the editor (Scrapbook-UIO-38)
   For: a double tap should select the word a writer means, and selecting should be quicker than tapping and dragging the handles.
   Built: a double tap now selects hashtags and mentions with their # or @, web and e-mail addresses whole (without the comma or full stop after them), numbers like 3.14, 1,000 and 10:30,
   and words with an apostrophe or a hyphen (don't, well-known), with accents and underscores, instead of the phone's own idea of a word; hidden marks stay outside it. A double tap on a word that
   a double tap just selected grows the selection along word, sentence, line, everything (triple tap still selects the line and four taps everything). A double tap that does not let go and moves
   takes the selection along by whole words, in both directions, with a light tick for each word and the page scrolling by itself near its top or bottom edge. A long press selects the same word a
   double tap does. Nothing changes in reading mode. (SmartSelect.kt; ui/Editor.kt: selectByTaps, wordAt, extendWords and the tap counter; test SmartSelectTest)

☐ 92. Sheet motion: a smoother rise, a height that glides, a sliding segmented pill (Scrapbook-UIO-39)
   For: sheets should move like the focus-session reference: the sheet eases up instead of sliding on a fixed timer, grows or shrinks to its new height when what is inside changes instead of jumping, and the
   chosen option of a segmented control slides to the next one instead of one pill fading out while the other fades in.
   Built: every sheet (they all share Sheet) now rises on a spring with no bounce, so it decelerates into place and never lifts off the bottom edge; leaving is still a short ease-out, and the dim fades with it. When
   the content of a sheet changes height (a page swaps, a row appears, a list loads) the sheet itself animates to the new height on a quick spring, the rounded corners and shadow following. The segmented control
   (Seg, used in 12 places) has one pill that slides between the options on a spring with a small give, and the text colors still fade. Nothing else changes: sizes, colors, buttons and gestures are as they were, and
   the system's animation speed setting still applies (ui/Customize.kt: Sheet, Seg).

☐ 93. Header: Buttons only, and the Header settings page from Paperback (Scrapbook-UIO-40)
   For: Paperback has four headers and Scrapbook had three of them: Left, Center and Round with a Compact, Regular or Large size are Paperback's Compact, Regular and Large, so only Buttons only (two round
   buttons, no wordmark) was missing. The settings page for the header should also be Paperback's: a live sample of every header to tap, instead of two bars with words.
   Built: a fourth header layout, Buttons only: the round menu button on the left and the round search button on the right, nothing between them, so the top bar takes the least room. It shows on Home and
   All scraps like the other three, can be part of a skin, and the Size setting makes its two buttons a little smaller or bigger (there is no wordmark to resize). Customize home > Header is now laid out
   like Paperback's App style page: a short line of explanation, then Left, Center, Round and Buttons only, each a real sample of the header at the chosen size inside a rounded outline, with a note beside its
   name, a Default badge on Center, and a Selected badge and a heavier outline on the one in use. Tap a sample to choose it. The Size choice is under the samples, and they change with it at once. The saved
   numbers are unchanged for the first three; the new one is 3, and a skin that holds 0 to 2 loads as before (Home.kt: MainHeader, HeaderSample; ui/HeaderSettings.kt; HomeExtras.kt; ArchiveViewModel.kt).

☐ 94. Selecting while the page scrolls by itself: faster, steady, and for a long press too (Scrapbook-UIO-41)
   For: dragging a selection toward the bottom (or the top) of the screen only scrolled a little and then stalled, so the page had to be scrolled by hand. It should scroll fast and by itself, as fast as the finger asks for.
   Built: the page now scrolls by itself while a finger that is selecting is near the top or the bottom, one step every frame, by the time passed since the last frame, so it is as quick on any screen and does not stall.
   The edge zone is a fifth of the visible page (at least 72dp) instead of 56dp; inside it the speed grows with the finger's depth, from gentle at the inner border to fast at the edge of the screen, and a finger pushed past
   the edge, onto the keyboard or the bar above it, goes faster still. The selection follows every step, also while the finger lies still, with one light tick at most every 45 ms instead of one per word (a buzz at this
   speed). This is for the double tap that does not let go and for a long press that keeps moving, which now also select by whole words, with the same scrolling. Dragging a selection handle: the page now also follows the
   start handle upward (before only the end handle was followed); the handles themselves are the system's and still need the finger to move to go on. (EdgeScroll.kt, test EdgeScrollTest; ui/Editor.kt: the gesture
   that counts taps, extendWords, the follow effect)


☐ 95. Hold a scrap: a menu on the card (Scrapbook-UIO-42)
   For: holding a scrap on All scraps or inside a box only turned on selecting, and the selection look was not liked. Holding should open a menu with the real choices, right on the card (mockup S1, Scrap: popover on the card).
   Built: hold a scrap and the screen dims while the held card stays bright, with a menu opening right under it, lined up with the card's right edge, or above it when there is no room below. On top are four round
   icon buttons (Pin or Unpin, Add to box, Tags, Share); under them a list: Select, Duplicate, and after a line Delete in red. Pin changes to Unpin with a filled star for a pinned scrap. Select starts picking
   several with this scrap picked, as holding used to. Add to box and Tags open the same sheets as before; Share opens the system share list; Delete goes to the Bin with the usual Undo. Tap outside or Back closes
   the menu. While several scraps are being picked, holding a card still just adds it. Holding a scrap on the home page keeps its own menu for now.
   Code: what the menu offers is a list (HoldMenu.kt: HoldAction, HoldMenuConfig with sanitized, encode and decode, placePopover), so a settings page for scrap and box menus can later reorder, hide and bring back
   actions; the menu is drawn in ui/ScrapPopover.kt (Modifier.tapOrHoldCard reports the card's place, ScrapPopoverState, ScrapPopoverHost); wired into AllScrapsScreen (Home.kt), ShelfScreen (Browse.kt) and the
   four card layouts (ListLayouts.kt). Test: HoldMenuTest (17 cases: the default menu, Unpin, no doubles, the four-button limit, Select never missing, encode and decode, and where the menu goes: below, above, tight fit,
   tall card, side and top limits).

☐ 96. Box style: Slim shelf, with the counts in the headings (Scrapbook-UIO-43)
   For: the box page's title line carried everything (name, number of scraps, number of boxes), and the boxes inside took a lot of room. Mockup E, Slim shelf, counts in context.
   Built: Settings > Box style has a new last choice, Slim shelf. On a box page it shows the box's name with what it is under it (the path above and the description stay), then a "Boxes 11" heading with See all on the right,
   and the boxes inside as slim chips (a dot in the box color, the name, the count) on one row that runs to the edges of the screen and scrolls sideways, ending with a dashed New box chip. See all (shown from 4 boxes on)
   spreads the chips over as many lines as they need, and turns into Show less. Under a thin line comes a "Scraps 6" heading with the filter (just an icon, or the icon and a count on a dark pill while a filter is on), the
   sort choice (the same menu as before) and the layout picker on its right; while a filter or a search shows only some of the scraps it reads "3 of 6". The title line no longer carries the counts. All, Pinned, Recent and Inbox
   get the same Scraps row. On Home the boxes of this style are the same sideways row of chips. The chips are 34dp to look at and 44dp to touch; holding one still offers to delete the box, until the box menu is rebuilt.
   The other seven box styles and the pages without this style are unchanged; the saved number for Slim shelf is 7.
   Code: BoxShelfRules.kt (SLIM_SHELF_STYLE, boxStyleDrawsOwnNewButton, showSeeAll, scrapsHeadingCount), ui/BoxStyles.kt (BOX_STYLES, SlimShelf, SlimChip, SlimNewChip, the bleed modifier), ui/Browse.kt (ShelfScreen: SlimHeading,
   SlimFilterButton, SlimSortButton), ui/Home.kt and ui/Settings.kt (small). Test: BoxShelfRulesTest (4 cases).

☐ 97. Swipe a page: back, and between the main pages; and an add button style with no buttons (Scrapbook-UIO-44)
   For: Paperback got swipe gestures for moving around (its step 30) and a menu-only Clean navigation (its step 19); Scrapbook should have them too, as choices that work with every navigation it has.
   Built: Settings > Home and lists > Swipes has two switches. Swipe to go back (on by default): swipe a page to the right and it does what the Back button does, so a sheet or a Settings page that is open closes
   first and the page goes only after that. Swipe between main pages (off by default): swipe left or right on Home, All scraps, Boxes or Settings to go to the next or the previous one; Back from any of them returns to Home.
   It takes a free sideways swipe of about 80dp that is clearly more sideways than up or down, so scrolling that drifts a little never turns a page, and a light tick says it worked. Anything on a page that
   already uses a sideways drag (a row that scrolls, a slider, swiping a recent scrap to pin or delete it, carrying a card) keeps it, two fingers (drawing, pinching) never count, and a sheet or the hold menu
   on top of a page keeps swipes from reaching the page under it. The editor, the layouts page, the Draw gestures page, the capture screen and the account page are left alone, and so is a locked app.
   Add button gets a sixth choice, No buttons: nothing is drawn over the pages (no pill, bar, arc, sheet handle or fade), so the screen is just the page. A scrap is started from the menu in the header or the quick capture card
   on Home, and the swipes move between pages. Skins can hold it too. The phone's own back animation (Android 14 and later) is switched on (enableOnBackInvokedCallback), so the page slides away under the finger
   while you swipe from the edge. The gesture guide on Home has a line for the swipes.
   Code: NavSwipes.kt (the rules: main pages, what each swipe does on each page, how far and how straight), ui/SwipeNav.kt (SwipeNavLayer around the NavHost, SwipeGate and BlockSwipes, goMain), MainActivity.kt,
   ArchiveViewModel.kt (swipeBack, swipeTabs), ui/Settings.kt, ui/HomeExtras.kt (ADD_BUTTON_NONE), ui/NavStyles.kt, ui/HomePage.kt, ui/Customize.kt (Sheet), ui/ScrapPopover.kt, AndroidManifest.xml.
   Test: NavSwipesTest (12 cases: the order of the main pages, the ends, Back only when there is a page before, the switches, pages that keep their own drags, distance and angle).

☑ 98. Home shows the background too (Scrapbook-UIO-45)
   For: with a gradient or a glow chosen, every page had it except Home, which stayed plain black (or white).
   Built: Home painted its own page color (the one its Look can tint) under everything, so the background could not show. While a background is on, Home's page is see-through; a page tint chosen in the Look stays as a
   see-through tint (55%) over the background, so a skin that tints the page still reads as tinted. The moment before Home has loaded is see-through as well, so there is no flash of plain page (HomePage pageBg).

☑ 99. Text on buttons is never see-through (Scrapbook-UIO-45)
   For: with Glass cards on, the label of the selected choice, the big button at the bottom of the menu, the New scrap pill and similar buttons lost their text, in both light and dark mode.
   Built: the card color is also what text and icons on the dark (or light) pills are drawn in, and Glass cards had made it a thin veil, so those texts vanished. The card color is solid again, always. What a card, a grouped row
   or a chip is filled with is now a color of its own (Sb.surface), the card color normally and the veil when a background has frosted or clear cards; the fills that are meant to show the background (about 80 of them, and the
   Agenda tiles, the timeline's dim dots and Home's cards) use it, and nothing that holds text on a pill does.

☑ 100. Cards on a background: Solid, Frosted or Clear (Scrapbook-UIO-45)
   For: the cards looked off on a background: black slabs on a gradient, and a muddy grey veil on a light one.
   Built: the Glass cards switch is now Cards on the Background page, with three choices: Solid (as on the plain page), Frosted (the usual: a veil of white, 10% in dark mode and 60% in light mode, so dark text stays easy to read on a
   colored page) and Clear (a thinner veil, 5% and 35%). The veil is white in both modes instead of black over a light page. The soft grey page switch has a shorter name so it is no longer cut off (AppBackground.cards,
   AppBackgrounds.veilAlpha; tests in AppBackgroundTest).

☐ 101. Editor toolbar: new highlight, pop-ups in the toolbar's color, grouped Quick tools (Scrapbook-UIO-46)
   For: the selected button (H1, the checklist and so on) had an uneven tint, as wide as its cell, and the pop-ups above the bar (+, Quick tools, Text options, color, size, undo) were a different grey from the bar itself.
   Built: every toolbar button now marks "on" with the same 44dp rounded square, so H1 is no longer wider than the others. Settings > Editor > Toolbar highlight has two looks: Soft tint (default, the light accent tint behind the
   button) and Quiet dot (no box, the icon in the accent color and a small dot under it); the Text options buttons and the size list follow it. Every pop-up above the bar is filled with the toolbar's own solid color (Sb.sheet),
   and what sits inside a pop-up (option groups, Quick tools tiles) is a step away from it (Sb.tile). Quick tools is now in titled cards (Blocks, Insert, Lines, Selected words), four tiles to a row, with Delete line in red.
   Code: ui/Editor.kt (barLookNow, onMark, OnDot, BarCell, OptBtn, SizeList, PanelCard, QuickToolsWindow, QuickTile), ui/Theme.kt (Sb.sheet, Sb.tile), ui/FontColor.kt, ui/HighlighterPanel.kt, ui/Windows.kt (PopupMenu colors),
   ArchiveViewModel.kt (toolbarLook), ui/Settings.kt.

☐ 102. Size, color and underline apply to what you type next (Scrapbook-UIO-46)
   For: picking a size with only a cursor changed the word next to the cursor (and did nothing between words); the new text was never in the size you picked.
   Built: with text selected, the buttons change that selection, as before. With only a cursor they set the look of everything typed next: an empty span ({s:24|}) is put at the cursor (never shown) and the typing goes inside it; a span
   the cursor is in is split around it. The buttons show the look at the cursor (size, color, underline), and "-" when a selection holds several sizes. Enter keeps the look on the new line instead of making it plain, and Enter right after
   picking a size no longer puts the line break inside the braces. The A button's underline shows the color at the cursor first, then the last color picked.
   Code: TypingStyle.kt (typingStyleAt, attrsAtCursor, emptySpanAt, enterInEmptySpan, carryStyleOverEnter), ui/Editor.kt (applySpan, toggleUnderline, liftEmptySpan, carryLook, edit).
   Test: TypingStyleTest (19 cases).

☐ 103. Cards: a page style with free cards laid over the page (Scrapbook-UIO-47)
   For: a scrap that looks like a board of small cards, like the chat-style page in the reference: any text on a card, and the cards placed anywhere you like, over anything, on any spot.
   Built: a second page layout, Cards, next to Classic (Page style > Layout, or the editor's menu > Change layout; the Layout row and page now show themselves because there are two). A Cards scrap is an
   ordinary scrap, with its text and photos, and the cards are laid over the whole scrolling page, over the text and over photos, so they move with the page. Add one from the + in the editor (the first
   row, Add a card) or from the editor's menu (Add a card); a new card appears near the top of what you are looking at, each next one a little further along. Drag a card with your finger to move it
   wherever you like; the page grows to hold the lowest card. Drag the small grip at a card's corner to make it wider or narrower. Tap a card to edit it. A card you moved comes to the front. In view-only
   mode the cards stay where they are. Undo and Redo cover adding, moving, resizing and editing a card. Switching a scrap back to Classic hides its cards without losing them; switching to Cards again
   shows them as they were. The cards are saved in the scrap's own canvas field, so nothing in the database changes (PageCards.kt, ui/PageCardsUi.kt, ui/Editor.kt; test PageCardsTest).

☐ 104. What a card can hold: title, text, badge, icon, link, color, width and tilt (Scrapbook-UIO-47)
   For: the things on the reference's cards: a heading, a few lines of text, a "Topic" pill, an icon and a round arrow button, cards at a slight angle.
   Built: the card's window has Title, Text, Badge (the words on a small pill at the top, like Topic), Badge icon and Icon (none, one of ten ready symbols, an emoji or symbol you type or paste, or a picture
   of your own from your photos), Link (a web address; the card gets a round arrow button in your accent color that opens it), Color (five: plain, warm, cool, rose, mint, each in light and in dark),
   Width (narrow, medium, wide, full) and Tilt (-10, -4, flat, +4, +10 degrees). It can also make a copy of the card, bring it to the front, or delete it. Cards have a soft shadow, rounded corners and
   centered text. A card with nothing on it says Tap to write on this card (ui/PageCardsUi.kt: PageCardView, CardsSheet).

☐ 105. Card pictures go with backups and are never swept away (Scrapbook-UIO-47)
   For: a picture you put on a card must not vanish when you restore a backup or when the app tidies its files.
   Built: the pictures used as card icons or badge icons are added to the backup zip and pointed at the restored copies when you restore; the tidy-up of unused picture files already counted the scrap's
   canvas text, so those pictures are kept (ArchiveViewModel export and restore, PageCards.pictures and mapPictures).

☐ 106. Toolbar highlight: Raised segment as a third look, and the setting shows (Scrapbook-UIO-48)
   For: a third way to mark the selected toolbar button, and the Toolbar highlight setting was missing from Settings > Editor.
   Built: Settings > Editor > Writing now lists Toolbar highlight under Editor toolbar (it was defined but left out of the group). It has a third choice, Raised segment: the button that is on lifts like a chip, in the
   pop-up's tile color with a soft shadow and the icon in the accent color; Text options and the size list use the same chip. With it, Quick tools opens as a tab switcher (Lists, Insert, Lines, Selected words), one group
   at a time, with each tile its own larger card (ui/Editor.kt: onMark, QuickToolsWindow, QuickTile; ui/Settings.kt; ArchiveViewModel.toolbarLook is 0, 1 or 2).

☐ 107. The profile card moves to the About page (Scrapbook-UIO-49)
   For: the profile card at the bottom of Settings took room on the main page.
   Built: the card with your picture, name and first line is now the first card on About, under the version, labelled PROFILE in the same small letters as PART OF THE FAMILY. Tapping it opens the Account page as before;
   Settings now ends with the About row only. The Account row in the settings search still works (ui/AccountScreen.kt: AccountRow replaces AccountCard; ui/About.kt; ui/Settings.kt; MainActivity.kt).

☐ 108. A new tagline: "Scraps of thought, kept close." (Scrapbook-UIO-50)
   For: the line under the name on the About page, "Quick notes, tidy boxes.", was to be replaced.
   Built: the About page and the Welcome sheet (the first-run card) now say "Scraps of thought, kept close." (ui/About.kt, ui/Customize.kt).

☐ 109. Customize menu: fewer things at once, no wireframe pictures (Scrapbook-UIO-51)
   For: the Customize menu page showed everything at once and its small pictures of the menu (the big one on top, one for each skin, one for each saved menu) did not look like the real thing.
   Built: the pictures are gone; "Try the menu" (the real menu) stays on top. The Look tab is now six rows, each with what it is now on the right (Skin, Words, Rows and icons, Top and dim, Buttons), and a tap opens just that
   group under its row (one at a time). Skin is a plain list of names with a line about each and a check. Words holds the title, the line under the buttons, the card names and whether card names show; Rows and icons holds
   the row size, icons and accent color; Top and dim holds your picture and name and the dim; Buttons holds the main button, the close button and what the main button looks like. Setups (Ready-made and Yours) are plain rows
   with the name, the skin and a check, and the trash button on your own. The Entries tab is unchanged (ui/MenuEdit.kt: LookGroup, SetupRow).

☐ 110. Greeting: it stays when you come back, a custom time, and twice as many lines (Scrapbook-UIO-52)
   For: the greeting was picked again (and typed again, with the Typing animation) every time Home left the screen: opening another page, or scrolling it out of sight and back.
   Built: the line that is showing and how much of it was typed are kept while the app runs (GreetingNow in Greetings.kt), so coming back shows the same line, finished typing; one that was cut short goes on from where it
   stopped. A line is replaced when its time is up (the timer counts from when it first appeared, not from when you came back), when the name, birthday or line types change, or when you tap it.
   Customize home > Greeting > Changing: "Change greeting every" has a new choice, Custom time, with a slider from 5 seconds to an hour (every 5 seconds up to a minute, every 15 seconds up to 5 minutes, then every minute),
   with the time in words next to it. The quick choices (Never, 10, 20, 40, 90 seconds) are as before. The greetings went from 171 to 343 lines in the same shapes and tones; there are lines for Tuesday, Thursday and Saturday now.
   Code: Greetings.kt (GreetingNow, GreetingPrefs.STEPS, everyLabel, Days), ui/GreetingHub.kt (TypedText, the stored line), ui/GreetingOptions.kt (TimeRow). Tests added in GreetingsTest.

☐ 111. Long scraps: typing and editing no longer restyle every line (Scrapbook-UIO-53)
   For: a scrap with many entries (50 log entries) got slow to type in and to scroll.
   Found: every key press re-ran the whole styling of the text: a dozen pattern searches on every line of the scrap, for lines that had not changed, and a code-block check that split the whole note into lines (and ran a
   pattern on each) several times per edit, even in notes with no code at all.
   Built: the renderer (ui/Editor.kt: mdRender, LineData, MdCache) now works out each line once and keeps it, so an edit works out the one line that changed; the rest is only put together. Code-block checks answer at once when
   the note has no ``` fence (Markup.kt: codeStateAt, codeLineStates). For notes over 3000 characters the menu's word count line ends with "styled in N ms", the time the last styling took, so the speed can be compared.
   Not changed: the scrap is still one text field, so very long scraps may still scroll slower than short ones; if scrolling is still heavy after this, the next step is splitting the text field.
   Tests: MarkupTest (fences).

☐ 112. Editor toolbar: the Growing card, a floating dark pill (Scrapbook-UIO-54)
   For: the editor's docked bar was to become a floating dark pill, like the reference, without losing anything the bubble toolbar can do.
   Built: Settings > Editor toolbar has a third choice, Growing card (the new default; the other two are as before). The bar is one floating dark pill with five round buttons: Undo, Heading, Checklist, Aa and +,
   with a soft light circle on the one that is on. Undo works as before (tap, hold for Undo, Redo and Revert all changes); + opens the + window and holding it opens Quick tools. Aa grows a dark card above the pill
   with three parts: TEXT (bold, italic, underline, strikethrough, bullets, numbers, left, center, right, indent, outdent), COLOR (Text and Highlight, the ready colors, your recent colors; Highlight and the
   rainbow dot open the full color panel and the Highlighter panel above the bar) and SIZE (the whole 6 to 64 list, scrolling sideways). The selection bubble (bold, italic, strikethrough, highlight, code, link,
   copy) stays with this choice. Toolbar highlight (tint, dot, raised) does not change the pill's own look; it still styles the pop-ups.
   Code: ui/Editor.kt (GrowBar, GrowBtn, GrowCard, GrowChip; the editor picks the bar from editorStyle 0, 1 or 2), ui/Settings.kt, ArchiveViewModel.editorStyle (default 2).

☐ 113. Growing card: the page's accent marks what is on (Scrapbook-UIO-55)
   For: the Growing card was only black and white; it should follow the page's accent like the rest of the editor.
   Built: the button that is on gets a soft circle of the page's accent with an accent icon, and the chips that are on in the card (bold, lists, alignment, Text, the current size) are filled with it. The accent is
   lightened when it would be too dark to read on the dark pill, and the text on a filled chip is white or near-black, whichever reads.
   Code: ui/Theme.kt (accentOnInk), ui/Editor.kt (GrowBtn, GrowChip, GrowSizes).

☐ 114. Growing card: the pill follows the selection (Scrapbook-UIO-55)
   For: with words selected the pill should offer what you need for them, close at hand.
   Built: while text is selected the pill shows Undo, Bold, Italic, Color (an A with the current color), Size (the current number), Aa and +. Color and Size open a small dark card above the pill with the color
   choices (Text, Highlight, ready and recent colors, the rainbow dot for the full panel) or the whole 6 to 64 size list. Aa and + still open the full card, the + window and (hold) Quick tools. Heading and
   Checklist show again when nothing is selected. The Color and Size cards close when the selection ends.
   Code: ui/Editor.kt (GrowBar takes the selection; panels 4 and 5; GrowColors, GrowSizes and GrowPop are shared with the Aa card).

☐ 115. Growing card: the pill floats over the page (Scrapbook-UIO-56)
   For: the pill sat in a bar-sized invisible box under the page, so the text stopped above it and the pill looked docked; it should float over the text.
   Built: with Growing card the pill no longer takes any room: the page runs the full height behind it, and the text shows around and behind the pill. While you write, the page gets extra room at its end,
   so the last lines can be scrolled clear of the pill. The Aa card, the Color and Size cards and the + windows open above it as before. The other two toolbar choices are unchanged.
   Code: ui/Editor.kt (GrowBar now sits in the page's own box, over the text; the values it needs are worked out before the page).

☐ 116. Growing card: undo moves to the end, the highlights no longer touch (Scrapbook-UIO-58)
   For: Undo sat first on the pill, and two buttons that were on (Checklist and Aa) had their circles touching.
   Built: the pill is now Heading, Checklist, Aa, +, then Undo last, after a thin gap (with text selected: Bold, Italic, Color, Size, Aa, +, Undo). Every button is 44dp (42dp with text selected) and the mark
   behind it is smaller than the button, so neighbours that are on always have a gap. The pill follows Toolbar highlight: Soft tint (round tint), Quiet dot (accent icon with a dot under it) or Raised segment (a soft chip).
   Code: ui/Editor.kt (GrowBar, GrowBtn).

☐ 117. Growing card: a flatter, cleaner Aa card and Quick tools (Scrapbook-UIO-58)
   For: the cards were big and busy.
   Built: the Aa card, the Color and Size cards and Quick tools are flat, with no outline and no light overlay. Related buttons share one soft track (bold, italic, underline, strikethrough; the two lists; the three
   alignments; indent and outdent), buttons are 32dp instead of 44dp, and what is on is a soft tint of the page's accent. Text and Highlight are one small switch, the color dots and recent colors are smaller, and
   the sizes are smaller chips. Quick tools from the Growing card always opens as tabs (Lists, Insert, Lines, Selected) with shorter tiles. In dark mode the pill is deep black and the cards a hair above it.
   Code: ui/Soft.kt (new: growPill, growCard, growFg, growChip), ui/Editor.kt (GrowCard, GrowGroup, GrowChip, GrowColors, GrowSizes, GrowPop, QuickToolsWindow), ui/Theme.kt (accentOnInk).

☐ 118. Smoother shadows in light and dark mode (Scrapbook-UIO-58)
   For: the shadows of the toolbar, its cards and the editor menus looked rough.
   Built: one soft shadow made of three layers (tight, middle, wide and faint), deeper in dark mode. Used on the pill, the Aa, Color and Size cards, the Quick tools window, the + and 3-dot menus, the bubble toolbar
   and the Highlighter panel.
   Code: ui/Soft.kt (softShadow), ui/Editor.kt, ui/HighlighterPanel.kt. Toolbar highlight's note in ui/Settings.kt now says it covers the Growing card too.

☐ 119. Growing card: a smaller Add to page window (Scrapbook-UIO-59)
   For: the Add to page window (the + button) was big and in a different color from the rest of the Growing card.
   Built: with the Growing card the + window is narrower, with 50dp rows (a small soft tile with the icon, the name and one short line) and the same flat colors as Quick tools: deep black in dark mode, a soft grey in
   light mode, no outline and a soft shadow. The other two toolbar choices keep their own + window.
   Code: ui/Editor.kt (AddWindow takes grow; new AddRow).

