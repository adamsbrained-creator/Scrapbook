# Signing the app, so every new version updates the old one

## Why this is needed

Android only lets a new APK replace an installed app when **both** are true:

1. It is signed with **the same key** as the installed one.
2. Its **versionCode is higher**.

Without your own key, GitHub makes a new random key on every run, so Android says
*"App not installed as package conflicts with an existing package"* and you have to delete the app first.

- **Same key:** you make one key once and store it in GitHub as four secrets. Every build uses it.
- **Higher versionCode:** the workflows set it from the clock (minutes since 1970), so it goes up by itself, whichever
  workflow made the build.

## Files this needs in your repository

- `.github/workflows/scrapbook-zip.yml` (unpacks a zip of the project and builds and signs the app: the phone-friendly way)
- `.github/workflows/android.yml` (builds and signs the app from the files in the repo; optional if you only use the zip)
- `.github/workflows/create-signing-key.yml` (makes the key, used once)
- `.gitignore` (keeps keys out of GitHub; only matters if you commit files from a computer)

Both build workflows use the same key and the same versionCode formula, so an APK from either one installs over the other.

## One-time setup

### 1. Make the key (in GitHub, nothing to install)

1. Repository > **Actions** > **Create signing key (run once)** > **Run workflow**.
2. When it finishes, open the run and download **`signing-key-keep-private`** from *Artifacts* (a zip, kept 2 days).
3. Unzip it. It holds `release.jks`, `KEYSTORE_B64.txt` and `passwords-and-alias.txt`.

The workflow refuses to run if the repository is public or a key is already saved.

### 2. Back it up. This is the most important step.

Save `release.jks` and `passwords-and-alias.txt` in a password manager, cloud drive or USB stick.
**If you lose them you can never update the app again.** GitHub cannot show the secrets back to you.
Never commit these files and never send them to anyone.

### 3. Add four secrets

Repository > **Settings > Secrets and variables > Actions > New repository secret**. Names are case-sensitive:

| Name | Value |
| --- | --- |
| `KEYSTORE_B64` | the whole text inside `KEYSTORE_B64.txt` (one long line) |
| `KEYSTORE_PASSWORD` | `KEYSTORE_PASSWORD` from `passwords-and-alias.txt` |
| `KEY_ALIAS` | `scrapbook` |
| `KEY_PASSWORD` | `KEY_PASSWORD` from `passwords-and-alias.txt` |

Then delete `create-signing-key.yml` from the repository and delete the `signing-key-keep-private` artifact.

### 4. Build

From a phone: upload the project zip to the top of the repo (the build starts by itself), or **Actions > Scrapbook (from zip) > Run workflow**.
Or push to `main`, or **Actions > Android CI > Run workflow**, to build from the files in the repo. When it finishes, open the run and download
**`scrapbook-release-apk`** from *Artifacts*. It is a zip containing `app-release.apk`.

The run page has a **Signing key** box with a SHA-256 line. It must be **identical on every run**.

## The one-time uninstall

If the app on your phone was built before this setup, it has a throwaway key, so Android will not update it. Do this **once**:

1. In the old app: **Settings > Back up archive**, and save the zip somewhere safe.
2. Uninstall the old Scrapbook.
3. Install the new `app-release.apk`.
4. **Settings > Restore from backup** and pick the zip.

From then on, install each new APK over the old one and your notes stay.

## Everyday use

1. Change the code and push to `main`.
2. Download `scrapbook-release-apk` from the finished run.
3. Install it over the old version.

## If something goes wrong

- **"No signing key" error:** one of the four secrets is missing or misspelled.
- **"Signing key problem":** `KEYSTORE_B64` was pasted incompletely, or `KEYSTORE_PASSWORD` / `KEY_ALIAS` is wrong.
- **"App not installed" / "conflicts with an existing package":** the installed copy has a different key. Do the one-time uninstall.
- **"A newer version is already installed":** the installed copy has a higher versionCode than this build. GitHub builds
  use the clock, so they only go up; this can only happen if the installed copy came from somewhere else with a larger
  number. Back up, uninstall, install the new APK and restore (see the one-time uninstall above).
- **Builds on your own computer** use a different key and versionCode 1, so they cannot replace a GitHub build.
