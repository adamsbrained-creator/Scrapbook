# R8 settings for the release build (see app/build.gradle.kts).
#
# Names are NOT scrambled: the crash page (Crash.kt) shows stack traces, and they are only useful when the names are readable.
# R8 still removes unused code and optimizes the rest, which is where the speed comes from.
-dontobfuscate
-keepattributes SourceFile,LineNumberTable

# Do not stop the build over a warning about a class from a library that is not used at run time.
-ignorewarnings

# Android starts the home-screen widget by name.
-keep class app.scrapbook.RediscoverReceiver { *; }
-keep class app.scrapbook.RediscoverWidget { *; }
