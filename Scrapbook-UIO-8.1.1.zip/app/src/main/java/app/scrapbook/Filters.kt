package app.scrapbook

import java.util.Calendar
import java.util.TimeZone

// One filter for every list: type, box, tags and date together. The rules live here so the screens only show the sheet and apply the result.

enum class DateRange(val label: String) { AnyTime("Any time"), Today("Today"), Week("7 days"), Month("30 days"), Year("Past year") }

/** Which date the range looks at: when the scrap was last edited, or when it was made. */
enum class DateField(val label: String) { Edited("Edited"), Created("Created") }

private const val FILTER_DAY_MS = 86_400_000L

/** The earliest time that still counts for this range, or null for any time. Today starts at midnight in [zone]. */
fun DateRange.cutoff(now: Long, zone: TimeZone = TimeZone.getDefault()): Long? = when (this) {
    DateRange.AnyTime -> null
    DateRange.Today -> Calendar.getInstance(zone).apply {
        timeInMillis = now; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    DateRange.Week -> now - 7 * FILTER_DAY_MS
    DateRange.Month -> now - 30 * FILTER_DAY_MS
    DateRange.Year -> now - 365 * FILTER_DAY_MS
}

/** What a list is narrowed to. Everything off (the default) shows everything. A scrap has to pass every filter that is on, and carry all the chosen tags. */
data class ScrapFilter(
    val kind: Kind? = null, val box: String? = null, val tags: Set<String> = emptySet(),
    val range: DateRange = DateRange.AnyTime, val field: DateField = DateField.Edited,
) {
    /** How many kinds of filter are on: type, box, tags and date count once each. */
    val count: Int get() = (if (kind != null) 1 else 0) + (if (box != null) 1 else 0) + (if (tags.isNotEmpty()) 1 else 0) + (if (range != DateRange.AnyTime) 1 else 0)
    val isOn: Boolean get() = count > 0

    fun hasTag(tag: String): Boolean = tags.any { it.equals(tag, ignoreCase = true) }
    fun toggleTag(tag: String): ScrapFilter = copy(tags = if (hasTag(tag)) tags.filterNot { it.equals(tag, ignoreCase = true) }.toSet() else tags + tag)

    /** One piece of text, so a screen can keep its filter across a rotation. */
    fun encode(): String = listOf(kind?.name.orEmpty(), box.orEmpty(), tags.joinToString("\u001F"), range.name, field.name).joinToString("\u001E")
}

/** Reads what [ScrapFilter.encode] wrote. Anything unreadable gives the plain "show everything" filter. */
fun decodeFilter(s: String?): ScrapFilter {
    val p = s?.split('\u001E') ?: return ScrapFilter()
    if (p.size != 5) return ScrapFilter()
    return ScrapFilter(
        kind = Kind.entries.firstOrNull { it.name == p[0] }, box = p[1].ifEmpty { null },
        tags = if (p[2].isEmpty()) emptySet() else p[2].split('\u001F').toSet(),
        range = DateRange.entries.firstOrNull { it.name == p[3] } ?: DateRange.AnyTime, field = DateField.entries.firstOrNull { it.name == p[4] } ?: DateField.Edited,
    )
}

/** The scraps that pass [f] at time [now]. With nothing on, the list itself. */
fun List<Item>.filteredBy(f: ScrapFilter, now: Long, zone: TimeZone = TimeZone.getDefault()): List<Item> {
    if (!f.isOn) return this
    val since = f.range.cutoff(now, zone)
    return filter { n ->
        (f.kind == null || n.kind == f.kind) && (f.box == null || n.collection == f.box) && f.tags.all { n.hasTag(it) } &&
            (since == null || (if (f.field == DateField.Created) n.createdAt else n.savedAt) >= since)
    }
}
