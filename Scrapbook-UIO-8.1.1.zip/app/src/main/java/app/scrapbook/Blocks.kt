package app.scrapbook

/**
 * The three parts a scrap's page is made of, in the order you chose for it: its photos, its attached files and its text.
 * The same order is used while reading and while writing, so the page never jumps around when you switch between them.
 * (The cover and the source line always stay at the very top.)
 */
enum class Block { Photos, Files, Text }

object Blocks {
    /** What a scrap shows until you arrange it: photos, then files, then the text. */
    val DEFAULT = listOf(Block.Photos, Block.Files, Block.Text)

    /** Reads the saved order ("Text,Photos,Files"). Anything unknown or repeated is skipped, anything missing goes at the end, so the result always holds each block exactly once. */
    fun parse(saved: String?): List<Block> {
        val out = ArrayList<Block>(3)
        for (part in saved.orEmpty().split(',')) {
            val b = Block.entries.firstOrNull { it.name == part.trim() } ?: continue
            if (b !in out) out.add(b)
        }
        for (b in DEFAULT) if (b !in out) out.add(b)
        return out
    }

    /** The text to store. The default order is stored as nothing at all, so scraps nobody arranged stay exactly as they were. */
    fun encode(order: List<Block>): String {
        val full = parse(order.joinToString(",") { it.name })
        return if (full == DEFAULT) "" else full.joinToString(",") { it.name }
    }

    /** Moves the block at [from] to position [to] (both counted in the list), keeping the others in order. Out-of-range moves change nothing. */
    fun move(order: List<Block>, from: Int, to: Int): List<Block> {
        if (from !in order.indices || to !in order.indices || from == to) return order
        return order.toMutableList().also { it.add(to, it.removeAt(from)) }
    }
}
