package app.scrapbook

// Version history and the Bin: the rules, kept apart from the database so they can be tested on their own.

/** A scrap in the Bin is deleted for good after this many days. */
const val BIN_DAYS = 30

/** At most this many earlier versions are kept for one scrap. The oldest go first. */
const val MAX_VERSIONS = 30

/** While you keep editing, an earlier version is put aside about this often. */
const val VERSION_GAP_MS = 5 * 60_000L

/** Text this long (characters) counts as worth keeping a version of when it first shows up, and as a big loss when half of it vanishes. */
private const val SUBSTANTIAL_CHARS = 200

private const val DAY_MS = 86_400_000L

/**
 * Called just before a save replaces [prev] (what is stored now) with [next]: should [prev] be put aside as a version first?
 * [last] is the newest version already kept for this scrap, [now] the clock in milliseconds. Only the title and the text count.
 *
 * Yes when the text changed, there is something in it, we do not already hold exactly this text, and one of these is true:
 * - a new editing session is starting: the stored text had sat untouched for VERSION_GAP_MS or more, so this keeps how it was before you began;
 * - you have been editing a long time: the newest version is VERSION_GAP_MS old, so the history gets a point along the way;
 * - this is the first version and the text is already substantial;
 * - a big chunk just vanished (the text got half as long or shorter): the classic select-all-and-delete or paste-over accident.
 */
fun shouldSnapshot(prev: Item, next: Item, last: ItemVersion?, now: Long): Boolean {
    if (prev.title == next.title && prev.body == next.body) return false
    if (prev.title.isBlank() && prev.body.isBlank()) return false
    if (last != null && last.title == prev.title && last.body == prev.body) return false
    if (now - prev.savedAt >= VERSION_GAP_MS) return true
    val substantial = prev.body.length >= SUBSTANTIAL_CHARS
    if (last == null) { if (substantial) return true } else if (now - last.takenAt >= VERSION_GAP_MS) return true
    return substantial && next.body.length * 2 <= prev.body.length
}

/** The moment before which a scrap deleted then is past its time in the Bin. */
fun binCutoff(now: Long): Long = now - BIN_DAYS * DAY_MS

/** Whole days a scrap deleted at [deletedAt] has left in the Bin (a started day counts). 0 means it is due to go. */
fun binDaysLeft(deletedAt: Long, now: Long): Int {
    val left = deletedAt + BIN_DAYS * DAY_MS - now
    return if (left <= 0) 0 else ((left + DAY_MS - 1) / DAY_MS).toInt()
}

/** A photo file younger than this is never swept: it may have just been picked or restored and not saved onto a scrap yet. */
const val IMAGE_GRACE_MS = DAY_MS

/**
 * Which photo files in app storage can go: [files] are (file name, last modified) pairs, [referencedText] is all the text of every scrap
 * (Bin included) and box that could mention a photo. A file is kept if it is young, or if its name appears anywhere in that text,
 * which also keeps a photo shared by a duplicated scrap for as long as one of them still uses it.
 */
fun orphanImages(files: List<Pair<String, Long>>, referencedText: String, now: Long): List<String> =
    files.filter { (name, modified) -> now - modified >= IMAGE_GRACE_MS && !referencedText.contains(name) }.map { it.first }
