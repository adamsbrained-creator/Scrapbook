package app.scrapbook

import java.text.DateFormat
import java.util.Date
import java.util.Locale

// The plain rules behind the editor's extra tools: a clean copy of a scrap for sharing, moving lines, checklist helpers, today's date and
// find-and-replace. They work on text and positions only (no screen code), so they can be tested on their own.

/** New text with the selection (or cursor, when [start] == [end]) in it. */
data class TextEdit(val text: String, val start: Int, val end: Int)

// ---------------------------------------------------------------------------------------------------------------------------------
// Share and copy
// ---------------------------------------------------------------------------------------------------------------------------------

private val LINK_RE = Regex("\\[([^\\]\\n]+)\\]\\(([^)\\s]*)\\)")
private val NUM_START = Regex("^\\d+\\. ")

/**
 * A scrap as plain text for sharing or copying: the title, then the text without its formatting codes. Lists keep a visible marker (• ☐ ☑ or the number),
 * indents stay, a divider becomes a line, and a link keeps its address: "docs (https://example.com)". A first line that only repeats the title is dropped.
 */
fun plainText(title: String, body: String): String {
    val head = title.trim()
    val bodyLines = (if (head.isEmpty()) body else bodyWithoutTitle(head, body)).lines(); val code = codeLineStates(bodyLines)
    // Code keeps its own text, indented four spaces so it stays set apart without the fences; everything else loses its formatting codes.
    val lines = bodyLines.mapIndexedNotNull { i, l ->
        when (code[i]) { CodeLine.OPEN, CodeLine.CLOSE -> null; CodeLine.BODY -> if (l.isEmpty()) "" else "    $l"; else -> plainLine(l) }
    }
    val text = lines.joinToString("\n").trim('\n')
    return when { head.isEmpty() -> text; text.isBlank() -> head; else -> head + "\n\n" + text }
}

private fun plainLine(raw: String): String {
    if (raw.trim() == "---") return "———"
    val prefix = LINE_PREFIX_RE.find(raw)?.value.orEmpty()
    val afterPrefix = raw.substring(prefix.length)
    val tags = LINE_TAGS.find(afterPrefix)
    val indent = tags?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
    val rest = afterPrefix.substring(tags?.value?.length ?: 0)
    val text = stripInline(LINK_RE.replace(rest) { m ->
        val label = m.groupValues[1]; val url = m.groupValues[2]
        if (url.isBlank() || label == url) label else "$label ($url)"
    })
    val marker = when {
        prefix == "- [ ] " -> "☐ "
        prefix == "- [x] " -> "☑ "
        prefix == "- " -> "• "
        prefix == "> " -> "> "
        NUM_START.matches(prefix) -> prefix
        else -> ""
    }
    return "  ".repeat(indent) + marker + text
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Today's date
// ---------------------------------------------------------------------------------------------------------------------------------

/** Today as written in the phone's language, for example "Oct 17, 2026" or "17 Oct 2026". */
fun todayText(now: Long = System.currentTimeMillis(), locale: Locale = Locale.getDefault()): String =
    DateFormat.getDateInstance(DateFormat.MEDIUM, locale).format(Date(now))

/** [insert] put where the selection is (it replaces the selected text); the cursor ends up after it. */
fun insertAt(text: String, selStart: Int, selEnd: Int, insert: String): TextEdit {
    val a = minOf(selStart, selEnd).coerceIn(0, text.length); val b = maxOf(selStart, selEnd).coerceIn(0, text.length)
    val out = text.substring(0, a) + insert + text.substring(b)
    return TextEdit(out, a + insert.length, a + insert.length)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Move lines
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * Moves the line the cursor is on (or every line the selection touches) one line up or down, and takes the selection along. Null when it is
 * already the first or last line. In a numbered list the numbers stay where they are, so "1. 2. 3." never gets out of order.
 */
fun moveLines(text: String, selStart: Int, selEnd: Int, up: Boolean): TextEdit? {
    val lines = text.split("\n")
    val a0 = minOf(selStart, selEnd).coerceIn(0, text.length); val b0 = maxOf(selStart, selEnd).coerceIn(0, text.length)
    fun pos(off: Int): Pair<Int, Int> {
        var start = 0
        for (i in lines.indices) { val end = start + lines[i].length; if (off <= end) return i to (off - start); start = end + 1 }
        return lines.lastIndex to lines.last().length
    }
    val (sl, sc) = pos(a0)
    var (el, ec) = pos(b0)
    // A selection that ends at the very start of a line does not include that line.
    if (b0 > a0 && ec == 0 && el > sl) { el -= 1; ec = lines[el].length }
    if (if (up) sl == 0 else el == lines.lastIndex) return null
    val nb = if (up) sl - 1 else el + 1
    val block = lines.subList(sl, el + 1).toList()
    val out = ArrayList<String>(lines.size)
    if (up) { out += lines.subList(0, nb); out += block; out += lines[nb]; out += lines.subList(el + 1, lines.size) }
    else { out += lines.subList(0, sl); out += lines[nb]; out += block; out += lines.subList(el + 2, lines.size) }
    // Numbers belong to the place, not to the text that moved.
    for (p in minOf(sl, nb)..maxOf(el, nb)) {
        val op = NUM_START.find(lines[p])?.value; val np = NUM_START.find(out[p])?.value
        if (op != null && np != null && op != np) out[p] = op + out[p].substring(np.length)
    }
    val d = if (up) -1 else 1
    fun offsetOf(line: Int, col: Int): Int {
        val moved = lines[line]; val now = out[line + d]
        val po = NUM_START.find(moved)?.value?.length ?: 0; val pn = NUM_START.find(now)?.value?.length ?: 0
        val c = (if (po > 0 && pn > 0) maxOf(col - po, 0) + pn else col).coerceAtMost(now.length)
        var off = 0
        for (i in 0 until line + d) off += out[i].length + 1
        return off + c
    }
    return TextEdit(out.joinToString("\n"), offsetOf(sl, sc), offsetOf(el, ec))
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Checklists
// ---------------------------------------------------------------------------------------------------------------------------------

private val CHECK_RE = Regex("^- \\[([ x])\\] ")

fun isCheckLine(line: String) = CHECK_RE.containsMatchIn(line)
fun isTicked(line: String) = CHECK_RE.find(line)?.groupValues?.get(1) == "x"

/** How many checklist items the text has, and how many of them are ticked. */
fun checklistCounts(text: String): Pair<Int, Int> {
    val all = text.lines(); val code = codeLineStates(all)
    val items = all.filterIndexed { i, l -> code[i] == CodeLine.NONE && isCheckLine(l) }   // a "- [ ]" inside a code block is code, not a task
    return items.size to items.count { isTicked(it) }
}

enum class CheckAction { TickedToBottom, ClearTicked, UntickAll }

/**
 * Tidies the checklist the cursor is in (a run of checklist lines with nothing between them). When the cursor is not in a checklist it tidies
 * every checklist in the text. Null when nothing would change. The cursor ends up at the start of the first list that was tidied.
 */
fun applyChecklist(text: String, cursor: Int, action: CheckAction): TextEdit? {
    val lines = text.split("\n").toMutableList()
    val blocks = mutableListOf<IntRange>(); var i = 0
    val code = codeLineStates(lines)
    fun task(n: Int) = code[n] == CodeLine.NONE && isCheckLine(lines[n])   // code is never tidied
    while (i < lines.size) {
        if (task(i)) { var j = i; while (j + 1 < lines.size && task(j + 1)) j++; blocks += i..j; i = j + 1 } else i++
    }
    if (blocks.isEmpty()) return null
    val cur = text.substring(0, cursor.coerceIn(0, text.length)).count { it == '\n' }
    val targets = blocks.firstOrNull { cur in it }?.let { listOf(it) } ?: blocks
    for (r in targets.reversed()) {
        val part = lines.subList(r.first, r.last + 1).toList()
        val replaced = when (action) {
            CheckAction.TickedToBottom -> part.filter { !isTicked(it) } + part.filter { isTicked(it) }
            CheckAction.ClearTicked -> part.filter { !isTicked(it) }
            CheckAction.UntickAll -> part.map { it.replaceFirst("- [x] ", "- [ ] ") }
        }
        if (replaced == part) continue
        repeat(part.size) { lines.removeAt(r.first) }
        lines.addAll(r.first, replaced)
    }
    val out = lines.joinToString("\n")
    if (out == text) return null
    val at = lines.take(targets.first().first).sumOf { it.length + 1 }.coerceAtMost(out.length)
    return TextEdit(out, at, at)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Find and replace
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * Where [query] occurs in the saved text [original] and can also be seen, whole, in the [shown] text (the saved text with its hidden marks taken away;
 * [toShown] says where a saved position lands in it). Matches that sit inside hidden marks, like a link's address or a color code, or that a mark
 * cuts in two, are left out, so replacing never touches what the page does not show. Same matching as findMatches: no capitals needed, no overlaps.
 */
fun visibleOccurrences(original: String, query: String, toShown: (Int) -> Int, shown: String): List<IntRange> {
    val q = query.trim()
    if (q.isEmpty()) return emptyList()
    val out = ArrayList<IntRange>(); var i = 0
    while (i <= original.length - q.length) {
        if (original.regionMatches(i, q, 0, q.length, ignoreCase = true)) {
            val ts = toShown(i); val te = toShown(i + q.length)
            if (ts >= 0 && te <= shown.length && te - ts == q.length && shown.regionMatches(ts, q, 0, q.length, ignoreCase = true)) out += i until i + q.length
            i += q.length
        } else i++
    }
    return out
}

/** [text] with every range swapped for [with]. */
fun replaceRanges(text: String, ranges: List<IntRange>, with: String): String {
    val sb = StringBuilder(text)
    for (r in ranges.sortedByDescending { it.first }) sb.replace(r.first, r.last + 1, with)
    return sb.toString()
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Font sizes
// ---------------------------------------------------------------------------------------------------------------------------------

/** The sizes the size list offers, like Samsung Notes: every size from 6 to 30, then every second one up to 48, then every fourth up to 64. */
val FONT_SIZES: List<Int> = (6..30).toList() + (32..48 step 2) + (52..64 step 4)

// ---------------------------------------------------------------------------------------------------------------------------------
// Font colors: typed or pasted, and remembered
// ---------------------------------------------------------------------------------------------------------------------------------

private val HEX_RE = Regex("^(?:#|0x)?([0-9a-f]{6})$")
private val SHORT_HEX_RE = Regex("^#([0-9a-f]{3})$")
private val RGB_RE = Regex("^(?:rgb\\s*\\(\\s*)?(\\d{1,3})\\s*[,\\s]\\s*(\\d{1,3})\\s*[,\\s]\\s*(\\d{1,3})\\s*\\)?$")

/**
 * A color typed or pasted in the usual ways, as the six hex digits in small letters ("ff8800"), or null when it is not one. Hex: "#ff8800", "ff8800", "0xff8800",
 * or the short "#f80" (that one needs its #, so a plain 255 is never taken for a color). RGB: "rgb(255, 136, 0)", "255, 136, 0" or "255 136 0", each number 0 to 255.
 */
fun parseColorText(raw: String): String? {
    val s = raw.trim().lowercase()
    HEX_RE.matchEntire(s)?.let { return it.groupValues[1] }
    SHORT_HEX_RE.matchEntire(s)?.let { m -> return m.groupValues[1].map { "$it$it" }.joinToString("") }
    RGB_RE.matchEntire(s)?.let { m ->
        val v = m.groupValues.drop(1).map { it.toInt() }
        if (v.all { it in 0..255 }) return "%02x%02x%02x".format(v[0], v[1], v[2])
    }
    return null
}

fun hexToRgb(hex: String): Int = hex.toIntOrNull(16) ?: 0
fun rgbToHex(rgb: Int): String = "%06x".format(rgb and 0xFFFFFF)
private fun isHex6(s: String) = s.length == 6 && s.all { it in '0'..'9' || it in 'a'..'f' }

/** The most colors kept in the Recent row of the font color panel. */
const val MAX_RECENT_COLORS = 6

/** The saved Recent colors (one per line) back into a list; anything that is not six hex digits is dropped. */
fun parseRecentColors(stored: String?): List<String> =
    (stored ?: "").lines().map { it.trim().lowercase() }.filter { isHex6(it) }.distinct().take(MAX_RECENT_COLORS)

fun encodeRecentColors(list: List<String>): String = list.joinToString("\n")

/** [hex] put at the front of [list]; one already there moves up instead of repeating, the list is cut to [max], and something that is not a color is ignored. */
fun addRecentColor(list: List<String>, hex: String, max: Int = MAX_RECENT_COLORS): List<String> {
    val h = hex.trim().lowercase()
    if (!isHex6(h)) return list
    return (listOf(h) + list.filterNot { it == h }).take(max)
}
