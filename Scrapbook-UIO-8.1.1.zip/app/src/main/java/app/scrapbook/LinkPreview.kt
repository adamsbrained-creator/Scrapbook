package app.scrapbook

// Link cards: what a web page says about itself for sharing (its title, a short description, a preview photo and the site's name, the same tags
// other apps use to show a link preview), turned into a few lines for a scrap. Reading the page is in ArchiveViewModel; the rules for what to keep and how
// the card looks are here, on plain strings, so they can be tested. Note this is the page's own description, not a summary written by anything.

data class LinkPreview(val title: String?, val description: String?, val imageUrl: String?, val siteName: String?) {
    /** Whether the page gave anything worth a card. */
    val hasContent: Boolean get() = title != null || description != null || imageUrl != null
}

private val META_TAG = Regex("<meta\\s[^>]*>", RegexOption.IGNORE_CASE)
private val ATTRIBUTE = Regex("([a-zA-Z_:][-a-zA-Z0-9_:.]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')")
private val NUMERIC_ENTITY = Regex("&#([xX]?)([0-9a-fA-F]{1,6});")

/** Decodes the HTML entities pages put in their descriptions and titles: &amp; &quot; &#39; &#x2019; and so on. */
fun decodeEntities(s: String): String {
    var out = NUMERIC_ENTITY.replace(s) { m ->
        val cp = m.groupValues[2].toIntOrNull(if (m.groupValues[1].isEmpty()) 10 else 16)
        if (cp != null && cp in 1..0x10FFFF && cp !in 0xD800..0xDFFF) String(Character.toChars(cp)) else m.value
    }
    out = out.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
    return out.replace("&amp;", "&")
}

private fun tidy(s: String?): String? = s?.let { decodeEntities(it) }?.replace(Regex("\\s+"), " ")?.trim()?.takeIf { it.isNotEmpty() }

/** A description cut to about [max] characters at a word, with an ellipsis when something was cut. */
fun shortDescription(text: String, max: Int = 280): String {
    if (text.length <= max) return text
    val cut = text.take(max); val sp = cut.lastIndexOf(' ')
    return (if (sp > max * 6 / 10) cut.substring(0, sp) else cut).trimEnd(' ', ',', ';', ':', '-', '.') + "\u2026"
}

/** The address of a preview photo as an absolute, secure one (a relative address is resolved against the page; http becomes https), or null. */
fun previewImageUrl(ref: String?, pageUrl: String): String? {
    val r = ref?.trim()?.takeIf { it.isNotEmpty() } ?: return null
    val abs = runCatching { java.net.URI(pageUrl).resolve(decodeEntities(r)).toString() }.getOrNull() ?: return null
    return when {
        abs.startsWith("https://", ignoreCase = true) -> abs
        abs.startsWith("http://", ignoreCase = true) -> "https://" + abs.substring(7)
        else -> null
    }
}

/** Reads the sharing tags of a page: title, description, photo and site name, each from the first tag that has it, else from the page's own title and description. */
fun parseLinkPreview(html: String, pageUrl: String): LinkPreview {
    val metas = HashMap<String, String>()
    for (m in META_TAG.findAll(html)) {
        var key: String? = null; var content: String? = null
        for (a in ATTRIBUTE.findAll(m.value)) {
            val v = a.groupValues[2].ifEmpty { a.groupValues[3] }
            when (a.groupValues[1].lowercase()) { "property", "name" -> if (key == null) key = v.trim().lowercase(); "content" -> content = v }
        }
        if (key != null && content != null) metas.putIfAbsent(key, content)
    }
    fun first(vararg keys: String) = keys.firstNotNullOfOrNull { k -> tidy(metas[k]) }
    val title = first("og:title", "twitter:title") ?: tidy(extractTitle(html))
    val description = first("og:description", "twitter:description", "description")?.let { shortDescription(it) }
    val image = previewImageUrl(first("og:image:secure_url", "og:image", "twitter:image", "twitter:image:src"), pageUrl)
    return LinkPreview(title?.take(150), description, image, first("og:site_name")?.take(60))
}

/**
 * The lines of a link card: the title in bold (left out when it became the scrap's own title), the description as a quote, and below them the link,
 * labeled with the site's name. The photo is not part of the text: it goes into the scrap's photos, which sit above the text.
 */
fun linkCardText(url: String, p: LinkPreview, includeTitle: Boolean): String {
    val lines = ArrayList<String>()
    if (includeTitle && p.title != null) lines += "**" + p.title.replace("*", "") + "**"
    if (p.description != null) lines += "> " + p.description
    val link = linkMarkdown(url, p.siteName ?: hostLabel(url))
    return if (lines.isEmpty()) link else lines.joinToString("\n") + "\n\n" + link
}
