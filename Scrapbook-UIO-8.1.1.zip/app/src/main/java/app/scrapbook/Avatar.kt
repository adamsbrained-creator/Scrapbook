package app.scrapbook

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File

/**
 * The profile picture. A picked photo is turned upright (cameras often store photos sideways and add a note saying so), cut to the square the person chose
 * (see [AvatarCrop]; the middle of the photo when it was not moved), made 512 pixels wide and saved as avatar_<time>.jpg in the app's own storage. The name starts
 * with "avatar_" on purpose: clearing out unused photos only touches files named img_ or imp_, so the picture is never swept away with them.
 */
object Avatar {
    const val PREFIX = "avatar_"
    private const val SIZE = 512

    /**
     * The photo at [uri], upright, and no bigger than [maxSide] pixels on its longer side (a 50 megapixel photo must not fill the phone's memory), or null when it
     * cannot be read. Run on a background thread.
     */
    fun decodeUpright(ctx: Context, uri: Uri, maxSide: Int = 2048): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val src = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) } ?: return null
        val rotation = cr.openInputStream(uri)?.use { input ->
            runCatching {
                when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }.getOrDefault(0f)
        } ?: 0f
        if (rotation == 0f) return src
        val upright = Bitmap.createBitmap(src, 0, 0, src.width, src.height, Matrix().apply { postRotate(rotation) }, true)
        if (upright !== src) src.recycle()
        return upright
    }

    /** Saves the part of the photo at [uri] that [crop] chose and returns the address of the new file, or null when it could not be read. Run on a background thread. */
    fun save(ctx: Context, uri: Uri, crop: AvatarCrop = AvatarCrop.Center): String? {
        val src = decodeUpright(ctx, uri) ?: return null
        val sq = crop.square(src.width, src.height)
        val cut = Bitmap.createBitmap(src, sq[0], sq[1], sq[2], sq[2])
        val out = if (sq[2] == SIZE) cut else Bitmap.createScaledBitmap(cut, SIZE, SIZE, true)
        val file = File(ctx.filesDir, "$PREFIX${System.currentTimeMillis()}.jpg")
        file.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        if (out !== cut) out.recycle()
        if (cut !== src) cut.recycle()
        src.recycle()
        return Uri.fromFile(file).toString()
    }

    /** Deletes the file behind an address saved by [save]. Anything not named avatar_ is left alone. */
    fun delete(address: String?) {
        val path = address?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it).path } ?: return
        val f = File(path)
        if (f.name.startsWith(PREFIX)) f.delete()
    }
}
