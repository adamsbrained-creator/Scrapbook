package app.scrapbook

/**
 * The order of the Boxes row on the home page when it follows activity. The Inbox comes first while it has scraps; then the other boxes with the
 * one you worked in most recently first; boxes with nothing in them (or below them) go last, in your own order. [lastEdited] holds, for each box
 * that has scraps, the time its newest scrap was edited, counting the boxes inside it; a box that is not in it is empty. Ties keep [names]' order.
 */
fun orderBoxesByActivity(names: List<String>, lastEdited: Map<String, Long>, inbox: String = "Inbox"): List<String> {
    val active = names.filter { it in lastEdited }
    val empty = names.filter { it !in lastEdited }
    return active.filter { it == inbox } + active.filter { it != inbox }.sortedByDescending { lastEdited.getValue(it) } + empty
}
