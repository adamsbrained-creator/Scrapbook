package app.scrapbook

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * The launcher icon follows the accent color. Android can't change an icon in place, so the manifest has one
 * <activity-alias> per accent (".IconCoral", ".IconTeal", ...), each with its own icon, and exactly one is enabled at a time.
 * The order here is the order of Themes in ui/Theme.kt (a unit test checks that they match).
 */
object AppIcon {
    val names = listOf("Coral", "Teal", "Amber", "Violet", "Green", "Pink", "Blue")

    /** Shows the icon for accent number [index] and hides the others. Does nothing if it is already showing. */
    fun apply(ctx: Context, index: Int) {
        val pm = ctx.packageManager
        val want = index.coerceIn(names.indices)
        fun comp(i: Int) = ComponentName(ctx.packageName, "app.scrapbook.Icon${names[i]}")
        fun on(i: Int): Boolean = when (pm.getComponentEnabledSetting(comp(i))) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> false
            else -> i == 0 // never touched: the manifest starts with Coral enabled and the rest disabled
        }
        runCatching {
            // Turn the new one on first, so there is never a moment with no launcher icon at all.
            if (!on(want)) pm.setComponentEnabledSetting(comp(want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            names.indices.filter { it != want && on(it) }.forEach {
                pm.setComponentEnabledSetting(comp(it), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
