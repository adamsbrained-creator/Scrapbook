package app.scrapbook

/**
 * The designs a part of Home can have, chosen from the icon on its row in Customize home. Every choice is optional: [default] is how Home looks without
 * any choice (the first option, except for sizes, where it is Regular). [key] is what is saved, so never rename one, and only ever add options at the end.
 * [hints] say in a few words what each option looks like.
 */
enum class HomeStyleKey(
    val key: String, val element: HomeElement, val label: String, val options: List<String>, val hints: List<String>, val default: Int = 0,
) {
    GreetingStyle("greetStyle", HomeElement.Greeting, "Style", listOf("Classic", "Centered", "Card", "Bubble", "Banner", "Minimal"),
        listOf("Greeting on the left, your picture on the right.", "Your picture on top, the greeting centered under it.", "The greeting sits on a rounded card, like the other parts of Home.",
            "The greeting is a chat bubble next to your picture, with the date under it.", "A wide banner with a color wash and a bigger greeting.", "One small quiet line with a tiny picture, no date.")),
    GreetingPicture("greetPic", HomeElement.Greeting, "Picture side", listOf("Right", "Left"),
        listOf("The picture sits at the end of the line.", "The picture sits at the start of the line.")),
    CaptureStyle("captureStyle", HomeElement.Capture, "Style", listOf("Classic", "Slim", "Icons only"),
        listOf("The writing card with shortcuts and the New scrap button.", "One line to write on, with a small add button.", "A row of round buttons: new scrap, checklist, photo, link.")),
    ContinueStyle("continueStyle", HomeElement.Continue, "Style", listOf("Classic", "Thin", "With preview"),
        listOf("The card with the scrap's name, box and time.", "A single thin line.", "The classic card with the first lines of the scrap under it.")),
    BoxesStyle("boxesStyle", HomeElement.Boxes, "Style", listOf("Chips", "Grid", "List"),
        listOf("A row of chips you swipe along.", "Two columns of boxes, up to 8.", "One box per line with its count, up to 6.")),
    PinnedStyle("pinnedStyle", HomeElement.Pinned, "Style", listOf("Cards", "List", "Grid"),
        listOf("A row of cards you swipe along.", "One pinned scrap per line, up to 8.", "Two columns of cards, up to 6.")),
    PinnedSize("pinnedSize", HomeElement.Pinned, "Card size", listOf("Small", "Regular", "Large"),
        listOf("Narrow cards.", "The usual size.", "Wide, tall cards."), default = 1),
    RecentStyle("recentStyle", HomeElement.Recent, "Style", listOf("Cards", "Compact"),
        listOf("The usual scrap cards.", "One short line per scrap.")),
    RecentCount("recentCount", HomeElement.Recent, "How many", listOf("3", "4", "6", "8"),
        listOf("The latest 3 scraps.", "The latest 4 scraps.", "The latest 6 scraps.", "The latest 8 scraps."), default = 1),
    GreetingBackground("greetBg", HomeElement.Greeting, "Background", listOf("Automatic", "None", "Card", "Tint", "Accent", "Gradient", "Outline"),
        listOf("Whatever suits the style: nothing, a card or a color wash.", "No background at all.", "A plain card, like the other parts of Home.", "A soft wash of your accent color.",
            "Your accent color, filled.", "A gradient of your accent color.", "A thin line in your accent color.")),
    GreetingShape("greetShape", HomeElement.Greeting, "Picture shape", listOf("Circle", "Squircle", "Leaf"),
        listOf("A round picture.", "A square picture with soft corners.", "Two rounded corners and two soft ones, like a leaf.")),
    GreetingAnimation("greetAnim", HomeElement.Greeting, "New line appears", listOf("Fade", "Slide", "Typing", "Pop"),
        listOf("The old line fades out and the new one fades in.", "The new line slides up while the old one slides away.", "The new line is typed out letter by letter.", "The new line pops in."));

    /** The number written in the option when it is a count. */
    fun number(index: Int): Int = options.getOrNull(index)?.toIntOrNull() ?: 0

    companion object {
        fun of(key: String): HomeStyleKey? = entries.firstOrNull { it.key == key }
        fun forElement(e: HomeElement): List<HomeStyleKey> = entries.filter { it.element == e }
    }
}

/**
 * The designs chosen for the parts of Home. Only choices that differ from the default are kept, so an empty one is the classic Home and two equal
 * choices are always equal. Nothing here touches Android, so the rules are tested on their own (HomeStylesTest).
 */
data class HomeStyles(val values: Map<HomeStyleKey, Int> = emptyMap()) {
    /** The chosen option's index, or the default one; always a real option. */
    operator fun get(k: HomeStyleKey): Int = (values[k] ?: k.default).coerceIn(0, k.options.lastIndex)

    /** The same choices with [k] set to option [index] (out of range is brought back into range). Choosing the default drops the choice. */
    fun with(k: HomeStyleKey, index: Int): HomeStyles {
        val i = index.coerceIn(0, k.options.lastIndex)
        return copy(values = if (i == k.default) values - k else values + (k to i))
    }

    /** True when nothing about this part differs from the classic look. */
    fun isDefault(e: HomeElement): Boolean = HomeStyleKey.forElement(e).all { it !in values }

    /** Every choice for this part back to the classic look. */
    fun reset(e: HomeElement): HomeStyles = copy(values = values.filterKeys { it.element != e })

    /** What differs from the classic look, in a few words (like Grid · Large), or an empty text. */
    fun summary(e: HomeElement): String =
        HomeStyleKey.forElement(e).filter { it in values }.joinToString(" · ") { it.options[get(it)] }

    /** Saved as `key=index` pairs in the order of [HomeStyleKey]; the classic look is an empty text. */
    fun encode(): String = HomeStyleKey.entries.filter { it in values }.joinToString(",") { "${it.key}=${get(it)}" }

    companion object {
        val Default = HomeStyles()

        /** Reads what [encode] wrote. Unknown names, unreadable numbers and choices equal to the default are dropped; numbers out of range are brought back in. */
        fun decode(s: String?): HomeStyles {
            var out = Default
            s.orEmpty().split(',').forEach { pair ->
                val k = HomeStyleKey.of(pair.substringBefore('=', "").trim()) ?: return@forEach
                val v = pair.substringAfter('=', "").trim().toIntOrNull() ?: return@forEach
                out = out.with(k, v)
            }
            return out
        }
    }
}
