package app.scrapbook

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Layout(val label: String) {
    Classic("Classic"), Journal("Journal"), Gallery("Gallery"), TwoColumn("Two Column"),
    Quote("Quote"), Reference("Reference"), Collection("Box"), Blank("Blank Canvas")
}

enum class Kind { Note, Image, Quote, Link, Voice }

/** Content lives on the item; layout is only a view of it, so switching layouts never loses anything. */
@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val body: String, val kind: Kind, val collection: String,
    val tags: List<String> = emptyList(), val layout: Layout = Layout.Classic,
    val color: Int = 0, val pinned: Boolean = false, val savedAt: Long = System.currentTimeMillis(),
    val font: Int = 0, val density: Int = 1, val showMeta: Boolean = true,
    val imageUri: String? = null,
    val canvas: String = "",
    val source: String = "",
    val images: String = "",
    val accent: Int = 0, val cover: String? = null,
    /** 0 = a normal scrap. Otherwise the time it was deleted: it sits in the Bin until it is restored or BIN_DAYS have passed. */
    val deletedAt: Long = 0,
    /** When the scrap was first made. savedAt moves on every edit; this never does. Scraps from before this existed carry their earliest known date. */
    val createdAt: Long = System.currentTimeMillis(),
    /** One optional emoji (or other single character) shown in front of the title. "" = none. */
    val icon: String = "",
    /** Files attached to the scrap, one per line (see Attachments.kt). "" = none. */
    val files: String = "",
    /** A permanent id, for links to this scrap (see Links.kt). Unlike [id] it survives a backup restore and a reinstall. */
    val uid: String = newUid(),
    /** Where the text and each photo and file sit on the page, from the top down, e.g. "Photo,Text,File,Photo" (see PageLayout.kt; the older "Text,Photos,Files" is still read). Photos and files that wrap the text or float are added after a "|", one entry each (see Floats.kt). "" = the usual order, nothing placed. */
    val blocks: String = "",
)

/** An earlier text of a scrap (title and body), kept so a note can be taken back to how it was. savedAt is when that text was written, takenAt when it was put aside. */
@Entity(tableName = "item_versions")
data class ItemVersion(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long, val takenAt: Long, val savedAt: Long, val title: String, val body: String,
)

/**
 * A user-made collection (a "box"). Notes join it by [name] (Item.collection), and a box inside another box points at its parent by name ("" = main page).
 * [name] is the box's permanent key: it is never shown when [title] is set and it never changes, so renaming a box rewrites nothing.
 * [title] is what you read on screen; blank means the key is shown (every box made before titles existed). "Inbox", "All", "Pinned" and "Recent" are built in.
 */
@Entity(tableName = "collections")
data class Shelf(@PrimaryKey val name: String, val description: String = "", val color: Int = 0, val coverUri: String? = null, val parent: String = "", val title: String = "",
                 /** Hidden boxes (and everything in them) are left out of every list until they are unlocked with the PIN. See Privacy.kt. */
                 val hidden: Boolean = false)

/** The name of the box as shown on screen. */
val Shelf.label: String get() = title.ifBlank { name }

/** Names no box may be called, because they already mean something: the built-in boxes and views. Compared without caring about capitals. */
val RESERVED_BOX_NAMES = listOf("Inbox", "All", "Pinned", "Recent")
fun isReservedBoxName(s: String) = RESERVED_BOX_NAMES.any { it.equals(s.trim(), true) }

fun itemsLabel(n: Int) = if (n == 1) "1 item" else "$n items"

/** Main image first, then any extra images added to the note. */
fun Item.allImages(): List<String> = listOfNotNull(imageUri) + images.split("\n").filter { it.isNotBlank() }

/** What a type is called on screen: a plain note is a "Scrap". */
val Kind.label: String get() = if (this == Kind.Note) "Scrap" else name

/** Boxes that show on the main page: no parent, or a parent that no longer exists (so nothing can get lost). */
fun List<Shelf>.topLevel(): List<Shelf> { val names = map { it.name }.toSet(); return filter { it.parent.isBlank() || it.parent !in names } }

/** The boxes directly inside the box called name. */
fun List<Shelf>.childrenOf(name: String): List<Shelf> = filter { it.parent == name && it.name != name }

/** Every box inside name, at any depth (not including name itself). */
fun List<Shelf>.descendantsOf(name: String): List<Shelf> {
    val out = mutableListOf<Shelf>(); val seen = mutableSetOf(name); val queue = ArrayDeque(listOf(name))
    while (queue.isNotEmpty()) { val n = queue.removeFirst(); childrenOf(n).forEach { if (seen.add(it.name)) { out += it; queue += it.name } } }
    return out
}

/** Every box in reading order for the Shelf view: each main-page box, then the boxes inside it (and inside those), with how deep each one sits (0 = main page). Nothing is ever left out. */
fun List<Shelf>.inTreeOrder(): List<Pair<Shelf, Int>> {
    val out = mutableListOf<Pair<Shelf, Int>>(); val seen = mutableSetOf<String>()
    fun walk(s: Shelf, depth: Int) {
        if (!seen.add(s.name)) return
        out += s to depth
        childrenOf(s.name).forEach { walk(it, depth + 1) }
    }
    topLevel().forEach { walk(it, 0) }
    forEach { walk(it, 0) }
    return out
}

/** The boxes on the main page when parent is "", otherwise the boxes directly inside parent. */
fun List<Shelf>.inside(parent: String): List<Shelf> = if (parent.isBlank()) topLevel() else childrenOf(parent)

/** The name to show for a box key: its title, or the key itself for the built-in boxes and for a box that no longer exists. */
fun List<Shelf>.labelOf(key: String): String = firstOrNull { it.name == key }?.label ?: key

/** The boxes to pass through to reach key, outermost first, ending with key itself. Empty if there is no such box. Safe against loops. */
fun List<Shelf>.pathTo(key: String): List<Shelf> {
    val byName = associateBy { it.name }
    val out = ArrayList<Shelf>()
    var next: String? = key
    while (next != null && out.size < 30) {
        val s = byName[next] ?: break
        if (out.any { it.name == s.name }) break
        out.add(0, s)
        next = s.parent.ifBlank { null }
    }
    return out
}

/** "Trips › Italy": where a box sits, by title. A key with no box is returned as it is. */
fun List<Shelf>.pathOf(key: String): String = pathTo(key).map { it.label }.ifEmpty { listOf(key) }.joinToString(" › ")

/** Like [labelOf], but when another box has the same title the whole path is given, so two "tests" can be told apart in a list of boxes. */
fun List<Shelf>.displayName(key: String): String {
    val s = firstOrNull { it.name == key } ?: return key
    return if (count { it.label.equals(s.label, true) } > 1) pathOf(key) else s.label
}

/** A free key for a new box called title: the title itself, or "title 2", "title 3"… when that key is taken (by a box in another parent, say). Never a reserved name. */
fun List<Shelf>.newKey(title: String): String {
    val t = title.trim(); val taken = map { it.name.lowercase() }.toSet()
    fun free(k: String) = k.lowercase() !in taken && !isReservedBoxName(k)
    if (free(t)) return t
    var i = 2
    while (!free("$t $i")) i++
    return "$t $i"
}

/** Whether a box with this title is already in that parent ("" = main page). ignoring is the key of the box being edited, which does not clash with itself. */
fun List<Shelf>.titleTaken(title: String, parent: String, ignoring: String? = null): Boolean =
    any { it.name != ignoring && it.parent == parent && it.label.trim().equals(title.trim(), true) }

/** Every box key in the box key and inside it, at any depth. */
fun List<Shelf>.subtreeKeys(key: String): List<String> = listOf(key) + descendantsOf(key).map { it.name }

/** Whether the box key may be moved into parent ("" = main page): not into itself or anything inside it. */
fun List<Shelf>.canMoveInto(key: String, parent: String): Boolean = parent.isBlank() || (parent != key && parent !in descendantsOf(key).map { it.name })

/** What a list of scraps can be sorted by. The order of this list is the order the pickers show. */
enum class SortMode(val label: String, val short: String) { Edited("Date edited", "Edited"), Created("Date created", "Created"), Title("Title", "Title") }

/** The natural direction for a field: newest first for dates, A to Z for titles. `asc` below means oldest first or A to Z. */
val SortMode.naturalAsc: Boolean get() = this == SortMode.Title

/** Sorted by [mode], reversed unless [asc], and pinned scraps always first (the order inside each group is kept). */
fun List<Item>.sortedFor(mode: SortMode, asc: Boolean): List<Item> {
    val base = when (mode) {
        SortMode.Title -> sortedBy { it.title.lowercase() }
        SortMode.Created -> sortedBy { it.createdAt }
        SortMode.Edited -> sortedBy { it.savedAt }
    }
    return (if (asc) base else base.reversed()).sortedByDescending { it.pinned }
}

/** The title as it shows in lists and headers: the icon, if there is one, then the title. */
val Item.displayTitle: String get() = if (icon.isBlank()) title else "$icon $title".trim()

/** The first thing a person would call one character of [s]: an emoji with its modifiers counts as one. "" for an empty string. */
fun firstGlyph(s: String): String {
    if (s.isEmpty()) return ""
    val bi = java.text.BreakIterator.getCharacterInstance(); bi.setText(s)
    val end = bi.next()
    return s.substring(0, if (end == java.text.BreakIterator.DONE) s.length else end)
}
