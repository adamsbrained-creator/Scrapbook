package app.scrapbook

/**
 * The three kinds of place the menu has by default. A skin may print one on top of a group (Float does) when everything in that group comes from the same
 * section, so the name never lies after you have moved things around.
 */
enum class MenuSection(val title: String) { Browse("Browse"), Discover("Discover"), Manage("Manage") }

/**
 * Everything the menu can hold. [key] is what is saved, so never rename one; [label] and [icon] (a name Ic draws) are what the menu shows.
 * The order of the entries here is the default order of the menu.
 */
enum class MenuEntry(val key: String, val label: String, val icon: String, val section: MenuSection) {
    Home("home", "Home", "home", MenuSection.Browse),
    AllScraps("scraps", "All scraps", "list", MenuSection.Browse),
    Pinned("pinned", "Pinned", "star", MenuSection.Browse),
    Recent("recent", "Recently edited", "clock", MenuSection.Browse),
    Rediscover("rediscover", "Rediscover", "sparkle", MenuSection.Discover),
    Timeline("timeline", "Timeline", "book", MenuSection.Discover),
    GoTo("goto", "Go to…", "jump", MenuSection.Discover),
    Search("search", "Search", "search", MenuSection.Discover),
    Bin("bin", "Bin", "trash", MenuSection.Manage),
    CustomizeHome("customize", "Customize home", "layout", MenuSection.Manage),
    CustomizeMenu("custmenu", "Customize menu", "menu", MenuSection.Manage),
    Settings("settings", "Settings", "sliders", MenuSection.Manage),
    About("about", "About", "info", MenuSection.Manage);

    /** Settings is the way back into everything else (Customize menu lives there too), so it can never be hidden. */
    val canHide: Boolean get() = this != Settings

    companion object {
        fun of(key: String): MenuEntry? = entries.firstOrNull { it.key == key }
    }
}

/** One thing in the menu's order: an entry, or a break between two groups of entries. [key] is what a screen can use to tell them apart. */
sealed class MenuItem {
    abstract val key: String

    data class Entry(val entry: MenuEntry) : MenuItem() {
        override val key: String get() = entry.key
    }

    /** A break between two groups. [id] tells breaks apart (it is saved as "-1", "-2" and so on). */
    data class Gap(val id: Int) : MenuItem() {
        override val key: String get() = "-$id"
    }
}

/**
 * What the menu shows and in what order, top to bottom. [order] always holds every entry once (hidden ones keep their place, so showing one again puts it back
 * where it was) and any number of group breaks, up to [MAX_GAPS]; [hidden] are the entries that are switched off. A break starts a new card in the menu.
 * Nothing here touches Android, so the rules are tested on their own (MenuLayoutTest).
 */
data class MenuLayout(
    val order: List<MenuItem> = DEFAULT_ORDER,
    val hidden: Set<MenuEntry> = emptySet(),
) {
    fun isHidden(e: MenuEntry): Boolean = e in hidden

    /** The group breaks, in the order they sit in. */
    val gaps: List<MenuItem.Gap> get() = order.filterIsInstance<MenuItem.Gap>()

    /** Moves the item at [from] to position [to]. Anything outside the list changes nothing. */
    fun move(from: Int, to: Int): MenuLayout {
        if (from == to || from !in order.indices || to !in order.indices) return this
        val list = order.toMutableList()
        list.add(to, list.removeAt(from))
        return copy(order = list)
    }

    /** Switches an entry off or on. Settings can not be switched off. */
    fun withHidden(e: MenuEntry, hide: Boolean): MenuLayout =
        if (hide && !e.canHide) this else copy(hidden = if (hide) hidden + e else hidden - e)

    /** Puts a new group break at position [at] (the top by default, where it is easy to find and drag). Nothing happens once [MAX_GAPS] are in use. */
    fun addGap(at: Int = 0): MenuLayout {
        if (gaps.size >= MAX_GAPS) return this
        val used = gaps.map { it.id }.toSet()
        val id = (1..MAX_ID).first { it !in used }
        val list = order.toMutableList()
        list.add(at.coerceIn(0, list.size), MenuItem.Gap(id))
        return copy(order = list)
    }

    fun removeGap(id: Int): MenuLayout = copy(order = order.filterNot { it is MenuItem.Gap && it.id == id })

    /**
     * The cards the menu draws: the entries that are shown, split wherever there is a break. Empty cards (everything in them hidden, or breaks side by side,
     * or at either end) are left out. [available] lets the screen leave out an entry that makes no sense where the menu was opened (Customize home away from Home).
     */
    fun groups(available: (MenuEntry) -> Boolean = { true }): List<List<MenuEntry>> {
        val out = mutableListOf<List<MenuEntry>>()
        var current = mutableListOf<MenuEntry>()
        for (item in order) {
            when (item) {
                is MenuItem.Entry -> if (item.entry !in hidden && available(item.entry)) current.add(item.entry)
                is MenuItem.Gap -> { if (current.isNotEmpty()) out.add(current); current = mutableListOf() }
            }
        }
        if (current.isNotEmpty()) out.add(current)
        return out
    }

    fun encodeOrder(): String = order.joinToString(",") { it.key }
    fun encodeHidden(): String = encodeHidden(hidden)

    companion object {
        const val MAX_GAPS = 6
        private const val MAX_ID = 99

        /** The menu as it has always been: Home to Recently edited, then Rediscover to Search, then Bin to About, plus the new Customize menu. */
        val DEFAULT_ORDER: List<MenuItem> = buildList {
            MenuEntry.entries.forEach { e ->
                if (e == MenuEntry.Rediscover) add(MenuItem.Gap(1))
                if (e == MenuEntry.Bin) add(MenuItem.Gap(2))
                add(MenuItem.Entry(e))
            }
        }

        val Default = MenuLayout()

        /**
         * The saved order. Nothing saved (or nothing readable) gives the usual menu. Unknown names and repeats are dropped, breaks past the limit are dropped,
         * and any entry that is missing (one added by a newer version) goes at the end.
         */
        fun decodeOrder(s: String?): List<MenuItem> {
            if (s.isNullOrBlank()) return DEFAULT_ORDER
            val entries = LinkedHashSet<MenuEntry>()
            val gapIds = HashSet<Int>()
            val out = mutableListOf<MenuItem>()
            s.split(',').map { it.trim() }.forEach { t ->
                val gap = if (t.startsWith("-")) t.drop(1).toIntOrNull()?.takeIf { it in 1..MAX_ID } else null
                if (gap != null) { if (gapIds.size < MAX_GAPS && gapIds.add(gap)) out.add(MenuItem.Gap(gap)) }
                else MenuEntry.of(t)?.let { if (entries.add(it)) out.add(MenuItem.Entry(it)) }
            }
            if (entries.isEmpty()) return DEFAULT_ORDER
            MenuEntry.entries.forEach { if (entries.add(it)) out.add(MenuItem.Entry(it)) }
            return out
        }

        /** The saved set of hidden entries; unknown names are dropped, and so is Settings. */
        fun decodeHidden(s: String?): Set<MenuEntry> =
            s.orEmpty().split(',').mapNotNull { MenuEntry.of(it.trim()) }.filter { it.canHide }.toSet()

        /** Hidden entries in the default order, so the saved text does not depend on the order they were switched off in. */
        fun encodeHidden(set: Set<MenuEntry>): String = MenuEntry.entries.filter { it in set }.joinToString(",") { it.key }
    }
}

/** The name a group goes by (Browse, Discover, Manage) when everything in it comes from the same section; otherwise null, and the menu shows no name. */
fun groupTitle(group: List<MenuEntry>): String? = group.map { it.section }.distinct().singleOrNull()?.title

/** The small line under the menu in skins that have one. */
fun menuSummary(scraps: Int, boxes: Int): String {
    if (scraps == 0 && boxes == 0) return "Nothing saved yet · stays on this phone"
    val s = if (scraps == 1) "1 scrap" else "$scraps scraps"
    val b = if (boxes == 1) "1 box" else "$boxes boxes"
    return "$s · $b · all on this phone"
}
