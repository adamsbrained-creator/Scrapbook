package app.scrapbook

/**
 * The color (six hex digits) of the text at the start of a line when the person colored it with the text color tool, written {c:ff0000|text};
 * null for normal text. Bullets and checkboxes take this color, so a line colored red is red all through, marks included.
 * [text] is the line after its prefix (and layout tags).
 */
fun leadingTextColor(text: String): String? =
    SPAN_RE.find(text)?.takeIf { it.range.first == 0 }?.let { parseSpanAttrs(it.groupValues[1]).color }
