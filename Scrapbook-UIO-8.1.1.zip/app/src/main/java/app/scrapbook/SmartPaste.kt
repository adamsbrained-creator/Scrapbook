package app.scrapbook

// Smart paste: after something is pasted into a scrap, recognize what it is and OFFER a tidier form. Nothing is ever changed by itself; the offer
// is a small button that goes away, and accepting it is an undoable step. The rules live here, on plain strings, so they can be tested.

enum class PasteOffer(val what: String, val action: String) {
    Link("Link pasted", "Make it a link"),
    Quote("Quote pasted", "Format as a quote"),
    Bullets("List pasted", "Make it a list"),
    Checklist("Checklist pasted", "Make it a checklist"),
    JoinLines("Broken lines pasted", "Join the lines"),
}

/** What an offer would produce: the whole new text and where the changed piece sits in it. */
data class PasteResult(val text: String, val range: IntRange)

private val URL_ONLY = Regex("^https?://\\S+$")
private val NUM_LINE = Regex("^\\d+[.)] ")
private const val MIN_PASTE = 10
private const val BULLETS = "\u2022\u25E6\u25AA\u25CF\u2023\u2219\u00B7\u25CB"
private const val BOXES_OPEN = "\u2610\u25A1"
private const val BOXES_DONE = "\u2611\u2612\u2713\u2714"
private const val OPEN_QUOTES = "\"\u201C\u00AB\u201E\u300C"
private const val CLOSE_QUOTES = "\"\u201D\u00BB\u201C\u300D"
private const val SENTENCE_ENDS = ".!?:;\"\u201D)]\u00BB"
private val ATTRIBUTION_SAME_LINE = Regex("^(.*[\"\u201D\u00BB\u201C\u300D])\\s*[\u2014\u2015\u2013]\\s*\\S.{0,60}$")

/**
 * The text one edit inserted, as a range in the new text, or null when the change was anything else (a deletion, an edit somewhere else, several
 * edits at once). The old selection a..b is what the insertion replaced, so pasting over a selection works too.
 */
fun insertedRange(oldText: String, oldStart: Int, oldEnd: Int, newText: String, newCursor: Int): IntRange? {
    val a = minOf(oldStart, oldEnd).coerceIn(0, oldText.length); val b = maxOf(oldStart, oldEnd).coerceIn(0, oldText.length)
    val ins = newText.length - (oldText.length - (b - a))
    if (ins <= 0 || newCursor != a + ins) return null
    if (!newText.startsWith(oldText.substring(0, a)) || !newText.endsWith(oldText.substring(b))) return null
    return a until a + ins
}

private fun isBulletLine(l: String) = (l.length > 1 && BULLETS.indexOf(l[0]) >= 0) || l.startsWith("* ")

/** Whether [core] reads as a copied quote: wrapped in quotation marks, perhaps followed by an attribution ("— Name"), and not already formatted. */
fun looksLikeQuote(core: String): Boolean {
    var lines = core.lines().map { it.trim() }.filter { it.isNotEmpty() }
    if (lines.isEmpty() || lines.all { it.startsWith(">") }) return false
    val attrib = lines.indexOfFirst { l -> l.startsWith("\u2014") || l.startsWith("\u2015") || l.startsWith("\u2013 ") || l.startsWith("-- ") || l.startsWith("~") }
    if (attrib > 0) lines = lines.subList(0, attrib)
    ATTRIBUTION_SAME_LINE.find(lines.last())?.let { lines = lines.dropLast(1) + it.groupValues[1] }
    val main = lines.joinToString(" ")
    return main.length >= 20 && OPEN_QUOTES.indexOf(main.first()) >= 0 && CLOSE_QUOTES.indexOf(main.last()) >= 0 && main.any { it.isLetter() }
}

/**
 * What to offer for the text that was just inserted at [range] in [text], or null for nothing (most pastes). [hadSelection] is true when the paste
 * replaced selected text: a web address over a selection already becomes a link by itself, so no offer is made for it.
 */
fun offerFor(text: String, range: IntRange, hadSelection: Boolean): PasteOffer? {
    if (range.first < 0 || range.last >= text.length) return null
    val core = text.substring(range.first, range.last + 1).trim()
    if (core.length < MIN_PASTE) return null
    val before = text.substring(0, range.first)
    if (!hadSelection && URL_ONLY.matches(core) && !before.endsWith("](") && !before.endsWith("[") && !before.endsWith("(")) return PasteOffer.Link
    if (looksLikeQuote(core)) return PasteOffer.Quote
    val lines = core.lines().filter { it.isNotBlank() }.map { it.trimStart() }
    if (lines.size >= 2) {
        val boxes = lines.count { BOXES_OPEN.indexOf(it[0]) >= 0 || BOXES_DONE.indexOf(it[0]) >= 0 }
        if (boxes >= 2 && boxes * 10 >= lines.size * 6) return PasteOffer.Checklist
        val bullets = lines.count { isBulletLine(it) }
        if (bullets >= 2 && bullets * 10 >= lines.size * 6) return PasteOffer.Bullets
    }
    // Text copied from a PDF or a narrow page is broken into lines in the middle of sentences: no blank lines, no list or heading marks, long lines
    // that mostly do not end a sentence.
    val raw = core.lines().map { it.trim() }
    if (raw.size >= 3 && raw.none { it.isEmpty() } && raw.none { isBulletLine(it) || NUM_LINE.containsMatchIn(it) || it.startsWith("#") || it.startsWith(">") || it.startsWith("- ") }) {
        val open = raw.dropLast(1).count { SENTENCE_ENDS.indexOf(it.last()) < 0 }
        if (raw.sumOf { it.length } / raw.size >= 35 && raw.maxOf { it.length } <= 130 && open * 10 >= (raw.size - 1) * 7) return PasteOffer.JoinLines
    }
    return null
}

/** The host of a web address without "www.", used as a link's label until its page title is known. */
fun hostLabel(url: String): String = runCatching { java.net.URI(url.trim()).host }.getOrNull()?.removePrefix("www.")?.takeIf { it.isNotBlank() } ?: url.trim().take(30)

/** A markdown link. The label loses brackets and line breaks, and a ")" in the address is written %29 so it can not end the link early. */
fun linkMarkdown(url: String, label: String): String {
    val clean = label.replace(Regex("\\s*[\\[\\]\\r\\n]+\\s*"), " ").trim().take(100).ifEmpty { hostLabel(url) }
    return "[$clean](${url.trim().replace(")", "%29")})"
}

/** The text with [offer] applied to the pasted piece at [range] (never to anything else); [label] is the link label for a Link offer. */
fun applyPasteOffer(text: String, range: IntRange, offer: PasteOffer, label: String? = null): PasteResult {
    val p = text.substring(range.first, range.last + 1)
    val core = p.trim(); val start = p.indexOf(core)
    val lead = p.substring(0, start); val trail = p.substring(start + core.length)
    val newCore = when (offer) {
        PasteOffer.Link -> linkMarkdown(core, label ?: hostLabel(core))
        PasteOffer.Quote -> core.lines().joinToString("\n") { if (it.isBlank()) "" else "> " + it.trim() }
        PasteOffer.Bullets -> core.lines().joinToString("\n") { l ->
            val t = l.trimStart()
            if (isBulletLine(t)) "- " + (if (t.startsWith("* ")) t.drop(2) else t.drop(1)).trimStart() else l
        }
        PasteOffer.Checklist -> core.lines().joinToString("\n") { l ->
            val t = l.trimStart()
            when {
                t.isNotEmpty() && BOXES_OPEN.indexOf(t[0]) >= 0 -> "- [ ] " + t.drop(1).trimStart()
                t.isNotEmpty() && BOXES_DONE.indexOf(t[0]) >= 0 -> "- [x] " + t.drop(1).trimStart()
                else -> l
            }
        }
        PasteOffer.JoinLines -> core.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" ")
    }
    // Quotes and lists are lines of their own, so they start on a new line (and what follows does too).
    return place(text, range, newCore, offer == PasteOffer.Quote || offer == PasteOffer.Bullets || offer == PasteOffer.Checklist)
}

/** Puts [newCore] where the pasted piece at [range] was, keeping the whitespace around it; a [block] gets a line of its own. */
private fun place(text: String, range: IntRange, newCore: String, block: Boolean): PasteResult {
    val p = text.substring(range.first, range.last + 1)
    val core = p.trim(); val start = p.indexOf(core)
    val lead = p.substring(0, start); val trail = p.substring(start + core.length)
    val needBefore = block && range.first > 0 && text[range.first - 1] != '\n' && !lead.endsWith("\n")
    val needAfter = block && range.last + 1 < text.length && text[range.last + 1] != '\n' && !trail.endsWith("\n")
    val piece = (if (needBefore) "\n" else "") + lead + newCore + trail + (if (needAfter) "\n" else "")
    return PasteResult(text.substring(0, range.first) + piece + text.substring(range.last + 1), range.first until range.first + piece.length)
}

/** Replaces the pasted address at [range] with a link card (see linkCardText), on lines of its own. */
fun applyLinkCard(text: String, range: IntRange, card: String): PasteResult = place(text, range, card, true)
