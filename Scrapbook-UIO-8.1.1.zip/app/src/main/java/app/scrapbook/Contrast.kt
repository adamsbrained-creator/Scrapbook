package app.scrapbook

import kotlin.math.pow
import kotlin.math.roundToInt

// Readable colors. The accent is user-chosen (or custom), so text drawn in it, or on a button filled with it, can be too faint to read: Teal on white is 1.7 to 1 where
// 4.5 to 1 is the usual minimum for small text. These rules find a color that is readable, changing the accent as little as possible. Colors here are plain 0xRRGGBB numbers.

/** The near-black used for text and icons on a light color (it is the same as the app's ink in light mode). */
const val DARK_INK = 0x1C1C1C

/** How bright a color looks to the eye, from 0 (black) to 1 (white); the WCAG "relative luminance". */
fun luminance(rgb: Int): Double {
    fun ch(v: Int): Double { val c = v / 255.0; return if (c <= 0.03928) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4) }
    return 0.2126 * ch((rgb shr 16) and 255) + 0.7152 * ch((rgb shr 8) and 255) + 0.0722 * ch(rgb and 255)
}

/** How well two colors stand apart, from 1 (the same) to 21 (black on white). 4.5 is the usual minimum for small text, 3 for large text and icons. */
fun contrastRatio(a: Int, b: Int): Double {
    val la = luminance(a); val lb = luminance(b)
    return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
}

/** The color for text or an icon sitting on [background]: white or near-black, whichever reads better. A light fill like Teal gets dark text; a dark one gets white. */
fun onColor(background: Int): Int = if (contrastRatio(0xFFFFFF, background) >= contrastRatio(DARK_INK, background)) 0xFFFFFF else DARK_INK

private fun mix(a: Int, b: Int, t: Double): Int {
    fun ch(sh: Int): Int = (((a shr sh) and 255) * (1 - t) + ((b shr sh) and 255) * t).roundToInt().coerceIn(0, 255)
    return (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}

/**
 * [color] as text on [background]: unchanged when it already has a contrast of at least [min], otherwise mixed toward black (or white on a dark background) by the
 * smallest amount that gets there, so it is still the same color, only deeper (or lighter).
 */
fun readableOn(color: Int, background: Int, min: Double = 4.5): Int {
    if (contrastRatio(color, background) >= min) return color
    val target = if (contrastRatio(0x000000, background) >= contrastRatio(0xFFFFFF, background)) 0x000000 else 0xFFFFFF
    var lo = 0.0; var hi = 1.0   // the share of the target that is mixed in
    repeat(14) { val mid = (lo + hi) / 2; if (contrastRatio(mix(color, target, mid), background) >= min) hi = mid else lo = mid }
    return mix(color, target, hi)
}
