package app.scrapbook

import android.content.Context

/**
 * Where you were in a scrap the last time you left it: the cursor (an offset in the saved text), how far the page was scrolled (in pixels),
 * and whether the keyboard was open, so that reopening a scrap you were typing in puts you back to typing.
 * This is view state, not content: it is kept on the phone next to the settings, never inside the scrap, so backups and versions are unaffected.
 */
data class EditorSpot(val cursor: Int, val scroll: Int, val keyboard: Boolean)

/**
 * The spots of the most recently opened scraps, as one short piece of text ("id:cursor:scroll:k;id:cursor:scroll:k;...", oldest first).
 * It keeps at most [MAX] scraps, so it can never grow without limit, and whatever it cannot read is skipped rather than failing.
 */
object EditorSpots {
    const val MAX = 300

    fun decode(text: String?): LinkedHashMap<Long, EditorSpot> {
        val map = LinkedHashMap<Long, EditorSpot>()
        for (part in text.orEmpty().split(';')) {
            val f = part.split(':')
            if (f.size != 4) continue
            val id = f[0].toLongOrNull() ?: continue
            val cursor = f[1].toIntOrNull() ?: continue
            val scroll = f[2].toIntOrNull() ?: continue
            map[id] = EditorSpot(cursor.coerceAtLeast(0), scroll.coerceAtLeast(0), f[3] == "1")
        }
        return map
    }

    fun encode(map: Map<Long, EditorSpot>): String =
        map.entries.joinToString(";") { e -> "${e.key}:${e.value.cursor}:${e.value.scroll}:${if (e.value.keyboard) 1 else 0}" }

    /** Sets the spot for [id] and makes it the newest. The oldest ones fall off past [MAX]. */
    fun put(map: LinkedHashMap<Long, EditorSpot>, id: Long, spot: EditorSpot) {
        map.remove(id)
        map[id] = spot
        while (map.size > MAX) map.remove(map.keys.first())
    }

    /** Forgets the spots of scraps that no longer exist. Returns true when something was dropped. */
    fun prune(map: LinkedHashMap<Long, EditorSpot>, alive: Set<Long>): Boolean = map.keys.retainAll(alive)

    /** The cursor to start with in a text of [length] characters: where it was, kept inside the text in case the text got shorter since. */
    fun cursorFor(spot: EditorSpot?, length: Int): Int = (spot?.cursor ?: 0).coerceIn(0, length)
}

/**
 * The scraps you set to "view only": they open as a plain page and stay that way, whatever the box says, until you unlock them.
 * Kept as a set of ids (as text) next to the spots. It is a choice you made, so unlike spots it is never trimmed to a limit, only cleaned of scraps that are gone.
 */
object LockedScraps {
    fun with(set: Set<String>, id: Long, locked: Boolean): Set<String> = if (locked) set + id.toString() else set - id.toString()
    fun has(set: Set<String>, id: Long): Boolean = id.toString() in set
    fun prune(set: Set<String>, alive: Set<Long>): Set<String> = set.filterTo(HashSet()) { it.toLongOrNull() in alive }
}

/** The phone-side store for [EditorSpots]. Reads are instant (the editor needs the answer before its first frame); writes finish in the background. */
class EditorMemory(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("editor_spots", Context.MODE_PRIVATE)

    fun get(id: Long): EditorSpot? = EditorSpots.decode(prefs.getString("spots", null))[id]

    fun put(id: Long, spot: EditorSpot) {
        val map = EditorSpots.decode(prefs.getString("spots", null))
        EditorSpots.put(map, id, spot)
        prefs.edit().putString("spots", EditorSpots.encode(map)).apply()
    }

    private fun lockedSet(): Set<String> = prefs.getStringSet("locked", emptySet()).orEmpty()

    /** Whether this scrap was set to view only. */
    fun isLocked(id: Long): Boolean = LockedScraps.has(lockedSet(), id)

    fun setLocked(id: Long, locked: Boolean) {
        // Android asks for a new set every time (the one it hands out must not be changed in place).
        prefs.edit().putStringSet("locked", LockedScraps.with(lockedSet(), id, locked)).apply()
    }

    /** Called once when the app starts: drops the spots and locks of scraps that are gone for good. */
    fun prune(alive: Set<Long>) {
        val map = EditorSpots.decode(prefs.getString("spots", null))
        val edit = prefs.edit()
        if (EditorSpots.prune(map, alive)) edit.putString("spots", EditorSpots.encode(map))
        val locks = lockedSet(); val kept = LockedScraps.prune(locks, alive)
        if (kept.size != locks.size) edit.putStringSet("locked", kept)
        edit.apply()
    }
}
