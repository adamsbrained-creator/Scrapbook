package app.scrapbook

// The plain rules for tags, kept apart from the screens so they can be tested. A tag is just a word on a scrap; the same tag can be on scraps
// in any boxes, which is what lets one tag cut across folders.

/** One tag as typed, tidied: spaces trimmed and a leading # dropped. "" when nothing is left. */
fun tidyTag(t: String): String = t.trim().trimStart('#').trim()

/** Whether the scrap carries [tag], ignoring case ("Lyrics" and "lyrics" are the same tag). */
fun Item.hasTag(tag: String): Boolean = tags.any { it.equals(tag, ignoreCase = true) }

/**
 * Every tag used across [items] with the number of scraps that have it, most used first (ties by name). Case is ignored when counting; the spelling shown
 * is the one most scraps use. A tag twice on one scrap counts once.
 */
fun tagCounts(items: List<Item>): List<Pair<String, Int>> {
    val total = LinkedHashMap<String, Int>()
    val spellings = HashMap<String, LinkedHashMap<String, Int>>()
    items.forEach { i ->
        i.tags.map(::tidyTag).filter { it.isNotEmpty() }.distinctBy { it.lowercase() }.forEach { t ->
            val k = t.lowercase()
            total[k] = (total[k] ?: 0) + 1
            val sp = spellings.getOrPut(k) { LinkedHashMap() }
            sp[t] = (sp[t] ?: 0) + 1
        }
    }
    return total.map { (k, c) -> spellings.getValue(k).maxByOrNull { it.value }!!.key to c }
        .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first.lowercase() })
}

/**
 * The tags to keep on a scrap: tidied, without empty ones and without repeats (ignoring case; the first one stays). A tag that is already in use
 * somewhere ([known]) takes that spelling, so "lyrics" typed on one scrap never splits away from "Lyrics" on the others.
 */
fun cleanTags(raw: List<String>, known: List<String> = emptyList()): List<String> {
    val spelling = HashMap<String, String>().also { m -> known.forEach { m.putIfAbsent(it.lowercase(), it) } }
    val seen = HashSet<String>(); val out = ArrayList<String>()
    for (r in raw) {
        val t = tidyTag(r); if (t.isEmpty()) continue
        val k = t.lowercase(); if (!seen.add(k)) continue
        out += spelling[k] ?: t
    }
    return out
}

/** The small line on a card: the first three tags as "#tag", and how many more there are. "" for no tags. */
fun tagLine(tags: List<String>): String =
    tags.take(3).joinToString("  ") { "#$it" } + if (tags.size > 3) "  +${tags.size - 3}" else ""
