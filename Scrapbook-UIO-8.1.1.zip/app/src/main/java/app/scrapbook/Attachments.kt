package app.scrapbook

import android.net.Uri
import java.io.File

/** The biggest file that can be attached. Bigger ones are refused, so one huge file cannot fill the phone or make backups impossible. */
const val MAX_ATTACHMENT_BYTES = 100L * 1024 * 1024

/**
 * A file attached to a scrap. The file itself is a copy kept in the app's own storage (so it survives after the picker's access ends);
 * [path] is that copy as a file:// address, [name] is what the file was called, [mime] what kind of file it is.
 */
data class Attachment(val path: String, val name: String, val size: Long, val mime: String)

/** Item.files holds one attachment per line, with its four parts separated by a tab. Names never contain tabs or line breaks (see [cleanDisplayName]). */
fun Attachment.encode(): String = listOf(path, name, size.toString(), mime).joinToString("\t")

fun parseAttachment(line: String): Attachment? {
    val p = line.split("\t")
    if (p.size < 4 || p[0].isBlank()) return null
    return Attachment(p[0], p[1], p[2].toLongOrNull() ?: 0L, p[3])
}

fun String.toAttachments(): List<Attachment> = lines().mapNotNull { parseAttachment(it) }

fun List<Attachment>.encodeAll(): String = joinToString("\n") { it.encode() }

fun Item.attachments(): List<Attachment> = files.toAttachments()

/** The stored copy, as a File. */
fun Attachment.file(): File = File(Uri.parse(path).path ?: "")

val Attachment.isPdf: Boolean get() = mime == "application/pdf" || name.endsWith(".pdf", ignoreCase = true)

val Attachment.isImage: Boolean get() = mime.startsWith("image/")

/** Voice recordings and any other sound file: these play inside the app instead of opening another one. */
val Attachment.isAudio: Boolean get() = mime.startsWith("audio/")

/** A short label for the file type: its extension in capitals ("ZIP", "DOCX"), or "FILE" when there is none. */
val Attachment.typeLabel: String
    get() = name.substringAfterLast('.', "").filter { it.isLetterOrDigit() }.take(4).uppercase().ifEmpty { "FILE" }

/** The name as shown: no line breaks, tabs or slashes (they would break how attachments are stored), and not endless. */
fun cleanDisplayName(raw: String?): String {
    val s = (raw ?: "").map { if (it.isISOControl() || it == '/' || it == '\\') ' ' else it }.joinToString("").replace(Regex("\\s+"), " ").trim()
    return s.take(120).ifEmpty { "File" }
}

/** A name that is safe to use on disk: letters, digits, dot, dash, underscore and space only, with the extension kept. */
fun diskName(display: String): String {
    val ext = display.substringAfterLast('.', "").filter { it.isLetterOrDigit() }.take(10)
    val base = display.substringBeforeLast('.', display).map { if (it.isLetterOrDigit() || it == ' ' || it == '-' || it == '_') it else '_' }
        .joinToString("").trim().take(60).ifEmpty { "file" }
    return if (ext.isEmpty()) base else "$base.$ext"
}

/** 1 B, 12 KB, 1.4 MB. */
fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    bytes < 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    else -> String.format(java.util.Locale.US, "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0))
}

/** A title for a scrap made only from a shared file: its name without the extension. */
fun titleFromFileName(name: String): String = name.substringBeforeLast('.', name).trim().ifEmpty { name }

private val ENDING_RE = Regex("\\.[A-Za-z0-9]{1,5}$")

/** True when [name] ends the way a file name does: a dot, then 1 to 5 letters or digits with at least one letter (".pdf" or ".mp3", but not the ".2" in "v1.2"). */
private fun hasEnding(name: String): Boolean = ENDING_RE.find(name)?.value?.any { it.isLetter() } == true

/**
 * The name to use after renaming a file from [old] to what was [typed]: tidied like any file name, and given the old ending back (".pdf", ".zip"...) when what was
 * typed has none, so "Electric bill" for "scan.pdf" becomes "Electric bill.pdf". Typing an ending of your own keeps it. Null when nothing was typed.
 */
fun renamedFileName(old: String, typed: String): String? {
    if (typed.isBlank()) return null
    val name = cleanDisplayName(typed)
    val ending = if (hasEnding(old)) ENDING_RE.find(old)?.value.orEmpty() else ""
    if (ending.isEmpty() || hasEnding(name)) return name
    return name.take(120 - ending.length).trimEnd('.', ' ') + ending
}

/** The same list with the file at [path] called [name]. Its place and its stored copy do not change, only what it is called. */
fun List<Attachment>.withName(path: String, name: String): List<Attachment> = map { if (it.path == path) it.copy(name = name) else it }
