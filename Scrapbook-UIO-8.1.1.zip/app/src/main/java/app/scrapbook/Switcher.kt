package app.scrapbook

import java.text.Normalizer

/** One place the quick switcher can jump to: a scrap or a box. [hint] is the small second line (its box, tags); it is searched too. */
data class Place(val key: String, val title: String, val hint: String, val savedAt: Long = 0L, val icon: String = "", val kind: String = "") {
    val isBox: Boolean get() = Recents.isBox(key)
}

/**
 * The rules of the quick switcher. With nothing typed it offers the places you opened last. Typing narrows to places where every word matches
 * (a title starting with it ranks first, then a word inside the title, then the second line), ties going to what you opened most recently.
 */
object Switcher {
    private fun plain(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "").lowercase()

    private fun words(s: String) = plain(s).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }

    /** How well one typed word fits the place; 0 = not at all. */
    private fun scoreWord(term: String, p: Place, titleW: List<String>, hintW: List<String>, title: String, hint: String): Int = when {
        title == term -> 100
        title.startsWith(term) -> 70
        titleW.any { it.startsWith(term) } -> 50
        title.contains(term) -> 28
        hintW.any { it.startsWith(term) } -> 16
        hint.contains(term) -> 8
        else -> 0
    }

    fun find(query: String, all: List<Place>, recents: List<String>, limit: Int = 12): List<Place> {
        val terms = words(query)
        val rank = recents.withIndex().associate { it.value to it.index }
        if (terms.isEmpty()) {
            val byKey = all.associateBy { it.key }
            val seen = recents.mapNotNull { byKey[it] }.take(limit)
            // Nothing opened yet: the newest scraps are the likeliest.
            return if (seen.isNotEmpty()) seen else all.filter { !it.isBox }.sortedByDescending { it.savedAt }.take(limit.coerceAtMost(6))
        }
        return all.mapNotNull { p ->
            val title = plain(p.title); val hint = plain(p.hint); val tw = words(p.title); val hw = words(p.hint)
            var total = 0
            for (t in terms) { val s = scoreWord(t, p, tw, hw, title, hint); if (s == 0) return@mapNotNull null; total += s }
            Triple(p, total, rank[p.key] ?: Int.MAX_VALUE)
        }.sortedWith(compareByDescending<Triple<Place, Int, Int>> { it.second }.thenBy { it.third }.thenByDescending { it.first.savedAt })
            .take(limit).map { it.first }
    }
}
