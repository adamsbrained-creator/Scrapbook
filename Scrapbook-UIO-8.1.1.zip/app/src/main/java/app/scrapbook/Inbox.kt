package app.scrapbook

/** The built-in box that quick captures land in. */
const val INBOX_BOX = "Inbox"

/**
 * Scraps waiting to be sorted: in Inbox, not in the Bin and not pinned (pinning is a decision: "keep this close").
 * Oldest first, so the backlog clears from the back and nothing sits there for ever.
 */
fun List<Item>.toSort(): List<Item> =
    filter { it.collection == INBOX_BOX && !it.pinned && it.deletedAt == 0L }.sortedBy { it.createdAt }

/** Whole days the oldest waiting scrap has been there. 0 when nothing waits or it was made today. */
fun oldestWaitingDays(items: List<Item>, now: Long): Int =
    items.toSort().firstOrNull()?.let { ((now - it.createdAt) / 86_400_000L).toInt().coerceAtLeast(0) } ?: 0

/**
 * A scrap that arrives in Inbox while Inbox is hidden would be invisible (the box cannot be opened), so Inbox comes back.
 * Only an arrival counts: a new scrap (before = null) or one moved in from another box. Editing a scrap that was already
 * in Inbox does not bring it back, so "Remove Inbox, keep scraps" stays removed.
 */
fun revealsInbox(hidden: Boolean, before: String?, after: String): Boolean =
    hidden && after == INBOX_BOX && before != INBOX_BOX
