package app.scrapbook

/**
 * The places you opened most recently, newest first: a scrap is "i<id>", a box is "b<name>". Kept as one short piece of text so it can live in the phone's
 * small settings storage (see RecentStore). Nothing here touches Android, so the rules are tested on their own.
 */
object Recents {
    const val MAX = 24
    private const val SEP = '\u001F'

    fun scrap(id: Long) = "i$id"
    fun box(name: String) = "b$name"
    fun isBox(key: String) = key.startsWith("b")
    fun scrapId(key: String): Long? = if (key.startsWith("i")) key.drop(1).toLongOrNull() else null
    fun boxName(key: String): String? = if (isBox(key)) key.drop(1) else null

    /** [key] moves to the front (or is added there); the list never grows past [MAX]. Opening what is already first changes nothing. */
    fun touch(list: List<String>, key: String): List<String> {
        if (key.length < 2 || list.firstOrNull() == key) return list
        return (listOf(key) + list.filter { it != key }).take(MAX)
    }

    fun encode(list: List<String>): String = list.filter { it.length >= 2 }.joinToString(SEP.toString())
    fun decode(s: String?): List<String> = s.orEmpty().split(SEP).filter { it.length >= 2 }.distinct().take(MAX)

    /** Drops places that no longer exist (scraps gone for good, boxes deleted). */
    fun prune(list: List<String>, aliveScraps: Set<Long>, aliveBoxes: Set<String>): List<String> =
        list.filter { k -> scrapId(k)?.let { it in aliveScraps } ?: boxName(k)?.let { it in aliveBoxes } ?: false }
}
