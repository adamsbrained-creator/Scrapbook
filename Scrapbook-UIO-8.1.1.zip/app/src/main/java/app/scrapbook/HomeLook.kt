package app.scrapbook

/**
 * The look that every part and section of Home shares, chosen on the Look page of Customize home (and kept by the skin you wear): how round the corners are, what a card
 * is made of, and how much space is between the parts. Every choice is optional: [default] is how Home looked before there was a choice. [key] is what is saved, so never
 * rename one, and only ever add options at the end.
 */
enum class HomeLookKey(val key: String, val label: String, val options: List<String>, val hints: List<String>, val default: Int) {
    Corners("corners", "Corners", listOf("Sharp", "Soft", "Round"),
        listOf("Almost square corners.", "The usual soft corners.", "Very round corners: pills and bubbles."), default = 1),
    Cards("card", "Cards", listOf("Filled", "Outlined", "Tinted", "Flat"),
        listOf("A filled card, like the rest of the app.", "Only a thin line around each part.", "A card with a soft wash of your accent color.", "No card at all: the content sits straight on the page."), default = 0),
    Spacing("spacing", "Space between parts", listOf("Tight", "Regular", "Roomy"),
        listOf("Parts close together: more fits on the screen.", "The usual space.", "Parts far apart: a calmer page."), default = 1);

    companion object {
        fun of(key: String): HomeLookKey? = entries.firstOrNull { it.key == key }
    }
}

/** The look chosen for Home. Only choices that differ from the default are kept, so an empty one is the classic look (rules tested in HomeLookTest). */
data class HomeLook(val values: Map<HomeLookKey, Int> = emptyMap()) {
    operator fun get(k: HomeLookKey): Int = (values[k] ?: k.default).coerceIn(0, k.options.lastIndex)

    fun with(k: HomeLookKey, index: Int): HomeLook {
        val i = index.coerceIn(0, k.options.lastIndex)
        return copy(values = if (i == k.default) values - k else values + (k to i))
    }

    val isDefault: Boolean get() = values.isEmpty()

    /** How much every corner radius is multiplied by. */
    val cornerScale: Float get() = CORNER_SCALES[this[HomeLookKey.Corners]]

    /** What a card is made of: 0 filled, 1 outlined, 2 tinted, 3 flat. */
    val card: Int get() = this[HomeLookKey.Cards]

    /** The space between the parts of the page, in dp. */
    val gap: Int get() = GAPS[this[HomeLookKey.Spacing]]

    /** A corner radius of [base] dp as this look has it. */
    fun radius(base: Float): Float = base * cornerScale

    /** What differs from the classic look, in a few words, or an empty text. */
    fun summary(): String = HomeLookKey.entries.filter { it in values }.joinToString(" · ") { it.options[get(it)] }

    /** Saved as `key=index` pairs; the classic look is an empty text. */
    fun encode(): String = HomeLookKey.entries.filter { it in values }.joinToString(",") { "${it.key}=${get(it)}" }

    companion object {
        val Default = HomeLook()
        private val CORNER_SCALES = listOf(.35f, 1f, 1.7f)
        private val GAPS = listOf(10, 18, 28)

        /** Reads what [encode] wrote. Unknown names, unreadable numbers and choices equal to the default are dropped; numbers out of range are brought back in. */
        fun decode(s: String?): HomeLook {
            var out = Default
            s.orEmpty().split(',').forEach { pair ->
                val k = HomeLookKey.of(pair.substringBefore('=', "").trim()) ?: return@forEach
                val v = pair.substringAfter('=', "").trim().toIntOrNull() ?: return@forEach
                out = out.with(k, v)
            }
            return out
        }
    }
}
