package app.scrapbook

import java.util.Calendar
import java.util.TimeZone

// The personal timeline: scraps laid out by the day they were made (or last edited), newest first, grouped by month.
// This file is only the rules; the screen is ui/TimelineScreen.kt.

/** Which date a scrap sits at on the timeline. */
enum class TimelineField(val label: String) { Created("Created"), Edited("Edited") }

fun Item.timelineAt(field: TimelineField): Long = if (field == TimelineField.Created) createdAt else savedAt

/** One day of a month: its number, its weekday (a Calendar.DAY_OF_WEEK value) and its scraps, the latest first. */
class TimelineDay(val day: Int, val dow: Int, val items: List<Item>)

/** One month of the timeline. [month] counts from 0, like Calendar.MONTH. */
class TimelineMonth(val year: Int, val month: Int, val days: List<TimelineDay>) {
    val count: Int get() = days.sumOf { it.items.size }
}

/** The scraps grouped into months and days, the newest month, day and scrap first. Every scrap appears once, at the date [field] says. */
fun timelineOf(items: List<Item>, field: TimelineField, zone: TimeZone = TimeZone.getDefault()): List<TimelineMonth> {
    class DayB(val day: Int, val dow: Int) { val items = ArrayList<Item>() }
    class MonthB(val year: Int, val month: Int) { val days = ArrayList<DayB>() }
    val cal = Calendar.getInstance(zone); val out = ArrayList<MonthB>()
    for (n in items.sortedByDescending { it.timelineAt(field) }) {
        cal.timeInMillis = n.timelineAt(field)
        val y = cal.get(Calendar.YEAR); val m = cal.get(Calendar.MONTH); val d = cal.get(Calendar.DAY_OF_MONTH)
        var mb = out.lastOrNull()
        if (mb == null || mb.year != y || mb.month != m) { mb = MonthB(y, m); out += mb }
        var db = mb.days.lastOrNull()
        if (db == null || db.day != d) { db = DayB(d, cal.get(Calendar.DAY_OF_WEEK)); mb.days += db }
        db.items += n
    }
    return out.map { mb -> TimelineMonth(mb.year, mb.month, mb.days.map { TimelineDay(it.day, it.dow, it.items) }) }
}

/** One line of the timeline list: a month heading, or a scrap. [day] is set on the first scrap of each day, which is where the day's number is shown. */
sealed class TimelineRow {
    class Month(val month: TimelineMonth) : TimelineRow()
    class Entry(val item: Item, val day: TimelineDay?) : TimelineRow()
}

fun timelineRows(months: List<TimelineMonth>): List<TimelineRow> {
    val rows = ArrayList<TimelineRow>()
    for (m in months) {
        rows += TimelineRow.Month(m)
        for (d in m.days) d.items.forEachIndexed { i, n -> rows += TimelineRow.Entry(n, if (i == 0) d else null) }
    }
    return rows
}

/** The position of a month's heading in the rows, or -1. */
fun List<TimelineRow>.indexOfMonth(year: Int, month: Int): Int =
    indexOfFirst { it is TimelineRow.Month && it.month.year == year && it.month.month == month }

/** The box that holds at least half of a busy month (4 or more scraps), or null. Used for the "mostly Ideas" note on a month heading. */
fun TimelineMonth.mostlyBox(): String? {
    if (count < 4) return null
    val top = days.flatMap { it.items }.groupingBy { it.collection.ifBlank { "Inbox" } }.eachCount().maxByOrNull { it.value } ?: return null
    return if (top.value * 2 >= count) top.key else null
}

/** Scraps made on today's date in an earlier year, the most recent year first. */
fun onThisDay(items: List<Item>, now: Long, zone: TimeZone = TimeZone.getDefault()): List<Item> {
    val cal = Calendar.getInstance(zone); cal.timeInMillis = now
    val y = cal.get(Calendar.YEAR); val m = cal.get(Calendar.MONTH); val d = cal.get(Calendar.DAY_OF_MONTH)
    return items.filter {
        cal.timeInMillis = it.createdAt
        cal.get(Calendar.YEAR) < y && cal.get(Calendar.MONTH) == m && cal.get(Calendar.DAY_OF_MONTH) == d
    }.sortedByDescending { it.createdAt }
}
