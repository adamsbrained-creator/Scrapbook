package app.scrapbook

import java.util.UUID

// Links to scraps: scrapbook://scrap/<uid>. The uid is a permanent id every scrap carries (Item.uid), unlike the database id, which a backup restore
// or a reinstall changes. A link made today therefore still opens the same scrap after either.

/** A new permanent id for a scrap: 32 lowercase hex characters. */
fun newUid(): String = UUID.randomUUID().toString().replace("-", "")

/** The link that opens the scrap with this [uid]. */
fun scrapLink(uid: String) = "scrapbook://scrap/$uid"

private val SCRAP_LINK = Regex("scrapbook://scrap/([A-Za-z0-9-]{8,64})/?", RegexOption.IGNORE_CASE)

/** The scrap id (lowercase) inside a scrapbook://scrap/<id> link, or null for anything else. Surrounding spaces and a trailing slash are fine. */
fun parseScrapLink(url: String?): String? {
    val text = url?.trim() ?: return null
    return SCRAP_LINK.matchEntire(text)?.groupValues?.get(1)?.lowercase()
}
