package app.scrapbook

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// The plain rules behind the privacy controls: the PIN, how long to wait after wrong tries, when to lock again, and which scraps a hidden box hides.
// One PIN does everything: the app lock, fingerprint unlock (which falls back to it) and revealing hidden boxes. It is never stored, only a salted hash of it.

const val PIN_MIN = 4
const val PIN_MAX = 8

/** How long you can be away before the app (and hidden boxes) lock again, in the order of [LOCK_DELAY_LABELS]. */
val LOCK_DELAYS_MS = listOf(0L, 30_000L, 60_000L, 300_000L)
val LOCK_DELAY_LABELS = listOf("Immediately", "30 seconds", "1 minute", "5 minutes")
const val LOCK_DELAY_DEFAULT = 2

private const val PIN_ITERATIONS = 60_000

/** A PIN is 4 to 8 digits. */
fun validPin(pin: String) = pin.length in PIN_MIN..PIN_MAX && pin.all { it in '0'..'9' }

private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
private fun derive(pin: String, salt: ByteArray, iterations: Int): ByteArray =
    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pin.toCharArray(), salt, iterations, 256)).encoded

/**
 * What is saved instead of the PIN: "length:iterations:salt:hash". The hash is PBKDF2 (a deliberately slow one-way function) of the PIN with a random
 * salt, so the PIN cannot be read back and two phones with the same PIN save different text. The length is kept so the lock screen can unlock by itself
 * the moment that many digits are typed.
 */
fun makePinRecord(pin: String, salt: ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }, iterations: Int = PIN_ITERATIONS): String =
    "${pin.length}:$iterations:${hex(salt)}:${hex(derive(pin, salt, iterations))}"

/** True when [pin] is the PIN [record] was made from. Anything unreadable is simply false. */
fun checkPinRecord(pin: String, record: String?): Boolean {
    val p = record?.split(":") ?: return false
    if (p.size != 4 || !validPin(pin)) return false
    val iterations = p[1].toIntOrNull()?.takeIf { it > 0 } ?: return false
    val salt = runCatching { unhex(p[2]) }.getOrNull() ?: return false
    val want = runCatching { unhex(p[3]) }.getOrNull() ?: return false
    return MessageDigest.isEqual(derive(pin, salt, iterations), want)
}

/** How many digits the saved PIN has, or null if there is no usable record. */
fun pinLength(record: String?): Int? = record?.split(":")?.firstOrNull()?.toIntOrNull()?.takeIf { it in PIN_MIN..PIN_MAX }

/** How long to wait after [fails] wrong tries in a row: nothing for the first four, then 30 seconds, doubling with each try up to 8 minutes. */
fun lockoutMs(fails: Int): Long = if (fails < 5) 0L else minOf(30_000L shl minOf(fails - 5, 4), 480_000L)

/** What is left of that wait. A last-try time in the future (the clock was set back) never makes it longer than the wait itself. */
fun lockoutRemainingMs(fails: Int, lastFailAt: Long, now: Long): Long {
    val wait = lockoutMs(fails)
    return minOf(maxOf(0L, lastFailAt + wait - now), wait)
}

/** Lock again when something is protected and you were away at least as long as the chosen delay. */
fun shouldRelock(protected: Boolean, awayMs: Long, delayMs: Long) = protected && awayMs >= delayMs

/**
 * The names of the boxes that are hidden: boxes marked hidden and every box inside them. Hiding a box hides everything in its tree.
 */
fun hiddenBoxNames(shelves: List<Shelf>): Set<String> {
    val inside = shelves.groupBy { it.parent }
    val out = HashSet<String>()
    fun add(name: String) { if (out.add(name)) inside[name]?.forEach { add(it.name) } }
    shelves.filter { it.hidden }.forEach { add(it.name) }
    return out
}

/** The scraps to show: all of them once hidden boxes are unlocked, otherwise without the scraps in hidden boxes. */
fun visibleItems(all: List<Item>, hidden: Set<String>, unlocked: Boolean): List<Item> =
    if (unlocked || hidden.isEmpty()) all else all.filter { it.collection !in hidden }

/** The answer to a PIN try. */
sealed class PinCheck {
    object Ok : PinCheck()
    object Wrong : PinCheck()
    /** Too many wrong tries: nothing is checked until [ms] have passed. */
    class Wait(val ms: Long) : PinCheck()
}

/** A PIN screen on top of the app: [Create] chooses a new PIN, [Verify] asks for the current one. [onDone] runs once it succeeded. */
sealed class PinFlow {
    abstract val title: String
    abstract val onDone: () -> Unit
    class Create(override val title: String, override val onDone: () -> Unit = {}) : PinFlow()
    class Verify(override val title: String, override val onDone: () -> Unit) : PinFlow()
}
