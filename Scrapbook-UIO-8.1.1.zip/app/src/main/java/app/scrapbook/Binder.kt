package app.scrapbook

import java.net.URLDecoder

// WORKING TOGETHER WITH BINDER
//
// Binder (package app.binder) is the lists and catalogues app of the same family. The two apps keep their own data and talk through links and
// explicit intents, so each one works alone and the other is simply absent when it is not installed. This file is only the rules; the Android
// side is ui/BinderBridge.kt. The rules, the same in both apps:
//
//   binder://item/<id>, binder://bind/<id>           open an item / a bind in Binder (the id is Binder's permanent id)
//   scrapbook://scrap/<uid>                          open a scrap (see Links.kt)
//   scrapbook://scrap/<uid>?binder=<id>&title=<t>    opens the scrap AND adds a link to that Binder item at its end (Binder sends this after "Add to Binder")
//   action app.binder.action.ADD                     Scrapbook asks Binder to add one item:   title, note, scrap (the scrap's uid)
//   action app.binder.action.IMPORT                  Scrapbook asks Binder to make a bind:    name, kind (optional), items, done (optional), scraps (optional)
//   action app.scrapbook.action.CREATE               Binder asks Scrapbook to make a scrap:   title, body, uid, box (optional), a cover picture in EXTRA_STREAM (optional)
//
// Binder chooses the uid of a scrap it asks for, so it can store the link to it at once; the scrap is made with exactly that uid.

const val BINDER_PACKAGE = "app.binder"
const val BINDER_ACTIVITY = "app.binder.MainActivity"
const val ACTION_BINDER_ADD = "app.binder.action.ADD"
const val ACTION_BINDER_IMPORT = "app.binder.action.IMPORT"
const val ACTION_SCRAPBOOK_CREATE = "app.scrapbook.action.CREATE"

fun binderItemLink(id: String) = "binder://item/$id"
fun binderBindLink(id: String) = "binder://bind/$id"

/** What a binder:// link points at: [kind] is "item" or "bind". */
class BinderRef(val kind: String, val id: String)

private val BINDER_LINK = Regex("binder://(item|bind)/([A-Za-z0-9-]{8,64})/?", RegexOption.IGNORE_CASE)

/** The item or bind inside a binder://item/<id> or binder://bind/<id> link, or null for anything else. */
fun parseBinderLink(url: String?): BinderRef? {
    val text = url?.trim() ?: return null
    val m = BINDER_LINK.matchEntire(text) ?: return null
    return BinderRef(m.groupValues[1].lowercase(), m.groupValues[2])
}

/** A scrapbook://scrap/<uid> link, with what Binder may have added: the id and name of the Binder item to link back to. */
class ScrapOpen(val uid: String, val binderItem: String?, val binderTitle: String?)

private val SCRAP_OPEN = Regex("scrapbook://scrap/([A-Za-z0-9-]{8,64})/?(?:\\?(.*))?", RegexOption.IGNORE_CASE)

private fun queryOf(s: String): Map<String, String> =
    if (s.isEmpty()) emptyMap()
    else s.split('&').mapNotNull { p ->
        val i = p.indexOf('=')
        if (i <= 0) null else URLDecoder.decode(p.substring(0, i), "UTF-8") to URLDecoder.decode(p.substring(i + 1), "UTF-8")
    }.toMap()

/** Reads a scrapbook://scrap/<uid> link, with or without Binder's ?binder=<id>&title=<name>; null for anything else. */
fun parseScrapOpen(url: String?): ScrapOpen? {
    val text = url?.trim() ?: return null
    val m = SCRAP_OPEN.matchEntire(text) ?: return null
    val q = runCatching { queryOf(m.groupValues[2]) }.getOrDefault(emptyMap())
    return ScrapOpen(m.groupValues[1].lowercase(), q["binder"]?.takeIf { it.isNotBlank() }, q["title"])
}

/** The line that links a scrap to its Binder item: "Binder: [name](binder://item/<id>)". Brackets in the name would break the link, so they are dropped. */
fun binderLinkLine(title: String, id: String): String =
    "Binder: [${title.replace(Regex("[\\[\\]\\n]+"), " ").trim().ifBlank { "item" }}](${binderItemLink(id)})"

/** The body with the link line added at its end, once: a body that already links to this item is returned as it is. */
fun withBinderLink(body: String, title: String, id: String): String {
    if (binderItemLink(id) in body) return body
    val line = binderLinkLine(title, id)
    return if (body.isBlank()) line else body.trimEnd('\n') + "\n\n" + line
}

private val BINDER_ITEM_IN_TEXT = Regex("binder://item/([A-Za-z0-9-]{8,64})", RegexOption.IGNORE_CASE)

/** The id of the first Binder item this text links to, ignoring anything inside code, or null. */
fun firstBinderItem(body: String): String? =
    BINDER_ITEM_IN_TEXT.find(maskCode(body))?.groups?.get(1)?.range?.let { body.substring(it.first, it.last + 1) }

/** The short note Binder keeps with an item added from a scrap: the start of its text without formatting. */
fun binderNoteOf(title: String, body: String): String = previewHead(title, body).take(200).trim()

/** The checklist lines of a text as (text without formatting, ticked), in order. A "- [ ]" inside a code block is code, not a task. */
fun checklistItems(body: String): List<Pair<String, Boolean>> {
    val lines = body.lines(); val code = codeLineStates(lines)
    return lines.mapIndexedNotNull { i, l ->
        if (code[i] != CodeLine.NONE) return@mapIndexedNotNull null
        val done = l.startsWith("- [x] ")
        if (!done && !l.startsWith("- [ ] ")) return@mapIndexedNotNull null
        val text = plainPreview(l.drop(6), "").trim()
        if (text.isEmpty()) null else text to done
    }
}
