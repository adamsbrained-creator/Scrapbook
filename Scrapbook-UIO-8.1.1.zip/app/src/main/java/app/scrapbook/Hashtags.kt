package app.scrapbook

// #words typed in a scrap's text count as tags, the way they do on social media. The rules live here, apart from the editor, so they can be tested.
// A hashtag is a # at the start of a word, then a letter, then letters, digits, _ or -. So "# Title" (a heading), "## Title", "C#", "#12", "page#section"
// and "https://site/#top" are not hashtags, and neither is anything inside code (`code` or a fenced block). Formatting marks (** ~~ == and the | of a color span) may sit right before the #, so a bold or colored hashtag still counts.

private const val MAX_HASHTAG = 40
private const val OPENERS = "([{\"'\u201C\u2018\u00AB*~=|"

private fun startsWord(text: String, i: Int): Boolean = i == 0 || text[i - 1].isWhitespace() || text[i - 1] in OPENERS

/** Where the hashtags are in [text], each range covering the # as well. Used to find them and to color them in the editor. */
fun hashtagRanges(source: String): List<IntRange> {
    val text = maskCode(source)   // nothing in code is a hashtag: "# comment" lines and "#include" in a code block stay plain
    val out = ArrayList<IntRange>(); val n = text.length; var i = 0
    while (i < n) {
        if (text[i] == '#' && startsWord(text, i) && i + 1 < n && text[i + 1].isLetter()) {
            var j = i + 2
            while (j < n && (text[j].isLetterOrDigit() || text[j] == '_' || text[j] == '-')) j++
            var end = j
            while (end > i + 1 && (text[end - 1] == '-' || text[end - 1] == '_')) end--
            if (end - (i + 1) in 1..MAX_HASHTAG) out += i until end
            i = j
        } else i++
    }
    return out
}

/**
 * The hashtags in [text] without the #, each once (ignoring case). With a [caret], the word the cursor is in or right after is left out: it may
 * still be being typed, and "#t", "#te", "#tes" must not each become a tag.
 */
fun hashtagsIn(text: String, caret: Int? = null): List<String> =
    hashtagRanges(text).filter { r -> caret == null || !(caret > r.first && caret <= r.last + 1) }
        .map { text.substring(it.first + 1, it.last + 1) }.distinctBy { it.lowercase() }

/** Every hashtag in [text], lower case: what a scrap already had when it was opened, so those are not turned into tags again. */
fun hashtagKeys(text: String): Set<String> = hashtagsIn(text).map { it.lowercase() }.toSet()

/** The hashtags to add as tags now: those in [text] (not counting the word at [caret]) that are not in [handled] yet. */
fun newHashtags(text: String, caret: Int?, handled: Set<String>): List<String> = hashtagsIn(text, caret).filter { it.lowercase() !in handled }
