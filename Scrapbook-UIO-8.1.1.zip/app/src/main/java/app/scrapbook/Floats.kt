package app.scrapbook

import kotlin.math.abs
import kotlin.math.max

/**
 * How a photo or a file sits on the page.
 * Inline is the normal way: it is in the order of the page (see PageLayout) and takes the full row. Nothing is stored for it.
 * Wrap: it sits at the left edge and the text runs beside it. Free: it floats anywhere on the page, in front of the text.
 */
enum class Placing(val code: Char) { Inline('I'), Wrap('W'), Free('F') }

/**
 * Where a photo or file is when it is not in line. [width] is a fraction of the page width (its height follows the picture).
 * Wrap: [line] is the line of the text (a paragraph, counted from 0) that it starts beside; it always sits at the left edge.
 * Free: [x] is its left edge as a fraction of the page width, [y] its top in dp from the top of the text.
 */
data class Placed(val how: Placing, val width: Float, val x: Float = 0f, val y: Float = 0f, val line: Int = 0)

/** Room kept beside a wrapped object: from the top of line [line] down for [height] px, [indent] px in from the left. */
data class WrapZone(val line: Int, val height: Float, val indent: Float)

/**
 * The photos and files that are not in line (Wrap or Free), and how the text makes room for the wrapped ones.
 *
 * While the page is open each is known by what it is (a photo's address, a file's path), so moving, removing and Undo can never mix them up. Saved, it is
 * known by its place among the photos or among the files (the third photo is "p2"), so a backup restored with new addresses still finds them. The text is
 * the usual page order followed by one "|" entry per object: "Photo,Text|p0:W:0.4:0.0:0.0:3|f1:F:0.55:0.4:120.0:0".
 */
object Floats {
    const val MIN_WIDTH = 0.12f
    const val MIN_FILE_WIDTH = 0.4f
    const val MAX_WRAP = 0.7f

    fun photoKey(uri: String) = "p$uri"
    fun fileKey(path: String) = "f$path"

    private fun minWidth(isFile: Boolean) = if (isFile) MIN_FILE_WIDTH else MIN_WIDTH
    private fun finite(v: Float, otherwise: Float) = if (v.isFinite()) v else otherwise

    /** The smallest and largest fraction of the page this object can be made. */
    fun minWidthOf(key: String) = minWidth(key.startsWith("f"))
    fun maxWidthOf(key: String, p: Placed): Float = if (p.how == Placing.Wrap) MAX_WRAP else max(minWidthOf(key), 1f - p.x)

    /** What an object gets the first time it is placed: wide enough to read, narrow enough to leave room. */
    fun defaultWidth(isFile: Boolean, how: Placing): Float = if (isFile) 0.55f else if (how == Placing.Wrap) 0.4f else 0.45f

    /**
     * [placed] without what is not (or no longer) there, and with every number brought into range, so what is kept and compared is always sensible.
     * Anything in line is dropped (in line is the absence of an entry).
     */
    fun clean(placed: Map<String, Placed>, photos: List<String>, files: List<String>): Map<String, Placed> {
        if (placed.isEmpty()) return placed
        val out = LinkedHashMap<String, Placed>()
        fun take(key: String) {
            val p = placed[key] ?: return
            if (p.how == Placing.Inline) return
            val w = finite(p.width, defaultWidth(key.startsWith("f"), p.how)).coerceIn(minWidthOf(key), if (p.how == Placing.Wrap) MAX_WRAP else 1f)
            out[key] = when (p.how) {
                Placing.Wrap -> Placed(Placing.Wrap, w, 0f, 0f, max(0, p.line))
                else -> Placed(Placing.Free, w, finite(p.x, 0f).coerceIn(0f, max(0f, 1f - w)), max(0f, finite(p.y, 0f)), 0)
            }
        }
        for (u in photos) take(photoKey(u))
        for (f in files) take(fileKey(f))
        return out
    }

    /** Reads the "|" entries of a saved page layout. Entries that do not make sense, or name a photo or file that is not there, are skipped. */
    fun parse(saved: String?, photos: List<String>, files: List<String>): Map<String, Placed> {
        if (saved.isNullOrBlank() || '|' !in saved) return emptyMap()
        val out = LinkedHashMap<String, Placed>()
        for (entry in saved.split('|').drop(1)) {
            val f = entry.split(':')
            if (f.size < 6 || f[0].length < 2) continue
            val index = f[0].substring(1).toIntOrNull() ?: continue
            val id = when (f[0][0]) { 'p' -> photos.getOrNull(index); 'f' -> files.getOrNull(index); else -> null } ?: continue
            val how = Placing.entries.firstOrNull { it.code.toString() == f[1] } ?: continue
            val w = f[2].toFloatOrNull() ?: continue
            val x = f[3].toFloatOrNull() ?: continue
            val y = f[4].toFloatOrNull() ?: continue
            val line = f[5].toIntOrNull() ?: continue
            out[(if (f[0][0] == 'p') photoKey(id) else fileKey(id))] = Placed(how, w, x, y, line)
        }
        return clean(out, photos, files)
    }

    private fun num(v: Float): String = (Math.round(v * 1000f) / 1000f).toString()

    /** The "|" entries to store after the page order: nothing at all when no photo or file is placed, so a scrap nobody changed stays exactly as it was. */
    fun encode(placed: Map<String, Placed>, photos: List<String>, files: List<String>): String {
        val c = clean(placed, photos, files)
        if (c.isEmpty()) return ""
        val sb = StringBuilder(); val seen = HashSet<String>()
        fun add(letter: Char, ids: List<String>) {
            ids.forEachIndexed { i, id ->
                val key = "$letter$id"
                val p = c[key]
                if (p != null && seen.add(key)) sb.append('|').append(letter).append(i).append(':').append(p.how.code).append(':')
                    .append(num(p.width)).append(':').append(num(p.x)).append(':').append(num(p.y)).append(':').append(p.line)
            }
        }
        add('p', photos); add('f', files)
        return sb.toString()
    }

    /** The whole text to store for a page: its order (see [PageLayout.encode]) and the placed photos and files. */
    fun save(layout: List<Part>, placed: Map<String, Placed>, photos: List<String>, files: List<String>): String =
        PageLayout.encode(layout, photos.size, files.size) + encode(placed, photos, files)

    /**
     * What an object becomes when it is switched to [how]. Null means in line. Its size is kept when it has one; from in line it gets a default size.
     * A wrapped object starts at the top of the text; a free one starts at the right edge, or where the wrapped one was ([topDp], dp from the top of the text).
     */
    fun switchTo(cur: Placed?, how: Placing, isFile: Boolean, topDp: Float = 0f): Placed? {
        if (how == Placing.Inline) return null
        val minW = minWidth(isFile)
        val w = (cur?.width ?: defaultWidth(isFile, how)).coerceIn(minW, if (how == Placing.Wrap) MAX_WRAP else 1f)
        return if (how == Placing.Wrap) Placed(Placing.Wrap, w, 0f, 0f, if (cur != null && cur.how == Placing.Wrap) cur.line else 0)
        else if (cur != null && cur.how == Placing.Free) cur
        else Placed(Placing.Free, w, if (cur == null) max(0f, 1f - w) else 0f, max(0f, topDp), 0)
    }

    /** The line whose top is closest to [y]: where a wrapped object lands when it is let go there. 0 when there are no lines yet. */
    fun lineAt(tops: List<Float>, y: Float): Int {
        var best = 0; var dist = Float.MAX_VALUE
        tops.forEachIndexed { i, t -> val d = abs(t - y); if (d < dist) { dist = d; best = i } }
        return best
    }

    /**
     * How far each line of the text has to be pushed in from the left to leave room for the wrapped objects. [tops] is the top of every line (paragraph) of the
     * text in px as it is laid out now. A wrapped object starts at the top of its line; that line and every following one that starts above the object's
     * bottom is pushed in by the object's [WrapZone.indent]. (A paragraph is pushed in as a whole, so a very long one stays narrow below the object too.)
     */
    fun indents(tops: List<Float>, zones: List<WrapZone>): Map<Int, Float> {
        val out = HashMap<Int, Float>()
        if (tops.isEmpty()) return out
        for (z in zones) {
            val first = z.line.coerceIn(0, tops.lastIndex)
            val bottom = tops[first] + z.height
            var j = first
            do { out[j] = max(out[j] ?: 0f, z.indent); j++ } while (j < tops.size && tops[j] < bottom)
        }
        return out
    }
}
