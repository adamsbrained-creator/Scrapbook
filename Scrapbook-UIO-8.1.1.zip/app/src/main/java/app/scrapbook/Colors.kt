package app.scrapbook

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Free (RGB) colors for a page's color and accent, kept in the same whole-number columns that already hold the five ready-made choices.
 * 0 is "none", 1 to 5 are the ready-made colors, and a number from [FLAG] up is a color of your own: FLAG plus the red, green and blue of the color.
 * So every scrap saved before this keeps meaning exactly what it did, and a backup holds custom colors without any new field.
 *
 * The picker is two bars: one for the hue and one that runs from black through the pure color to white. [fromHueShade] and [toHueShade] go between those two bars and
 * a color, so the bars can be put back where they were when you reopen a custom color.
 */
object CustomColors {
    const val FLAG = 0x01000000

    /** The color a new custom choice starts as (a clear blue), until you move the bars. */
    const val START_RGB = 0x0A84FF

    fun isCustom(value: Int): Boolean = value >= FLAG
    fun encode(rgb: Int): Int = FLAG or (rgb and 0xFFFFFF)
    fun rgb(value: Int): Int = value and 0xFFFFFF

    /** The color at [hue] (0 to 360) and [shade] (0 black, 0.5 the pure color, 1 white), as 0xRRGGBB. */
    fun fromHueShade(hue: Float, shade: Float): Int {
        val t = shade.coerceIn(0f, 1f)
        val s = if (t < .5f) 1f else 1f - (t - .5f) * 2f
        val v = if (t < .5f) t * 2f else 1f
        return hsvToRgb(((hue % 360f) + 360f) % 360f, s, v)
    }

    /** The two bar positions for a color: the hue (0 to 360) and the shade (0 to 1). Colors that are not on the bars land on the nearest spot. */
    fun toHueShade(rgb: Int): Pair<Float, Float> {
        val r = ((rgb shr 16) and 255) / 255f; val g = ((rgb shr 8) and 255) / 255f; val b = (rgb and 255) / 255f
        val hi = max(r, max(g, b)); val lo = min(r, min(g, b)); val d = hi - lo
        val hue = when {
            d == 0f -> 0f
            hi == r -> 60f * (((g - b) / d) % 6f)
            hi == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }.let { if (it < 0f) it + 360f else it }
        val sat = if (hi == 0f) 0f else d / hi
        val shade = if (hi < .999f) hi / 2f else .5f + (1f - sat) / 2f
        return hue to shade.coerceIn(0f, 1f)
    }

    private fun hsvToRgb(h: Float, s: Float, v: Float): Int {
        val c = v * s; val x = c * (1f - abs((h / 60f) % 2f - 1f)); val m = v - c
        val (r, g, b) = when {
            h < 60f -> Triple(c, x, 0f); h < 120f -> Triple(x, c, 0f); h < 180f -> Triple(0f, c, x)
            h < 240f -> Triple(0f, x, c); h < 300f -> Triple(x, 0f, c); else -> Triple(c, 0f, x)
        }
        fun ch(f: Float) = ((f + m) * 255f + .5f).toInt().coerceIn(0, 255)
        return (ch(r) shl 16) or (ch(g) shl 8) or ch(b)
    }

    /** The position in [palette] (a list of 0xRRGGBB colors) closest to [rgb]. Used to pick the launcher icon that suits a custom accent. */
    fun nearest(rgb: Int, palette: List<Int>): Int {
        fun dist(a: Int, b: Int): Int {
            val dr = ((a shr 16) and 255) - ((b shr 16) and 255); val dg = ((a shr 8) and 255) - ((b shr 8) and 255); val db = (a and 255) - (b and 255)
            return dr * dr + dg * dg + db * db
        }
        return palette.indices.minByOrNull { dist(rgb, palette[it]) } ?: 0
    }
}
