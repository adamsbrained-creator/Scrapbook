package app.scrapbook

// The plain rules behind search: which words were typed, which scraps match, where the matches sit, and which stretch of text to show.
// Matching ignores case. Positions are found in the original text (never in a lowercased copy), so they cannot drift on letters like İ or ẞ.

/** The words typed in the search field, without repeats. "red  car" gives [red, car]. */
fun searchTerms(q: String): List<String> =
    q.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.distinctBy { it.lowercase() }

/** A scrap matches when every typed word appears somewhere in it (the title, text, tags, ...), in any order. No words typed matches everything. */
fun matchesAll(terms: List<String>, fields: List<String>): Boolean =
    terms.all { t -> fields.any { it.contains(t, ignoreCase = true) } }

/** Where any of the [terms] occur in [text], as sorted ranges of character positions. Overlapping or touching ranges are joined into one. */
fun matchRanges(text: String, terms: List<String>): List<IntRange> {
    if (text.isEmpty()) return emptyList()
    val found = ArrayList<IntRange>()
    terms.filter { it.isNotEmpty() }.forEach { t ->
        var i = 0
        while (i <= text.length - t.length) {
            if (text.regionMatches(i, t, 0, t.length, ignoreCase = true)) { found += i until i + t.length; i += t.length } else i++
        }
    }
    if (found.isEmpty()) return found
    found.sortBy { it.first }
    val out = ArrayList<IntRange>(); var cur = found[0]
    for (r in found.drop(1)) {
        if (r.first <= cur.last + 1) { if (r.last > cur.last) cur = cur.first..r.last } else { out += cur; cur = r }
    }
    out += cur
    return out
}

/**
 * The part of a long [text] worth showing for a search: the start when the first match is already near it, otherwise about [max] characters
 * around the first match, cut at word edges, with "…" at each cut end. Text with no match, or short text, is returned unchanged.
 */
fun snippet(text: String, terms: List<String>, max: Int = 90): String {
    if (text.length <= max) return text
    val first = matchRanges(text, terms).firstOrNull() ?: return text
    if (first.last < max) return text
    var from = (first.first - max / 4).coerceAtLeast(0)
    var to = (from + max).coerceAtMost(text.length)
    if (from > 0) { val sp = text.indexOf(' ', from); if (sp in 0 until first.first) from = sp + 1 }
    if (to < text.length) { val sp = text.lastIndexOf(' ', to); if (sp > first.last) to = sp }
    to = maxOf(to, minOf(text.length, first.last + 1))
    return (if (from > 0) "…" else "") + text.substring(from, to).trim() + (if (to < text.length) "…" else "")
}

/** The tags ("#idea") and attachment names that contain a typed word: the small "why did this match" line under a result. */
fun matchedExtras(tags: List<String>, attachmentNames: List<String>, terms: List<String>): List<String> {
    fun hit(s: String) = terms.any { s.contains(it, ignoreCase = true) }
    return tags.filter(::hit).map { "#$it" } + attachmentNames.filter(::hit)
}

/** The most searches kept in the Recent list. */
const val MAX_RECENT_SEARCHES = 8

/** The Recent list as saved (one search per line) back into a list. */
fun parseRecentSearches(stored: String?): List<String> = (stored ?: "").lines().map { it.trim() }.filter { it.isNotEmpty() }

fun encodeRecentSearches(list: List<String>): String = list.joinToString("\n")

/**
 * [query] put at the front of [list]. Spaces are tidied, a search already there (in any letter case) moves up instead of repeating, and the
 * list is cut to [max]. A search shorter than two letters is not worth keeping, so the list comes back as it was.
 */
fun addRecentSearch(list: List<String>, query: String, max: Int = MAX_RECENT_SEARCHES): List<String> {
    val q = query.trim().replace(Regex("\\s+"), " ")
    if (q.length < 2) return list
    return (listOf(q) + list.filterNot { it.equals(q, ignoreCase = true) }).take(max)
}

/**
 * The boxes a search in the box called [name] looks in: that box and, once words are typed ([searching]), every box inside it at any depth.
 * With nothing typed only the box itself, so the screen shows exactly what is filed in it.
 */
fun searchBoxNames(name: String, shelves: List<Shelf>, searching: Boolean): Set<String> =
    if (searching) setOf(name) + shelves.descendantsOf(name).map { it.name } else setOf(name)
