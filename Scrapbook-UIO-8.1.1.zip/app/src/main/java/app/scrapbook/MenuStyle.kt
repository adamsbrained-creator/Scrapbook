package app.scrapbook

/**
 * The skins a menu can wear. [key] is what is saved, so never rename one. What each skin looks like is in ui/MenuSkins.kt; this is only the list and the names.
 * Add a skin: add it here, give it a MenuSkin in MenuSkins.kt and a case in MenuSkins.of.
 */
enum class MenuSkinId(val key: String, val label: String, val blurb: String) {
    Classic("classic", "Classic", "The sheet you know: docked to the bottom, soft grey groups, one big button."),
    Floating("float", "Float", "A card that floats above the page, with a centered title, outlined groups, icon tiles and two buttons.");

    companion object {
        /** An unknown or missing name falls back to Classic, so a skin removed in a later version never leaves the menu without a look. */
        fun of(key: String?): MenuSkinId = entries.firstOrNull { it.key == key } ?: Classic
    }
}

/**
 * The choices that work on top of any skin. Whether a skin uses one is up to the skin: Classic has no footer line and no floating pill, so those two do nothing there.
 * [rowSize] 0 compact, 1 comfortable, 2 roomy; [dim] 0 light, 1 normal, 2 strong; [action] 0 two buttons, 1 a floating pill.
 */
data class MenuOptions(
    val rowSize: Int = 1,
    val icons: Boolean = true,
    val dim: Int = 1,
    val footer: Boolean = true,
    val action: Int = 0,
) {
    fun clamped(): MenuOptions = copy(rowSize = rowSize.coerceIn(0, 2), dim = dim.coerceIn(0, 2), action = action.coerceIn(0, 1))

    /** How dark the page behind a sheet goes. */
    val dimAlpha: Float get() = DIM_ALPHA[dim.coerceIn(0, 2)]

    /** How many dp taller (or shorter, when negative) than the usual a row is. */
    val rowDelta: Int get() = (rowSize.coerceIn(0, 2) - 1) * 8

    companion object {
        val ROW_SIZES = listOf("Compact", "Comfortable", "Roomy")
        val DIMS = listOf("Light", "Normal", "Strong")
        val ACTIONS = listOf("Two buttons", "Floating pill")
        private val DIM_ALPHA = listOf(.22f, .4f, .58f)
    }
}

/** The skin and the choices on top of it. */
data class MenuStyle(val skin: MenuSkinId = MenuSkinId.Classic, val options: MenuOptions = MenuOptions())
