package app.scrapbook

/**
 * The width, in dp, of a plain (not polaroid) photo in the editor, so it fills the page: a single photo spans it, and with several the next one peeks in from the
 * right so it is clear that the row scrolls. [screenDp] is the screen's width; the page has about 20dp of margin on each side.
 */
fun plainPhotoWidth(screenDp: Int, count: Int): Int = (if (count <= 1) screenDp - 40 else screenDp - 80).coerceAtLeast(160)
