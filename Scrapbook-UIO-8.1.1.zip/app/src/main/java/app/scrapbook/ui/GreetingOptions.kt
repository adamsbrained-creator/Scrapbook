package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// The options of the greeting, opened from the Greeting row in Customize home (the sliders button). They used to be a page in Settings; every part of Home is meant to
// keep its own options here, next to where it is moved and hidden. The rows are the same ones Settings uses. The preview stays on top while the rest scrolls,
// so a slider can be seen working. Showing or hiding the greeting is the eye on its row in Customize home, so there is no switch for it here.

@Composable
fun GreetingOptions(vm: ArchiveViewModel, onBack: () -> Unit) {
    val account by vm.account.collectAsState()
    val greet by vm.greetingPrefs.collectAsState()
    val stylesNow by vm.homeStyles.collectAsState()
    val styles = stylesNow ?: HomeStyles.Default
    val scraps by vm.items.collectAsState()
    var picker by remember { mutableStateOf<String?>(null) }
    // While a size slider is being dragged the preview follows it before anything is saved; afterwards it simply equals the saved size.
    var liveText by remember { mutableStateOf<Int?>(null) }
    var livePic by remember { mutableStateOf<Int?>(null) }
    BackHandler { onBack() }

    val picks = mapOf(
        "tone" to SettingPick("Greeting tone", GreetingPrefs.TONES, greet.tone.coerceIn(0, 3), note = "Mixed uses all three voices. The others stick to their own.") { vm.setGreetingPrefs(greet.copy(tone = it)) },
        "every" to SettingPick("Change greeting every", GreetingPrefs.EVERY.map { if (it == 0) "Never" else "$it seconds" }, GreetingPrefs.EVERY.indexOf(greet.everySec).coerceAtLeast(0),
            note = "A new greeting also appears each time Home opens, and whenever you tap it.") { vm.setGreetingPrefs(greet.copy(everySec = GreetingPrefs.EVERY[it])) },
        "sub" to SettingPick("Line under the greeting", GreetingPrefs.SUBS, greet.sub.coerceIn(0, 3)) { vm.setGreetingPrefs(greet.copy(sub = it)) },
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                CircleBtn("Back to Customize home", onBack) { Ic("back", 22.dp, Sb.ink) }
                Text("Greeting", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
            }
            Spacer(Modifier.height(10.dp))
            SettingsCard {
                Box(Modifier.fillMaxWidth().padding(vertical = 14.dp)) {
                    GreetingHub(account, greet.copy(textSize = liveText ?: greet.textSize, picSize = livePic ?: greet.picSize), scraps.size, 0, scraps.count { it.pinned },
                        style = styles[HomeStyleKey.GreetingStyle], picLeft = styles[HomeStyleKey.GreetingPicture] == 1, bg = styles[HomeStyleKey.GreetingBackground],
                        shape = styles[HomeStyleKey.GreetingShape], anim = styles[HomeStyleKey.GreetingAnimation], onProfile = {})
                }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
                SectionLabel("Look")
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Optional: the greeting keeps its classic look until another style is chosen.
                    TileChoice(HomeStyleKey.GreetingStyle, styles, { vm.setHomeStyles(it) }) { LayoutGlyph(it) }
                    if (styles[HomeStyleKey.GreetingStyle] != 1) DesignPicker(HomeStyleKey.GreetingPicture, styles) { vm.setHomeStyles(it) }
                    TileChoice(HomeStyleKey.GreetingBackground, styles, { vm.setHomeStyles(it) }) { BackgroundGlyph(it) }
                    if (greet.avatar) DesignPicker(HomeStyleKey.GreetingShape, styles) { vm.setHomeStyles(it) }
                    SettingsCard { SliderRow("headsize", "Text size", liveText ?: greet.textSize, GreetingPrefs.TEXT_MIN..GreetingPrefs.TEXT_MAX, { liveText = it }) { liveText = it; vm.setGreetingPrefs(greet.copy(textSize = it)) } }
                    SettingsCard { SliderRow("image", "Picture size", livePic ?: greet.picSize, GreetingPrefs.PIC_MIN..GreetingPrefs.PIC_MAX, { livePic = it }) { livePic = it; vm.setGreetingPrefs(greet.copy(picSize = it)) } }
                    SettingsCard { SwitchRow("person", "Show my picture", greet.avatar) { vm.setGreetingPrefs(greet.copy(avatar = it)) } }
                    SettingsCard { IconRow("list", "Line under the greeting", GreetingPrefs.SUBS[greet.sub.coerceIn(0, 3)]) { picker = "sub" } }
                    if (!styles.isDefault(HomeElement.Greeting)) SettingsCard { IconRow("undo", "Back to the classic look", "") { vm.setHomeStyles(styles.reset(HomeElement.Greeting)) } }
                }
                SectionLabel("Changing")
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { DesignPicker(HomeStyleKey.GreetingAnimation, styles) { vm.setHomeStyles(it) } }
                Spacer(Modifier.height(10.dp))
                SettingsCard { IconRow("clock", "Change greeting every", GreetingPrefs.EVERY.indexOf(greet.everySec).let { if (it <= 0) "Never" else "${greet.everySec} seconds" }) { picker = "every" } }
                Footer("Tap the greeting on Home to see another one right away.")
                SectionLabel("Greeting lines")
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsCard { IconRow("sparkle", "Greeting tone", GreetingPrefs.TONES[greet.tone.coerceIn(0, 3)]) { picker = "tone" } }
                    SettingsCard { SwitchRow("clock", "Time of day and weekdays", greet.time) { vm.setGreetingPrefs(greet.copy(time = it)) } }
                    SettingsCard { SwitchRow("sparkle", "Casual lines", greet.casual) { vm.setGreetingPrefs(greet.copy(casual = it)) } }
                    SettingsCard { SwitchRow("tag", "Lines about your scraps", greet.notes) { vm.setGreetingPrefs(greet.copy(notes = it)) } }
                }
                Footer("Your birthday, set on the Account page, always gets its own greeting.")
            }
        }
        picker?.let { key -> picks[key]?.let { PickerSheet(it) { picker = null } } }
    }
}

@Composable
private fun Footer(text: String) {
    Text(text, Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp), fontSize = 12.sp, color = Sb.mute)
}

/** A choice with many options, shown as tiles you swipe along (each with a small drawing), and a line saying what the chosen option looks like. */
@Composable
private fun TileChoice(k: HomeStyleKey, styles: HomeStyles, onStyles: (HomeStyles) -> Unit, glyph: @Composable (Int) -> Unit) {
    SettingsCard {
        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(k.label, Modifier.padding(horizontal = 18.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp), Arrangement.spacedBy(8.dp)) {
                k.options.forEachIndexed { i, name ->
                    val on = styles[k] == i
                    val tile = RoundedCornerShape(18.dp)
                    Column(Modifier.width(78.dp).clip(tile).border(2.dp, if (on) Sb.ink else Sb.line, tile).tap(name) { onStyles(styles.with(k, i)) }.semantics { selected = on }.padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(width = 56.dp, height = 40.dp), Alignment.Center) { glyph(i) }
                        Text(name, fontSize = 12.sp, fontWeight = if (on) FontWeight.Medium else FontWeight.Normal, color = Sb.ink, maxLines = 1)
                    }
                }
            }
            Text(k.hints[styles[k]], Modifier.padding(horizontal = 18.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
        }
    }
}

/** A tiny drawing of each layout, in the order of the Style choice: classic, centered, card, bubble, banner, minimal. */
@Composable
private fun LayoutGlyph(i: Int) {
    val ink = Sb.ink; val soft = Sb.ink.copy(alpha = .25f); val acc = LocalSb.current.acc; val onFill = onAccent(acc)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val t = 3.dp.toPx(); val r = CornerRadius(t / 2f)
        fun bar(x: Float, y: Float, len: Float, c: Color) = drawRoundRect(c, Offset(x, y), Size(len, t), r)
        fun dot(cx: Float, cy: Float, rad: Float, c: Color) = drawCircle(c, rad, Offset(cx, cy))
        when (i) {
            0 -> { bar(0f, h * .3f, w * .5f, soft); bar(0f, h * .52f, w * .68f, ink); dot(w - 7.dp.toPx(), h * .45f, 7.dp.toPx(), ink) }
            1 -> { dot(w / 2f, h * .24f, 6.dp.toPx(), ink); bar(w * .2f, h * .62f, w * .6f, ink); bar(w * .3f, h * .84f, w * .4f, soft) }
            2 -> { drawRoundRect(soft, Offset.Zero, size, CornerRadius(10.dp.toPx())); dot(11.dp.toPx(), h / 2f, 5.dp.toPx(), ink); bar(w * .32f, h * .36f, w * .5f, ink); bar(w * .32f, h * .56f, w * .34f, soft) }
            3 -> { dot(6.dp.toPx(), h - 8.dp.toPx(), 5.dp.toPx(), ink); drawRoundRect(soft, Offset(16.dp.toPx(), h * .12f), Size(w - 16.dp.toPx(), h * .62f), CornerRadius(9.dp.toPx())); bar(w * .38f, h * .36f, w * .45f, ink) }
            4 -> { drawRoundRect(acc, Offset.Zero, size, CornerRadius(12.dp.toPx())); bar(w * .12f, h * .34f, w * .5f, onFill); bar(w * .12f, h * .56f, w * .34f, onFill.copy(alpha = .6f)); dot(w - 10.dp.toPx(), h * .5f, 6.dp.toPx(), onFill) }
            else -> { dot(6.dp.toPx(), h / 2f, 5.dp.toPx(), ink); bar(w * .3f, h / 2f - t / 2f, w * .66f, ink) }
        }
    }
}

/** A tiny swatch of each background, in the order of the Background choice: automatic, none, card, tint, accent, gradient, outline. */
@Composable
private fun BackgroundGlyph(i: Int) {
    val acc = LocalSb.current.acc; val card = Sb.card; val line = Sb.line
    val onFill = onAccent(acc)
    val end = lerp(acc, if (onFill.luminance() < .5f) Color.White else Color.Black, .35f)
    if (i == 0) Box(Modifier.fillMaxSize().border(1.5.dp, line, RoundedCornerShape(10.dp)), Alignment.Center) { Text("A", fontSize = 18.sp, color = Sb.mute) }
    else Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val r = CornerRadius(10.dp.toPx()); val hair = Stroke(1.5.dp.toPx())
        when (i) {
            1 -> { drawRoundRect(line, cornerRadius = r, style = hair); drawLine(line, Offset(w * .2f, h * .85f), Offset(w * .8f, h * .15f), 1.5.dp.toPx()) }
            2 -> { drawRoundRect(card, cornerRadius = r); drawRoundRect(line, cornerRadius = r, style = hair) }
            3 -> drawRoundRect(acc.copy(alpha = .2f), cornerRadius = r)
            4 -> drawRoundRect(acc, cornerRadius = r)
            5 -> drawRoundRect(Brush.linearGradient(listOf(acc, end)), cornerRadius = r)
            else -> drawRoundRect(acc, cornerRadius = r, style = Stroke(2.dp.toPx()))
        }
    }
}
