package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

// Your own sections on Home (see HomeSections.kt for the rules): a row of shortcuts to scraps and boxes, made by dragging a thing out of Home and letting go.
// Each section has a name, one of four layouts (cards, chips, rows, grid) and whatever you put in it. Hold its title for Move up / Move down / Edit / Delete.
// Things inside a section can be held and carried too: to another section, to a box (a scrap is filed there), or into the open (a new section).

/** What a section can do, given by Home. Every function works on the newest saved sections. */
class SectionOps(
    val edit: (String) -> Unit,
    val move: (String, Int) -> Unit,
    val delete: (String) -> Unit,
    val rename: (String, String) -> Unit,
    val layout: (String, SectionLayout) -> Unit,
    val toggle: (String, SectionRef) -> Unit,
    val remove: (String, SectionRef) -> Unit,
    val newWith: (SectionRef) -> Unit,
)

/** Everything a section needs to draw itself and to be held. */
class HomeEnv(
    val vm: ArchiveViewModel, val nav: NavController, val items: List<Item>, val shelves: List<Shelf>, val counts: Map<String, Int>,
    val inboxHidden: Boolean, val colorOf: (String) -> Color, val drag: HomeDrag, val actions: HomeActions, val ops: SectionOps, val preview: Boolean,
)

/** One thing in a section, looked up again each time so a renamed box, a deleted scrap or a hidden Inbox is never shown wrongly. */
private class Entry(val ref: SectionRef, val scrap: Item?, val label: String, val dot: Color?, val count: Int) {
    val token: String get() = ref.token
}

private fun entriesOf(s: HomeSection, env: HomeEnv, byUid: Map<String, Item>): List<Entry> = s.refs.mapNotNull { r ->
    if (r.box) {
        if (r.key == "Inbox") { if (env.inboxHidden) null else Entry(r, null, "Inbox", env.colorOf("Inbox"), env.counts["Inbox"] ?: 0) }
        else env.shelves.firstOrNull { it.name == r.key }?.let { sh -> Entry(r, null, sh.label, TAB_COLORS[sh.color % TAB_COLORS.size], env.counts[sh.name] ?: 0) }
    } else byUid[r.key]?.let { n -> Entry(r, n, n.displayTitle, null, 0) }
}

private fun countText(n: Int) = if (n == 1) "1 scrap" else "$n scraps"

@Composable
private fun EntryChip(e: Entry, onClick: () -> Unit) {
    Row(Modifier.pressScale(.95f).height(48.dp).homeCard(24.dp).tap("Open ${e.label}", onClick).padding(horizontal = 20.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        if (e.dot != null) Box(Modifier.size(14.dp).clip(CircleShape).background(e.dot)) else Ic("page", 18.dp, Sb.mute)
        Text(e.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
        if (e.scrap == null) Text("${e.count}", fontSize = 15.sp, color = Sb.mute)
    }
}

/** A card the size of a Pinned card: a scrap shows its date and the start of its text, a box its color tab and how many scraps are in it. */
@Composable
private fun EntryCard(e: Entry, preview: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val n = e.scrap
    Column(modifier.pressScale(.96f).height(136.dp).homeCard(28.dp).tap("Open ${e.label}", onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (e.dot != null) { Box(Modifier.size(12.dp).clip(CircleShape).background(e.dot)); Spacer(Modifier.width(8.dp)) }
            Text(e.label, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n != null && n.pinned) { Spacer(Modifier.width(6.dp)); Ic("star", 14.dp, Color(0xFFFFB400)) }
        }
        if (n != null) {
            Text(fmtDate(n.savedAt, true), fontSize = 12.sp, color = Sb.mute)
            if (preview) Text(remember(n.title, n.body) { previewHead(n.title, n.body) }, Modifier.padding(top = 6.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = 3, overflow = TextOverflow.Ellipsis)
        } else {
            Text("Box", fontSize = 12.sp, color = Sb.mute)
            Text(countText(e.count), Modifier.padding(top = 6.dp), fontSize = 14.sp, color = Sb.mute)
        }
    }
}

/** A full-width row for a box (a scrap uses the normal scrap card). */
@Composable
private fun BoxRow(e: Entry, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().homeCard(28.dp).tap("Open ${e.label}", onClick).padding(horizontal = 20.dp, vertical = 18.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(e.dot ?: TAB_GRAY))
        Text(e.label, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(countText(e.count), fontSize = 14.sp, color = Sb.mute)
    }
}

/** One of your sections on Home. */
@Composable
fun SectionBlock(s: HomeSection, env: HomeEnv, modifier: Modifier = Modifier) {
    val byUid = remember(env.items) { env.items.associateBy { it.uid } }
    val entries = entriesOf(s, env, byUid)
    val source = "section:${s.id}"
    val ops = env.ops
    fun openEntry(e: Entry) { if (e.scrap != null) env.actions.open(e.scrap) else env.actions.openBox(e.ref.key) }

    /** Makes one entry holdable: its menu, and the payload that lets it be carried. A box in a section is also a place a scrap can be dropped on. */
    @Composable
    fun Held(e: Entry, mod: Modifier, content: @Composable () -> Unit) {
        val id = "sec:${s.id}:${e.token}"
        // Each thing reports its place under the section (so another thing of this section can be dropped on it to change the order); a box is also a place a scrap can be filed.
        val here = mod.dropRect(env.drag, "item:${s.id}\u0001${e.token}")
        val place = if (e.ref.box) here.dropRect(env.drag, "box:${e.ref.key}\u0001${s.id}") else here
        HoldSlot(env.drag, id, DragPayload(id, e.ref, e.label, e.dot, source, s.id), place, menu = { close ->
            if (e.scrap != null) ScrapMenu(e.scrap, env.actions, env.vm, close, true) { ops.remove(s.id, e.ref) }
            else BoxMenu(e.ref.key, env.actions, close, true) { ops.remove(s.id, e.ref) }
        }, content = content)
    }

    Column(modifier.dropRect(env.drag, source), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // The title: hold it for the section's own menu, tap it to edit.
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            HoldSlot(env.drag, "head:$source", null, Modifier.weight(1f), menu = { close ->
                PopupItem("Edit section", "edit") { close(); ops.edit(s.id) }
                PopupItem("Move up", "up") { close(); ops.move(s.id, -1) }
                PopupItem("Move down", "down") { close(); ops.move(s.id, 1) }
                PopupDivider()
                PopupItem("Delete section", "trash", tint = Sb.danger) { close(); ops.delete(s.id) }
            }) {
                Text(s.name, Modifier.asHeading(), fontSize = 18.sp, fontWeight = FontWeight.Medium, fontFamily = headFont(), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("Edit", Modifier.tap("Edit ${s.name}") { ops.edit(s.id) }.padding(vertical = 6.dp), fontSize = 14.sp, color = Sb.mute)
        }
        if (entries.isEmpty()) {
            Text("Nothing here yet. Drag a scrap or a box in, or tap Edit.", Modifier.padding(horizontal = 20.dp).fillMaxWidth().homeCard(28.dp)
                .tap("Edit ${s.name}") { ops.edit(s.id) }.padding(20.dp), fontSize = 15.sp, color = Sb.mute)
        } else when (s.layout) {
            SectionLayout.Chips -> LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(entries, key = { it.token }) { e -> Held(e, Modifier) { EntryChip(e) { openEntry(e) } } }
            }
            SectionLayout.Cards -> LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(entries, key = { it.token }) { e -> Held(e, Modifier) { EntryCard(e, env.preview, Modifier.width(176.dp)) { openEntry(e) } } }
            }
            SectionLayout.Rows -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                entries.forEach { e ->
                    Held(e, Modifier.fillMaxWidth()) {
                        if (e.scrap != null) NoteRow(e.scrap, env.nav, onHold = {}) else BoxRow(e) { openEntry(e) }
                    }
                }
            }
            SectionLayout.Grid -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                entries.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                        pair.forEach { e -> Held(e, Modifier.weight(1f)) { EntryCard(e, env.preview, Modifier.fillMaxWidth()) { openEntry(e) } } }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

/** Edit a section: its name, its layout, what is in it (and a way to add boxes and scraps), and Delete. */
@Composable
fun SectionSheet(section: HomeSection, env: HomeEnv, onDone: () -> Unit) {
    var name by remember { mutableStateOf(section.title) }
    var adding by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val ops = env.ops
    val byUid = remember(env.items) { env.items.associateBy { it.uid } }
    val entries = entriesOf(section, env, byUid)
    Sheet("Edit section", onDone) {
        SheetLabel("Name")
        InputBox { Field(name, { name = it.take(HomeSections.MAX_TITLE); ops.rename(section.id, name) }, "Section name", 18.sp, headFont(), FontWeight.Medium) }
        SheetLabel("Layout")
        Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            SectionLayout.entries.forEach { l -> SoftChip(l.label, section.layout == l) { ops.layout(section.id, l) } }
        }
        SheetLabel("In this section")
        if (entries.isEmpty()) SheetNote("Nothing yet. Add boxes and scraps below, or drag them in from Home.")
        else SheetGroup {
            entries.forEachIndexed { i, e ->
                if (i > 0) SheetDivider(46.dp)
                Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(start = 18.dp, end = 6.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                    if (e.dot != null) Box(Modifier.size(14.dp).clip(CircleShape).background(e.dot)) else Ic("page", 18.dp, Sb.mute)
                    Text(e.label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Remove ${e.label} from this section") { ops.remove(section.id, e.ref) }, Alignment.Center) { Ic("close", 20.dp, Sb.mute) }
                }
            }
        }
        SheetNote("A section only holds shortcuts. Taking something out never deletes it.")
        SheetGroup { ActionRow(if (adding) "up" else "plus", if (adding) "Done adding" else "Add boxes and scraps") { adding = !adding } }
        if (adding) {
            SheetLabel("Boxes")
            SheetGroup {
                val inboxRef = SectionRef(true, "Inbox")
                var first = true
                if (!env.inboxHidden) { OptionRow("Inbox", section.has(inboxRef), dot = env.colorOf("Inbox")) { ops.toggle(section.id, inboxRef) }; first = false }
                env.shelves.forEach { sh ->
                    if (!first) SheetDivider(46.dp); first = false
                    val r = SectionRef(true, sh.name)
                    OptionRow(sh.label, section.has(r), dot = TAB_COLORS[sh.color % TAB_COLORS.size]) { ops.toggle(section.id, r) }
                }
            }
            SheetLabel("Scraps")
            InputBox { Field(query, { query = it }, "Search your scraps", 16.sp, headFont()) }
            val shown = remember(env.items, query) {
                val q = query.trim()
                env.items.filter { q.isEmpty() || it.title.contains(q, true) || it.body.contains(q, true) }.sortedByDescending { it.savedAt }.take(25)
            }
            if (shown.isEmpty()) SheetNote("No scraps match.")
            else SheetGroup {
                shown.forEachIndexed { i, n ->
                    if (i > 0) SheetDivider(18.dp)
                    val r = SectionRef(false, n.uid)
                    OptionRow(n.displayTitle, section.has(r), sub = LocalShelves.current.displayName(n.collection)) { ops.toggle(section.id, r) }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        SheetGroup { ActionRow("trash", "Delete section", sub = "Only the section goes. Its scraps and boxes stay where they are.", danger = true) { ops.delete(section.id); onDone() } }
    }
}

/** Choose a section to put a scrap or a box in, or start a new one with it. */
@Composable
fun AddToSectionSheet(ref: SectionRef, sections: List<HomeSection>, ops: SectionOps, onDone: () -> Unit) {
    Sheet("Add to a section", onDone, doneLabel = "Cancel", soft = true) {
        if (sections.isNotEmpty()) SheetGroup {
            sections.forEachIndexed { i, s ->
                if (i > 0) SheetDivider(18.dp)
                OptionRow(s.name, s.has(ref), sub = if (s.refs.size == 1) "1 item" else "${s.refs.size} items") { ops.toggle(s.id, ref); onDone() }
            }
        }
        SheetGroup { ActionRow("plus", "New section with this") { ops.newWith(ref); onDone() } }
        if (sections.isEmpty()) SheetNote("You can also make a section by holding a scrap or a box and dragging it onto an empty spot of Home.")
    }
}
