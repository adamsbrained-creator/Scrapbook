package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import coil.compose.AsyncImage
import kotlin.math.roundToInt

// Photos and files that are not in line with the page (see Floats.kt): they sit at the left edge with the text beside them (Wrap) or anywhere on the page (Free).
// This layer is drawn over the text field. Tap an object to select it: it gets a frame, a handle in its corner to resize it, and a small bar to switch how it
// sits. Drag a selected object to move it. Tap it again to open it.

/** One photo or file that is not in line. [key] is the object's key in Floats; exactly one of [photo] (its address) and [file] is set. */
class FloatItem(val key: String, val photo: String?, val file: Attachment?, val placed: Placed)

/** Everything the layer needs to know about the page, and what to tell it when something happens. */
class FloatHost(
    /** Width of the page (the text box) and the height of its text, in px; [density] is px per dp. */
    val width: Int, val textHeight: Int, val density: Float,
    /** The top of every line of the text in px (see Floats.indents): where a wrapped object sits. */
    val lineTops: List<Float>,
    /** The measured size of every object, by key. */
    val sizes: Map<String, IntSize>,
    val selected: String?,
    /** False in view only: the objects are shown but cannot be touched. */
    val interactive: Boolean,
    /** True while writing: a selected object also has Remove. */
    val editing: Boolean,
    val onSelect: (String?) -> Unit,
    val onSize: (String, IntSize) -> Unit,
    /** An object was moved or resized: its key, where it is now and what to call the step in Undo. */
    val onChange: (String, Placed, String) -> Unit,
    val onMode: (String, Placing) -> Unit,
    val onRemove: (String) -> Unit,
    val onOpen: (String) -> Unit,
)

/** Where the top left corner of an object is, in px from the top left of the page. */
private fun cornerOf(p: Placed, host: FloatHost): IntOffset =
    if (p.how == Placing.Wrap) IntOffset(0, (host.lineTops.getOrNull(p.line) ?: 0f).roundToInt())
    else IntOffset((p.x * host.width).roundToInt(), (p.y * host.density).roundToInt())

/** Put inside a Box that is as big as the page's text: draws every object over it. */
@Composable
fun BoxScope.FloatLayer(items: List<FloatItem>, host: FloatHost) {
    Box(Modifier.matchParentSize()) {
        items.forEach { item -> key(item.key) { FloatObject(item, host) } }
        val sel = items.firstOrNull { it.key == host.selected }
        if (sel != null && host.interactive) FloatBar(sel, host)
    }
}

@Composable
private fun FloatObject(item: FloatItem, host: FloatHost) {
    val p = item.placed
    val d = LocalDensity.current
    val selected = host.selected == item.key && host.interactive
    var drag by remember(item.key) { mutableStateOf(Offset.Zero) }
    val hostNow by rememberUpdatedState(host)
    val itemNow by rememberUpdatedState(item)
    val corner = cornerOf(p, host)
    val widthDp = with(d) { (p.width * host.width).coerceAtLeast(1f).toDp() }
    // The outer box lets a tall picture be as tall as it is, whatever room the page has; the inner one is the object itself.
    Box(Modifier.offset { IntOffset(corner.x + drag.x.roundToInt(), corner.y + drag.y.roundToInt()) }.width(widthDp).wrapContentHeight(Alignment.Top, unbounded = true)) {
        Box(Modifier.onSizeChanged { host.onSize(item.key, it) }) {
            FloatBody(item)
            if (host.interactive) {
                Box(Modifier.matchParentSize()
                    .pointerInput(item.key) {
                        detectTapGestures(
                            onTap = { if (hostNow.selected == itemNow.key) hostNow.onOpen(itemNow.key) else hostNow.onSelect(itemNow.key) },
                            onLongPress = { hostNow.onSelect(itemNow.key) })
                    }
                    .pointerInput(item.key, selected) {
                        if (!selected) return@pointerInput
                        detectDragGestures(onDragStart = { drag = Offset.Zero }, onDragEnd = { dropAt(drag, itemNow, hostNow); drag = Offset.Zero }, onDragCancel = { drag = Offset.Zero }) { change, amount ->
                            change.consume(); drag += amount
                        }
                    })
            }
            if (selected) FloatFrame(item, host)
        }
    }
}

/** Lets go of a moved object: a free one stays where it is, a wrapped one starts beside the line closest to where it was let go. */
private fun dropAt(drag: Offset, item: FloatItem, host: FloatHost) {
    val p = item.placed
    if (host.width <= 0) return
    val c = cornerOf(p, host)
    val cx = c.x + drag.x; val cy = c.y + drag.y
    val next = if (p.how == Placing.Wrap) p.copy(line = Floats.lineAt(host.lineTops, cy))
    else {
        val maxY = (host.textHeight - 40f * host.density).coerceAtLeast(0f)
        p.copy(x = (cx / host.width).coerceIn(0f, (1f - p.width).coerceAtLeast(0f)), y = cy.coerceIn(0f, maxY) / host.density)
    }
    if (next != p) host.onChange(item.key, next, if (item.photo != null) "Photo moved" else "File moved")
}

@Composable
private fun FloatBody(item: FloatItem) {
    val shape = RoundedCornerShape(LocalSb.current.radius)
    val photo = item.photo; val file = item.file
    if (photo != null) AsyncImage(photo, null, Modifier.fillMaxWidth().heightIn(min = 40.dp).clip(shape), contentScale = ContentScale.FillWidth)
    else if (file != null) AttachmentCard(file)
}

/** The frame round the selected object, and the round handle in its bottom right corner that resizes it. */
@Composable
private fun BoxScope.FloatFrame(item: FloatItem, host: FloatHost) {
    val acc = LocalSb.current.acc
    val hostNow by rememberUpdatedState(host)
    val itemNow by rememberUpdatedState(item)
    Box(Modifier.matchParentSize().border(2.dp, acc, RoundedCornerShape(LocalSb.current.radius)))
    Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(30.dp).clip(CircleShape).background(acc)
        .pointerInput(item.key) {
            var startWidth = 0f; var travelled = 0f
            detectDragGestures(onDragStart = { startWidth = itemNow.placed.width; travelled = 0f }) { change, amount ->
                change.consume(); travelled += amount.x
                val p = itemNow.placed
                val w = (startWidth + travelled / hostNow.width.coerceAtLeast(1)).coerceIn(Floats.minWidthOf(itemNow.key), Floats.maxWidthOf(itemNow.key, p))
                if (w != p.width) hostNow.onChange(itemNow.key, p.copy(width = w), if (itemNow.photo != null) "Photo resized" else "File resized")
            }
        }, Alignment.Center) {
        Text("↘", color = androidx.compose.ui.graphics.Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

/** The small bar over (or under) the selected object: how it sits, take it off, done. */
@Composable
private fun FloatBar(item: FloatItem, host: FloatHost) {
    val corner = cornerOf(item.placed, host)
    val h = host.sizes[item.key]?.height ?: 0
    val barH = (46f * host.density).roundToInt(); val gap = (6f * host.density).roundToInt()
    val above = corner.y - barH - gap
    val y = if (above >= 0) above else corner.y + h + gap
    val shape = RoundedCornerShape(23.dp)
    Row(Modifier.offset { IntOffset(0, y) }.fillMaxWidth().clip(shape).background(Sb.menu).border(1.dp, Sb.menuLine, shape).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        BarButton("In line", false, false) { host.onMode(item.key, Placing.Inline) }
        BarButton("Wrap", item.placed.how == Placing.Wrap, false) { host.onMode(item.key, Placing.Wrap) }
        BarButton("Free", item.placed.how == Placing.Free, false) { host.onMode(item.key, Placing.Free) }
        if (host.editing) BarButton("Remove", false, true) { host.onRemove(item.key) }
        BarButton("Done", false, false) { host.onSelect(null) }
    }
}

@Composable
private fun RowScope.BarButton(label: String, on: Boolean, danger: Boolean, onClick: () -> Unit) {
    val acc = LocalSb.current.acc
    Text(label, Modifier.weight(1f).tap(label, onClick).padding(vertical = 13.dp), textAlign = TextAlign.Center, maxLines = 1,
        color = if (on) acc else if (danger) Sb.danger else Sb.ink, fontSize = 14.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
}
