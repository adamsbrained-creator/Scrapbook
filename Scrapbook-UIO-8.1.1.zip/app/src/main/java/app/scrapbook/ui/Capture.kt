package app.scrapbook.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

/** The box that things shared from Paperback go to. It is made the first time you save one. */
private const val PAPERBACK_BOX = "Paperback"

/** Opened when another app shares text, a link or images to Scrapbook. */
@Composable
fun CaptureScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val inc by vm.incoming.collectAsState()
    val src = inc
    BackHandler(enabled = src != null) { vm.clearIncoming() }
    // Only leave if this screen is still the one on top: after adding to an existing scrap we have already moved on to that scrap.
    if (src == null) { LaunchedEffect(Unit) { if (nav.currentDestination?.route == "capture") nav.popBackStack() }; return }
    val hasImage = src.images.isNotEmpty()
    val kind = classifyShare(src.text, hasImage)
    val initial = remember(src) { shareTitle(src.subject, src.text, hasImage) }
    var title by remember(src) { mutableStateOf(initial) }
    var body by remember(src) { mutableStateOf(src.text) }
    val fromPaperback = "readest://" in src.text
    var shelf by remember(src) { mutableStateOf(if (fromPaperback) PAPERBACK_BOX else "Inbox") }
    var img by remember(src) { mutableStateOf<String?>(null) }
    LaunchedEffect(src) { if (isUrl(src.text) && src.subject.isBlank()) vm.fetchTitle(src.text.trim()) { t2 -> if (title == initial) title = t2 } }
    LaunchedEffect(src) { src.images.firstOrNull()?.let { u -> vm.importImage(u) { p -> img = p } } }
    // Files (a PDF, a zip...) shared in are copied into the app first; Save waits until every one has been tried.
    val ctx = LocalContext.current
    var attached by remember(src) { mutableStateOf(emptyList<Attachment>()) }
    var filesDone by remember(src) { mutableIntStateOf(0) }
    LaunchedEffect(src) {
        src.files.forEach { u ->
            vm.importFile(u, failed = { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); filesDone++ }) { a ->
                attached = attached + a; filesDone++
                // A file shared with no words of its own is titled after the file.
                if (title == initial && src.text.isBlank() && src.subject.isBlank()) title = titleFromFileName(a.name)
            }
        }
    }
    val ready = (!hasImage || img != null) && filesDone >= src.files.size

    val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    // Instead of a new scrap, the shared things can go into a scrap that already exists (for example a "Files" scrap that holds your zips).
    var addToExisting by remember(src) { mutableStateOf(false) }
    var target by remember(src) { mutableStateOf<Item?>(null) }
    var query by remember(src) { mutableStateOf("") }
    var adding by remember(src) { mutableStateOf(false) }
    val allScraps by vm.items.collectAsState()
    fun addToTarget() {
        val tg = target ?: return
        if (!ready || adding) return
        adding = true
        vm.addSharedToScrap(tg.id, body, img, src.images.drop(1), attached) { ok ->
            if (ok) {
                // Open the scrap so you see the result. Everything above Home is dropped, so no editor left underneath can later save an old copy over it.
                nav.navigate("item/${tg.id}") { popUpTo("home") }
                vm.clearIncoming()
            } else { adding = false; Toast.makeText(ctx, "That scrap is no longer there.", Toast.LENGTH_SHORT).show() }
        }
    }
    fun save() {
        if (addToExisting) { addToTarget(); return }
        if (!ready) return
        if (shelf == PAPERBACK_BOX && !vm.boxExists(PAPERBACK_BOX)) vm.saveShelf(Shelf(PAPERBACK_BOX, "Quotes and notes from my books.", 0))
        val color = (System.currentTimeMillis() % 5).toInt() + 1
        vm.save(Item(title = title.ifBlank { "Untitled" }, body = body, kind = kind, collection = shelf, imageUri = img, color = 0, files = attached.encodeAll()))
        src.images.drop(1).forEach { u ->
            vm.importImage(u) { p -> vm.save(Item(title = title.ifBlank { "Shared image" }, body = "", kind = Kind.Image, collection = shelf, imageUri = p, color = color - 1)) }
        }
        vm.clearIncoming()
    }

    Scaffold(containerColor = t.paper) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad).imePadding()) {
            ScreenHeader({ vm.clearIncoming() }, title = "Save to Scrapbook", backIcon = "close", backDesc = "Cancel")
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 16.dp)) {
                Text(kind.label + (if (src.images.size > 1) " · ${src.images.size} images" else "") + (if (src.files.isNotEmpty()) " · " + (if (src.files.size == 1) "1 file" else "${src.files.size} files") else ""), Modifier.clip(CircleShape).background(Sb.card).padding(horizontal = 14.dp, vertical = 7.dp),
                    fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
                Spacer(Modifier.height(14.dp))
                if (!addToExisting) Field(title, { title = it }, "Title", 26.sp, headFont(), FontWeight.Medium)
                else {
                    val tg = target
                    if (tg != null) {
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Sb.card).tap("Choose another scrap") { target = null }.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Adding to", fontSize = 12.sp, color = Sb.mute)
                                Text(tg.displayTitle.ifBlank { "Untitled" }, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 18.sp, color = Sb.ink, maxLines = 1)
                                Text(shelves.displayName(tg.collection), fontSize = 12.sp, color = Sb.mute, maxLines = 1)
                            }
                            Text("Change", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = accentText(t.acc))
                        }
                    } else {
                        Field(query, { query = it }, "Search your scraps…", 20.sp, headFont(), FontWeight.Medium)
                        Spacer(Modifier.height(8.dp))
                        val q = query.trim()
                        val matches = remember(allScraps, q) { allScraps.filter { q.isEmpty() || it.displayTitle.contains(q, true) || it.body.contains(q, true) }.take(40) }
                        if (matches.isEmpty()) Text("No scraps match.", fontSize = 14.sp, color = Sb.mute, modifier = Modifier.padding(vertical = 8.dp))
                        matches.forEach { n ->
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).tap("Add to ${n.displayTitle}") { target = n }.padding(horizontal = 4.dp, vertical = 10.dp)) {
                                Text(n.displayTitle.ifBlank { "Untitled" }, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, color = Sb.ink, maxLines = 1)
                                Text(shelves.displayName(n.collection) + if (n.pinned) " · pinned" else "", fontSize = 12.sp, color = Sb.mute, maxLines = 1)
                            }
                        }
                    }
                }
                if (img != null) {
                    Spacer(Modifier.height(12.dp))
                    ItemImage(Item(title = "", body = "", kind = kind, collection = shelf, imageUri = img), Modifier.fillMaxWidth().height(180.dp), 24.dp)
                }
                if (attached.isNotEmpty()) AttachmentList(attached, Modifier.padding(top = 12.dp))
                Spacer(Modifier.height(12.dp))
                Field(body, { body = it }, if (addToExisting) "Text to add (optional)…" else "Write something…", 17.sp, headFont())
            }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(Sb.card).padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 16.dp)) {
                SheetLabel("Save as", start = 2.dp)
                Row(Modifier.padding(top = 6.dp), Arrangement.spacedBy(8.dp)) {
                    SoftChip("New scrap", !addToExisting, container = Sb.paper) { addToExisting = false }
                    SoftChip("Add to a scrap", addToExisting, container = Sb.paper) { addToExisting = true }
                }
                if (!addToExisting) {
                    SheetLabel("Save in", start = 2.dp)
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), Arrangement.spacedBy(8.dp)) {
                        SoftChip("Inbox", shelf == "Inbox", container = Sb.paper, dot = if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) { shelf = "Inbox" }
                        if (fromPaperback && shelves.none { it.name == PAPERBACK_BOX }) SoftChip(PAPERBACK_BOX, shelf == PAPERBACK_BOX, container = Sb.paper) { shelf = PAPERBACK_BOX }
                        shelves.forEach { sh -> SoftChip(shelves.displayName(sh.name), shelf == sh.name, container = Sb.paper, dot = TAB_COLORS[sh.color % TAB_COLORS.size]) { shelf = sh.name } }
                    }
                }
                val canSave = ready && (!addToExisting || (target != null && !adding))
                Text(when { !ready -> "Preparing…"; addToExisting && target == null -> "Choose a scrap above"; addToExisting -> "Add to scrap"; else -> "Save" },
                    Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(28.dp)).background(Sb.ink.copy(alpha = if (canSave) 1f else .35f))
                    .tap("Save") { save() }.padding(vertical = 16.dp),
                    color = Sb.card, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            }
        }
    }
}
