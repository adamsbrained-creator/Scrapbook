package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.Toast
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import app.scrapbook.*
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** The first page of a PDF as a small picture, and how many pages it has. */
private class PdfPreview(val page: ImageBitmap, val pages: Int)

/** A few recent previews, so scrolling back to a note does not draw them again. */
private val pdfCache = android.util.LruCache<String, PdfPreview>(16)

/** Draws page one at [widthPx] wide with Android's own PDF renderer. Null if the file cannot be read (damaged, or locked with a password). */
private fun renderPdf(file: File, widthPx: Int): PdfPreview? = try {
    val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    try {
        val r = PdfRenderer(fd)
        try {
            val pages = r.pageCount
            if (pages == 0) null else {
                val page = r.openPage(0)
                try {
                    val h = (widthPx * page.height.toFloat() / page.width).toInt().coerceIn(1, widthPx * 3)
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    PdfPreview(bmp.asImageBitmap(), pages)
                } finally { page.close() }
            }
        } finally { r.close() }
    } finally { fd.close() }
} catch (e: Throwable) { null }

@Composable
private fun pdfPreview(a: Attachment): PdfPreview? {
    val state = produceState<PdfPreview?>(pdfCache.get(a.path), a.path) {
        if (value == null) value = withContext(Dispatchers.IO) { renderPdf(a.file(), 220)?.also { pdfCache.put(a.path, it) } }
    }
    return state.value
}

private fun uriFor(ctx: Context, a: Attachment) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", a.file())

/** Opens the file in whatever app on the phone can show it. If there is none, offers to send it somewhere instead (Files, Drive...). */
fun openAttachment(ctx: Context, a: Attachment) {
    if (!a.file().exists()) { Toast.makeText(ctx, "This file is no longer on the phone.", Toast.LENGTH_SHORT).show(); return }
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(ctx, a), a.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(view) }
    catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app here can open this file. Choose where to send it instead.", Toast.LENGTH_LONG).show()
        shareAttachment(ctx, a)
    }
}

/** The share sheet for the file, so it can be saved to Files, sent to a friend, and so on. */
fun shareAttachment(ctx: Context, a: Attachment) {
    if (!a.file().exists()) { Toast.makeText(ctx, "This file is no longer on the phone.", Toast.LENGTH_SHORT).show(); return }
    val stored = a.file(); val wanted = diskName(a.name)
    if (stored.name == wanted) { sendFile(ctx, a, stored); return }
    // Renamed: another app sees the name the stored copy has, so a copy under the new name is what gets shared (made off the main thread; files can be big).
    Thread {
        val copy = try { File(File(ctx.cacheDir, "shared").apply { deleteRecursively(); mkdirs() }, wanted).also { stored.copyTo(it, overwrite = true) } } catch (e: Exception) { null }
        Handler(Looper.getMainLooper()).post { if (copy != null) sendFile(ctx, a, copy) else Toast.makeText(ctx, "This file could not be shared.", Toast.LENGTH_SHORT).show() }
    }.start()
}

private fun sendFile(ctx: Context, a: Attachment, file: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).setType(a.mime.ifBlank { "*/*" }).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = ClipData.newRawUri(a.name, uri)
        ctx.startActivity(Intent.createChooser(send, a.name))
    } catch (e: Exception) {
        Toast.makeText(ctx, "This file could not be shared.", Toast.LENGTH_SHORT).show()
    }
}

/** The small picture at the left of a card: page one for a PDF, the picture itself for an image, otherwise the file type in the accent color. */
@Composable
private fun AttachmentThumb(a: Attachment, pdf: PdfPreview?, playing: Boolean = false) {
    // A sound button and a file-type badge are plain circles. A page or a picture keeps its portrait shape, with corners that follow the card's:
    // the card has 28dp corners and the thumbnail sits 10dp inside it, so 18dp makes them line up.
    val t = LocalSb.current; val shape = RoundedCornerShape(18.dp)
    val m = Modifier.size(52.dp, 68.dp).clip(shape)
    when {
        a.isAudio -> Box(Modifier.size(56.dp).clip(CircleShape).background(t.acc.copy(alpha = .16f)), Alignment.Center) { Ic(if (playing) "pause" else "play", 26.dp, accentText(t.acc)) }
        pdf != null -> Image(pdf.page, null, m.background(Color.White).border(1.dp, Sb.line, shape), alignment = Alignment.TopCenter, contentScale = ContentScale.Crop)
        a.isImage -> AsyncImage(a.path, a.name, m, contentScale = ContentScale.Crop)
        else -> Box(Modifier.size(56.dp).clip(CircleShape).background(t.acc.copy(alpha = .16f)), Alignment.Center) { Text(a.typeLabel, color = accentText(t.acc), fontWeight = FontWeight.Bold, fontSize = 13.sp) }
    }
}

/**
 * One attached file: a thumbnail, its name, and what it is (type, pages for a PDF, size). Tap opens it (a sound plays right in the card), and holding it opens the share sheet (in the editor, the reading page and the save screen alike).
 * The ⋮ at the right opens Rename (where the screen allows it), Share and, in the editor, Remove.
 */
@Composable
fun AttachmentCard(a: Attachment, onRemove: (() -> Unit)? = null, player: AudioPlayer? = null, onDrag: (() -> Unit)? = null, onFloat: ((Placing) -> Unit)? = null) {
    val ctx = LocalContext.current; val t = LocalSb.current; val haptic = LocalHapticFeedback.current
    val rename = LocalAttachmentRename.current   // set by a screen that can rename (and shows the box for it): the editor and the reading page
    val missing = remember(a.path) { !a.file().exists() }
    val pdf = if (a.isPdf && !missing) pdfPreview(a) else null
    // A sound plays right here: tap to play or pause, with a bar to move around in it while it is the one playing.
    val sound = if (a.isAudio && !missing) player else null
    val length by produceState(0L, a.path) { if (a.isAudio) value = withContext(Dispatchers.IO) { Recordings.durationMs(a.file()) } }
    val active = sound != null && sound.loadedKey == a.path
    val sub = buildList {
        add(a.typeLabel)
        if (pdf != null) add(if (pdf.pages == 1) "1 page" else "${pdf.pages} pages")
        if (a.isAudio && length > 0) add(if (sound != null && active) formatDuration(sound.position.toLong()) + " / " + formatDuration(length) else formatDuration(length))
        add(if (missing) "missing" else formatSize(a.size))
    }.joinToString(" · ")
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card)
            .let { m ->
                val open = { if (sound != null) sound.toggle(a.path, a.file()) else openAttachment(ctx, a) }
                // Holding the card opens its menu when it can be dragged on the page (the menu then starts with Drag); otherwise it goes straight to the share sheet.
                if (onDrag != null) m.tapOrHold(if (sound != null) "Play ${a.name}" else "Open ${a.name}", "Options for ${a.name}", onHold = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); menu = true }) { open() }
                else m.tapOrHold(if (sound != null) "Play ${a.name}" else "Open ${a.name}", "Share ${a.name}", onHold = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); shareAttachment(ctx, a) }) { open() }
            }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AttachmentThumb(a, pdf, sound != null && active && sound.playing)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.name, color = Sb.ink, fontFamily = headFont(), fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Sb.mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            if (sound != null && active && sound.duration > 0) Slider(
                value = sound.position.toFloat().coerceIn(0f, sound.duration.toFloat()), onValueChange = { sound.seek(it.toInt()) }, valueRange = 0f..sound.duration.toFloat(),
                colors = SliderDefaults.colors(thumbColor = t.acc, activeTrackColor = t.acc, inactiveTrackColor = Sb.line), modifier = Modifier.height(28.dp))
        }
        Box {
            Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("More for ${a.name}") { menu = true }, Alignment.Center) { Ic("more", 20.dp, Sb.mute) }
            PopupMenu(menu, { menu = false }) {
                if (onDrag != null) PopupItem("Drag", "sort") { menu = false; onDrag() }
                if (onFloat != null) PopupItem("Wrap text", "alignl", "Text runs beside it") { menu = false; onFloat(Placing.Wrap) }
                if (onFloat != null) PopupItem("Place freely", "expand", "Anywhere, any size") { menu = false; onFloat(Placing.Free) }
                if (rename != null) PopupItem("Rename", "edit") { menu = false; rename(a) }
                PopupItem("Share", "share") { menu = false; shareAttachment(ctx, a) }
                if (onRemove != null) PopupItem("Remove", "trash", tint = Sb.danger) { menu = false; onRemove() }
            }
        }
    }
}

/** A screen that lets a file be renamed provides this: it is told which file was asked for, and shows a RenameSheet. Without it the card has no Rename. */
val LocalAttachmentRename = compositionLocalOf<((Attachment) -> Unit)?> { null }

/** The box that asks for a new name. The file keeps its ending (like .pdf) unless you type one. [onSave] gets the finished name; [onDone] closes the box. */
@Composable
fun RenameSheet(current: String, onSave: (String) -> Unit, onDone: () -> Unit) {
    val t = LocalSb.current; val focus = remember { FocusRequester() }
    // Everything before the ending starts out selected, so typing replaces the name and leaves ".pdf" alone.
    var tf by remember { mutableStateOf(TextFieldValue(current, TextRange(0, current.substringBeforeLast('.', current).length))) }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) { /* the box was not ready yet */ } }
    val newName = renamedFileName(current, tf.text)
    val save = { if (newName != null) { if (newName != current) onSave(newName); onDone() } }
    Sheet("Rename", onDone, doneLabel = "Save", primary = save, enabled = newName != null, subtitle = "The file keeps its ending (like .pdf) unless you type a new one.") {
        InputBox {
            BasicTextField(tf, { tf = it }, Modifier.fillMaxWidth().focusRequester(focus), singleLine = true,
                textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink, fontFamily = headFont()), cursorBrush = SolidColor(t.acc),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { save() }))
        }
    }
}

/** All of a scrap's files, one card each, with a little room between. Nothing is drawn when there are none. */
@Composable
fun AttachmentList(files: List<Attachment>, modifier: Modifier = Modifier, onRemove: ((Attachment) -> Unit)? = null,
                   onDrag: ((Attachment) -> Unit)? = null, onFloat: ((Attachment, Placing) -> Unit)? = null, cardModifier: (Attachment) -> Modifier = { Modifier }) {
    if (files.isEmpty()) return
    // One player for the whole list, so starting one sound stops the one before it.
    val player = if (files.any { it.isAudio }) rememberAudioPlayer() else null
    Column(modifier, Arrangement.spacedBy(8.dp)) {
        files.forEach { a ->
            key(a.path) {
                // [onDrag] puts "Drag" in each card's menu (opened by holding it); [cardModifier] lets the page find the card and fade it while it is carried.
                Box(cardModifier(a)) { AttachmentCard(a, if (onRemove == null) null else ({ onRemove(a) }), player, if (onDrag == null) null else ({ onDrag(a) }), if (onFloat == null) null else ({ how -> onFloat(a, how) })) }
            }
        }
    }
}
