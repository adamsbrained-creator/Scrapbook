package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Shown before anything else if the app crashed last time. Deliberately independent of the rest of the app (no theme, settings or custom fonts),
 * so it still works when those are what broke. It only borrows the app's look: big title, grey cards, round pills.
 */
@Composable
fun CrashScreen(report: String, onShare: () -> Unit, onDismiss: () -> Unit) {
    val dark = isSystemInDarkTheme()
    val paper = if (dark) Color(0xFF0B0B0B) else Color.White
    val card = if (dark) Color(0xFF1C1C1C) else Color(0xFFF3F3F3)
    val ink = if (dark) Color(0xFFF2F2F2) else Color(0xFF1C1C1C)
    val mute = if (dark) Color(0xFF9B9B9B) else Color(0xFF666666)
    Column(Modifier.fillMaxSize().background(paper).systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("Scrapbook closed unexpectedly last time", color = ink, fontSize = 28.sp, lineHeight = 33.sp, fontWeight = FontWeight.Medium)
        Text("Share this report and it can be fixed. Nothing was sent anywhere automatically.", color = mute, fontSize = 15.sp, lineHeight = 21.sp)
        Spacer(Modifier.height(4.dp))
        Text("Share report", Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(ink).clickable(role = Role.Button, onClick = onShare).padding(vertical = 16.dp),
            color = paper, fontSize = 16.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Text("Dismiss and continue", Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(card).clickable(role = Role.Button, onClick = onDismiss).padding(vertical = 16.dp),
            color = ink, fontSize = 16.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Text("REPORT", Modifier.padding(start = 6.dp, top = 12.dp), color = mute, fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp)
        Text(report, Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(card).padding(18.dp), color = ink, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 14.sp)
    }
}
