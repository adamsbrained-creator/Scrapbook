package app.scrapbook.ui

import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf

// Small vibrations that confirm what your finger just did: a task ticked, a scrap pinned, a scrap filed in a box.
// They are only used for things you did on purpose. Never for autosave (that happens while you type) and never for scrolling.
// Android's own "touch feedback" setting still applies: if it is off in the phone's settings, nothing vibrates, whatever Scrapbook says.
// The View constants are used instead of Compose's HapticFeedbackType, which only has two kinds in the Compose version this app uses.

/** One place for every vibration in the app. Use it through [LocalHaptics]. When [enabled] is false (Settings) every call does nothing. */
@Stable
class Haptics(private val view: View?, private val enabled: Boolean) {
    private fun go(constant: Int) { if (enabled) view?.performHapticFeedback(constant) }

    /** The lightest feedback: choosing something, pinning, a switch on older phones. */
    fun tick() = go(HapticFeedbackConstants.CLOCK_TICK)

    /** A switch or a checkbox going on or off. Android 14 and newer have a proper on/off pair; older phones get the light tick. */
    fun toggle(on: Boolean) = go(
        if (Build.VERSION.SDK_INT >= 34) { if (on) HapticFeedbackConstants.TOGGLE_ON else HapticFeedbackConstants.TOGGLE_OFF }
        else HapticFeedbackConstants.CLOCK_TICK
    )

    /** Something finished and landed: a scrap filed in a box, an earlier version brought back. Slightly firmer than [tick]. */
    fun confirm() = go(if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.CONTEXT_CLICK)
}

/** The app-wide vibration helper. The default does nothing, so previews and tests are silent. */
val LocalHaptics = compositionLocalOf { Haptics(null, false) }
