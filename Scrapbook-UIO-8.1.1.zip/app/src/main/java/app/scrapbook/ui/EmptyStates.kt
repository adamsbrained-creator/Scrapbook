package app.scrapbook.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.CoroutineScope

// USEFUL EMPTY STATES
//
// An empty screen offers what you most likely want to do next instead of only describing itself. Everything new lives in this file; the
// existing screens only call into it from five places, each marked with "[empty-states hook N]" so they are easy to find and re-add:
//
//   1. Browse.kt, ShelfScreen: a state line      var movingIn by remember { mutableStateOf(false) }
//   2. Browse.kt, ShelfScreen: where the old "Nothing here yet..." text was, in the LazyColumn:
//        if (shown.isEmpty()) item { ShelfEmpty(vm, nav, name, shelf, subs.isNotEmpty(), query.isNotBlank(), filter.isOn,
//                                               { q = "" }, { filter = ScrapFilter() }, { creatingSub = true }, { movingIn = true }) }
//   3. Browse.kt, ShelfScreen: next to the other sheets:  if (movingIn && shelf != null) MoveInSheet(vm, name, scope, snack) { movingIn = false }
//   4. Home.kt, AllScrapsScreen: where the old "No scraps yet..." text was:
//        if (sorted.isEmpty()) item { AllEmpty(vm, nav, filter.isOn && all.isNotEmpty()) { filter = ScrapFilter() } }
//   5. Browse.kt, SearchScreen: the "N results" line:  item { if (res.isEmpty()) SearchEmpty(q) { q = "" } else Text(...the old count...) }

/** One button of an empty state. */
class EmptyAction(val label: String, val icon: String? = null, val onClick: () -> Unit)

/** The shared look: a round icon, a title, one line of text, a main button and smaller ones under it. */
@Composable
fun EmptyState(icon: String, title: String, text: String, modifier: Modifier = Modifier, tint: Color = Sb.mute, primary: EmptyAction? = null, secondary: List<EmptyAction> = emptyList()) {
    Column(modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(tint.copy(alpha = .16f)), Alignment.Center) { Ic(icon, 30.dp, tint) }
        Text(title, Modifier.padding(top = 8.dp), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, textAlign = TextAlign.Center)
        Text(text, fontSize = 15.sp, lineHeight = 21.sp, color = Sb.mute, textAlign = TextAlign.Center)
        if (primary != null) Row(Modifier.padding(top = 14.dp).pressScale(.96f).clip(RoundedCornerShape(28.dp)).background(Sb.ink).tap(primary.label, primary.onClick)
            .padding(horizontal = 26.dp, vertical = 14.dp), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
            if (primary.icon != null) Ic(primary.icon, 20.dp, Sb.card)
            Text(primary.label, color = Sb.card, fontWeight = FontWeight.Medium, fontSize = 16.sp)
        }
        secondary.forEach { a ->
            Row(Modifier.pressScale(.96f).clip(RoundedCornerShape(22.dp)).background(Sb.card).tap(a.label, a.onClick).padding(horizontal = 18.dp, vertical = 11.dp),
                Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                if (a.icon != null) Ic(a.icon, 18.dp, Sb.mute)
                Text(a.label, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

private val PAGES = setOf("All", "Pinned", "Recent")

/**
 * The empty page of a box, of the Inbox, or of the All / Pinned / Recent pages. With a search or filter on it says nothing matches and offers to clear it;
 * otherwise it offers to write a scrap right here, to move existing ones in (a real box, when there are scraps elsewhere) and to make a box inside.
 */
@Composable
fun ShelfEmpty(vm: ArchiveViewModel, nav: NavController, name: String, shelf: Shelf?, hasSubs: Boolean, searching: Boolean, filtering: Boolean,
               onClearSearch: () -> Unit, onClearFilter: () -> Unit, onNewBox: () -> Unit, onMoveIn: () -> Unit) {
    val all by vm.items.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    val page = name in PAGES; val label = shelf?.label ?: name
    val tint = when {
        shelf != null -> TAB_COLORS[shelf.color.mod(TAB_COLORS.size)]
        name == "Inbox" -> if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]
        else -> Sb.mute
    }
    val elsewhere = all.any { it.collection != name }
    val newScrap = EmptyAction("New scrap", "edit") { vm.pendingShelf = if (shelf != null) name else null; nav.navigate("edit/0") }
    val moveIn = if (shelf != null && elsewhere) EmptyAction("Move scraps in", "folder", onMoveIn) else null
    when {
        searching || filtering -> EmptyState("search", "Nothing matches",
            if (searching && filtering) "No scrap here fits your search and filters." else if (searching) "No scrap here matches your search." else "No scrap here fits the filters.",
            primary = EmptyAction(if (searching) "Clear search" else "Clear filters", "close", if (searching) onClearSearch else onClearFilter),
            secondary = if (searching && filtering) listOf(EmptyAction("Clear filters", "close", onClearFilter)) else emptyList())
        name == "Pinned" -> EmptyState("star", "Nothing pinned yet", "Pin a scrap from its menu, or hold it in a list, and it will wait for you here.")
        hasSubs -> EmptyState("folder", "No scraps directly in $label", "The boxes above hold the rest. You can still write a scrap straight into this one.",
            tint = tint, primary = newScrap, secondary = listOfNotNull(moveIn))
        page -> EmptyState("edit", "No scraps yet", "Write your first scrap, or share something to Scrapbook from another app.", primary = newScrap)
        name == "Inbox" -> EmptyState("folder", "Inbox is empty", "Scraps you write or share into Scrapbook land here until you file them.", tint = tint, primary = newScrap)
        else -> EmptyState("folder", "This box is empty",
            if (elsewhere) "Write a scrap straight into $label, or move some in from your other boxes." else "Write a scrap straight into $label.",
            tint = tint, primary = newScrap, secondary = listOfNotNull(moveIn, if (shelf != null) EmptyAction("New box inside", "plus", onNewBox) else null))
    }
}

/** The empty All scraps page: nothing matches the filters, or no scrap has been written yet. */
@Composable
fun AllEmpty(vm: ArchiveViewModel, nav: NavController, filtering: Boolean, onClearFilter: () -> Unit) {
    if (filtering) EmptyState("search", "Nothing matches", "No scrap fits these filters.", primary = EmptyAction("Clear filters", "close", onClearFilter))
    else EmptyState("edit", "No scraps yet", "Write your first scrap, or share something to Scrapbook from another app.",
        primary = EmptyAction("New scrap", "edit") { vm.pendingShelf = null; nav.navigate("edit/0") })
}

/** A search that found nothing. */
@Composable
fun SearchEmpty(query: String, onClear: () -> Unit) =
    EmptyState("search", "No results", "Nothing matches “${query.trim()}”. Try fewer words, check the spelling, or remove a type filter.", primary = EmptyAction("Clear search", "close", onClear))

/** The round pick mark of the Move scraps in list: a ring, or the accent color filled with a check. */
@Composable
private fun PickDot(on: Boolean) {
    val acc = LocalSb.current.acc; val tick = if (acc.luminance() > .5f) Color(0xFF1A1A1A) else Color.White
    Canvas(Modifier.size(22.dp)) {
        val sw = 1.6.dp.toPx(); val r = size.minDimension / 2f; val d = size.minDimension
        if (on) {
            drawCircle(acc, r)
            val p = Path().apply { moveTo(d * .27f, d * .52f); lineTo(d * .43f, d * .68f); lineTo(d * .74f, d * .34f) }
            drawPath(p, tick, style = Stroke(width = sw * 1.15f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        } else drawCircle(Sb.mute, r - sw / 2f, style = Stroke(sw))
    }
}

/** At most this many scraps are listed at once in Move scraps in; searching narrows the rest. */
private const val MOVE_IN_LIMIT = 60

/**
 * Pick scraps from your other boxes (the Inbox first) and move them into [box]. The move can be undone from the snackbar on the box page, like any move.
 */
@Composable
fun MoveInSheet(vm: ArchiveViewModel, box: String, scope: CoroutineScope, snack: SnackbarHostState, onDone: () -> Unit) {
    val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    var q by remember { mutableStateOf("") }; var picked by remember { mutableStateOf(emptySet<Long>()) }
    val word = q.trim()
    val pool = remember(all, box, word) {
        all.filter { it.collection != box && (word.isEmpty() || it.title.contains(word, true) || it.body.contains(word, true)) }
            .sortedBy { if (it.collection == "Inbox") 0 else 1 }   // stable: the Inbox comes first, each group keeps its usual order
    }
    val shown = pool.take(MOVE_IN_LIMIT)
    val count = picked.size
    Sheet("Move scraps in", onDone, if (count == 0) "Pick scraps to move" else if (count == 1) "Move 1 scrap here" else "Move $count scraps here",
        primary = { batchMove(vm, all.filter { it.id in picked }, box, scope, snack); onDone() }, enabled = count > 0, subtitle = "Into ${shelves.labelOf(box)}") {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Sb.card).padding(horizontal = 14.dp, vertical = 12.dp), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
            Ic("search", 20.dp, Sb.mute)
            BasicTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(Sb.ink),
                decorationBox = { inner -> Box { if (q.isEmpty()) Text("Search your scraps", color = Sb.mute, fontSize = 16.sp); inner() } })
        }
        if (shown.isEmpty()) SheetNote(if (word.isEmpty()) "There are no other scraps to move in." else "No scrap matches that.")
        else SheetGroup {
            shown.forEachIndexed { i, n ->
                if (i > 0) SheetDivider(52.dp)
                val on = n.id in picked
                Row(Modifier.fillMaxWidth().tap(if (on) "Unselect ${n.title}" else "Select ${n.title}") { picked = if (on) picked - n.id else picked + n.id }
                    .padding(horizontal = 16.dp, vertical = 12.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                    PickDot(on)
                    Column(Modifier.weight(1f)) {
                        Text(n.title.ifBlank { "Untitled" }, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("From ${shelves.labelOf(n.collection.ifBlank { "Inbox" })}", fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        if (pool.size > MOVE_IN_LIMIT) SheetNote("Showing the first $MOVE_IN_LIMIT. Search to narrow it down.")
    }
}
