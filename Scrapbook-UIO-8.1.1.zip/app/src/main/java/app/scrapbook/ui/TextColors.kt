package app.scrapbook.ui

import androidx.compose.runtime.compositionLocalOf

/**
 * Where the accent color shows up inside a scrap's text, from Settings. By default list marks (bullets, checkboxes, quote bars) have the normal text
 * color, so they look like the rest of the text and follow it when the text is colored; links and #hashtags use the accent color.
 * [hashtagsOn] is the separate switch that turns #words into tags: when it is off they are not colored at all.
 */
data class TextColors(val marksAccent: Boolean = false, val linksAccent: Boolean = true, val hashtagsAccent: Boolean = true, val hashtagsOn: Boolean = true) {
    val colorHashtags: Boolean get() = hashtagsOn && hashtagsAccent
}

val LocalTextColors = compositionLocalOf { TextColors() }
