package app.scrapbook.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

/** Keeps a screen's filter across a rotation or the app being rebuilt. */
val ScrapFilterSaver = Saver<ScrapFilter, String>(save = { it.encode() }, restore = { decodeFilter(it) })

/** The pill that opens the filter sheet: "Filter", or "Filter · 2" with how many kinds of filter are on. */
@Composable
fun FilterButton(filter: ScrapFilter, onClick: () -> Unit) {
    val on = filter.isOn
    Row(Modifier.heightIn(min = 44.dp).clip(CircleShape).background(if (on) Sb.ink else Sb.card).tap(if (on) "Filter, ${filter.count} on" else "Filter", onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Ic("sliders", 18.dp, if (on) Sb.card else Sb.mute); Spacer(Modifier.width(8.dp))
        Text(if (on) "Filter · ${filter.count}" else "Filter", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (on) Sb.card else Sb.ink, maxLines = 1)
    }
}

/**
 * Type, box, tags and date in one sheet. [items] are the scraps the list is made from (the tags offered are the ones they use), [boxes] the boxes to
 * choose from (null inside a box, where it would be pointless), and [count] how many scraps pass right now, shown on the big button.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FilterSheet(filter: ScrapFilter, onChange: (ScrapFilter) -> Unit, items: List<Item>, boxes: List<String>?, count: Int, onDone: () -> Unit) {
    val tags = remember(items) { tagCounts(items) }
    Sheet("Filter", onDone, doneLabel = if (count == 1) "Show 1 scrap" else "Show $count scraps",
        subtitle = if (filter.isOn) "${filter.count} on" else "Narrow the list down") {
        SheetLabel("Type")
        FlowRow(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Arrangement.spacedBy(8.dp)) {
            SoftChip("All", filter.kind == null) { onChange(filter.copy(kind = null)) }
            Kind.entries.forEach { k -> SoftChip(k.label + "s", filter.kind == k) { onChange(filter.copy(kind = k)) } }
        }
        if (boxes != null) {
            SheetLabel("Box")
            FlowRow(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Arrangement.spacedBy(8.dp)) {
                SoftChip("Any box", filter.box == null) { onChange(filter.copy(box = null)) }
                boxes.forEach { b -> SoftChip(LocalShelves.current.displayName(b), filter.box == b) { onChange(filter.copy(box = b)) } }
            }
        }
        SheetLabel("Tags")
        if (tags.isEmpty()) SheetNote("No tags yet. Add some in a scrap's Details.") else {
            FlowRow(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Arrangement.spacedBy(8.dp)) {
                tags.forEach { (name, n) -> SoftChip("$name  $n", filter.hasTag(name)) { onChange(filter.toggleTag(name)) } }
            }
            if (filter.tags.size > 1) SheetNote("Scraps need all of the chosen tags.")
        }
        SheetLabel("Date")
        FlowRow(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Arrangement.spacedBy(8.dp)) {
            DateRange.entries.forEach { r -> SoftChip(r.label, filter.range == r) { onChange(filter.copy(range = r)) } }
        }
        if (filter.range != DateRange.AnyTime) {
            Spacer(Modifier.height(10.dp))
            Seg(DateField.entries.map { it.label }, filter.field.ordinal) { onChange(filter.copy(field = DateField.entries[it])) }
        }
        if (filter.isOn) { Spacer(Modifier.height(14.dp)); SoftChip("Clear all filters") { onChange(ScrapFilter()) } }
        Spacer(Modifier.height(6.dp))
    }
}
