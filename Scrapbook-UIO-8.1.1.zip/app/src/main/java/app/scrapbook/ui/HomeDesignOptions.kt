package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// The options page of a part of Home, opened from the sliders button on its row in Customize home. Same shape as the greeting's page: a preview stays on top while the
// choices scroll, so a choice can be seen at once. Parts with more than one design (Capture, Continue, Boxes, Pinned, Recent) get a Design section; every design choice is
// optional: a part keeps its classic look until one is picked, and "Back to the classic look" undoes all of them. A part can also bring its own settings through [extras]
// (the header's layout and size, the add button, the order of the boxes): these used to be in Settings and live next to the part they change. The greeting keeps its own
// page (GreetingOptions.kt), which uses [DesignPicker] for its style and picture side.

/** One choice shown as a card: its name, the options as a segmented control, and an optional line saying what the chosen option looks like. */
@Composable
fun ChoiceCard(title: String, options: List<String>, selected: Int, hint: String?, onSelect: (Int) -> Unit) {
    SettingsCard {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
            Seg(options, selected.coerceIn(0, options.lastIndex), onSelect)
            if (hint != null) Text(hint, fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
        }
    }
}

/** One choice of design of a part. */
@Composable
fun DesignPicker(k: HomeStyleKey, styles: HomeStyles, onStyles: (HomeStyles) -> Unit) {
    ChoiceCard(k.label, k.options, styles[k], k.hints[styles[k]]) { i -> onStyles(styles.with(k, i)) }
}

/** Which choices of a part apply right now: the card size only means something for pinned cards in a row. */
fun designKeys(el: HomeElement, styles: HomeStyles): List<HomeStyleKey> =
    HomeStyleKey.forElement(el).filter { k -> !(k == HomeStyleKey.PinnedSize && styles[HomeStyleKey.PinnedStyle] != 0) }

/** The small grey line under a group of settings. */
@Composable
fun HomeFooter(text: String) {
    Text(text, Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp), fontSize = 12.sp, lineHeight = 17.sp, color = Sb.mute)
}

/**
 * [extras] adds a part's own settings under its designs; it is handed a function that opens a picker sheet over the page. [preview] shows the real part with your own scraps,
 * only to look at: a layer over it blocks taps.
 */
@Composable
internal fun HomeDesignOptions(
    el: HomeElement, styles: HomeStyles, onStyles: (HomeStyles) -> Unit, onBack: () -> Unit,
    extras: @Composable ColumnScope.((SettingPick) -> Unit) -> Unit = {}, preview: @Composable () -> Unit,
) {
    var pick by remember { mutableStateOf<SettingPick?>(null) }
    BackHandler { onBack() }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                CircleBtn("Back to Customize home", onBack) { Ic("back", 22.dp, Sb.ink) }
                Text(el.label, Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
            }
            Spacer(Modifier.height(10.dp))
            SettingsCard {
                Box(Modifier.fillMaxWidth().heightIn(max = 300.dp).padding(vertical = 14.dp)) {
                    preview()
                    Box(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { } })
                }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
                val keys = designKeys(el, styles)
                if (keys.isNotEmpty()) {
                    SectionLabel("Design")
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { keys.forEach { k -> DesignPicker(k, styles, onStyles) } }
                    HomeFooter("Optional. ${el.label} keeps its classic look until you choose another one.")
                    if (!styles.isDefault(el)) {
                        Spacer(Modifier.height(10.dp))
                        SettingsCard { IconRow("undo", "Back to the classic look", "") { onStyles(styles.reset(el)) } }
                    }
                }
                extras { p -> pick = p }
            }
        }
        pick?.let { p -> PickerSheet(p) { pick = null } }
    }
}
