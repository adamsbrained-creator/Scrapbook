package app.scrapbook.ui

import androidx.compose.ui.graphics.isSpecified
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.scrapbook.CustomColors

// The free color picker shared by the page color, the page accent and the app accent: a round "rainbow" choice among the ready-made ones,
// and under it two bars (the same two the text color panel in the editor has). The colors themselves live in Colors.kt.

private val RAINBOW = listOf(Color(0xFFFF3B30), Color(0xFFFFCC00), Color(0xFF34C759), Color(0xFF00C7BE), Color(0xFF0A84FF), Color(0xFFBF5AF2), Color(0xFFFF3B30))

/** The round choice that opens the color bars. A rainbow while no color of your own is chosen; the chosen color (with a check) when one is. */
@Composable
fun RgbDot(rgb: Int?, onClick: () -> Unit, size: Dp = 34.dp, checkColor: Color = Color.Unspecified) {
    val on = rgb != null
    val fill = if (rgb != null) Modifier.background(rgbColor(rgb)) else Modifier.background(Brush.sweepGradient(RAINBOW))
    Box(Modifier.size(size).clip(CircleShape).then(fill).border(if (on) 2.5.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape)
        .tapIcon("Custom color", onClick).semantics { selected = on }, Alignment.Center) {
        if (on) Ic("check", 18.dp, if (checkColor.isSpecified) checkColor else rgb?.let { onAccent(rgbColor(it)) } ?: Color.White)
    }
}

/**
 * Two bars: the hue, and light to dark. [onLive] reports the color while a finger is dragging (to show it right away), [onCommit] when the finger lifts
 * (to save it, so a drag does not save a hundred times). [startRgb] puts the bars where that color is.
 */
@Composable
fun RgbSliders(startRgb: Int?, onLive: (Int) -> Unit, onCommit: (Int) -> Unit, modifier: Modifier = Modifier) {
    val start = remember { CustomColors.toHueShade(startRgb ?: CustomColors.START_RGB) }
    var hue by remember { mutableFloatStateOf(start.first) }; var shade by remember { mutableFloatStateOf(start.second) }
    fun now() = CustomColors.fromHueShade(hue, shade)
    fun at(h: Float, t: Float) = rgbColor(CustomColors.fromHueShade(h, t))
    Column(modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
        GradientSlider(hue / 360f, Brush.horizontalGradient(listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { at(it % 360f, .5f) }), at(hue, .5f),
            { hue = it * 360f; onLive(now()) }, { onCommit(now()) })
        GradientSlider(shade, Brush.horizontalGradient(listOf(Color.Black, at(hue, .5f), Color.White)), at(hue, shade),
            { shade = it; onLive(now()) }, { onCommit(now()) })
    }
}
