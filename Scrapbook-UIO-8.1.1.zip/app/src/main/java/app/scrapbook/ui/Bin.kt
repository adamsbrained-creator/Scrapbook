package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

/** "12 days left", or "Last day" for the final one. */
private fun daysLeftLabel(n: Item, now: Long): String = binDaysLeft(n.deletedAt, now).let { if (it <= 1) "Last day" else "$it days left" }

/** One deleted scrap: its title, a short preview, and which box it came from and how long it stays. */
@Composable
private fun BinRow(n: Item, now: Long, onClick: () -> Unit) {
    val preview = plainPreview(bodyWithoutTitle(n.title, n.body)); val shelves = LocalShelves.current
    Column(Modifier.pressScale(.98f).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Open ${n.title}", onClick)
        .padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(n.displayTitle.ifBlank { "Untitled" }, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (preview.isNotBlank()) Text(preview, fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("${shelves.displayName(n.collection.ifBlank { "Inbox" })} · ${daysLeftLabel(n, now)}", Modifier.padding(top = 4.dp), fontSize = 12.5.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** The Bin: deleted scraps wait here for BIN_DAYS days. Tap one to restore it or delete it for good; the button at the top right empties the Bin. */
@Composable
fun BinScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val bin by vm.bin.collectAsState(); val shelves by vm.shelves.collectAsState()
    var open by remember { mutableStateOf<Item?>(null) }; var confirmEmpty by remember { mutableStateOf(false) }
    val now = remember { System.currentTimeMillis() }
    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.paper) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
                ScreenHeader({ nav.popBackStack() }, title = "Bin", trailing = {
                    if (bin.isEmpty()) Spacer(Modifier.size(44.dp)) else CircleBtn("Empty the Bin", { confirmEmpty = true }) { Ic("trash", 22.dp, Sb.ink) }
                })
                if (bin.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 40.dp), Alignment.Center) {
                        Text("The Bin is empty.\nDeleted scraps wait here for $BIN_DAYS days before they are gone for good.", textAlign = TextAlign.Center, fontSize = 15.sp, lineHeight = 21.sp, color = Sb.mute)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item { Text("Deleted scraps stay here for $BIN_DAYS days. Tap one to restore it or delete it for good.", Modifier.padding(horizontal = 4.dp, vertical = 4.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute) }
                        items(bin, key = { it.id }) { n -> BinRow(n, now) { open = n } }
                    }
                }
            }
        }
        open?.let { n ->
            val back = if (n.collection.isNotBlank() && (n.collection == "Inbox" || shelves.any { it.name == n.collection })) n.collection else "Inbox"
            Sheet(n.title.ifBlank { "Untitled" }.let { if (it.length > 40) it.take(40) + "…" else it }, { open = null }, doneLabel = "Cancel", soft = true) {
                val preview = plainPreview(bodyWithoutTitle(n.title, n.body), "\n").take(400)
                if (preview.isNotBlank()) SheetNote(preview)
                SheetGroup {
                    ActionRow("undo", "Restore", sub = if (back == n.collection) "Back in ${shelves.displayName(back)}" else "Its box was deleted, so it goes to Inbox") { vm.restoreFromBin(n.id); open = null }
                    SheetDivider(56.dp)
                    ActionRow("trash", "Delete forever", sub = "This can't be undone", danger = true) { vm.deleteForever(n.id); open = null }
                }
            }
        }
        if (confirmEmpty) Sheet("Empty the Bin?", { confirmEmpty = false }, doneLabel = "Cancel", soft = true) {
            SheetNote((if (bin.size == 1) "1 scrap" else "${bin.size} scraps") + " will be deleted for good. This can't be undone.")
            SheetGroup { ActionRow("trash", "Delete forever", danger = true) { vm.emptyBin(); confirmEmpty = false } }
        }
    }
}
