package app.scrapbook.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** "Today · 3:05 PM", "Yesterday · 9:40 AM", then "Oct 12 · 4:10 PM". */
internal fun whenText(ms: Long): String {
    val d = Date(ms); val day = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
    val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(d)
    return when (day.format(d)) {
        day.format(Date()) -> "Today · $time"
        day.format(Date(System.currentTimeMillis() - 86_400_000L)) -> "Yesterday · $time"
        else -> SimpleDateFormat("MMM d · h:mm a", Locale.getDefault()).format(d)
    }
}

@Composable
private fun VersionRow(v: ItemVersion, onClick: () -> Unit) {
    val words = v.body.split(Regex("\\s+")).count { it.isNotBlank() }
    val preview = plainPreview(bodyWithoutTitle(v.title, v.body), " · ").ifBlank { v.title.ifBlank { "Empty" } }
    Column(Modifier.pressScale(.98f).fillMaxWidth().tap("Bring back this version", onClick).padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("${whenText(v.savedAt)} · $words ${if (words == 1) "word" else "words"}", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
        Text(preview, fontSize = 15.sp, lineHeight = 20.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

/** The earlier texts of a scrap, newest first. Tapping one brings it back (the editor keeps the current text as a version first, and Undo works too). */
@Composable
fun VersionsSheet(versions: List<ItemVersion>, onRestore: (ItemVersion) -> Unit, onClose: () -> Unit) =
    Sheet("Version history", onClose, doneLabel = "Close", soft = true, subtitle = if (versions.isEmpty()) null else "Tap one to bring it back") {
        if (versions.isEmpty()) SheetNote("Nothing here yet. Earlier texts are kept automatically while you edit: about every five minutes, and whenever a big chunk of text disappears.")
        else {
            SheetGroup {
                versions.forEachIndexed { i, v ->
                    if (i > 0) SheetDivider()
                    VersionRow(v) { onRestore(v); onClose() }
                }
            }
            SheetNote("The text you have now is kept as a version too, so bringing one back can be taken back.")
        }
    }
