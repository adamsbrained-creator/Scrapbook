package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import app.scrapbook.*

// SCRAPBOOK <-> BINDER, the Android side. The rules and the message formats are in Binder.kt. Everything here sends one intent to Binder
// and says so plainly when Binder is not installed. The rest of the app touches this from marked hook lines ("[binder hook N]"):
//
//   1. MainActivity.kt: handleLink (a scrapbook:// link from Binder, with the Binder part), handleBinder (Binder asks for a new scrap)
//      and the effect that opens the new scrap in the editor (vm.editRequest)
//   2. ArchiveViewModel.kt: editRequest, createFromBinder, linkBack
//   3. Editor.kt ("Share & copy" menu page) and Pages.kt (reading view menu):  BinderMenuRows(uid, title, body) { menu = false }
//   4. Browse.kt, the box's more-menu:  BinderBoxItem(title, scrapsInThisBox) { more = false }
//   5. Pages.kt / Markup.kt / OpenLink.kt: binder:// is a link scheme, like readest:// and scrapbook://

private fun toBinder(ctx: Context, action: String, fill: Intent.() -> Unit) {
    val i = Intent(action).setClassName(BINDER_PACKAGE, BINDER_ACTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).apply(fill)
    try { ctx.startActivity(i) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Binder isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/** Asks Binder to put this scrap in one of its binds. Binder lets you pick the bind, then brings you back here with a link to the new item added. */
fun addToBinder(ctx: Context, uid: String, title: String, body: String) = toBinder(ctx, ACTION_BINDER_ADD) {
    putExtra("title", title.ifBlank { "Untitled" }); putExtra("note", binderNoteOf(title, body)); putExtra("scrap", uid)
}

/** Asks Binder to make a checklist bind from these lines (text, ticked). */
fun checklistToBinder(ctx: Context, name: String, items: List<Pair<String, Boolean>>) = toBinder(ctx, ACTION_BINDER_IMPORT) {
    putExtra("name", name); putExtra("kind", "CHECKLIST")
    putStringArrayListExtra("items", ArrayList(items.map { it.first })); putExtra("done", items.map { it.second }.toBooleanArray())
}

/** Asks Binder to make a bind from the scraps of a box: one item each, linked to its scrap. Binder asks what kind of bind it should be. */
fun boxToBinder(ctx: Context, name: String, scraps: List<Item>) = toBinder(ctx, ACTION_BINDER_IMPORT) {
    putExtra("name", name)
    putStringArrayListExtra("items", ArrayList(scraps.map { it.title.ifBlank { "Untitled" } })); putStringArrayListExtra("scraps", ArrayList(scraps.map { it.uid }))
}

/** Opens a binder:// link in Binder. */
fun openInBinder(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Binder isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/**
 * The Binder rows of a scrap's menu: Add to Binder; Open in Binder when the scrap already links to a Binder item; Make a checklist bind when
 * it has checklist lines. [uid] is null for a scrap that has not been saved yet.
 */
@Composable
fun BinderMenuRows(uid: String?, title: String, body: String, close: () -> Unit) {
    val ctx = LocalContext.current
    val linked = remember(body) { firstBinderItem(body) }
    val tasks = remember(body) { checklistItems(body) }
    MenuRow("plus", "Add to Binder", "Put this scrap in one of your binds") {
        close()
        if (uid == null) Toast.makeText(ctx, "Write something first, so there is a scrap to add", Toast.LENGTH_SHORT).show() else addToBinder(ctx, uid, title, body)
    }
    if (linked != null) MenuRow("link", "Open in Binder", "The item this scrap is about") { close(); openInBinder(ctx, binderItemLink(linked)) }
    if (tasks.isNotEmpty()) MenuRow("taskcheck", "Make a checklist bind", "${tasks.size} items go into a new bind") { close(); checklistToBinder(ctx, title.ifBlank { "Checklist" }, tasks) }
}

/** The box menu's "Make a bind in Binder". */
@Composable
fun BinderBoxItem(title: String, scraps: List<Item>, close: () -> Unit) {
    val ctx = LocalContext.current
    PopupItem("Make a bind in Binder", "folder", "Each scrap becomes an item") {
        close()
        if (scraps.isEmpty()) Toast.makeText(ctx, "There are no scraps in this box yet", Toast.LENGTH_SHORT).show() else boxToBinder(ctx, title, scraps)
    }
}
