package app.scrapbook.ui

import java.text.SimpleDateFormat
import java.util.HashMap
import java.util.Locale
import java.util.TimeZone

/**
 * SimpleDateFormat is slow to create, and the lists made three or four of them for every card they drew. This keeps one of each pattern
 * per thread (the class is not thread safe), and makes a new one if the phone's language or time zone has changed since.
 */
internal object Fmt {
    private class Slot(val locale: Locale, val zone: String, val format: SimpleDateFormat)
    private val slots = object : ThreadLocal<HashMap<String, Slot>>() {
        override fun initialValue(): HashMap<String, Slot> = HashMap()
    }

    fun of(pattern: String): SimpleDateFormat {
        val map = slots.get()!!
        val locale = Locale.getDefault(); val zone = TimeZone.getDefault().id
        val s = map[pattern]
        if (s != null && s.locale == locale && s.zone == zone) return s.format
        return SimpleDateFormat(pattern, locale).also { map[pattern] = Slot(locale, zone, it) }
    }
}
