package app.scrapbook.ui

import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import app.scrapbook.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// The lock screen and the PIN screens (set a PIN, confirm it before a change). They all share one keypad and one fingerprint prompt.

/** The activity a screen is in, as a FragmentActivity (the fingerprint prompt needs one). Null if there is none. */
fun Context.fragmentActivity(): FragmentActivity? {
    var c = this
    while (c is ContextWrapper) { if (c is FragmentActivity) return c; c = c.baseContext }
    return null
}

/** True when this phone has a fingerprint (or similar strong biometric) set up. */
fun biometricAvailable(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

private var biometricShowing = false

/** Asks for a fingerprint; [onSuccess] runs only if it matches. Cancelling (or "Use PIN") just closes the prompt, and the PIN keypad stays. */
fun promptBiometric(activity: FragmentActivity, title: String, onSuccess: () -> Unit) {
    if (biometricShowing) return
    biometricShowing = true
    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { biometricShowing = false; onSuccess() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { biometricShowing = false }
    })
    prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle(title).setNegativeButtonText("Use PIN")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build())
}

/** The full-screen frame: lock icon, title, a hint, the PIN dots, a line for errors, and the keypad underneath. It also stops touches reaching the app below. */
@Composable
private fun PinFrame(title: String, hint: String?, filled: Int, total: Int, error: String?, onClose: (() -> Unit)?, pad: @Composable () -> Unit) {
    val t = LocalSb.current
    Box(Modifier.fillMaxSize().background(t.paper).pointerInput(Unit) { detectTapGestures { } }.windowInsetsPadding(WindowInsets.systemBars), Alignment.Center) {
        if (onClose != null) Box(Modifier.align(Alignment.TopStart).padding(16.dp)) { CircleBtn("Cancel", onClose) { Ic("close", 22.dp, Sb.ink) } }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp), Arrangement.spacedBy(20.dp), Alignment.CenterHorizontally) {
            Ic("lock", 34.dp, accentText(t.acc))
            Text(title, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 24.sp, textAlign = TextAlign.Center)
            if (hint != null) Text(hint, fontSize = 14.sp, color = Sb.mute, textAlign = TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                repeat(total) { i -> Box(Modifier.size(14.dp).clip(CircleShape).then(if (i < filled) Modifier.background(t.acc) else Modifier.border(2.dp, Sb.mute, CircleShape))) }
            }
            Box(Modifier.heightIn(min = 20.dp)) { if (error != null) Text(error, fontSize = 14.sp, color = Sb.danger, textAlign = TextAlign.Center) }
            pad()
        }
    }
}

@Composable
private fun PadKey(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(76.dp).clip(CircleShape).background(Sb.card).then(if (enabled) Modifier.tap(label, onClick) else Modifier), Alignment.Center) {
        Text(label, fontSize = 28.sp, fontWeight = FontWeight.Medium, color = if (enabled) Sb.ink else Sb.mute)
    }
}

/** The 3 by 4 keypad. The bottom left key is whatever [left] puts there (the fingerprint or a confirm button, or nothing). */
@Composable
private fun PinPad(enabled: Boolean, onDigit: (Char) -> Unit, onBack: () -> Unit, left: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        listOf("123", "456", "789").forEach { r -> Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) { r.forEach { d -> PadKey(d.toString(), enabled) { onDigit(d) } } } }
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            Box(Modifier.size(76.dp), Alignment.Center) { left() }
            PadKey("0", enabled) { onDigit('0') }
            Box(Modifier.size(76.dp).clip(CircleShape).tapIcon("Delete", onBack), Alignment.Center) { Ic("backspace", 28.dp, Sb.ink) }
        }
    }
}

/**
 * Asks for the current PIN. It unlocks by itself as soon as the saved number of digits is typed, and a fingerprint can be used instead when that is on.
 * After five wrong tries it makes you wait (30 seconds, doubling up to 8 minutes), and that wait survives closing the app.
 */
@Composable
private fun PinCheckScreen(vm: ArchiveViewModel, activity: FragmentActivity?, title: String, hint: String?, onClose: (() -> Unit)?, onOk: () -> Unit) {
    val acc = LocalSb.current.acc; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val len by vm.pinDigits.collectAsState(); val bio by vm.biometricOn.collectAsState()
    var entered by remember { mutableStateOf("") }; var error by remember { mutableStateOf<String?>(null) }; var waitMs by remember { mutableLongStateOf(0L) }
    var busy by remember { mutableStateOf(false) }
    val bioReady = remember(ctx) { biometricAvailable(ctx) }
    val canBio = bio && activity != null && bioReady
    LaunchedEffect(Unit) { waitMs = vm.lockoutRemaining() }
    LaunchedEffect(waitMs > 0) { while (waitMs > 0) { delay(1000); waitMs = (waitMs - 1000).coerceAtLeast(0) } }
    LaunchedEffect(Unit) { if (canBio) { delay(300); promptBiometric(activity!!, title) { onOk() } } }
    fun submit(pin: String) {
        busy = true
        scope.launch {
            when (val r = vm.checkPin(pin)) {
                PinCheck.Ok -> onOk()
                PinCheck.Wrong -> { error = "Wrong PIN"; entered = "" }
                is PinCheck.Wait -> { waitMs = r.ms; error = null; entered = "" }
            }
            busy = false
        }
    }
    val shownError = if (waitMs > 0) "Too many tries. Try again in ${(waitMs + 999) / 1000} s." else error
    PinFrame(title, hint, entered.length, len, shownError, onClose) {
        PinPad(waitMs == 0L && !busy, { d -> if (entered.length < len) { error = null; entered += d; if (entered.length == len) submit(entered) } }, { entered = entered.dropLast(1) }) {
            if (canBio) Box(Modifier.size(76.dp).clip(CircleShape).tap("Use fingerprint") { promptBiometric(activity!!, title) { onOk() } }, Alignment.Center) { Ic("fingerprint", 32.dp, accentText(acc)) }
        }
    }
}

/** Choose a PIN: type 4 to 8 digits and tap the check mark, then type it again. */
@Composable
private fun PinCreateScreen(vm: ArchiveViewModel, title: String, onClose: () -> Unit, onSaved: () -> Unit) {
    val acc = LocalSb.current.acc
    var first by remember { mutableStateOf<String?>(null) }; var entered by remember { mutableStateOf("") }; var error by remember { mutableStateOf<String?>(null) }
    fun done(pin: String) {
        val f = first
        if (f == null) { first = pin; entered = ""; error = null }
        else if (pin == f) vm.setPin(pin, onSaved)
        else { first = null; entered = ""; error = "The PINs did not match. Start again." }
    }
    val f = first
    PinFrame(if (f == null) title else "Enter it again", if (f == null) "4 to 8 digits. A forgotten PIN cannot be recovered, so keep a backup of your scraps." else null,
        entered.length, f?.length ?: maxOf(entered.length, PIN_MIN), error, onClose) {
        PinPad(true, { d -> if (entered.length < PIN_MAX) { error = null; entered += d; if (f != null && entered.length == f.length) done(entered) } }, { entered = entered.dropLast(1) }) {
            if (f == null && entered.length >= PIN_MIN) Box(Modifier.size(76.dp).clip(CircleShape).background(acc).tapIcon("Continue") { done(entered) }, Alignment.Center) { Ic("check", 30.dp, onAccent(acc)) }
        }
    }
}

/** What covers the app while it is locked. Back leaves the app instead of going back into it. */
@Composable
fun LockScreen(vm: ArchiveViewModel) {
    val ctx = LocalContext.current; val activity = remember(ctx) { ctx.fragmentActivity() }
    BackHandler { activity?.moveTaskToBack(true) }
    PinCheckScreen(vm, activity, "Scrapbook is locked", null, null) { vm.locked.value = false }
}

/** The PIN screen opened by [ArchiveViewModel.pinFlow]. Back or the close button cancels it. */
@Composable
fun PinFlowScreen(vm: ArchiveViewModel, flow: PinFlow) {
    val ctx = LocalContext.current; val activity = remember(ctx) { ctx.fragmentActivity() }
    val close = { vm.pinFlow.value = null }
    BackHandler { close() }
    when (flow) {
        is PinFlow.Create -> PinCreateScreen(vm, flow.title, close) { vm.pinFlow.value = null; flow.onDone() }
        is PinFlow.Verify -> PinCheckScreen(vm, activity, flow.title, null, close) { vm.pinFlow.value = null; flow.onDone() }
    }
}
