package app.scrapbook.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import app.scrapbook.matchRanges

/** [text] with every occurrence of the search [terms] marked. With no terms it is just the text. */
fun hlTerms(text: String, terms: List<String>, mark: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    matchRanges(text, terms).forEach { r ->
        append(text.substring(i, r.first))
        withStyle(SpanStyle(background = mark)) { append(text.substring(r.first, r.last + 1)) }
        i = r.last + 1
    }
    append(text.substring(i))
}
