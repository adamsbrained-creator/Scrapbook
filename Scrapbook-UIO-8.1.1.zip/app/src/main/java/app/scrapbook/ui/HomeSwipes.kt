package app.scrapbook.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

// The rest of the Home gestures (UIO 9). Each one only reads what the finger does and calls a function Home gives it; nothing here changes a scrap by itself.
//
//  Swipe a Recent row   Right pins the scrap, left deletes it (Home shows the Undo message). The row follows the finger over a colored strip with the icon.
//  Quick capture        Swipe the card up and let go past the line: a new checklist. Hold it: a new scrap that starts recording a voice note.
//  Double tap greeting  Jumps to the scrap you edited last, or to Inbox (Customize home > Gestures).
//  Pull the page down   At the top of Home, pull down past the line and let go: search opens.

/** A row that can be swiped sideways. Right shows [rightIcon] and, past the line, calls [onRight]; left does the same with [leftIcon] and [onLeft] (colored as a warning). Both are also actions for screen readers. */
@Composable
fun SwipeRow(
    enabled: Boolean, rightIcon: String, rightLabel: String, onRight: () -> Unit, leftIcon: String, leftLabel: String, onLeft: () -> Unit,
    modifier: Modifier = Modifier, content: @Composable () -> Unit,
) {
    val haptics = LocalHaptics.current
    val acc = LocalSb.current.acc
    val scope = rememberCoroutineScope()
    val x = remember { Animatable(0f) }
    var width by remember { mutableFloatStateOf(1f) }
    var armed by remember { mutableStateOf(false) }
    val right by rememberUpdatedState(onRight)
    val left by rememberUpdatedState(onLeft)
    suspend fun settle() {
        val v = x.value
        if (abs(v) >= width * .28f) {
            val dir = if (v > 0f) 1f else -1f
            haptics.confirm()
            x.animateTo(dir * width, tween(170))
            if (dir > 0f) right() else left()
            x.snapTo(0f)
        } else x.animateTo(0f, spring(dampingRatio = .75f, stiffness = 500f))
        armed = false
    }
    Box(modifier.onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }.semantics {
        customActions = listOf(CustomAccessibilityAction(rightLabel) { right(); true }, CustomAccessibilityAction(leftLabel) { left(); true })
    }) {
        val dx = x.value
        if (dx != 0f) {
            val toRight = dx > 0f
            val fill = if (toRight) acc else Sb.danger
            Box(Modifier.matchParentSize().clip(RoundedCornerShape(26.dp)).background(fill.copy(alpha = if (abs(dx) >= width * .28f) 1f else .55f)).padding(horizontal = 26.dp),
                if (toRight) Alignment.CenterStart else Alignment.CenterEnd) { Ic(if (toRight) rightIcon else leftIcon, 24.dp, onAccent(fill)) }
        }
        Box(Modifier.offset { IntOffset(x.value.roundToInt(), 0) }.then(
            if (!enabled) Modifier else Modifier.pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { armed = false },
                    onDragEnd = { scope.launch { settle() } },
                    onDragCancel = { scope.launch { x.animateTo(0f) } },
                ) { change, amount ->
                    change.consume()
                    scope.launch(start = CoroutineStart.UNDISPATCHED) { x.snapTo((x.value + amount).coerceIn(-width, width)) }
                    val on = abs(x.value) >= width * .28f
                    if (on != armed) { armed = on; if (on) haptics.tick() }
                }
            }
        )) { content() }
    }
}

/**
 * Quick capture's own gestures: swipe the card up (past a line, with a small label saying when to let go) for a new checklist, hold it for a new scrap that starts recording.
 * Dragging up from the card takes the drag, so the page does not scroll with it; dragging down, or starting anywhere else, scrolls as always.
 */
@Composable
fun CaptureGestures(onChecklist: () -> Unit, onVoice: () -> Unit, content: @Composable () -> Unit) {
    val g = LocalHomeGestures.current
    if (g == null || !g.prefs.capture) { content(); return }
    val haptics = LocalHaptics.current
    val acc = LocalSb.current.acc
    val limit = with(LocalDensity.current) { 72.dp.toPx() }
    var pull by remember { mutableFloatStateOf(0f) }
    val go by rememberUpdatedState(onChecklist)
    val armed = pull >= limit
    val hold = if (g.holdOn) Modifier.pickUp(g.drag, "capture", null) { onVoice() } else Modifier
    Box(Modifier.then(hold).pointerInput(limit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            var first = 0f
            // Only an upward drag is taken; a downward one is left for the page to scroll.
            val taken = awaitVerticalTouchSlopOrCancellation(down.id) { change, over -> if (over < 0f) { change.consume(); first = -over } }
            if (taken != null) {
                pull = first
                var was = false
                val done = verticalDrag(taken.id) { change ->
                    pull = (pull - change.positionChange().y).coerceAtLeast(0f)
                    change.consume()
                    val on = pull >= limit
                    if (on != was) { was = on; haptics.tick() }
                }
                val fire = done && pull >= limit
                pull = 0f
                if (fire) { haptics.confirm(); go() }
            }
        }
    }.graphicsLayer { translationY = -pull * .45f }) {
        content()
        if (pull > 0f) {
            Text(if (armed) "Let go for a checklist" else "Swipe up for a checklist", Modifier.align(Alignment.TopCenter).offset { IntOffset(0, (-36.dp.toPx()).roundToInt()) }
                .clip(CircleShape).background(if (armed) acc else Sb.card).padding(horizontal = 14.dp, vertical = 6.dp),
                color = if (armed) onAccent(acc) else Sb.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** Calls [onDouble] when the same spot is tapped twice quickly. It only watches: the taps still do whatever they did, so a greeting that changes on a tap changes twice. */
@Composable
fun Modifier.onDoubleTap(enabled: Boolean, onDouble: () -> Unit): Modifier {
    if (!enabled) return this
    val act by rememberUpdatedState(onDouble)
    return this.pointerInput(Unit) {
        var lastUp = 0L
        var lastAt = Offset.Zero
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var up: androidx.compose.ui.input.pointer.PointerInputChange? = null
            var moved = false
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                if ((c.position - down.position).getDistance() > viewConfiguration.touchSlop) { moved = true; break }
                if (!c.pressed) { up = c; break }
            }
            val u = up
            if (moved || u == null || u.uptimeMillis - down.uptimeMillis >= viewConfiguration.longPressTimeoutMillis) { lastUp = 0L; return@awaitEachGesture }
            if (lastUp != 0L && u.uptimeMillis - lastUp <= viewConfiguration.doubleTapTimeoutMillis && (u.position - lastAt).getDistance() <= viewConfiguration.touchSlop * 6) {
                lastUp = 0L
                act()
            } else { lastUp = u.uptimeMillis; lastAt = u.position }
        }
    }
}

/**
 * Pull the page down at its top to open search. Put on the page's list with Modifier.nestedScroll; [pull] is how far it has been pulled (for [PullIndicator]), it counts half of
 * the finger's travel, and past [limit] letting go calls [trigger]. Scrolling back up takes the pull back first; flinging never counts.
 */
@Stable
class PullToSearch(val limit: Float, private val haptics: Haptics, private val enabled: () -> Boolean, private val trigger: () -> Unit) : NestedScrollConnection {
    var pull by mutableFloatStateOf(0f)
        private set
    val armed: Boolean get() = pull >= limit
    private var wasArmed = false

    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
        if (pull > 0f && available.y < 0f && source == NestedScrollSource.UserInput) {
            val take = max(available.y, -pull)
            pull += take
            return Offset(0f, take)
        }
        return Offset.Zero
    }

    override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
        if (!enabled() || source != NestedScrollSource.UserInput || available.y <= 0f) return Offset.Zero
        pull += available.y * .5f
        if (armed && !wasArmed) { wasArmed = true; haptics.tick() }
        return Offset(0f, available.y)
    }

    override suspend fun onPreFling(available: Velocity): Velocity {
        val go = armed
        pull = 0f; wasArmed = false
        if (go) trigger()
        return Velocity.Zero
    }

    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
        pull = 0f; wasArmed = false
        return Velocity.Zero
    }
}

/** The round search button that slides down from the top while the page is pulled, and fills with the accent color once letting go will open search. */
@Composable
fun BoxScope.PullIndicator(p: PullToSearch) {
    val pull = p.pull
    if (pull <= 0f) return
    val acc = LocalSb.current.acc
    val frac = (pull / p.limit).coerceIn(0f, 1f)
    Box(Modifier.align(Alignment.TopCenter).offset { IntOffset(0, (pull * .7f - 28.dp.toPx()).roundToInt()) }
        .graphicsLayer { alpha = frac; scaleX = .6f + .4f * frac; scaleY = .6f + .4f * frac }
        .size(48.dp).clip(CircleShape).background(if (p.armed) acc else Sb.card), Alignment.Center) {
        Ic("search", 22.dp, if (p.armed) onAccent(acc) else Sb.ink)
    }
}
