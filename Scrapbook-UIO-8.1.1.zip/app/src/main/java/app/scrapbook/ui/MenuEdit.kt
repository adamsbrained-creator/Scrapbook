package app.scrapbook.ui

import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

// Customize menu: change how the Home menu looks (the skin and the choices on top of it), and which entries it holds and in what order.
// Open it from the menu itself (Customize menu) or from Settings > Menus. Everything is saved on this phone as you go (see MenuLayout.kt, MenuStyle.kt);
// no scrap or box is touched. "Try the menu" opens the real menu on top of this page, so a change can be judged without leaving.

@Composable
fun MenuCustomizeScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val haptics = LocalHaptics.current
    val stored by vm.menuLayout.collectAsState(); val style by vm.menuStyle.collectAsState()
    val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    val drag = remember { DragReorder(vertical = true) }
    // The page works on its own copy of the layout so a dragged row follows the finger at once; every change is saved straight away.
    // Several swaps can happen in one drag event, before the page has had time to show the first: each one starts from the layout the last one made.
    var layout by remember { mutableStateOf(stored) }
    val live = remember { arrayOf(stored) }
    LaunchedEffect(stored) { if (drag.active == null) { layout = stored; live[0] = stored } }
    fun commit(next: MenuLayout) { live[0] = next; layout = next; vm.setMenuLayout(next) }
    val move: (Int, Int) -> Unit = { from, to -> commit(live[0].move(from, to)) }
    val keys = remember(layout) { layout.order.map { it.key } }
    var trying by remember { mutableStateOf(false) }
    val skin = MenuSkins.of(style.skin); val o = style.options
    fun setOptions(next: MenuOptions) = vm.setMenuStyle(style.copy(options = next))

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.paper) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                ScreenHeader({ nav.popBackStack() }, title = "Customize menu")
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp), userScrollEnabled = drag.active == null) {
                    // --- The skin
                    item(key = "skinLabel") { SheetLabel("Skin") }
                    item(key = "skins") {
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp).horizontalScroll(rememberScrollState()), Arrangement.spacedBy(12.dp)) {
                            MenuSkins.all.forEach { s ->
                                val on = s.id == style.skin
                                val shape = RoundedCornerShape(24.dp)
                                Column(Modifier.pressScale(.97f).width(160.dp).clip(shape).background(Sb.card).border(if (on) 2.dp else 1.dp, if (on) Sb.ink else Sb.line, shape)
                                    .semantics { selected = on }.tap(s.id.label) { if (!on) { haptics.tick(); vm.setMenuStyle(style.copy(skin = s.id)) } }.padding(10.dp), Arrangement.spacedBy(10.dp)) {
                                    SkinPreview(s)
                                    Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(s.id.label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                                        if (on) Ic("check", 20.dp, accentText(t.acc))
                                    }
                                }
                            }
                        }
                    }
                    item(key = "skinNote") { Text(style.skin.blurb, Modifier.padding(start = 6.dp, end = 6.dp, top = 10.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute) }

                    // --- The choices on top of it
                    item(key = "optLabel") { SheetLabel("Options") }
                    item(key = "options") {
                      Column {
                        Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).padding(vertical = 4.dp)) {
                            ChoiceRow("Row size", MenuOptions.ROW_SIZES, o.rowSize.coerceIn(0, 2)) { setOptions(o.copy(rowSize = it)) }
                            SheetDivider()
                            ToggleRow(null, "Icons next to the names", o.icons) { setOptions(o.copy(icons = it)) }
                            SheetDivider()
                            ChoiceRow("Dim behind the menu", MenuOptions.DIMS, o.dim.coerceIn(0, 2)) { setOptions(o.copy(dim = it)) }
                            if (skin.canFooter) { SheetDivider(); ToggleRow(null, "Line under the buttons", o.footer) { setOptions(o.copy(footer = it)) } }
                            if (skin.canPill) { SheetDivider(); ChoiceRow("Main button", MenuOptions.ACTIONS, o.action.coerceIn(0, 1)) { setOptions(o.copy(action = it)) } }
                        }
                        if (!skin.canFooter || !skin.canPill) Text("${style.skin.label} has no ${if (!skin.canFooter && !skin.canPill) "line under the buttons or floating button" else if (!skin.canFooter) "line under the buttons" else "floating button"}; a skin like Float does.",
                            Modifier.padding(start = 6.dp, end = 6.dp, top = 8.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
                      }
                    }
                    item(key = "try") {
                        Column(Modifier.fillMaxWidth().padding(top = 16.dp), Arrangement.spacedBy(10.dp)) {
                            Row(Modifier.pressScale(.97f).fillMaxWidth().clip(CircleShape).background(Sb.ink).tap("Try the menu") { trying = true }.padding(vertical = 16.dp),
                                Arrangement.Center, Alignment.CenterVertically) {
                                Ic("menu", 20.dp, Sb.card); Spacer(Modifier.width(10.dp))
                                Text("Try the menu", color = Sb.card, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            }
                            if (style != MenuStyle()) Text("Back to the Classic look", Modifier.pressScale(.97f).fillMaxWidth().clip(CircleShape).background(Sb.line.copy(alpha = .6f))
                                .tap("Use the Classic skin and the usual options") { haptics.confirm(); vm.setMenuStyle(MenuStyle()) }.padding(vertical = 14.dp),
                                color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                        }
                    }

                    // --- What the menu holds
                    item(key = "arrangeLabel") { SheetLabel("Arrange") }
                    item(key = "arrangeNote") {
                        SheetNote("Hold the handle and drag to move an entry. Tap the eye to hide it. A group break starts a new card in the menu.")
                    }
                    items(layout.order, key = { it.key }) { entry ->
                        val i = layout.order.indexOf(entry)
                        val dragging = drag.active == entry.key
                        val what = when (entry) { is MenuItem.Entry -> entry.entry.label; is MenuItem.Gap -> "group break" }
                        val shape = RoundedCornerShape(22.dp)
                        // The row being dragged follows the finger, so it must not also slide to its new place; the others do.
                        Box(Modifier.animateItem(placementSpec = if (dragging) null else tween(220)).reorderLayer(drag, entry.key).fillMaxWidth()
                            .height(if (entry is MenuItem.Gap) 60.dp else 72.dp).padding(vertical = 4.dp)
                            .semantics {
                                customActions = listOf(
                                    CustomAccessibilityAction("Move $what up") { if (i > 0) { haptics.tick(); move(i, i - 1); true } else false },
                                    CustomAccessibilityAction("Move $what down") { if (i < layout.order.lastIndex) { haptics.tick(); move(i, i + 1); true } else false },
                                )
                            }) {
                            when (entry) {
                                is MenuItem.Entry -> {
                                    val e = entry.entry; val hidden = layout.isHidden(e)
                                    Row(Modifier.fillMaxSize().clip(shape).background(Sb.card).padding(start = 16.dp, end = 4.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                        Row(Modifier.weight(1f).alpha(if (hidden) .4f else 1f), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                            Ic(e.icon, 24.dp, Sb.ink)
                                            Column(Modifier.weight(1f)) {
                                                Text(e.label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                if (hidden) Text("Hidden", fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute)
                                                else if (!e.canHide) Text("Always in the menu", fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute)
                                            }
                                        }
                                        if (e.canHide) Box(Modifier.size(48.dp).clip(CircleShape).tapIcon(if (hidden) "Show ${e.label}" else "Hide ${e.label}") {
                                            haptics.toggle(hidden); commit(live[0].withHidden(e, !hidden))
                                        }, Alignment.Center) { Ic(if (hidden) "eyeoff" else "eye", 22.dp, if (hidden) Sb.mute else Sb.ink) }
                                        else Box(Modifier.size(48.dp), Alignment.Center) { Ic("lock", 20.dp, Sb.mute) }
                                        Box(Modifier.size(48.dp).reorderGesture(drag, entry.key, keys, true, move, handle = true).semantics { contentDescription = "Drag ${e.label}" }, Alignment.Center) {
                                            Ic("grip", 22.dp, Sb.mute)
                                        }
                                    }
                                }
                                is MenuItem.Gap -> {
                                    Row(Modifier.fillMaxSize().clip(shape).dashedOutline(Sb.mute.copy(alpha = .5f), shape).padding(start = 16.dp, end = 4.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                        Ic("divider", 24.dp, Sb.mute)
                                        Column(Modifier.weight(1f)) {
                                            Text("Group break", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.mute, maxLines = 1)
                                            Text("A new card starts below", fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Remove group break") { haptics.tick(); commit(live[0].removeGap(entry.id)) }, Alignment.Center) { Ic("close", 20.dp, Sb.mute) }
                                        Box(Modifier.size(48.dp).reorderGesture(drag, entry.key, keys, true, move, handle = true).semantics { contentDescription = "Drag group break" }, Alignment.Center) {
                                            Ic("grip", 22.dp, Sb.mute)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item(key = "addGap") {
                        val full = layout.gaps.size >= MenuLayout.MAX_GAPS
                        Row(Modifier.padding(top = 10.dp).pressScale(.95f).height(48.dp).alpha(if (full) .4f else 1f).clip(RoundedCornerShape(24.dp))
                            .tap(if (full) "No more group breaks fit" else "Add a group break") { if (!full) { haptics.tick(); commit(live[0].addGap(live[0].order.size)) } }.padding(horizontal = 6.dp),
                            Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                            Ic("plus", 18.dp, Sb.mute); Text("Add a group break", fontSize = 16.sp, color = Sb.mute)
                        }
                    }
                    if (layout != MenuLayout.Default) item(key = "reset") {
                        Text("Back to the usual menu", Modifier.pressScale(.97f).fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f))
                            .tap("Put every entry back where it was and show them all") { haptics.confirm(); commit(MenuLayout.Default) }.padding(vertical = 16.dp),
                            color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                    }
                }
            }
        }
        if (trying) MenuSheet(nav, { trying = false }, onCustomize = {}, summary = menuSummary(all.size, shelves.size), preview = true) {}
    }
}

/** A name with a row of pills under it, one chosen. The row scrolls sideways when the names do not fit. */
@Composable
private fun ChoiceRow(label: String, options: List<String>, on: Int, onPick: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), Arrangement.spacedBy(10.dp)) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, s -> SoftChip(s, on = i == on, container = Sb.paper) { onPick(i) } }
        }
    }
}
