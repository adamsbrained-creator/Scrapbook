package app.scrapbook.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

/** One tag as a pill with a small cross: tap it to take the tag off. */
@Composable
private fun TagPill(text: String, onRemove: () -> Unit) {
    Row(Modifier.clip(CircleShape).background(Sb.paper).tap("Remove tag $text", onRemove).padding(start = 16.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1)
        Ic("close", 14.dp, Sb.mute)
    }
}

/**
 * A scrap's tags as pills you can remove, a field to add more (Enter or a comma adds the tag), and one-tap suggestions from the tags already used
 * on other scraps. [tags] is the stored "one, two" text; changes go out through [onChange] in the same form. [known] is every tag with its count.
 * A new tag takes the spelling of an existing one and a tag can not be added twice (see cleanTags).
 */
@Composable
fun TagEditor(tags: String, known: List<Pair<String, Int>>, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val current = remember(tags) { parseTags(tags) }
    var typed by remember { mutableStateOf("") }
    val names = remember(known) { known.map { it.first } }
    fun commit(text: String) {
        val add = parseTags(text)
        if (add.isNotEmpty()) onChange(cleanTags(current + add, names).joinToString(", "))
        typed = ""
    }
    val suggestions = remember(names, current, typed) {
        val q = tidyTag(typed.substringAfterLast(',')).lowercase()
        names.filter { n -> current.none { it.equals(n, ignoreCase = true) } && (q.isEmpty() || n.lowercase().contains(q)) }.take(8)
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (current.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            current.forEach { t -> TagPill(t) { onChange(current.filterNot { it.equals(t, ignoreCase = true) }.joinToString(", ")) } }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Sb.paper).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Ic("tag", 20.dp, Sb.mute); Spacer(Modifier.width(12.dp))
            BasicTextField(typed, { v -> if (v.contains(',')) commit(v) else typed = v }, Modifier.weight(1f), singleLine = true,
                textStyle = TextStyle(fontSize = 15.sp, color = Sb.ink), cursorBrush = SolidColor(Sb.ink),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { commit(typed) }),
                decorationBox = { inner -> Box { if (typed.isEmpty()) Text(if (current.isEmpty()) "Add a tag" else "Add another tag", color = Sb.mute, fontSize = 15.sp); inner() } })
        }
        if (suggestions.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            suggestions.forEach { s -> SoftChip(s, container = Sb.paper) { commit(s) } }
        }
    }
}
