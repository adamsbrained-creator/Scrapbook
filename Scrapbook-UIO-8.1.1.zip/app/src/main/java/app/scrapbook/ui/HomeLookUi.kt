package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// The look every part of Home shares (see HomeLook.kt). Home reads it from [LocalHomeLook], which only the Home page provides, so the other pages of the app keep the classic look.
// Parts draw their card with [homeCard] instead of a fixed clip and background.

val LocalHomeLook = staticCompositionLocalOf { HomeLook.Default }

/**
 * A card of Home with the corner radius [base] (as the classic look has it) dressed the way the look says: filled, outlined, tinted or flat.
 * With the classic look this is exactly a clip with that radius and a filled background.
 */
@Composable
fun Modifier.homeCard(base: Dp): Modifier {
    val look = LocalHomeLook.current
    val shape = RoundedCornerShape(look.radius(base.value).dp)
    return when (look.card) {
        1 -> clip(shape).border(1.5.dp, Sb.mute.copy(alpha = .4f), shape)
        2 -> clip(shape).background(Sb.card).background(LocalSb.current.acc.copy(alpha = .12f))
        3 -> clip(shape)
        else -> clip(shape).background(Sb.card)
    }
}

/** The card in Customize home that shows the look in use and opens the Look page. */
@Composable
fun LookCard(look: HomeLook, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Look of every part", onOpen).padding(start = 18.dp, end = 12.dp).heightIn(min = 72.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic("palette", 24.dp, Sb.ink)
        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
            Text("Look", fontSize = 13.sp, color = Sb.mute)
            Text(look.summary().ifEmpty { "Corners, cards and space" }, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1)
        }
        Text("Change", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
        Ic("chevron", 18.dp, Sb.mute)
    }
}

/** The Look page: a preview of a few parts that stays on top, and one choice for each of corners, cards and space. [preview] is drawn under the look being chosen. */
@Composable
internal fun HomeLookPage(look: HomeLook, onLook: (HomeLook) -> Unit, onBack: () -> Unit, preview: @Composable () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
            CircleBtn("Back to Customize home", onBack) { Ic("back", 22.dp, Sb.ink) }
            Text("Look", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
        }
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            // The preview is the real parts with your own scraps, but only to look at: taps on it do nothing.
            Box(Modifier.fillMaxWidth().heightIn(max = 320.dp).padding(vertical = 14.dp)) {
                preview()
                Box(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { } })
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            SectionLabel("Shared by every part")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeLookKey.entries.forEach { k -> ChoiceCard(k.label, k.options, look[k], k.hints[look[k]]) { i -> onLook(look.with(k, i)) } }
            }
            HomeFooter("Optional. The look belongs to the skin you wear, and it applies to every part and section of Home. Scrap cards keep the colors you gave each scrap.")
            if (!look.isDefault) {
                Spacer(Modifier.height(10.dp))
                SettingsCard { IconRow("undo", "Back to the classic look", "") { onLook(HomeLook.Default) } }
            }
        }
    }
}
