package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// Menu skins: how the app's menus and small windows look. One skin is worn by every sheet (Sheet in Customize.kt), every pop-up menu (PopupMenu in Windows.kt),
// every group of rows in a sheet (SheetGroup) and the Home menu itself (MenuSheet in Home.kt), so changing the skin changes all of them at once.
// The skin and the choices on top of it (MenuStyle) are saved on this phone and handed down through LocalMenuStyle; which entries the Home menu shows, and in
// what order, is MenuLayout (LocalMenuLayout). Customize menu (ui/MenuEdit.kt) is where both are changed.
//
// To add a skin: add it to MenuSkinId (MenuStyle.kt), describe it here as another MenuSkin and add it to MenuSkins.of and MenuSkins.all.
// Everything a skin can change is a field of MenuSkin, so a new skin is mostly numbers; the Float skin is the example.

/** The numbers and switches that make up one skin. Colors that depend on light or dark come from the functions at the bottom, so they follow the theme. */
@Immutable
class MenuSkin(
    val id: MenuSkinId,
    /** True: the sheet is a card that floats clear of the screen edges. False: it is docked to the bottom edge. */
    val floating: Boolean,
    /** Corner of the sheet (the top corners only, when it is docked). */
    val corner: Dp,
    /** Space between a floating sheet and the screen edges. */
    val inset: Dp,
    val centerTitle: Boolean,
    val titleSize: TextUnit,
    /** True: groups of rows are outlined cards, and may carry a name on top. False: soft grey fill, no outline. */
    val outlined: Boolean,
    val groupCorner: Dp,
    /** True: a row's icon sits on a small rounded tile. */
    val tiles: Boolean,
    /** True: a sheet with a real action shows Cancel and the action side by side instead of one big button. */
    val split: Boolean,
    val popupCorner: Dp,
    val popupWidth: Dp,
    /** Whether the skin has a footer line under the buttons, and a floating pill as another way to show the main button. */
    val canFooter: Boolean,
    val canPill: Boolean,
    /** Height of a row in the Home menu, before the row size choice adds to it or takes from it. */
    val rowHeight: Dp,
) {
    /** The fill of a group of rows. */
    fun groupFill(): Color = if (!outlined) Sb.line.copy(alpha = .5f) else if (Sb.dark) Color(0xFF262626) else Color(0xFFF6F6F6)

    /** The outline of a group, and the hairlines between its rows. */
    fun groupLine(): Color = if (Sb.dark) Color(0xFF383838) else Color(0xFFE4E4E4)
}

object MenuSkins {
    /** The sheet as it has always been. Every number here is what the sheet used before skins existed, so choosing Classic changes nothing. */
    val Classic = MenuSkin(
        id = MenuSkinId.Classic, floating = false, corner = 32.dp, inset = 0.dp, centerTitle = false, titleSize = 22.sp, outlined = false, groupCorner = 26.dp,
        tiles = false, split = false, popupCorner = 24.dp, popupWidth = 248.dp, canFooter = false, canPill = false, rowHeight = 54.dp,
    )

    /** A floating card, after the Smart WiFi Transfer and Art-direction references: centered title, outlined groups with a name on top, icon tiles, two pill buttons, a footer line, or a floating pill. */
    val FloatSkin = MenuSkin(
        id = MenuSkinId.Floating, floating = true, corner = 34.dp, inset = 10.dp, centerTitle = true, titleSize = 20.sp, outlined = true, groupCorner = 22.dp,
        tiles = true, split = true, popupCorner = 28.dp, popupWidth = 262.dp, canFooter = true, canPill = true, rowHeight = 52.dp,
    )

    val all: List<MenuSkin> = listOf(Classic, FloatSkin)

    fun of(id: MenuSkinId): MenuSkin = when (id) {
        MenuSkinId.Classic -> Classic
        MenuSkinId.Floating -> FloatSkin
    }
}

/** The skin and options in use. Provided once in MainActivity, so every window follows them. */
val LocalMenuStyle = compositionLocalOf { MenuStyle() }

/** What the Home menu shows and in what order (Customize menu). Provided once in MainActivity. */
val LocalMenuLayout = compositionLocalOf { MenuLayout.Default }

@Composable
fun menuSkin(): MenuSkin = MenuSkins.of(LocalMenuStyle.current.skin)

@Composable
fun menuOptions(): MenuOptions = LocalMenuStyle.current.options

/** The fill (and, in an outlined skin, the outline) of a group of rows or a field, with the corner of the skin unless [corner] is given. */
@Composable
fun Modifier.skinCard(corner: Dp? = null): Modifier {
    val skin = menuSkin()
    val shape = RoundedCornerShape(corner ?: skin.groupCorner)
    return this.clip(shape).background(skin.groupFill()).then(if (skin.outlined) Modifier.border(1.dp, skin.groupLine(), shape) else Modifier)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// The Home menu's own pieces
// ---------------------------------------------------------------------------------------------------------------------------------

/** A group of menu rows on one card. In an outlined skin the card may carry a name on top (Browse, Discover, Manage), when [title] is given. */
@Composable
fun MenuGroup(title: String?, content: @Composable ColumnScope.() -> Unit) {
    val skin = menuSkin()
    Column(Modifier.fillMaxWidth().skinCard()) {
        if (skin.outlined && title != null) {
            Text(title, Modifier.fillMaxWidth().background(Sb.ink.copy(alpha = .05f)).padding(vertical = 9.dp).asHeading(),
                color = Sb.mute, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, letterSpacing = .3.sp, textAlign = TextAlign.Center)
        }
        content()
    }
}

/** One row of the Home menu: icon (on a tile, in some skins), label and a chevron. The last row of a group has no hairline under it. */
@Composable
fun MenuRow(entry: MenuEntry, last: Boolean, onClick: () -> Unit) {
    val skin = menuSkin(); val o = menuOptions()
    val h = skin.rowHeight + o.rowDelta.dp
    if (skin.tiles) {
        val tile = RoundedCornerShape(12.dp)
        Column {
            Row(Modifier.pressScale(.98f).fillMaxWidth().height(h).tap(entry.label, onClick).padding(horizontal = 12.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                if (o.icons) Box(Modifier.size(36.dp).clip(tile).background(Sb.raised).border(1.dp, skin.groupLine(), tile), Alignment.Center) { Ic(entry.icon, 20.dp, Sb.ink) }
                Text(entry.label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Ic("chevron", 16.dp, Sb.mute)
            }
            if (!last) Box(Modifier.padding(start = if (o.icons) 60.dp else 16.dp, end = 16.dp).fillMaxWidth().height(1.dp).background(skin.groupLine().copy(alpha = .7f)))
        }
    } else {
        Column {
            Row(Modifier.fillMaxWidth().height(h).tap(entry.label, onClick).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                if (o.icons) { Ic(entry.icon, 24.dp, Sb.ink); Spacer(Modifier.width(14.dp)) }
                Text(entry.label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Ic("chevron", 18.dp, Sb.mute)
            }
            if (!last) Box(Modifier.padding(start = if (o.icons) 56.dp else 18.dp, end = 18.dp).fillMaxWidth().height(1.dp).background(Sb.line))
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// The floating pill
// ---------------------------------------------------------------------------------------------------------------------------------

/** The main action of a sheet shown as a floating pill (after the Art-direction reference): a round icon, the action and a line under it, and an arrow. See Sheet. */
class SheetCapsule(val icon: String, val label: String, val sub: String? = null, val onClick: () -> Unit)

@Composable
fun CapsuleButton(c: SheetCapsule, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(.9f).pressScale(.97f).shadow(14.dp, CircleShape).clip(CircleShape).background(Sb.ink).tap(c.label, c.onClick)
        .padding(start = 10.dp, end = 22.dp, top = 10.dp, bottom = 10.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Sb.card), Alignment.Center) { Ic(c.icon, 22.dp, Sb.ink) }
        Column(Modifier.weight(1f)) {
            Text(c.label, color = Sb.card, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            if (c.sub != null) Text(c.sub, color = Sb.card.copy(alpha = .65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Ic("arrow", 22.dp, Sb.card)
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// A small picture of a skin, for choosing one
// ---------------------------------------------------------------------------------------------------------------------------------

/** A tiny phone with a dimmed page and a sheet in the given skin, drawn with plain boxes in the colors of the current theme. */
@Composable
fun SkinPreview(skin: MenuSkin, modifier: Modifier = Modifier) {
    val sheetShape = if (skin.floating) RoundedCornerShape(12.dp) else RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
    val frame = RoundedCornerShape(18.dp)
    val fill = skin.groupFill(); val line = skin.groupLine()
    Box(modifier.height(150.dp).clip(frame).background(Sb.paper).border(1.dp, Sb.line, frame)) {
        // The page behind the sheet, dimmed.
        Column(Modifier.fillMaxSize().padding(10.dp), Arrangement.spacedBy(6.dp)) {
            Box(Modifier.width(44.dp).height(7.dp).clip(RoundedCornerShape(4.dp)).background(Sb.ink.copy(alpha = .35f)))
            Box(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(7.dp)).background(Sb.card))
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .3f)))
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().then(if (skin.floating) Modifier.padding(6.dp) else Modifier)
            .clip(sheetShape).background(Sb.raised).padding(horizontal = 8.dp, vertical = 7.dp),
            Arrangement.spacedBy(5.dp), if (skin.centerTitle) Alignment.CenterHorizontally else Alignment.Start) {
            Box(Modifier.align(Alignment.CenterHorizontally).width(16.dp).height(2.dp).clip(RoundedCornerShape(1.dp)).background(Sb.line))
            Box(Modifier.width(34.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Sb.ink))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).background(fill).then(if (skin.outlined) Modifier.border(1.dp, line, RoundedCornerShape(7.dp)) else Modifier)
                .padding(horizontal = 6.dp, vertical = 5.dp), Arrangement.spacedBy(5.dp)) {
                repeat(3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (skin.tiles) Box(Modifier.size(8.dp).clip(RoundedCornerShape(3.dp)).background(Sb.raised).border(1.dp, line, RoundedCornerShape(3.dp)))
                        Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Sb.ink.copy(alpha = .3f)))
                    }
                }
            }
            if (skin.split) Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(4.dp)) {
                Box(Modifier.weight(1f).height(10.dp).clip(CircleShape).background(Sb.line))
                Box(Modifier.weight(1.5f).height(10.dp).clip(CircleShape).background(Sb.ink))
            } else Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(Sb.ink))
        }
    }
}
