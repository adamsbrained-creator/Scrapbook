package app.scrapbook.ui

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// Where a photo is cut for the profile picture. The photo fills a square window; drag it to move, pinch (or use the slider) to zoom, and the circle shows what will be kept.
// Nothing is saved until "Use photo"; the rules for turning what is shown into the cut are in AvatarCrop (Account.kt).

@Composable
fun AvatarCropper(uri: Uri, onCancel: () -> Unit, onDone: (AvatarCrop) -> Unit) {
    val ctx = LocalContext.current
    val acc = LocalSb.current.acc
    var bmp by remember(uri) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(uri) { mutableStateOf(false) }
    LaunchedEffect(uri) {
        val b = withContext(Dispatchers.IO) { runCatching { Avatar.decodeUpright(ctx, uri, 1600) }.getOrNull() }
        if (b == null) failed = true else bmp = b
    }
    LaunchedEffect(failed) { if (failed) { Toast.makeText(ctx, "That photo could not be opened", Toast.LENGTH_SHORT).show(); onCancel() } }
    BackHandler { onCancel() }

    var zoom by remember(uri) { mutableFloatStateOf(1f) }
    // How far the photo's middle is from the window's middle, in pixels (0 is centered).
    var dx by remember(uri) { mutableFloatStateOf(0f) }
    var dy by remember(uri) { mutableFloatStateOf(0f) }
    // The side of the square window, in pixels.
    var window by remember { mutableFloatStateOf(0f) }

    /** Sets the zoom and the offset, keeping the photo covering the whole window. */
    fun place(z: Float, x: Float, y: Float) {
        val b = bmp ?: return
        if (window <= 0f) return
        val nz = z.coerceIn(1f, AvatarCrop.MAX_ZOOM)
        val s = window / minOf(b.width, b.height) * nz
        val mx = ((b.width * s - window) / 2f).coerceAtLeast(0f)
        val my = ((b.height * s - window) / 2f).coerceAtLeast(0f)
        zoom = nz; dx = x.coerceIn(-mx, mx); dy = y.coerceIn(-my, my)
    }

    Column(Modifier.fillMaxSize().background(Sb.paper)) {
        // The cropper fills the whole screen, so the header starts below the status bar (and the bottom stays clear of the navigation bar).
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
            CircleBtn("Cancel", onCancel) { Ic("close", 22.dp, Sb.ink) }
            Text("Move and zoom", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 24.sp, letterSpacing = (-0.3).sp)
            Box(Modifier.clip(CircleShape).background(acc).tap("Use photo") {
                val b = bmp
                if (b != null && window > 0f) {
                    val s = window / minOf(b.width, b.height) * zoom
                    onDone(AvatarCrop(cx = .5f - dx / (b.width * s), cy = .5f - dy / (b.height * s), zoom = zoom))
                }
            }.padding(horizontal = 20.dp, vertical = 12.dp)) { Text("Use photo", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = onAccent(acc)) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) {
            val b = bmp
            if (b != null) {
                val image = remember(b) { b.asImageBitmap() }
                Canvas(Modifier.padding(20.dp).fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(24.dp)).onSizeChanged { window = it.width.toFloat() }
                    .pointerInput(b) {
                        detectTransformGestures { _, pan, gesture, _ ->
                            // Zooming keeps the point in the middle of the window where it is, so the offset grows with the zoom.
                            val nz = (zoom * gesture).coerceIn(1f, AvatarCrop.MAX_ZOOM)
                            place(nz, dx * nz / zoom + pan.x, dy * nz / zoom + pan.y)
                        }
                    }) {
                    val s = size.width / minOf(b.width, b.height) * zoom
                    val w = b.width * s; val h = b.height * s
                    val left = (size.width - w) / 2f + dx; val top = (size.height - h) / 2f + dy
                    drawImage(image, srcOffset = IntOffset.Zero, srcSize = IntSize(b.width, b.height),
                        dstOffset = IntOffset(left.roundToInt(), top.roundToInt()), dstSize = IntSize(w.roundToInt(), h.roundToInt()), filterQuality = FilterQuality.Medium)
                    // Dim everything outside the circle that will be kept.
                    val r = size.width / 2f - 2f
                    val mid = Offset(size.width / 2f, size.height / 2f)
                    val dim = Path().apply {
                        addRect(Rect(0f, 0f, size.width, size.height))
                        addOval(Rect(Offset(mid.x - r, mid.y - r), Size(2f * r, 2f * r)))
                        fillType = PathFillType.EvenOdd
                    }
                    drawPath(dim, Color(0x99000000))
                    drawCircle(Color.White, r, mid, style = Stroke(2.dp.toPx()))
                }
            } else Text("Opening the photo…", fontSize = 15.sp, color = Sb.mute)
        }
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 28.dp, end = 28.dp, bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Slider(zoom, { v -> place(v, dx * v / zoom, dy * v / zoom) }, Modifier.fillMaxWidth(), valueRange = 1f..AvatarCrop.MAX_ZOOM,
                colors = SliderDefaults.colors(thumbColor = acc, activeTrackColor = acc, inactiveTrackColor = Sb.line))
            Text("Drag to move. Pinch or use the slider to zoom.", fontSize = 13.sp, color = Sb.mute)
        }
    }
}
