package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// Skins of Home (see HomeSkins.kt): a card at the top of Customize home shows the skin you are wearing and opens this page, where you put on another one,
// make a new one from the Home you have now, rename, copy, reset or delete. Putting a skin on changes Home at once, and what you change while wearing it stays with it.

/** The card at the top of Customize home: the skin being worn, and a way to the list of skins. */
@Composable
fun SkinCard(name: String, changed: Boolean, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Skins, wearing $name", onOpen).padding(start = 18.dp, end = 12.dp).heightIn(min = 72.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic("layout", 24.dp, Sb.ink)
        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
            Text("Skin", fontSize = 13.sp, color = Sb.mute)
            Text(name + if (changed) " · changed" else "", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("Change", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
        Ic("chevron", 18.dp, Sb.mute)
    }
}

/** How tall the bar for each part of Home is in a skin's small picture. */
private fun barHeight(e: HomeElement): Dp = when (e) {
    HomeElement.Header -> 5.dp
    HomeElement.Greeting -> 9.dp
    HomeElement.Capture -> 11.dp
    HomeElement.Continue -> 8.dp
    HomeElement.Sort -> 6.dp
    HomeElement.Boxes -> 7.dp
    HomeElement.Pinned -> 14.dp
    HomeElement.Recent -> 18.dp
}

/** A skin as a tiny page: one bar for each part that shows, in order, and a tinted bar for each section. */
@Composable
private fun SkinThumb(skin: HomeSkin) {
    val acc = LocalSb.current.acc
    val layout = skin.layout
    val slots = remember(skin.values) { HomeSections.slots(layout.order, skin.sections).filter { it !is HomeSlot.Part || it.element !in layout.hidden } }
    Column(Modifier.size(width = 60.dp, height = 92.dp).clip(RoundedCornerShape(10.dp)).background(Sb.paper).padding(6.dp), Arrangement.spacedBy(3.dp)) {
        slots.forEach { s ->
            val (h, c) = when (s) {
                is HomeSlot.Part -> barHeight(s.element) to Sb.line
                is HomeSlot.Sec -> 12.dp to acc.copy(alpha = .55f)
            }
            Box(Modifier.fillMaxWidth().height(h).clip(RoundedCornerShape(3.dp)).background(c))
        }
    }
}

private fun summaryOf(skin: HomeSkin): String {
    val layout = skin.layout
    val parts = layout.order.count { it !in layout.hidden }
    val secs = skin.sections.size
    return "$parts ${if (parts == 1) "part" else "parts"}" + if (secs > 0) " · $secs ${if (secs == 1) "section" else "sections"}" else ""
}

@Composable
internal fun SkinsPage(
    skins: HomeSkins, onBack: () -> Unit, onWear: (String) -> Unit, onNew: () -> Unit, onReady: (String) -> Unit,
    onRename: (String, String) -> Unit, onCopy: (String) -> Unit, onReset: (String) -> Unit, onDelete: (String) -> Unit,
) {
    val haptics = LocalHaptics.current
    var menuFor by remember { mutableStateOf<String?>(null) }
    BackHandler { onBack() }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                CircleBtn("Back to Customize home", onBack) { Ic("back", 22.dp, Sb.ink) }
                Text("Skins", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
            }
            Text("A skin is a whole Home: which parts show and where, their designs, your sections, the header and the add button. Tap one to wear it. What you change while wearing a skin stays with it.",
                Modifier.padding(horizontal = 24.dp, vertical = 10.dp), fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute)
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(skins.skins, key = { it.id }) { skin ->
                    val worn = skin.id == skins.current.id
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.card).tap(if (worn) "${skin.name}, worn now" else "Wear ${skin.name}") { if (!worn) { haptics.confirm(); onWear(skin.id) } }
                        .semantics { selected = worn }.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 6.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        SkinThumb(skin)
                        Column(Modifier.weight(1f)) {
                            Text(skin.name, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(summaryOf(skin), fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (worn) Text(if (skin.builtIn && skin.changed) "Worn now · changed" else "Worn now", Modifier.padding(top = 4.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = accentText(LocalSb.current.acc))
                        }
                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Options for ${skin.name}") { menuFor = skin.id }, Alignment.Center) { Ic("more", 22.dp, Sb.mute) }
                    }
                }
                item(key = "new") {
                    Text("New skin from this Home", Modifier.fillMaxWidth().padding(top = 4.dp).clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f))
                        .tap("Make a new skin from Home as it is now and wear it") { haptics.confirm(); onNew() }.padding(vertical = 16.dp),
                        color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                }
                item(key = "ready-label") { SectionLabel("Ready-made") }
                items(ReadySkins.all, key = { "ready-" + it.key }) { ready ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Add ${ready.name} to your skins and wear it") { haptics.confirm(); onReady(ready.key) }
                        .padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 14.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                        SkinThumb(HomeSkin(ready.key, ready.name, ready.values))
                        Column(Modifier.weight(1f)) {
                            Text(ready.name, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(ready.blurb, fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                        Text("Add", Modifier.clip(CircleShape).background(Sb.ink).padding(horizontal = 18.dp, vertical = 10.dp), color = Sb.card, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
                item(key = "ready-note") { HomeFooter("A ready-made skin is added to your skins as a copy and worn. You can change or delete the copy like any other skin; the ready-made one stays here.") }
            }
        }
        menuFor?.let { id -> skins.get(id)?.let { skin -> SkinMenu(skin, skins, { menuFor = null }, onWear, onRename, onCopy, onReset, onDelete) } }
    }
}

/** What can be done with one skin. */
@Composable
private fun SkinMenu(
    skin: HomeSkin, skins: HomeSkins, onDone: () -> Unit, onWear: (String) -> Unit,
    onRename: (String, String) -> Unit, onCopy: (String) -> Unit, onReset: (String) -> Unit, onDelete: (String) -> Unit,
) {
    var name by remember { mutableStateOf(skin.name) }
    var sure by remember { mutableStateOf(false) }
    val worn = skin.id == skins.current.id
    Sheet(skin.name, onDone) {
        if (!skin.builtIn) {
            SheetLabel("Name")
            InputBox { Field(name, { name = it.take(HomeSkins.MAX_NAME); onRename(skin.id, name) }, "Skin name", 18.sp, headFont(), FontWeight.Medium) }
        }
        SheetGroup {
            if (!worn) { ActionRow("check", "Wear this skin") { onWear(skin.id); onDone() }; SheetDivider(46.dp) }
            ActionRow("page", "Make a copy") { onCopy(skin.id); onDone() }
            SheetDivider(46.dp)
            ActionRow("undo", "Back to the classic look", if (worn) "Home changes now" else "Only this skin changes") { onReset(skin.id); onDone() }
            if (skins.canDelete(skin.id)) {
                SheetDivider(46.dp)
                if (sure) ActionRow("trash", "Tap again to delete this skin", "Your Home does not change", danger = true) { onDelete(skin.id); onDone() }
                else ActionRow("trash", "Delete", danger = true) { sure = true }
            }
        }
        if (skin.builtIn) SheetNote("Classic is the look Home started with. It stays in the list; reset brings it back if you changed it.")
        else if (worn) SheetNote("This skin is worn now, so it cannot be deleted. Wear another skin first.")
    }
}
