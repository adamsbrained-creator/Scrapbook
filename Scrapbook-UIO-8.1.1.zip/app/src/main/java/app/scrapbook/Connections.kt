package app.scrapbook

import kotlin.math.ln

// Connections between scraps: which scraps this one links to, which link to it, which titles it mentions without linking them, and which share its tags.
// Nothing here is stored. A link is just the text [words](scrapbook://scrap/<id>) inside a scrap (see Links.kt), so every answer is worked out from the scraps'
// own text each time. That is why it can never be out of date, and why old links, backups and restores all just work.
// The rules take plain [ScrapInfo] values (only live scraps, never the Bin) so they can be tested without the database.

/** The few facts about a scrap the connection rules need. */
data class ScrapInfo(val id: Long, val uid: String, val title: String, val body: String, val tags: List<String>, val box: String, val savedAt: Long,
                      val icon: String = "", val kind: String = "")

/** A scrap whose title appears in some text without being linked. [range] is where the first such place is. */
data class Mention(val scrap: ScrapInfo, val range: IntRange)

/** A scrap offered in the "link to" list, with the reason it was put forward (null when there is none to give). */
data class ConnectionPick(val scrap: ScrapInfo, val why: String?)

/** What changed in a text: the new text and where the cursor goes. */
data class LinkEdit(val text: String, val cursor: Int)

object Connections {
    private val SCRAP_URL = Regex("scrapbook://scrap/([A-Za-z0-9-]{8,64})", RegexOption.IGNORE_CASE)

    /** Places a title must not be matched in: an existing [label](address), a written-out address, and `code`. */
    private val OFF_LIMITS = Regex("\\[[^\\]\\n]*\\]\\([^)\\s]*\\)|(?:https?|scrapbook)://\\S+|`[^`\\n]*`", RegexOption.IGNORE_CASE)

    /** The ids of the scraps a text links to (lowercase, no repeats, in the order they first appear). */
    fun uidsIn(text: String): List<String> = SCRAP_URL.findAll(text).map { it.groupValues[1].lowercase() }.distinct().toList()

    /** The scraps this text links to, in the order the links appear. A link to the scrap itself, or to one that no longer exists, is left out. */
    fun linksTo(text: String, selfUid: String, all: List<ScrapInfo>): List<ScrapInfo> {
        val by = all.associateBy { it.uid.lowercase() }
        return uidsIn(text).filter { it != selfUid.lowercase() }.mapNotNull { by[it] }
    }

    /** How many links in this text lead to a scrap that is gone (deleted for good, or not on this phone). */
    fun brokenLinks(text: String, selfUid: String, all: List<ScrapInfo>): Int {
        val known = all.mapTo(HashSet()) { it.uid.lowercase() }
        return uidsIn(text).count { it != selfUid.lowercase() && it !in known }
    }

    /** The scraps that link to the scrap with [selfUid] (its backlinks), the most recently edited first. */
    fun linkedFrom(selfUid: String, all: List<ScrapInfo>): List<ScrapInfo> {
        if (selfUid.isBlank()) return emptyList()
        val me = selfUid.lowercase()
        return all.filter { it.uid.lowercase() != me && me in uidsIn(it.body) }.sortedByDescending { it.savedAt }
    }

    private fun usableTitle(raw: String): String? {
        val t = raw.trim()
        if (t.length < 4 || t.length > 60 || t.none { it.isLetter() } || '\n' in t) return null
        if (t.equals("Untitled", true) || t.endsWith(" copy", true)) return null
        return t
    }

    private fun overlaps(a: IntRange, b: IntRange) = a.first <= b.last && b.first <= a.last

    /**
     * Scraps whose title is written in [text] but not linked yet: the places where a link could be made with one tap. Whole words only, ignoring case,
     * never inside an existing link, address or code. If two titles overlap the longer one wins ("The Stranger" over "Stranger"); if two scraps share a
     * title the newer one is offered. [skip] holds ids that are linked already.
     */
    fun mentions(text: String, selfUid: String, all: List<ScrapInfo>, skip: Set<String> = emptySet(), limit: Int = 5): List<Mention> {
        if (text.isBlank()) return emptyList()
        val off = OFF_LIMITS.findAll(text).map { it.range }.toList()
        val skipped = skip.mapTo(HashSet()) { it.lowercase() }
        val candidates = all.filter { it.uid.lowercase() != selfUid.lowercase() && it.uid.lowercase() !in skipped }
            .mapNotNull { s -> usableTitle(s.title)?.let { s to it } }
            .groupBy { it.second.lowercase() }.values.map { group -> group.maxByOrNull { it.first.savedAt }!! }
        val found = ArrayList<Mention>()
        for ((scrap, title) in candidates) {
            var from = 0
            while (true) {
                val at = text.indexOf(title, from, ignoreCase = true)
                if (at < 0) break
                val range = at until at + title.length
                val wordStart = at == 0 || !text[at - 1].isLetterOrDigit()
                val wordEnd = range.last + 1 >= text.length || !text[range.last + 1].isLetterOrDigit()
                if (wordStart && wordEnd && off.none { overlaps(it, range) }) { found += Mention(scrap, range); break }
                from = at + 1
            }
        }
        val chosen = ArrayList<Mention>()
        for (m in found.sortedByDescending { it.range.last - it.range.first }) if (chosen.none { overlaps(it.range, m.range) }) chosen += m
        return chosen.sortedBy { it.range.first }.take(limit)
    }

    /**
     * Scraps that share tags with this one, best first. A tag that few scraps carry says more than one on half the scraps, so rare tags count for more.
     * [exclude] holds ids not to offer again (already linked in either direction).
     */
    fun related(selfUid: String, selfTags: List<String>, all: List<ScrapInfo>, exclude: Set<String> = emptySet(), limit: Int = 3): List<ConnectionPick> {
        val mine = selfTags.map { it.lowercase() }.filter { it.isNotBlank() }.toSet()
        if (mine.isEmpty()) return emptyList()
        val freq = HashMap<String, Int>()
        for (s in all) for (t in s.tags.map { it.lowercase() }.toSet()) freq[t] = (freq[t] ?: 0) + 1
        val skipped = exclude.mapTo(HashSet()) { it.lowercase() }
        return all.filter { it.uid.lowercase() != selfUid.lowercase() && it.uid.lowercase() !in skipped }.mapNotNull { s ->
            val shared = s.tags.map { it.lowercase() }.filter { it in mine }.distinct()
            if (shared.isEmpty()) null else Triple(s, shared, shared.sumOf { 1.0 / ln(1.0 + (freq[it] ?: 1)) })
        }.sortedWith(compareByDescending<Triple<ScrapInfo, List<String>, Double>> { it.third }.thenByDescending { it.first.savedAt })
            .take(limit).map { (s, shared, _) -> ConnectionPick(s, "Shares " + shared.take(2).joinToString(", ") { "#$it" }) }
    }

    /**
     * The list for "Link to scrap". With nothing typed it puts the likely ones first: scraps whose title this text already mentions, scraps that link here
     * (so you can link back), scraps sharing tags, scraps in the same box, then the rest by when they were edited. Typed words must all appear (title, tags,
     * box or text); a title that starts with them comes first. A scrap this text already links to is still offered, but lower, and says so.
     */
    fun picks(query: String, selfUid: String, selfText: String, selfTags: List<String>, selfBox: String, all: List<ScrapInfo>, limit: Int = 40): List<ConnectionPick> {
        val me = selfUid.lowercase()
        val others = all.filter { it.uid.lowercase() != me }
        val linked = uidsIn(selfText).toSet()
        val mentioned = mentions(selfText, selfUid, others, linked, 50).associate { it.scrap.uid.lowercase() to it }
        val backlinks = linkedFrom(selfUid, all).mapTo(HashSet()) { it.uid.lowercase() }
        val sharing = related(selfUid, selfTags, others, emptySet(), others.size).associate { it.scrap.uid.lowercase() to it }
        val terms = searchTerms(query)
        val scored = others.mapNotNull { s ->
            val key = s.uid.lowercase()
            var score = 0.0; var why: String? = null
            if (key in linked) { score -= 20.0; why = "Already linked" }
            else {
                if (key in mentioned) { score += 40; why = "Its title is in this scrap" }
                if (key in backlinks) { score += 25; if (why == null) why = "Links to this scrap" }
                sharing[key]?.let { score += 10; if (why == null) why = it.why }
                if (why == null && selfBox.isNotBlank() && s.box == selfBox) { score += 3; why = "Same box" }
            }
            if (terms.isNotEmpty()) {
                if (!matchesAll(terms, listOf(s.title, s.tags.joinToString(" "), s.box, s.body))) return@mapNotNull null
                val title = s.title.lowercase()
                score += when {
                    title.startsWith(terms[0].lowercase()) -> 60.0
                    terms.all { title.contains(it.lowercase()) } -> 40.0
                    terms.any { s.tags.any { tg -> tg.contains(it, true) } } -> 15.0
                    else -> 5.0
                }
            }
            Triple(s, score, why)
        }
        return scored.sortedWith(compareByDescending<Triple<ScrapInfo, Double, String?>> { it.second }.thenByDescending { it.first.savedAt })
            .take(limit).map { ConnectionPick(it.first, it.third) }
    }

    /** Brackets and line breaks would break the [label](address) form, so they are swapped or flattened. */
    fun labelFor(text: String): String = text.replace('[', '(').replace(']', ')').replace(Regex("\\s+"), " ").trim().ifEmpty { "Scrap" }

    fun linkText(label: String, uid: String) = "[${labelFor(label)}](${scrapLink(uid)})"

    /**
     * Puts a link to the scrap [uid] into [text]. If [replace] is the two typed brackets "[[", they become the link. Otherwise selected text becomes the link's
     * words (a title when the selection could not be one), and with nothing selected the scrap's [title] is put at the cursor, with a space before it when it
     * would otherwise run into a word.
     */
    fun insertLink(text: String, selStart: Int, selEnd: Int, title: String, uid: String, replace: IntRange? = null): LinkEdit {
        if (replace != null && replace.first >= 0 && replace.last + 1 <= text.length && text.substring(replace.first, replace.last + 1) == "[[") {
            val link = linkText(title, uid)
            return LinkEdit(text.substring(0, replace.first) + link + text.substring(replace.last + 1), replace.first + link.length)
        }
        val a = minOf(selStart, selEnd).coerceIn(0, text.length); val b = maxOf(selStart, selEnd).coerceIn(0, text.length)
        if (a != b) {
            val picked = text.substring(a, b)
            val label = if (picked.any { it == '\n' || it == '[' || it == ']' }) title else picked
            val link = linkText(label, uid)
            return LinkEdit(text.substring(0, a) + link + text.substring(b), a + link.length)
        }
        val gap = if (a > 0 && !text[a - 1].isWhitespace() && text[a - 1] != '(') " " else ""
        val link = gap + linkText(title, uid)
        return LinkEdit(text.substring(0, a) + link + text.substring(a), a + link.length)
    }

    /** Turns the words at [range] (a title written out in the text) into a link to [uid], keeping the words as they are written. Null if the text moved on. */
    fun linkMention(text: String, range: IntRange, uid: String, expected: String): LinkEdit? {
        if (range.first < 0 || range.last + 1 > text.length) return null
        val written = text.substring(range.first, range.last + 1)
        if (!written.equals(expected, ignoreCase = true)) return null
        val link = linkText(written, uid)
        return LinkEdit(text.substring(0, range.first) + link + text.substring(range.last + 1), range.first + link.length)
    }

    /** If the last thing typed made "[[" (one new character, the second bracket), the range of those two characters; otherwise null. */
    fun typedBrackets(old: String, new: String, cursor: Int): IntRange? {
        if (new.length != old.length + 1 || cursor < 2 || cursor > new.length) return null
        if (new[cursor - 1] != '[' || new[cursor - 2] != '[') return null
        if (new.removeRange(cursor - 1, cursor) != old) return null
        if (cursor >= 3 && new[cursor - 3] == '[') return null
        return (cursor - 2)..(cursor - 1)
    }
}
