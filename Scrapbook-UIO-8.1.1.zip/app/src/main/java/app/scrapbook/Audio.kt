package app.scrapbook

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// Voice recordings. A recording is an ordinary attachment (see Attachments.kt) whose file is an .m4a, so it is stored, backed up, shared and removed
// like any other attached file. The recorder itself comes from the Songbook app.

/** 83000 -> "1:23" */
fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

object Recordings {
    /** What the mime type of a recording is. Any file with an audio/ type is played inside the app, not only these. */
    const val MIME = "audio/mp4"

    /** An empty file to record into. Like every attached file it gets a folder of its own inside attachments/, so it is cleaned up the same way. */
    fun newFile(ctx: Context): File {
        val dir = File(File(ctx.filesDir, "attachments"), "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyy-MM-dd HH-mm", Locale.US).format(Date())
        return File(dir, diskName("Recording $stamp.m4a"))
    }

    /** The finished file as an attachment, ready to be added to a scrap. */
    fun attachment(f: File): Attachment = Attachment(Uri.fromFile(f).toString(), cleanDisplayName(f.name), f.length(), MIME)

    /** Throws a take away together with its folder. Only a folder inside attachments/ is ever removed. */
    fun discard(f: File?) {
        if (f == null) return
        runCatching {
            val dir = f.parentFile
            if (dir != null && dir.parentFile?.name == "attachments") dir.deleteRecursively() else f.delete()
        }
    }

    /** Length of a recording in milliseconds, 0 when it cannot be read. */
    fun durationMs(file: File): Long = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            r.release()
        }
    }.getOrDefault(0L)
}

/** Records from the microphone into an .m4a file. */
class AudioRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()

    fun start(): Boolean {
        val f = Recordings.newFile(context)
        return try {
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = f
            startedAt = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            runCatching { recorder?.release() }
            recorder = null
            Recordings.discard(f)
            false
        }
    }

    /** Stops the recording. Returns the finished file, or null when nothing usable was recorded (for example it was far too short). */
    fun stop(): File? {
        val r = recorder ?: return file
        recorder = null
        return try {
            r.stop()
            r.release()
            file
        } catch (e: RuntimeException) {
            runCatching { r.release() }
            Recordings.discard(file)
            file = null
            null
        }
    }

    /** Throws the take away (stops it first if it is still running). */
    fun cancel() {
        recorder?.let { r ->
            runCatching { r.stop() }
            runCatching { r.release() }
        }
        recorder = null
        Recordings.discard(file)
        file = null
    }

    /** The recorded file is kept; the recorder forgets it, so [cancel] no longer deletes it. */
    fun keep(): File? = file.also { file = null }

    fun elapsedMs(): Long = if (recorder != null) System.currentTimeMillis() - startedAt else 0L

    /** Loudness 0..32767 while recording. */
    fun level(): Int = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)
}
