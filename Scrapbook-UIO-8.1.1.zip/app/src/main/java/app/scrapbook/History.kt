package app.scrapbook

/** One step of history: how things were before a change (or after it, in the redo list) and what the change was, such as "Typing" or "Photo removed". */
class Step<T>(val snap: T, val what: String)

/**
 * Undo and redo for one editing session.
 *
 * T is a snapshot of everything that can change (the editor's Snap: text, title, photos, color, type, box, tags, source). The editor calls record()
 * just before a change is applied, and undo() / redo() with how things are right now; they hand back the snapshot to put on screen.
 *
 * Quick changes of the same kind in a row (typing, a few photos picked at once) merge into one step, but a step never grows past MAX_GROUP_MS, so
 * one undo takes back a sentence or two rather than a whole page. Everything else is a step of its own.
 * The oldest steps are dropped past maxSteps, or when the snapshots together get bigger than maxCost (cost() says how big one is), so a very long
 * note cannot use up the phone's memory.
 */
class History<T>(private val cost: (T) -> Int, private val maxSteps: Int = 200, private val maxCost: Int = 2_000_000) {
    private val undoSteps = ArrayDeque<Step<T>>()
    private val redoSteps = ArrayDeque<Step<T>>()
    private var lastAt = 0L
    private var groupAt = 0L
    private var groupKey = ""

    /** What the next undo would take back ("Typing"), or null when there is nothing to undo. */
    val undoLabel: String? get() = undoSteps.lastOrNull()?.what
    /** What the next redo would bring back, or null when there is nothing to redo. */
    val redoLabel: String? get() = redoSteps.lastOrNull()?.what

    /**
     * Call just before a change. before is how things are right now, what names the change, now is the clock in milliseconds.
     * With merge = true the change joins the step before it when that one has the same key, happened less than PAUSE_MS ago and is not older than
     * MAX_GROUP_MS. Any new change clears the redo list.
     */
    fun record(before: T, what: String, now: Long, key: String = what, merge: Boolean = false) {
        val joins = merge && undoSteps.isNotEmpty() && key == groupKey && now - lastAt <= PAUSE_MS && now - groupAt <= MAX_GROUP_MS
        if (!joins) { undoSteps.addLast(Step(before, what)); groupAt = now; trim() }
        groupKey = key; lastAt = now
        redoSteps.clear()
    }

    /** Takes back the last step. current is how things are now (kept for redo). Returns what to show, or null if there is nothing to undo. */
    fun undo(current: T): T? {
        val s = undoSteps.removeLastOrNull() ?: return null
        redoSteps.addLast(Step(current, s.what)); groupKey = ""
        return s.snap
    }

    /** Brings back the step that was undone. Returns what to show, or null if there is nothing to redo. */
    fun redo(current: T): T? {
        val s = redoSteps.removeLastOrNull() ?: return null
        undoSteps.addLast(Step(current, s.what)); groupKey = ""
        return s.snap
    }

    private fun trim() {
        var total = undoSteps.sumOf { cost(it.snap) }
        while (undoSteps.size > 1 && (undoSteps.size > maxSteps || total > maxCost)) total -= cost(undoSteps.removeFirst().snap)
    }

    companion object {
        /** Typing stops being one step after a pause this long. */
        const val PAUSE_MS = 700L
        /** And a step never grows past this, however steadily you type. */
        const val MAX_GROUP_MS = 4000L
    }
}
