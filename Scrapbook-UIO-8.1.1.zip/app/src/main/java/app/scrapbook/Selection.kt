package app.scrapbook

/** Adds [id] to a selection, or takes it out if it is already in. The order of picking is kept. */
fun List<Long>.toggled(id: Long): List<Long> = if (id in this) this - id else this + id

/** Adds [id] to a selection (a long press never takes one out). */
fun List<Long>.added(id: Long): List<Long> = if (id in this) this else this + id

/** The picks that are still on screen. A scrap that was filtered out, moved or deleted drops out of the selection by itself. */
fun List<Long>.stillShown(shown: Collection<Long>): List<Long> { val on = shown.toSet(); return filter { it in on } }

/** "1 scrap", "3 scraps". */
fun scrapsLabel(n: Int) = if (n == 1) "1 scrap" else "$n scraps"

/** True when every picked scrap is pinned, so the Pin button unpins them; otherwise it pins them all. */
fun allPinned(items: List<Item>) = items.isNotEmpty() && items.all { it.pinned }

/** Tags typed as "one, two, three": trimmed, without empty ones. */
fun parseTags(text: String): List<String> = text.split(",").map { it.trim() }.filter { it.isNotEmpty() }

/** [existing] followed by the [add] tags it does not have yet (compared without regard to case). The existing ones are never changed or reordered. */
fun mergeTags(existing: List<String>, add: List<String>): List<String> {
    val seen = existing.map { it.lowercase() }.toMutableSet(); val out = existing.toMutableList()
    add.forEach { if (seen.add(it.lowercase())) out += it }
    return out
}

/** The tags used most across [items], most used first, to offer as one-tap suggestions. */
fun topTags(items: List<Item>, limit: Int = 12): List<String> {
    val shown = LinkedHashMap<String, String>(); val count = HashMap<String, Int>()
    items.forEach { i -> i.tags.forEach { t -> val k = t.lowercase(); if (k.isNotBlank()) { shown.putIfAbsent(k, t); count[k] = (count[k] ?: 0) + 1 } } }
    return shown.keys.sortedWith(compareByDescending<String> { count[it] ?: 0 }.thenBy { it }).take(limit).map { shown.getValue(it) }
}

/** Puts a tapped suggestion at the end of what is typed: "one, two" + "three" gives "one, two, three". */
fun appendTag(text: String, tag: String): String {
    val base = text.trim().trimEnd(',').trim()
    return if (base.isEmpty()) tag else "$base, $tag"
}
