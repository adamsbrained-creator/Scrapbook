package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class RecentSearchesTest {
    @Test fun newestGoesFirstAndSpacesAreTidied() = assertEquals(listOf("red car", "tax"), addRecentSearch(listOf("tax"), "  red   car "))
    @Test fun repeatedSearchMovesUpInsteadOfRepeating() = assertEquals(listOf("CAT", "a b"), addRecentSearch(listOf("a b", "cat"), "CAT"))
    @Test fun tooShortOrBlankSearchesAreIgnored() {
        assertEquals(listOf("tax"), addRecentSearch(listOf("tax"), "x"))
        assertEquals(listOf("tax"), addRecentSearch(listOf("tax"), "   "))
    }
    @Test fun listIsCutToTheLimit() {
        var l = emptyList<String>()
        for (i in 1..12) l = addRecentSearch(l, "search $i")
        assertEquals(MAX_RECENT_SEARCHES, l.size)
        assertEquals("search 12", l.first())
        assertEquals("search 5", l.last())
    }
    @Test fun storedListRoundTrips() {
        val l = listOf("red car", "tax")
        assertEquals(l, parseRecentSearches(encodeRecentSearches(l)))
        assertEquals(emptyList<String>(), parseRecentSearches(null))
        assertEquals(listOf("a", "b"), parseRecentSearches("a\n\n b \n"))
    }

    private val shelves = listOf(Shelf("A"), Shelf("B", parent = "A"), Shelf("C", parent = "B"), Shelf("D"))
    @Test fun searchingAlsoLooksInsideTheBox() = assertEquals(setOf("A", "B", "C"), searchBoxNames("A", shelves, true))
    @Test fun nothingTypedMeansOnlyThisBox() = assertEquals(setOf("A"), searchBoxNames("A", shelves, false))
    @Test fun aBoxWithNoBoxesInsideSearchesOnlyItself() = assertEquals(setOf("D"), searchBoxNames("D", shelves, true))
    @Test fun builtInListsHaveNoBoxesInside() = assertEquals(setOf("All"), searchBoxNames("All", shelves, true))
}
