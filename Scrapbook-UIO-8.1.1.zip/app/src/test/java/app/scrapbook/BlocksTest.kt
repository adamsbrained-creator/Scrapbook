package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class BlocksTest {
    @Test fun nothingSavedMeansTheDefaultOrder() {
        assertEquals(Blocks.DEFAULT, Blocks.parse(null))
        assertEquals(Blocks.DEFAULT, Blocks.parse(""))
    }

    @Test fun aSavedOrderIsKept() {
        assertEquals(listOf(Block.Text, Block.Photos, Block.Files), Blocks.parse("Text,Photos,Files"))
    }

    @Test fun missingBlocksGoAtTheEnd() {
        assertEquals(listOf(Block.Text, Block.Photos, Block.Files), Blocks.parse("Text"))
        assertEquals(listOf(Block.Files, Block.Photos, Block.Text), Blocks.parse("Files"))
    }

    @Test fun unknownAndRepeatedPartsAreSkipped() {
        assertEquals(listOf(Block.Files, Block.Photos, Block.Text), Blocks.parse("Files,Nonsense,Files, Photos ,"))
    }

    @Test fun theDefaultIsStoredAsNothing() {
        assertEquals("", Blocks.encode(Blocks.DEFAULT))
        assertEquals("Text,Photos,Files", Blocks.encode(listOf(Block.Text, Block.Photos, Block.Files)))
    }

    @Test fun encodeThenParseGivesTheSameOrder() {
        for (a in Block.entries) for (b in Block.entries) for (c in Block.entries) {
            val order = listOf(a, b, c)
            if (order.toSet().size != 3) continue
            assertEquals(order, Blocks.parse(Blocks.encode(order)))
        }
    }

    @Test fun movingKeepsEveryBlockOnce() {
        val o = Blocks.DEFAULT
        assertEquals(listOf(Block.Files, Block.Text, Block.Photos), Blocks.move(o, 0, 2))
        assertEquals(listOf(Block.Text, Block.Photos, Block.Files), Blocks.move(o, 2, 0))
        assertEquals(o, Blocks.move(o, 1, 1))
        assertEquals(o, Blocks.move(o, 3, 0))
        assertEquals(o, Blocks.move(o, 0, -1))
    }
}
