package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeLookTest {
    @Test fun nothingChosenIsTheClassicLook() {
        val l = HomeLook.Default
        assertTrue(l.isDefault)
        assertEquals(1f, l.cornerScale)
        assertEquals(0, l.card)
        assertEquals(18, l.gap)
        assertEquals(28f, l.radius(28f))
        assertEquals("", l.encode())
        assertEquals("", l.summary())
    }

    @Test fun everyChoiceHasAHintAndADefaultThatIsAnOption() {
        HomeLookKey.entries.forEach {
            assertEquals(it.name, it.options.size, it.hints.size)
            assertTrue(it.name, it.default in it.options.indices)
        }
    }

    @Test fun sharpCornersAreSmallerAndRoundOnesBigger() {
        val sharp = HomeLook.Default.with(HomeLookKey.Corners, 0)
        val round = HomeLook.Default.with(HomeLookKey.Corners, 2)
        assertTrue(sharp.radius(28f) < 28f)
        assertTrue(round.radius(28f) > 28f)
        assertTrue(sharp.radius(10f) > 0f)
    }

    @Test fun spaceBetweenPartsGrowsFromTightToRoomy() {
        val gaps = (0..2).map { HomeLook.Default.with(HomeLookKey.Spacing, it).gap }
        assertEquals(listOf(10, 18, 28), gaps)
    }

    @Test fun theCardChoiceIsReadBack() {
        assertEquals(1, HomeLook.Default.with(HomeLookKey.Cards, 1).card)
        assertEquals(3, HomeLook.Default.with(HomeLookKey.Cards, 3).card)
    }

    @Test fun choosingTheDefaultAgainDropsTheChoice() {
        val l = HomeLook.Default.with(HomeLookKey.Cards, 2).with(HomeLookKey.Cards, 0)
        assertEquals(HomeLook.Default, l)
        assertFalse(HomeLook.Default.with(HomeLookKey.Spacing, 0).isDefault)
    }

    @Test fun anOutOfRangeChoiceIsBroughtBackIntoRange() {
        assertEquals(3, HomeLook.Default.with(HomeLookKey.Cards, 99).card)
        assertEquals(HomeLook.Default.with(HomeLookKey.Corners, 0), HomeLook.Default.with(HomeLookKey.Corners, -4))
    }

    @Test fun theSummaryListsWhatDiffersInOrder() {
        val l = HomeLook.Default.with(HomeLookKey.Spacing, 2).with(HomeLookKey.Corners, 2)
        assertEquals("Round · Roomy", l.summary())
    }

    @Test fun theLookIsSavedAndReadBackTheSame() {
        val l = HomeLook.Default.with(HomeLookKey.Corners, 0).with(HomeLookKey.Cards, 3).with(HomeLookKey.Spacing, 2)
        assertEquals("corners=0,card=3,spacing=2", l.encode())
        assertEquals(l, HomeLook.decode(l.encode()))
    }

    @Test fun unreadableSavedTextIsTheClassicLook() {
        assertEquals(HomeLook.Default, HomeLook.decode(null))
        assertEquals(HomeLook.Default, HomeLook.decode(""))
        assertEquals(HomeLook.Default, HomeLook.decode("wat=1,,card=x,=3,spacing"))
        assertEquals(HomeLook.Default, HomeLook.decode("corners=1,card=0,spacing=1"))
        assertEquals(3, HomeLook.decode("card=40").card)
    }
}
