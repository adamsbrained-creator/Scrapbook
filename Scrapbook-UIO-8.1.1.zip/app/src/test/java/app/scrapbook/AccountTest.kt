package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AccountTest {
    @Test fun greetingsCallYouByTheFirstWordOfYourName() = assertEquals("John", Account(name = "John Smith").callName)
    @Test fun aNicknameWinsOverTheName() = assertEquals("Johnny", Account(name = "John Smith", nickname = " Johnny ").callName)
    @Test fun noNameMeansNoCallName() { assertEquals("", Account().callName); assertFalse(Account().hasName) }
    @Test fun theInitialIsTheFirstLetterOrDigit() { assertEquals("J", Account(name = "john").initial); assertEquals("A", Account(name = "  ,Ann").initial); assertEquals("", Account().initial) }

    @Test fun aFieldIsOneLineAndCapped() {
        assertEquals("a b c", Account.clean("a\nb\rc", 40))
        assertEquals(5, Account.clean("abcdefghij", 5).length)
    }
    @Test fun theAboutTextKeepsTwoLinesAndIsCapped() {
        assertEquals("one\ntwo", Account.cleanAbout("one\ntwo\nthree\nfour"))
        assertEquals(Account.MAX_ABOUT, Account.cleanAbout("x".repeat(500)).length)
    }

    @Test fun theBirthdayIsRecognisedOnTheDay() {
        val a = Account(birthMonth = 11, birthDay = 5)
        assertTrue(a.isBirthday(11, 5, false)); assertFalse(a.isBirthday(11, 6, false)); assertFalse(a.isBirthday(10, 5, false))
    }
    @Test fun noBirthdaySetIsNeverABirthday() { assertFalse(Account().hasBirthday); assertFalse(Account().isBirthday(1, 1, false)) }
    @Test fun aLeapDayBirthdayIsCelebratedOn28FebruaryInOtherYears() {
        val a = Account(birthMonth = 2, birthDay = 29)
        assertTrue(a.isBirthday(2, 28, false)); assertFalse(a.isBirthday(3, 1, false))
        assertTrue(a.isBirthday(2, 29, true)); assertFalse(a.isBirthday(2, 28, true))
    }
    @Test fun onlyRealDatesAreValidBirthdays() {
        assertTrue(Account.validBirthday(2, 29)); assertTrue(Account.validBirthday(12, 31))
        assertFalse(Account.validBirthday(2, 30)); assertFalse(Account.validBirthday(4, 31)); assertFalse(Account.validBirthday(13, 1)); assertFalse(Account.validBirthday(0, 0))
    }
    @Test fun leapYears() { assertTrue(Account.isLeap(2024)); assertTrue(Account.isLeap(2000)); assertFalse(Account.isLeap(1900)); assertFalse(Account.isLeap(2026)) }
}
