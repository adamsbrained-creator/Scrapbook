package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EditorSpotsTest {
    @Test fun roundTrip() {
        val map = LinkedHashMap<Long, EditorSpot>()
        EditorSpots.put(map, 7, EditorSpot(120, 640, true))
        EditorSpots.put(map, 9, EditorSpot(0, 0, false))
        val back = EditorSpots.decode(EditorSpots.encode(map))
        assertEquals(map, back)
        assertEquals(listOf(7L, 9L), back.keys.toList())
    }

    @Test fun emptyAndBrokenTextGiveAnEmptyMap() {
        assertTrue(EditorSpots.decode(null).isEmpty())
        assertTrue(EditorSpots.decode("").isEmpty())
        assertTrue(EditorSpots.decode("nonsense;1:2;a:b:c:d").isEmpty())
    }

    @Test fun oneBrokenPartDoesNotLoseTheOthers() {
        val back = EditorSpots.decode("1:5:10:1;oops;2:6:11:0")
        assertEquals(EditorSpot(5, 10, true), back[1])
        assertEquals(EditorSpot(6, 11, false), back[2])
        assertEquals(2, back.size)
    }

    @Test fun negativeNumbersAreClampedToZero() {
        assertEquals(EditorSpot(0, 0, false), EditorSpots.decode("3:-4:-5:0")[3])
    }

    @Test fun puttingAgainMakesItTheNewest() {
        val map = LinkedHashMap<Long, EditorSpot>()
        EditorSpots.put(map, 1, EditorSpot(1, 1, false))
        EditorSpots.put(map, 2, EditorSpot(2, 2, false))
        EditorSpots.put(map, 1, EditorSpot(9, 9, true))
        assertEquals(listOf(2L, 1L), map.keys.toList())
        assertEquals(EditorSpot(9, 9, true), map[1])
    }

    @Test fun theOldestFallOffPastTheLimit() {
        val map = LinkedHashMap<Long, EditorSpot>()
        for (i in 1L..(EditorSpots.MAX + 5L)) EditorSpots.put(map, i, EditorSpot(0, 0, false))
        assertEquals(EditorSpots.MAX, map.size)
        assertNull(map[1L])
        assertTrue(map.containsKey(EditorSpots.MAX + 5L))
    }

    @Test fun pruneDropsOnlyScrapsThatAreGone() {
        val map = EditorSpots.decode("1:0:0:0;2:0:0:0;3:0:0:0")
        assertTrue(EditorSpots.prune(map, setOf(1L, 3L)))
        assertEquals(listOf(1L, 3L), map.keys.toList())
        assertFalse(EditorSpots.prune(map, setOf(1L, 3L, 4L)))
    }

    @Test fun cursorStaysInsideAShorterText() {
        assertEquals(0, EditorSpots.cursorFor(null, 50))
        assertEquals(20, EditorSpots.cursorFor(EditorSpot(20, 0, false), 50))
        assertEquals(10, EditorSpots.cursorFor(EditorSpot(200, 0, false), 10))
        assertEquals(0, EditorSpots.cursorFor(EditorSpot(5, 0, false), 0))
    }

    @Test fun locksAreAddedRemovedAndPruned() {
        var set = emptySet<String>()
        set = LockedScraps.with(set, 4, true); set = LockedScraps.with(set, 9, true)
        assertTrue(LockedScraps.has(set, 4)); assertFalse(LockedScraps.has(set, 5))
        set = LockedScraps.with(set, 4, false)
        assertFalse(LockedScraps.has(set, 4))
        assertEquals(setOf("9"), LockedScraps.prune(setOf("9", "10", "junk"), setOf(9L)))
    }
}
