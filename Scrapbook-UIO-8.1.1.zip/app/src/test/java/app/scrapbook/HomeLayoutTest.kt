package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeLayoutTest {
    private val all = HomeElement.entries.toList()

    @Test fun theDefaultShowsEveryPartInTheUsualOrder() {
        assertEquals(all, HomeLayout.Default.order)
        assertEquals(all, HomeLayout.Default.shown)
        assertEquals(listOf("header", "greeting", "capture", "continue", "sort", "boxes", "pinned", "recent"), all.map { it.key })
    }

    @Test fun movingAPartDownOrUpKeepsTheOthersInOrder() {
        val down = HomeLayout.Default.move(1, 4)
        assertEquals(listOf(HomeElement.Header, HomeElement.Capture, HomeElement.Continue, HomeElement.Sort, HomeElement.Greeting), down.order.take(5))
        val up = HomeLayout.Default.move(6, 0)
        assertEquals(HomeElement.Pinned, up.order.first())
        assertEquals(all.size, up.order.size)
        assertEquals(all.toSet(), up.order.toSet())
    }

    @Test fun movingNowhereOrOutsideTheListChangesNothing() {
        val l = HomeLayout.Default
        assertEquals(l, l.move(2, 2))
        assertEquals(l, l.move(-1, 2))
        assertEquals(l, l.move(2, 99))
        assertEquals(l, l.move(99, 0))
    }

    @Test fun aHiddenPartIsLeftOutOfWhatIsShownButKeepsItsPlace() {
        val l = HomeLayout.Default.withHidden(HomeElement.Boxes, true)
        assertTrue(l.isHidden(HomeElement.Boxes))
        assertFalse(HomeElement.Boxes in l.shown)
        assertEquals(all, l.order)
        assertEquals(all, l.withHidden(HomeElement.Boxes, false).shown)
    }

    @Test fun aHiddenPartCanBeMovedAndStaysHidden() {
        val l = HomeLayout.Default.withHidden(HomeElement.Pinned, true).move(6, 1)
        assertEquals(HomeElement.Pinned, l.order[1])
        assertTrue(l.isHidden(HomeElement.Pinned))
        assertEquals(all.size - 1, l.shown.size)
    }

    @Test fun theOrderIsSavedAndReadBackTheSame() {
        val l = HomeLayout.Default.move(0, 7).move(3, 1)
        assertEquals(l.order, HomeLayout.decodeOrder(l.encodeOrder()))
    }

    @Test fun anUnreadableOrderFallsBackToTheDefault() {
        assertEquals(all, HomeLayout.decodeOrder(null))
        assertEquals(all, HomeLayout.decodeOrder(""))
        assertEquals(all, HomeLayout.decodeOrder("nonsense,,??"))
    }

    @Test fun unknownNamesAndRepeatsAreDroppedAndMissingPartsGoLast() {
        val order = HomeLayout.decodeOrder("recent, boxes,boxes,wat,header")
        assertEquals(listOf(HomeElement.Recent, HomeElement.Boxes, HomeElement.Header), order.take(3))
        assertEquals(all.size, order.size)
        assertEquals(all.toSet(), order.toSet())
        assertEquals(listOf(HomeElement.Greeting, HomeElement.Capture, HomeElement.Continue, HomeElement.Sort, HomeElement.Pinned), order.drop(3))
    }

    @Test fun hiddenPartsAreSavedInTheDefaultOrderAndReadBack() {
        val set = setOf(HomeElement.Recent, HomeElement.Greeting)
        assertEquals("greeting,recent", HomeLayout.encodeHidden(set))
        assertEquals(set, HomeLayout.decodeHidden("recent,greeting"))
        assertEquals(set, HomeLayout.decodeHidden("recent,?,greeting,recent"))
    }

    @Test fun nothingHiddenIsSavedAsAnEmptyTextAndReadBackAsNothing() {
        assertEquals("", HomeLayout.Default.encodeHidden())
        assertEquals(emptySet<HomeElement>(), HomeLayout.decodeHidden(""))
        assertEquals(emptySet<HomeElement>(), HomeLayout.decodeHidden(null))
    }
}
