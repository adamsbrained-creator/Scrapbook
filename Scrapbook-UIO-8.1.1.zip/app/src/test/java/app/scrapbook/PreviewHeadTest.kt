package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/** The short previews used on cards must be the start of exactly what the full preview would be. */
class PreviewHeadTest {
    private val pieces = listOf("# Title", "Title", "- item", "1. one", "> quote", "**bold** x", "{c:ff0000|red} t", "[a](http://x) y", "---", "", "   ",
        "{a:c}Hi", "plain text line here", "- [ ] todo", "*it* ~~s~~ ==m==")

    private fun fullPreview(title: String, body: String) = plainPreview(bodyWithoutTitle(title, body))

    @Test fun shortTextGivesTheFullPreview() {
        assertEquals(fullPreview("Hello", "Hello\n\nWorld"), previewHead("Hello", "Hello\n\nWorld"))
        assertEquals("World", previewHead("Hello", "Hello\n\nWorld"))
        assertEquals(fullPreview("Hello", "- Hello"), previewHead("Hello", "- Hello"))
    }

    @Test fun blankBodyGivesNothing() {
        assertEquals("", previewHead("T", ""))
        assertEquals("", previewHead("T", "  \n \n"))
    }

    @Test fun longTextIsCutNearTheLimitButStaysThePrefix() {
        val body = (1..500).joinToString("\n") { "line number $it with some words" }
        val head = previewHead("x", body, 200)
        assertTrue(head.length in 200..260)
        assertTrue(fullPreview("x", body).startsWith(head))
    }

    @Test fun headIsAlwaysTheStartOfTheFullPreview() {
        val rnd = Random(7)
        repeat(3000) {
            val title = listOf("Title", "Hello", "", "x")[rnd.nextInt(4)]
            val sep = listOf("\n", "\r\n")[rnd.nextInt(2)]
            val body = (0 until rnd.nextInt(0, 40)).joinToString(sep) { pieces[rnd.nextInt(pieces.size)] }
            val limit = listOf(20, 80, 200, 800)[rnd.nextInt(4)]
            val head = previewHead(title, body, limit); val all = fullPreview(title, body)
            assertTrue("[$title] [$body]", all.startsWith(head))
            assertTrue("[$title] [$body]", head.length >= limit || head == all)
            val plainHead = plainPreviewHead(body, " ", limit); val plainAll = plainPreview(body, " ")
            assertTrue("[$body]", plainAll.startsWith(plainHead))
            assertTrue("[$body]", plainHead.length >= limit || plainHead == plainAll)
        }
    }
}
