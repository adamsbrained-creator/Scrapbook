package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkPreviewTest {
    private val page = "https://example.com/a/b"

    @Test fun sharingTagsAreRead() {
        val html = """<html><head><title>Fallback Title</title>
            <meta property="og:title" content="The Real Title &amp; More">
            <meta content='A description with &quot;quotes&quot; and an apostrophe&#39;s.' property='og:description'>
            <meta property="og:image" content="/img/cover.jpg">
            <meta property="og:site_name" content="Example News">
            </head></html>"""
        val p = parseLinkPreview(html, page)
        assertEquals("The Real Title & More", p.title)
        assertEquals("A description with \"quotes\" and an apostrophe's.", p.description)
        assertEquals("https://example.com/img/cover.jpg", p.imageUrl)
        assertEquals("Example News", p.siteName)
        assertTrue(p.hasContent)
    }

    @Test fun thePageTitleAndDescriptionAreTheFallback() {
        val p = parseLinkPreview("<title> Plain  Page\n Title </title><meta name=\"description\" content=\"Just a description.\">", page)
        assertEquals("Plain Page Title", p.title)
        assertEquals("Just a description.", p.description)
        assertNull(p.imageUrl); assertNull(p.siteName)
    }

    @Test fun twitterTagsWorkWhenThereAreNoOpenGraphOnes() {
        val p = parseLinkPreview("<meta name=\"twitter:title\" content=\"T\"><meta name=\"twitter:description\" content=\"D\"><meta name=\"twitter:image\" content=\"https://c.io/p.png\">", page)
        assertEquals("T", p.title); assertEquals("D", p.description); assertEquals("https://c.io/p.png", p.imageUrl)
    }

    @Test fun anInsecurePhotoAddressBecomesSecure() =
        assertEquals("https://cdn.example.com/p.png", parseLinkPreview("<meta name=\"twitter:image\" content=\"http://cdn.example.com/p.png\">", page).imageUrl)

    @Test fun aProtocolRelativePhotoAddressIsResolved() =
        assertEquals("https://cdn.example.com/p.png", previewImageUrl("//cdn.example.com/p.png", page))

    @Test fun aPhotoThatIsNotAWebAddressIsIgnored() {
        assertNull(previewImageUrl("ftp://x/y.png", page)); assertNull(previewImageUrl("  ", page)); assertNull(previewImageUrl(null, page))
    }

    @Test fun aPageWithNothingGivesNoCard() {
        val p = parseLinkPreview("<html><body>hello</body></html>", page)
        assertEquals(LinkPreview(null, null, null, null), p)
        assertFalse(p.hasContent)
    }

    @Test fun aLongDescriptionIsCutAtAWord() {
        val r = shortDescription("word ".repeat(100).trim())
        assertTrue(r.endsWith("word\u2026")); assertTrue(r.length <= 281)
        assertEquals("short one", shortDescription("short one"))
    }

    @Test fun entitiesAreDecoded() = assertEquals("\u2019|\u2019|&lt;|a b", decodeEntities("&#x2019;|&#8217;|&amp;lt;|a&nbsp;b"))

    @Test fun theCardHasTitleQuoteAndLink() =
        assertEquals("**T**\n> D\n\n[Site](https://x.io/a)", linkCardText("https://x.io/a", LinkPreview("T", "D", null, "Site"), includeTitle = true))

    @Test fun theTitleCanBeLeftOutOfTheCard() =
        assertEquals("> D\n\n[Site](https://x.io/a)", linkCardText("https://x.io/a", LinkPreview("T", "D", null, "Site"), includeTitle = false))

    @Test fun withoutADescriptionOrTitleTheCardIsJustTheLink() =
        assertEquals("[x.io](https://x.io/a)", linkCardText("https://x.io/a", LinkPreview(null, null, "https://i.io/p.jpg", null), includeTitle = true))

    @Test fun asterisksInATitleDoNotBreakTheBold() =
        assertEquals("**AB**\n\n[x.io](https://x.io/a)", linkCardText("https://x.io/a", LinkPreview("A*B", null, null, null), includeTitle = true))

    @Test fun theCardTakesThePlaceOfThePastedAddressOnItsOwnLines() {
        val text = "see https://x.io/a now"
        val r = applyLinkCard(text, 4 until 18, "> D\n\n[x.io](https://x.io/a)")
        assertEquals("see \n> D\n\n[x.io](https://x.io/a)\n now", r.text)
        assertEquals(4 until 4 + "\n> D\n\n[x.io](https://x.io/a)\n".length, r.range)
    }

    @Test fun anAddressOnItsOwnIsReplacedByTheCard() {
        val text = "https://x.io/a"
        val card = "> D\n\n[x.io](https://x.io/a)"
        val r = applyLinkCard(text, 0 until text.length, card)
        assertEquals(card, r.text); assertEquals(0 until card.length, r.range)
    }
}
