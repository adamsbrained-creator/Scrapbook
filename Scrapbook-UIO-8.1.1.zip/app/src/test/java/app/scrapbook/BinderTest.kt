package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test

class BinderTest {
    private val id = "6f1c2d3e-aaaa-bbbb-cccc-1234567890ab"

    @Test fun readsBinderLinks() {
        val item = parseBinderLink("binder://item/$id")!!
        assertEquals("item", item.kind); assertEquals(id, item.id)
        val bind = parseBinderLink(" binder://bind/abcdef12/ ")!!
        assertEquals("bind", bind.kind); assertEquals("abcdef12", bind.id)
        assertNull(parseBinderLink("binder://other/abcdef12")); assertNull(parseBinderLink("https://example.com")); assertNull(parseBinderLink(null)); assertNull(parseBinderLink("binder://item/short"))
    }

    @Test fun readsAPlainScrapLink() {
        val o = parseScrapOpen("scrapbook://scrap/ABCDEF1234567890")!!
        assertEquals("abcdef1234567890", o.uid); assertNull(o.binderItem); assertNull(o.binderTitle)
        assertNull(parseScrapOpen("scrapbook://scrap/short")); assertNull(parseScrapOpen("https://example.com/abcdef1234567890"))
    }

    @Test fun readsTheBinderPartOfAScrapLink() {
        val o = parseScrapOpen("scrapbook://scrap/abcdef1234567890?binder=$id&title=Perfect%20Days%20%E2%80%A2%20Movies")!!
        assertEquals("abcdef1234567890", o.uid); assertEquals(id, o.binderItem); assertEquals("Perfect Days • Movies", o.binderTitle)
        assertNull(parseScrapOpen("scrapbook://scrap/abcdef1234567890?other=1")!!.binderItem)
    }

    @Test fun addsTheLinkLineOnce() {
        val once = withBinderLink("Hello", "Perfect Days", id)
        assertEquals("Hello\n\nBinder: [Perfect Days](binder://item/$id)", once)
        assertEquals(once, withBinderLink(once, "Perfect Days", id))
        assertEquals("Binder: [Perfect Days](binder://item/$id)", withBinderLink("", "Perfect Days", id))
        assertEquals("Hello\n\nBinder: [Perfect Days](binder://item/$id)", withBinderLink("Hello\n\n\n", "Perfect Days", id))
    }

    @Test fun aTitleWithBracketsStillMakesAWorkingLabel() {
        val line = binderLinkLine("A [b] c", id)
        assertFalse(line.substringAfter("[").substringBefore("](").contains('['))
        assertFalse(line.substringAfter("[").substringBefore("](").contains(']'))
    }

    @Test fun findsTheFirstBinderItemOutsideCode() {
        assertEquals("abcdef12-1111", firstBinderItem("see binder://item/abcdef12-1111 now"))
        assertNull(firstBinderItem("code: `binder://item/abcdef12-1111`"))
        assertNull(firstBinderItem("```\nbinder://item/abcdef12-1111\n```"))
        assertNull(firstBinderItem("nothing here"))
    }

    @Test fun checklistLinesLoseTheirFormattingAndSkipCode() {
        val body = "intro\n- [ ] buy **milk**\n- [x] call mum\n- [ ] \n```\n- [ ] not a task\n```\n- plain bullet"
        assertEquals(listOf("buy milk" to false, "call mum" to true), checklistItems(body))
    }

    @Test fun theNoteIsAShortPlainStart() {
        assertEquals("one two", binderNoteOf("T", "one\ntwo").replace(" · ", " "))
        assertEquals(200, binderNoteOf("T", "x".repeat(500)).length)
    }
}
