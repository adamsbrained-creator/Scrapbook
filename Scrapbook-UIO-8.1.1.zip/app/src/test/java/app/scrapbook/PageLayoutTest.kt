package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PageLayoutTest {
    private fun l(s: String) = s.map { when (it) { 'P' -> Part.Photo; 'F' -> Part.File; else -> Part.Text } }
    private fun s(x: List<Part>) = x.joinToString("") { when (it) { Part.Photo -> "P"; Part.File -> "F"; Part.Text -> "T" } }

    @Test fun nothingSavedMeansPhotosThenFilesThenText() {
        assertEquals("PPFT", s(PageLayout.default(2, 1)))
        assertEquals("PPFT", s(PageLayout.parse(null, 2, 1)))
        assertEquals("PPFT", s(PageLayout.parse("", 2, 1)))
    }

    @Test fun theOlderGroupFormIsStillRead() {
        assertEquals("TPPF", s(PageLayout.parse("Text,Photos,Files", 2, 1)))
        assertEquals("FFPT", s(PageLayout.parse("Files", 1, 2)))
        assertEquals("TPF", s(PageLayout.parse("Text", 1, 1)))
    }

    @Test fun parsingKeepsTheRightNumberOfPlaces() {
        assertEquals("PTFP", s(PageLayout.parse("Photo,Text,File,Photo", 2, 1)))
        assertEquals("PT", s(PageLayout.parse("Photo,Photo,Photo,Text", 1, 0)))
        assertEquals("TP", s(PageLayout.parse("x,Text,,Photo,Text", 1, 0)))
    }

    @Test fun newPhotosAndFilesGoAfterTheLastOfTheirKind() {
        assertEquals("PFTPP", s(PageLayout.fit(l("PFTP"), 3, 1)))
        assertEquals("PFT", s(PageLayout.fit(l("FT"), 1, 1)))
        assertEquals("PFT", s(PageLayout.fit(l("PT"), 1, 1)))
        assertEquals("FT", s(PageLayout.fit(l("T"), 0, 1)))
        assertEquals("PT", s(PageLayout.fit(l("PPFT"), 1, 0)))
        assertEquals("PFT", s(PageLayout.fit(l("PF"), 1, 1)))
    }

    @Test fun theUsualOrderIsStoredAsNothing() {
        assertEquals("", PageLayout.encode(l("PPFT"), 2, 1))
        assertEquals("Photo,Text,File", PageLayout.encode(l("PTF"), 1, 1))
        assertEquals("FPTP", s(PageLayout.parse(PageLayout.encode(l("FPTP"), 2, 1), 2, 1)))
    }

    @Test fun removingAndFindingPlaces() {
        assertEquals("PFT", s(PageLayout.without(l("PFPT"), Part.Photo, 1)))
        assertEquals("PPT", s(PageLayout.without(l("PFPT"), Part.File, 0)))
        assertEquals("PT", s(PageLayout.without(l("PT"), Part.File, 0)))
        assertEquals(2, PageLayout.slotOf(l("PFPT"), Part.Photo, 1))
        assertEquals(-1, PageLayout.slotOf(l("PFPT"), Part.File, 1))
        assertEquals(1, PageLayout.kindIndex(l("PFPT"), 2))
    }

    @Test fun neighbouringPlacesOfOneKindAreShownTogether() {
        val r = PageLayout.runs(l("PPFFTPF"))
        assertEquals(listOf("P0x2@0", "F0x2@2", "T0x1@4", "P2x1@5", "F2x1@6"), r.map { "${it.part.name[0]}${it.first}x${it.count}@${it.slot}" })
    }

    @Test fun movingAPlaceAndTheOrderOfItsKind() {
        assertNull(PageLayout.moveResult(l("PFT"), 1, 1))
        assertNull(PageLayout.moveResult(l("PFT"), 1, 2))
        assertNull(PageLayout.moveResult(l("PFT"), 5, 0))
        val bottom = PageLayout.moveResult(l("PFT"), 0, 3)!!
        assertEquals("FTP", s(bottom.layout)); assertEquals(0, bottom.fromKind); assertEquals(0, bottom.toKind)
        val above = PageLayout.moveResult(l("PPT"), 1, 0)!!
        assertEquals(1, above.fromKind); assertEquals(0, above.toKind)
        val below = PageLayout.moveResult(l("FFT"), 0, 2)!!
        assertEquals(0, below.fromKind); assertEquals(1, below.toKind)
        assertEquals("PTFP", s(PageLayout.moveResult(l("PFPT"), 3, 1)!!.layout))
    }

    @Test fun groupsForTheArrangeSheet() {
        assertEquals(listOf(Block.Files, Block.Photos, Block.Text), PageLayout.groups(l("FPFT")))
        assertEquals("TFPP", s(PageLayout.regroup(listOf(Block.Text, Block.Files, Block.Photos), 2, 1)))
        assertEquals("FT", s(PageLayout.regroup(listOf(Block.Files, Block.Photos, Block.Text), 0, 1)))
    }

    private val lay = l("PFFT")
    private val cells = listOf(Cell(0f, 0f, 150f, 100f), Cell(0f, 110f, 400f, 190f), Cell(0f, 198f, 400f, 278f), Cell(0f, 290f, 400f, 700f))

    @Test fun droppingOverFilesAndText() {
        assertEquals(0, PageLayout.dropGap(lay, cells, Part.File, 100f, -20f))
        assertEquals(1, PageLayout.dropGap(lay, cells, Part.File, 100f, 120f))
        assertEquals(2, PageLayout.dropGap(lay, cells, Part.File, 100f, 185f))
        assertEquals(3, PageLayout.dropGap(lay, cells, Part.File, 100f, 300f))
        assertEquals(4, PageLayout.dropGap(lay, cells, Part.File, 100f, 600f))
        assertEquals(4, PageLayout.dropGap(lay, cells, Part.Photo, 100f, 5000f))
    }

    @Test fun aFileGoesAboveOrBelowAWholeRowOfPhotos() {
        assertEquals(0, PageLayout.dropGap(lay, cells, Part.File, 50f, 20f))
        assertEquals(1, PageLayout.dropGap(lay, cells, Part.File, 50f, 80f))
    }

    @Test fun aPhotoCanJoinARowOfPhotos() {
        val row = l("PPPT")
        val rc = listOf(Cell(0f, 0f, 100f, 100f), Cell(100f, 0f, 200f, 100f), Cell(200f, 0f, 300f, 100f), Cell(0f, 110f, 400f, 500f))
        assertEquals(1, PageLayout.dropGap(row, rc, Part.Photo, 120f, 50f))
        assertEquals(3, PageLayout.dropGap(row, rc, Part.Photo, 290f, 50f))
        assertEquals(0, PageLayout.dropGap(row, rc, Part.Photo, 120f, 10f))
        assertEquals(3, PageLayout.dropGap(row, rc, Part.Photo, 120f, 95f))
        val line = PageLayout.dropLine(row, rc, 1)!!
        assertEquals(100f, line.left); assertEquals(line.left, line.right); assertEquals(0f, line.top); assertEquals(100f, line.bottom)
    }

    @Test fun placesThatAreNotDrawnAreSkipped() {
        assertEquals(3, PageLayout.dropGap(lay, listOf(null, null, null, Cell(0f, 290f, 400f, 700f)), Part.File, 100f, 100f))
        assertEquals(4, PageLayout.dropGap(lay, listOf(null, null, null, null), Part.File, 1f, 1f))
    }

    @Test fun theDropLineSitsBetweenNeighbours() {
        val flat = PageLayout.dropLine(lay, cells, 2)!!
        assertEquals(flat.top, flat.bottom); assertEquals(194f, flat.top)
        assertEquals(0f, PageLayout.dropLine(lay, cells, 0)!!.top)
        assertEquals(700f, PageLayout.dropLine(lay, cells, 4)!!.top)
        assertNotNull(PageLayout.dropLine(lay, cells, 1))
    }

    @Test fun movedItemMovesOneEntry() {
        assertEquals(listOf(2, 3, 1), listOf(1, 2, 3).movedItem(0, 2))
        assertEquals(listOf(1, 2, 3), listOf(1, 2, 3).movedItem(2, 2))
    }
}
