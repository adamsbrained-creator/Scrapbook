package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConnectionsTest {
    private fun s(n: Int, title: String, body: String = "", tags: List<String> = emptyList(), box: String = "Inbox", at: Long = n.toLong()) =
        ScrapInfo(n.toLong(), "uid%08d".format(n), title, body, tags, box, at)
    private fun link(n: Int) = "[x](scrapbook://scrap/uid%08d)".format(n)

    @Test fun uidsAreFoundInLinksAndBareAddresses() {
        val t = "see ${link(1)} and scrapbook://scrap/UID00000002 and again ${link(1)}"
        assertEquals(listOf("uid00000001", "uid00000002"), Connections.uidsIn(t))
        assertTrue(Connections.uidsIn("nothing here, https://example.com").isEmpty())
    }

    @Test fun linksToKeepTheOrderAndLeaveOutSelfAndGone() {
        val all = listOf(s(1, "One"), s(2, "Two"), s(3, "Three"))
        val text = "${link(3)} then ${link(2)} then ${link(1)} then ${link(9)}"
        assertEquals(listOf(3L, 2L), Connections.linksTo(text, "uid00000001", all).map { it.id })
        assertEquals(1, Connections.brokenLinks(text, "uid00000001", all))
    }

    @Test fun backlinksAreNewestFirstAndNotSelf() {
        val all = listOf(s(1, "Existentialism", at = 5), s(2, "Camus", "about ${link(1)}", at = 10), s(3, "Quote", "${link(1)}", at = 20), s(4, "Other", "no link"))
        assertEquals(listOf(3L, 2L), Connections.linkedFrom("uid00000001", all).map { it.id })
        assertTrue(Connections.linkedFrom("", all).isEmpty())
        assertTrue(Connections.linkedFrom("uid00000002", all).isEmpty())
    }

    @Test fun titlesAreFoundAsWholeWordsIgnoringCase() {
        val all = listOf(s(1, "Camus"), s(2, "The Stranger"), s(3, "Art"))
        val m = Connections.mentions("I read the stranger by camus. Camusian is not it.", "uid00000099", all)
        assertEquals(listOf("The Stranger", "Camus"), m.map { it.scrap.title })
        assertEquals("the stranger", "I read the stranger by camus. Camusian is not it.".substring(m[0].range.first, m[0].range.last + 1))
        assertTrue(Connections.mentions("part of the artwork", "uid00000099", listOf(s(3, "Art"))).isEmpty())   // too short to suggest
    }

    @Test fun titlesInsideLinksAddressesAndCodeAreIgnored() {
        val all = listOf(s(1, "Camus"))
        assertTrue(Connections.mentions("[Camus](https://x.org) and https://camus.org and `Camus`", "uid00000099", all).isEmpty())
        assertEquals(1, Connections.mentions("[Camus](https://x.org) but also Camus here", "uid00000099", all).size)
    }

    @Test fun alreadyLinkedAndSelfAreNotSuggested() {
        val all = listOf(s(1, "Camus"), s(2, "Sartre"))
        val m = Connections.mentions("Camus and Sartre", "uid00000002", all, skip = setOf("UID00000001"))
        assertTrue(m.isEmpty())
    }

    @Test fun theLongerTitleWinsAnOverlapAndTheNewerScrapAnAmbiguousTitle() {
        val all = listOf(s(1, "Stranger Things"), s(2, "Stranger things", at = 50), s(3, "Things"), s(4, "Stranger Danger"))
        val m = Connections.mentions("Watching stranger things tonight", "uid00000099", all)
        assertEquals(1, m.size)
        assertEquals(2L, m[0].scrap.id)
    }

    @Test fun relatedCountsRareTagsMore() {
        val all = listOf(
            s(1, "Me", tags = listOf("philosophy", "ideas")),
            s(2, "A", tags = listOf("ideas"), at = 1), s(3, "B", tags = listOf("ideas"), at = 2), s(4, "C", tags = listOf("ideas"), at = 3),
            s(5, "Rare", tags = listOf("philosophy"), at = 0), s(6, "None", tags = listOf("food")))
        val r = Connections.related("uid00000001", listOf("philosophy", "ideas"), all)
        assertEquals(5L, r[0].scrap.id)                      // the rare tag outweighs a common one
        assertEquals("Shares #philosophy", r[0].why)
        assertFalse(r.any { it.scrap.id == 6L || it.scrap.id == 1L })
        assertTrue(Connections.related("uid00000001", emptyList(), all).isEmpty())
        assertEquals(1, Connections.related("uid00000001", listOf("philosophy", "ideas"), all, limit = 1).size)
        assertFalse(Connections.related("uid00000001", listOf("philosophy"), all, exclude = setOf("uid00000005")).any { it.scrap.id == 5L })
    }

    @Test fun pickerPutsLikelyScrapsFirstWhenNothingIsTyped() {
        val all = listOf(
            s(1, "Existentialism", "Camus wrote about it", listOf("philosophy")),
            s(2, "Camus", tags = emptyList(), at = 1),
            s(3, "Old shopping", at = 100),
            s(4, "Notes on Sartre", "links back ${link(1)}", at = 2),
            s(5, "Essays", tags = listOf("philosophy"), at = 3))
        val p = Connections.picks("", "uid00000001", all[0].body, listOf("philosophy"), "Inbox", all)
        assertEquals(listOf(2L, 4L, 5L, 3L), p.map { it.scrap.id })
        assertEquals("Its title is in this scrap", p[0].why)
        assertEquals("Links to this scrap", p[1].why)
    }

    @Test fun pickerSearchNeedsEveryWordAndPutsTitleMatchesFirst() {
        val all = listOf(s(1, "Me"), s(2, "Stranger notes", "x"), s(3, "Camus", "the stranger, a book"), s(4, "Unrelated", "nothing"))
        val p = Connections.picks("stran", "uid00000001", "", emptyList(), "Inbox", all)
        assertEquals(listOf(2L, 3L), p.map { it.scrap.id })
        assertTrue(Connections.picks("stranger book", "uid00000001", "", emptyList(), "Inbox", all).map { it.scrap.id } == listOf(3L))
    }

    @Test fun anAlreadyLinkedScrapIsStillOfferedButLowerAndLabelled() {
        val all = listOf(s(1, "Me"), s(2, "Camus", at = 1), s(3, "Sartre", at = 99))
        val p = Connections.picks("", "uid00000001", link(3), emptyList(), "Inbox", all)
        assertEquals(listOf(2L, 3L), p.map { it.scrap.id })
        assertEquals("Already linked", p[1].why)
    }

    @Test fun insertingALinkAtTheCursorSelectionAndBrackets() {
        val uid = "uid00000002"; val url = "scrapbook://scrap/$uid"
        assertEquals("[Camus]($url)", Connections.insertLink("", 0, 0, "Camus", uid).text)
        val atWord = Connections.insertLink("read", 4, 4, "Camus", uid)
        assertEquals("read [Camus]($url)", atWord.text); assertEquals(atWord.text.length, atWord.cursor)
        assertEquals("a [the book]($url) b", Connections.insertLink("a the book b", 2, 10, "Camus", uid).text)
        assertEquals("[Camus]($url)", Connections.insertLink("a\nb", 0, 3, "Camus", uid).text)   // a selection with a line break cannot be the words
        val b = Connections.insertLink("see [[", 6, 6, "Camus", uid, replace = 4..5)
        assertEquals("see [Camus]($url)", b.text); assertEquals(b.text.length, b.cursor)
        assertEquals("[Odd (name)]($url)", Connections.insertLink("", 0, 0, "Odd [name]", uid).text)
    }

    @Test fun aMentionBecomesALinkKeepingTheWrittenWords() {
        val text = "I read the stranger last year"
        val e = Connections.linkMention(text, 7..18, "uid00000002", "The Stranger")!!
        assertEquals("I read [the stranger](scrapbook://scrap/uid00000002) last year", e.text)
        assertNull(Connections.linkMention("I read something else", 7..18, "uid00000002", "The Stranger"))   // the text moved on
        assertNull(Connections.linkMention("short", 7..18, "uid00000002", "The Stranger"))
    }

    @Test fun twoTypedBracketsAreRecognised() {
        assertEquals(4..5, Connections.typedBrackets("see [", "see [[", 6))
        assertEquals(0..1, Connections.typedBrackets("[", "[[", 2))
        assertNull(Connections.typedBrackets("see [", "see [x", 6))
        assertNull(Connections.typedBrackets("see [[", "see [[[", 7))       // a third bracket is not "just typed the pair"
        assertNull(Connections.typedBrackets("see ", "see [", 5))
        assertNull(Connections.typedBrackets("a[", "[a[[", 4))             // pasted, more than one character
    }
}
