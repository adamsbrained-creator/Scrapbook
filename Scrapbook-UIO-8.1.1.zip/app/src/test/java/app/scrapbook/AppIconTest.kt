package app.scrapbook

import app.scrapbook.ui.Themes
import org.junit.Assert.assertEquals
import org.junit.Test

class AppIconTest {
    /** Every accent in Settings needs a launcher icon alias in the manifest, in the same order. */
    @Test fun iconAliasesMatchAccents() = assertEquals(Themes.map { it.name }, AppIcon.names)
}
