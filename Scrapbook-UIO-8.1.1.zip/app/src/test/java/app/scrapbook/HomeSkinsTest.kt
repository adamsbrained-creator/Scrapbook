package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeSkinsTest {
    private val classic = HomeSkins.initial(emptyMap())
    private val boxesGrid = mapOf(SkinKeys.STYLES to "boxesStyle=1")

    @Test fun theClassicLookIsAnEmptySkin() {
        assertEquals(listOf(HomeSkins.CLASSIC_ID), classic.skins.map { it.id })
        assertEquals(HomeSkins.CLASSIC_ID, classic.active)
        assertTrue(classic.current.values.isEmpty())
        assertFalse(classic.current.changed)
    }

    @Test fun everyClassicPieceIsDroppedFromASkin() {
        assertEquals(emptyMap<String, String>(), HomeSkins.sparse(SkinKeys.DEFAULTS))
        assertEquals(mapOf(SkinKeys.HEADER to "2"), HomeSkins.sparse(mapOf(SkinKeys.HEADER to "2", SkinKeys.ADD_BUTTON to "0", "junk" to "1")))
    }

    @Test fun theClassicOrderIsTheDefaultOrder() {
        assertEquals(HomeLayout.Default.encodeOrder(), SkinKeys.DEFAULTS[SkinKeys.ORDER])
        assertEquals(HomeLayout.Default, HomeSkin("x", "x").layout)
    }

    @Test fun settingsThatAreAlreadyClassicStartWithClassicWorn() {
        assertEquals(HomeSkins.CLASSIC_ID, HomeSkins.initial(SkinKeys.DEFAULTS).active)
    }

    @Test fun settingsThatDifferStartWithMyHomeHoldingThemAndWorn() {
        val s = HomeSkins.initial(boxesGrid)
        assertEquals(listOf("classic", "mine"), s.skins.map { it.id })
        assertEquals("mine", s.active)
        assertEquals("My home", s.current.name)
        assertEquals(boxesGrid, s.current.values)
        assertTrue(s.get("classic")!!.values.isEmpty())
    }

    @Test fun theWornSkinAlwaysShowsWhatTheSettingsHoldNow() {
        val live = mapOf(SkinKeys.HEADER to "0")
        val s = classic.withLive(live)
        assertEquals(live, s.current.values)
        assertTrue(s.current.changed)
        assertEquals(live, s.get("classic")!!.values)
    }

    @Test fun takingASkinOffKeepsWhatWasChangedOnIt() {
        val (withNew, mine) = classic.add("Mine", boxesGrid)
        val worn = withNew.withLive(mapOf(SkinKeys.HEADER to "2")).activate(mine.id)!!
        assertEquals(mine.id, worn.active)
        assertEquals(mapOf(SkinKeys.HEADER to "2"), worn.get("classic")!!.values)
        assertEquals(boxesGrid, worn.current.values)
    }

    @Test fun anUnknownSkinCannotBeWorn() {
        assertNull(classic.activate("nope"))
    }

    @Test fun anAddedSkinIsNamedAndNotWornAndGetsAFreshId() {
        val (s, a) = classic.add("Plain", emptyMap())
        val (s2, b) = s.add("Plain", boxesGrid)
        assertEquals("Plain", a.name)
        assertEquals("Plain 2", b.name)
        assertTrue(a.id != b.id)
        assertEquals("classic", s2.active)
        assertEquals(3, s2.skins.size)
        assertEquals(boxesGrid, b.values)
    }

    @Test fun aBlankNameBecomesMySkinAndALongOneIsCut() {
        assertEquals("My skin", classic.add("   ", emptyMap()).second.name)
        assertEquals(HomeSkins.MAX_NAME, classic.add("x".repeat(80), emptyMap()).second.name.length)
    }

    @Test fun uniqueNamesCountUp() {
        assertEquals("A", HomeSkins.uniqueName("A", setOf("B")))
        assertEquals("A 2", HomeSkins.uniqueName("A", setOf("A")))
        assertEquals("A 3", HomeSkins.uniqueName("A", setOf("A", "A 2")))
    }

    @Test fun renamingChangesOnlyThatSkinAndNeverClassic() {
        val (s, a) = classic.add("One", emptyMap())
        val r = s.rename(a.id, "  Two  ")
        assertEquals("Two", r.get(a.id)!!.name)
        assertEquals("Classic", r.rename("classic", "Other").get("classic")!!.name)
        assertEquals(r, r.rename(a.id, "   "))
    }

    @Test fun classicAndTheWornSkinCannotBeDeleted() {
        val (s, a) = classic.add("One", emptyMap())
        assertFalse(s.canDelete("classic"))
        assertTrue(s.canDelete(a.id))
        val worn = s.activate(a.id)!!
        assertFalse(worn.canDelete(a.id))
        assertEquals(worn, worn.delete(a.id))
        assertEquals(listOf("classic"), s.delete(a.id).skins.map { it.id })
    }

    @Test fun resettingASkinEmptiesIt() {
        val (s, a) = classic.add("One", boxesGrid)
        assertTrue(s.reset(a.id).get(a.id)!!.values.isEmpty())
        assertEquals("One", s.reset(a.id).get(a.id)!!.name)
    }

    @Test fun skinsAreSavedAndReadBackTheSame() {
        val (s1, a) = classic.add("Bold & plain", mapOf(SkinKeys.STYLES to "boxesStyle=2,recentCount=3", SkinKeys.SECTIONS to "S|abc|cards||Week%7Cend\nB|Inbox\n", SkinKeys.HEADER to "0"))
        val s = s1.activate(a.id)!!
        val back = HomeSkins.decode(s.encode())
        assertEquals(s, back)
        assertEquals("Bold & plain", back.current.name)
    }

    @Test fun aSavedSkinsSectionsReadBack() {
        val sec = HomeSection("a1", "Week", SectionLayout.Rows, "pinned", listOf(SectionRef(true, "Inbox"), SectionRef(false, "uid1")))
        val (s, a) = classic.add("With a section", mapOf(SkinKeys.SECTIONS to HomeSections.encode(listOf(sec))))
        assertEquals(listOf(sec), HomeSkins.decode(s.encode()).get(a.id)!!.sections)
    }

    @Test fun unreadableSavedTextIsJustClassic() {
        assertEquals(classic, HomeSkins.decode(null))
        assertEquals(classic, HomeSkins.decode(""))
        assertEquals(classic, HomeSkins.decode("garbage\nK|\nV|x\nA"))
    }

    @Test fun classicIsPutBackIfMissingAndAnUnknownWornSkinBecomesClassic() {
        val d = HomeSkins.decode("A|ghost\nK|abc|Mine\nV|header|2\n")
        assertEquals(listOf("classic", "abc"), d.skins.map { it.id })
        assertEquals("classic", d.active)
        assertEquals(mapOf(SkinKeys.HEADER to "2"), d.get("abc")!!.values)
    }

    @Test fun repeatedIdsUnknownPiecesAndClassicRenamesAreIgnored() {
        val d = HomeSkins.decode("A|abc\nK|classic|Renamed\nV|header|2\nK|abc|One\nK|abc|Two\nV|nonsense|1\nV|nav|2\n")
        assertEquals("Classic", d.get("classic")!!.name)
        assertEquals("One", d.get("abc")!!.name)
        assertEquals(2, d.skins.size)
        assertTrue(d.get("abc")!!.values.isEmpty())
    }

    @Test fun aPieceThatIsTheClassicLookIsNotKept() {
        val d = HomeSkins.decode("K|abc|One\nV|header|1\nV|addButton|3\n")
        assertEquals(mapOf(SkinKeys.ADD_BUTTON to "3"), d.get("abc")!!.values)
        assertNotNull(d.get("abc"))
    }

    @Test fun aSkinHoldsItsOwnGestures() {
        val g = GesturePrefs(swipe = false, doubleTap = 0)
        val (list, quiet) = HomeSkins.initial(SkinKeys.DEFAULTS).add("Quiet", mapOf(SkinKeys.GESTURES to g.encode()))
        assertEquals(g, quiet.gestures)
        assertEquals(GesturePrefs(), HomeSkin("x", "x").gestures)
        assertEquals(mapOf(SkinKeys.GESTURES to g.encode()), quiet.values)
        assertEquals(emptyMap<String, String>(), HomeSkins.sparse(mapOf(SkinKeys.GESTURES to GesturePrefs().encode())))
        assertEquals(list, HomeSkins.decode(list.encode()))
    }
}
