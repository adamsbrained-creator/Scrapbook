package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class SortingTest {
    private fun item(id: Long, title: String, created: Long, edited: Long, pinned: Boolean = false) =
        Item(id = id, title = title, body = "", kind = Kind.Note, collection = "Inbox", pinned = pinned, savedAt = edited, createdAt = created)

    // b was made first but edited last; c was made last and never touched again.
    private val a = item(1, "Apple", created = 20, edited = 30)
    private val b = item(2, "banana", created = 10, edited = 50)
    private val c = item(3, "Cherry", created = 40, edited = 40)
    private val all = listOf(a, b, c)

    private fun ids(l: List<Item>) = l.map { it.id }

    @Test fun editedNewestFirst() = assertEquals(listOf(2L, 3L, 1L), ids(all.sortedFor(SortMode.Edited, asc = false)))

    @Test fun createdNewestFirst() = assertEquals(listOf(3L, 1L, 2L), ids(all.sortedFor(SortMode.Created, asc = false)))

    @Test fun createdOldestFirst() = assertEquals(listOf(2L, 1L, 3L), ids(all.sortedFor(SortMode.Created, asc = true)))

    @Test fun titleAToZIgnoresCase() = assertEquals(listOf(1L, 2L, 3L), ids(all.sortedFor(SortMode.Title, asc = true)))

    @Test fun titleZToA() = assertEquals(listOf(3L, 2L, 1L), ids(all.sortedFor(SortMode.Title, asc = false)))

    @Test fun pinnedScrapsStayOnTopInEveryMode() {
        val pinnedOld = item(4, "Zed", created = 1, edited = 1, pinned = true)
        for (m in SortMode.entries) for (asc in listOf(true, false)) assertEquals(4L, (all + pinnedOld).sortedFor(m, asc).first().id)
    }

    @Test fun naturalDirections() {
        assertEquals(true, SortMode.Title.naturalAsc)
        assertEquals(false, SortMode.Created.naturalAsc)
        assertEquals(false, SortMode.Edited.naturalAsc)
    }
}
