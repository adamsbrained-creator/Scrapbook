package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HashtagsTest {
    @Test fun aHashtagIsFound() = assertEquals(listOf("test"), hashtagsIn("buy milk #test today"))

    @Test fun severalAreFoundInOrder() = assertEquals(listOf("a", "b"), hashtagsIn("#a and #b"))

    @Test fun repeatsCountOnceIgnoringCase() = assertEquals(listOf("Idea"), hashtagsIn("#Idea then #idea and #IDEA"))

    @Test fun headingsAreNotHashtags() {
        assertTrue(hashtagsIn("# Title").isEmpty())
        assertTrue(hashtagsIn("## Title").isEmpty())
        assertTrue(hashtagsIn("#").isEmpty())
    }

    @Test fun otherUsesOfTheSignAreNotHashtags() {
        assertTrue(hashtagsIn("I like C# a lot").isEmpty())
        assertTrue(hashtagsIn("room #12").isEmpty())
        assertTrue(hashtagsIn("page#section").isEmpty())
        assertTrue(hashtagsIn("see https://example.com/#top").isEmpty())
    }

    @Test fun aHashtagMayStartALineOrFollowAnOpeningMark() {
        assertEquals(listOf("one", "two"), hashtagsIn("first\n#one\n(#two)"))
        assertEquals(listOf("quoted"), hashtagsIn("\"#quoted\""))
    }

    @Test fun punctuationEndsAHashtag() = assertEquals(listOf("idea", "song"), hashtagsIn("#idea, #song."))

    @Test fun insideAHashtagLettersDigitsUnderscoreAndDashAreKept() = assertEquals(listOf("lyrics_2-draft"), hashtagsIn("#lyrics_2-draft"))

    @Test fun aTrailingDashOrUnderscoreIsNotPartOfIt() = assertEquals(listOf("test"), hashtagsIn("#test- and #test_"))

    @Test fun otherAlphabetsWork() = assertEquals(listOf("музыка"), hashtagsIn("#музыка"))

    @Test fun twoSignsTogetherGiveOnlyTheFirst() = assertEquals(listOf("a"), hashtagsIn("#a#b"))

    @Test fun aVeryLongWordIsNotATag() = assertTrue(hashtagsIn("#" + "a".repeat(41)).isEmpty())

    @Test fun rangesCoverTheSignToo() = assertEquals(listOf(4..8), hashtagRanges("see #idea now"))

    @Test fun theWordUnderTheCursorWaits() {
        assertEquals(listOf("a"), hashtagsIn("#a #be", caret = 6))      // cursor at the end of #be
        assertEquals(listOf("a", "be"), hashtagsIn("#a #be ", caret = 7)) // a space was typed: it counts now
        assertEquals(listOf("be"), hashtagsIn("#a #be", caret = 2))     // cursor in #a
        assertEquals(listOf("a", "be"), hashtagsIn("#a #be", caret = null))
    }

    @Test fun onlyNewHashtagsAreAdded() {
        val handled = hashtagKeys("old #Done #keep")
        assertEquals(setOf("done", "keep"), handled)
        assertEquals(listOf("fresh"), newHashtags("old #done #keep #fresh", null, handled))
    }

    @Test fun nothingIsNewWhenNothingChanged() = assertTrue(newHashtags("#a #b", null, hashtagKeys("#a #b")).isEmpty())

    @Test fun aBoldOrColoredHashtagStillCounts() {
        assertEquals(listOf("bold"), hashtagsIn("**#bold**"))
        assertEquals(listOf("red"), hashtagsIn("{c:ff0000|#red}"))
        assertEquals(listOf("hot"), hashtagsIn("==#hot=="))
    }
}
