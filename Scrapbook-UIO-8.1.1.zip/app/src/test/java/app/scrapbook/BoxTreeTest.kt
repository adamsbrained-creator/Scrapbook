package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class BoxTreeTest {
    private fun names(l: List<Shelf>) = l.inTreeOrder().map { it.first.name to it.second }

    @Test fun boxesInsideComeRightAfterTheirParent() {
        val l = listOf(Shelf("a"), Shelf("b", parent = "a"), Shelf("c"), Shelf("d", parent = "b"))
        assertEquals(listOf("a" to 0, "b" to 1, "d" to 2, "c" to 0), names(l))
    }

    @Test fun aBoxWhoseParentIsGoneStaysOnTheMainPage() {
        assertEquals(listOf("x" to 0), names(listOf(Shelf("x", parent = "missing"))))
    }

    @Test fun nothingIsLostWhenBoxesPointAtEachOther() {
        val l = listOf(Shelf("a", parent = "b"), Shelf("b", parent = "a"))
        assertEquals(setOf("a", "b"), l.inTreeOrder().map { it.first.name }.toSet())
        assertEquals(2, l.inTreeOrder().size)
    }

    @Test fun emptyListIsEmpty() = assertEquals(emptyList<Pair<String, Int>>(), names(emptyList()))
}
