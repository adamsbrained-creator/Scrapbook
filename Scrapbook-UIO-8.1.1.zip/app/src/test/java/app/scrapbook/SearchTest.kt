package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchTest {
    @Test fun termsSplitOnAnySpaceAndDropRepeats() {
        assertEquals(listOf("red", "car"), searchTerms("  red   Car RED "))
        assertEquals(emptyList<String>(), searchTerms("   "))
    }

    @Test fun everyWordMustAppearButInAnyFieldAndOrder() {
        val fields = listOf("Road trip", "we took the car, it was red", "#cars")
        assertTrue(matchesAll(searchTerms("red car"), fields))
        assertTrue(matchesAll(searchTerms("trip RED"), fields))
        assertFalse(matchesAll(searchTerms("red bike"), fields))
        assertTrue(matchesAll(emptyList(), fields))
    }

    @Test fun rangesAreCaseInsensitiveAndSorted() = assertEquals(listOf(0..2, 8..10), matchRanges("Cat and cat", listOf("cat")))

    @Test fun overlappingAndTouchingRangesJoin() {
        assertEquals(listOf(0..5), matchRanges("abcdef", listOf("abcd", "cdef")))
        assertEquals(listOf(0..3), matchRanges("abcd", listOf("ab", "cd")))
    }

    @Test fun positionsDoNotDriftOnLettersThatChangeLengthWhenLowercased() = assertEquals(listOf(9..12), matchRanges("İstanbul city", listOf("city")))

    @Test fun noTermsOrNoMatchGivesNoRanges() {
        assertEquals(emptyList<IntRange>(), matchRanges("hello", emptyList()))
        assertEquals(emptyList<IntRange>(), matchRanges("hello", listOf("xyz")))
        assertEquals(emptyList<IntRange>(), matchRanges("", listOf("a")))
    }

    private val long = "one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty"

    @Test fun shortTextAndTextWithoutMatchAreUnchanged() {
        assertEquals("short text", snippet("short text", listOf("text")))
        assertEquals(long, snippet(long, listOf("zebra")))
    }

    @Test fun matchNearTheStartKeepsTheStart() = assertEquals(long, snippet(long, listOf("three")))

    @Test fun deepMatchIsCentredWithEllipsesAndStaysVisible() {
        val s = snippet(long, listOf("eighteen"))
        assertTrue(s.startsWith("…")); assertTrue(s.contains("eighteen")); assertTrue(s.length < long.length)
        assertTrue(s.removePrefix("…").removeSuffix("…").let { long.contains(it) })
    }

    @Test fun matchAtTheVeryEndHasNoTrailingEllipsis() {
        val s = snippet(long, listOf("twenty"))
        assertTrue(s.startsWith("…")); assertTrue(s.endsWith("twenty"))
    }

    @Test fun extrasListMatchingTagsAndAttachments() {
        assertEquals(listOf("#idea", "plan.pdf"), matchedExtras(listOf("idea", "home"), listOf("plan.pdf", "photo.jpg"), listOf("i", "plan")))
        assertEquals(emptyList<String>(), matchedExtras(listOf("idea"), listOf("a.pdf"), listOf("zzz")))
    }
}
