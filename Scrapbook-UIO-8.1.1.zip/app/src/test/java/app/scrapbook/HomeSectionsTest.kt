package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeSectionsTest {
    private val order = HomeElement.entries.toList()
    private fun sec(id: String, anchor: String = "", vararg refs: SectionRef) = HomeSection(id, "T$id", SectionLayout.Cards, anchor, refs.toList())
    private val scrap = SectionRef(false, "abc123")
    private val box = SectionRef(true, "Trips")

    @Test fun noSectionsMeansTheUsualPage() {
        assertEquals(order.map { HomeSlot.Part(it) }, HomeSections.slots(order, emptyList()))
    }

    @Test fun aSectionSitsRightAfterItsPart() {
        val slots = HomeSections.slots(order, listOf(sec("a", "pinned")))
        val keys = slots.map { it.key }
        assertEquals("section:a", keys[keys.indexOf("pinned") + 1])
        assertEquals(order.size + 1, slots.size)
    }

    @Test fun anAnchorOfNothingIsTheVeryTop() {
        assertEquals("section:a", HomeSections.slots(order, listOf(sec("a", ""))).first().key)
    }

    @Test fun aSectionWhosePartIsGoneGoesLast() {
        assertEquals("section:a", HomeSections.slots(order, listOf(sec("a", "gone"))).last().key)
    }

    @Test fun sectionsWithTheSameAnchorKeepTheirOrder() {
        val keys = HomeSections.slots(order, listOf(sec("a", "boxes"), sec("b", "boxes"))).map { it.key }
        assertEquals(listOf("boxes", "section:a", "section:b", "pinned"), keys.subList(keys.indexOf("boxes"), keys.indexOf("boxes") + 4))
    }

    @Test fun insertingAfterAPartAnchorsToIt() {
        val out = HomeSections.insert(order, emptyList(), sec("n"), "continue")
        assertEquals(1, out.size)
        assertEquals("continue", out[0].anchor)
    }

    @Test fun insertingAfterASectionAnchorsToTheSameAnchorAndComesAfterIt() {
        val first = HomeSections.insert(order, emptyList(), sec("a"), "boxes")
        val both = HomeSections.insert(order, first, sec("b"), "section:a")
        assertEquals(listOf("a", "b"), both.map { it.id })
        assertEquals(listOf("boxes", "boxes"), both.map { it.anchor })
    }

    @Test fun insertingAtTheTopOrAtAnUnknownKey() {
        assertEquals("", HomeSections.insert(order, emptyList(), sec("n"), null)[0].anchor)
        assertEquals("recent", HomeSections.insert(order, emptyList(), sec("n"), "nonsense")[0].anchor)
    }

    @Test fun movingDownPassesOnePart() {
        val s = listOf(sec("a", "boxes"))
        val down = HomeSections.move(order, emptySet(), s, "a", 1)
        assertEquals("pinned", down[0].anchor)
    }

    @Test fun movingUpPassesOnePart() {
        val s = listOf(sec("a", "boxes"))
        val up = HomeSections.move(order, emptySet(), s, "a", -1)
        assertEquals("sort", up[0].anchor)
    }

    @Test fun movingUpPastAnotherSectionGoesBeforeIt() {
        val s = listOf(sec("a", "boxes"), sec("b", "boxes"))
        val out = HomeSections.move(order, emptySet(), s, "b", -1)
        assertEquals(listOf("b", "a"), out.map { it.id })
        assertEquals(listOf("boxes", "boxes"), out.map { it.anchor })
    }

    @Test fun movingStepsOverHiddenParts() {
        val s = listOf(sec("a", "boxes"))
        val down = HomeSections.move(order, setOf(HomeElement.Pinned), s, "a", 1)
        assertEquals("recent", down[0].anchor)
    }

    @Test fun movingAtTheEndsChangesNothing() {
        val last = listOf(sec("a", "recent"))
        assertEquals(last, HomeSections.move(order, emptySet(), last, "a", 1))
        val top = listOf(sec("a", ""))
        assertEquals(top, HomeSections.move(order, emptySet(), top, "a", -1))
        assertEquals(top, HomeSections.move(order, emptySet(), top, "missing", 1))
    }

    @Test fun thingsGoInAndOutOfASectionOnce() {
        val s = listOf(sec("a"), sec("b"))
        val one = HomeSections.withRef(HomeSections.withRef(s, "a", scrap), "a", scrap)
        assertEquals(listOf(scrap), one[0].refs)
        assertTrue(one[1].refs.isEmpty())
        assertTrue(HomeSections.withoutRef(one, "a", scrap)[0].refs.isEmpty())
    }

    @Test fun movingAThingBetweenSectionsTakesItOutOfTheFirst() {
        val s = listOf(sec("a", "", box), sec("b"))
        val out = HomeSections.moveRef(s, "a", "b", box)
        assertTrue(out[0].refs.isEmpty())
        assertEquals(listOf(box), out[1].refs)
        val fresh = HomeSections.moveRef(listOf(sec("a")), null, "a", scrap)
        assertEquals(listOf(scrap), fresh[0].refs)
        assertEquals(listOf(scrap), HomeSections.moveRef(fresh, "a", "a", scrap)[0].refs)
    }

    @Test fun removingASectionKeepsTheRest() {
        assertEquals(listOf("b"), HomeSections.remove(listOf(sec("a"), sec("b")), "a").map { it.id })
    }

    @Test fun aDropGoesAfterTheLastBlockWhoseMiddleIsAboveIt() {
        val blocks = listOf(BlockSpan("pinned", 300f, 400f), BlockSpan("greeting", 0f, 100f), BlockSpan("boxes", 150f, 250f))
        assertEquals("boxes", HomeSections.dropAfter(blocks, 260f))
        assertEquals("greeting", HomeSections.dropAfter(blocks, 120f))
        assertEquals("pinned", HomeSections.dropAfter(blocks, 900f))
        assertNull(HomeSections.dropAfter(blocks, 10f))
        assertNull(HomeSections.dropAfter(emptyList(), 10f))
    }

    @Test fun savingAndReadingBringsEverythingBack() {
        val s = listOf(
            HomeSection("a1", "Reading | now\nnext", SectionLayout.Chips, "pinned", listOf(scrap, box, SectionRef(true, "Inbox"))),
            HomeSection("b2", "", SectionLayout.Grid, "", emptyList()),
            HomeSection("c3", "Ünïcode ✓ 100%", SectionLayout.Rows, "recent", listOf(SectionRef(true, "A/B"))),
        )
        assertEquals(s, HomeSections.decode(HomeSections.encode(s)))
    }

    @Test fun nothingSavedMeansNoSections() {
        assertTrue(HomeSections.decode(null).isEmpty())
        assertTrue(HomeSections.decode("").isEmpty())
        assertTrue(HomeSections.encode(emptyList()).isEmpty())
    }

    @Test fun readingSkipsWhatMakesNoSense() {
        val text = "N|orphan\nS|x\nS|a|cards||Hello\nB|Trips\nB|Trips\nB|\nZ|what\nS|a|chips||Again\nN|late\n"
        val out = HomeSections.decode(text)
        assertEquals(1, out.size)
        assertEquals("a", out[0].id)
        assertEquals("Hello", out[0].title)
        assertEquals(listOf(SectionRef(true, "Trips")), out[0].refs)
    }

    @Test fun anUnknownLayoutFallsBackToCards() {
        assertEquals(SectionLayout.Cards, SectionLayout.of("whatever"))
        assertEquals(SectionLayout.Cards, SectionLayout.of(null))
        assertEquals(SectionLayout.Grid, SectionLayout.of("grid"))
    }

    @Test fun titlesAreTrimmedAndShortened() {
        assertEquals("Hi", HomeSections.cleanTitle("  Hi  "))
        assertEquals(HomeSections.MAX_TITLE, HomeSections.cleanTitle("x".repeat(100)).length)
        assertEquals("New section", HomeSection("a").name)
    }

    @Test fun aPartMovesPastHiddenOnesAndStopsAtTheEnds() {
        val l = HomeLayout.Default.withHidden(HomeElement.Pinned, true)
        val down = l.shifted(HomeElement.Boxes, 1)
        assertEquals(HomeElement.Recent, down.order[down.order.indexOf(HomeElement.Boxes) - 1])
        assertEquals(l, l.shifted(HomeElement.Recent, 1))
        assertEquals(l, l.shifted(HomeElement.Header, -1))
        assertEquals(order.toSet(), down.order.toSet())
    }

    @Test fun movingABlockAcrossThePageKeepsEverySectionNextToItsPart() {
        val s = listOf(sec("a", "boxes"))
        // The section is the block after Boxes; moving it one place down puts it after Pinned. The parts stay as they were.
        val (o1, s1) = HomeSections.reorderSlots(order, s, 6, 7)
        assertEquals(order, o1)
        assertEquals("pinned", s1[0].anchor)
        // Moving the Boxes part (row 5) down past its own section and Pinned: the section stays where it was on the page, so it now follows Sort.
        val (o2, s2) = HomeSections.reorderSlots(order, s, 5, 7)
        assertEquals(order.size, o2.size)
        assertEquals(o2.indexOf(HomeElement.Pinned) + 1, o2.indexOf(HomeElement.Boxes))
        assertEquals("sort", s2[0].anchor)
        // Nothing moves for the same place or for places that are not rows.
        assertEquals(order to s, HomeSections.reorderSlots(order, s, 3, 3))
        assertEquals(order to s, HomeSections.reorderSlots(order, s, 3, 99))
    }

    @Test fun aThingCanBeBroughtToAnotherPlaceInItsSection() {
        val x = SectionRef(false, "x"); val y = SectionRef(true, "y"); val z = SectionRef(false, "z")
        val s = listOf(HomeSection("a", "", SectionLayout.Cards, "", listOf(x, y, z)))
        assertEquals(listOf(z, x, y), HomeSections.reorder(s, "a", z, 0)[0].refs)
        assertEquals(listOf(y, z, x), HomeSections.reorder(s, "a", x, 2)[0].refs)
        assertEquals(listOf(y, z, x), HomeSections.reorder(s, "a", x, 99)[0].refs)
        assertEquals(s, HomeSections.reorder(s, "a", SectionRef(false, "other"), 0))
        assertEquals(s, HomeSections.reorder(s, "missing", x, 0))
    }

    @Test fun everyThingHasItsOwnToken() {
        assertEquals("b:Trips", SectionRef(true, "Trips").token)
        assertEquals("n:Trips", SectionRef(false, "Trips").token)
    }

    @Test fun gestureSettingsSurviveBeingWrittenDown() {
        val g = GesturePrefs(hold = false, drag = true, file = false, empty = true, swipe = false, capture = true, doubleTap = 2, pull = false)
        assertEquals("0,1,0,1,0,1,0,2", g.encode())
        assertEquals(g, GesturePrefs.decode(g.encode()))
        assertEquals("1,1,1,1,1,1,1,1", GesturePrefs().encode())
        assertEquals(GesturePrefs(), GesturePrefs.decode(GesturePrefs().encode()))
    }

    @Test fun unreadableGestureSettingsAreTheUsualOnes() {
        assertEquals(GesturePrefs(), GesturePrefs.decode(null))
        assertEquals(GesturePrefs(), GesturePrefs.decode(""))
        assertEquals(GesturePrefs(), GesturePrefs.decode("junk"))
        assertEquals(GesturePrefs(doubleTap = 2), GesturePrefs.decode("1,1,1,1,1,1,1,2"))
        assertEquals(GesturePrefs.DOUBLE_TAP_OPTIONS.lastIndex, GesturePrefs.decode("1,1,1,1,1,1,1,9").doubleTap)
    }
}
