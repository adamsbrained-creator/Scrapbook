package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecentsTest {
    @Test fun touchMovesToFront() {
        assertEquals(listOf("i3", "i1", "i2"), Recents.touch(listOf("i1", "i2", "i3"), "i3"))
        assertEquals(listOf("i9", "i1"), Recents.touch(listOf("i1"), "i9"))
    }
    @Test fun touchOfTheFirstChangesNothing() {
        val l = listOf("i1", "i2"); assertTrue(Recents.touch(l, "i1") === l)
    }
    @Test fun neverGrowsPastTheLimit() {
        var l = emptyList<String>(); for (i in 1..40) l = Recents.touch(l, "i$i")
        assertEquals(Recents.MAX, l.size); assertEquals("i40", l.first())
    }
    @Test fun encodeDecodeKeepsBoxNamesWithOddCharacters() {
        val l = listOf("i4", "bTrips, 2026 | Italy", "b:x")
        assertEquals(l, Recents.decode(Recents.encode(l)))
        assertEquals(emptyList<String>(), Recents.decode(null)); assertEquals(emptyList<String>(), Recents.decode(""))
    }
    @Test fun keysAreTold() {
        assertEquals(12L, Recents.scrapId(Recents.scrap(12))); assertEquals(null, Recents.scrapId(Recents.box("12")))
        assertEquals("Trips", Recents.boxName(Recents.box("Trips")))
    }
    @Test fun pruneDropsWhatIsGone() {
        assertEquals(listOf("i1", "bA"), Recents.prune(listOf("i1", "i2", "bA", "bB", "junk"), setOf(1L), setOf("A")))
    }
}
