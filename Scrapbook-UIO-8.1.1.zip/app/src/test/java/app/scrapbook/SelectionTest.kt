package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SelectionTest {
    private fun item(id: Long, pinned: Boolean = false, tags: List<String> = emptyList()) =
        Item(id = id, title = "t$id", body = "", kind = Kind.Note, collection = "Inbox", pinned = pinned, tags = tags)

    @Test fun toggleAddsThenRemoves() {
        val one = emptyList<Long>().toggled(5)
        assertEquals(listOf(5L), one)
        assertEquals(listOf(5L, 7L), one.toggled(7))
        assertEquals(emptyList<Long>(), one.toggled(5))
    }

    @Test fun addedNeverRemovesAndNeverDuplicates() {
        assertEquals(listOf(1L, 2L), listOf(1L).added(2))
        assertEquals(listOf(1L, 2L), listOf(1L, 2L).added(2))
    }

    @Test fun picksThatLeftTheScreenDropOut() = assertEquals(listOf(1L, 3L), listOf(1L, 2L, 3L).stillShown(listOf(3L, 1L, 9L)))

    @Test fun labels() { assertEquals("1 scrap", scrapsLabel(1)); assertEquals("3 scraps", scrapsLabel(3)) }

    @Test fun pinButtonUnpinsOnlyWhenEverythingIsPinned() {
        assertFalse(allPinned(emptyList()))
        assertFalse(allPinned(listOf(item(1, true), item(2, false))))
        assertTrue(allPinned(listOf(item(1, true), item(2, true))))
    }

    @Test fun parseTagsTrimsAndDropsEmpties() = assertEquals(listOf("a", "b c"), parseTags(" a , ,b c,"))

    @Test fun mergeKeepsExistingAndSkipsCaseInsensitiveDuplicates() {
        assertEquals(listOf("Work", "idea", "new"), mergeTags(listOf("Work", "idea"), listOf("work", "IDEA", "new", "New")))
    }

    @Test fun mergeIntoNoTagsAddsAll() = assertEquals(listOf("x", "y"), mergeTags(emptyList(), listOf("x", "y")))

    @Test fun topTagsMostUsedFirstThenAlphabetical() {
        val l = listOf(item(1, tags = listOf("b", "a")), item(2, tags = listOf("B", "c")), item(3, tags = listOf("c", "b")))
        assertEquals(listOf("b", "c", "a"), topTags(l))
        assertEquals(listOf("b"), topTags(l, limit = 1))
    }

    @Test fun appendTagBuildsACommaList() {
        assertEquals("one", appendTag("", "one"))
        assertEquals("one, two", appendTag("one", "two"))
        assertEquals("one, two", appendTag("one, ", "two"))
    }
}
