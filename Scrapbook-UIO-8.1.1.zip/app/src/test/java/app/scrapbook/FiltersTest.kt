package app.scrapbook

import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FiltersTest {
    private val utc = TimeZone.getTimeZone("UTC")
    private val day = 86_400_000L
    private val now = 100 * day + 15 * 3_600_000L   // 15:00 on day 100

    private fun item(id: Long, kind: Kind = Kind.Note, box: String = "Inbox", tags: List<String> = emptyList(), edited: Long = now, created: Long = now) =
        Item(id = id, title = "t$id", body = "", kind = kind, collection = box, tags = tags, savedAt = edited, createdAt = created)

    private fun ids(l: List<Item>) = l.map { it.id }

    @Test fun nothingOnShowsEverything() {
        val all = listOf(item(1), item(2))
        assertTrue(all.filteredBy(ScrapFilter(), now, utc) === all)
    }

    @Test fun typeFilter() = assertEquals(listOf(2L), ids(listOf(item(1), item(2, kind = Kind.Quote)).filteredBy(ScrapFilter(kind = Kind.Quote), now, utc)))

    @Test fun boxFilter() = assertEquals(listOf(2L), ids(listOf(item(1), item(2, box = "Music")).filteredBy(ScrapFilter(box = "Music"), now, utc)))

    @Test fun aTagCutsAcrossBoxes() {
        val all = listOf(item(1, box = "Music", tags = listOf("unfinished")), item(2, box = "Work", tags = listOf("Unfinished")), item(3, box = "Music"))
        assertEquals(listOf(1L, 2L), ids(all.filteredBy(ScrapFilter(tags = setOf("unfinished")), now, utc)))
    }

    @Test fun severalTagsMeansAllOfThem() {
        val all = listOf(item(1, tags = listOf("unfinished", "lyrics")), item(2, tags = listOf("unfinished")), item(3, tags = listOf("lyrics", "inspiration", "unfinished")))
        assertEquals(listOf(1L, 3L), ids(all.filteredBy(ScrapFilter(tags = setOf("unfinished", "lyrics")), now, utc)))
    }

    @Test fun filtersCombine() {
        val all = listOf(item(1, box = "Music", tags = listOf("lyrics")), item(2, box = "Music", kind = Kind.Quote, tags = listOf("lyrics")), item(3, box = "Work", tags = listOf("lyrics")))
        assertEquals(listOf(2L), ids(all.filteredBy(ScrapFilter(kind = Kind.Quote, box = "Music", tags = setOf("lyrics")), now, utc)))
    }

    @Test fun todayStartsAtMidnight() {
        val all = listOf(item(1, edited = 100 * day + 1), item(2, edited = 100 * day - 1))
        assertEquals(listOf(1L), ids(all.filteredBy(ScrapFilter(range = DateRange.Today), now, utc)))
    }

    @Test fun weekMonthAndYearLookBack() {
        val all = listOf(item(1, edited = now - 6 * day), item(2, edited = now - 20 * day), item(3, edited = now - 200 * day))
        assertEquals(listOf(1L), ids(all.filteredBy(ScrapFilter(range = DateRange.Week), now, utc)))
        assertEquals(listOf(1L, 2L), ids(all.filteredBy(ScrapFilter(range = DateRange.Month), now, utc)))
        assertEquals(listOf(1L, 2L, 3L), ids(all.filteredBy(ScrapFilter(range = DateRange.Year), now, utc)))
    }

    @Test fun theDateFieldDecidesWhichDateCounts() {
        val old = item(1, edited = now, created = now - 60 * day)
        assertEquals(listOf(1L), ids(listOf(old).filteredBy(ScrapFilter(range = DateRange.Week, field = DateField.Edited), now, utc)))
        assertTrue(listOf(old).filteredBy(ScrapFilter(range = DateRange.Week, field = DateField.Created), now, utc).isEmpty())
    }

    @Test fun countsEachKindOfFilterOnce() {
        assertEquals(0, ScrapFilter().count)
        assertFalse(ScrapFilter().isOn)
        assertEquals(3, ScrapFilter(kind = Kind.Link, tags = setOf("a", "b"), range = DateRange.Month).count)
    }

    @Test fun togglingATagIgnoresCase() {
        val f = ScrapFilter().toggleTag("Lyrics")
        assertTrue(f.hasTag("lyrics"))
        assertTrue(f.toggleTag("lyrics").tags.isEmpty())
    }

    @Test fun aFilterSurvivesBeingWrittenAndRead() {
        val f = ScrapFilter(Kind.Quote, "Music", setOf("unfinished", "lyrics"), DateRange.Week, DateField.Created)
        assertEquals(f, decodeFilter(f.encode()))
        assertEquals(ScrapFilter(), decodeFilter(ScrapFilter().encode()))
    }

    @Test fun unreadableTextGivesTheEmptyFilter() {
        assertEquals(ScrapFilter(), decodeFilter(null))
        assertEquals(ScrapFilter(), decodeFilter("garbage"))
    }
}
