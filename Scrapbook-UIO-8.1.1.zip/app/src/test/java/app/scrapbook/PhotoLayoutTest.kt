package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class PhotoLayoutTest {
    @Test fun aSinglePhotoSpansThePage() = assertEquals(371, plainPhotoWidth(411, 1))

    @Test fun severalPhotosLeaveRoomForTheNextToPeekIn() = assertEquals(331, plainPhotoWidth(411, 3))

    @Test fun noPhotosCountsAsOne() = assertEquals(371, plainPhotoWidth(411, 0))

    @Test fun aTinyScreenStillGetsAUsableWidth() = assertEquals(160, plainPhotoWidth(180, 2))
}
