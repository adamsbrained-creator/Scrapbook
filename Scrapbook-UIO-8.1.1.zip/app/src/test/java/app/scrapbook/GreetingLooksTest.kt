package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GreetingLooksTest {
    @Test fun theThreeFirstLayoutsAreStillWhereTheyWere() {
        assertEquals(listOf("Classic", "Centered", "Card"), HomeStyleKey.GreetingStyle.options.take(3))
        assertEquals(listOf("Bubble", "Banner", "Minimal"), HomeStyleKey.GreetingStyle.options.drop(3))
    }

    @Test fun theNewChoicesStartAtTheirFirstOptionAndBelongToTheGreeting() {
        listOf(HomeStyleKey.GreetingBackground, HomeStyleKey.GreetingShape, HomeStyleKey.GreetingAnimation).forEach {
            assertEquals(HomeElement.Greeting, it.element); assertEquals(0, it.default)
        }
        assertEquals(7, HomeStyleKey.GreetingBackground.options.size)
        assertEquals(3, HomeStyleKey.GreetingShape.options.size)
        assertEquals(4, HomeStyleKey.GreetingAnimation.options.size)
    }

    @Test fun choicesSavedBeforeTheNewOnesStillRead() {
        val s = HomeStyles.decode("greetStyle=2,greetPic=1")
        assertEquals(2, s[HomeStyleKey.GreetingStyle]); assertEquals(1, s[HomeStyleKey.GreetingPicture])
        assertEquals(0, s[HomeStyleKey.GreetingBackground]); assertEquals(0, s[HomeStyleKey.GreetingShape]); assertEquals(0, s[HomeStyleKey.GreetingAnimation])
    }

    @Test fun theNewChoicesAreSavedAndReadBack() {
        val text = "greetStyle=5,greetBg=6,greetShape=2,greetAnim=3"
        val s = HomeStyles.decode(text)
        assertEquals(5, s[HomeStyleKey.GreetingStyle]); assertEquals(6, s[HomeStyleKey.GreetingBackground])
        assertEquals(2, s[HomeStyleKey.GreetingShape]); assertEquals(3, s[HomeStyleKey.GreetingAnimation])
        assertEquals(text, s.encode())
    }

    @Test fun aChoiceOutOfRangeIsBroughtBack() {
        assertEquals(6, HomeStyles.decode("greetBg=99")[HomeStyleKey.GreetingBackground])
        assertEquals(HomeStyles.Default, HomeStyles.decode("greetAnim=0,greetShape=0"))
    }

    @Test fun theSummaryAndTheWayBackCoverTheNewChoices() {
        val s = HomeStyles.Default.with(HomeStyleKey.GreetingStyle, 5).with(HomeStyleKey.GreetingShape, 1)
        assertEquals("Minimal · Squircle", s.summary(HomeElement.Greeting))
        assertTrue(s.reset(HomeElement.Greeting).isDefault(HomeElement.Greeting))
    }
}
