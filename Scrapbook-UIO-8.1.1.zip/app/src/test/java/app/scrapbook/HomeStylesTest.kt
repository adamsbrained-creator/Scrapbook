package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeStylesTest {
    @Test fun nothingChosenIsTheClassicHome() {
        val s = HomeStyles.Default
        HomeElement.entries.forEach { assertTrue(s.isDefault(it)) }
        assertEquals("", s.encode())
        HomeStyleKey.entries.forEach { assertEquals(it.default, s[it]) }
    }

    @Test fun everyChoiceHasAHintAndADefaultThatIsAnOption() {
        HomeStyleKey.entries.forEach {
            assertEquals(it.name, it.options.size, it.hints.size)
            assertTrue(it.name, it.default in it.options.indices)
        }
    }

    @Test fun sizesStartAtRegularAndStylesAtTheFirstOption() {
        assertEquals("Regular", HomeStyleKey.PinnedSize.options[HomeStyleKey.PinnedSize.default])
        assertEquals("4", HomeStyleKey.RecentCount.options[HomeStyleKey.RecentCount.default])
        assertEquals(0, HomeStyleKey.BoxesStyle.default)
    }

    @Test fun aChoiceChangesOnlyItsOwnPart() {
        val s = HomeStyles.Default.with(HomeStyleKey.BoxesStyle, 1)
        assertEquals(1, s[HomeStyleKey.BoxesStyle])
        assertFalse(s.isDefault(HomeElement.Boxes))
        assertTrue(s.isDefault(HomeElement.Pinned))
        assertEquals("Grid", s.summary(HomeElement.Boxes))
    }

    @Test fun choosingTheDefaultAgainDropsTheChoice() {
        val s = HomeStyles.Default.with(HomeStyleKey.PinnedSize, 2).with(HomeStyleKey.PinnedSize, 1)
        assertEquals(HomeStyles.Default, s)
        assertEquals("", s.encode())
    }

    @Test fun anOutOfRangeChoiceIsBroughtBackIntoRange() {
        assertEquals(HomeStyleKey.GreetingStyle.options.lastIndex, HomeStyles.Default.with(HomeStyleKey.GreetingStyle, 99)[HomeStyleKey.GreetingStyle])
        assertEquals(HomeStyles.Default, HomeStyles.Default.with(HomeStyleKey.GreetingStyle, -5))
    }

    @Test fun resettingAPartLeavesTheOthersAlone() {
        val s = HomeStyles.Default.with(HomeStyleKey.RecentStyle, 1).with(HomeStyleKey.RecentCount, 3).with(HomeStyleKey.BoxesStyle, 2)
        val r = s.reset(HomeElement.Recent)
        assertTrue(r.isDefault(HomeElement.Recent))
        assertEquals(2, r[HomeStyleKey.BoxesStyle])
    }

    @Test fun theSummaryListsWhatDiffersInOrder() {
        val s = HomeStyles.Default.with(HomeStyleKey.GreetingStyle, 1).with(HomeStyleKey.GreetingPicture, 1)
        assertEquals("Centered · Left", s.summary(HomeElement.Greeting))
        assertEquals("", s.summary(HomeElement.Capture))
    }

    @Test fun choicesAreSavedAndReadBackTheSame() {
        val s = HomeStyles.Default.with(HomeStyleKey.PinnedStyle, 2).with(HomeStyleKey.RecentCount, 0).with(HomeStyleKey.GreetingPicture, 1)
        assertEquals("greetPic=1,pinnedStyle=2,recentCount=0", s.encode())
        assertEquals(s, HomeStyles.decode(s.encode()))
    }

    @Test fun unreadableSavedTextFallsBackToTheClassicHome() {
        assertEquals(HomeStyles.Default, HomeStyles.decode(null))
        assertEquals(HomeStyles.Default, HomeStyles.decode(""))
        assertEquals(HomeStyles.Default, HomeStyles.decode("wat=1,,boxesStyle=x,=3,pinnedSize"))
    }

    @Test fun savedChoicesEqualToTheDefaultAreDroppedAndBadNumbersFixed() {
        assertEquals(HomeStyles.Default, HomeStyles.decode("boxesStyle=0,pinnedSize=1"))
        assertEquals(2, HomeStyles.decode("boxesStyle=40")[HomeStyleKey.BoxesStyle])
    }

    @Test fun countsReadTheirNumber() {
        assertEquals(6, HomeStyleKey.RecentCount.number(2))
        assertEquals(0, HomeStyleKey.BoxesStyle.number(1))
    }

    @Test fun onlyThePartsWithDesignsTheGreetingAndTheHeaderHaveOptions() {
        assertTrue(HomeElement.Greeting.hasOptions)
        assertTrue(HomeElement.Header.hasOptions)
        assertFalse(HomeElement.Sort.hasOptions)
        HomeStyleKey.entries.forEach { assertTrue(it.element.hasOptions) }
    }
}
