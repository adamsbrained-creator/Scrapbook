package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InboxTest {
    private val day = 86_400_000L
    private fun item(id: Long, box: String = "Inbox", created: Long = 0, pinned: Boolean = false, deleted: Long = 0) =
        Item(id = id, title = "t$id", body = "", kind = Kind.Note, collection = box, pinned = pinned, createdAt = created, deletedAt = deleted)

    @Test fun onlyUnpinnedInboxScrapsWaitAndOldestComesFirst() {
        val l = listOf(item(1, created = 30), item(2, created = 10), item(3, box = "Ideas"), item(4, pinned = true), item(5, deleted = 99), item(6, created = 20))
        assertEquals(listOf(2L, 6L, 1L), l.toSort().map { it.id })
    }

    @Test fun nothingWaitingGivesZeroDays() = assertEquals(0, oldestWaitingDays(emptyList(), 10 * day))

    @Test fun oldestWaitingDaysCountsWholeDays() {
        val l = listOf(item(1, created = 10 * day), item(2, created = 3 * day + 5))
        assertEquals(7, oldestWaitingDays(l, 10 * day + 1000))
    }

    @Test fun aClockBehindTheScrapNeverGoesNegative() = assertEquals(0, oldestWaitingDays(listOf(item(1, created = 50 * day)), 10 * day))

    @Test fun newScrapIntoHiddenInboxBringsItBack() = assertTrue(revealsInbox(true, null, "Inbox"))

    @Test fun scrapMovedIntoHiddenInboxBringsItBack() = assertTrue(revealsInbox(true, "Ideas", "Inbox"))

    @Test fun editingAScrapAlreadyInInboxLeavesItHidden() = assertFalse(revealsInbox(true, "Inbox", "Inbox"))

    @Test fun visibleInboxOrOtherBoxesChangeNothing() {
        assertFalse(revealsInbox(false, null, "Inbox"))
        assertFalse(revealsInbox(true, null, "Ideas"))
    }
}
