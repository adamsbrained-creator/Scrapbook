package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BoxNamesTest {
    // Binder and Scrapbook each hold a box called "tests". The second one gets another key; both read "tests".
    private val two = listOf(
        Shelf("Binder"), Shelf("Scrapbook"),
        Shelf("tests", parent = "Binder", title = "tests"), Shelf("tests 2", parent = "Scrapbook", title = "tests"),
    )

    @Test fun aBoxWithoutATitleShowsItsName() = assertEquals("Trips", Shelf("Trips").label)
    @Test fun aTitleWinsOverTheKey() = assertEquals("Italy", Shelf("Italy 2", title = "Italy").label)

    @Test fun theSameTitleCanLiveUnderTwoParents() {
        val l = listOf(Shelf("Binder"), Shelf("Scrapbook"), Shelf("tests", parent = "Binder"))
        assertFalse(l.titleTaken("tests", "Scrapbook"))
        assertTrue(l.titleTaken("tests", "Binder"))
        assertTrue(l.titleTaken("TESTS", "Binder"))
    }

    @Test fun aBoxDoesNotClashWithItself() {
        val l = listOf(Shelf("Binder"), Shelf("tests", parent = "Binder"))
        assertFalse(l.titleTaken("tests", "Binder", ignoring = "tests"))
    }

    @Test fun titleClashIsCheckedAgainstTheShownTitleNotTheKey() {
        val l = listOf(Shelf("tests 2", parent = "Scrapbook", title = "tests"))
        assertTrue(l.titleTaken("tests", "Scrapbook"))
        assertFalse(l.titleTaken("tests 2", "Scrapbook"))
    }

    @Test fun newKeyIsTheTitleWhenFree() = assertEquals("Trips", emptyList<Shelf>().newKey("Trips"))
    @Test fun newKeyAddsANumberWhenTaken() = assertEquals("tests 2", listOf(Shelf("tests")).newKey("tests"))
    @Test fun newKeySkipsNumbersAlreadyTaken() = assertEquals("tests 3", listOf(Shelf("tests"), Shelf("tests 2")).newKey("tests"))
    @Test fun newKeyIgnoresCapitals() = assertEquals("Tests 2", listOf(Shelf("tests")).newKey("Tests"))
    @Test fun newKeyIsNeverABuiltInName() { assertEquals("recent 2", emptyList<Shelf>().newKey("recent")); assertEquals("All 2", emptyList<Shelf>().newKey(" All ")) }

    @Test fun builtInNamesAreReserved() {
        listOf("Inbox", "All", "Pinned", "Recent", "inbox", " RECENT ").forEach { assertTrue(it, isReservedBoxName(it)) }
        listOf("Trips", "Allies", "Pinned things", "").forEach { assertFalse(it, isReservedBoxName(it)) }
    }

    @Test fun pathListsBoxesOutermostFirst() {
        val l = listOf(Shelf("Trips"), Shelf("Italy", parent = "Trips"), Shelf("Rome", parent = "Italy"))
        assertEquals(listOf("Trips", "Italy", "Rome"), l.pathTo("Rome").map { it.name })
        assertEquals("Trips › Italy › Rome", l.pathOf("Rome"))
        assertEquals("Trips", l.pathOf("Trips"))
    }

    @Test fun pathUsesTitlesNotKeys() = assertEquals("Scrapbook › tests", two.pathOf("tests 2"))
    @Test fun aKeyWithNoBoxIsShownAsItIs() { assertEquals("Inbox", two.labelOf("Inbox")); assertEquals("Inbox", two.pathOf("Inbox")); assertEquals("Inbox", two.displayName("Inbox")) }
    @Test fun pathStopsOnALoop() {
        val l = listOf(Shelf("a", parent = "b"), Shelf("b", parent = "a"))
        assertEquals(2, l.pathTo("a").size)
    }

    @Test fun displayNameIsTheTitleUntilTwoBoxesShareIt() {
        assertEquals("Binder", two.displayName("Binder"))
        assertEquals("Binder › tests", two.displayName("tests"))
        assertEquals("Scrapbook › tests", two.displayName("tests 2"))
        assertEquals("tests", listOf(Shelf("tests", parent = "Binder"), Shelf("Binder")).displayName("tests"))
    }

    @Test fun aBoxCannotMoveIntoItselfOrItsOwnInsides() {
        val l = listOf(Shelf("Trips"), Shelf("Italy", parent = "Trips"), Shelf("Rome", parent = "Italy"), Shelf("Work"))
        assertFalse(l.canMoveInto("Trips", "Trips"))
        assertFalse(l.canMoveInto("Trips", "Italy"))
        assertFalse(l.canMoveInto("Trips", "Rome"))
        assertTrue(l.canMoveInto("Rome", "Work"))
        assertTrue(l.canMoveInto("Italy", "Work"))
        assertTrue(l.canMoveInto("Rome", "Trips"))
        assertTrue(l.canMoveInto("Rome", ""))
    }

    @Test fun movingBackOutToTheMainPageIsAlwaysAllowed() {
        val l = listOf(Shelf("Trips"), Shelf("Italy", parent = "Trips"))
        assertTrue(l.canMoveInto("Italy", ""))
        assertTrue(l.canMoveInto("Trips", ""))
    }

    @Test fun subtreeIsTheBoxAndEverythingInIt() {
        val l = listOf(Shelf("Trips"), Shelf("Italy", parent = "Trips"), Shelf("Rome", parent = "Italy"), Shelf("Work"))
        assertEquals(setOf("Trips", "Italy", "Rome"), l.subtreeKeys("Trips").toSet())
        assertEquals(listOf("Work"), l.subtreeKeys("Work"))
        assertEquals(setOf("Italy", "Rome"), l.subtreeKeys("Italy").toSet())
    }

    @Test fun insideGivesTheMainPageOrTheDirectChildren() {
        val l = listOf(Shelf("Trips"), Shelf("Italy", parent = "Trips"), Shelf("Rome", parent = "Italy"), Shelf("Work"))
        assertEquals(setOf("Trips", "Work"), l.inside("").map { it.name }.toSet())
        assertEquals(listOf("Italy"), l.inside("Trips").map { it.name })
    }
}
