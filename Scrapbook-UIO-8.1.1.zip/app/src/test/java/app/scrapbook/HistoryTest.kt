package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HistoryTest {
    /** The snapshot here is just the text, as a String. */
    private fun history(maxSteps: Int = 200, maxCost: Int = 2_000_000) = History<String>({ it.length }, maxSteps, maxCost)

    /** Types one character at a time, every 100 ms, like fast typing. Returns the text after. */
    private fun type(h: History<String>, from: String, chars: String, startAt: Long): String {
        var text = from; var t = startAt
        for (c in chars) { h.record(text, "Typing", t, key = "text", merge = true); text += c; t += 100 }
        return text
    }

    @Test fun fastTypingIsOneStep() {
        val h = history()
        val text = type(h, "", "hello", 1000)
        assertEquals("", h.undo(text))
        assertNull(h.undo(""))
    }

    @Test fun aPauseStartsANewStep() {
        val h = history()
        var text = type(h, "", "one", 1000)
        text = type(h, text, " two", 5000)
        assertEquals("one", h.undo(text))
        assertEquals("", h.undo("one"))
    }

    @Test fun aStepNeverGrowsPastAFewSeconds() {
        val h = history()
        // 100 characters, 100 ms apart: ten seconds without a pause.
        val text = type(h, "", "a".repeat(100), 1000)
        // Steps of 41, 41 and 18 characters: the first undo takes back only the last 18.
        assertEquals(82, h.undo(text)!!.length)
        var steps = 1; var cur = ""
        var next = h.undo("a".repeat(82))
        while (next != null) { cur = next; steps++; next = h.undo(cur) }
        assertEquals(3, steps)
        assertEquals("", cur)
    }

    @Test fun undoThenRedoComesBackToTheSameText() {
        val h = history()
        val text = type(h, "", "hello", 1000)
        val before = h.undo(text)!!
        assertEquals(text, h.redo(before))
        assertNull(h.redo(text))
    }

    @Test fun aNewChangeClearsRedo() {
        val h = history()
        val text = type(h, "", "hello", 1000)
        val before = h.undo(text)!!
        assertEquals("Typing", h.redoLabel)
        h.record(before, "Title", 9000)
        assertNull(h.redoLabel)
    }

    @Test fun typingRightAfterAnUndoIsANewStep() {
        val h = history()
        var text = type(h, "", "abc", 1000)
        text = h.undo(text)!!                       // back to ""
        text = type(h, text, "xyz", 1200)           // well inside the pause of the last typing
        assertEquals("", h.undo(text))              // one undo takes back xyz, nothing more
        assertNull(h.undo(""))
    }

    @Test fun typingRightAfterAnUndoDoesNotMergeIntoTheStepBefore() {
        val h = history()
        var text = type(h, "", "abc", 1000)
        text = type(h, text, "def", 3000)                                   // a second step
        text = h.undo(text)!!                                               // back to "abc"
        h.record(text, "Typing", 3300, key = "text", merge = true); text += "x"   // 100 ms after the last keystroke
        assertEquals("abc", h.undo(text))                                   // the undo takes back only the "x"
        assertEquals("", h.undo("abc"))                                     // and "abc" is still its own step
    }

    @Test fun otherChangesAreStepsOfTheirOwnAndKeepTheirNames() {
        val h = history()
        h.record("a", "Photo added", 1000)
        h.record("a+photo", "Photo removed", 1050)
        assertEquals("Photo removed", h.undoLabel)
        assertEquals("a+photo", h.undo("a"))
        assertEquals("Photo added", h.undoLabel)
        assertEquals("a", h.undo("a+photo"))
        assertNull(h.undoLabel)
    }

    @Test fun mergeOnlyWithTheSameKind() {
        val h = history()
        h.record("", "Typing", 1000, key = "text", merge = true)
        h.record("a", "Title", 1100, merge = true)          // a different kind, so a new step
        assertEquals("Title", h.undoLabel)
        assertEquals("a", h.undo("ab"))
        assertEquals("Typing", h.undoLabel)
    }

    @Test fun anEnterCanStartANewStepAndTypingAfterItJoinsIt() {
        val h = history()
        h.record("", "Typing", 1000, key = "text", merge = true)
        h.record("a", "Typing", 1100, key = "text", merge = false)     // Enter: forced new step
        h.record("a\n", "Typing", 1200, key = "text", merge = true)    // next letter joins the Enter step
        assertEquals("a", h.undo("a\nb"))
        assertEquals("", h.undo("a"))
    }

    @Test fun theOldestStepsAreDroppedPastTheLimit() {
        val h = history(maxSteps = 3)
        for (i in 1..10) h.record("s$i", "Color", i * 10_000L)
        var n = 0; var cur = "end"
        while (true) { cur = h.undo(cur) ?: break; n++ }
        assertEquals(3, n)
        assertEquals("s8", cur)
    }

    @Test fun veryBigSnapshotsAreDroppedButTheLatestStepIsKept() {
        val h = history(maxCost = 100)
        h.record("x".repeat(60), "Typing", 1000)
        h.record("y".repeat(60), "Color", 2000)
        h.record("z".repeat(60), "Box", 3000)
        assertEquals("z".repeat(60), h.undo("now"))
        assertNull(h.undo("z".repeat(60)))
    }
}
