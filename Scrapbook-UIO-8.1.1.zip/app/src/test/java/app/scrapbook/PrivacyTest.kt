package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PrivacyTest {
    private val salt = ByteArray(16) { it.toByte() }
    private fun rec(pin: String) = makePinRecord(pin, salt, iterations = 1000)

    @Test fun aPinIsFourToEightDigits() {
        assertTrue(validPin("1234")); assertTrue(validPin("12345678"))
        assertFalse(validPin("123")); assertFalse(validPin("123456789")); assertFalse(validPin("12a4")); assertFalse(validPin("")); assertFalse(validPin("12 4"))
    }

    @Test fun theRightPinChecksOutAndOthersDoNot() {
        val r = rec("4821")
        assertTrue(checkPinRecord("4821", r))
        assertFalse(checkPinRecord("4822", r)); assertFalse(checkPinRecord("482", r)); assertFalse(checkPinRecord("48210", r)); assertFalse(checkPinRecord("", r))
    }

    @Test fun theSavedTextDoesNotContainThePin() = assertFalse(rec("4821").split(":").drop(1).any { it.contains("4821") })

    @Test fun differentSaltsGiveDifferentRecordsForTheSamePin() {
        val a = makePinRecord("4821", ByteArray(16) { 1 }, 1000); val b = makePinRecord("4821", ByteArray(16) { 2 }, 1000)
        assertNotEquals(a, b); assertTrue(checkPinRecord("4821", a)); assertTrue(checkPinRecord("4821", b))
    }

    @Test fun unreadableRecordsNeverUnlock() {
        assertFalse(checkPinRecord("1234", null)); assertFalse(checkPinRecord("1234", "")); assertFalse(checkPinRecord("1234", "garbage"))
        assertFalse(checkPinRecord("1234", "4:1000:zz:zz")); assertFalse(checkPinRecord("1234", "4:0:00:00")); assertFalse(checkPinRecord("1234", "4:abc:00:00"))
    }

    @Test fun theLengthIsReadFromTheRecord() {
        assertEquals(4, pinLength(rec("4821"))); assertEquals(8, pinLength(rec("12345678")))
        assertNull(pinLength(null)); assertNull(pinLength("")); assertNull(pinLength("3:1:aa:bb")); assertNull(pinLength("x:1:aa:bb"))
    }

    @Test fun waitingStartsAtTheFifthWrongTryAndDoublesToACap() {
        assertEquals(0L, lockoutMs(0)); assertEquals(0L, lockoutMs(4))
        assertEquals(30_000L, lockoutMs(5)); assertEquals(60_000L, lockoutMs(6)); assertEquals(120_000L, lockoutMs(7))
        assertEquals(480_000L, lockoutMs(9)); assertEquals(480_000L, lockoutMs(50))
    }

    @Test fun theRemainingWaitCountsDownAndNeverExceedsTheWait() {
        assertEquals(20_000L, lockoutRemainingMs(5, lastFailAt = 1_000, now = 11_000))
        assertEquals(0L, lockoutRemainingMs(5, 1_000, 40_000))
        assertEquals(0L, lockoutRemainingMs(3, 1_000, 1_000))
        assertEquals(30_000L, lockoutRemainingMs(5, lastFailAt = 9_999_999, now = 1_000))
    }

    @Test fun lockAgainOnlyWhenProtectedAndAwayLongEnough() {
        assertTrue(shouldRelock(true, 60_000, 60_000)); assertTrue(shouldRelock(true, 5_000, 0))
        assertFalse(shouldRelock(true, 59_999, 60_000)); assertFalse(shouldRelock(false, 999_999, 0))
    }

    @Test fun hidingABoxHidesEverythingInsideIt() {
        val s = listOf(Shelf("a", hidden = true), Shelf("b", parent = "a"), Shelf("c", parent = "b"), Shelf("d"), Shelf("e", parent = "d"))
        assertEquals(setOf("a", "b", "c"), hiddenBoxNames(s))
        assertEquals(emptySet<String>(), hiddenBoxNames(listOf(Shelf("x"), Shelf("y", parent = "x"))))
    }

    @Test fun aBoxLoopCannotHangTheHiding() = assertEquals(setOf("a", "b"), hiddenBoxNames(listOf(Shelf("a", parent = "b", hidden = true), Shelf("b", parent = "a"))))

    private fun item(box: String) = Item(title = "t", body = "", kind = Kind.Note, collection = box)

    @Test fun lockedHiddenBoxesDropOutOfEveryList() {
        val all = listOf(item("Inbox"), item("secret"), item("open"), item("secret"))
        assertEquals(listOf("Inbox", "open"), visibleItems(all, setOf("secret"), unlocked = false).map { it.collection })
        assertEquals(4, visibleItems(all, setOf("secret"), unlocked = true).size)
        assertEquals(4, visibleItems(all, emptySet(), unlocked = false).size)
    }
}
