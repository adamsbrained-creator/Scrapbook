package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TagsTest {
    private fun item(vararg tags: String) = Item(title = "t", body = "", kind = Kind.Note, collection = "Inbox", tags = tags.toList())

    @Test fun tidyDropsSpacesAndALeadingHash() {
        assertEquals("lyrics", tidyTag("  #lyrics "))
        assertEquals("c#", tidyTag("c#"))
        assertEquals("", tidyTag(" # "))
    }

    @Test fun hasTagIgnoresCase() {
        assertTrue(item("Lyrics").hasTag("lyrics"))
        assertFalse(item("Lyrics").hasTag("lyric"))
    }

    @Test fun cleanTagsDropsEmptyAndRepeatedTagsKeepingTheFirst() =
        assertEquals(listOf("Lyrics", "idea"), cleanTags(listOf("Lyrics", " ", "lyrics", "#idea", "IDEA")))

    @Test fun aKnownSpellingIsReused() = assertEquals(listOf("Lyrics", "demo"), cleanTags(listOf("lyrics", "demo"), known = listOf("Lyrics", "Inspiration")))

    @Test fun countsMergeCaseAndShowTheMostUsedSpelling() {
        val counts = tagCounts(listOf(item("lyrics", "idea"), item("Lyrics"), item("Lyrics", "lyrics")))
        assertEquals(listOf("Lyrics" to 3, "idea" to 1), counts)
    }

    @Test fun countsAreOrderedByUseThenName() =
        assertEquals(listOf("b" to 2, "a" to 1, "c" to 1), tagCounts(listOf(item("b", "a"), item("b", "c"))))

    @Test fun noTagsGiveNoCounts() = assertTrue(tagCounts(listOf(item(), item())).isEmpty())

    @Test fun theCardLineShowsThreeTagsAndTheRest() {
        assertEquals("", tagLine(emptyList()))
        assertEquals("#a  #b", tagLine(listOf("a", "b")))
        assertEquals("#a  #b  #c  +2", tagLine(listOf("a", "b", "c", "d", "e")))
    }
}
