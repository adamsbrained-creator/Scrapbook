package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LinksTest {
    @Test fun newIdsAreDifferentAndLookLikeHex() {
        val a = newUid(); val b = newUid()
        assertNotEquals(a, b); assertEquals(32, a.length); assertEquals(a, a.lowercase()); assertEquals(true, a.all { it in "0123456789abcdef" })
    }

    @Test fun aLinkRoundTrips() { val u = newUid(); assertEquals(u, parseScrapLink(scrapLink(u))) }

    @Test fun parsingIgnoresCaseSpacesAndATrailingSlash() {
        assertEquals("abcdef1234567890", parseScrapLink("  SCRAPBOOK://Scrap/ABCDEF1234567890/ "))
    }

    @Test fun otherLinksAreNotScrapLinks() {
        assertNull(parseScrapLink(null)); assertNull(parseScrapLink(""))
        assertNull(parseScrapLink("https://example.com/scrap/abcdef1234567890"))
        assertNull(parseScrapLink("scrapbook://box/abcdef1234567890"))
        assertNull(parseScrapLink("scrapbook://scrap/"))
        assertNull(parseScrapLink("scrapbook://scrap/short"))
        assertNull(parseScrapLink("scrapbook://scrap/abcdef1234567890/extra"))
    }

    @Test fun twoScrapsMadeInARowGetDifferentIds() {
        val a = Item(title = "a", body = "", kind = Kind.Note, collection = "Inbox"); val b = Item(title = "a", body = "", kind = Kind.Note, collection = "Inbox")
        assertNotEquals(a.uid, b.uid)
    }

    @Test fun copyingAScrapKeepsItsIdUnlessGivenANewOne() {
        val a = Item(title = "a", body = "", kind = Kind.Note, collection = "Inbox")
        assertEquals(a.uid, a.copy(title = "b").uid)
        assertNotEquals(a.uid, a.copy(uid = newUid()).uid)
    }
}
