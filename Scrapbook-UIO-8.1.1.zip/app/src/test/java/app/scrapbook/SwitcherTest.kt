package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SwitcherTest {
    private val places = listOf(
        Place("i1", "Existentialism", "Philosophy · #camus", 10), Place("i2", "The Stranger", "Books · #camus", 20),
        Place("i3", "Albert Camus quotes", "Philosophy", 30), Place("bPhil", "Philosophy", "Boxes", 0), Place("i4", "Café notes", "Inbox", 40),
        Place("i5", "Shopping", "Inbox · #camus", 5),
    )
    @Test fun emptyQueryShowsRecentsInOrder() {
        assertEquals(listOf("i2", "bPhil"), Switcher.find("", places, listOf("i2", "bPhil", "gone")).map { it.key })
    }
    @Test fun emptyQueryWithoutRecentsShowsNewestScraps() {
        val r = Switcher.find("", places, emptyList()); assertEquals("i4", r.first().key); assertTrue(r.none { it.isBox })
    }
    @Test fun titleWordBeatsHint() {
        val r = Switcher.find("camus", places, emptyList()).map { it.key }
        assertEquals("i3", r.first()); assertEquals(setOf("i1", "i2", "i5"), r.drop(1).toSet())
    }
    @Test fun everyWordMustMatch() {
        assertEquals(listOf("i3"), Switcher.find("camus quotes", places, emptyList()).map { it.key })
        assertTrue(Switcher.find("camus zebra", places, emptyList()).isEmpty())
    }
    @Test fun ignoresCapitalsAndAccents() {
        assertEquals("i4", Switcher.find("CAFE", places, emptyList()).first().key)
        assertEquals("i4", Switcher.find("café", places, emptyList()).first().key)
    }
    @Test fun recentlyOpenedWinsTies() {
        assertEquals("i5", Switcher.find("camus", listOf(places[5], places[1]), listOf("i5")).first().key)
    }
    @Test fun boxesAreFoundToo() {
        assertEquals("bPhil", Switcher.find("philos", places, emptyList()).first { it.isBox }.key)
    }
}
