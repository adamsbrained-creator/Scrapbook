package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FloatsTest {
    private val photos = listOf("content://a", "content://b", "content://c")
    private val files = listOf("/f/one.pdf", "/f/two.pdf")

    private fun placedWrap(w: Float = 0.4f, line: Int = 2) = Placed(Placing.Wrap, w, 0f, 0f, line)
    private fun placedFree(w: Float = 0.5f, x: Float = 0.3f, y: Float = 120f) = Placed(Placing.Free, w, x, y, 0)

    @Test fun nothingPlacedIsStoredAsNothing() {
        assertEquals("", Floats.encode(emptyMap(), photos, files))
        assertEquals("", Floats.save(PageLayout.default(3, 2), emptyMap(), photos, files))
    }

    @Test fun saveKeepsTheOrderAndAddsTheEntries() {
        val m = mapOf(Floats.photoKey("content://b") to placedWrap())
        val s = Floats.save(listOf(Part.Photo, Part.Text, Part.Photo, Part.Photo, Part.File, Part.File), m, photos, files)
        assertEquals("Photo,Text,Photo,Photo,File,File|p1:W:0.4:0.0:0.0:2", s)
        // the order is still read from the part before the "|"
        assertEquals(listOf(Part.Photo, Part.Text, Part.Photo, Part.Photo, Part.File, Part.File), PageLayout.parse(s, 3, 2))
    }

    @Test fun onlyPlacedObjectsAndDefaultOrderStillSaveTheEntries() {
        val m = mapOf(Floats.fileKey("/f/two.pdf") to placedFree())
        assertEquals("|f1:F:0.5:0.3:120.0:0", Floats.save(PageLayout.default(3, 2), m, photos, files))
        assertEquals(PageLayout.default(3, 2), PageLayout.parse("|f1:F:0.5:0.3:120.0:0", 3, 2))
    }

    @Test fun roundTripThroughNewAddresses() {
        val m = mapOf(Floats.photoKey("content://a") to placedFree(), Floats.fileKey("/f/one.pdf") to placedWrap(0.55f, 0))
        val saved = Floats.encode(m, photos, files)
        // a backup restored under other addresses: the same places still find the same objects
        val newPhotos = listOf("file://x1", "file://x2", "file://x3"); val newFiles = listOf("/r/one.pdf", "/r/two.pdf")
        val back = Floats.parse("Photo,Text$saved", newPhotos, newFiles)
        assertEquals(mapOf(Floats.photoKey("file://x1") to placedFree(), Floats.fileKey("/r/one.pdf") to placedWrap(0.55f, 0)), back)
    }

    @Test fun parseSkipsWhatDoesNotMakeSense() {
        val saved = "Photo,Text|p9:W:0.4:0:0:1|x1:W:0.4:0:0:1|p0:Q:0.4:0:0:1|p1:W:abc:0:0:1|p1:W:0.4|f0:F:0.5:0.2:30:0"
        assertEquals(mapOf(Floats.fileKey("/f/one.pdf") to Placed(Placing.Free, 0.5f, 0.2f, 30f, 0)), Floats.parse(saved, photos, files))
        assertEquals(emptyMap<String, Placed>(), Floats.parse(null, photos, files))
        assertEquals(emptyMap<String, Placed>(), Floats.parse("Photo,Text", photos, files))
    }

    @Test fun cleanBringsNumbersIntoRange() {
        val m = mapOf(
            Floats.photoKey("content://a") to Placed(Placing.Wrap, 0.95f, 0.5f, 40f, -3),
            Floats.photoKey("content://b") to Placed(Placing.Free, 0.01f, 0.99f, -20f, 5),
            Floats.fileKey("/f/one.pdf") to Placed(Placing.Free, 0.1f, 0f, 0f, 0),
            Floats.photoKey("content://gone") to placedWrap(),
            Floats.photoKey("content://c") to Placed(Placing.Inline, 0.3f))
        val c = Floats.clean(m, photos, files)
        assertEquals(Placed(Placing.Wrap, Floats.MAX_WRAP, 0f, 0f, 0), c[Floats.photoKey("content://a")])
        assertEquals(Placed(Placing.Free, Floats.MIN_WIDTH, 0.88f, 0f, 0), c[Floats.photoKey("content://b")])
        assertEquals(Floats.MIN_FILE_WIDTH, c[Floats.fileKey("/f/one.pdf")]!!.width)
        assertNull(c[Floats.photoKey("content://gone")])
        assertNull(c[Floats.photoKey("content://c")])
        assertEquals(3, c.size)
    }

    @Test fun notANumberNeverGetsSaved() {
        val m = mapOf(Floats.photoKey("content://a") to Placed(Placing.Free, Float.NaN, Float.POSITIVE_INFINITY, Float.NaN, 0))
        val c = Floats.clean(m, photos, files)[Floats.photoKey("content://a")]!!
        assertEquals(Placed(Placing.Free, 0.45f, 0f, 0f, 0), c)
        assertEquals("|p0:F:0.45:0.0:0.0:0", Floats.encode(m, photos, files))
    }

    @Test fun removedObjectsFallOutOfTheSavedText() {
        val m = mapOf(Floats.photoKey("content://a") to placedFree(), Floats.photoKey("content://b") to placedWrap())
        assertEquals("|p0:W:0.4:0.0:0.0:2", Floats.encode(m, listOf("content://b", "content://c"), emptyList()))
    }

    @Test fun switchingModes() {
        assertNull(Floats.switchTo(placedFree(), Placing.Inline, false))
        val w = Floats.switchTo(null, Placing.Wrap, false)!!
        assertEquals(Placed(Placing.Wrap, 0.4f, 0f, 0f, 0), w)
        // a free photo starts at the right edge
        val f = Floats.switchTo(null, Placing.Free, false)!!
        assertEquals(Placing.Free, f.how); assertEquals(0.45f, f.width); assertEquals(0.55f, f.x, 0.0001f)
        // wrap to free keeps its size and top, free to wrap keeps its size
        val fromWrap = Floats.switchTo(placedWrap(0.5f, 3), Placing.Free, false, 80f)!!
        assertEquals(Placed(Placing.Free, 0.5f, 0f, 80f, 0), fromWrap)
        assertEquals(Placed(Placing.Wrap, 0.5f, 0f, 0f, 0), Floats.switchTo(placedFree(0.5f), Placing.Wrap, false))
        assertEquals(placedFree(), Floats.switchTo(placedFree(), Placing.Free, false))
        // a file never gets narrower than a card can be read
        assertEquals(Floats.MIN_FILE_WIDTH, Floats.switchTo(placedWrap(0.2f), Placing.Wrap, true)!!.width)
        assertEquals(0.55f, Floats.switchTo(null, Placing.Wrap, true)!!.width)
    }

    @Test fun widthLimits() {
        assertEquals(Floats.MAX_WRAP, Floats.maxWidthOf("pa", placedWrap()))
        assertEquals(0.7f, Floats.maxWidthOf("pa", placedFree(0.2f, 0.3f)), 0.0001f)
        assertEquals(Floats.MIN_FILE_WIDTH, Floats.maxWidthOf("f/x", placedFree(0.2f, 0.9f)))
        assertEquals(Floats.MIN_WIDTH, Floats.minWidthOf("pa"))
        assertEquals(Floats.MIN_FILE_WIDTH, Floats.minWidthOf("f/x"))
    }

    @Test fun lineAtPicksTheClosestTop() {
        val tops = listOf(0f, 30f, 60f, 200f)
        assertEquals(0, Floats.lineAt(tops, -50f))
        assertEquals(1, Floats.lineAt(tops, 40f))
        assertEquals(2, Floats.lineAt(tops, 46f))
        assertEquals(3, Floats.lineAt(tops, 9000f))
        assertEquals(0, Floats.lineAt(emptyList(), 10f))
    }

    @Test fun textBesideAWrappedObjectIsPushedIn() {
        val tops = listOf(0f, 30f, 60f, 90f, 120f)
        // starts at line 1, 70 px tall: lines 1, 2 and 3 start above 100
        val r = Floats.indents(tops, listOf(WrapZone(1, 70f, 150f)))
        assertEquals(mapOf(1 to 150f, 2 to 150f, 3 to 150f), r)
        // a line that starts exactly at the bottom is not pushed
        assertEquals(setOf(1, 2), Floats.indents(tops, listOf(WrapZone(1, 60f, 100f))).keys)
        // the line it starts beside is always pushed, even for a tiny object
        assertEquals(setOf(4), Floats.indents(tops, listOf(WrapZone(4, 0f, 100f))).keys)
        // a line number past the end counts as the last line
        assertEquals(setOf(4), Floats.indents(tops, listOf(WrapZone(99, 10f, 100f))).keys)
    }

    @Test fun twoWrappedObjectsTakeTheWiderIndent() {
        val tops = listOf(0f, 30f, 60f, 90f)
        val r = Floats.indents(tops, listOf(WrapZone(0, 70f, 100f), WrapZone(2, 70f, 160f)))
        assertEquals(100f, r[0]); assertEquals(100f, r[1]); assertEquals(160f, r[2]); assertEquals(160f, r[3])
        assertTrue(Floats.indents(emptyList(), listOf(WrapZone(0, 10f, 10f))).isEmpty())
        assertTrue(Floats.indents(tops, emptyList()).isEmpty())
    }

    @Test fun indentsSettleWhenTheTextGrowsTaller() {
        // Pushing a paragraph in makes it wrap onto more lines, so later paragraphs start lower and may fall out of the zone.
        // The decision for a line only depends on the tops above it, so applying the result again gives the same answer.
        fun layout(indented: Set<Int>): List<Float> { var y = 0f; return List(6) { i -> val top = y; y += if (i in indented) 60f else 30f; top } }
        val zone = listOf(WrapZone(0, 100f, 120f))
        var set = emptySet<Int>()
        repeat(8) { set = Floats.indents(layout(set), zone).keys }
        val again = Floats.indents(layout(set), zone).keys
        assertEquals(set, again)
        assertEquals(setOf(0, 1), set)
    }
}
