package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SmartPasteTest {
    private fun offer(text: String, hadSelection: Boolean = false) = offerFor(text, 0 until text.length, hadSelection)
    private fun apply(text: String, what: PasteOffer) = applyPasteOffer(text, 0 until text.length, what)

    // ---- finding what was pasted
    @Test fun aPasteAtTheCursorIsFound() = assertEquals(4 until 13, insertedRange("abcd", 4, 4, "abcdhttp://xy", 13))

    @Test fun theRangeCoversTheInsertedText() = assertEquals(2 until 7, insertedRange("abef", 2, 2, "abXXXXXef", 7))

    @Test fun pastingOverASelectionCountsAsOneInsertion() = assertEquals(1 until 6, insertedRange("a-bc", 1, 3, "aHELLOc", 6))

    @Test fun typingOneLetterIsAnInsertionOfOne() = assertEquals(2 until 3, insertedRange("ab", 2, 2, "abc", 3))

    @Test fun aDeletionIsNotAnInsertion() = assertNull(insertedRange("abcd", 4, 4, "abc", 3))

    @Test fun aChangeSomewhereElseIsNotAnInsertion() = assertNull(insertedRange("abcd", 4, 4, "XXcdY", 5))

    // ---- what to offer
    @Test fun aWebAddressOffersALink() = assertEquals(PasteOffer.Link, offer("https://example.com/some/page"))

    @Test fun aWebAddressOverASelectionOffersNothing() = assertNull(offer("https://example.com/some/page", hadSelection = true))

    @Test fun anAddressInsideALinkOffersNothing() =
        assertNull(offerFor("see [x](https://example.com/page", 8 until 32, false))

    @Test fun shortTextOffersNothing() = assertNull(offer("hello world"))

    @Test fun anOrdinarySentenceOffersNothing() = assertNull(offer("Remember to call the dentist tomorrow morning about the appointment."))

    @Test fun aWrappedQuoteOffersAQuote() = assertEquals(PasteOffer.Quote, offer("\u201CThe only way out is through, and through is forward.\u201D"))

    @Test fun aStraightQuotedQuoteWithAnAttributionLineOffersAQuote() =
        assertEquals(PasteOffer.Quote, offer("\"We are what we repeatedly do.\"\n\u2014 Will Durant"))

    @Test fun anAttributionOnTheSameLineStillOffersAQuote() =
        assertEquals(PasteOffer.Quote, offer("\u201CWe are what we repeatedly do.\u201D \u2014 Will Durant"))

    @Test fun aSentenceThatStartsWithAQuotedPhraseIsNotAQuote() = assertNull(offer("\"hello there\" she said, smiling."))

    @Test fun textThatIsAlreadyAQuoteOffersNothing() = assertNull(offer("> \u201CThe only way out is through, and through is forward.\u201D"))

    @Test fun bulletedLinesOfferAList() = assertEquals(PasteOffer.Bullets, offer("\u2022 milk\n\u2022 eggs\n\u2022 bread"))

    @Test fun asterisksOfferAListToo() = assertEquals(PasteOffer.Bullets, offer("* milk and cream\n* eggs and cheese"))

    @Test fun boxesOfferAChecklist() = assertEquals(PasteOffer.Checklist, offer("\u2610 call the bank\n\u2611 send the report\n\u2610 book the flight"))

    @Test fun oneBulletAmongProseIsNotAList() = assertNull(offer("\u2022 just one bullet line here\nand then a normal line of text"))

    @Test fun hardWrappedLinesOfferJoining() = assertEquals(
        PasteOffer.JoinLines,
        offer("The committee met on Tuesday to discuss the\nnew proposal and agreed that further work was\nneeded before any decision could be reached by\nthe full board of directors in the spring."),
    )

    @Test fun paragraphsAreNotJoined() = assertNull(offer("First paragraph that is fairly long and ends here.\n\nSecond paragraph that is also fairly long and ends here."))

    // ---- applying an offer
    @Test fun aLinkGetsTheSiteNameUntilATitleIsKnown() =
        assertEquals("see [example.com](https://www.example.com/a) now", applyPasteOffer("see https://www.example.com/a now", 4 until 29, PasteOffer.Link).text)

    @Test fun aLinkTitleHasNoBrackets() = assertEquals("[A B](https://x.io/p)", linkMarkdown("https://x.io/p", "A [B]"))

    @Test fun aBracketOnlyTitleFallsBackToTheSite() = assertEquals("[x.io](https://x.io/p)", linkMarkdown("https://x.io/p", "[]"))

    @Test fun aClosingParenthesisInTheAddressIsEscaped() = assertEquals("[x.io](https://x.io/a%29b)", linkMarkdown("https://x.io/a)b", "x.io"))

    @Test fun theHostLosesWww() = assertEquals("example.com", hostLabel("https://www.example.com/a/b"))

    @Test fun aQuoteGetsAMarkOnEveryLine() =
        assertEquals("> \u201CHello there, friend.\u201D\n> \u2014 Someone", apply("\u201CHello there, friend.\u201D\n\u2014 Someone", PasteOffer.Quote).text)

    @Test fun aQuotePastedMidLineStartsOnItsOwnLine() {
        val text = "intro \"A fairly long quoted sentence here.\" tail"
        val r = applyPasteOffer(text, 6..42, PasteOffer.Quote)
        assertEquals("intro \n> \"A fairly long quoted sentence here.\"\n tail", r.text)
    }

    @Test fun bulletsBecomeListMarks() = assertEquals("- milk\n- eggs", apply("\u2022 milk\n\u2022 eggs", PasteOffer.Bullets).text)

    @Test fun boxesBecomeCheckboxes() =
        assertEquals("- [ ] call\n- [x] send", apply("\u2610 call\n\u2611 send", PasteOffer.Checklist).text)

    @Test fun brokenLinesAreJoinedWithSpaces() = assertEquals("one two three", apply("one\ntwo\nthree", PasteOffer.JoinLines).text)

    @Test fun surroundingWhitespaceOfThePasteIsKept() =
        assertEquals("\n\n- a\n- b\n", apply("\n\n\u2022 a\n\u2022 b\n", PasteOffer.Bullets).text)

    @Test fun theChangedRangeCoversTheNewPiece() {
        val r = applyPasteOffer("a \u2022 x\n\u2022 y", 2..8, PasteOffer.Bullets)
        assertEquals("a \n- x\n- y", r.text)
        assertEquals(2 until 10, r.range)
    }
}
