package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class HomeBoxesTest {
    @Test fun theMostRecentlyEditedBoxComesFirst() =
        assertEquals(listOf("b", "c", "a"), orderBoxesByActivity(listOf("a", "b", "c"), mapOf("a" to 1L, "b" to 9L, "c" to 5L)))

    @Test fun theInboxIsFirstWhileItHasScraps() =
        assertEquals(listOf("Inbox", "b", "a"), orderBoxesByActivity(listOf("a", "b", "Inbox"), mapOf("a" to 1L, "b" to 9L, "Inbox" to 0L)))

    @Test fun anEmptyInboxGoesWithTheEmptyBoxes() =
        assertEquals(listOf("b", "a", "Inbox"), orderBoxesByActivity(listOf("a", "b", "Inbox"), mapOf("a" to 1L, "b" to 9L)))

    @Test fun emptyBoxesGoLastInTheirOwnOrder() =
        assertEquals(listOf("c", "x", "y"), orderBoxesByActivity(listOf("x", "y", "c"), mapOf("c" to 3L)))

    @Test fun boxesEditedAtTheSameTimeKeepTheirOrder() =
        assertEquals(listOf("a", "b", "c"), orderBoxesByActivity(listOf("a", "b", "c"), mapOf("a" to 5L, "b" to 5L, "c" to 5L)))

    @Test fun nothingToOrderGivesNothing() = assertEquals(emptyList<String>(), orderBoxesByActivity(emptyList(), emptyMap()))
}
