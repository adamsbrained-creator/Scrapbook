package app.scrapbook

import java.util.Calendar
import java.util.GregorianCalendar
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TimelineTest {
    private val utc = TimeZone.getTimeZone("UTC")
    private fun at(y: Int, m: Int, d: Int, h: Int = 12): Long = GregorianCalendar(utc).apply { clear(); set(y, m - 1, d, h, 0, 0) }.timeInMillis
    private fun scrap(id: Long, created: Long, edited: Long = created, box: String = "Inbox") =
        Item(id = id, title = "s$id", body = "", kind = Kind.Note, collection = box, savedAt = edited, createdAt = created)
    private fun ids(m: TimelineMonth) = m.days.flatMap { d -> d.items.map { it.id } }

    @Test fun groupsByMonthAndDayNewestFirst() {
        val items = listOf(scrap(1, at(2026, 9, 3)), scrap(2, at(2026, 10, 17, 9)), scrap(3, at(2026, 10, 17, 18)), scrap(4, at(2026, 10, 2)), scrap(5, at(2025, 12, 31)))
        val months = timelineOf(items, TimelineField.Created, utc)
        assertEquals(listOf(2026 to 9, 2026 to 8, 2025 to 11), months.map { it.year to it.month })      // October 2026, September 2026, December 2025
        assertEquals(listOf(17, 2), months[0].days.map { it.day })
        assertEquals(listOf(3L, 2L, 4L), ids(months[0]))                                                  // the 18:00 scrap before the 9:00 one
        assertEquals(3, months[0].count)
    }

    @Test fun theFieldDecidesWhereAScrapSits() {
        val items = listOf(scrap(1, created = at(2026, 1, 5), edited = at(2026, 3, 9)))
        assertEquals(0, timelineOf(items, TimelineField.Created, utc)[0].month)
        assertEquals(2, timelineOf(items, TimelineField.Edited, utc)[0].month)
    }

    @Test fun theWeekdayIsKept() {
        val m = timelineOf(listOf(scrap(1, at(2026, 10, 17))), TimelineField.Created, utc)[0]
        assertEquals(Calendar.SATURDAY, m.days[0].dow)    // 17 October 2026 is a Saturday
    }

    @Test fun rowsAreAMonthHeadingThenItsScrapsWithTheDayOnTheFirstOfEachDay() {
        val months = timelineOf(listOf(scrap(1, at(2026, 10, 17, 9)), scrap(2, at(2026, 10, 17, 18)), scrap(3, at(2026, 10, 2)), scrap(4, at(2026, 9, 1))), TimelineField.Created, utc)
        val rows = timelineRows(months)
        assertEquals(6, rows.size)
        assertTrue(rows[0] is TimelineRow.Month)
        assertEquals(17, (rows[1] as TimelineRow.Entry).day!!.day); assertNull((rows[2] as TimelineRow.Entry).day)
        assertEquals(2, (rows[3] as TimelineRow.Entry).day!!.day)
        assertTrue(rows[4] is TimelineRow.Month)
    }

    @Test fun findsAMonthsHeading() {
        val rows = timelineRows(timelineOf(listOf(scrap(1, at(2026, 10, 17)), scrap(2, at(2026, 9, 1))), TimelineField.Created, utc))
        assertEquals(0, rows.indexOfMonth(2026, 9)); assertEquals(2, rows.indexOfMonth(2026, 8)); assertEquals(-1, rows.indexOfMonth(2020, 0))
    }

    @Test fun aBusyMonthMostlyInOneBoxSaysSo() {
        val busy = (1..5L).map { scrap(it, at(2026, 10, it.toInt()), box = if (it <= 3) "Ideas" else "Inbox") }
        assertEquals("Ideas", timelineOf(busy, TimelineField.Created, utc)[0].mostlyBox())
        val mixed = (1..4L).map { scrap(it, at(2026, 10, it.toInt()), box = "Box$it") }
        assertNull(timelineOf(mixed, TimelineField.Created, utc)[0].mostlyBox())
        val quiet = (1..3L).map { scrap(it, at(2026, 10, it.toInt()), box = "Ideas") }
        assertNull(timelineOf(quiet, TimelineField.Created, utc)[0].mostlyBox())    // too few scraps to say "mostly"
    }

    @Test fun onThisDayIsTodaysDateInEarlierYears() {
        val items = listOf(scrap(1, at(2025, 10, 17)), scrap(2, at(2024, 10, 17)), scrap(3, at(2026, 10, 17, 8)), scrap(4, at(2025, 10, 18)), scrap(5, at(2025, 9, 17)))
        assertEquals(listOf(1L, 2L), onThisDay(items, at(2026, 10, 17, 20), utc).map { it.id })
    }
}
