package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ColorsTest {
    @Test fun readyMadeChoicesAreNotCustom() {
        for (v in 0..5) assertFalse(CustomColors.isCustom(v))
        assertFalse(CustomColors.isCustom(CustomColors.FLAG - 1))
    }

    @Test fun encodeKeepsTheColor() {
        val v = CustomColors.encode(0x12ABEF)
        assertTrue(CustomColors.isCustom(v))
        assertEquals(0x12ABEF, CustomColors.rgb(v))
        assertTrue(CustomColors.isCustom(CustomColors.encode(0)))   // black is a color too, not "none"
        assertEquals(0, CustomColors.rgb(CustomColors.encode(0)))
        assertEquals(0xFFFFFF, CustomColors.rgb(CustomColors.encode(0xFFFFFF)))
        assertTrue(CustomColors.encode(0xFFFFFF) > 0)               // always a normal positive number in the database
    }

    @Test fun theBarsGiveTheExpectedColors() {
        assertEquals(0xFF0000, CustomColors.fromHueShade(0f, .5f))
        assertEquals(0x00FF00, CustomColors.fromHueShade(120f, .5f))
        assertEquals(0x0000FF, CustomColors.fromHueShade(240f, .5f))
        assertEquals(0x000000, CustomColors.fromHueShade(77f, 0f))
        assertEquals(0xFFFFFF, CustomColors.fromHueShade(77f, 1f))
        assertEquals(CustomColors.fromHueShade(10f, .5f), CustomColors.fromHueShade(370f, .5f))
    }

    private fun close(a: Int, b: Int, by: Int = 3): Boolean =
        (0..2).all { i -> Math.abs(((a shr (i * 8)) and 255) - ((b shr (i * 8)) and 255)) <= by }

    @Test fun aColorFromTheBarsComesBackToTheSameSpot() {
        for (h in 0 until 360 step 17) for (i in 0..20) {
            val t = i / 20f
            val rgb = CustomColors.fromHueShade(h.toFloat(), t)
            val (h2, t2) = CustomColors.toHueShade(rgb)
            val again = CustomColors.fromHueShade(h2, t2)
            assertTrue("hue $h shade $t: ${rgb.toString(16)} became ${again.toString(16)}", close(rgb, again))
        }
    }

    @Test fun nearestPicksTheClosestOne() {
        val palette = listOf(0xF26B4E, 0x3DD9D3, 0x4DA3FF)
        assertEquals(0, CustomColors.nearest(0xFF0000, palette))
        assertEquals(1, CustomColors.nearest(0x00FFEE, palette))
        assertEquals(2, CustomColors.nearest(0x2060FF, palette))
        assertEquals(0, CustomColors.nearest(0x123456, emptyList()))
    }
}
