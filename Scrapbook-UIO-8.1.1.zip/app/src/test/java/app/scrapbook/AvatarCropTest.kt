package app.scrapbook

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AvatarCropTest {
    @Test fun notMovedItIsTheBiggestSquareInTheMiddle() {
        assertArrayEquals(intArrayOf(100, 0, 200), AvatarCrop.Center.square(400, 200))
        assertArrayEquals(intArrayOf(0, 100, 200), AvatarCrop.Center.square(200, 400))
        assertArrayEquals(intArrayOf(0, 0, 300), AvatarCrop.Center.square(300, 300))
    }

    @Test fun zoomingInTakesASmallerSquare() {
        assertArrayEquals(intArrayOf(150, 50, 100), AvatarCrop(zoom = 2f).square(400, 200))
    }

    @Test fun theSquareNeverLeavesThePhoto() {
        assertArrayEquals(intArrayOf(0, 50, 100), AvatarCrop(cx = 0f, zoom = 2f).square(400, 200))
        assertArrayEquals(intArrayOf(300, 50, 100), AvatarCrop(cx = 1f, zoom = 2f).square(400, 200))
        assertArrayEquals(intArrayOf(150, 100, 100), AvatarCrop(cy = 5f, zoom = 2f).square(400, 200))
        assertArrayEquals(intArrayOf(150, 0, 100), AvatarCrop(cy = -3f, zoom = 2f).square(400, 200))
    }

    @Test fun theZoomIsKeptBetweenOneAndTheMaximum() {
        assertArrayEquals(intArrayOf(0, 0, 500), AvatarCrop(zoom = .2f).square(500, 500))
        assertArrayEquals(intArrayOf(200, 200, 100), AvatarCrop(zoom = 99f).square(500, 500))
    }

    @Test fun aTinyPhotoStillGivesARealSquare() {
        val sq = AvatarCrop(zoom = 5f).square(3, 2)
        assertTrue(sq[2] >= 1); assertTrue(sq[0] >= 0 && sq[0] + sq[2] <= 3); assertTrue(sq[1] >= 0 && sq[1] + sq[2] <= 2)
    }
}
