package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TextMarksTest {
    @Test fun aLineColoredFromTheStartGivesItsColor() = assertEquals("ff0000", leadingTextColor("{c:ff0000|red} and more"))

    @Test fun colorWithSizeAndUnderlineStillGivesTheColor() = assertEquals("00ff00", leadingTextColor("{c:00ff00 s:20 u|big green}"))

    @Test fun plainTextHasNoColor() = assertNull(leadingTextColor("just text"))

    @Test fun aColorLaterInTheLineDoesNotColorTheMark() = assertNull(leadingTextColor("start {c:ff0000|red}"))

    @Test fun aSizeWithoutAColorHasNoColor() = assertNull(leadingTextColor("{s:30|big}"))

    @Test fun emptyTextHasNoColor() = assertNull(leadingTextColor(""))
}
