package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class AppearanceTest {
    private fun item(title: String, icon: String = "") = Item(title = title, body = "", kind = Kind.Note, collection = "Inbox", icon = icon)

    @Test fun noIconLeavesTheTitleAlone() = assertEquals("Groceries", item("Groceries").displayTitle)

    @Test fun anIconGoesInFrontOfTheTitle() = assertEquals("🛒 Groceries", item("Groceries", "🛒").displayTitle)

    @Test fun anIconWithoutATitleHasNoTrailingSpace() = assertEquals("🛒", item("", "🛒").displayTitle)

    @Test fun aBlankIconCountsAsNone() = assertEquals("Groceries", item("Groceries", "  ").displayTitle)

    @Test fun firstGlyphOfNothingIsNothing() = assertEquals("", firstGlyph(""))

    @Test fun firstGlyphKeepsOneCharacter() = assertEquals("a", firstGlyph("abc"))

    @Test fun firstGlyphKeepsAWholeEmoji() = assertEquals("😀", firstGlyph("😀x"))
}
