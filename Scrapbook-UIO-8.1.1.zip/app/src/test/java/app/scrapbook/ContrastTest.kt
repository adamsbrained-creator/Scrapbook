package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContrastTest {
    private val accents = listOf(0xF26B4E, 0x3DD9D3, 0xF5B83D, 0x9B8CFF, 0x5CCB8A, 0xFF8FB1, 0x4DA3FF)   // Coral, Teal, Amber, Violet, Green, Pink, Blue
    private val lightCard = 0xF3F3F3; private val darkCard = 0x242424

    @Test fun blackOnWhiteIs21() = assertEquals(21.0, contrastRatio(0x000000, 0xFFFFFF), 0.01)
    @Test fun aColorOnItselfIs1() = assertEquals(1.0, contrastRatio(0x3DD9D3, 0x3DD9D3), 0.0001)

    @Test fun everyReadyMadeAccentGetsDarkTextOnIt() = accents.forEach { assertEquals(DARK_INK, onColor(it)) }
    @Test fun aDarkFillGetsWhiteText() { assertEquals(0xFFFFFF, onColor(0x1C1C1C)); assertEquals(0xFFFFFF, onColor(0x5E5CE6)) }
    @Test fun textOnAFillAlwaysReadsAtLeastAsWellAsTheOtherChoice() = accents.forEach {
        assertTrue(contrastRatio(onColor(it), it) >= maxOf(contrastRatio(0xFFFFFF, it), contrastRatio(DARK_INK, it)) - 0.0001)
    }

    @Test fun accentTextIsReadableOnALightCard() = accents.forEach { assertTrue(contrastRatio(readableOn(it, lightCard), lightCard) >= 4.5) }
    @Test fun accentTextIsReadableOnADarkCard() = (accents + 0x333333 + 0x4B0082).forEach { assertTrue(contrastRatio(readableOn(it, darkCard), darkCard) >= 4.5) }
    @Test fun aColorThatAlreadyReadsIsLeftAlone() { assertEquals(0x1C1C1C, readableOn(0x1C1C1C, lightCard)); assertEquals(0xF26B4E, readableOn(0xF26B4E, darkCard)) }
    @Test fun aDeeperTealIsStillTeal() {
        val c = readableOn(0x3DD9D3, lightCard)
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        assertTrue(g > r && b > r)
    }
}
