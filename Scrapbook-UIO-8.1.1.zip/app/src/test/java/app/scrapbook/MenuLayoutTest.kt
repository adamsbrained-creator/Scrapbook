package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MenuLayoutTest {
    private val all = MenuEntry.entries.toList()
    private fun e(vararg k: MenuEntry) = k.toList()

    @Test fun theDefaultMenuIsTheMenuThatWasThereBefore() {
        val g = MenuLayout.Default.groups()
        assertEquals(3, g.size)
        assertEquals(e(MenuEntry.Home, MenuEntry.AllScraps, MenuEntry.Pinned, MenuEntry.Recent), g[0])
        assertEquals(e(MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search), g[1])
        assertEquals(e(MenuEntry.Bin, MenuEntry.CustomizeHome, MenuEntry.CustomizeMenu, MenuEntry.Settings, MenuEntry.About), g[2])
        assertEquals(all, g.flatten())
    }

    @Test fun theDefaultOrderHoldsEveryEntryOnceAndTwoBreaks() {
        val order = MenuLayout.Default.order
        assertEquals(all, order.filterIsInstance<MenuItem.Entry>().map { it.entry })
        assertEquals(listOf(1, 2), MenuLayout.Default.gaps.map { it.id })
        assertEquals(all.size + 2, order.size)
    }

    @Test fun keysAreUniqueSoAScreenCanUseThemToTellRowsApart() {
        val keys = MenuLayout.Default.order.map { it.key }
        assertEquals(keys.size, keys.toSet().size)
        assertEquals(all.size, all.map { it.key }.toSet().size)
    }

    @Test fun movingAnItemKeepsTheOthersInOrder() {
        val l = MenuLayout.Default
        val i = l.order.indexOf(MenuItem.Entry(MenuEntry.Search))
        val moved = l.move(i, 0)
        assertEquals(MenuItem.Entry(MenuEntry.Search), moved.order.first())
        assertEquals(l.order.size, moved.order.size)
        assertEquals(l.order.toSet(), moved.order.toSet())
        // Search is now at the top of the first card.
        assertEquals(MenuEntry.Search, moved.groups()[0][0])
        assertEquals(e(MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo), moved.groups()[1])
    }

    @Test fun movingNowhereOrOutsideTheListChangesNothing() {
        val l = MenuLayout.Default
        assertEquals(l, l.move(2, 2))
        assertEquals(l, l.move(-1, 2))
        assertEquals(l, l.move(2, 99))
        assertEquals(l, l.move(99, 0))
    }

    @Test fun movingABreakRegroupsTheMenu() {
        val l = MenuLayout.Default
        val gap = l.order.indexOf(MenuItem.Gap(1))      // between Recently edited and Rediscover
        val moved = l.move(gap, gap - 2)                 // now between All scraps and Pinned
        assertEquals(e(MenuEntry.Home, MenuEntry.AllScraps), moved.groups()[0])
        assertEquals(e(MenuEntry.Pinned, MenuEntry.Recent, MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search), moved.groups()[1])
    }

    @Test fun aHiddenEntryIsLeftOutButKeepsItsPlace() {
        val l = MenuLayout.Default.withHidden(MenuEntry.Pinned, true)
        assertTrue(l.isHidden(MenuEntry.Pinned))
        assertFalse(MenuEntry.Pinned in l.groups().flatten())
        assertEquals(MenuLayout.Default.order, l.order)
        assertEquals(all, l.withHidden(MenuEntry.Pinned, false).groups().flatten())
    }

    @Test fun settingsCanNeverBeHidden() {
        val l = MenuLayout.Default.withHidden(MenuEntry.Settings, true)
        assertEquals(MenuLayout.Default, l)
        assertFalse(l.isHidden(MenuEntry.Settings))
        assertTrue(MenuEntry.Settings in l.groups().flatten())
        assertFalse(MenuEntry.Settings.canHide)
        assertTrue(MenuEntry.About.canHide)
    }

    @Test fun aCardWhoseEntriesAreAllHiddenDisappears() {
        var l = MenuLayout.Default
        e(MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search).forEach { l = l.withHidden(it, true) }
        val g = l.groups()
        assertEquals(2, g.size)
        assertEquals(MenuEntry.Home, g[0][0])
        assertEquals(MenuEntry.Bin, g[1][0])
    }

    @Test fun breaksAtTheEndsOrSideBySideDoNotMakeEmptyCards() {
        val l = MenuLayout(listOf(MenuItem.Gap(1), MenuItem.Entry(MenuEntry.Home), MenuItem.Gap(2), MenuItem.Gap(3), MenuItem.Entry(MenuEntry.Settings), MenuItem.Gap(4)))
        assertEquals(listOf(e(MenuEntry.Home), e(MenuEntry.Settings)), l.groups())
    }

    @Test fun anEntryThatDoesNotFitTheScreenIsLeftOut() {
        val g = MenuLayout.Default.groups { it != MenuEntry.CustomizeHome }
        assertFalse(MenuEntry.CustomizeHome in g.flatten())
        assertEquals(e(MenuEntry.Bin, MenuEntry.CustomizeMenu, MenuEntry.Settings, MenuEntry.About), g[2])
    }

    @Test fun addingABreakPutsItOnTopWithTheSmallestFreeNumber() {
        val l = MenuLayout.Default.addGap()
        assertEquals(MenuItem.Gap(3), l.order.first())
        assertEquals(3, l.gaps.size)
        // Taking number 1 away frees it again.
        assertEquals(MenuItem.Gap(1), l.removeGap(1).addGap().order.first())
    }

    @Test fun thereIsALimitToTheNumberOfBreaks() {
        var l = MenuLayout.Default
        repeat(10) { l = l.addGap() }
        assertEquals(MenuLayout.MAX_GAPS, l.gaps.size)
        assertEquals(l, l.addGap())
        assertEquals(l.gaps.map { it.id }.toSet().size, l.gaps.size)
    }

    @Test fun removingABreakJoinsTheTwoCards() {
        val l = MenuLayout.Default.removeGap(1)
        assertEquals(2, l.groups().size)
        assertEquals(e(MenuEntry.Home, MenuEntry.AllScraps, MenuEntry.Pinned, MenuEntry.Recent, MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search), l.groups()[0])
        assertEquals(MenuLayout.Default, MenuLayout.Default.removeGap(42))
    }

    @Test fun theOrderIsSavedAndReadBackTheSame() {
        val l = MenuLayout.Default.move(0, 8).move(3, 1).addGap(5).removeGap(2)
        assertEquals(l.order, MenuLayout.decodeOrder(l.encodeOrder()))
        assertEquals(MenuLayout.Default.order, MenuLayout.decodeOrder(MenuLayout.Default.encodeOrder()))
    }

    @Test fun nothingSavedOrUnreadableGivesTheUsualMenu() {
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder(null))
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder(""))
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder("   "))
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder("nonsense,,??,-x"))
    }

    @Test fun unknownNamesAndRepeatsAreDroppedAndMissingEntriesGoLast() {
        val order = MenuLayout.decodeOrder("search, home,home,wat,-1,-1,about")
        assertEquals(listOf("search", "home", "-1", "about"), order.take(4).map { it.key })
        assertEquals(all.toSet(), order.filterIsInstance<MenuItem.Entry>().map { it.entry }.toSet())
        assertEquals(all.size, order.filterIsInstance<MenuItem.Entry>().size)
        assertEquals(1, order.filterIsInstance<MenuItem.Gap>().size)
        // The ones that were missing are in the usual order after the ones that were saved.
        assertEquals(MenuEntry.AllScraps, (order[4] as MenuItem.Entry).entry)
    }

    @Test fun savedBreaksAreKeptAsTheyAreAndTooManyAreDropped() {
        val s = (1..9).joinToString(",") { "-$it" } + ",home"
        val order = MenuLayout.decodeOrder(s)
        assertEquals(MenuLayout.MAX_GAPS, order.filterIsInstance<MenuItem.Gap>().size)
        assertEquals(listOf(-1, -2, -3, -4, -5, -6), order.filterIsInstance<MenuItem.Gap>().map { -it.id })
        // A saved menu with no breaks at all stays without them.
        val flat = MenuLayout.decodeOrder(all.joinToString(",") { it.key })
        assertTrue(flat.none { it is MenuItem.Gap })
    }

    @Test fun hiddenEntriesAreSavedInTheDefaultOrder() {
        val set = setOf(MenuEntry.About, MenuEntry.Home)
        assertEquals("home,about", MenuLayout.encodeHidden(set))
        assertEquals(set, MenuLayout.decodeHidden("about,home"))
        assertEquals(set, MenuLayout.decodeHidden("about,?,home,about"))
    }

    @Test fun nothingHiddenIsSavedAsNothing() {
        assertEquals("", MenuLayout.Default.encodeHidden())
        assertEquals(emptySet<MenuEntry>(), MenuLayout.decodeHidden(""))
        assertEquals(emptySet<MenuEntry>(), MenuLayout.decodeHidden(null))
    }

    @Test fun aSavedSettingsIsNeverReadAsHidden() {
        assertEquals(setOf(MenuEntry.Bin), MenuLayout.decodeHidden("settings,bin"))
    }

    @Test fun aGroupIsNamedOnlyWhenAllOfItComesFromOneSection() {
        val g = MenuLayout.Default.groups()
        assertEquals("Browse", groupTitle(g[0]))
        assertEquals("Discover", groupTitle(g[1]))
        assertEquals("Manage", groupTitle(g[2]))
        assertNull(groupTitle(e(MenuEntry.Home, MenuEntry.Search)))
        assertNull(groupTitle(emptyList()))
        assertEquals("Browse", groupTitle(e(MenuEntry.Pinned)))
    }

    @Test fun theSummaryCountsRightAndReadsNaturally() {
        assertEquals("1 scrap · 1 box · all on this phone", menuSummary(1, 1))
        assertEquals("128 scraps · 12 boxes · all on this phone", menuSummary(128, 12))
        assertEquals("0 scraps · 3 boxes · all on this phone", menuSummary(0, 3))
        assertEquals("Nothing saved yet · stays on this phone", menuSummary(0, 0))
    }
}

class MenuStyleTest {
    @Test fun anUnknownSkinFallsBackToClassic() {
        assertEquals(MenuSkinId.Classic, MenuSkinId.of(null))
        assertEquals(MenuSkinId.Classic, MenuSkinId.of("gone"))
        assertEquals(MenuSkinId.Floating, MenuSkinId.of("float"))
        MenuSkinId.entries.forEach { assertEquals(it, MenuSkinId.of(it.key)) }
    }

    @Test fun skinKeysAreUnique() {
        assertEquals(MenuSkinId.entries.size, MenuSkinId.entries.map { it.key }.toSet().size)
    }

    @Test fun optionsAreKeptInRange() {
        val o = MenuOptions(rowSize = 9, dim = -3, action = 7).clamped()
        assertEquals(2, o.rowSize)
        assertEquals(0, o.dim)
        assertEquals(1, o.action)
    }

    @Test fun rowSizeAndDimGiveUsableNumbers() {
        assertEquals(-8, MenuOptions(rowSize = 0).rowDelta)
        assertEquals(0, MenuOptions(rowSize = 1).rowDelta)
        assertEquals(8, MenuOptions(rowSize = 2).rowDelta)
        assertTrue(MenuOptions(dim = 0).dimAlpha < MenuOptions(dim = 1).dimAlpha)
        assertTrue(MenuOptions(dim = 1).dimAlpha < MenuOptions(dim = 2).dimAlpha)
        assertEquals(3, MenuOptions.ROW_SIZES.size)
        assertEquals(3, MenuOptions.DIMS.size)
        assertEquals(2, MenuOptions.ACTIONS.size)
    }

    @Test fun theUsualStyleIsClassicWithComfortableRows() {
        val s = MenuStyle()
        assertEquals(MenuSkinId.Classic, s.skin)
        assertEquals(1, s.options.rowSize)
        assertTrue(s.options.icons)
        assertEquals(1, s.options.dim)
    }
}
