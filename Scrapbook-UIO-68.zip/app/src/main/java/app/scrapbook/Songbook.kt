package app.scrapbook

import java.security.MessageDigest

// WORKING TOGETHER WITH SONGBOOK
//
// Songbook (package com.songbook.app) keeps songs: lyrics with chords, sections, a writing desk for ideas. Like Binder, it keeps its own data and the two
// apps talk through links and explicit intents, so each one works alone and the other is simply absent when it is not installed. This file is only the
// rules (no Android in it, so it can be tested); the Android side is ui/SongbookBridge.kt. The rules, the same in both apps:
//
//   songbook://song/<id>                              opens a song in Songbook (the id is Songbook's own number)
//   action com.songbook.app.action.RECEIVE            Scrapbook -> Songbook: mode ("idea", "song" or "update"), title, body (song text), tasks + done
//                                                     (checklist lines), scrap (the scrap's uid), song (the song's id, for "update")
//   action app.scrapbook.action.SONG_LINKED           Songbook -> Scrapbook after it received: uid, song, title, what (the mode). Scrapbook adds the link line.
//   action app.scrapbook.action.EDIT_SONG             Songbook -> Scrapbook, "Edit in Scrapbook": title, body (song text), tasks + done, song, uid (a hint)
//
// A scrap is tied to its song by one line at its end, "Songbook: [name](songbook://song/<id>)", the same way Binder items are. That line travels with
// backups and restores, and a song can always find its scrap again by it. The text of a song and the text of a scrap are written differently (a scrap is
// Markdown, a song has [Chord] marks and "# Section" lines), so everything crossing over goes through songTextOf and scrapBodyOf below.

const val SONGBOOK_PACKAGE = "com.songbook.app"
const val SONGBOOK_RECEIVER = "com.songbook.app.ScrapbookReceiverActivity"
const val ACTION_SONGBOOK_RECEIVE = "com.songbook.app.action.RECEIVE"
const val ACTION_SCRAPBOOK_EDIT_SONG = "app.scrapbook.action.EDIT_SONG"
const val ACTION_SCRAPBOOK_SONG_LINKED = "app.scrapbook.action.SONG_LINKED"

object SongbookMode { const val IDEA = "idea"; const val SONG = "song"; const val UPDATE = "update" }

fun songbookSongLink(id: Long) = "songbook://song/$id"

private val SONG_LINK_IN_TEXT = Regex("songbook://song/(\\d{1,18})")

/** The ids of the songs this text links to, in order, ignoring anything inside code. */
fun songbookSongIds(body: String): List<Long> =
    SONG_LINK_IN_TEXT.findAll(maskCode(body)).mapNotNull { it.groupValues[1].toLongOrNull() }.distinct().toList()

/** The first song this text links to, or null. */
fun firstSongbookSong(body: String): Long? = songbookSongIds(body).firstOrNull()

/** The line that ties a scrap to its song: "Songbook: [name](songbook://song/<id>)". Brackets in the name would break the link, so they are dropped. */
fun songbookLinkLine(title: String, id: Long): String =
    "Songbook: [${title.replace(Regex("[\\[\\]\\n]+"), " ").trim().ifBlank { "song" }}](${songbookSongLink(id)})"

/** The body with the link line added at its end, once: a body that already links to this song is returned as it is. */
fun withSongbookLink(body: String, title: String, id: Long): String {
    if (id in songbookSongIds(body)) return body
    val line = songbookLinkLine(title, id)
    return if (body.isBlank()) line else body.trimEnd('\n') + "\n\n" + line
}

/** A line that only links the scrap to another app ("Songbook: [..](songbook://..)" or "Binder: [..](binder://..)"). It is not part of the text. */
private val LINK_LINE = Regex("^(?:Songbook|Binder): \\[[^\\]\\n]*]\\([a-z]+://\\S+\\)\\s*$")

/** [newBody] with the link lines of [oldBody] kept at its end (once each), and the link to [songId] added. Used when a song's text replaces a scrap's. */
fun withKeptLinkLines(oldBody: String, newBody: String, title: String, songId: Long): String {
    val have = newBody.lines().map { it.trim() }.toSet()
    val kept = oldBody.lines().filter { LINK_LINE.matches(it.trim()) && it.trim() !in have }
    val base = if (kept.isEmpty()) newBody.trimEnd('\n') else (newBody.trimEnd('\n') + "\n\n" + kept.joinToString("\n")).trimStart('\n')
    return withSongbookLink(base, title, songId)
}

/** What a scrap says, written the way a song is: the text, and its checklist lines apart as (text, ticked). */
class SongText(val text: String, val tasks: List<Pair<String, Boolean>>)

private val HEADING = Regex("^#{1,6}\\s+(.*\\S)\\s*$")
private val TASK = Regex("^\\s*[-*+] \\[([ xX])] (.*\\S)\\s*$")
private val BULLET = Regex("^\\s*[-*+] (.*)$")
private val QUOTE = Regex("^\\s*> ?(.*)$")
private val BOLD = Regex("\\*\\*(.+?)\\*\\*")
private val STRIKE = Regex("~~(.+?)~~")
private val MARK = Regex("==(.+?)==")
private val ITALIC = Regex("(?<![*\\w])\\*(?!\\s)(.+?)(?<!\\s)\\*(?![*\\w])")
private val STYLE = Regex("\\{(?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2}\\|(.+?)\\}")
private val CODE_TICKS = Regex("`([^`\\n]+)`")

/** A line without its formatting marks. A [Chord] is kept (it is not a link: a link has an address after it). */
fun stripInline(line: String): String {
    var s = MD_LINK.replace(line) { m -> if ("://" in m.groupValues[2]) m.groupValues[1] else m.value }
    s = STYLE.replace(s) { it.groupValues[1] }
    s = BOLD.replace(s) { it.groupValues[1] }
    s = STRIKE.replace(s) { it.groupValues[1] }
    s = MARK.replace(s) { it.groupValues[1] }
    s = ITALIC.replace(s) { it.groupValues[1] }
    return CODE_TICKS.replace(s) { it.groupValues[1] }
}

private fun tidy(lines: List<String>): String {
    val res = ArrayList<String>()
    for (l in lines) {
        if (l.isBlank() && (res.isEmpty() || res.last().isBlank())) continue
        res += l.trimEnd()
    }
    while (res.isNotEmpty() && res.last().isBlank()) res.removeAt(res.size - 1)
    return res.joinToString("\n")
}

/**
 * A scrap's body as song text. Headings become "# Section" lines, chords like [Em] stay, formatting marks go, a list marker or quote mark goes, the lines
 * of a code block are kept as they are (that is where tabs live), checklist lines are taken apart as tasks, and the Songbook / Binder link lines are left out.
 */
fun songTextOf(body: String): SongText {
    val lines = body.split("\n"); val code = codeLineStates(lines)
    val out = ArrayList<String>(); val tasks = ArrayList<Pair<String, Boolean>>()
    loop@ for (i in lines.indices) {
        val line = lines[i].trimEnd('\r')
        if (code[i] == CodeLine.OPEN || code[i] == CodeLine.CLOSE) continue@loop
        if (code[i] == CodeLine.BODY) { out += line; continue@loop }
        if (LINK_LINE.matches(line.trim())) continue@loop
        val task = TASK.matchEntire(line)
        if (task != null) { tasks += stripInline(task.groupValues[2]).trim() to (task.groupValues[1] != " "); continue@loop }
        val heading = HEADING.matchEntire(line)
        if (heading != null) { out += "# " + stripInline(heading.groupValues[1]).trim(); continue@loop }
        val bullet = BULLET.matchEntire(line)
        if (bullet != null) { out += stripInline(bullet.groupValues[1]); continue@loop }
        val quote = QUOTE.matchEntire(line)
        if (quote != null) { out += stripInline(quote.groupValues[1]); continue@loop }
        out += stripInline(line)
    }
    return SongText(tidy(out), tasks)
}

private fun isTabLine(line: String): Boolean { val t = line.trimStart(); return t.contains('|') && t.count { it == '-' } >= 3 && !t.contains('[') }

/** Song text as scrap text: tab lines go inside a code block (so their columns line up), everything else is already readable. */
fun scrapTextOf(songText: String): String {
    val out = ArrayList<String>(); var inTab = false
    for (raw in songText.split("\n")) {
        val line = raw.trimEnd('\r'); val tab = isTabLine(line)
        if (tab && !inTab) { out += "```"; inTab = true }
        if (!tab && inTab) { out += "```"; inTab = false }
        out += line
    }
    if (inTab) out += "```"
    return out.joinToString("\n").trim('\n')
}

/** A song's text and tasks as the body of a scrap: the text, then the tasks as checklist lines. */
fun scrapBodyOf(songText: String, tasks: List<Pair<String, Boolean>>): String {
    val head = scrapTextOf(songText)
    val tail = tasks.joinToString("\n") { (if (it.second) "- [x] " else "- [ ] ") + it.first }
    return listOf(head, tail).filter { it.isNotBlank() }.joinToString("\n\n")
}

/** What a song's text and tasks are made into, one string, so two of them can be compared. Trailing spaces and blank edges do not count. */
fun songCanon(text: String, tasks: List<Pair<String, Boolean>>): String =
    text.lines().joinToString("\n") { it.trimEnd() }.trim() + tasks.joinToString("") { "\n" + (if (it.second) "[x] " else "[ ] ") + it.first.trim() }

/** A short fingerprint of [songCanon], to remember "this is how the scrap and the song matched last time" without keeping the text. */
fun songSyncKey(text: String, tasks: List<Pair<String, Boolean>>): String =
    MessageDigest.getInstance("SHA-1").digest(songCanon(text, tasks).toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

/** What "Edit in Scrapbook" does when the scrap of that song exists already. */
enum class SongbookSync {
    /** Scrap and song say the same. */ SAME,
    /** Only the song changed since they matched: the scrap takes the song's text (its old text stays in History). */ TAKE_SONG,
    /** Only the scrap changed: it is kept, and "Send back" updates the song. */ KEEP_SCRAP,
    /** Both changed, or nothing is known about how they matched: the scrap is kept untouched and nothing is lost on either side. */ CONFLICT
}

/** [scrapKey] and [songKey] are [songSyncKey]s of the scrap now and of the song now; [syncedKey] is the one remembered from when they last matched (null = never). */
fun decideSync(scrapKey: String, songKey: String, syncedKey: String?): SongbookSync = when {
    scrapKey == songKey -> SongbookSync.SAME
    syncedKey != null && scrapKey == syncedKey -> SongbookSync.TAKE_SONG
    syncedKey != null && songKey == syncedKey -> SongbookSync.KEEP_SCRAP
    else -> SongbookSync.CONFLICT
}
