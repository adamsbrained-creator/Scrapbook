package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import app.scrapbook.*

// SCRAPBOOK <-> SONGBOOK, the Android side. The rules and the message formats are in Songbook.kt. Everything here sends one intent to Songbook and says
// so plainly when Songbook is not installed. The rest of the app touches this from marked hook lines ("[songbook hook N]"):
//
//   1. MainActivity.kt: handleSongbook (Songbook asks for a song to be opened as a scrap, or says which song a sent scrap became)
//   2. ArchiveViewModel.kt: editFromSongbook, songLinked, songbookTouched
//   3. Editor.kt ("Share & copy" menu page) and Pages.kt (reading view menu):  SongbookMenuRows(uid, title, body) { menu = false }
//   4. Pages.kt / Markup.kt / OpenLink.kt: songbook:// is a link scheme, like binder:// and scrapbook://
//   5. Editor.kt: takes the new text when Songbook changed the open scrap (so the next autosave cannot put the old text back)

private fun toSongbook(ctx: Context, fill: Intent.() -> Unit) {
    val i = Intent(ACTION_SONGBOOK_RECEIVE).setClassName(SONGBOOK_PACKAGE, SONGBOOK_RECEIVER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).apply(fill)
    try { ctx.startActivity(i) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Songbook isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/**
 * Sends this scrap to Songbook: [mode] is an idea, a new song, or an update of the song [songId] it is already tied to. Songbook does it without
 * coming to the front and answers with SONG_LINKED, which adds the link line to the scrap (see ArchiveViewModel.songLinked).
 */
fun sendToSongbook(ctx: Context, mode: String, uid: String, title: String, body: String, songId: Long) {
    val st = songTextOf(body)
    songbookRememberSent(ctx, uid, songSyncKey(st.text, st.tasks))
    toSongbook(ctx) {
        putExtra("mode", mode); putExtra("title", title.ifBlank { "Untitled" }); putExtra("body", st.text)
        putStringArrayListExtra("tasks", ArrayList(st.tasks.map { it.first })); putExtra("done", st.tasks.map { it.second }.toBooleanArray())
        putExtra("scrap", uid); putExtra("song", songId)
    }
}

/** Opens a songbook:// link in Songbook. */
fun openInSongbook(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Songbook isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/**
 * The Songbook rows of a scrap's menu. A scrap that is not tied to a song yet can be sent as an idea (its lines go on the writing desk) or as a song;
 * one that is can be sent back (the song's text is replaced, and Songbook keeps an Undo) or opened in Songbook. [uid] is null for a scrap that has not
 * been saved yet.
 */
@Composable
fun SongbookMenuRows(uid: String?, title: String, body: String, close: () -> Unit) {
    val ctx = LocalContext.current
    val linked = remember(body) { firstSongbookSong(body) }
    val empty = remember(body) { songTextOf(body).let { it.text.isBlank() && it.tasks.isEmpty() } }
    fun send(mode: String) {
        close()
        if (uid == null || empty) Toast.makeText(ctx, "Write something first, so there is a scrap to send", Toast.LENGTH_SHORT).show()
        else sendToSongbook(ctx, mode, uid, title, body, linked ?: -1L)
    }
    if (linked == null) {
        MenuRow("send", "Send to Songbook as an idea", "The lines go on the writing desk") { send(SongbookMode.IDEA) }
        MenuRow("send", "Send to Songbook as a song", "Starts at the Lyrics stage") { send(SongbookMode.SONG) }
    } else {
        MenuRow("undo", "Send back to Songbook", "Replaces the song's text. Songbook keeps an Undo") { send(SongbookMode.UPDATE) }
        MenuRow("external", "Open in Songbook", "The song this scrap is about") { close(); openInSongbook(ctx, songbookSongLink(linked)) }
    }
}
