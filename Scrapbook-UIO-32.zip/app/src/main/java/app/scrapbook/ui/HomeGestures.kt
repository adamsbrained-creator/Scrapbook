package app.scrapbook.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlin.math.roundToInt

// New gestures on Home (UIO 4).
//
//  Hold      Hold a box, a scrap, a section title or the greeting for a moment: it lifts a little and, when you let go, a small menu pops up next to it.
//  Drag      Keep holding and move: the thing comes along with your finger over the whole page (not only inside its own row). Let go and
//              - on a box: a scrap dropped on a box is filed in it;
//              - on one of your sections: it is added there;
//              - anywhere else: a new section is made at that spot, holding it. A section is a row of shortcuts you can rename, lay out and fill.
//
//  Reorder   Carry a thing of a section and drop it on another thing of the same section: it takes that place.
//  Empty     Hold on an empty spot of Home to open Customize home.
//
// One listener watches the whole Home page (dragHost), instead of each card listening for itself. That is what lets a dragged thing keep going when the
// page scrolls under it (the card it started from may have scrolled out of sight), and it never gets in the way of taps or of scrolling: it only
// takes over once a finger has stayed put for the hold time.

/** What is being carried. [sourceKey] is the block of the page it came from (dropping it back there does nothing); [sourceSection] is the section it was taken from, if any. */
class DragPayload(val id: String, val ref: SectionRef, val label: String, val dot: Color?, val sourceKey: String, val sourceSection: String? = null)

/** What letting go would do right now. */
sealed class DropTarget {
    object None : DropTarget()
    /** A scrap dropped on the box with this key: it is filed there. */
    class File(val box: String) : DropTarget()
    /** Dropped on one of your sections. */
    class Into(val section: String) : DropTarget()
    /** Dropped in the open: a new section, right after the block [after] (null = at the very top). */
    class NewAt(val after: String?) : DropTarget()
    /** A thing of a section dropped on another thing of the same section: it takes that thing's place. [beforeToken] is the token of that other thing (see SectionRef.token). */
    class Reorder(val section: String, val beforeToken: String) : DropTarget()
}

/** The state of one Home page's gestures: what can be held, where the drop places are, and what is being carried. */
@Stable
class HomeDrag {
    /** Something that can be held (and maybe carried). [payload] null means it can only be held, for its menu. */
    class Spot(val id: String, val rect: Rect, val payload: DragPayload?, val onHold: () -> Unit)

    private val spots = HashMap<String, Spot>()
    private val rects = HashMap<String, Rect>()

    /** Where the page's gesture area is on the screen, so a finger position can be turned into a screen position. */
    var hostOrigin: Offset = Offset.Zero
    var hostHeight: Float = 0f
    /** How tall each block of the page is (a part's key or "section:<id>"), in px, as far as the page has measured them; it is what a section that fills the page subtracts. */
    val sizes = mutableStateMapOf<String, Int>()
    /** The sections that fill themselves (they take nothing dropped on them). */
    var smartSections: Set<String> = emptySet()
    var fileOn: Boolean = true

    /** What is being carried (null when nothing is), and where the finger is on the screen. */
    var active: DragPayload? by mutableStateOf(null)
        private set
    var pos: Offset by mutableStateOf(Offset.Zero)
        private set
    /** The id of the thing that has been held and lifted, before it starts to move. */
    var held: String? by mutableStateOf(null)

    fun putSpot(s: Spot) { spots[s.id] = s }
    fun forgetSpot(id: String) { spots.remove(id) }
    fun putRect(key: String, r: Rect) { rects[key] = r }
    fun forgetRect(key: String) { rects.remove(key) }
    fun rectOf(key: String): Rect? = rects[key]

    /** The smallest thing that can be held at this screen position. */
    fun spotAt(p: Offset): Spot? = spots.values.filter { it.rect.contains(p) }.minByOrNull { it.rect.width * it.rect.height }

    fun begin(p: DragPayload, at: Offset) { active = p; pos = at; held = null }
    fun move(at: Offset) { pos = at }
    fun end() { active = null; held = null }

    /** Whether [at] (a screen position) is an empty spot of Home: nothing that can be held, no part or section of the page, and above the strip the add button lives in. */
    fun isEmptyAt(at: Offset, bottomReserve: Float): Boolean {
        if (at.y > hostOrigin.y + hostHeight - bottomReserve) return false
        return spotAt(at) == null && rects.values.none { it.contains(at) }
    }

    /** The top of the highest block of the page that is on screen. */
    fun topOfBlocks(): Float? = rects.filterKeys { !it.startsWith("box:") }.values.minOfOrNull { it.top }

    /** What letting go of [p] at screen position [at] would do. */
    fun resolve(p: DragPayload, at: Offset): DropTarget {
        if (!p.ref.box && fileOn) {
            for ((k, r) in rects) if (k.startsWith("box:") && r.contains(at)) return DropTarget.File(k.removePrefix("box:").substringBefore('\u0001'))
        }
        val own = p.sourceSection
        if (own != null && rects["section:$own"]?.contains(at) == true) {
            // Inside the section it came from: it takes the place of the nearest thing there.
            val prefix = "item:$own\u0001"
            val near = rects.entries.filter { it.key.startsWith(prefix) }.minByOrNull { (_, r) -> val c = r.center; (c.x - at.x) * (c.x - at.x) + (c.y - at.y) * (c.y - at.y) }?.key?.removePrefix(prefix)
            return if (near == null || near == p.ref.token) DropTarget.None else DropTarget.Reorder(own, near)
        }
        for ((k, r) in rects) {
            if (k.startsWith("section:") && r.contains(at)) {
                val id = k.removePrefix("section:")
                return if (id == p.sourceSection || id in smartSections) DropTarget.None else DropTarget.Into(id)
            }
        }
        if (rects[p.sourceKey]?.contains(at) == true) return DropTarget.None
        val blocks = rects.filterKeys { !it.startsWith("box:") }.map { (k, r) -> BlockSpan(k, r.top, r.bottom) }
        val after = HomeSections.dropAfter(blocks, at.y) ?: (if (rects.containsKey("header")) "header" else null)
        return DropTarget.NewAt(after)
    }
}

/** Reports where a holdable thing is, and what its hold does ([onHold] opens its menu). Does not move or scale what it is put on, so a pop-up anchored to it stays put. */
@Composable
private fun Modifier.holdSpot(state: HomeDrag, id: String, payload: DragPayload?, onHold: () -> Unit): Modifier {
    val hold by rememberUpdatedState(onHold)
    val load by rememberUpdatedState(payload)
    DisposableEffect(id) { onDispose { state.forgetSpot(id) } }
    return this.onGloballyPositioned { state.putSpot(HomeDrag.Spot(id, it.boundsInRoot(), load, { hold() })) }
}

/** The look of a held thing: it grows a little while held and fades while it is being carried. */
@Composable
private fun Modifier.liftOnHold(state: HomeDrag, id: String): Modifier {
    val scale by animateFloatAsState(if (state.held == id) 1.05f else 1f, spring(dampingRatio = .6f, stiffness = 500f), label = "pickUp")
    return this.graphicsLayer { scaleX = scale; scaleY = scale; alpha = if (state.active?.id == id) .3f else 1f }
}

/** Makes a thing holdable: it reports where it is, grows a little while held and fades while it is being carried. [onHold] is what the hold does (opens its menu). Put it first in the chain. */
@Composable
fun Modifier.pickUp(state: HomeDrag, id: String, payload: DragPayload?, onHold: () -> Unit): Modifier = holdSpot(state, id, payload, onHold).liftOnHold(state, id)

/** Reports where a block of the page, a section or a box is, so a dropped thing can find it. [key] is the part's key, "section:<id>" or "box:<name>". */
@Composable
fun Modifier.dropRect(state: HomeDrag, key: String): Modifier {
    DisposableEffect(key) { onDispose { state.forgetRect(key) } }
    return this.onGloballyPositioned { state.putRect(key, it.boundsInRoot()) }
}

/**
 * Wraps something on Home so it can be held: [menu] is the pop-up that opens next to it. With [payload] it can also be picked up and carried.
 * [menu] gets a function that closes the pop-up.
 */
@Composable
fun HoldSlot(state: HomeDrag, id: String, payload: DragPayload?, modifier: Modifier = Modifier, menu: @Composable ColumnScope.(close: () -> Unit) -> Unit, content: @Composable () -> Unit) {
    var open by remember { mutableStateOf(false) }
    // The thing grows while it is held, but the pop-up is anchored to the box around it, which does not: a pop-up anchored to a growing box was placed from its
    // enlarged edges (a little off screen on the left, so it went to the right side) and jumped back to the left when the finger let go and the box shrank.
    Box(modifier.holdSpot(state, id, payload) { open = true }) {
        Box(Modifier.liftOnHold(state, id)) { content() }
        PopupMenu(open, { open = false }) { menu { open = false } }
    }
}

/** Waits for the hold time with the finger staying put. False if it moved or lifted first (an ordinary tap or scroll: nothing is touched). */
private suspend fun AwaitPointerEventScope.heldStill(down: PointerInputChange, slop: Float): Boolean {
    val early = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
        var out = false
        while (true) {
            val ev = awaitPointerEvent(PointerEventPass.Initial)
            val c = ev.changes.firstOrNull { it.id == down.id }
            if (c == null || !c.pressed || (c.position - down.position).getDistance() > slop) { out = true; break }
        }
        out
    }
    return early == null
}

/**
 * Put on the Home page's content: watches every finger that lands on something holdable. A tap or a scroll is left completely alone. A finger that stays put for the hold time
 * lifts the thing; then, if the finger moves, the thing is carried ([onDrop] gets it, and the screen position, when the finger lifts); if it does not move, the thing's menu opens
 * when the finger lifts (at once, if the thing cannot be carried). A finger that stays put on an empty spot of Home ([emptyOn]) calls [onEmpty] (Customize home);
 * [bottomReserve] is the strip at the bottom where the add button is, which never counts as empty.
 */
@Composable
fun Modifier.dragHost(state: HomeDrag, holdOn: Boolean, dragOn: Boolean, emptyOn: Boolean, bottomReserve: Dp, onEmpty: () -> Unit, onDrop: (DragPayload, Offset) -> Unit): Modifier {
    val haptics = LocalHaptics.current
    val dropIt by rememberUpdatedState(onDrop)
    val emptyIt by rememberUpdatedState(onEmpty)
    val reservePx = with(LocalDensity.current) { bottomReserve.toPx() }
    return this
        .onGloballyPositioned { state.hostOrigin = it.positionInRoot(); state.hostHeight = it.size.height.toFloat() }
        .pointerInput(state, holdOn, dragOn, emptyOn, reservePx) {
            if (!holdOn && !dragOn && !emptyOn) return@pointerInput
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val slop = viewConfiguration.touchSlop
                val at = down.position + state.hostOrigin
                val spot = state.spotAt(at)
                if (spot == null) {
                    // Nothing to hold here. On an empty spot, a hold opens Customize home.
                    if (!emptyOn || !state.isEmptyAt(at, reservePx)) return@awaitEachGesture
                    if (!heldStill(down, slop)) return@awaitEachGesture
                    haptics.confirm()
                    emptyIt()
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                        c.consume()
                        if (!c.pressed) break
                    }
                    return@awaitEachGesture
                }
                val pl = spot.payload
                val canDrag = dragOn && pl != null
                if (!canDrag && !holdOn) return@awaitEachGesture
                if (!heldStill(down, slop)) return@awaitEachGesture
                haptics.tick()
                state.held = spot.id
                if (!canDrag) spot.onHold()
                var dragging = false
                var released = false
                try {
                    // From here on the gesture is ours: nothing underneath scrolls or taps.
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!c.pressed) { c.consume(); released = true; break }
                        if (!dragging && pl != null && canDrag && (c.position - down.position).getDistance() > slop) {
                            dragging = true
                            state.begin(pl, c.position + state.hostOrigin)
                        }
                        if (dragging) state.move(c.position + state.hostOrigin)
                        c.consume()
                    }
                    if (released) {
                        if (dragging) state.active?.let { dropIt(it, state.pos) }
                        else if (canDrag && holdOn) spot.onHold()
                    }
                } finally {
                    state.end()
                }
            }
        }
}

/** The look of the carried thing and of the place it would land: drawn over the whole page while something is being carried. */
@Composable
fun DragOverlay(state: HomeDrag, modifier: Modifier = Modifier) {
    val p = state.active ?: return
    val at = state.pos
    val acc = LocalSb.current.acc
    val d = LocalDensity.current
    val origin = state.hostOrigin
    val target = state.resolve(p, at)
    Box(modifier.fillMaxSize()) {
        when (target) {
            is DropTarget.File -> state.rectOf("box:${target.box}")?.let { TargetFrame(it, origin, acc) }
            is DropTarget.Into -> state.rectOf("section:${target.section}")?.let { TargetFrame(it, origin, acc) }
            is DropTarget.Reorder -> state.rectOf("item:${target.section}\u0001${target.beforeToken}")?.let { TargetFrame(it, origin, acc) }
            is DropTarget.NewAt -> {
                val line = (target.after?.let { state.rectOf(it)?.bottom } ?: state.topOfBlocks()?.let { it - with(d) { 18.dp.toPx() } }) ?: at.y
                val y = line + with(d) { 9.dp.toPx() } - origin.y
                Box(Modifier.offset { IntOffset(0, (y - 3.dp.toPx()).roundToInt()) }.fillMaxWidth().padding(horizontal = 24.dp).height(6.dp).clip(CircleShape).background(acc))
                Text("New section here", Modifier.align(Alignment.TopCenter).offset { IntOffset(0, (y - 38.dp.toPx()).roundToInt()) }.clip(CircleShape).background(acc).padding(horizontal = 14.dp, vertical = 6.dp),
                    color = onAccent(acc), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            else -> {}
        }
        Ghost(p, Modifier.offset { IntOffset((at.x - origin.x).roundToInt(), (at.y - origin.y).roundToInt()) })
    }
}

/** A frame around the place the carried thing would land. */
@Composable
private fun TargetFrame(r: Rect, origin: Offset, acc: Color) {
    val d = LocalDensity.current
    Box(Modifier.offset { IntOffset((r.left - origin.x).roundToInt(), (r.top - origin.y).roundToInt()) }
        .size(with(d) { r.width.toDp() }, with(d) { r.height.toDp() }).border(3.dp, acc, RoundedCornerShape(24.dp)))
}

/** The carried thing: a small floating card with its name, held just above the finger so the finger does not hide it. */
@Composable
private fun Ghost(p: DragPayload, modifier: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Row(modifier.graphicsLayer { translationX = -size.width / 2f; translationY = -size.height - 14.dp.toPx(); scaleX = 1.04f; scaleY = 1.04f }
        .shadow(16.dp, shape).background(Sb.raised, shape).padding(horizontal = 16.dp, vertical = 12.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        if (p.dot != null) Box(Modifier.size(14.dp).clip(CircleShape).background(p.dot)) else Ic("page", 18.dp, Sb.mute)
        Text(p.label, Modifier.widthIn(max = 200.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** What Home's parts need to be held: given to the page with [LocalHomeGestures]. Where it is not given (the previews in Customize home) nothing can be held. */
class HomeGestureEnv(val drag: HomeDrag, val vm: ArchiveViewModel, val actions: HomeActions, val prefs: GesturePrefs) {
    val holdOn: Boolean get() = prefs.hold
    val dragOn: Boolean get() = prefs.drag
}

val LocalHomeGestures = compositionLocalOf<HomeGestureEnv?> { null }

/** The title row of a part (Boxes, Pinned, Recent) can be held for its own menu. [id] must be different for each part. */
class PartHold(val id: String, val menu: @Composable ColumnScope.(close: () -> Unit) -> Unit)

/** Reports where a part of the page is, so a dropped thing can be placed between parts. [key] is the part's key (see HomeElement). Does nothing where nothing can be held. */
@Composable
fun Modifier.homeBlock(key: String): Modifier {
    val g = LocalHomeGestures.current ?: return this
    return dropRect(g.drag, key).sizeReport(g.drag, key)
}

/** Reports how tall a block of the page is, and forgets it when the block leaves the page. */
@Composable
fun Modifier.sizeReport(state: HomeDrag, key: String): Modifier {
    DisposableEffect(key) { onDispose { state.sizes.remove(key) } }
    return this.onSizeChanged { state.sizes[key] = it.height }
}

/** A scrap on Home, in whatever design: hold it for its menu, keep holding and move to carry it. [where] is the part it is shown in ("pinned", "recent", "continue"). */
@Composable
fun HeldScrap(n: Item, where: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val g = LocalHomeGestures.current
    if (g == null) { Box(modifier) { content() }; return }
    val id = "$where:${n.uid}"
    HoldSlot(g.drag, id, DragPayload(id, SectionRef(false, n.uid), n.displayTitle, null, where), modifier, menu = { close -> ScrapMenu(n, g.actions, g.vm, close) }, content = content)
}

/** A box on Home, in whatever design: hold it for its menu, carry it, or drop a scrap on it to file the scrap there. [name] is the box's key, [label] what it is called. */
@Composable
fun HeldBox(name: String, label: String, dot: Color, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val g = LocalHomeGestures.current
    if (g == null) { Box(modifier) { content() }; return }
    val id = "boxspot:$name"
    HoldSlot(g.drag, id, DragPayload(id, SectionRef(true, name), label, dot, "boxes"), modifier.dropRect(g.drag, "box:$name"), menu = { close -> BoxMenu(name, g.actions, close) }, content = content)
}

/** Customize home > the gestures: the switches, under the list of parts. */
@Composable
fun GestureSettings(prefs: GesturePrefs, onGuide: () -> Unit, onDraw: () -> Unit, onChange: (GesturePrefs) -> Unit) {
    SectionLabel("Gestures")
    SettingsCard {
        IconRow("info", "Gesture guide", "All of them") { onGuide() }
        IconRow("edit", "Draw gestures", "Open things by drawing") { onDraw() }
        SwitchRow("grip", "Hold for a menu", prefs.hold) { onChange(prefs.copy(hold = it)) }
        SwitchRow("layout", "Hold and drag to move", prefs.drag) { onChange(prefs.copy(drag = it)) }
        SwitchRow("folder", "Drop a scrap on a box to file it", prefs.file) { onChange(prefs.copy(file = it)) }
        SwitchRow("sliders", "Hold an empty spot for Customize home", prefs.empty) { onChange(prefs.copy(empty = it)) }
        SwitchRow("star", "Swipe scraps: recent right pins, left deletes; pinned list unpins", prefs.swipe) { onChange(prefs.copy(swipe = it)) }
        SwitchRow("edit", "Quick capture: swipe up for a checklist, hold for a voice note", prefs.capture) { onChange(prefs.copy(capture = it)) }
        SwitchRow("search", "Pull the page down to search", prefs.pull) { onChange(prefs.copy(pull = it)) }
    }
    HomeFooter("Hold a box, a scrap, a part's title or the greeting. Keep holding and move to carry a box or a scrap: drop it on a box to file a scrap there, on one of your sections to add it, on another thing of its own section to change the order, or on an empty spot of Home to start a new section.")
    SectionLabel("Double tap the greeting")
    ChoiceCard("Jump to", GesturePrefs.DOUBLE_TAP_OPTIONS, prefs.doubleTap, when (prefs.doubleTap) {
        1 -> "Opens the scrap you edited last."
        2 -> "Opens Inbox."
        3 -> "Puts on the next skin in your list and says which. Give the same double tap to the skins you want to go round."
        else -> "Nothing happens."
    }) { onChange(prefs.copy(doubleTap = it)) }
    HomeFooter("These settings belong to the skin you are wearing: another skin can have its own.")
}

/**
 * The add button of Home (the "New scrap" pill): hold it for a small menu of what to start: a scrap, a checklist, a photo, a link or a voice note. [modifier] places it (the pill's own
 * place on the screen); anywhere but Home it is just the button.
 */
@Composable
fun AddHold(modifier: Modifier, content: @Composable () -> Unit) {
    val g = LocalHomeGestures.current
    if (g == null) { Box(modifier) { content() }; return }
    HoldSlot(g.drag, "add-button", null, modifier, menu = { close ->
        PopupItem("New scrap", "edit") { close(); g.actions.quickNew("text") }
        PopupItem("Checklist", "check") { close(); g.actions.quickNew("checklist") }
        PopupItem("Photo", "image") { close(); g.actions.quickNew("photo") }
        PopupItem("Link", "link") { close(); g.actions.quickNew("link") }
        PopupItem("Voice note", "mic") { close(); g.actions.quickNew("voice") }
    }, content = content)
}

/** The search button of Home's header: hold it for a small menu of your recent searches (tap one to search for it again). Anywhere else it is just the button. */
@Composable
fun SearchHold(nav: NavController, content: @Composable () -> Unit) {
    val g = LocalHomeGestures.current
    if (g == null) { content(); return }
    val recent by g.vm.recentSearches.collectAsState()
    HoldSlot(g.drag, "search-button", null, Modifier, menu = { close -> RecentSearchMenu(recent, g.vm, nav, close) }, content = content)
}

/** The items of the recent searches menu: a new search, up to six of the last searches, and a way to clear them. */
@Composable
fun ColumnScope.RecentSearchMenu(recent: List<String>, vm: ArchiveViewModel, nav: NavController, close: () -> Unit) {
    PopupItem("New search", "search") { close(); nav.navigate("search") }
    if (recent.isEmpty()) {
        PopupItem("No recent searches yet", "search", tint = Sb.mute) { close() }
    } else {
        PopupDivider()
        recent.take(6).forEach { q -> PopupItem(q, "search") { close(); vm.pendingQuery = q; vm.rememberSearch(q); nav.navigate("search") } }
        PopupDivider()
        PopupItem("Clear recent searches", "trash", tint = Sb.danger) { close(); vm.clearSearches() }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// What the hold menus can do. Home gives each action; the menus only decide which ones to offer.
// ---------------------------------------------------------------------------------------------------------------------------------

class HomeActions(
    val open: (Item) -> Unit,
    val openBox: (String) -> Unit,
    val newScrapIn: (String) -> Unit,
    val editBox: (String) -> Unit,
    val newBoxIn: (String) -> Unit,
    val deleteBox: (String) -> Unit,
    val inboxColor: () -> Unit,
    val sortInbox: () -> Unit,
    val moveScrap: (Item) -> Unit,
    val tagScrap: (Item) -> Unit,
    val deleteScrap: (Item) -> Unit,
    val toSection: (SectionRef) -> Unit,
    val customize: () -> Unit,
    val account: () -> Unit,
    /** Opens the app's menu (the one the header's menu button opens). */
    val openMenu: () -> Unit,
    /** Pin a scrap (swipe right on a Recent row). */
    val pin: (Item) -> Unit,
    /** Delete a scrap, with the Undo message (swipe left on a Recent row). */
    val delete: (Item) -> Unit,
    /** Take a scrap off the pinned ones, with the Undo message (swipe a row of Pinned, in its list design). */
    val unpin: (Item) -> Unit,
    /** What a double tap on the greeting does. */
    val greetingDouble: () -> Unit,
    /** Starts resizing a part of Home (its corner can be dragged), from the part's hold menu. */
    val resizePart: (HomeElement) -> Unit,
    /** Makes a section that fills itself with a box's scraps (from the box's menu) or with the scraps of a tag (from a scrap's menu). */
    val smartBox: (String) -> Unit,
    val smartTag: (String) -> Unit,
    /** Starts a new scrap of a kind: "text", "checklist", "photo", "link" or "voice" (the add button's menu). */
    val quickNew: (String) -> Unit,
)

/** The menu of a scrap. Inside a section it can also take the scrap out of that section (it is only a shortcut: the scrap itself stays). */
@Composable
fun ColumnScope.ScrapMenu(n: Item, a: HomeActions, vm: ArchiveViewModel, close: () -> Unit, inSection: Boolean = false, onRemove: () -> Unit = {}) {
    val haptics = LocalHaptics.current
    PopupItem("Open", "arrow") { close(); a.open(n) }
    PopupItem(if (n.pinned) "Unpin" else "Pin", if (n.pinned) "star" else "starline") { close(); haptics.tick(); vm.togglePin(n) }
    PopupItem("Add to box", "folder") { close(); a.moveScrap(n) }
    PopupItem("Add to a section", "plus") { close(); a.toSection(SectionRef(false, n.uid)) }
    if (inSection) PopupItem("Remove from this section", "close") { close(); onRemove() }
    PopupItem("Tags", "tag") { close(); a.tagScrap(n) }
    n.tags.firstOrNull()?.let { tg -> PopupItem("Section for #$tg", "layout") { close(); a.smartTag(tg) } }
    PopupItem("Duplicate", "copy") { close(); vm.duplicate(n) }
    PopupDivider()
    PopupItem("Delete", "trash", tint = Sb.danger) { close(); a.deleteScrap(n) }
}

/** The menu of a box (Inbox has its own short list, because it is built in). */
@Composable
fun ColumnScope.BoxMenu(name: String, a: HomeActions, close: () -> Unit, inSection: Boolean = false, onRemove: () -> Unit = {}) {
    val inbox = name == "Inbox"
    PopupItem("Open", "folder") { close(); a.openBox(name) }
    PopupItem("New scrap here", "plus") { close(); a.newScrapIn(name) }
    if (inbox) {
        PopupItem("Sort Inbox", "sort") { close(); a.sortInbox() }
        PopupItem("Inbox color", "palette") { close(); a.inboxColor() }
    } else {
        PopupItem("Edit box", "edit") { close(); a.editBox(name) }
        PopupItem("New box inside", "newfile") { close(); a.newBoxIn(name) }
    }
    PopupItem("Add to a section", "layout") { close(); a.toSection(SectionRef(true, name)) }
    PopupItem("Section of its scraps", "list") { close(); a.smartBox(name) }
    if (inSection) PopupItem("Remove from this section", "close") { close(); onRemove() }
    PopupDivider()
    PopupItem(if (inbox) "Remove Inbox" else "Delete box", "trash", tint = Sb.danger) { close(); a.deleteBox(name) }
}

/** The menu of a part's title on Home (Boxes, Pinned, Recent): move it, hide it, or open Customize home. */
@Composable
fun ColumnScope.PartMenu(e: HomeElement, layout: HomeLayout, onLayout: (HomeLayout) -> Unit, a: HomeActions, close: () -> Unit) {
    val up = layout.shifted(e, -1); val down = layout.shifted(e, 1)
    if (up != layout) PopupItem("Move up", "up") { close(); onLayout(up) }
    if (down != layout) PopupItem("Move down", "down") { close(); onLayout(down) }
    PopupItem("Resize", "expand") { close(); a.resizePart(e) }
    PopupItem("Hide ${e.label}", "eyeoff") { close(); onLayout(layout.withHidden(e, true)) }
    PopupItem("Customize home", "sliders") { close(); a.customize() }
}

/** The menu of the greeting: its options live in Customize home now, so that is where this leads. */
@Composable
fun ColumnScope.GreetingMenu(a: HomeActions, close: () -> Unit) {
    PopupItem("Menu", "menu") { close(); a.openMenu() }
    PopupItem("Resize", "expand") { close(); a.resizePart(HomeElement.Greeting) }
    PopupItem("Customize home", "sliders") { close(); a.customize() }
    PopupItem("Account", "person") { close(); a.account() }
}
