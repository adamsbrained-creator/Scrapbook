package app.scrapbook.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import java.util.TimeZone

// The Calendar card of Home (the Calendar skin is one section of this kind; see CalendarMonth.kt for the dates):
//  - CalendarCardBody: the month's name with a round button each side, the weekdays, a month of round days with a small dot for each scrap made on it, and a row of boxes to narrow it down.
//  - CalendarDaySheet: the list a tapped day opens, with the scraps made that day. Home draws it (it is on the page, not in the card, which sits inside the scrolling list).
// It only reads scraps: nothing here moves, copies or deletes one. It is drawn in the fonts and colors of the app, like everything else on Home.

/** The day a tapped round cell asks Home to list, and the box (a key, null for all of them) the calendar was narrowed to at the time. */
internal class CalendarPick(val dayStart: Long, val box: String?)

/** The scraps of one day, narrowed to a box and what is inside it when [box] is not null. Newest made first. */
internal fun scrapsOfDay(items: List<Item>, shelves: List<Shelf>, dayStart: Long, box: String?, zone: TimeZone = TimeZone.getDefault()): List<Item> {
    val keys = box?.let { b -> if (b == "Inbox") setOf("Inbox") else shelves.subtreeKeys(b).toSet() }
    return CalendarMonth.byDay(items, zone)[dayStart].orEmpty().filter { keys == null || it.collection in keys }
}

/** One round day: its number, and under it up to three dots in the colors of the boxes the scraps are in. */
@Composable
private fun DayCircle(cell: CalendarCell, scraps: List<Item>, today: Boolean, size: androidx.compose.ui.unit.Dp, modifier: Modifier, onClick: () -> Unit) {
    val acc = LocalSb.current.acc
    val has = scraps.isNotEmpty()
    val base = if (!cell.inMonth) Color.Transparent else if (today) acc else Sb.surface
    val numberColor = if (!cell.inMonth) Sb.mute.copy(alpha = .35f) else if (today) onAccent(acc) else if (has) Sb.ink else Sb.ink.copy(alpha = .8f)
    val desc = buildString {
        append(cell.day)
        if (today) append(", today")
        append(", ").append(if (has) countText(scraps.size) else "no scraps")
    }
    val tapMod = if (cell.inMonth) Modifier.pressScale(.9f).tap(if (has) "Open $desc" else desc, onClick) else Modifier
    Box(modifier.size(size).clip(CircleShape).background(base).then(tapMod).semantics { contentDescription = desc }, Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(cell.day.toString(), fontFamily = headFont(), fontWeight = if (has || today) FontWeight.Bold else FontWeight.Medium, fontSize = 16.sp, color = numberColor, maxLines = 1)
            if (cell.inMonth && has) {
                val shown = scraps.take(CalendarMonth.MAX_DOTS)
                Row(Modifier.height(6.dp), Arrangement.spacedBy(3.dp), Alignment.CenterVertically) {
                    shown.forEach { n ->
                        // On the accent circle of today the dots are in the number's color, so they never vanish into it.
                        Box(Modifier.size(6.dp).clip(CircleShape).background(if (today) numberColor else boxDotColor(n.collection)))
                    }
                    if (CalendarMonth.hasMore(scraps.size)) Text("+", fontSize = 9.sp, lineHeight = 9.sp, color = numberColor, fontWeight = FontWeight.Bold)
                }
            } else if (cell.inMonth) {
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

/** The small round button at each side of the month's name. */
@Composable
private fun MonthButton(icon: String, desc: String, onClick: () -> Unit) {
    CircleBtn(desc, onClick) { Ic(icon, 20.dp, Sb.ink) }
}

/**
 * The calendar: [outer] is the shape the card has been given (between the page's margins, or filling a box you sized), and with [scrolls] (a fixed height) it scrolls inside it.
 * A tap on a day with scraps asks Home to open that day's list (env.onDay).
 */
@Composable
internal fun CalendarCardBody(s: HomeSection, env: HomeEnv, outer: Modifier, scrolls: Boolean) {
    val zone = remember { TimeZone.getDefault() }
    val now = System.currentTimeMillis()
    val today = Agenda.dayStart(now, zone)
    var month by remember(s.id) { mutableLongStateOf(CalendarMonth.monthStart(now, zone)) }
    var box by remember(s.id) { mutableStateOf<String?>(null) }
    // A box that was deleted (or hidden) meanwhile is simply All again.
    val boxes = remember(env.shelves) { env.shelves.topLevel().filter { !it.hidden } }
    val activeBox = box?.takeIf { b -> b == "Inbox" || boxes.any { it.name == b } }
    val keys = remember(activeBox, env.shelves) { activeBox?.let { b -> if (b == "Inbox") setOf("Inbox") else env.shelves.subtreeKeys(b).toSet() } }
    val byDay = remember(env.items, keys) { CalendarMonth.byDay(env.items.let { list -> if (keys == null) list else list.filter { it.collection in keys } }, zone) }
    val weekdays = remember { CalendarMonth.weekdayLabels(zone) }
    val title = CalendarMonth.title(month, !CalendarMonth.sameYear(month, now, zone), zone)
    val thisMonth = CalendarMonth.monthStart(now, zone)
    val scroll = rememberScrollState()
    val haptics = LocalHaptics.current
    // Which way the month moved last (1 later, -1 earlier), so the days slide in from that side.
    var dir by remember(s.id) { mutableIntStateOf(1) }
    fun goTo(next: Long) {
        if (next == month) return
        dir = if (next > month) 1 else -1
        month = next
        haptics.tick()
    }
    // A swipe sideways over the month goes to the next (swipe left) or the earlier (swipe right) month. It takes the drag, so the page's own swipe between pages never sees it; a tap still reaches the days.
    val swipe = Modifier.pointerInput(Unit) {
        val need = 48.dp.toPx()
        var total = 0f
        detectHorizontalDragGestures(onDragStart = { total = 0f }, onDragCancel = { total = 0f },
            onDragEnd = { if (total <= -need) goTo(CalendarMonth.addMonths(month, 1, zone)) else if (total >= need) goTo(CalendarMonth.addMonths(month, -1, zone)) }) { change, dx ->
            change.consume(); total += dx
        }
    }
    Column(outer.then(if (scrolls) Modifier.verticalScroll(scroll) else Modifier).then(swipe), Arrangement.spacedBy(16.dp)) {
        // The month: a big name between two round buttons. A tap on the name comes back to this month.
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            MonthButton("back", "Earlier month") { goTo(CalendarMonth.addMonths(month, -1, zone)) }
            Box(Modifier.weight(1f).clip(CircleShape).then(if (month != thisMonth) Modifier.tap("Back to this month") { goTo(thisMonth) } else Modifier), Alignment.Center) {
                Text(title, Modifier.padding(vertical = 4.dp).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Bold, fontSize = 34.sp, letterSpacing = (-0.5).sp,
                    textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            MonthButton("chevron", "Later month") { goTo(CalendarMonth.addMonths(month, 1, zone)) }
        }
        // The weekdays, each in a small pill, over the columns of days.
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            weekdays.forEach { d ->
                Box(Modifier.weight(1f), Alignment.Center) {
                    Text(d, Modifier.clip(CircleShape).background(Sb.surface).padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 10.sp, fontWeight = FontWeight.Medium, color = Sb.mute, maxLines = 1)
                }
            }
        }
        // The days: seven round cells to a row, as wide as the page leaves room for (never wider than 52dp, so the month does not get huge on a tablet). A month slides out and the next slides in.
        AnimatedContent(month, Modifier.fillMaxWidth(), transitionSpec = {
            val d = dir
            (slideInHorizontally(tween(240)) { w -> d * w / 3 } + fadeIn(tween(240))) togetherWith (slideOutHorizontally(tween(160)) { w -> -d * w / 3 } + fadeOut(tween(120)))
        }, label = "calendarMonth") { m ->
            val cells = remember(m) { CalendarMonth.cells(m, zone) }
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val gap = 6.dp
                val cell = minOf((maxWidth - gap * 6) / 7, 52.dp)
                Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(gap), Alignment.CenterHorizontally) {
                    cells.chunked(7).forEach { week ->
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                            week.forEach { c ->
                                Box(Modifier.weight(1f), Alignment.Center) {
                                    val scraps = byDay[c.start].orEmpty()
                                    DayCircle(c, scraps, c.start == today, cell, Modifier) { if (scraps.isNotEmpty()) env.onDay(c.start, activeBox) }
                                }
                            }
                        }
                    }
                }
            }
        }
        // The boxes to narrow the calendar to (All is every scrap). Only when there is more than one box to choose from.
        if (boxes.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            SoftChip("All", activeBox == null, Sb.surface) { box = null }
            boxes.forEach { b -> SoftChip(b.label, activeBox == b.name, Sb.surface, TAB_COLORS[b.color % TAB_COLORS.size]) { box = if (activeBox == b.name) null else b.name } }
        }
    }
}

/** The list a day opens: its date at the top, and a card for each scrap made that day, newest first. Tapping a scrap opens it. */
@Composable
internal fun CalendarDaySheet(pick: CalendarPick, items: List<Item>, shelves: List<Shelf>, nav: NavController, onDone: () -> Unit) {
    val list = remember(items, shelves, pick) { scrapsOfDay(items, shelves, pick.dayStart, pick.box) }
    val boxName = pick.box?.let { if (it == "Inbox") "Inbox" else shelves.labelOf(it) }
    Sheet(CalendarMonth.dayTitle(pick.dayStart), onDone, doneLabel = "Close", soft = true, subtitle = countText(list.size) + (boxName?.let { " in $it" } ?: "")) {
        if (list.isEmpty()) SheetNote("Nothing was made on this day.")
        else list.forEach { n -> NoteRow(n, nav, onHold = {}) }
    }
}
