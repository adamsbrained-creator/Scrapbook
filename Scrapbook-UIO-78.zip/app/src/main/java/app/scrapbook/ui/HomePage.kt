package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import app.scrapbook.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// The Home page, the page the app starts on: a greeting, a quick way to write something down, the scrap you were last in,
// your boxes, your pinned scraps and the latest ones. The full list lives on the All scraps page (see Home.kt).

/** "5 min ago", "2 h ago", "yesterday", then the date. */
private fun ago(ms: Long): String {
    val mins = ((System.currentTimeMillis() - ms) / 60_000).coerceAtLeast(0)
    val day = Fmt.of("yyyyMMdd")
    return when {
        mins < 1 -> "just now"
        mins < 60 -> "$mins min ago"
        day.format(Date(ms)) == day.format(Date()) -> "${mins / 60} h ago"
        day.format(Date(ms)) == day.format(Date(System.currentTimeMillis() - 86_400_000L)) -> "yesterday"
        else -> Fmt.of("MMM d").format(Date(ms))
    }
}

/** A section title with a small grey link on the right. With [hold] the row can be held for the part's own menu (move it, hide it, Customize home). */
@Composable
private fun SectionHeader(title: String, action: String, hold: PartHold? = null, onClick: () -> Unit) {
    val g = LocalHomeGestures.current
    val row: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(title, Modifier.asHeading(), fontSize = 18.sp, fontWeight = FontWeight.Medium, fontFamily = headFont())
            Text(action, Modifier.tap("$title: $action", onClick).padding(vertical = 6.dp), fontSize = 14.sp, color = Sb.mute)
        }
    }
    if (hold != null && g != null) HoldSlot(g.drag, hold.id, null, Modifier.fillMaxWidth(), menu = hold.menu, content = row) else row()
}

/** A small round button in the capture card. */
@Composable
private fun MiniBtn(icon: String, desc: String, onClick: () -> Unit) {
    Box(Modifier.pressScale(.88f).size(44.dp).clip(CircleShape).background(Sb.paper).tapIcon(desc, onClick), Alignment.Center) { Ic(icon, 20.dp, Sb.ink) }
}

/** Write something down right away: tap the line to start a blank scrap, or use a shortcut (checklist, photo, link). */
@Composable
private fun CaptureCard(onOpen: () -> Unit, onChecklist: () -> Unit, onImage: () -> Unit, onLink: () -> Unit) {
    val acc = LocalSb.current.acc
    Column(Modifier.fillMaxWidth().homeCard(28.dp).padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Jot something down…", Modifier.fillMaxWidth().tap("Write a new scrap", onOpen), fontSize = 17.sp, color = Sb.mute)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MiniBtn("check", "New checklist", onChecklist); MiniBtn("image", "New scrap with a photo", onImage); MiniBtn("link", "New scrap with a link", onLink)
            }
            Row(Modifier.pressScale(.94f).heightIn(min = 44.dp).clip(CircleShape).background(acc).tap("New scrap", onOpen).padding(start = 16.dp, end = 20.dp),
                Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                Ic("plus", 18.dp, onAccent(acc)); Text("New scrap", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = onAccent(acc))
            }
        }
    }
}

/** The scrap you edited last, one tap from picking up where you left off. */
@Composable
private fun ContinueCard(n: Item, dot: Color, withPreview: Boolean = false, onOpen: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.pressScale(.98f).fillMaxWidth().homeCard(28.dp).tap("Continue ${n.title}", onOpen).padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("CONTINUE", fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = accentText(acc))
            Text(n.displayTitle, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Text("${LocalShelves.current.displayName(n.collection)} · edited ${ago(n.savedAt)}", fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (withPreview) Text(remember(n.title, n.body) { previewHead(n.title, n.body) }, Modifier.padding(top = 4.dp), fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(48.dp).clip(CircleShape).background(Sb.ink), Alignment.Center) { Ic("arrow", 22.dp, Sb.paper) }
    }
}

/** Scraps are waiting in Inbox: one tap starts sorting them. Only shown while there are some, and never when Inbox is hidden. */
@Composable
private fun SortCard(count: Int, oldestDays: Int, onOpen: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.pressScale(.98f).fillMaxWidth().homeCard(28.dp).tap("Sort Inbox, $count waiting", onOpen).padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("TO SORT", fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = accentText(acc))
            Text(if (count == 1) "1 scrap in Inbox" else "$count scraps in Inbox", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (oldestDays >= 2) "The oldest has waited $oldestDays days" else "File them, keep them close or let them go", fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(48.dp).clip(CircleShape).background(Sb.ink), Alignment.Center) { Ic("arrow", 22.dp, Sb.paper) }
    }
}

@Composable
private fun HomeChip(b: BoxTile, onClick: () -> Unit) {
    Row(Modifier.pressScale(.95f).height(48.dp).homeCard(24.dp).tap("Open ${b.label}, ${b.count}", onClick).padding(horizontal = 20.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(b.tab))
        Text(b.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
        Text("${b.count}", fontSize = 15.sp, color = Sb.mute)
    }
}

@Composable
private fun NewBoxChip(onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(Modifier.height(48.dp).clip(shape).dashedOutline(Sb.mute.copy(alpha = .5f), shape).tap("New box", onClick).padding(horizontal = 18.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
        Ic("plus", 18.dp, Sb.mute); Text("New box", fontSize = 16.sp, color = Sb.mute)
    }
}

@Composable
private fun PinnedCard(n: Item, preview: Boolean, modifier: Modifier = Modifier, w: Dp = 176.dp, h: Dp = 136.dp, onClick: () -> Unit) {
    Column(modifier.pressScale(.96f).then(if (w == Dp.Unspecified) Modifier.fillMaxWidth() else Modifier.width(w)).height(h).homeCard(28.dp).tap("Open ${n.title}", onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(n.displayTitle, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.width(6.dp)); Ic("star", 14.dp, Color(0xFFFFB400))
        }
        Text(fmtDate(n.savedAt, true), fontSize = 12.sp, color = Sb.mute)
        if (preview) Text(remember(n.title, n.body) { previewHead(n.title, n.body) }, Modifier.padding(top = 6.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

// The other designs of the parts of Home (Customize home > a part's options). Each part has a classic look, which is what you get until you choose another one.

/** Capture, slim: one line to write on and a small add button. */
@Composable
private fun CaptureSlim(onOpen: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.fillMaxWidth().homeCard(30.dp).padding(start = 22.dp, end = 8.dp), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Text("Jot something down…", Modifier.weight(1f).tap("Write a new scrap", onOpen).padding(vertical = 20.dp), fontSize = 17.sp, color = Sb.mute)
        Box(Modifier.pressScale(.9f).size(46.dp).clip(CircleShape).background(acc).tapIcon("New scrap", onOpen), Alignment.Center) { Ic("plus", 20.dp, onAccent(acc)) }
    }
}

/** Capture, icons only: a row of round buttons. */
@Composable
private fun CaptureIcons(onOpen: () -> Unit, onChecklist: () -> Unit, onImage: () -> Unit, onLink: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.fillMaxWidth().homeCard(28.dp).padding(horizontal = 14.dp, vertical = 12.dp), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
        Box(Modifier.pressScale(.9f).size(52.dp).clip(CircleShape).background(acc).tapIcon("New scrap", onOpen), Alignment.Center) { Ic("edit", 22.dp, onAccent(acc)) }
        listOf(Triple("check", "New checklist", onChecklist), Triple("image", "New scrap with a photo", onImage), Triple("link", "New scrap with a link", onLink)).forEach { (icon, desc, go) ->
            Box(Modifier.pressScale(.9f).size(52.dp).clip(CircleShape).background(Sb.paper).tapIcon(desc, go), Alignment.Center) { Ic(icon, 22.dp, Sb.ink) }
        }
    }
}

/** Continue, thin: the last scrap on a single line. */
@Composable
private fun ContinueThin(n: Item, dot: Color, onOpen: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 56.dp).homeCard(28.dp).tap("Continue ${n.title}", onOpen).padding(horizontal = 20.dp, vertical = 12.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Text(n.displayTitle, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(ago(n.savedAt), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
        Ic("arrow", 20.dp, Sb.mute)
    }
}

/** Boxes, grid: two columns. */
@Composable
private fun BoxCell(b: BoxTile, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.pressScale(.97f).height(52.dp).homeCard(26.dp).tap("Open ${b.label}, ${b.count}", onClick).padding(horizontal = 18.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(b.tab))
        Text(b.label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${b.count}", fontSize = 15.sp, color = Sb.mute)
    }
}

/** Boxes, list: one box per line. */
@Composable
private fun BoxLine(b: BoxTile, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().height(56.dp).homeCard(24.dp).tap("Open ${b.label}, ${b.count}", onClick).padding(horizontal = 20.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(b.tab))
        Text(b.label, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${b.count}", fontSize = 15.sp, color = Sb.mute)
        Ic("chevron", 18.dp, Sb.mute)
    }
}

/** Pinned, list: one pinned scrap per line. */
@Composable
private fun PinnedLine(n: Item, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 56.dp).homeCard(24.dp).tap("Open ${n.title}", onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Text(n.displayTitle, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(fmtDate(n.savedAt, true), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
        Ic("star", 14.dp, Color(0xFFFFB400))
    }
}

/** Recent, compact: one short line per scrap. */
@Composable
private fun RecentLine(n: Item, dot: Color, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 52.dp).homeCard(24.dp).tap("Open ${n.title}", onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Text(n.displayTitle, Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(fmtDate(n.savedAt, false), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
    }
}

@Composable
private fun CaptureDesign(style: Int, onOpen: () -> Unit, onChecklist: () -> Unit, onImage: () -> Unit, onLink: () -> Unit) {
    when (style) {
        1 -> CaptureSlim(onOpen)
        2 -> CaptureIcons(onOpen, onChecklist, onImage, onLink)
        else -> CaptureCard(onOpen, onChecklist, onImage, onLink)
    }
}

@Composable
private fun ContinueDesign(style: Int, n: Item, dot: Color, onOpen: () -> Unit) {
    // The designs after the three of its own are layouts of sections (Hero, Banner; see SectionLooks.kt). The card around it already holds the scrap and sits between the margins.
    val shape = PartShapes.layoutFor("continueStyle", style)
    if (shape != null) { PartShape(shape, listOf(scrapEntry(n, dot)), LocalShowPreview.current, NotHeld, padded = false) { onOpen() }; return }
    when (style) {
        1 -> ContinueThin(n, dot, onOpen)
        else -> ContinueCard(n, dot, withPreview = style == 2, onOpen = onOpen)
    }
}

/** The boxes under their title: chips in a row, a grid of two columns (up to 8) or a list (up to 6). */
@Composable
private fun BoxesDesign(style: Int, tiles: List<BoxTile>, onOpen: (BoxTile) -> Unit, onNew: () -> Unit) {
    // The designs after the three of its own are layouts of sections (up to 12 boxes; see SectionLooks.kt).
    val shape = PartShapes.layoutFor("boxesStyle", style)
    if (shape != null) {
        val byName = tiles.associateBy { it.name }
        PartShape(shape, tiles.take(12).map { boxEntry(it) }, false, partHeld("boxes")) { e -> byName[e.ref.key]?.let(onOpen) }
        return
    }
    when (style) {
        1 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            tiles.take(8).chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                    pair.forEach { b -> HeldBox(b.name, b.label, b.tab, Modifier.weight(1f)) { BoxCell(b, Modifier.fillMaxWidth()) { onOpen(b) } } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        2 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { tiles.take(6).forEach { b -> HeldBox(b.name, b.label, b.tab) { BoxLine(b) { onOpen(b) } } } }
        else -> LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tiles, key = { it.name }) { b -> HeldBox(b.name, b.label, b.tab) { HomeChip(b) { onOpen(b) } } }
            item { NewBoxChip(onNew) }
        }
    }
}

/** The pinned scraps under their title: cards in a row (small, regular or large), a list (up to 8) or a grid of two columns (up to 6). */
@Composable
private fun PinnedDesign(style: Int, size: Int, pinned: List<Item>, preview: Boolean, onOpen: (Item) -> Unit) {
    val g = LocalHomeGestures.current
    // The designs after the three of its own are layouts of sections (up to 10 scraps; see SectionLooks.kt). Their size is the layout's own, so the card size does not apply.
    val shape = PartShapes.layoutFor("pinnedStyle", style)
    if (shape != null) {
        PartShape(shape, pinned.take(10).map { scrapEntry(it) }, preview, partHeld("pinned")) { e -> e.scrap?.let(onOpen) }
        return
    }
    when (style) {
        // The list is the one design where a row can be swiped (either way unpins it); in cards and grid a sideways drag belongs to scrolling, so use the hold menu there.
        1 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            pinned.take(8).forEach { n ->
                HeldScrap(n, "pinned") {
                    val unpin = { g?.actions?.unpin?.invoke(n); Unit }
                    SwipeRow(g != null && g.prefs.swipe, "starline", "Unpin ${n.displayTitle}", unpin, "starline", "Unpin ${n.displayTitle}", unpin, Modifier.fillMaxWidth()) { PinnedLine(n) { onOpen(n) } }
                }
            }
        }
        2 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            pinned.take(6).chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                    pair.forEach { n -> HeldScrap(n, "pinned", Modifier.weight(1f)) { PinnedCard(n, preview, Modifier, Dp.Unspecified, 136.dp) { onOpen(n) } } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        else -> {
            val w = listOf(148.dp, 176.dp, 224.dp)[size.coerceIn(0, 2)]
            val h = listOf(116.dp, 136.dp, 168.dp)[size.coerceIn(0, 2)]
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(pinned, key = { it.id }) { n -> HeldScrap(n, "pinned", Modifier.animateItem()) { PinnedCard(n, preview && size != 0, Modifier, w, h) { onOpen(n) } } }
            }
        }
    }
}

/** The latest scraps under their title: the usual scrap cards, or one short line each. */
@Composable
private fun RecentDesign(style: Int, recent: List<Item>, nav: NavController, dot: (Item) -> Color, onHold: (Item) -> Unit) {
    val g = LocalHomeGestures.current
    // The designs after the two of its own are layouts of sections (see SectionLooks.kt). Swiping a row to pin or delete belongs to the two classic designs; the hold menu does both.
    val shape = PartShapes.layoutFor("recentStyle", style)
    if (shape != null) {
        PartShape(shape, recent.map { scrapEntry(it, dot(it)) }, LocalShowPreview.current, partHeld("recent")) { e -> e.scrap?.let { nav.navigate("edit/${it.id}") } }
        return
    }
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(if (style == 1) 8.dp else 12.dp)) {
        recent.forEach { n ->
            HeldScrap(n, "recent") {
                // Swipe right to pin, left to delete (with the Undo message). Where nothing can be held (the preview in Customize home) the row does not move.
                SwipeRow(g != null && g.prefs.swipe, "star", "Pin ${n.displayTitle}", { g?.actions?.pin?.invoke(n) }, "trash", "Delete ${n.displayTitle}", { g?.actions?.delete?.invoke(n) }, Modifier.fillMaxWidth()) {
                    // Holding a scrap card used to ask to delete it. With the hold menu on, the menu does that (and more), so the card's own hold stays quiet.
                    if (style == 1) RecentLine(n, dot(n)) { nav.navigate("edit/${n.id}") } else NoteRow(n, nav, onHold = if (g?.holdOn == true) ({}) else ({ onHold(n) }))
                }
            }
        }
    }
}

/** The Home page: where the app starts. */
@Composable
fun HomeScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    val inboxColor by vm.inboxColor.collectAsState(); val inboxHidden by vm.inboxHidden.collectAsState()
    val welcomed by vm.welcomed.collectAsState(); val deleted by vm.deleted.collectAsState(); val header by vm.headerStyle.collectAsState()
    val navStyle by vm.navStyle.collectAsState(); val headerSize by vm.headerSize.collectAsState()
    val account by vm.account.collectAsState(); val greet by vm.greetingPrefs.collectAsState()
    // Your own sections and the gestures (hold, drag): see HomeGestures.kt and HomeSections.kt.
    val sectionsStored by vm.homeSections.collectAsState(); val gestures by vm.gesturePrefs.collectAsState()
    var listH by remember { mutableIntStateOf(0) }
    val drag = remember { HomeDrag() }; val listState = rememberLazyListState(); val scope = rememberCoroutineScope()
    drag.fileOn = gestures.file
    // Which parts of the page show and in what order (Customize home). While it is being customized the screen keeps its own copy, so a drag follows the finger
    // without waiting for the saved settings to come back; the copy is let go of shortly after Done.
    val stored by vm.homeLayout.collectAsState()
    var editing by remember { mutableStateOf(false) }
    // The skins page of Customize home (see HomeSkins.kt) and the skins themselves.
    var skinsOpen by remember { mutableStateOf(false) }
    val skinsState by vm.homeSkins.collectAsState()
    val scheduleState by vm.skinSchedule.collectAsState()
    // The look every part shares (corners, cards, space): its page in Customize home, and the saved look.
    var lookOpen by remember { mutableStateOf(false) }
    val lookStored by vm.homeLook.collectAsState()
    var draft by remember { mutableStateOf<HomeLayout?>(null) }
    // The designs chosen for the parts (their options in Customize home) are kept the same way.
    val storedStyles by vm.homeStyles.collectAsState()
    var stylesDraft by remember { mutableStateOf<HomeStyles?>(null) }
    // The sections too: dragging one in Customize home must follow the finger without waiting for the saved settings.
    var sectionsDraft by remember { mutableStateOf<List<HomeSection>?>(null) }
    if ((stored == null && draft == null) || (storedStyles == null && stylesDraft == null) || sectionsStored == null || lookStored == null) { Box(Modifier.fillMaxSize().background(t.page)); return }   // the first instant, before the saved layout is read: nothing to flash
    val layout = draft ?: stored ?: HomeLayout.Default
    val styles = stylesDraft ?: storedStyles ?: HomeStyles.Default
    val sections = sectionsDraft ?: sectionsStored ?: emptyList()
    drag.smartSections = sections.filter { it.isSmart || it.isCard }.map { it.id }.toSet()   // these hold nothing of their own, so nothing can be dropped on them
    val look = lookStored ?: HomeLook.Default
    // The accent color and the page tint of the Look are only for Home: the theme below is the app's own with that accent, and the page is painted in the tint.
    val homeTheme = rememberHomeTheme(look)
    // With a background behind the screens (Settings > Look > Background) Home's page is see-through too, so the background shows on Home like everywhere else. A page tint of the Look stays,
    // as a see-through tint over the background, so a skin that tints the page still reads as tinted.
    val appBg by vm.appBackground.collectAsState()
    val pageBg = homePageColor(look.tint, homeTheme.acc).let { c -> if (!appBg.active) c else if (look.tint == 0) Color.Transparent else c.copy(alpha = .55f) }
    // Settings has a row that leads here: it asks Home to open Customize home as soon as it shows (once).
    // Scheduled skins (see SkinSchedule.kt): while Home is on screen, look at the clock now and every half minute. Not while customizing, so a skin never changes under your hands.
    LaunchedEffect(Unit) {
        while (true) {
            if (!editing) {
                val c = java.util.Calendar.getInstance()
                vm.tickSkinSchedule(c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE), (c.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7)
            }
            delay(30_000)
        }
    }
    LaunchedEffect(Unit) { if (vm.pendingCustomize) { vm.pendingCustomize = false; draft = layout; stylesDraft = styles; editing = true } }
    LaunchedEffect(editing, stored, storedStyles, sectionsStored) {
        if (!editing && (draft != null || stylesDraft != null || sectionsDraft != null)) {
            if ((draft == null || stored == draft) && (stylesDraft == null || storedStyles == stylesDraft) && (sectionsDraft == null || sectionsStored == sectionsDraft)) { draft = null; stylesDraft = null; sectionsDraft = null }
            else { delay(500); draft = null; stylesDraft = null; sectionsDraft = null }
        }
    }
    val hs = listOf(.8f, 1f, 1.2f)[headerSize.coerceIn(0, 2)]
    val snack = remember { SnackbarHostState() }
    var menuSheet by remember { mutableStateOf(false) }; var deletingScrap by remember { mutableStateOf<Item?>(null) }
    val clipboard = LocalClipboardManager.current
    LaunchedEffect(deleted) {
        if (deleted != null) { val r = snack.showSnackbar("Scrap deleted", "Undo", duration = SnackbarDuration.Long); if (r == SnackbarResult.ActionPerformed) vm.undoDelete() else vm.clearDeleted() }
    }
    val latest = remember(all) { all.maxByOrNull { it.savedAt } }
    val waiting = remember(all) { all.toSort().size }
    val oldestDays = remember(all) { oldestWaitingDays(all, System.currentTimeMillis()) }
    val pinned = remember(all) { all.filter { it.pinned }.sortedByDescending { it.savedAt } }
    // Recent is what is not already shown above: pinned scraps have their own row and the newest one is the Continue card.
    val recentCount = HomeStyleKey.RecentCount.number(styles[HomeStyleKey.RecentCount])
    val recent = remember(all, latest, recentCount) { all.filter { !it.pinned && it.id != latest?.id }.sortedByDescending { it.savedAt }.take(recentCount) }
    // The line under a part's name in Customize home: what it is, or the design chosen for it.
    fun noteOf(e: HomeElement, base: String) = styles.summary(e).let { if (it.isEmpty()) base else "Design: $it" }
    val notes = mapOf(
        HomeElement.Header to "Menu, wordmark and search",
        HomeElement.Greeting to noteOf(HomeElement.Greeting, "Your hello and picture"),
        HomeElement.Capture to if (navStyle == ADD_BUTTON_WRITING_BAR) "Hidden while the add button is the Writing bar" else noteOf(HomeElement.Capture, "Write something down"),
        HomeElement.Continue to if (latest == null) "Shows once you have a scrap" else noteOf(HomeElement.Continue, "The scrap you edited last"),
        HomeElement.Sort to if (inboxHidden) "Inbox is hidden" else "Shows while Inbox has scraps",
        HomeElement.Boxes to noteOf(HomeElement.Boxes, "Your boxes in a row"),
        HomeElement.Pinned to if (pinned.isEmpty()) "Shows once you pin a scrap" else noteOf(HomeElement.Pinned, "${pinned.size} pinned"),
        HomeElement.Recent to noteOf(HomeElement.Recent, "The latest scraps"),
    )
    val boxesByActivity by vm.homeBoxesActive.collectAsState()
    // When each box was last worked in (its newest scrap), found in one pass over the scraps.
    val newestByBox = remember(all) { HashMap<String, Long>().also { m -> all.forEach { n -> if (n.savedAt > (m[n.collection] ?: Long.MIN_VALUE)) m[n.collection] = n.savedAt } } }
    val countByBox = remember(all) { all.groupingBy { it.collection }.eachCount() }
    val showPreview = LocalShowPreview.current
    fun colorOf(box: String): Color =
        if (box == "Inbox") (if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size])
        else shelves.firstOrNull { it.name == box }?.let { TAB_COLORS[it.color % TAB_COLORS.size] } ?: TAB_GRAY
    /** Opens a new scrap, optionally with some text already in it or straight to the photo picker. */
    fun newScrap(body: String? = null, image: Boolean = false, record: Boolean = false) { vm.pendingShelf = null; vm.pendingBody = body; vm.pendingImage = image; vm.pendingRecord = record; nav.navigate("edit/0") }
    fun linkStart(): String { val c = clipboard.getText()?.text?.trim().orEmpty(); return if (Regex("^https?://\\S+$").matches(c)) c else "https://" }

    // The boxes shown on Home, in order (also used by the preview of the Boxes options).
    val inbox = countByBox["Inbox"] ?: 0
    val inboxTile = if (inboxHidden) emptyList<BoxTile>() else listOf(BoxTile("Inbox", inbox, colorOf("Inbox")))
    val tiles0 = shelves.topLevel().map { BoxTile(it.name, countByBox[it.name] ?: 0, TAB_COLORS[it.color % TAB_COLORS.size], it.label, shelves.childrenOf(it.name).size) } + inboxTile
    // The row follows your work: Inbox first while it has scraps, then the boxes you edited most recently (counting the boxes inside them), empty ones last.
    // Switch it off in Settings for your own order.
    val tiles = if (!boxesByActivity) tiles0 else remember(newestByBox, shelves, inboxHidden, tiles0) {
        val last = HashMap<String, Long>()
        shelves.topLevel().forEach { b -> shelves.subtreeKeys(b.name).mapNotNull { k -> newestByBox[k] }.maxOrNull()?.let { t0 -> last[b.name] = t0 } }
        if (!inboxHidden) newestByBox["Inbox"]?.let { t0 -> last["Inbox"] = t0 }
        orderBoxesByActivity(tiles0.map { b -> b.name }, last).mapNotNull { nm -> tiles0.firstOrNull { b -> b.name == nm } }
    }
    /** A part as it looks with the designs now chosen, for the preview in its options. Only to look at: the options page puts a layer over it that blocks taps. */
    @Composable
    fun PartPreview(el: HomeElement) {
        val none = { }
        when (el) {
            HomeElement.Header -> Box(Modifier.padding(horizontal = 16.dp)) { MainHeader(header, hs, nav, none) }
            HomeElement.Capture -> Box(Modifier.padding(horizontal = 20.dp)) { CaptureDesign(styles[HomeStyleKey.CaptureStyle], none, none, none, none) }
            HomeElement.Continue -> latest?.let { n -> Box(Modifier.padding(horizontal = 20.dp)) { ContinueDesign(styles[HomeStyleKey.ContinueStyle], n, colorOf(n.collection), none) } }
                ?: Text("Shows once you have a scrap.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute)
            HomeElement.Boxes -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Boxes", "See all", onClick = none)
                BoxesDesign(styles[HomeStyleKey.BoxesStyle], tiles, { _ -> }, none)
            }
            HomeElement.Pinned -> if (pinned.isEmpty()) Text("Shows once you pin a scrap.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute) else Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Pinned", "${pinned.size} ${if (pinned.size == 1) "scrap" else "scraps"}", onClick = none)
                PinnedDesign(styles[HomeStyleKey.PinnedStyle], styles[HomeStyleKey.PinnedSize], pinned, showPreview) { _ -> }
            }
            HomeElement.Recent -> if (recent.isEmpty()) Text("Shows once you have more scraps.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute) else Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Recent", "All scraps", onClick = none)
                RecentDesign(styles[HomeStyleKey.RecentStyle], recent, nav, { n -> colorOf(n.collection) }) { _ -> }
            }
            else -> {}
        }
    }

    // ----- Gestures (UIO 4): the menus that open when something is held, what letting go of a carried thing does, and your sections. -----
    var editBoxKey by remember { mutableStateOf<String?>(null) }; var deleteBoxKey by remember { mutableStateOf<String?>(null) }
    var newBoxIn by remember { mutableStateOf<String?>(null) }; var inboxSheet by remember { mutableStateOf(false) }
    var moveScrap by remember { mutableStateOf<Item?>(null) }; var tagScrap by remember { mutableStateOf<Item?>(null) }
    var sectionEdit by remember { mutableStateOf<String?>(null) }; var toSection by remember { mutableStateOf<SectionRef?>(null) }
    // The section whose corner can be dragged to resize it, or null. Back ends it.
    var resizeId by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = resizeId != null) { resizeId = null }
    var addSectionSheet by remember { mutableStateOf(false) }
    val haptics = LocalHaptics.current
    // The one-time card about the gestures: it comes a moment after Home, only when there is something to hold, and goes for good with "Got it", with the guide or with the first hold.
    val hintSeen by vm.gestureHintSeen.collectAsState()
    var guideSheet by remember { mutableStateOf(false) }
    var buttonPick by remember { mutableStateOf<SettingPick?>(null) }
    var hintReady by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(1500); hintReady = true }
    LaunchedEffect(drag.held) { if (drag.held != null && hintSeen == false) vm.seeGestureHint() }
    fun say(msg: String, action: String? = null, onAction: () -> Unit = {}) {
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            val r = snack.showSnackbar(msg, action, duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) onAction()
        }
    }
    fun boxLabel(key: String) = if (key == "Inbox") "Inbox" else shelves.labelOf(key)
    // The newest saved sections, read at the moment of the change, so two quick changes never undo each other.
    fun cur(): List<HomeSection> = vm.homeSections.value.orEmpty()
    fun put(list: List<HomeSection>) = vm.setHomeSections(list)
    val ops = SectionOps(
        edit = { id -> sectionEdit = id },
        move = { id, dir -> haptics.tick(); put(HomeSections.move(layout.order, layout.hidden, cur(), id, dir)) },
        delete = { id -> val before = cur(); if (sectionEdit == id) sectionEdit = null; put(HomeSections.remove(before, id)); say("Section deleted", "Undo") { put(before) } },
        rename = { id, t -> put(HomeSections.update(cur(), id) { it.copy(title = t) }) },
        layout = { id, l -> put(HomeSections.update(cur(), id) { it.copy(layout = l) }) },
        toggle = { id, r -> val has = cur().firstOrNull { it.id == id }?.has(r) == true; put(if (has) HomeSections.withoutRef(cur(), id, r) else HomeSections.withRef(cur(), id, r)) },
        remove = { id, r -> put(HomeSections.withoutRef(cur(), id, r)) },
        rule = { id, r, t, refs -> put(HomeSections.update(cur(), id) { it.copy(rule = r, title = t ?: it.title, refs = refs ?: it.refs) }) },
        card = { id, c -> put(HomeSections.update(cur(), id) { it.copy(card = c) }) },
        showTitle = { id, on -> put(HomeSections.update(cur(), id) { it.copy(showTitle = on) }) },
        size = { id, w, h -> put(HomeSections.sized(cur(), id, w, h)) },
        resize = { id -> resizeId = id },
        space = { id, dp -> put(HomeSections.spaced(cur(), id, dp)) },
        style = { id, f -> put(HomeSections.update(cur(), id) { it.copy(style = f(it.style).clamped()) }) },
        sizing = { id, w, h, fill -> put(HomeSections.update(cur(), id) { s -> val sized = HomeSections.sized(listOf(s), s.id, w, h).first(); sized.copy(style = sized.style.copy(fill = fill)) }) },
        addTimeline = {
            val made = HomeSection(HomeSections.newId(), "This week", SectionLayout.Timeline, "", emptyList(), SectionRule(SectionRule.WEEK))
            val before = cur()
            put(HomeSections.insert(layout.order, before, made, HomeSections.slots(layout.order, before).lastOrNull()?.key))
            sectionEdit = made.id
        },
        addAgenda = {
            val made = HomeSection(HomeSections.newId(), SectionCard.defaultTitle(SectionCard.TABS), SectionLayout.Agenda, "", card = SectionCard(SectionCard.TABS, SectionTabs.encode(SectionTabs.DEFAULT)))
            val before = cur()
            put(HomeSections.insert(layout.order, before, made, HomeSections.slots(layout.order, before).lastOrNull()?.key))
            sectionEdit = made.id
        },
        add = { c ->
            val made = HomeSection(HomeSections.newId(), c?.let { SectionCard.defaultTitle(it.kind) } ?: "", SectionLayout.Cards, "", card = c)
            val before = cur()
            put(HomeSections.insert(layout.order, before, made, HomeSections.slots(layout.order, before).lastOrNull()?.key))
            sectionEdit = made.id
        },
        newWith = { r ->
            val made = HomeSection(HomeSections.newId(), "", SectionLayout.Cards, "", listOf(r))
            val before = cur()
            put(HomeSections.insert(layout.order, before, made, HomeSections.slots(layout.order, before).lastOrNull()?.key))
            say("New section created", "Edit") { sectionEdit = made.id }
        },
    )
    /** Makes a section that fills itself by [rule], at the end of the page, with a message to edit it. */
    fun makeSmart(rule: SectionRule) {
        val made = HomeSection(HomeSections.newId(), ruleTitle(rule, shelves), SectionLayout.Cards, "", emptyList(), rule)
        val before = cur()
        put(HomeSections.insert(layout.order, before, made, HomeSections.slots(layout.order, before).lastOrNull()?.key))
        haptics.confirm()
        say("Section created at the end of Home", "Edit") { sectionEdit = made.id }
    }
    val boxImporter = rememberBoxImporter(vm) { m -> say(m) }
    val actions = HomeActions(
        open = { n -> nav.navigate("edit/${n.id}") },
        openBox = { b -> nav.navigate("shelf/$b") },
        newScrapIn = { b -> vm.pendingShelf = if (b == "Inbox") null else b; vm.pendingBody = null; vm.pendingImage = false; nav.navigate("edit/0") },
        editBox = { b -> editBoxKey = b },
        newBoxIn = { b -> newBoxIn = b },
        deleteBox = { b -> deleteBoxKey = b },
        inboxColor = { inboxSheet = true },
        sortInbox = { nav.navigate("sort") },
        moveScrap = { n -> moveScrap = n },
        tagScrap = { n -> tagScrap = n },
        deleteScrap = { n -> deletingScrap = n },
        toSection = { r -> toSection = r },
        customize = { draft = layout; stylesDraft = styles; editing = true },
        account = { nav.navigate("account") },
        openMenu = { menuSheet = true },
        pin = { n -> vm.togglePin(n); say("Pinned \"${n.displayTitle}\"", "Undo") { vm.togglePin(n.copy(pinned = true)) } },
        delete = { n -> vm.delete(n) },
        unpin = { n -> vm.togglePin(n); say("Unpinned \"${n.displayTitle}\"", "Undo") { vm.togglePin(n.copy(pinned = false)) } },
        resizePart = { e -> resizeId = "part:${e.key}" },
        greetingDouble = {
            when (gestures.doubleTap) {
                1 -> { val last = latest; if (last != null) nav.navigate("edit/${last.id}") else say("Nothing to continue yet") }
                2 -> nav.navigate("shelf/Inbox")
                3 -> { val name = vm.nextSkin(); say(if (name != null) "Skin: $name" else "Add another skin to go round them") }
                else -> {}
            }
        },
        smartBox = { b -> makeSmart(SectionRule(SectionRule.BOX, b)) },
        smartTag = { tg -> makeSmart(SectionRule(SectionRule.TAG, tg)) },
        importInto = { b, folder -> if (folder) boxImporter.folder(b) else boxImporter.files(b) },
        quickNew = { k ->
            when (k) {
                "checklist" -> newScrap("- [ ] ")
                "photo" -> newScrap(image = true)
                "link" -> newScrap(linkStart())
                "voice" -> newScrap(record = true)
                else -> newScrap()
            }
        },
    )
    // The pill tabs of a tabs card can be docked to the screen (the Agenda skin): Home keeps a strip clear at the bottom for them, and they stay put while the page's list moves.
    val tabPicks = remember { mutableStateMapOf<String, Int>() }
    // The day a Calendar card was tapped on: its list opens as a sheet over the page (a card sits inside the scrolling list, so the sheet cannot be drawn there).
    var calendarDay by remember { mutableStateOf<CalendarPick?>(null) }
    val dockSec = SectionTabs.dockHost(sections)
    val menuFloat = HomeElement.Header in layout.hidden && styles[HomeStyleKey.MenuButton] == 3 && navStyle != 1 && navStyle != 2
    val bottomRoom = if (dockSec != null) (if (navStyle == ADD_BUTTON_WRITING_BAR) DOCK_ROOM_DP + 58 else DOCK_ROOM_DP).dp else navClearance(navStyle, 140.dp)
    // A section that fills the page: what the list has room for, less the blocks above it and the space between them, and the strip at the bottom the add button (or the docked tabs) needs.
    val fillDensity = LocalDensity.current
    /** What the page has left for section [id] in dp (it can be less than a section needs), and the height in dp of what comes after it. */
    fun roomFor(id: String): Pair<Int, Int> {
        var above = 0
        var blocks = 0
        var below = 0
        var passed = false
        for (sl in HomeSections.slots(layout.order, sections)) {
            if (sl is HomeSlot.Sec && sl.section.id == id) { passed = true; continue }
            val h = drag.sizes[sl.key] ?: 0
            if (passed) below += h else if (h > 0) { above += h; blocks++ }
        }
        val room = listH - above - with(fillDensity) { (look.gap.dp * blocks + bottomRoom).toPx() }
        return (room / fillDensity.density).toInt() to (below / fillDensity.density).toInt()
    }
    fun fillFor(id: String): Int = if (listH <= 0) 0 else roomFor(id).first.coerceAtLeast(220)
    // A docked section that fills the page with nothing after it makes Home hold still: the header stays, and only the list inside the section scrolls.
    val locked = dockSec != null && dockSec.style.fill && listH > 0 && roomFor(dockSec.id).let { (room, below) -> SectionTabs.pageLocked(room, below, 220) }
    // Holding still starts from the top, so a page that was scrolled before cannot stay stuck partway.
    LaunchedEffect(locked) { if (locked) listState.scrollToItem(0) }
    val env = HomeEnv(vm, nav, all, shelves, countByBox, inboxHidden, { b -> colorOf(b) }, drag, actions, ops, showPreview, resizeId, ::fillFor, dockSec?.id, { id -> tabPicks[id] ?: 0 }, { id, i -> tabPicks[id] = i }, { d, b -> calendarDay = CalendarPick(d, b) })
    val gestureEnv = HomeGestureEnv(drag, vm, actions, gestures)
    val sizes by vm.homeSizes.collectAsState()
    /** A part of Home as one item of the page, in the frame of the size you gave it (see PartFrame). */
    fun LazyListScope.partItem(e: HomeElement, content: @Composable () -> Unit) {
        item(key = e.key) { PartFrame(e, sizes[e], resizeId == "part:${e.key}", { w, h -> vm.setHomeSizes(sizes.with(e, w, h)) }, { resizeId = null }, content) }
    }
    fun holdOf(e: HomeElement) = PartHold("part:${e.key}") { close -> PartMenu(e, layout, { next -> vm.setHomeLayout(next) }, actions, close) }
    fun LazyListScope.sectionItems(list: List<HomeSection>) {
        // A section with a space of its own below it changes the page's space (Look > Space between parts) by the difference.
        list.forEach { sec -> item(key = "section-${sec.id}") { SectionBlock(sec, env, Modifier.moreSpaceBelow(if (sec.spaceBelow >= 0) (sec.spaceBelow - look.gap).toFloat() else 0f).appear("sec-${sec.id}")) } }
    }
    /** What letting go of a carried thing does: file a scrap in a box, add it to a section, or start a new section. Every one can be undone. */
    fun handleDrop(p: DragPayload, at: Offset) {
        val before = cur()
        when (val t = drag.resolve(p, at)) {
            is DropTarget.None -> {}
            is DropTarget.File -> {
                val n = all.firstOrNull { it.uid == p.ref.key }
                if (n != null) {
                    if (n.collection == t.box) say("Already in ${boxLabel(t.box)}")
                    else { vm.save(n.copy(collection = t.box)); haptics.confirm(); say("Moved to ${boxLabel(t.box)}", "Undo") { vm.save(n) } }
                }
            }
            is DropTarget.Into -> {
                put(HomeSections.moveRef(before, p.sourceSection, t.section, p.ref)); haptics.confirm()
                say("Added to ${before.firstOrNull { it.id == t.section }?.name ?: "the section"}", "Undo") { put(before) }
            }
            is DropTarget.Reorder -> {
                val idx = before.firstOrNull { it.id == t.section }?.refs?.indexOfFirst { it.token == t.beforeToken } ?: -1
                if (idx >= 0) { put(HomeSections.reorder(before, t.section, p.ref, idx)); haptics.confirm() }
            }
            is DropTarget.NewAt -> {
                val made = HomeSection(HomeSections.newId(), "", SectionLayout.Cards, "", listOf(p.ref))
                val src = p.sourceSection
                val base = if (src != null) HomeSections.withoutRef(before, src, p.ref) else before
                put(HomeSections.insert(layout.order, base, made, t.after)); haptics.confirm()
                say("New section created", "Edit") { sectionEdit = made.id }
            }
        }
    }
    // While something is carried near the top or bottom edge, the page scrolls on its own so it can be taken anywhere.
    val density = LocalDensity.current
    // Pull the page down at its top to open search (see HomeSwipes.kt).
    val pullOn = rememberUpdatedState(gestures.pull && !editing)
    val goSearch = rememberUpdatedState({ nav.navigate("search") })
    val pullSearch = remember { PullToSearch(with(density) { 88.dp.toPx() }, haptics, { pullOn.value }, { goSearch.value() }) }
    LaunchedEffect(drag.active != null) {
        if (drag.active == null) return@LaunchedEffect
        val edge = with(density) { 96.dp.toPx() }
        val speed = with(density) { 14.dp.toPx() }
        while (true) {
            delay(16)
            val y = drag.pos.y - drag.hostOrigin.y
            val up = ((edge - y) / edge).coerceIn(0f, 1f)
            val down = if (drag.hostHeight > 0f) ((y - (drag.hostHeight - edge)) / edge).coerceIn(0f, 1f) else 0f
            if (up > 0f) listState.scrollBy(-speed * (.3f + .7f * up)) else if (down > 0f) listState.scrollBy(speed * (.3f + .7f * down))
        }
    }

    CompositionLocalProvider(LocalHomeLook provides look, LocalSb provides homeTheme) {
    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = pageBg, snackbarHost = { SnackbarHost(snack) { d -> SwipeAway({ d.dismiss() }) { Snackbar(d, shape = RoundedCornerShape(20.dp), containerColor = Sb.ink, contentColor = Sb.card, actionColor = t.acc) } } }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad).dragHost(drag, gestures.hold, gestures.drag, gestures.empty && !editing, 140.dp, { draft = layout; stylesDraft = styles; editing = true }) { p, at -> handleDrop(p, at) }) {
                if (editing) {
                    val skins = skinsState
                    if (lookOpen) {
                        HomeLookPage(look, { vm.setHomeLook(it) }, { lookOpen = false }) {
                            Column(verticalArrangement = Arrangement.spacedBy(look.gap.dp)) {
                                PartPreview(HomeElement.Capture); PartPreview(HomeElement.Continue); PartPreview(HomeElement.Boxes)
                            }
                        }
                    } else if (skinsOpen && skins != null) {
                        // Putting a skin on changes the saved layout and designs, so the copies kept while customizing are let go and the saved ones show.
                        SkinsPage(skins, { skinsOpen = false },
                            onWear = { id -> vm.wearSkin(id); draft = null; stylesDraft = null; sectionsDraft = null },
                            onNew = { vm.newSkin() },
                            onReady = { key -> vm.wearReadySkin(key); draft = null; stylesDraft = null; sectionsDraft = null },
                            onImport = { skin -> vm.importSkin(skin) },
                            schedule = scheduleState, onRules = { rules -> vm.setSkinRules(rules) },
                            onRestore = { skin, index -> vm.restoreSkin(skin, index) },
                            onRestoreValues = { id, values -> vm.restoreSkinValues(id, values); draft = null; stylesDraft = null; sectionsDraft = null },
                            onRename = { id, name -> vm.renameSkin(id, name) },
                            onCopy = { id -> vm.duplicateSkin(id) },
                            onReset = { id -> vm.resetSkin(id); draft = null; stylesDraft = null; sectionsDraft = null },
                            onDelete = { id -> vm.deleteSkin(id) })
                    } else {
                        HomeCustomize(layout, notes, { next -> draft = next; vm.setHomeLayout(next) }, { editing = false; skinsOpen = false; lookOpen = false }, withOptions = HomeElement.entries.toSet(),
                            options = { el, back ->
                                // Every part can be resized: its options page ends with its size, and Resize on Home leads back to the page with the corner handle.
                                val sizeSection: @Composable () -> Unit = { PartSizeSection(el, sizes[el], { w, h -> vm.setHomeSizes(sizes.with(el, w, h)) }) { resizeId = "part:${el.key}"; editing = false; skinsOpen = false; lookOpen = false } }
                                if (el == HomeElement.Greeting) GreetingOptions(vm, back, sizeSection)
                                else HomeDesignOptions(el, styles, { next -> stylesDraft = next; vm.setHomeStyles(next) }, back, extras = { openPick -> HomeExtras(el, vm, openPick); sizeSection() }) { PartPreview(el) }
                            },
                            footer = {
                                ButtonsSettings(navStyle, styles[HomeStyleKey.MenuButton], { vm.setNav(it) }, { i -> val next = styles.with(HomeStyleKey.MenuButton, i); stylesDraft = next; vm.setHomeStyles(next) }, { buttonPick = it })
                                GestureSettings(gestures, { guideSheet = true }, { nav.navigate("draw") }) { vm.setGesturePrefs(it) }
                            },
                            sections = sections, onSections = { next -> sectionsDraft = next; vm.setHomeSections(next) }, onEditSection = { id -> sectionEdit = id }, onAddSection = { addSectionSheet = true },
                            top = { Column { skins?.let { SkinCard(it.current.name, it.current.builtIn && it.current.changed) { skinsOpen = true } }; LookCard(look) { lookOpen = true } } })
                    }
                } else {
                CompositionLocalProvider(LocalHomeGestures provides gestureEnv) {
                LazyColumn(Modifier.fillMaxSize().nestedScroll(pullSearch).onSizeChanged { listH = it.height }, state = listState, userScrollEnabled = !locked, contentPadding = PaddingValues(bottom = bottomRoom), verticalArrangement = Arrangement.spacedBy(look.gap.dp)) {
                    // A hidden header still leaves the menu button, so the menu (and Customize home with it) can always be reached.
                    if (HomeElement.Header in layout.hidden && (styles[HomeStyleKey.MenuButton] < 2 || (styles[HomeStyleKey.MenuButton] == 3 && navStyle == 2))) item(key = "menu") { Box(Modifier.appear("hdr").homeBlock("header").padding(horizontal = 16.dp)) { MenuOnlyHeader(styles[HomeStyleKey.MenuButton] == 1) { menuSheet = true } } }
                    sectionItems(sections.filter { it.anchor.isEmpty() })
                    for (el in layout.order) {
                        if (el !in layout.hidden) when (el) {
                            HomeElement.Header -> partItem(HomeElement.Header) { Box(Modifier.appear("hdr").homeBlock("header").padding(horizontal = 16.dp)) { MainHeader(header, hs, nav) { menuSheet = true } } }
                            HomeElement.Greeting -> partItem(HomeElement.Greeting) { HoldSlot(drag, "part:greeting", null, Modifier.homeBlock("greeting").onDoubleTap(gestures.doubleTap != 0) { actions.greetingDouble() }, menu = { close -> GreetingMenu(actions, close) }) { GreetingHub(account, greet, all.size, if (inboxHidden) 0 else waiting, pinned.size, Modifier.appear("greet"), style = styles[HomeStyleKey.GreetingStyle], picLeft = styles[HomeStyleKey.GreetingPicture] == 1,
                            bg = styles[HomeStyleKey.GreetingBackground], shape = styles[HomeStyleKey.GreetingShape], anim = styles[HomeStyleKey.GreetingAnimation]) { nav.navigate("account") } } }
                            HomeElement.Capture -> { if (navStyle != ADD_BUTTON_WRITING_BAR) partItem(HomeElement.Capture) { Box(Modifier.appear("capture").homeBlock("capture").padding(horizontal = 20.dp)) { CaptureGestures({ newScrap("- [ ] ") }, { newScrap(record = true) }) { CaptureDesign(styles[HomeStyleKey.CaptureStyle], { newScrap() }, { newScrap("- [ ] ") }, { newScrap(image = true) }, { newScrap(linkStart()) }) } } } }
                            HomeElement.Continue -> { latest?.let { n -> partItem(HomeElement.Continue) { Box(Modifier.appear("continue").homeBlock("continue").padding(horizontal = 20.dp)) { HeldScrap(n, "continue") { ContinueDesign(styles[HomeStyleKey.ContinueStyle], n, colorOf(n.collection)) { nav.navigate("edit/${n.id}") } } } } } }
                            HomeElement.Sort -> { if (waiting > 0 && !inboxHidden) partItem(HomeElement.Sort) { Box(Modifier.appear("sort").homeBlock("sort").padding(horizontal = 20.dp)) { SortCard(waiting, oldestDays) { nav.navigate("sort") } } } }
                            HomeElement.Boxes -> {
                                partItem(HomeElement.Boxes) {
                                    Column(Modifier.appear("boxes").homeBlock("boxes"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader("Boxes", "See all", holdOf(HomeElement.Boxes)) { nav.navigate("collections") }
                                        BoxesDesign(styles[HomeStyleKey.BoxesStyle], tiles, { b -> nav.navigate("shelf/${b.name}") }) { nav.navigate("collections") }
                                    }
                                }
                            }
                            HomeElement.Pinned -> {
                                if (pinned.isNotEmpty()) partItem(HomeElement.Pinned) {
                                    Column(Modifier.appear("pinned").homeBlock("pinned"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader("Pinned", "${pinned.size} ${if (pinned.size == 1) "scrap" else "scraps"}", holdOf(HomeElement.Pinned)) { nav.navigate("shelf/Pinned") }
                                        PinnedDesign(styles[HomeStyleKey.PinnedStyle], styles[HomeStyleKey.PinnedSize], pinned, showPreview) { n -> nav.navigate("edit/${n.id}") }
                                    }
                                }
                            }
                            HomeElement.Recent -> {
                                if (recent.isNotEmpty()) partItem(HomeElement.Recent) {
                                    Column(Modifier.homeBlock("recent"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader("Recent", "All scraps", holdOf(HomeElement.Recent)) { nav.navigate("scraps") }
                                        RecentDesign(styles[HomeStyleKey.RecentStyle], recent, nav, { n -> colorOf(n.collection) }) { n -> deletingScrap = n }
                                    }
                                } else if (all.isEmpty()) item(key = "recent") { Text(if (navStyle == 2) "No scraps yet. Write your first one below." else "No scraps yet. Write your first one above.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute) }
                            }
                        }
                        sectionItems(sections.filter { it.anchor == el.key })
                    }
                    sectionItems(sections.filter { it.anchor.isNotEmpty() && HomeElement.of(it.anchor) == null })
                }
                }
                if (dockSec == null && navStyle != ADD_BUTTON_NONE) Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(120.dp).background(Brush.verticalGradient(listOf(Color.Transparent, pageBg))))
                val addScrap = { newScrap() }
                // The add button can be held for a menu, so it is given the same gesture state as the list. With the pill tabs docked, the Pill add button is the round one beside them.
                CompositionLocalProvider(LocalHomeGestures provides gestureEnv) {
                    if (dockSec == null || navStyle != 0) AddNav(navStyle, vm, nav, "Inbox", { menuSheet = true }, addScrap)
                    if (dockSec != null) {
                        val dockTabs = dockSec.card?.tabs.orEmpty()
                        TabsDock(dockTabs.map { it.label }, SectionTabs.selected(dockTabs, tabPicks[dockSec.id] ?: 0), { i -> tabPicks[dockSec.id] = i },
                            startRoom = if (menuFloat) 76.dp else 0.dp, endRoom = if (navStyle == 1 || navStyle == 3 || navStyle == 4) 78.dp else 0.dp, lift = if (navStyle == ADD_BUTTON_WRITING_BAR) 58.dp else 0.dp,
                            addButton = navStyle == 0, onAdd = addScrap)
                    }
                }
                // With the header hidden, a menu button of its own can float at the bottom left (the Bottom bar and the Writing bar have theirs).
                if (menuFloat) FloatingMenuButton(Modifier.align(Alignment.BottomStart)) { menuSheet = true }
                AnimatedVisibility(hintSeen == false && hintReady && all.isNotEmpty() && drag.active == null, Modifier.align(Alignment.BottomCenter),
                    enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 2 }, exit = fadeOut(tween(150))) {
                    GestureHint(Modifier.padding(start = 16.dp, end = 16.dp, bottom = if (navStyle == 2) 170.dp else 112.dp), { vm.seeGestureHint() }, { vm.seeGestureHint(); guideSheet = true })
                }
                PullIndicator(pullSearch)
                DragOverlay(drag)
                }
            }
        }
        if (menuSheet) MenuSheet(nav, { menuSheet = false }, { vm.switcherOpen.value = true }, onCustomize = { draft = layout; stylesDraft = styles; editing = true }, summary = menuSummary(all.size, shelves.size)) { vm.pendingShelf = null }
        deletingScrap?.let { n -> DeleteScrapSheet(n, vm) { deletingScrap = null } }
        editBoxKey?.let { k -> shelves.firstOrNull { it.name == k }?.let { sh -> ShelfSheet(vm, sh, { editBoxKey = null }) } }
        newBoxIn?.let { parent -> ShelfSheet(vm, null, { newBoxIn = null }, parent = parent) }
        deleteBoxKey?.let { k -> DeleteBoxSheet(k, vm, { deleteBoxKey = null }) }
        if (inboxSheet) InboxSheet(vm) { inboxSheet = false }
        moveScrap?.let { n -> MoveSheet(n, vm) { moveScrap = null } }
        tagScrap?.let { n -> TagSheet(n, vm) { tagScrap = null } }
        sectionEdit?.let { id -> sections.firstOrNull { it.id == id }?.let { sec -> SectionSheet(sec, env) { sectionEdit = null } } }
        if (addSectionSheet) AddSectionSheet({ c -> addSectionSheet = false; ops.add(c) }, { addSectionSheet = false; ops.addTimeline() }, { addSectionSheet = false; ops.addAgenda() }) { addSectionSheet = false }
        calendarDay?.let { pick -> CalendarDaySheet(pick, all, shelves, nav) { calendarDay = null } }
        toSection?.let { r -> AddToSectionSheet(r, sections, ops) { toSection = null } }
        if (guideSheet) GestureGuideSheet { guideSheet = false }
        buttonPick?.let { p -> PickerSheet(p) { buttonPick = null } }
        if (!welcomed) Welcome({ vm.dismissWelcome() }, { vm.addExamples() })
    }
    }
}
