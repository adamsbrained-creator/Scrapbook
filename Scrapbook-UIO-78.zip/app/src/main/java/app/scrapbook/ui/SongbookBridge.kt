package app.scrapbook.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.scrapbook.*

// SCRAPBOOK <-> SONGBOOK, the Android side. The rules and the message formats are in Songbook.kt. Everything here sends one intent to Songbook and says
// so plainly when Songbook is not installed. The rest of the app touches this from marked hook lines ("[songbook hook N]"):
//
//   1. MainActivity.kt: handleSongbook (Songbook asks for a song to be opened as a scrap, or says which song a sent scrap became)
//   2. ArchiveViewModel.kt: editFromSongbook, songLinked, songbookTouched
//   3. Editor.kt ("Share & copy" menu page) and Pages.kt (reading view menu):  SongbookMenuRows(uid, title, body) { menu = false }
//   4. Pages.kt / Markup.kt / OpenLink.kt: songbook:// is a link scheme, like binder:// and scrapbook://
//   5. Editor.kt: takes the new text when Songbook changed the open scrap (so the next autosave cannot put the old text back)

private fun toSongbook(ctx: Context, fill: Intent.() -> Unit) {
    val i = Intent(ACTION_SONGBOOK_RECEIVE).setClassName(SONGBOOK_PACKAGE, SONGBOOK_RECEIVER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).apply(fill)
    try { ctx.startActivity(i) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Songbook isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/**
 * Sends this scrap to Songbook: [mode] is an idea, a new song, or an update of the song [songId] it is already tied to. Songbook does it without
 * coming to the front and answers with SONG_LINKED, which adds the link line to the scrap (see ArchiveViewModel.songLinked).
 */
fun sendToSongbook(ctx: Context, mode: String, uid: String, title: String, body: String, songId: Long) {
    val st = songTextOf(body)
    songbookRememberSent(ctx, uid, songSyncKey(st.text, st.tasks))
    toSongbook(ctx) {
        putExtra("mode", mode); putExtra("title", title.ifBlank { "Untitled" }); putExtra("body", st.text)
        putStringArrayListExtra("tasks", ArrayList(st.tasks.map { it.first })); putExtra("done", st.tasks.map { it.second }.toBooleanArray())
        putExtra("scrap", uid); putExtra("song", songId)
        if (st.capo > 0) putExtra("capo", st.capo)
    }
}

/** Opens a songbook:// link in Songbook. */
fun openInSongbook(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Songbook isn't installed on this phone", Toast.LENGTH_SHORT).show() }
}

/**
 * The Songbook rows of a scrap's menu. A scrap that is not tied to a song yet can be sent as an idea (its lines go on the writing desk) or as a song;
 * one that is can be sent back (the song's text is replaced, and Songbook keeps an Undo) or opened in Songbook. [uid] is null for a scrap that has not
 * been saved yet. When sending would move chords into the words (a chord sheet) or read a capo, the person first sees the result and can cancel.
 */
@Composable
fun SongbookMenuRows(uid: String?, title: String, body: String, close: () -> Unit) {
    val ctx = LocalContext.current
    val linked = remember(body) { firstSongbookSong(body) }
    val st = remember(body) { songTextOf(body) }
    val empty = st.text.isBlank() && st.tasks.isEmpty()
    var asking by remember { mutableStateOf<String?>(null) }   // the way of sending that waits for "Send" in the preview
    fun send(mode: String) {
        close()
        if (uid == null || empty) Toast.makeText(ctx, "Write something first, so there is a scrap to send", Toast.LENGTH_SHORT).show()
        else sendToSongbook(ctx, mode, uid, title, body, linked ?: -1L)
    }
    fun ask(mode: String) { if (uid != null && !empty && chordsWereMoved(body, st)) asking = mode else send(mode) }
    if (linked == null) {
        MenuRow("send", "Send to Songbook as an idea", "The lines go on the writing desk") { ask(SongbookMode.IDEA) }
        MenuRow("send", "Send to Songbook as a song", "Starts at the Lyrics stage") { ask(SongbookMode.SONG) }
    } else {
        MenuRow("undo", "Send back to Songbook", "Replaces the song's text. Songbook keeps an Undo") { ask(SongbookMode.UPDATE) }
        MenuRow("external", "Open in Songbook", "The song this scrap is about") { close(); openInSongbook(ctx, songbookSongLink(linked)) }
    }
    asking?.let { mode -> SongbookPreview(st, onSend = { asking = null; send(mode) }, onCancel = { asking = null }) }
}

/** What Songbook is about to get, for a scrap written with the chords above the words: the converted text and the capo, with Send and Cancel. */
@Composable
private fun SongbookPreview(st: SongText, onSend: () -> Unit, onCancel: () -> Unit) {
    val sans = LocalFonts.current.second
    val shape = RoundedCornerShape(24.dp)
    Dialog(onDismissRequest = onCancel) {
        Column(Modifier.fillMaxWidth().heightIn(max = 600.dp).clip(shape).background(Sb.raised).padding(20.dp), Arrangement.spacedBy(12.dp)) {
            Text("This is how Songbook will get it", color = Sb.ink, fontSize = 17.sp, fontWeight = FontWeight.Medium, fontFamily = sans)
            val capoNote = if (st.capo > 0) "Capo ${st.capo}: the chords are written as they sound, and Songbook will show the shapes. " else ""
            Text(capoNote + "Each chord is in front of the word it sits over. Anything off can be fixed in Songbook.", color = Sb.mute, fontSize = 12.5.sp, lineHeight = 16.sp, fontFamily = sans)
            Box(Modifier.weight(1f, fill = false).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Sb.card).verticalScroll(rememberScrollState()).padding(12.dp)) {
                Text(st.text, color = Sb.ink, fontSize = 13.sp, lineHeight = 19.sp, fontFamily = FontFamily.Monospace)
            }
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(Sb.card).tap("Cancel", onCancel).padding(vertical = 13.dp), Alignment.Center) {
                    Text("Cancel", color = Sb.ink, fontSize = 15.sp, fontFamily = sans, textAlign = TextAlign.Center)
                }
                Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(Sb.ink).tap("Send to Songbook", onSend).padding(vertical = 13.dp), Alignment.Center) {
                    Text("Send", color = Sb.raised, fontSize = 15.sp, fontWeight = FontWeight.Medium, fontFamily = sans, textAlign = TextAlign.Center)
                }
            }
        }
    }
}
