package app.scrapbook

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// The Calendar card of Home: a month of round days, each showing the scraps made on it. This file is only the dates (no Android), so they are tested on their own (CalendarMonthTest);
// ui/CalendarParts.kt draws them. A scrap belongs to the day it was MADE (Item.createdAt, which never moves), not the day it was last edited.

/** One round day of the grid. [start] is the first millisecond of the day, [day] the number printed, [inMonth] false for the few days of the next or last month that fill the first and last row. */
class CalendarCell(val start: Long, val day: Int, val inMonth: Boolean)

object CalendarMonth {
    /** The most dots a day shows under its number; more scraps than that show a plus sign instead of one more dot. */
    const val MAX_DOTS = 3

    /** The first millisecond of the first day of the month [ms] falls in. */
    fun monthStart(ms: Long, zone: TimeZone = TimeZone.getDefault()): Long {
        val c = Calendar.getInstance(zone)
        c.timeInMillis = ms
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** The start of the month [months] after (or before, when negative) the month that starts at [monthStart]. */
    fun addMonths(monthStart: Long, months: Int, zone: TimeZone = TimeZone.getDefault()): Long {
        val c = Calendar.getInstance(zone)
        c.timeInMillis = monthStart
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.add(Calendar.MONTH, months)
        return c.timeInMillis
    }

    /** The number of whole months from [from] to [to] (both starts of a month); negative when [to] is earlier. */
    fun monthsBetween(from: Long, to: Long, zone: TimeZone = TimeZone.getDefault()): Int {
        val a = Calendar.getInstance(zone).apply { timeInMillis = from }
        val b = Calendar.getInstance(zone).apply { timeInMillis = to }
        return (b.get(Calendar.YEAR) - a.get(Calendar.YEAR)) * 12 + (b.get(Calendar.MONTH) - a.get(Calendar.MONTH))
    }

    /** The first day of the week where [locale] is (Calendar.SUNDAY .. Calendar.SATURDAY). */
    fun firstDayOfWeek(zone: TimeZone = TimeZone.getDefault(), locale: Locale = Locale.getDefault()): Int = Calendar.getInstance(zone, locale).firstDayOfWeek

    /**
     * The days to draw for the month that starts at [monthStart]: whole weeks, from the first day of the week the month begins in to the last day of the week it ends in,
     * so 28 to 42 cells (4 to 6 rows). The days outside the month are there to fill the row and are marked as such.
     */
    fun cells(monthStart: Long, zone: TimeZone = TimeZone.getDefault(), locale: Locale = Locale.getDefault()): List<CalendarCell> {
        val first = Calendar.getInstance(zone, locale).apply { timeInMillis = monthStart }
        val month = first.get(Calendar.MONTH)
        val daysIn = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        val weekStart = first.firstDayOfWeek
        val lead = Math.floorMod(first.get(Calendar.DAY_OF_WEEK) - weekStart, 7)
        val rows = (lead + daysIn + 6) / 7
        val c = Calendar.getInstance(zone, locale).apply { timeInMillis = monthStart; add(Calendar.DAY_OF_MONTH, -lead) }
        val out = ArrayList<CalendarCell>(rows * 7)
        repeat(rows * 7) {
            out.add(CalendarCell(c.timeInMillis, c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) == month))
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
        return out
    }

    /** The seven short weekday names in the order the grid has them, in capitals ("SUN", "MON", ...). */
    fun weekdayLabels(zone: TimeZone = TimeZone.getDefault(), locale: Locale = Locale.getDefault()): List<String> {
        val f = SimpleDateFormat("EEE", locale).apply { timeZone = zone }
        val c = Calendar.getInstance(zone, locale)
        c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
        return List(7) { i ->
            val label = f.format(Date(c.timeInMillis)).uppercase(locale)
            if (i < 6) c.add(Calendar.DAY_OF_MONTH, 1)
            label
        }
    }

    /** The name of the month: "June", or "June 2026" when [withYear] (the calendar shows the year whenever it is not showing this year). */
    fun title(monthStart: Long, withYear: Boolean, zone: TimeZone = TimeZone.getDefault(), locale: Locale = Locale.getDefault()): String {
        val f = SimpleDateFormat(if (withYear) "LLLL yyyy" else "LLLL", locale).apply { timeZone = zone }
        return f.format(Date(monthStart)).replaceFirstChar { it.titlecase(locale) }
    }

    /** Whether [monthStart] is in the same year as [now]. */
    fun sameYear(monthStart: Long, now: Long, zone: TimeZone = TimeZone.getDefault()): Boolean {
        val a = Calendar.getInstance(zone).apply { timeInMillis = monthStart }
        val b = Calendar.getInstance(zone).apply { timeInMillis = now }
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
    }

    /** The scraps of each day: day start to the scraps made that day, newest made first. Scraps in the Bin are never given here. */
    fun byDay(items: List<Item>, zone: TimeZone = TimeZone.getDefault()): Map<Long, List<Item>> =
        items.filter { it.deletedAt == 0L }.sortedByDescending { it.createdAt }.groupBy { Agenda.dayStart(it.createdAt, zone) }

    /** How many dots a day with [count] scraps shows, and whether it also shows a plus sign for the rest. */
    fun dots(count: Int): Int = count.coerceIn(0, MAX_DOTS)
    fun hasMore(count: Int): Boolean = count > MAX_DOTS

    /** The heading of the list a tapped day opens: "Fri, 12 June". */
    fun dayTitle(dayStart: Long, zone: TimeZone = TimeZone.getDefault(), locale: Locale = Locale.getDefault()): String {
        val f = SimpleDateFormat("EEE, d MMMM", locale).apply { timeZone = zone }
        return f.format(Date(dayStart))
    }
}
