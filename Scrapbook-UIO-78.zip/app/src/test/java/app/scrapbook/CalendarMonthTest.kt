package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Locale
import java.util.TimeZone

/** The Calendar card of Home (the Calendar skin): the days of a month, the scraps of each day, and the skin itself. */
class CalendarMonthTest {
    private val utc: TimeZone = TimeZone.getTimeZone("UTC")
    private val us = Locale.US
    private val uk = Locale.UK
    private fun at(y: Int, mo: Int, d: Int, h: Int = 12, mi: Int = 0): Long = LocalDateTime.of(y, mo, d, h, mi).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()
    private fun made(title: String, createdAt: Long, saved: Long = createdAt, box: String = "Inbox", deleted: Long = 0L) =
        Item(title = title, body = "", kind = Kind.Note, collection = box, savedAt = saved, createdAt = createdAt, deletedAt = deleted)

    // ----- The grid -----

    @Test fun juneOf2026FillsFiveRowsFromSundayLikeTheMockup() {
        val cells = CalendarMonth.cells(CalendarMonth.monthStart(at(2026, 6, 12), utc), utc, us)
        assertEquals(35, cells.size)
        // 31 May to 4 July: the mockup's first row is "31 1 2 3 4 5 6" and its last row "28 29 30 1 2 3 4".
        assertEquals(listOf(31, 1, 2, 3, 4, 5, 6), cells.take(7).map { it.day })
        assertEquals(listOf(28, 29, 30, 1, 2, 3, 4), cells.takeLast(7).map { it.day })
        assertFalse(cells.first().inMonth)
        assertEquals(30, cells.count { it.inMonth })
        assertEquals(at(2026, 5, 31, 0), cells.first().start)
        assertEquals(at(2026, 7, 4, 0), cells.last().start)
    }

    @Test fun theWeekStartsWhereTheLocaleSaysSo() {
        val cells = CalendarMonth.cells(CalendarMonth.monthStart(at(2026, 6, 12), utc), utc, uk)
        // 1 June 2026 is a Monday, so a Monday-first week starts right on it, and the month fills five rows.
        assertEquals(1, cells.first().day)
        assertTrue(cells.first().inMonth)
        assertEquals(35, cells.size)
        assertEquals(listOf("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"), CalendarMonth.weekdayLabels(utc, uk))
        assertEquals(listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"), CalendarMonth.weekdayLabels(utc, us))
    }

    @Test fun everyMonthIsWholeWeeksAndHoldsEveryDayOnce() {
        for (locale in listOf(us, uk)) for (y in 2024..2026) for (m in 1..12) {
            val start = CalendarMonth.monthStart(at(y, m, 15), utc)
            val cells = CalendarMonth.cells(start, utc, locale)
            assertEquals("$y-$m", 0, cells.size % 7)
            assertTrue("$y-$m", cells.size in 28..42)
            val inside = cells.filter { it.inMonth }
            assertEquals("$y-$m", (1..inside.size).toList(), inside.map { it.day })
            assertEquals("$y-$m", at(y, m, 1, 0), inside.first().start)
            // The days run one after the other, a day apart.
            cells.zipWithNext().forEach { (a, b) -> assertEquals(86_400_000L, b.start - a.start) }
        }
    }

    @Test fun februaryOfALeapYearHasTwentyNineDaysAndAnExactFebruaryCanBeFourRows() {
        assertEquals(29, CalendarMonth.cells(CalendarMonth.monthStart(at(2028, 2, 10), utc), utc, us).count { it.inMonth })
        // 1 Feb 2026 is a Sunday and the month has 28 days: exactly four rows with a Sunday-first week.
        assertEquals(28, CalendarMonth.cells(CalendarMonth.monthStart(at(2026, 2, 10), utc), utc, us).size)
    }

    // ----- Months -----

    @Test fun aMonthStartsAtMidnightOnTheFirst() {
        assertEquals(at(2026, 6, 1, 0), CalendarMonth.monthStart(at(2026, 6, 30, 23, 59), utc))
        assertEquals(at(2026, 6, 1, 0), CalendarMonth.monthStart(at(2026, 6, 1, 0), utc))
    }

    @Test fun monthsStepAcrossTheYear() {
        val jan = CalendarMonth.monthStart(at(2026, 1, 20), utc)
        assertEquals(at(2025, 12, 1, 0), CalendarMonth.addMonths(jan, -1, utc))
        assertEquals(at(2026, 2, 1, 0), CalendarMonth.addMonths(jan, 1, utc))
        assertEquals(at(2027, 1, 1, 0), CalendarMonth.addMonths(jan, 12, utc))
        assertEquals(-1, CalendarMonth.monthsBetween(jan, CalendarMonth.addMonths(jan, -1, utc), utc))
        assertEquals(14, CalendarMonth.monthsBetween(jan, CalendarMonth.addMonths(jan, 14, utc), utc))
    }

    @Test fun theTitleIsTheMonthAndOnlyShowsTheYearWhenItIsNotThisOne() {
        val june = CalendarMonth.monthStart(at(2026, 6, 12), utc)
        assertEquals("June", CalendarMonth.title(june, false, utc, us))
        assertEquals("June 2026", CalendarMonth.title(june, true, utc, us))
        assertTrue(CalendarMonth.sameYear(june, at(2026, 11, 8), utc))
        assertFalse(CalendarMonth.sameYear(june, at(2027, 1, 2), utc))
    }

    @Test fun aTappedDayIsNamedLikeThis() {
        assertEquals("Fri, 12 June", CalendarMonth.dayTitle(at(2026, 6, 12, 0), utc, us))
    }

    // ----- The scraps of each day -----

    @Test fun aScrapBelongsToTheDayItWasMadeNotTheDayItWasEdited() {
        val a = made("a", createdAt = at(2026, 6, 12, 9), saved = at(2026, 6, 20, 9))
        val days = CalendarMonth.byDay(listOf(a), utc)
        assertEquals(listOf(a), days[at(2026, 6, 12, 0)])
        assertNull(days[at(2026, 6, 20, 0)])
    }

    @Test fun aDayListsItsScrapsNewestMadeFirstAndLeavesOutTheBin() {
        val early = made("early", at(2026, 6, 12, 8))
        val late = made("late", at(2026, 6, 12, 22, 30))
        val other = made("other", at(2026, 6, 13, 1))
        val binned = made("binned", at(2026, 6, 12, 10), deleted = at(2026, 6, 14))
        val days = CalendarMonth.byDay(listOf(early, other, late, binned), utc)
        assertEquals(listOf("late", "early"), days.getValue(at(2026, 6, 12, 0)).map { it.title })
        assertEquals(listOf("other"), days.getValue(at(2026, 6, 13, 0)).map { it.title })
        assertEquals(2, days.size)
    }

    @Test fun lateNightAndEarlyMorningAreDifferentDays() {
        val days = CalendarMonth.byDay(listOf(made("a", at(2026, 6, 12, 23, 59)), made("b", at(2026, 6, 13, 0, 0))), utc)
        assertEquals(setOf(at(2026, 6, 12, 0), at(2026, 6, 13, 0)), days.keys)
    }

    @Test fun aDayShowsAtMostThreeDotsAndAPlusForTheRest() {
        assertEquals(0, CalendarMonth.dots(0))
        assertEquals(2, CalendarMonth.dots(2))
        assertEquals(3, CalendarMonth.dots(3))
        assertEquals(3, CalendarMonth.dots(40))
        assertFalse(CalendarMonth.hasMore(3))
        assertTrue(CalendarMonth.hasMore(4))
    }

    // ----- The card and the skin -----

    @Test fun theCalendarCardIsOneOfTheKindsAndSurvivesBeingSaved() {
        assertTrue(SectionCard.CALENDAR in SectionCard.KINDS)
        assertEquals("Calendar", SectionCard.label(SectionCard.CALENDAR))
        assertEquals("Calendar", SectionCard.defaultTitle(SectionCard.CALENDAR))
        val s = HomeSection("c", "Calendar", SectionLayout.Cards, "header", card = SectionCard(SectionCard.CALENDAR), showTitle = false)
        val back = HomeSections.decode(HomeSections.encode(listOf(s))).single()
        assertEquals(SectionCard.CALENDAR, back.card?.kind)
        assertFalse(back.showTitle)
        assertFalse(back.fillsItself)   // it holds nothing of its own and has no rule; it only reads the scraps on its own
    }

    @Test fun theCalendarSkinIsAHeaderAndOneCalendarSectionWithNoNameLine() {
        val r = ReadySkins.calendar
        assertEquals(r, ReadySkins.of("calendar"))
        assertEquals("Calendar", r.name)
        val section = HomeSections.decode(r.values[SkinKeys.SECTIONS]).single()
        assertEquals(SectionCard.CALENDAR, section.card?.kind)
        assertFalse(section.showTitle)
        assertEquals(HomeElement.Header.key, section.anchor)
        val layout = HomeSkin("c", "Calendar", r.values).layout
        assertEquals(HomeElement.entries.toSet() - HomeElement.Header, layout.hidden)
    }
}
