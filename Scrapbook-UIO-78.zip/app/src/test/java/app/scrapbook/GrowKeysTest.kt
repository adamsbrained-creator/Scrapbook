package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GrowKeysTest {
    @Test fun theSmallPillKeepsTheFewEverydayTools() = assertEquals(listOf("H", "CK"), growKeys(PillMode.Tools, false))
    @Test fun theStretchedBarOffersListsAndQuoteOnAPlainLine() = assertEquals(listOf("H", "CK", "BL", "NM", "QT"), growKeys(PillMode.Tools, true))
    @Test fun aNarrowScreenKeepsTheFirstToolsOnly() = assertEquals(listOf("B", "I", "S"), growKeys(PillMode.Selection, true, 3))
    @Test fun selectedWordsGetStrikethroughOnTheStretchedBar() { assertTrue("S" in growKeys(PillMode.Selection, true)); assertTrue("S" !in growKeys(PillMode.Selection, false)) }
    @Test fun aChecklistLineGetsListsToo() = assertEquals(listOf("OU", "IN", "CK", "BL", "NM"), growKeys(PillMode.Task, true))
    @Test fun aLinkKeepsOpenEditRemove() { assertEquals(growKeys(PillMode.Link, false), growKeys(PillMode.Link, true)) }
    @Test fun anEmptyLineIsTheSameAsAPlainLineWhenStretched() = assertEquals(growKeys(PillMode.Tools, true), growKeys(PillMode.Empty, true))
    @Test fun anEmptyLineOffersStartersOnTheSmallPill() = assertEquals(listOf("H", "CK", "BL", "QT"), growKeys(PillMode.Empty, false))
    @Test fun theMinimizedBarShowsTheUsualToolsWhenItOpens() = assertEquals(growKeys(PillMode.Tools, true), growKeys(PillMode.Tucked, true))
}
