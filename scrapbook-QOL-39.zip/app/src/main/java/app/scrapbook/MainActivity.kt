package app.scrapbook

import android.content.Intent
import android.widget.Toast
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.scrapbook.ui.*
import java.io.File
import kotlinx.coroutines.flow.first

class MainActivity : ComponentActivity() {
    private val vm: ArchiveViewModel by viewModels()
    private val crashFile get() = File(filesDir, "crash.txt")
    /** True when the app is starting from scratch. Not after a rotation or when Android restores the app, because the navigation state comes back by itself then. */
    private var freshLaunch = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        freshLaunch = savedInstanceState == null
        enableEdgeToEdge()
        if (savedInstanceState == null) { handleShare(intent); handleLink(intent) }
        setContent {
            var crash by remember { mutableStateOf(crashFile.takeIf { it.exists() }?.readText()) }
            val report = crash
            if (report != null) CrashScreen(report, onShare = { shareReport(report) }, onDismiss = { crashFile.delete(); crash = null })
            else AppRoot()
        }
    }

    private fun shareReport(report: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Scrapbook crash report"); putExtra(Intent.EXTRA_TEXT, report)
        }, "Share crash report"))
    }

    @Composable
    private fun AppRoot() {
        val theme by vm.theme.collectAsState()
        val incoming by vm.incoming.collectAsState()
        val darkMode by vm.darkMode.collectAsState()
        val greyBg by vm.greyBg.collectAsState()
        val showPreview by vm.showPreview.collectAsState()
        val marksAccent by vm.marksAccent.collectAsState(); val linksAccent by vm.linksAccent.collectAsState()
        val hashtagsAccent by vm.hashtagsAccent.collectAsState(); val hashtagsOn by vm.hashtagTags.collectAsState()
        val textColors = remember(marksAccent, linksAccent, hashtagsAccent, hashtagsOn) { TextColors(marksAccent, linksAccent, hashtagsAccent, hashtagsOn) }
        val boxStyle by vm.boxStyle.collectAsState()
        val allShelves by vm.shelves.collectAsState()
        val hapticsOn by vm.haptics.collectAsState()
        val view = LocalView.current
        val haptics = remember(view, hapticsOn) { Haptics(view, hapticsOn) }
        ScrapbookTheme(theme, darkMode, greyBg) {
            val nav = rememberNavController()
            val visits = remember { HashMap<String, EnterState>() }
            val dark = Sb.dark
            LaunchedEffect(dark) {
                val bars = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT) else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
            }
            // Optional (Settings, off by default): a fresh launch can reopen the box you were in, on top of the Home page. Until that is decided (a few
            // milliseconds to read the saved settings) a blank page is shown instead of flashing the main page first.
            var ready by remember { mutableStateOf(!freshLaunch) }
            var reopen by remember { mutableStateOf(emptyList<String>()) }
            LaunchedEffect(Unit) {
                if (!ready) {
                    // Sharing something into the app always goes to the capture screen instead.
                    if (incoming == null && vm.linkRequest.value == null && vm.readReopenLastBox()) reopen = vm.boxPath(vm.readLastBox())
                    ready = true
                }
            }
            LaunchedEffect(ready) {
                if (!ready) return@LaunchedEffect
                // Open each box on the way (box, then the box inside it), so Back climbs up the same way it would have.
                // The NavHost sets up its graph while it is first composed, which can happen after this effect has started. Navigating before that
                // throws "Navigation graph has not been set", so wait until the first screen (Home) exists.
                if (reopen.isNotEmpty()) { nav.currentBackStackEntryFlow.first(); reopen.forEach { nav.navigate("shelf/$it") } }
                // From here on, remember the box on screen. The main page, All scraps, Pinned and Recent are not boxes: they clear it.
                nav.currentBackStackEntryFlow.collect { e ->
                    when (e.destination.route) {
                        "home", "scraps" -> vm.setLastBox("")
                        "shelf/{name}" -> vm.setLastBox(e.arguments?.getString("name")?.takeUnless { it == "All" || it == "Pinned" || it == "Recent" } ?: "")
                    }
                }
            }
            LaunchedEffect(incoming != null, ready) {
                if (ready && incoming != null) {
                    // Sharing into a closed app starts it and sets `incoming` at once, so this can run before the NavHost has set its graph
                    // (that crashed with "Cannot navigate to capture. Navigation graph has not been set"). Wait for the first screen, then open capture.
                    nav.currentBackStackEntryFlow.first()
                    nav.navigate("capture") { launchSingleTop = true }
                }
            }
            // A scrapbook://scrap/<id> link: open that scrap on top of whatever is open, so Back returns to where you were.
            val linkReq by vm.linkRequest.collectAsState()
            LaunchedEffect(linkReq, ready) {
                val uid = linkReq ?: return@LaunchedEffect
                if (!ready) return@LaunchedEffect
                nav.currentBackStackEntryFlow.first()   // the NavHost may not have set its graph yet (see the share handling above)
                vm.linkRequest.value = null
                val item = vm.findByUid(uid)
                when {
                    item == null -> Toast.makeText(this@MainActivity, "That scrap no longer exists", Toast.LENGTH_SHORT).show()
                    item.deletedAt != 0L -> Toast.makeText(this@MainActivity, "That scrap is in the Bin", Toast.LENGTH_SHORT).show()
                    else -> nav.navigate("item/${item.id}")
                }
            }
            Box(Modifier.fillMaxSize().background(LocalSb.current.paper), contentAlignment = Alignment.TopCenter) {
                Box(Modifier.widthIn(max = 640.dp).fillMaxSize()) {
                    if (ready) CompositionLocalProvider(LocalShowPreview provides showPreview, LocalTextColors provides textColors, LocalBoxStyle provides boxStyle, LocalShelves provides allShelves, LocalHaptics provides haptics) {
                        // Screens fade and slide in a short way; going Back fades the old one out the other way. Quick enough not to slow you down.
                        NavHost(nav, "home",
                            enterTransition = { fadeIn(tween(220, delayMillis = 40)) + slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { it / 14 } },
                            exitTransition = { fadeOut(tween(140)) },
                            popEnterTransition = { fadeIn(tween(220, delayMillis = 40)) },
                            popExitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 14 } }) {
                            composable("home") { Visit(visits, it) { HomeScreen(vm, nav) } }
                            composable("scraps") { Visit(visits, it) { AllScrapsScreen(vm, nav) } }
                            composable("settings") { Visit(visits, it) { SettingsScreen(vm, nav) } }
                            composable("about") { Visit(visits, it) { AboutScreen(nav) } }
                            composable("whatsnew") { Visit(visits, it) { WhatsNewScreen(nav) } }
                            composable("licenses") { Visit(visits, it) { LicensesScreen(nav) } }
                            composable("capture") { Visit(visits, it) { CaptureScreen(vm, nav) } }
                            composable("sort") { Visit(visits, it) { SortInboxScreen(vm, nav) } }
                            composable("bin") { Visit(visits, it) { BinScreen(vm, nav) } }
                            composable("collections") { Visit(visits, it) { CollectionsScreen(vm, nav) } }
                            composable("shelf/{name}", listOf(navArgument("name") { type = NavType.StringType })) {
                                Visit(visits, it) { ShelfScreen(vm, nav, it.arguments!!.getString("name")!!) }
                            }
                            composable("search") { Visit(visits, it) { SearchScreen(vm, nav) } }
                            composable("rediscover") { Visit(visits, it) { RediscoverScreen(vm, nav) } }
                            composable("item/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                                Visit(visits, it) { ItemScreen(vm, nav, it.arguments!!.getLong("id")) }
                            }
                            composable("edit/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                                Visit(visits, it) { EditorScreen(vm, nav, it.arguments!!.getLong("id")) }
                            }
                            composable("layouts/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                                Visit(visits, it) { LayoutScreen(vm, nav, it.arguments!!.getLong("id")) }
                            }
                        }
                    }
                }
            }
        }
    }

    /** Leaving the app is the safe moment to swap the launcher icon for the one that matches the accent color. */
    override fun onStop() {
        super.onStop()
        vm.syncIcon()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
        handleLink(intent)
    }

    /** A scrapbook://scrap/<id> link (from another app, a note or the browser) asks to open that scrap. */
    private fun handleLink(i: Intent?) {
        if (i?.action != Intent.ACTION_VIEW) return
        vm.linkRequest.value = parseScrapLink(i.dataString) ?: return
    }

    /** Text, links and images shared from other apps open the capture screen. */
    private fun handleShare(i: Intent?) {
        if (i == null || (i.action != Intent.ACTION_SEND && i.action != Intent.ACTION_SEND_MULTIPLE)) return
        val text = i.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString().orEmpty()
        val subject = i.getStringExtra(Intent.EXTRA_SUBJECT).orEmpty()
        val uris: List<Uri> = if (i.action == Intent.ACTION_SEND_MULTIPLE)
            IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
        else listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
        // Pictures become photos; anything else (a PDF, a zip...) is attached to the new scrap as a file.
        val (pictures, others) = uris.partition { u -> (contentResolver.getType(u) ?: i.type)?.startsWith("image/") == true }
        if (text.isNotBlank() || uris.isNotEmpty()) vm.incoming.value = Incoming(text, subject, pictures, others)
    }
}
