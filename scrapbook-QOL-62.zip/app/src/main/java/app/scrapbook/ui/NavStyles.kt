package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.delay

// The ways to add a scrap and reach the menu from the main pages (Settings > Add button). 0 Pill and 1 Bottom bar live in Home.kt; the newer ones are here:
// 2 Writing bar (a small composer at the bottom: type, pick a box, send), 3 One button with an arc, 4 Swipe-up sheet.

/** How far the list needs to stay clear of the bottom so its last scrap is not hidden under the add control. */
fun navClearance(style: Int, normal: Dp): Dp = if (style == 2) 200.dp else normal

/**
 * Draws the add control the Settings choice asks for, inside the screen's Box. [box] is where a scrap written here is filed (the box on screen, Inbox on the
 * main pages); [onMenu] opens the menu sheet and [onAdd] opens an empty editor in that box.
 */
@Composable
fun BoxScope.AddNav(style: Int, vm: ArchiveViewModel, nav: NavController, box: String, onMenu: () -> Unit, onAdd: () -> Unit) {
    when (style) {
        1 -> BottomNav(Modifier.matchParentSize(), onMenu, onAdd)
        2 -> WriteBar(vm, nav, box)
        else -> NewScrapPill(Modifier.align(Alignment.BottomEnd), onAdd)
    }
}

/** A round button of the writing bar. */
@Composable
private fun BarBtn(icon: String, desc: String, dark: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.pressScale(.9f).size(44.dp).clip(CircleShape).background(if (dark) Sb.ink else Sb.card).tap(desc, onClick), Alignment.Center) {
        Ic(icon, 22.dp, if (dark) Sb.paper else Sb.ink)
    }
}

/** Where a scrap from the writing bar goes: Inbox, or any box. */
@Composable
private fun BoxPickSheet(current: String, vm: ArchiveViewModel, onPick: (String) -> Unit, onDone: () -> Unit) = Sheet("Save to", onDone, doneLabel = "Cancel", soft = true) {
    val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    SheetGroup {
        OptionRow("Inbox", current == "Inbox", dot = if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) { onPick("Inbox"); onDone() }
        BoxTreeRows(shelves, current) { s -> onPick(s.name); onDone() }
    }
    if (shelves.isEmpty()) SheetNote("No boxes yet. Create one from the Boxes screen.")
}

/**
 * The writing bar: a small card at the bottom of the page with a line to type in, a + for photo, checklist, link and voice, the box the scrap will be filed in
 * and a send button. Sending saves the scrap at once (title from its first line, #words as tags) and leaves you where you are; "Open" in the confirmation, or
 * the expand button, opens it in the editor. With nothing typed the dark button opens an empty editor. What you have typed is kept while you look around.
 */
@Composable
fun BoxScope.WriteBar(vm: ArchiveViewModel, nav: NavController, startBox: String) {
    val t = LocalSb.current; val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState()
    val focus = LocalFocusManager.current; val haptics = LocalHaptics.current; val clipboard = LocalClipboardManager.current
    var text by rememberSaveable { mutableStateOf("") }
    var chosen by rememberSaveable(startBox) { mutableStateOf(startBox) }
    val box = if (chosen == "Inbox" || shelves.any { it.name == chosen }) chosen else "Inbox"
    var focused by remember { mutableStateOf(false) }
    var plus by remember { mutableStateOf(false) }; var picking by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf<Pair<Long, String>?>(null) }
    LaunchedEffect(saved) { if (saved != null) { delay(5000); saved = null } }
    BackHandler(focused) { focus.clearFocus() }
    val boxName = if (box == "Inbox") "Inbox" else shelves.displayName(box)
    val boxDot = if (box == "Inbox") (if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) else shelves.firstOrNull { it.name == box }?.let { TAB_COLORS[it.color % TAB_COLORS.size] } ?: TAB_GRAY

    /** Hands what is typed (and the chosen box) to a new editor. [image], [record] and [body] are the editor's usual quick starts. */
    fun toEditor(image: Boolean = false, record: Boolean = false, body: String? = null) {
        vm.pendingShelf = box; vm.pendingBody = body ?: text.ifBlank { null }; vm.pendingImage = image; vm.pendingRecord = record
        text = ""; focus.clearFocus(); nav.navigate("edit/0")
    }
    fun send() {
        val s = text.trim(); if (s.isEmpty()) return
        haptics.confirm(); val to = box
        vm.addQuick(s, to) { id -> saved = id to to }
        text = ""; focus.clearFocus()
    }

    // While you are typing the page behind goes quiet, and a tap on it puts the keyboard away.
    AnimatedVisibility(focused, Modifier.matchParentSize(), enter = fadeIn(tween(160)), exit = fadeOut(tween(120))) {
        Box(Modifier.fillMaxSize().background(t.paper.copy(alpha = .78f)).pointerInput(Unit) { detectTapGestures { focus.clearFocus() } })
    }
    val shape = RoundedCornerShape(28.dp)
    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().consumeWindowInsets(WindowInsets.navigationBars).imePadding().padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
        .shadow(10.dp, shape).clip(shape).background(Sb.raised).border(1.dp, Sb.line, shape).padding(start = 20.dp, end = 10.dp, top = 14.dp, bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().padding(end = 6.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.weight(1f).padding(top = 3.dp)) {
                BasicTextField(text, { text = it }, Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
                    textStyle = TextStyle(fontSize = 18.sp, lineHeight = 26.sp, fontFamily = headFont(), color = Sb.ink), cursorBrush = SolidColor(t.acc), maxLines = 6,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    decorationBox = { inner ->
                        Box {
                            if (text.isEmpty()) {
                                val s = saved
                                if (s != null) Row(Modifier.tap("Open the new scrap") { nav.navigate("edit/${s.first}") }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Ic("check", 18.dp, t.acc)
                                    Text("Saved to ${if (s.second == "Inbox") "Inbox" else shelves.displayName(s.second)}", fontSize = 16.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                    Text("Open", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = t.acc)
                                } else Text("Write something…", fontSize = 18.sp, lineHeight = 26.sp, fontFamily = headFont(), color = Sb.mute)
                            }
                            inner()
                        }
                    })
            }
            if (text.isNotBlank()) Box(Modifier.size(34.dp).clip(CircleShape).tap("Open in the editor") { toEditor() }, Alignment.Center) { Ic("expand", 18.dp, Sb.mute) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                BarBtn("plus", "More ways to write") { plus = true }
                PopupMenu(plus, { plus = false }) {
                    PopupItem("Photo", "image") { plus = false; toEditor(image = true) }
                    PopupItem("Checklist", "check") { plus = false; toEditor(body = if (text.isBlank()) "- [ ] " else text.trimEnd() + "\n- [ ] ") }
                    PopupItem("Link", "link") {
                        plus = false
                        val c = clipboard.getText()?.text?.trim().orEmpty()
                        toEditor(body = if (Regex("^https?://\\S+$").matches(c)) c else "https://")
                    }
                }
            }
            Row(Modifier.pressScale(.96f).height(44.dp).clip(CircleShape).background(Sb.card).tap("Saves to $boxName. Choose a box") { focus.clearFocus(); picking = true }.padding(start = 14.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(boxDot))
                Text(boxName, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
                Ic("chevdown", 16.dp, Sb.mute)
            }
            Spacer(Modifier.weight(1f))
            BarBtn("mic", "Record a voice memo") { toEditor(record = true) }
            if (text.isBlank()) BarBtn("edit", "Open an empty scrap", dark = true) { toEditor() } else BarBtn("send", "Save the scrap", dark = true) { send() }
        }
    }
    if (picking) BoxPickSheet(box, vm, { chosen = it }) { picking = false }
}
