package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * A photo shown as a normal picture: no frame, no tape, no tilt, the whole photo at its own proportions (not cropped) with rounded corners. The other
 * way to show photos is the polaroid. [width] is how wide it is; while writing ([removable]) the cross takes it off the page.
 */
@Composable
fun PlainPhoto(uri: String, width: Dp, removable: Boolean, onOpen: () -> Unit, onRemove: () -> Unit) {
    Box(Modifier.padding(end = 10.dp, top = 6.dp, bottom = 10.dp).width(width)) {
        AsyncImage(uri, null, Modifier.fillMaxWidth().heightIn(min = 140.dp, max = 380.dp).clip(RoundedCornerShape(LocalSb.current.radius)).tap("Open photo", onOpen),
            contentScale = ContentScale.Fit)
        // The cross only shows while writing; reading the page never takes a photo off by accident.
        if (removable) Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(30.dp).clip(CircleShape).background(Color(0x99000000)).tap("Remove image", onRemove), Alignment.Center) {
            Ic("close", 16.dp, Color.White)
        }
    }
}
