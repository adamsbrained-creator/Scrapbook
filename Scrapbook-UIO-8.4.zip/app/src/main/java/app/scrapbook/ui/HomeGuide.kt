package app.scrapbook.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import app.scrapbook.*

// The gestures of Home are invisible, so Home tells about them (UIO 11): a small card the first time ("Got it" puts it away for good) and a guide that lists every gesture,
// opened from that card and from Customize home > Gestures. The guide is only text: change a gesture and its line here, in the same change.

/** One gesture in the guide: an icon, its name and how to do it. */
private class GuideLine(val icon: String, val title: String, val how: String)

private val GUIDE = listOf(
    GuideLine("grip", "Hold", "Hold a scrap, a box, a part's title or the greeting. Let go and a menu opens next to it."),
    GuideLine("layout", "Hold and move", "Keep holding and move to carry a box or a scrap. Drop a scrap on a box to file it, on one of your sections to add it, or on an empty spot to start a new section."),
    GuideLine("list", "Change the order", "Drop a thing of a section on another thing of the same section: it takes that place."),
    GuideLine("sliders", "Hold an empty spot", "Customize home opens."),
    GuideLine("star", "Swipe a scrap", "On a recent scrap, right pins it and left deletes it (you can undo). In the list design of Pinned, swipe to unpin."),
    GuideLine("edit", "Quick capture", "Swipe the card up for a checklist. Hold it for a voice note."),
    GuideLine("plus", "The add button", "Hold the New scrap button for a scrap, a checklist, a photo, a link or a voice note."),
    GuideLine("person", "The greeting", "Double tap it to jump to the scrap you edited last, or to Inbox (Customize home > Gestures)."),
    GuideLine("search", "Search", "Pull the page down to search. Hold the search button for your recent searches."),
    GuideLine("tag", "Smart sections", "Hold a box and pick Section of its scraps, or hold a scrap and pick Section for its tag. Or edit a section and choose Fill automatically: a tag, a box or this week."),
)

/** Every gesture of Home, one line each. */
@Composable
fun GestureGuideSheet(onDone: () -> Unit) {
    Sheet("Gestures", onDone) {
        SheetNote("Each one can be switched off under Gestures in Customize home.")
        SheetGroup {
            GUIDE.forEachIndexed { i, g ->
                if (i > 0) SheetDivider(56.dp)
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), Arrangement.spacedBy(14.dp), Alignment.Top) {
                    Ic(g.icon, 24.dp, Sb.ink)
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(g.title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text(g.how, fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute)
                    }
                }
            }
        }
    }
}

/** The small card Home shows once: what to try first, and a way to see them all. */
@Composable
fun GestureHint(modifier: Modifier, onGotIt: () -> Unit, onAll: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(modifier.fillMaxWidth().shadow(14.dp, shape).clip(shape).background(Sb.raised).border(1.dp, Sb.line, shape).padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Try holding something", fontSize = 17.sp, fontWeight = FontWeight.Medium)
        Text("Hold a scrap or a box for a menu. Keep holding and move it to carry it somewhere else on Home.", fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), Arrangement.End, Alignment.CenterVertically) {
            Text("All gestures", Modifier.tap("See all gestures", onAll).padding(horizontal = 14.dp, vertical = 10.dp), fontSize = 15.sp, color = Sb.mute)
            Text("Got it", Modifier.tap("Got it", onGotIt).padding(horizontal = 14.dp, vertical = 10.dp), fontSize = 15.sp, fontWeight = FontWeight.Medium, color = LocalSb.current.acc)
        }
    }
}
