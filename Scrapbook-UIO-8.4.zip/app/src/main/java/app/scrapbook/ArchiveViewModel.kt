package app.scrapbook

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import app.scrapbook.ui.ListLayout
import app.scrapbook.ui.SbTheme
import app.scrapbook.ui.Themes
import app.scrapbook.ui.rgbColor
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

val Context.dataStore by preferencesDataStore("settings")
private val ACC = intPreferencesKey("accent")
/** The color of your own for the app accent (0xRRGGBB). It is in use when ACC is -1. */
private val ACC_RGB = intPreferencesKey("accent_rgb")
private val SERIF = booleanPreferencesKey("serif")
private val RAD = intPreferencesKey("radius")
private val DARK = intPreferencesKey("dark")
private val HEADER = intPreferencesKey("header")
private val INBOX = intPreferencesKey("inbox_color")
private val NAV = intPreferencesKey("nav_style")
private val EDITOR = intPreferencesKey("editor_style")
private val PIN_RECORD = stringPreferencesKey("pin_record")
private val LOCK_ON = booleanPreferencesKey("lock_on")
private val BIO_ON = booleanPreferencesKey("lock_biometric")
private val LOCK_DELAY = intPreferencesKey("lock_delay")
private val HIDE_RECENTS = booleanPreferencesKey("lock_hide_recents")
private val PIN_FAILS = intPreferencesKey("pin_fails")
private val PIN_FAIL_AT = longPreferencesKey("pin_fail_at")
private val FIND_ENTRY = intPreferencesKey("find_entry")
private val WELCOMED = booleanPreferencesKey("welcomed")
private val INBOX_HIDDEN = booleanPreferencesKey("inbox_hidden")
private val GREY_BG = booleanPreferencesKey("grey_bg")
private val HEADER_SIZE = intPreferencesKey("header_size")
private val DEFAULT_GRID = booleanPreferencesKey("default_grid")
private val DEFAULT_LAYOUT = stringPreferencesKey("default_layout")
private val SORT_TITLE = booleanPreferencesKey("sort_title")
private val SORT_ASC = booleanPreferencesKey("sort_asc")
private val SORT_MODE = intPreferencesKey("sort_mode")
private val BOX_STYLE = intPreferencesKey("box_style")
private val BOXES_VIEW = intPreferencesKey("boxes_view")
private val SHOW_PREVIEW = booleanPreferencesKey("show_preview")
private val SHOW_BOXES = booleanPreferencesKey("show_boxes")
private val HOME_BOXES_ACTIVE = booleanPreferencesKey("home_boxes_active")
private val HOME_ORDER = stringPreferencesKey("home_order")
private val HOME_HIDDEN = stringPreferencesKey("home_hidden")
private val HOME_STYLES = stringPreferencesKey("home_styles")
private val HOME_SECTIONS = stringPreferencesKey("home_sections")
private val HOME_SKINS = stringPreferencesKey("home_skins")
private val HOME_LOOK = stringPreferencesKey("home_look")
private val MENU_ORDER = stringPreferencesKey("menu_order")
private val MENU_HIDDEN = stringPreferencesKey("menu_hidden")
private val MENU_SKIN = stringPreferencesKey("menu_skin")
private val MENU_ROWS = intPreferencesKey("menu_rows")
private val MENU_ICONS = booleanPreferencesKey("menu_icons")
private val MENU_DIM = intPreferencesKey("menu_dim")
private val MENU_FOOTER = booleanPreferencesKey("menu_footer")
private val MENU_ACTION = intPreferencesKey("menu_action")
private val MENU_SHORTCUTS = stringPreferencesKey("menu_shortcuts")
private val MENU_LOOKS = stringPreferencesKey("menu_looks")
private val MENU_SECTIONS = stringPreferencesKey("menu_sections")
private val MENU_TITLE = stringPreferencesKey("menu_title")
private val MENU_SHOW_TITLE = booleanPreferencesKey("menu_show_title")
private val MENU_GROUPS = intPreferencesKey("menu_groups")
private val MENU_CANCEL = intPreferencesKey("menu_cancel")
private val MENU_BOTTOM = stringPreferencesKey("menu_bottom")
private val MENU_FOOTER_TEXT = stringPreferencesKey("menu_footer_text")
private val MENU_ACCENT = booleanPreferencesKey("menu_accent")
private val MENU_PROFILE = booleanPreferencesKey("menu_profile")
private val MENU_PRESETS = stringPreferencesKey("menu_presets")
private val GESTURE_HOLD = booleanPreferencesKey("gesture_hold")
private val GESTURE_DRAG = booleanPreferencesKey("gesture_drag")
private val GESTURE_FILE = booleanPreferencesKey("gesture_file")
private val GESTURE_EMPTY = booleanPreferencesKey("gesture_empty")
private val GESTURE_SWIPE = booleanPreferencesKey("gesture_swipe")
private val GESTURE_CAPTURE = booleanPreferencesKey("gesture_capture")
private val GESTURE_DOUBLE = intPreferencesKey("gesture_double")
private val GESTURE_PULL = booleanPreferencesKey("gesture_pull")
private val GESTURE_HINT = booleanPreferencesKey("gesture_hint_seen")
private val LAST_BOX = stringPreferencesKey("last_box")
private val BOX_SEARCH = booleanPreferencesKey("box_search")
private val RECENT_SEARCHES = stringPreferencesKey("recent_searches")
private val RECENT_COLORS = stringPreferencesKey("recent_text_colors")
private val REOPEN_LAST_BOX = booleanPreferencesKey("reopen_last_box")
private val HASHTAG_TAGS = booleanPreferencesKey("hashtag_tags")
private val PASTE_OFFERS = booleanPreferencesKey("paste_offers")
private val PLAIN_PHOTOS = booleanPreferencesKey("plain_photos")
private val LINK_SUGGEST = booleanPreferencesKey("link_suggestions")
private val CONNECTIONS_OPEN = booleanPreferencesKey("connections_open")
private val SHOW_SAVED = booleanPreferencesKey("show_saved_mark")
private val AUTO_KEYBOARD = booleanPreferencesKey("auto_keyboard")
private val MARKS_ACCENT = booleanPreferencesKey("marks_accent")
private val LINKS_ACCENT = booleanPreferencesKey("links_accent")
private val HASHTAGS_ACCENT = booleanPreferencesKey("hashtags_accent")
private val ICON_FOLLOWS = booleanPreferencesKey("icon_follows_accent")
private val HAPTICS = booleanPreferencesKey("haptics")
// Account (see Account.kt) and the Home greeting (see Greetings.kt).
private val ACCOUNT_NAME = stringPreferencesKey("account_name")
private val ACCOUNT_NICK = stringPreferencesKey("account_nick")
private val ACCOUNT_ABOUT = stringPreferencesKey("account_about")
private val ACCOUNT_PRONOUNS = stringPreferencesKey("account_pronouns")
private val ACCOUNT_BMONTH = intPreferencesKey("account_bmonth")
private val ACCOUNT_BDAY = intPreferencesKey("account_bday")
private val ACCOUNT_AVATAR = stringPreferencesKey("account_avatar")
private val ACCOUNT_AVATAR_COLOR = intPreferencesKey("account_avatar_color")
private val GREET_ON = booleanPreferencesKey("greet_on")
private val GREET_TONE = intPreferencesKey("greet_tone")
private val GREET_TIME = booleanPreferencesKey("greet_time")
private val GREET_CASUAL = booleanPreferencesKey("greet_casual")
private val GREET_NOTES = booleanPreferencesKey("greet_notes")
private val GREET_EVERY = intPreferencesKey("greet_every")
private val GREET_AVATAR = booleanPreferencesKey("greet_avatar")
private val GREET_SUB = intPreferencesKey("greet_sub")
private val GREET_TEXT = intPreferencesKey("greet_text")
private val GREET_PIC = intPreferencesKey("greet_pic")

/** Something shared into the app from elsewhere, waiting to be saved. */
data class Incoming(val text: String, val subject: String, val images: List<Uri>, val files: List<Uri> = emptyList())


/**
 * The parts of Home that are switched off. Until Customize home has saved anything this is read from the two older switches (Show boxes on home,
 * Show greeting), so nobody's Home changes when they update.
 */
private fun homeHiddenOf(p: Preferences): Set<HomeElement> =
    p[HOME_HIDDEN]?.let { HomeLayout.decodeHidden(it) } ?: buildSet {
        if (p[SHOW_BOXES] == false) add(HomeElement.Boxes)
        if (p[GREET_ON] == false) add(HomeElement.Greeting)
    }

/** Switches one part of Home on or off inside an edit of the settings. */
private fun MutablePreferences.setHomeShown(e: HomeElement, shown: Boolean) {
    val h = homeHiddenOf(this).toMutableSet()
    if (shown) h.remove(e) else h.add(e)
    this[HOME_HIDDEN] = HomeLayout.encodeHidden(h)
}

/** The gesture settings as they are now. */
private fun gesturePrefsOf(p: Preferences): GesturePrefs = GesturePrefs(
    p[GESTURE_HOLD] ?: true, p[GESTURE_DRAG] ?: true, p[GESTURE_FILE] ?: true, p[GESTURE_EMPTY] ?: true, p[GESTURE_SWIPE] ?: true, p[GESTURE_CAPTURE] ?: true,
    (p[GESTURE_DOUBLE] ?: 1).coerceIn(0, GesturePrefs.DOUBLE_TAP_OPTIONS.lastIndex), p[GESTURE_PULL] ?: true,
)

/** Every piece of Home a skin holds, read from the settings as they are now (see HomeSkins.kt). */
private fun homeSnapshot(p: Preferences): Map<String, String> = HomeSkins.sparse(mapOf(
    SkinKeys.ORDER to HomeLayout.decodeOrder(p[HOME_ORDER]).joinToString(",") { it.key },
    SkinKeys.HIDDEN to HomeLayout.encodeHidden(homeHiddenOf(p)),
    SkinKeys.STYLES to HomeStyles.decode(p[HOME_STYLES]).encode(),
    SkinKeys.SECTIONS to HomeSections.encode(HomeSections.decode(p[HOME_SECTIONS])),
    SkinKeys.HEADER to (p[HEADER] ?: 1).toString(),
    SkinKeys.HEADER_SIZE to (p[HEADER_SIZE] ?: 1).toString(),
    SkinKeys.ADD_BUTTON to (p[NAV] ?: 0).toString(),
    SkinKeys.BOXES_ACTIVE to (p[HOME_BOXES_ACTIVE] ?: true).toString(),
    SkinKeys.GREET_TEXT to (p[GREET_TEXT] ?: GreetingPrefs.TEXT_DEFAULT).toString(),
    SkinKeys.GREET_PIC to (p[GREET_PIC] ?: GreetingPrefs.PIC_DEFAULT).toString(),
    SkinKeys.GREET_AVATAR to (p[GREET_AVATAR] ?: true).toString(),
    SkinKeys.GESTURES to gesturePrefsOf(p).encode(),
    SkinKeys.LOOK to HomeLook.decode(p[HOME_LOOK]).encode(),
))

/** Puts a skin's pieces into the settings. A piece the skin does not hold is the classic look; a piece that cannot be read is too. */
private fun MutablePreferences.applyHomeSnapshot(values: Map<String, String>) {
    fun piece(k: String): String = values[k] ?: SkinKeys.DEFAULTS.getValue(k)
    fun int(k: String, lo: Int, hi: Int): Int = (piece(k).toIntOrNull() ?: SkinKeys.DEFAULTS.getValue(k).toInt()).coerceIn(lo, hi)
    this[HOME_ORDER] = HomeLayout.decodeOrder(piece(SkinKeys.ORDER)).joinToString(",") { it.key }
    this[HOME_HIDDEN] = HomeLayout.encodeHidden(HomeLayout.decodeHidden(piece(SkinKeys.HIDDEN)))
    this[HOME_STYLES] = HomeStyles.decode(piece(SkinKeys.STYLES)).encode()
    this[HOME_SECTIONS] = HomeSections.encode(HomeSections.decode(piece(SkinKeys.SECTIONS)))
    this[HEADER] = int(SkinKeys.HEADER, 0, 2)
    this[HEADER_SIZE] = int(SkinKeys.HEADER_SIZE, 0, 2)
    this[NAV] = int(SkinKeys.ADD_BUTTON, 0, 4)
    this[HOME_BOXES_ACTIVE] = piece(SkinKeys.BOXES_ACTIVE) != "false"
    this[GREET_TEXT] = int(SkinKeys.GREET_TEXT, GreetingPrefs.TEXT_MIN, GreetingPrefs.TEXT_MAX)
    this[GREET_PIC] = int(SkinKeys.GREET_PIC, GreetingPrefs.PIC_MIN, GreetingPrefs.PIC_MAX)
    this[GREET_AVATAR] = piece(SkinKeys.GREET_AVATAR) != "false"
    this[HOME_LOOK] = HomeLook.decode(piece(SkinKeys.LOOK)).encode()
    val g = GesturePrefs.decode(piece(SkinKeys.GESTURES))
    this[GESTURE_HOLD] = g.hold; this[GESTURE_DRAG] = g.drag; this[GESTURE_FILE] = g.file; this[GESTURE_EMPTY] = g.empty
    this[GESTURE_SWIPE] = g.swipe; this[GESTURE_CAPTURE] = g.capture; this[GESTURE_DOUBLE] = g.doubleTap; this[GESTURE_PULL] = g.pull
}

/** The saved skins, or the first ones made from the settings as they are; the worn skin always holds what the settings hold now. */
private fun homeSkinsOf(p: Preferences): HomeSkins {
    val live = homeSnapshot(p)
    return (p[HOME_SKINS]?.let { HomeSkins.decode(it) } ?: HomeSkins.initial(live)).withLive(live)
}

class ArchiveViewModel(app: Application) : AndroidViewModel(app) {
    /** Text to put in the Settings search when that screen opens (the editor menu links to a group this way). Settings clears it after reading it. */
    var settingsSearch: String = ""
    /** Set by a collection screen so the next new note starts in that collection. */
    var pendingShelf: String? = null
    /** A filter for the Search screen to start with (a tapped tag): read once when Search opens, then cleared. */
    var pendingFilter: ScrapFilter? = null
    /** A search to start with: set by the recent searches menu on Home's search button, taken by the search page. */
    var pendingQuery: String? = null
    /** Set by the Home page's quick buttons: the editor opens a new scrap with this text already in it, or goes straight to the photo picker. */
    var pendingBody: String? = null
    /** Set by the Customize home row in Settings: Home opens Customize home as soon as it is shown, once. */
    var pendingCustomize = false
    var pendingImage = false
    fun takePendingBody(): String? { val s = pendingBody; pendingBody = null; return s }
    fun takePendingImage(): Boolean { val b = pendingImage; pendingImage = false; return b }
    /** Set by the Home page's microphone button: the editor opens a new scrap with the Record audio sheet already open. */
    var pendingRecord = false
    fun takePendingRecord(): Boolean { val b = pendingRecord; pendingRecord = false; return b }
    /** The writing bar's Files and Camera: the new editor opens the file picker or the camera at once, like [pendingImage] does for the photo picker. */
    var pendingFile = false
    fun takePendingFile(): Boolean { val b = pendingFile; pendingFile = false; return b }
    var pendingCamera = false
    fun takePendingCamera(): Boolean { val b = pendingCamera; pendingCamera = false; return b }
    /** Tags picked on the writing bar, in the stored "one, two" form, for a scrap opened in the editor from it. */
    var pendingTags: String? = null
    fun takePendingTags(): String? { val s = pendingTags; pendingTags = null; return s }

    /**
     * Saves a scrap straight from the writing bar (see NavStyles.kt): the text goes in as it is, the title is its first line (as in the editor), #words become
     * tags when that setting is on. [done] gets the new scrap's id once it is stored.
     */
    /** [extraTags] are tags picked on the writing bar; they join the #words found in the text. */
    fun addQuick(text: String, box: String, extraTags: List<String> = emptyList(), done: (Long) -> Unit) {
        viewModelScope.launch {
            val first = text.lineSequence().firstOrNull { it.isNotBlank() && !it.startsWith("```") }?.let { plainPreview(it) }?.takeIf { it.isNotBlank() }?.take(50)
            val tags = cleanTags((if (hashtagTags.value) newHashtags(text, null, emptySet()) else emptyList()) + extraTags)
            done(saveNow(Item(title = first ?: "Untitled", body = text, kind = Kind.Note, collection = box, tags = tags)))
        }
    }
    /** The writing bar's voice memo: a new scrap holding just the recording, titled with the time. */
    fun addRecording(a: Attachment, box: String, done: (Long) -> Unit) {
        viewModelScope.launch {
            val title = "Voice memo, " + java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            done(saveNow(Item(title = title, body = "", kind = Kind.Note, collection = box, files = a.encode())))
        }
    }
    /** Set by anything that opens a scrap meaning to write in it (the reading page's Edit button, a fresh duplicate); the editor takes it once and starts in writing instead of reading. */
    var pendingEdit = false
    fun takePendingEdit(): Boolean { val b = pendingEdit; pendingEdit = false; return b }
    fun takePendingShelf(): String? { val s = pendingShelf; pendingShelf = null; return s }
    val incoming = MutableStateFlow<Incoming?>(null)
    fun clearIncoming() { incoming.value = null }
    private val dao = Db.get(app).dao()
    // Hidden boxes (see Privacy.kt): [items], [shelves] and [bin] are what every screen sees, and they leave out hidden boxes until they are unlocked with the
    // PIN, so no screen can show one by forgetting to check. Only backup and restore use the full lists ([rawItems], [rawShelves]). These come first because the
    // lists below are built from them.
    val hiddenUnlocked = MutableStateFlow(false)
    private val rawItems: StateFlow<List<Item>> = dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    private val rawShelves: StateFlow<List<Shelf>> = dao.shelves().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val pinSet: StateFlow<Boolean> = app.dataStore.data.map { !it[PIN_RECORD].isNullOrEmpty() }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    /** The boxes hidden right now. Boxes marked hidden only count while a PIN exists, so a backup restored onto a new phone cannot lock you out of its boxes. */
    val hiddenNames: StateFlow<Set<String>> = combine(rawShelves, pinSet) { s, p -> if (p) hiddenBoxNames(s) else emptySet() }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val hasHiddenBoxes: StateFlow<Boolean> = hiddenNames.map { it.isNotEmpty() }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val items: StateFlow<List<Item>> = combine(rawItems, hiddenNames, hiddenUnlocked) { all, hidden, open -> visibleItems(all, hidden, open) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val shelves: StateFlow<List<Shelf>> = combine(rawShelves, hiddenNames, hiddenUnlocked) { all, hidden, open -> if (open || hidden.isEmpty()) all else all.filter { it.name !in hidden } }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    /** Deleted scraps waiting in the Bin, the most recently deleted first. */
    val bin: StateFlow<List<Item>> = combine(dao.bin(), hiddenNames, hiddenUnlocked) { all, hidden, open -> visibleItems(all, hidden, open) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    init {
        // Housekeeping when the app starts: scraps that have been in the Bin for BIN_DAYS go for good, and so do the versions of scraps that no longer exist.
        viewModelScope.launch {
            dao.purgeBefore(binCutoff(System.currentTimeMillis())); dao.dropOrphanVersions()
            // These two read every scrap in full. Nothing depends on them being quick, so they wait until the first screen is up instead of competing with it.
            delay(6_000)
            sweepImages(); pruneSpots()
        }
    }

    /** Forgets where you were (cursor, scroll) in scraps that are gone for good. Scraps still in the Bin keep theirs, so a restored scrap opens where it was. */
    private suspend fun pruneSpots() = withContext(Dispatchers.IO) {
        try {
            val ids = dao.everything().map { it.id }.toSet()
            EditorMemory(getApplication<Application>()).prune(ids)
            // Places you opened that are gone for good drop out of the quick switcher too.
            val kept = Recents.prune(recentPlaces.value, ids, rawShelves.value.map { it.name }.toSet() + "Inbox")
            if (kept.size != recentPlaces.value.size) { recentPlaces.value = kept; recentPrefs.edit().putString("list", Recents.encode(kept)).apply() }
        } catch (_: Exception) { /* view memory is best effort */ }
    }

    /** Deletes photo files nothing uses any more (purged scraps, photos taken off a scrap, replaced box covers). Safe by design: see [orphanImages]. */
    private suspend fun sweepImages() = withContext(Dispatchers.IO) {
        try {
            val dir = getApplication<Application>().filesDir
            val text = StringBuilder()
            dao.everything().forEach { text.append(it.imageUri).append('\n').append(it.images).append('\n').append(it.cover).append('\n').append(it.canvas).append('\n').append(it.body).append('\n').append(it.files).append('\n') }
            dao.shelves().first().forEach { text.append(it.coverUri).append('\n') }
            val files = dir.listFiles().orEmpty().filter { it.isFile && (it.name.startsWith("img_") || it.name.startsWith("imp_")) }.map { it.name to it.lastModified() }
            orphanImages(files, text.toString(), System.currentTimeMillis()).forEach { File(dir, it).delete() }
            // Attached files each live in their own folder inside attachments/. A folder goes when nothing mentions it any more (same grace period as photos).
            val adir = File(dir, "attachments")
            val folders = adir.listFiles().orEmpty().filter { it.isDirectory }.map { it.name to it.lastModified() }
            orphanImages(folders, text.toString(), System.currentTimeMillis()).forEach { File(adir, it).deleteRecursively() }
        } catch (_: Exception) { /* cleanup is best effort: a failure must never touch the user's notes */ }
    }

    private val ds = app.dataStore
    val theme: StateFlow<SbTheme> = ds.data.map { p ->
        val base = customAccentOf(p)?.let { rgb ->
            val acc = rgbColor(rgb)
            SbTheme("Custom", acc, lerp(Color.White, acc, .15f), Color.White)
        } ?: Themes[(p[ACC] ?: 0).coerceIn(Themes.indices)]
        base.copy(serif = p[SERIF] ?: false, radius = (p[RAD] ?: 24).dp)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, Themes[0])
    private fun edit(f: (MutablePreferences) -> Unit) { viewModelScope.launch { ds.edit { f(it) } } }
    val welcomed: StateFlow<Boolean> = ds.data.map { it[WELCOMED] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun dismissWelcome() = edit { it[WELCOMED] = true }
    val darkMode: StateFlow<Int> = ds.data.map { it[DARK] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    fun setDark(i: Int) = edit { it[DARK] = i }
    /** Main page header: 0 wordmark on the left, 1 wordmark centered, 2 round buttons with a centered wordmark. */
    val headerStyle: StateFlow<Int> = ds.data.map { it[HEADER] ?: 1 }.stateIn(viewModelScope, SharingStarted.Eagerly, 1)
    fun setHeader(i: Int) = edit { it[HEADER] = i }
    /** Color of the Inbox box: -1 is gray, otherwise an index into the box colors. */
    val inboxColor: StateFlow<Int> = ds.data.map { it[INBOX] ?: -1 }.stateIn(viewModelScope, SharingStarted.Eagerly, -1)
    fun setInboxColor(i: Int) = edit { it[INBOX] = i }
    /** Inbox is built in, so "deleting" it hides its tile. Its scraps stay in All scraps, and the Boxes screen can bring it back. */
    val inboxHidden: StateFlow<Boolean> = ds.data.map { it[INBOX_HIDDEN] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setInboxHidden(b: Boolean) = edit { it[INBOX_HIDDEN] = b }
    /** Add button style: 0 is the "New scrap" pill, 1 is a single round menu button (as in Binder): tap for the menu, hold it to pop out the round add button. */
    val navStyle: StateFlow<Int> = ds.data.map { it[NAV] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    fun setNav(i: Int) = edit { it[NAV] = i }
    /** Editor toolbar: 0 is the selection bubble (default), 1 is the floating pill. */
    val editorStyle: StateFlow<Int> = ds.data.map { it[EDITOR] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    fun setEditorStyle(i: Int) = edit { it[EDITOR] = i }
    /** Where "Find in scrap" starts from in the editor: 0 hold the back button, 1 the 3-dot menu, 2 both. */
    val findEntry: StateFlow<Int> = ds.data.map { it[FIND_ENTRY] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    fun setFindEntry(i: Int) = edit { it[FIND_ENTRY] = i }
    /** Light mode page color: false is white (the default), true is the soft grey page. Dark mode ignores it. */
    val greyBg: StateFlow<Boolean> = ds.data.map { it[GREY_BG] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setGreyBg(b: Boolean) = edit { it[GREY_BG] = b }
    /** Size of the "scrapbook" title on the main page: 0 compact, 1 regular, 2 large. */
    val headerSize: StateFlow<Int> = ds.data.map { it[HEADER_SIZE] ?: 1 }.stateIn(viewModelScope, SharingStarted.Eagerly, 1)
    fun setHeaderSize(i: Int) = edit { it[HEADER_SIZE] = i }
    /** The view the main page starts in. The list/grid switch on the page itself only changes it until you leave. */
    val defaultGrid: StateFlow<Boolean> = ds.data.map { it[DEFAULT_GRID] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setDefaultGrid(b: Boolean) = edit { it[DEFAULT_GRID] = b }
    /** The layout pages start in (Cards, Grid, …). Installs that only stored list or grid keep working: grid stays Grid, list becomes Cards. */
    val defaultLayout: StateFlow<ListLayout> = ds.data.map { p -> ListLayout.of(p[DEFAULT_LAYOUT] ?: if (p[DEFAULT_GRID] == true) "grid" else "cards") }.stateIn(viewModelScope, SharingStarted.Eagerly, ListLayout.Cards)
    fun setDefaultLayout(l: ListLayout) = edit { it[DEFAULT_LAYOUT] = l.key }
    /** How scraps are sorted everywhere (All scraps, boxes, Settings share it): by date edited, date created or title, and whether the order is reversed (oldest first, Z to A). */
    /** Date edited, date created or title. Older installs only stored title or not, so that is the fallback. */
    val sortMode: StateFlow<SortMode> = ds.data.map { p -> p[SORT_MODE]?.let { SortMode.entries.getOrNull(it) } ?: if (p[SORT_TITLE] == true) SortMode.Title else SortMode.Edited }
        .stateIn(viewModelScope, SharingStarted.Eagerly, SortMode.Edited)
    val sortAsc: StateFlow<Boolean> = ds.data.map { it[SORT_ASC] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setSortAsc(b: Boolean) = edit { it[SORT_ASC] = b }
    fun setSort(mode: SortMode, asc: Boolean = mode.naturalAsc) = edit { it[SORT_MODE] = mode.ordinal; it[SORT_TITLE] = mode == SortMode.Title; it[SORT_ASC] = asc }
    /** Look of the boxes: an index into BOX_STYLES (0 tabbed, 1 paper stack, 2 tinted tiles, 3 folder tabs, 4 chips, 5 list rows, 6 notebook covers). */
    val boxStyle: StateFlow<Int> = ds.data.map { it[BOX_STYLE] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    fun setBoxStyle(i: Int) = edit { it[BOX_STYLE] = i }
    /** Look of the Boxes screen: an index into BOXES_VIEWS (0 default cards, 1 nested, 2 shelf, 3 cover, 4 stack). */
    val boxesView: StateFlow<Int> = ds.data.map { it[BOXES_VIEW] ?: 0 }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    fun setBoxesView(i: Int) = edit { it[BOXES_VIEW] = i }
    /** Whether lists show a few lines of each scrap under its title. */
    val showPreview: StateFlow<Boolean> = ds.data.map { it[SHOW_PREVIEW] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowPreview(b: Boolean) = edit { it[SHOW_PREVIEW] = b }
    /** Whether the box tiles are shown on the main page. */
    val showBoxes: StateFlow<Boolean> = ds.data.map { HomeElement.Boxes !in homeHiddenOf(it) }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowBoxes(b: Boolean) = edit { it[SHOW_BOXES] = b; it.setHomeShown(HomeElement.Boxes, b) }
    /** Which parts Home shows and in what order (Customize home). Null for the first moment, until the saved layout has been read. */
    val homeLayout: StateFlow<HomeLayout?> = ds.data.map { p -> HomeLayout(HomeLayout.decodeOrder(p[HOME_ORDER]), homeHiddenOf(p)) }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    fun setHomeLayout(l: HomeLayout) = edit { it[HOME_ORDER] = l.encodeOrder(); it[HOME_HIDDEN] = l.encodeHidden() }
    /** The designs chosen for the parts of Home (Customize home > a part's options). Nothing chosen is the classic Home. Null for the first moment, until they have been read. */
    val homeStyles: StateFlow<HomeStyles?> = ds.data.map { HomeStyles.decode(it[HOME_STYLES]) }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    fun setHomeStyles(s: HomeStyles) = edit { it[HOME_STYLES] = s.encode() }

    // The menu (the sheet the menu button opens): what it holds and in what order, the names you gave things, your shortcuts, and the skin it wears.
    // See MenuLayout.kt, MenuStyle.kt and ui/MenuSkins.kt.
    val menuLayout: StateFlow<MenuLayout> = ds.data.map { p -> MenuLayout.decode(p[MENU_ORDER], p[MENU_HIDDEN], p[MENU_SHORTCUTS], p[MENU_LOOKS], p[MENU_SECTIONS]) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, MenuLayout.Default)
    fun setMenuLayout(l: MenuLayout) = edit { writeMenuLayout(it, l) }
    val menuStyle: StateFlow<MenuStyle> = ds.data.map { p ->
        MenuStyle(MenuSkinId.of(p[MENU_SKIN]), MenuOptions(
            rowSize = p[MENU_ROWS] ?: 1, icons = p[MENU_ICONS] ?: true, dim = p[MENU_DIM] ?: 1, footer = p[MENU_FOOTER] ?: true, action = p[MENU_ACTION] ?: 0,
            title = p[MENU_TITLE].orEmpty(), showTitle = p[MENU_SHOW_TITLE] ?: true, groupNames = p[MENU_GROUPS] ?: 0, cancel = p[MENU_CANCEL] ?: 0,
            bottom = MenuBottom.of(p[MENU_BOTTOM]), footerText = p[MENU_FOOTER_TEXT].orEmpty(), accent = p[MENU_ACCENT] ?: false, profile = p[MENU_PROFILE] ?: false,
        ).clamped())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, MenuStyle())
    fun setMenuStyle(s: MenuStyle) = edit { writeMenuStyle(it, s) }
    /** Layout and style in one write (Undo and the presets). */
    fun setMenuConfig(c: MenuConfig) = edit { writeMenuLayout(it, c.layout); writeMenuStyle(it, c.style) }
    /** The menu setups you saved under a name (see MenuPresets). */
    val menuPresets: StateFlow<List<MenuPreset>> = ds.data.map { MenuPresets.decode(it[MENU_PRESETS]) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun setMenuPresets(list: List<MenuPreset>) = edit { it[MENU_PRESETS] = MenuPresets.encode(list) }
    private fun writeMenuLayout(p: MutablePreferences, l: MenuLayout) {
        p[MENU_ORDER] = l.encodeOrder(); p[MENU_HIDDEN] = l.encodeHidden(); p[MENU_SHORTCUTS] = l.encodeShortcuts(); p[MENU_LOOKS] = l.encodeLooks(); p[MENU_SECTIONS] = l.encodeSections()
    }
    private fun writeMenuStyle(p: MutablePreferences, s: MenuStyle) {
        val o = s.options.clamped()
        p[MENU_SKIN] = s.skin.key; p[MENU_ROWS] = o.rowSize; p[MENU_ICONS] = o.icons; p[MENU_DIM] = o.dim; p[MENU_FOOTER] = o.footer; p[MENU_ACTION] = o.action
        p[MENU_TITLE] = o.title; p[MENU_SHOW_TITLE] = o.showTitle; p[MENU_GROUPS] = o.groupNames; p[MENU_CANCEL] = o.cancel; p[MENU_BOTTOM] = o.bottom.key
        p[MENU_FOOTER_TEXT] = o.footerText; p[MENU_ACCENT] = o.accent; p[MENU_PROFILE] = o.profile
    }
    /** The sections you made on Home by dragging a scrap or a box out of its place (see HomeSections.kt). Null for the first moment, until they have been read. */
    val homeSections: StateFlow<List<HomeSection>?> = ds.data.map { HomeSections.decode(it[HOME_SECTIONS]) }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    fun setHomeSections(l: List<HomeSection>) = edit { it[HOME_SECTIONS] = HomeSections.encode(l) }

    /** The look every part of Home shares (corners, cards, space; see HomeLook.kt). Null for the first moment, until it has been read. */
    val homeLook: StateFlow<HomeLook?> = ds.data.map { HomeLook.decode(it[HOME_LOOK]) }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    fun setHomeLook(l: HomeLook) = edit { it[HOME_LOOK] = l.encode() }

    /** The Home skins (see HomeSkins.kt). Null for the first moment, until they have been read. */
    val homeSkins: StateFlow<HomeSkins?> = ds.data.map { homeSkinsOf(it) }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    /** Puts skin [id] on: the one worn now keeps what was changed on it, then the settings become the new one's. */
    fun wearSkin(id: String) = edit { p ->
        val next = homeSkinsOf(p).activate(id) ?: return@edit
        p[HOME_SKINS] = next.encode()
        p.applyHomeSnapshot(next.current.values)
    }
    /** Adds a ready-made skin (HomeReadySkins.kt) to the skins as a copy and puts it on: the skin worn now keeps what was changed on it. */
    fun wearReadySkin(key: String) = edit { p ->
        val ready = ReadySkins.of(key) ?: return@edit
        val (list, skin) = homeSkinsOf(p).add(ready.name, ready.values)
        p[HOME_SKINS] = list.activate(skin.id)!!.encode()
        p.applyHomeSnapshot(skin.values)
    }
    /** Makes a new skin from Home as it is now and puts it on, so what you change next is saved in it and the skin you came from stays as it was. */
    fun newSkin() = edit { p ->
        val (list, skin) = homeSkinsOf(p).let { it.add("My skin", it.current.values) }
        p[HOME_SKINS] = list.activate(skin.id)!!.encode()
    }
    /** A copy of a skin, named after it. It is not put on. */
    fun duplicateSkin(id: String) = edit { p ->
        val cur = homeSkinsOf(p)
        val from = cur.get(id) ?: return@edit
        p[HOME_SKINS] = cur.add(from.name + " copy", from.values).first.encode()
    }
    /** Adds a skin that came from a shared code (see SkinShare.kt) next to the others. It is not put on. */
    fun importSkin(skin: HomeSkin) = edit { p -> p[HOME_SKINS] = homeSkinsOf(p).add(skin.name, skin.values).first.encode() }
    fun renameSkin(id: String, name: String) = edit { p -> p[HOME_SKINS] = homeSkinsOf(p).rename(id, name).encode() }
    fun deleteSkin(id: String) = edit { p -> p[HOME_SKINS] = homeSkinsOf(p).delete(id).encode() }
    /** Back to the classic look for a skin; if it is the one worn, Home goes back to the classic look too. */
    fun resetSkin(id: String) = edit { p ->
        val next = homeSkinsOf(p).reset(id)
        p[HOME_SKINS] = next.encode()
        if (next.current.id == id) p.applyHomeSnapshot(emptyMap())
    }
    /** Hold for a menu, hold and drag to move, drop a scrap on a box to file it: all on by default (Customize home). */
    val gesturePrefs: StateFlow<GesturePrefs> = ds.data.map { gesturePrefsOf(it) }.stateIn(viewModelScope, SharingStarted.Eagerly, GesturePrefs())
    /** Whether the one-time card about the gestures has been put away. Null for the first moment, until it has been read. */
    val gestureHintSeen: StateFlow<Boolean?> = ds.data.map { it[GESTURE_HINT] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    fun seeGestureHint() = edit { it[GESTURE_HINT] = true }
    fun setGesturePrefs(g: GesturePrefs) = edit { it[GESTURE_HOLD] = g.hold; it[GESTURE_DRAG] = g.drag; it[GESTURE_FILE] = g.file; it[GESTURE_EMPTY] = g.empty; it[GESTURE_SWIPE] = g.swipe; it[GESTURE_CAPTURE] = g.capture; it[GESTURE_DOUBLE] = g.doubleTap; it[GESTURE_PULL] = g.pull }
    /** The Boxes row on the home page follows activity (Inbox first, newest work first, empty boxes last). Off = your own order. */
    val homeBoxesActive: StateFlow<Boolean> = ds.data.map { it[HOME_BOXES_ACTIVE] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setHomeBoxesActive(b: Boolean) = edit { it[HOME_BOXES_ACTIVE] = b }
    /** Whether the search bar is shown at the top of a box's screen. On by default. */
    val showBoxSearch: StateFlow<Boolean> = ds.data.map { it[BOX_SEARCH] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowBoxSearch(b: Boolean) = edit { it[BOX_SEARCH] = b }
    /** The last few searches from the Search screen, newest first. Kept on this phone only. */
    val recentSearches: StateFlow<List<String>> = ds.data.map { parseRecentSearches(it[RECENT_SEARCHES]) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    /** Puts a search at the top of the Recent list (see addRecentSearch for what is ignored). */
    fun rememberSearch(q: String) { if (q.isBlank()) return; edit { p -> p[RECENT_SEARCHES] = encodeRecentSearches(addRecentSearch(parseRecentSearches(p[RECENT_SEARCHES]), q)) } }
    fun forgetSearch(q: String) = edit { p -> p[RECENT_SEARCHES] = encodeRecentSearches(parseRecentSearches(p[RECENT_SEARCHES]).filterNot { it == q }) }
    fun clearSearches() = edit { p -> p.remove(RECENT_SEARCHES) }
    /** The font colors used last (six hex digits each), newest first. Kept on this phone for every scrap. */
    val recentColors: StateFlow<List<String>> = ds.data.map { parseRecentColors(it[RECENT_COLORS]) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun rememberColor(hex: String) = edit { p -> p[RECENT_COLORS] = encodeRecentColors(addRecentColor(parseRecentColors(p[RECENT_COLORS]), hex)) }
    /** Whether small vibrations confirm things you do on purpose (ticking a task, pinning, filing a scrap). On by default. */
    val haptics: StateFlow<Boolean> = ds.data.map { it[HAPTICS] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setHaptics(b: Boolean) = edit { it[HAPTICS] = b }

    // ----- Account: who you are, kept on this phone only (see Account.kt). The picture is a small file in the app's own storage. -----
    val account: StateFlow<Account> = ds.data.map { p ->
        Account(
            name = p[ACCOUNT_NAME].orEmpty(), nickname = p[ACCOUNT_NICK].orEmpty(), about = p[ACCOUNT_ABOUT].orEmpty(), pronouns = p[ACCOUNT_PRONOUNS].orEmpty(),
            birthMonth = p[ACCOUNT_BMONTH] ?: 0, birthDay = p[ACCOUNT_BDAY] ?: 0,
            avatarUri = p[ACCOUNT_AVATAR]?.takeIf { it.isNotEmpty() }, avatarColor = p[ACCOUNT_AVATAR_COLOR] ?: -1,
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, Account(loaded = false))
    fun setAccountName(s: String) = edit { it[ACCOUNT_NAME] = Account.clean(s, Account.MAX_NAME) }
    fun setAccountNick(s: String) = edit { it[ACCOUNT_NICK] = Account.clean(s, Account.MAX_NAME) }
    fun setAccountAbout(s: String) = edit { it[ACCOUNT_ABOUT] = Account.cleanAbout(s) }
    fun setAccountPronouns(s: String) = edit { it[ACCOUNT_PRONOUNS] = Account.clean(s, Account.MAX_PRONOUNS) }
    fun setBirthday(month: Int, day: Int) = edit {
        if (Account.validBirthday(month, day)) { it[ACCOUNT_BMONTH] = month; it[ACCOUNT_BDAY] = day } else { it.remove(ACCOUNT_BMONTH); it.remove(ACCOUNT_BDAY) }
    }
    fun setAvatarColor(i: Int) = edit { it[ACCOUNT_AVATAR_COLOR] = if (i in AVATAR_COLORS.indices) i else -1 }

    /** Saves a picked photo as the profile picture: the part [crop] chose (the middle by default) as a small square, stored as a file named avatar_<time>.jpg (the old one is deleted). */
    fun setAvatar(uri: Uri, crop: AvatarCrop = AvatarCrop.Center, done: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val saved = withContext(Dispatchers.IO) { runCatching { Avatar.save(ctx, uri, crop) }.getOrNull() }
            if (saved == null) { done(false); return@launch }
            val old = ds.data.first()[ACCOUNT_AVATAR]
            ds.edit { it[ACCOUNT_AVATAR] = saved }
            withContext(Dispatchers.IO) { Avatar.delete(old) }
            done(true)
        }
    }

    fun removeAvatar() {
        viewModelScope.launch {
            val old = ds.data.first()[ACCOUNT_AVATAR]
            ds.edit { it.remove(ACCOUNT_AVATAR) }
            withContext(Dispatchers.IO) { Avatar.delete(old) }
        }
    }

    // ----- The Home greeting (see Greetings.kt) -----
    val greetingPrefs: StateFlow<GreetingPrefs> = ds.data.map { p ->
        GreetingPrefs(
            on = HomeElement.Greeting !in homeHiddenOf(p), tone = p[GREET_TONE] ?: 0, time = p[GREET_TIME] ?: true, casual = p[GREET_CASUAL] ?: true, notes = p[GREET_NOTES] ?: true,
            everySec = p[GREET_EVERY] ?: 20, avatar = p[GREET_AVATAR] ?: true, sub = p[GREET_SUB] ?: 0,
            textSize = (p[GREET_TEXT] ?: GreetingPrefs.TEXT_DEFAULT).coerceIn(GreetingPrefs.TEXT_MIN, GreetingPrefs.TEXT_MAX),
            picSize = (p[GREET_PIC] ?: GreetingPrefs.PIC_DEFAULT).coerceIn(GreetingPrefs.PIC_MIN, GreetingPrefs.PIC_MAX),
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, GreetingPrefs())
    fun setGreetingPrefs(g: GreetingPrefs) = edit {
        it[GREET_ON] = g.on; it.setHomeShown(HomeElement.Greeting, g.on); it[GREET_TONE] = g.tone; it[GREET_TIME] = g.time; it[GREET_CASUAL] = g.casual; it[GREET_NOTES] = g.notes
        it[GREET_EVERY] = g.everySec; it[GREET_AVATAR] = g.avatar; it[GREET_SUB] = g.sub
        it[GREET_TEXT] = g.textSize; it[GREET_PIC] = g.picSize
    }
    /** Whether the app opens in the box you were last in, instead of the main page. On by default. */
    val reopenLastBox: StateFlow<Boolean> = ds.data.map { it[REOPEN_LAST_BOX] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setReopenLastBox(b: Boolean) = edit { it[REOPEN_LAST_BOX] = b }
    /** A #word typed in a scrap becomes one of its tags (see Hashtags.kt). On by default. */
    val hashtagTags: StateFlow<Boolean> = ds.data.map { it[HASHTAG_TAGS] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setHashtagTags(b: Boolean) = edit { it[HASHTAG_TAGS] = b }
    /** After a paste the editor offers a tidier form (see SmartPaste.kt). It never changes anything by itself. On by default. */
    val pasteOffers: StateFlow<Boolean> = ds.data.map { it[PASTE_OFFERS] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setPasteOffers(b: Boolean) = edit { it[PASTE_OFFERS] = b }
    /** Photos in the editor are shown as normal pictures instead of taped polaroids. Off by default (polaroids). */
    val plainPhotos: StateFlow<Boolean> = ds.data.map { it[PLAIN_PHOTOS] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setPlainPhotos(b: Boolean) = edit { it[PLAIN_PHOTOS] = b }
    /** Whether a scrap's Connected section suggests links: titles written in the text that could be linked, and scraps that share its tags. Real links always show. */
    val linkSuggestions: StateFlow<Boolean> = ds.data.map { it[LINK_SUGGEST] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setLinkSuggestions(b: Boolean) = edit { it[LINK_SUGGEST] = b }
    /** Whether a scrap's Connected section is unfolded. Closed until you open it; after that it stays the way you last left it, for every scrap. */
    val connectionsOpen: StateFlow<Boolean> = ds.data.map { it[CONNECTIONS_OPEN] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setConnectionsOpen(b: Boolean) = edit { it[CONNECTIONS_OPEN] = b }
    /** Whether the editor header shows "Saved" for a moment after each save. On by default; saving itself never depends on it. */
    val showSaved: StateFlow<Boolean> = ds.data.map { it[SHOW_SAVED] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowSaved(b: Boolean) = edit { it[SHOW_SAVED] = b }
    /**
     * Whether the editor raises the keyboard by itself: when you come back to a scrap you left with the keyboard up, and when you open it with Edit (or Duplicate)
     * from the reading page. On by default. Tapping the text to write always raises it, whatever this says.
     */
    val autoKeyboard: StateFlow<Boolean> = ds.data.map { it[AUTO_KEYBOARD] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setAutoKeyboard(b: Boolean) = edit { it[AUTO_KEYBOARD] = b }

    // Where the accent color shows in a scrap's text (see TextColors). List marks: normal text color unless switched on. Links and #hashtags: accent unless switched off.
    val marksAccent: StateFlow<Boolean> = ds.data.map { it[MARKS_ACCENT] ?: false }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setMarksAccent(b: Boolean) = edit { it[MARKS_ACCENT] = b }
    val linksAccent: StateFlow<Boolean> = ds.data.map { it[LINKS_ACCENT] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setLinksAccent(b: Boolean) = edit { it[LINKS_ACCENT] = b }
    val hashtagsAccent: StateFlow<Boolean> = ds.data.map { it[HASHTAGS_ACCENT] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setHashtagsAccent(b: Boolean) = edit { it[HASHTAGS_ACCENT] = b }
    suspend fun readReopenLastBox(): Boolean = ds.data.first()[REOPEN_LAST_BOX] ?: true
    /** The box that was open when the app was last used. "" means the main page (or All scraps, Pinned and Recent, which are not boxes). */
    suspend fun readLastBox(): String = ds.data.first()[LAST_BOX] ?: ""
    fun setLastBox(name: String) = edit { it[LAST_BOX] = name }
    /** The boxes to open, outermost first, to land in `name` with the same back stack as if you had tapped your way there. Empty if the box is gone. */
    suspend fun boxPath(name: String): List<String> {
        if (name == "Inbox") return if (ds.data.first()[INBOX_HIDDEN] ?: false) emptyList() else listOf("Inbox")
        val all = dao.shelves().first()
        if (all.none { it.name == name }) return emptyList()
        if (!hiddenUnlocked.value && name in hiddenNames.value) return emptyList()
        val path = ArrayList<String>(); var cur = name
        while (cur.isNotBlank() && path.size < 20 && cur !in path) { path.add(0, cur); cur = all.firstOrNull { it.name == cur }?.parent ?: "" }
        return path
    }
    fun setAccent(i: Int) = edit { it[ACC] = i }
    /** The app accent color of your own (0xRRGGBB), or null while one of the ready-made accents is in use. */
    val accentCustom: StateFlow<Int?> = ds.data.map { customAccentOf(it) }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    fun setAccentCustom(rgb: Int) = edit { it[ACC] = -1; it[ACC_RGB] = rgb and 0xFFFFFF }
    private fun customAccentOf(p: Preferences): Int? = if ((p[ACC] ?: 0) < 0) p[ACC_RGB] else null
    /** Which ready-made accent the launcher icon should take. A color of your own gets the icon of the ready-made accent closest to it. */
    private fun iconIndexOf(p: Preferences): Int =
        customAccentOf(p)?.let { CustomColors.nearest(it, Themes.map { t -> t.acc.toArgb() and 0xFFFFFF }) } ?: (p[ACC] ?: 0).coerceIn(Themes.indices)
    /** Whether the launcher icon takes the accent color. On by default. When it is off the default (Coral) icon stays. */
    val iconFollowsAccent: StateFlow<Boolean> = ds.data.map { it[ICON_FOLLOWS] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setIconFollowsAccent(b: Boolean) = edit { it[ICON_FOLLOWS] = b }
    /** Makes the launcher icon match the saved settings. Called when the app leaves the screen, so the icon never flips under your finger. */
    fun syncIcon() {
        viewModelScope.launch {
            val p = ds.data.first()
            AppIcon.apply(getApplication<Application>(), if (p[ICON_FOLLOWS] ?: true) iconIndexOf(p) else 0)
        }
    }
    fun setSerif(b: Boolean) = edit { it[SERIF] = b }
    fun setRadius(dp: Int) = edit { it[RAD] = dp }

    fun addExamples() {
        viewModelScope.launch {
            listOf(Shelf("Ideas", "Half-formed things worth keeping.", 0), Shelf("Memories", "", 1), Shelf("Movies", "", 2),
                Shelf("References", "", 3), Shelf("Quotes", "Lines I want to remember.", 4))
                .filter { s -> rawShelves.value.none { it.name == s.name } }.forEach { dao.upsertShelf(it) }   // never over a box that exists (a hidden one is not in [shelves])
            sample.forEach { dao.upsert(it.copy(id = 0)) }
        }
    }

    /**
     * Saves a box. Its key (name) never changes, so renaming (the title) or moving it (the parent) leaves every scrap and inner box where it is.
     * A box can never be put inside itself or inside a box that is inside it.
     */
    fun saveShelf(s: Shelf) {
        viewModelScope.launch {
            val all = dao.shelves().first()
            val ok = all.canMoveInto(s.name, s.parent)
            dao.upsertShelf(if (ok) s else s.copy(parent = all.firstOrNull { it.name == s.name }?.parent ?: ""))
        }
    }
    /** Deletes the box and keeps its scraps: they move to Inbox (which reappears if it was hidden). Boxes inside it move up one level. */
    fun deleteShelf(name: String) {
        val hadScraps = items.value.any { it.collection == name }
        val up = shelves.value.firstOrNull { it.name == name }?.parent ?: ""
        viewModelScope.launch { dao.moveItems(name, "Inbox"); dao.moveShelves(name, up); dao.removeShelf(name) }
        if (hadScraps && inboxHidden.value) setInboxHidden(false)
    }
    /** Deletes the box, every box inside it, and moves every scrap in all of them to the Bin (restorable for BIN_DAYS). */
    fun deleteShelfAndScraps(name: String) {
        val names = listOf(name) + shelves.value.descendantsOf(name).map { it.name }
        // Hidden boxes inside it cannot be seen while locked, so they are not deleted: they move up to where the deleted box was.
        val up = shelves.value.firstOrNull { it.name == name }?.parent ?: ""
        viewModelScope.launch { val now = System.currentTimeMillis(); names.forEach { dao.binItemsIn(it, now); dao.moveShelves(it, up); dao.removeShelf(it) } }
    }
    /** Removes the Inbox box. With deleteScraps, the scraps in it go to the Bin too. */
    fun removeInbox(deleteScraps: Boolean) {
        viewModelScope.launch { if (deleteScraps) dao.binItemsIn("Inbox", System.currentTimeMillis()) }
        setInboxHidden(true)
    }

    /** Copies a picked photo into app storage so it stays available after the picker's temporary access ends. */
    fun importImage(uri: Uri, done: (String) -> Unit) {
        viewModelScope.launch { done(copyImage(uri)) }
    }
    private suspend fun copyImage(uri: Uri): String = withContext(Dispatchers.IO) {
        val ctx = getApplication<Application>()
        val f = File(ctx.filesDir, "img_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(8)}.jpg")
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        Uri.fromFile(f).toString()
    }

    /**
     * Adds things shared into the app to a scrap that already exists instead of making a new one: the text goes at the end, pictures join the
     * scrap's photos and files join its attachments. [firstImage] is a picture already copied into the app; [moreImages] are copied here.
     * done(false) means the scrap is gone (deleted meanwhile), and nothing was changed.
     */
    fun addSharedToScrap(id: Long, text: String, firstImage: String?, moreImages: List<Uri>, files: List<Attachment>, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val photos = listOfNotNull(firstImage) + moreImages.map { copyImage(it) }
            val cur = dao.byId(id)
            if (cur == null) { done(false); return@launch }
            val body = when { text.isBlank() -> cur.body; cur.body.isBlank() -> text; else -> cur.body.trimEnd() + "\n\n" + text }
            val allPhotos = cur.allImages() + photos
            saveNow(cur.copy(body = body, imageUri = allPhotos.firstOrNull(), images = allPhotos.drop(1).joinToString("\n"),
                files = (cur.attachments() + files).encodeAll(), savedAt = System.currentTimeMillis()))
            done(true)
        }
    }
    /**
     * Copies a picked or shared file into the app's own storage (so it stays after the picker's access ends) and tells what it is.
     * Each file gets a folder of its own, so it keeps its real name when it is opened or shared. Files over [MAX_ATTACHMENT_BYTES] are refused:
     * failed gets a short sentence to show, and nothing is left behind.
     */
    fun importFile(uri: Uri, failed: (String) -> Unit = {}, done: (Attachment) -> Unit) {
        viewModelScope.launch {
            var folder: File? = null; var error: String? = null   // the message is shown after the copy, back on the main thread
            val result: Attachment? = withContext(Dispatchers.IO) {
                try {
                    val ctx = getApplication<Application>()
                    var name: String? = null; var declared = -1L
                    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = c.getColumnIndex(OpenableColumns.SIZE)
                            if (ni >= 0) name = c.getString(ni)
                            if (si >= 0 && !c.isNull(si)) declared = c.getLong(si)
                        }
                    }
                    if (declared > MAX_ATTACHMENT_BYTES) { error = "That file is bigger than ${formatSize(MAX_ATTACHMENT_BYTES)}, so it was not attached."; return@withContext null }
                    val display = cleanDisplayName(name ?: uri.lastPathSegment)
                    val dir = File(File(ctx.filesDir, "attachments"), "${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(8)}")
                    dir.mkdirs(); folder = dir
                    val target = File(dir, diskName(display))
                    val input = ctx.contentResolver.openInputStream(uri)
                    if (input == null) { dir.deleteRecursively(); error = "Could not read that file."; return@withContext null }
                    var total = 0L; var tooBig = false
                    input.use { i -> target.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            total += n
                            if (total > MAX_ATTACHMENT_BYTES) { tooBig = true; break }
                            o.write(buf, 0, n)
                        }
                    } }
                    if (tooBig) { dir.deleteRecursively(); error = "That file is bigger than ${formatSize(MAX_ATTACHMENT_BYTES)}, so it was not attached."; return@withContext null }
                    val ext = target.extension.lowercase()
                    val byName = if (ext.isEmpty()) null else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                    val mime = ctx.contentResolver.getType(uri)?.takeIf { it != "application/octet-stream" } ?: byName ?: "application/octet-stream"
                    Attachment(Uri.fromFile(target).toString(), display, target.length(), mime)
                } catch (e: Exception) {
                    folder?.deleteRecursively(); error = "Could not attach that file."; null
                }
            }
            if (result != null) done(result) else error?.let { failed(it) }
        }
    }
    private fun itemJson(i: Item, imgs: List<String>, cover: String? = null, files: org.json.JSONArray = org.json.JSONArray()) = org.json.JSONObject().apply {
        put("title", i.title); put("body", i.body); put("kind", i.kind.name); put("collection", i.collection)
        put("tags", org.json.JSONArray(i.tags)); put("layout", i.layout.name); put("color", i.color); put("pinned", i.pinned)
        put("savedAt", i.savedAt); put("createdAt", i.createdAt); put("icon", i.icon); put("font", i.font); put("density", i.density); put("showMeta", i.showMeta)
        put("imageUri", imgs.firstOrNull() ?: org.json.JSONObject.NULL); put("images", org.json.JSONArray(imgs.drop(1))); put("canvas", i.canvas); put("source", i.source); put("accent", i.accent); put("cover", cover ?: org.json.JSONObject.NULL)
        put("files", files); put("uid", i.uid); put("blocks", i.blocks)
    }

    /** Zip with archive.json and every photo. Returns the file to share. */
    suspend fun buildBackup(): File = withContext(Dispatchers.IO) {
        val ctx = getApplication<Application>()
        val out = File(File(ctx.cacheDir, "backups").apply { mkdirs() }, "scrapbook-backup.zip")
        val arr = org.json.JSONArray(); val imgs = mutableSetOf<File>(); val attached = mutableSetOf<File>()
        rawItems.value.forEach { i ->
            val fs = i.allImages().map { File(Uri.parse(it).path ?: "") }.filter { it.exists() }
            imgs += fs
            val cf = i.cover?.let { File(Uri.parse(it).path ?: "") }?.takeIf { it.exists() }
            if (cf != null) imgs += cf
            val fj = org.json.JSONArray()
            i.attachments().forEach { a ->
                val f = a.file(); if (!f.exists()) return@forEach
                attached += f
                fj.put(org.json.JSONObject().apply { put("path", "files/${f.parentFile?.name}/${f.name}"); put("name", a.name); put("size", a.size); put("mime", a.mime) })
            }
            arr.put(itemJson(i, fs.map { "images/${it.name}" }, cf?.let { "images/${it.name}" }, fj))
        }
        val sarr = org.json.JSONArray()
        rawShelves.value.forEach { s ->
            val f = s.coverUri?.let { File(Uri.parse(it).path ?: "") }?.takeIf { it.exists() }
            if (f != null) imgs += f
            sarr.put(org.json.JSONObject().apply {
                put("name", s.name); put("description", s.description); put("color", s.color); put("parent", s.parent); put("title", s.title); put("hidden", s.hidden)
                put("coverUri", f?.let { "images/${it.name}" } ?: org.json.JSONObject.NULL)
            })
        }
        // The account (see Account.kt) travels too, so a new phone gets the name, birthday and picture back.
        val acc = account.value
        val avatarFile = acc.avatarUri?.let { File(Uri.parse(it).path ?: "") }?.takeIf { it.exists() }
        val accountJson = org.json.JSONObject().apply {
            put("name", acc.name); put("nickname", acc.nickname); put("about", acc.about); put("pronouns", acc.pronouns)
            put("birthMonth", acc.birthMonth); put("birthDay", acc.birthDay); put("avatarColor", acc.avatarColor)
            put("avatar", avatarFile?.let { "avatar/${it.name}" } ?: org.json.JSONObject.NULL)
        }
        // The menu (see MenuLayout.kt, MenuStyle.kt) travels too: its look, what it holds and the setups you saved.
        val menuText = MenuConfig(menuLayout.value, menuStyle.value).encode(); val menuPresetsText = MenuPresets.encode(menuPresets.value)
        // The Home skins (see HomeSkins.kt) travel too: every skin, with the one worn as Home is now, so a new phone gets the look of Home back.
        val homeSkinsText = homeSkins.value?.encode()
        ZipOutputStream(out.outputStream()).use { z ->
            z.putNextEntry(ZipEntry("archive.json")); z.write(arr.toString(2).toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("collections.json")); z.write(sarr.toString(2).toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("account.json")); z.write(accountJson.toString(2).toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("menu.txt")); z.write(menuText.toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("menu-presets.txt")); z.write(menuPresetsText.toByteArray()); z.closeEntry()
            homeSkinsText?.let { t -> z.putNextEntry(ZipEntry("home-skins.txt")); z.write(t.toByteArray()); z.closeEntry() }
            avatarFile?.let { f -> z.putNextEntry(ZipEntry("avatar/${f.name}")); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
            imgs.forEach { f -> z.putNextEntry(ZipEntry("images/${f.name}")); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
            attached.forEach { f -> z.putNextEntry(ZipEntry("files/${f.parentFile?.name}/${f.name}")); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
        }
        out
    }

    /** Adds items from a backup zip, skipping ones already here (same title and date). done(-1) means unreadable. */
    fun restoreBackup(uri: Uri, done: (Int) -> Unit) {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) {
                try {
                    val ctx = getApplication<Application>(); val stamp = System.currentTimeMillis(); var json: String? = null; var shelvesJson: String? = null; var accountJson: String? = null; var menuText: String? = null; var menuPresetsText: String? = null; var homeSkinsText: String? = null; var avatarTmp: File? = null
                    ZipInputStream(ctx.contentResolver.openInputStream(uri)).use { z ->
                        var e = z.nextEntry
                        while (e != null) {
                            if (e.name == "archive.json") json = z.readBytes().toString(Charsets.UTF_8)
                            else if (e.name == "collections.json") shelvesJson = z.readBytes().toString(Charsets.UTF_8)
                            else if (e.name == "account.json") accountJson = z.readBytes().toString(Charsets.UTF_8)
                            else if (e.name == "menu.txt") menuText = z.readBytes().toString(Charsets.UTF_8)
                            else if (e.name == "menu-presets.txt") menuPresetsText = z.readBytes().toString(Charsets.UTF_8)
                            else if (e.name == "home-skins.txt") homeSkinsText = z.readBytes().toString(Charsets.UTF_8)
                            else if (e.name.startsWith("avatar/") && !e.isDirectory && avatarTmp == null) {
                                val f = File(ctx.filesDir, "${Avatar.PREFIX}${stamp}r.jpg"); f.outputStream().use { o -> z.copyTo(o) }; avatarTmp = f
                            }
                            else if (e.name.startsWith("images/") && !e.isDirectory)
                                File(ctx.filesDir, "imp_${stamp}_" + File(e.name).name).outputStream().use { o -> z.copyTo(o) }
                            else if (e.name.startsWith("files/") && !e.isDirectory) {
                                // files/<folder>/<name>: each file comes back into a folder of its own, under a new name so nothing here is overwritten.
                                val parts = e.name.split('/')
                                if (parts.size == 3 && parts.all { it.isNotEmpty() && it != ".." && it != "." }) {
                                    val d = File(File(ctx.filesDir, "attachments"), "${stamp}r_${File(parts[1]).name}").apply { mkdirs() }
                                    File(d, File(parts[2]).name).outputStream().use { o -> z.copyTo(o) }
                                }
                            }
                            e = z.nextEntry
                        }
                    }
                    shelvesJson?.let { sj ->
                        val a = org.json.JSONArray(sj); val have = rawShelves.value.map { it.name }.toSet()
                        for (k in 0 until a.length()) {
                            val o = a.getJSONObject(k); val n = o.getString("name"); if (n in have) continue
                            val cv = o.optString("coverUri", "").takeIf { it.startsWith("images/") }
                                ?.let { Uri.fromFile(File(ctx.filesDir, "imp_${stamp}_" + File(it).name)).toString() }
                            dao.upsertShelf(Shelf(n, o.optString("description"), o.optInt("color"), cv, o.optString("parent", ""), o.optString("title", ""), o.optBoolean("hidden")))
                        }
                    }
                    val arr = org.json.JSONArray(json ?: return@withContext -1)
                    val have = rawItems.value.map { it.title to it.savedAt }.toSet(); var added = 0; var toInbox = false
                    // A restored scrap keeps the permanent id it had, so links to it still work; if that id is already taken (or an old backup has none) it gets a new one.
                    val uids = rawItems.value.map { it.uid.lowercase() }.toMutableSet()
                    fun restoredUid(raw: String): String { val u = raw.trim().lowercase(); return if (u.isNotEmpty() && uids.add(u)) u else newUid().also { uids.add(it) } }
                    for (k in 0 until arr.length()) {
                        val o = arr.getJSONObject(k); val at = o.getLong("savedAt")
                        if ((o.getString("title") to at) in have) continue
                        fun imp(p: String) = Uri.fromFile(File(ctx.filesDir, "imp_${stamp}_" + File(p).name)).toString()
                        val first = o.optString("imageUri", "").takeIf { it.startsWith("images/") }?.let { imp(it) }
                        val cov = o.optString("cover", "").takeIf { it.startsWith("images/") }?.let { imp(it) }
                        val extra = o.optJSONArray("images")?.let { a -> (0 until a.length()).map { imp(a.getString(it)) } } ?: emptyList()
                        val tags = o.optJSONArray("tags")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                        val restoredFiles = o.optJSONArray("files")?.let { a ->
                            (0 until a.length()).mapNotNull { n ->
                                val fo = a.getJSONObject(n); val parts = fo.optString("path", "").split('/')
                                if (parts.size != 3) return@mapNotNull null
                                val f = File(File(File(ctx.filesDir, "attachments"), "${stamp}r_${File(parts[1]).name}"), File(parts[2]).name)
                                if (!f.exists()) null else Attachment(Uri.fromFile(f).toString(), cleanDisplayName(fo.optString("name")), f.length(), fo.optString("mime", "application/octet-stream"))
                            }
                        } ?: emptyList()
                        dao.upsert(Item(uid = restoredUid(o.optString("uid")), title = o.getString("title"), body = o.optString("body"),
                            kind = runCatching { Kind.valueOf(o.getString("kind")) }.getOrDefault(Kind.Note),
                            collection = o.optString("collection", "Inbox").also { if (it == INBOX_BOX) toInbox = true }, tags = tags,
                            layout = runCatching { Layout.valueOf(o.getString("layout")) }.getOrDefault(Layout.Classic),
                            color = o.optInt("color"), pinned = o.optBoolean("pinned"), savedAt = at, createdAt = o.optLong("createdAt", at), icon = o.optString("icon", ""), font = o.optInt("font"),
                            density = o.optInt("density", 1), showMeta = o.optBoolean("showMeta", true), imageUri = first, images = extra.joinToString("\n"), canvas = o.optString("canvas"), source = o.optString("source"), accent = o.optInt("accent"), cover = cov, files = restoredFiles.encodeAll(), blocks = o.optString("blocks", "")))
                        added++
                    }
                    // The account only fills in what this phone does not have yet: a restore never overwrites a name or a picture that is already set.
                    accountJson?.let { aj ->
                        val o = org.json.JSONObject(aj); val cur = account.value
                        var keepAvatar = false
                        ds.edit { p ->
                            fun fill(k: Preferences.Key<String>, v: String) { if (p[k].isNullOrBlank() && v.isNotBlank()) p[k] = v }
                            fill(ACCOUNT_NAME, Account.clean(o.optString("name"), Account.MAX_NAME)); fill(ACCOUNT_NICK, Account.clean(o.optString("nickname"), Account.MAX_NAME))
                            fill(ACCOUNT_ABOUT, Account.cleanAbout(o.optString("about"))); fill(ACCOUNT_PRONOUNS, Account.clean(o.optString("pronouns"), Account.MAX_PRONOUNS))
                            val bm = o.optInt("birthMonth"); val bd = o.optInt("birthDay")
                            if (!cur.hasBirthday && Account.validBirthday(bm, bd)) { p[ACCOUNT_BMONTH] = bm; p[ACCOUNT_BDAY] = bd }
                            val ac = o.optInt("avatarColor", -1)
                            if (cur.avatarColor == -1 && ac in AVATAR_COLORS.indices) p[ACCOUNT_AVATAR_COLOR] = ac
                            val tmp = avatarTmp
                            if (tmp != null && p[ACCOUNT_AVATAR].isNullOrEmpty()) { p[ACCOUNT_AVATAR] = Uri.fromFile(tmp).toString(); keepAvatar = true }
                        }
                        if (!keepAvatar) avatarTmp?.delete()
                    }
                    // The menu only fills in what this phone has not customized yet; saved setups are added next to the ones already here.
                    menuText?.let { t ->
                        val cfg = MenuConfig.decode(t)
                        if (cfg != null) ds.edit { p -> if (p[MENU_ORDER] == null && p[MENU_SKIN] == null) { writeMenuLayout(p, cfg.layout); writeMenuStyle(p, cfg.style) } }
                    }
                    menuPresetsText?.let { t ->
                        val theirs = MenuPresets.decode(t)
                        if (theirs.isNotEmpty()) ds.edit { p ->
                            val mine = MenuPresets.decode(p[MENU_PRESETS])
                            p[MENU_PRESETS] = MenuPresets.encode((mine + theirs.filter { x -> mine.none { it.name.equals(x.name, true) } }).take(MenuPresets.MAX_SAVED))
                        }
                    }
                    // The Home skins: a phone whose Home is still as new takes the worn skin as its Home; a phone that has been customized only gets the skins it does not have yet (by name), added next to its own.
                    homeSkinsText?.let { t ->
                        val theirs = HomeSkins.decode(t)
                        ds.edit { p ->
                            val fresh = p[HOME_SKINS] == null && homeSnapshot(p).isEmpty()
                            if (fresh) { p[HOME_SKINS] = theirs.encode(); p.applyHomeSnapshot(theirs.current.values) }
                            else p[HOME_SKINS] = HomeSkins.merged(homeSkinsOf(p), theirs).encode()
                        }
                    }
                    if (toInbox && inboxHidden.value) setInboxHidden(false)
                    added
                } catch (e: Exception) { -1 }
            }
            done(n)
        }
    }

    /** Best-effort page title for a shared link. Calls done only when one is found. */
    fun fetchTitle(url: String, done: (String) -> Unit) {
        viewModelScope.launch {
            val t = withContext(Dispatchers.IO) {
                runCatching {
                    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 4000; c.readTimeout = 4000; c.setRequestProperty("User-Agent", "Mozilla/5.0")
                    // A single read() can return early, so fill the buffer (the <title> sits near the top of the page).
                    val html = try {
                        c.inputStream.use { s ->
                            val buf = ByteArray(65536); var n = 0
                            while (n < buf.size) { val r = s.read(buf, n, buf.size - n); if (r < 0) break; n += r }
                            String(buf, 0, n, Charsets.UTF_8)
                        }
                    } finally { c.disconnect() }
                    extractTitle(html)
                }.getOrNull()
            }
            if (t != null) done(t)
        }
    }

    private class HttpResult(val finalUrl: String, val contentType: String?, val bytes: ByteArray)

    /**
     * A plain GET that follows up to five redirects itself (HttpURLConnection will not follow one from http to https). Only web addresses are fetched,
     * and with [secureOnly] only https ones. At most [maxBytes] are read: a page is just cut there, but anything bigger than that is refused when
     * [truncate] is false (a photo that is too big is no use). Null for any failure.
     */
    private fun httpGet(start: String, maxBytes: Int, secureOnly: Boolean, truncate: Boolean): HttpResult? {
        var current = start
        repeat(5) {
            val u = java.net.URL(current)
            if (u.protocol != "https" && (secureOnly || u.protocol != "http")) return null
            val c = u.openConnection() as java.net.HttpURLConnection
            try {
                c.connectTimeout = 5000; c.readTimeout = 5000; c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "Mozilla/5.0"); c.setRequestProperty("Accept-Language", "en")
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: return null
                    current = java.net.URI(current).resolve(loc.trim()).toString(); return@repeat
                }
                if (code != 200) return null
                if (!truncate && c.contentLengthLong > maxBytes) return null
                val out = java.io.ByteArrayOutputStream(); val tmp = ByteArray(16384); var total = 0
                c.inputStream.use { s ->
                    while (true) {
                        val r = s.read(tmp); if (r < 0) break
                        if (total + r > maxBytes) { if (truncate) { out.write(tmp, 0, maxBytes - total); total = maxBytes; break } else return null }
                        out.write(tmp, 0, r); total += r
                    }
                }
                return HttpResult(current, c.contentType, out.toByteArray())
            } finally { c.disconnect() }
        }
        return null
    }

    /** Copies a link's preview photo into app storage when it is a real picture of a sensible size on a secure address; null otherwise. */
    private fun downloadPreviewImage(imageUrl: String): String? {
        val r = httpGet(imageUrl, 3_000_000, secureOnly = true, truncate = false) ?: return null
        if (r.contentType?.startsWith("image/", ignoreCase = true) != true) return null
        val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeByteArray(r.bytes, 0, r.bytes.size, opts)
        if (opts.outWidth < 100 || opts.outHeight < 100) return null   // an icon or a tracking pixel, not a photo
        val f = File(getApplication<Application>().filesDir, "img_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(8)}.jpg")
        f.writeBytes(r.bytes)
        return Uri.fromFile(f).toString()
    }

    /**
     * What a link card is made of: the page's title, description and site name, and a copy of its photo in app storage when it has a usable one.
     * done gets (null, null) when the page could not be read. This only runs when the person asked for the card.
     */
    fun fetchLinkPreview(url: String, done: (LinkPreview?, String?) -> Unit) {
        viewModelScope.launch {
            val out = withContext(Dispatchers.IO) {
                runCatching {
                    val page = httpGet(url, 262144, secureOnly = false, truncate = true) ?: return@runCatching null
                    val charset = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(page.contentType.orEmpty())?.groupValues?.get(1)
                        ?.let { runCatching { java.nio.charset.Charset.forName(it) }.getOrNull() } ?: Charsets.UTF_8
                    val preview = parseLinkPreview(String(page.bytes, charset), page.finalUrl)
                    preview to preview.imageUrl?.let { runCatching { downloadPreviewImage(it) }.getOrNull() }
                }.getOrNull()
            }
            done(out?.first, out?.second)
        }
    }

    /** Imports plain-text and Markdown files as notes in Inbox. A leading "# Title" line becomes the title. */
    fun importTexts(uris: List<Uri>, done: (Int) -> Unit) {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) {
                val ctx = getApplication<Application>(); var added = 0
                for (u in uris) {
                    try {
                        val text = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: continue
                        val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                            val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                            if (c.moveToFirst() && i >= 0) c.getString(i) else null
                        }?.substringBeforeLast('.')
                        val lines = text.lines(); val h = lines.indexOfFirst { it.startsWith("# ") }
                        val title = (if (h >= 0) lines[h].drop(2).trim() else name ?: "Imported scrap").take(80)
                        val body = (if (h >= 0) lines.filterIndexed { i, _ -> i != h } else lines).joinToString("\n").trim()
                        dao.upsert(Item(title = title, body = body, kind = Kind.Note, collection = "Inbox")); added++
                    } catch (e: Exception) { }
                }
                added
            }
            if (n > 0 && inboxHidden.value) setInboxHidden(false)
            done(n)
        }
    }

    fun save(item: Item) { viewModelScope.launch { saveNow(item) } }
    /**
     * Every save goes through here. Two things happen besides writing: an ordinary save never changes whether a scrap is in the Bin (a stale copy of a
     * deleted scrap cannot bring it back; only restoreFromBin can), and the text it replaces may be put aside as a version first (see shouldSnapshot).
     */
    suspend fun saveNow(item: Item): Long {
        val safe = keepBinState(item)
        val before = if (safe.id == 0L) null else dao.byIdAny(safe.id)?.collection
        snapshotBeforeSave(safe)
        val id = dao.upsert(safe)
        // A scrap arriving in a hidden Inbox (new, or moved in) would be unreachable, so Inbox comes back (see revealsInbox).
        if (safe.deletedAt == 0L && revealsInbox(inboxHidden.value, before, safe.collection)) setInboxHidden(false)
        return id
    }
    private suspend fun keepBinState(item: Item): Item {
        if (item.id == 0L) return item
        val cur = dao.byIdAny(item.id) ?: return item
        return if (cur.deletedAt == item.deletedAt) item else item.copy(deletedAt = cur.deletedAt)
    }
    private suspend fun snapshotBeforeSave(next: Item) {
        if (next.id == 0L) return
        val prev = dao.byIdAny(next.id) ?: return
        if (prev.title == next.title && prev.body == next.body) return   // the common case while typing in a pause: nothing to look at
        val now = System.currentTimeMillis()
        if (!shouldSnapshot(prev, next, dao.latestVersion(prev.id), now)) return
        dao.addVersion(ItemVersion(itemId = prev.id, takenAt = now, savedAt = prev.savedAt, title = prev.title, body = prev.body))
        dao.trimVersions(prev.id, MAX_VERSIONS)
    }
    /** The earlier versions of one scrap, newest first. */
    fun versionsOf(id: Long): Flow<List<ItemVersion>> = dao.versionsOf(id)
    /** Puts the scrap's stored text aside as a version right now (unless we already hold exactly it), so bringing back an older version can itself be taken back. */
    suspend fun keepVersion(id: Long) {
        val cur = dao.byIdAny(id) ?: return
        if (cur.title.isBlank() && cur.body.isBlank()) return
        val last = dao.latestVersion(id)
        if (last != null && last.title == cur.title && last.body == cur.body) return
        dao.addVersion(ItemVersion(itemId = id, takenAt = System.currentTimeMillis(), savedAt = cur.savedAt, title = cur.title, body = cur.body))
        dao.trimVersions(id, MAX_VERSIONS)
    }
    /** Reads one scrap straight from the database. The in-memory list is empty for a moment after the app starts, so the editor cannot rely on it. */
    suspend fun load(id: Long): Item? = dao.byId(id)
    fun duplicate(item: Item, done: (Long) -> Unit = {}) {
        viewModelScope.launch { done(dao.upsert(item.copy(id = 0, uid = newUid(), title = item.title + " copy", pinned = false, savedAt = System.currentTimeMillis(), createdAt = System.currentTimeMillis()))) }
    }

    /** The last deleted scrap, so the Undo snackbar knows what to bring back. Every deleted scrap also waits in the Bin (see bin). */
    val deleted = MutableStateFlow<Item?>(null)
    /** Moves a scrap to the Bin. It stays there for BIN_DAYS, then goes for good. */
    fun delete(item: Item) { viewModelScope.launch { dao.markDeleted(item.id, System.currentTimeMillis()); deleted.value = item } }
    fun undoDelete() { deleted.value?.let { restoreFromBin(it.id) }; deleted.value = null }
    fun clearDeleted() { deleted.value = null }
    /** Takes a scrap out of the Bin. If its box was deleted in the meantime it goes to Inbox, which comes back if it was hidden. */
    fun restoreFromBin(id: Long) {
        viewModelScope.launch {
            val row = dao.byIdAny(id) ?: return@launch
            val boxStillThere = row.collection.isNotBlank() && (row.collection == "Inbox" || dao.shelves().first().any { it.name == row.collection })
            val box = if (boxStillThere) row.collection else "Inbox"
            dao.restoreTo(id, box)
            if (box == "Inbox" && inboxHidden.value) setInboxHidden(false)
        }
    }
    /** Deletes one scrap from the Bin for good, with its versions and any photos nothing else uses. */
    fun deleteForever(id: Long) { viewModelScope.launch { dao.purge(id); dao.dropOrphanVersions(); sweepImages() } }
    fun emptyBin() { viewModelScope.launch { dao.purgeAll(); dao.dropOrphanVersions(); sweepImages() } }
    fun togglePin(item: Item) = save(item.copy(pinned = !item.pinned))

    /** A scrapbook://scrap/<id> link that arrived and has not been opened yet (the screen picks it up and opens that scrap). */
    val linkRequest = MutableStateFlow<String?>(null)

    // [binder hook 2] Working with Binder (rules in Binder.kt, Android side in ui/BinderBridge.kt).
    /** The scrap Binder's "Write about this" has just made: the screen picks it up and opens it in the editor. */
    val editRequest = MutableStateFlow<Long?>(null)

    /**
     * Binder's "Write about this": makes the scrap with exactly the permanent id [uid] Binder chose (so Binder already holds the link), in [box] when
     * you have a box of that name and in the Inbox otherwise, with [cover] as its picture, and asks to open it in the editor. If a scrap with that id
     * exists already it is opened instead of making a second one.
     */
    fun createFromBinder(title: String, body: String, uid: String, box: String, cover: Uri?) {
        viewModelScope.launch {
            val id = uid.lowercase().takeIf { Regex("[0-9a-f]{32}").matches(it) } ?: newUid()
            val existing = dao.byUid(id)
            if (existing != null) { linkRequest.value = id; return@launch }
            val boxName = if (box.isNotBlank() && dao.shelves().first().any { it.name == box }) box else "Inbox"
            val picture = cover?.let { runCatching { copyImage(it) }.getOrNull() }
            editRequest.value = saveNow(Item(title = title.ifBlank { "Untitled" }, body = body, kind = Kind.Note, collection = boxName, imageUri = picture, uid = id))
        }
    }

    /** Binder came back after "Add to Binder": adds a link to the Binder item at the end of the scrap, once. done(true) when the scrap was changed. */
    fun linkBack(uid: String, binderItem: String, title: String, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val scrap = dao.byUid(uid)
            if (scrap == null) { done(false); return@launch }
            val next = withBinderLink(scrap.body, title, binderItem)
            if (next == scrap.body) { done(false); return@launch }
            saveNow(scrap.copy(body = next, savedAt = System.currentTimeMillis())); done(true)
        }
    }

    // The places opened last (see Recents.kt), for the quick switcher. Kept in the phone's small settings storage, so it needs no database change.
    private val recentPrefs = app.getSharedPreferences("recents", android.content.Context.MODE_PRIVATE)
    val recentPlaces = MutableStateFlow(Recents.decode(recentPrefs.getString("list", null)))
    /** True while the quick switcher is open on top of the current screen (the menu's "Go to…"). */
    val switcherOpen = MutableStateFlow(false)
    /** Remember that a scrap ([Recents.scrap]) or a box ([Recents.box]) was just opened. */
    fun opened(key: String) {
        val now = Recents.touch(recentPlaces.value, key)
        if (now !== recentPlaces.value) { recentPlaces.value = now; recentPrefs.edit().putString("list", Recents.encode(now)).apply() }
    }
    suspend fun findByUid(uid: String): Item? = dao.byUid(uid)

    // ---------------- Privacy: the PIN, app lock, fingerprint and hidden boxes. The rules are in Privacy.kt, the screens in ui/LockScreen.kt.
    /** False until it is known whether the app starts locked (a few milliseconds), so nothing shows before then. */
    val lockChecked = MutableStateFlow(false)
    /** True while the lock screen covers the app. */
    val locked = MutableStateFlow(false)
    /** The PIN screen on top of the app, if one is open (set a PIN, or confirm it before changing something). */
    val pinFlow = MutableStateFlow<PinFlow?>(null)
    /** Counts up each time the app should return to the main page (hidden boxes lock, or the box on screen was just hidden). */
    val homeRequest = MutableStateFlow(0)
    private var leftAt: Long? = null
    init {
        viewModelScope.launch {
            val d = app.dataStore.data.first()
            locked.value = (d[LOCK_ON] ?: false) && !d[PIN_RECORD].isNullOrEmpty()
            lockChecked.value = true
        }
    }
    val lockOn: StateFlow<Boolean> = ds.data.map { (it[LOCK_ON] ?: false) && !it[PIN_RECORD].isNullOrEmpty() }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val biometricOn: StateFlow<Boolean> = ds.data.map { (it[BIO_ON] ?: false) && !it[PIN_RECORD].isNullOrEmpty() }.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val lockDelay: StateFlow<Int> = ds.data.map { (it[LOCK_DELAY] ?: LOCK_DELAY_DEFAULT).coerceIn(0, LOCK_DELAYS_MS.lastIndex) }.stateIn(viewModelScope, SharingStarted.Eagerly, LOCK_DELAY_DEFAULT)
    /** Hide the app in Android's recent apps list and block screenshots (only while a PIN is set). */
    val hideRecents: StateFlow<Boolean> = ds.data.map { it[HIDE_RECENTS] ?: true }.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val pinDigits: StateFlow<Int> = ds.data.map { pinLength(it[PIN_RECORD]) ?: PIN_MIN }.stateIn(viewModelScope, SharingStarted.Eagerly, PIN_MIN)
    fun setLockOn(on: Boolean) = edit { it[LOCK_ON] = on }
    fun setBiometricOn(on: Boolean) = edit { it[BIO_ON] = on }
    fun setLockDelay(i: Int) = edit { it[LOCK_DELAY] = i.coerceIn(0, LOCK_DELAYS_MS.lastIndex) }
    fun setHideRecents(on: Boolean) = edit { it[HIDE_RECENTS] = on }

    /** Saves a new PIN (only a salted hash of it is kept), then runs [then]. */
    fun setPin(pin: String, then: () -> Unit) {
        viewModelScope.launch {
            val record = withContext(Dispatchers.Default) { makePinRecord(pin) }
            ds.edit { it[PIN_RECORD] = record; it[PIN_FAILS] = 0 }
            then()
        }
    }
    /** How long a PIN cannot be tried yet because of earlier wrong tries (kept on the phone, so restarting the app does not reset it). */
    suspend fun lockoutRemaining(): Long {
        val d = ds.data.first()
        return lockoutRemainingMs(d[PIN_FAILS] ?: 0, d[PIN_FAIL_AT] ?: 0L, System.currentTimeMillis())
    }
    suspend fun checkPin(pin: String): PinCheck {
        val d = ds.data.first(); val now = System.currentTimeMillis()
        val wait = lockoutRemainingMs(d[PIN_FAILS] ?: 0, d[PIN_FAIL_AT] ?: 0L, now)
        if (wait > 0) return PinCheck.Wait(wait)
        val record = d[PIN_RECORD] ?: return PinCheck.Wrong
        if (withContext(Dispatchers.Default) { checkPinRecord(pin, record) }) { ds.edit { it[PIN_FAILS] = 0 }; return PinCheck.Ok }
        val fails = (d[PIN_FAILS] ?: 0) + 1
        ds.edit { it[PIN_FAILS] = fails; it[PIN_FAIL_AT] = now }
        val next = lockoutRemainingMs(fails, now, now)
        return if (next > 0) PinCheck.Wait(next) else PinCheck.Wrong
    }
    /** Removes the PIN. Boxes stay hidden only while a PIN exists, so they are shown again. */
    fun removePin() {
        viewModelScope.launch {
            rawShelves.value.filter { it.hidden }.forEach { dao.upsertShelf(it.copy(hidden = false)) }
            ds.edit { it.remove(PIN_RECORD); it[LOCK_ON] = false; it[BIO_ON] = false; it[PIN_FAILS] = 0 }
            hiddenUnlocked.value = false; locked.value = false
        }
    }
    fun showHiddenBoxes() { hiddenUnlocked.value = true }
    /** Whether a box with this key exists, hidden or not. Boxes are saved by key, so saving over a hidden box's key would silently replace it. */
    fun boxExists(name: String) = rawShelves.value.any { it.name == name }
    /** A key for a new box that no box has, hidden ones included (the name you see can be the same as a hidden box's; the key never is). */
    fun newBoxKey(label: String) = rawShelves.value.newKey(label)
    /** Hides the hidden boxes again and goes back to the main page, so no hidden scrap stays open on screen. */
    fun lockHiddenNow() { if (hiddenUnlocked.value) { hiddenUnlocked.value = false; goHome() } }
    fun goHome() { homeRequest.value = homeRequest.value + 1 }
    /** Hide a box (and the boxes inside it), or show it again. Hiding takes you back to the main page, because the box you were in is gone. */
    fun setBoxHidden(name: String, hidden: Boolean) {
        viewModelScope.launch { rawShelves.value.firstOrNull { it.name == name }?.let { dao.upsertShelf(it.copy(hidden = hidden)) } }
        if (hidden) { hiddenUnlocked.value = false; goHome() }
    }
    /** The app was left for the home screen or another app (not a rotation). */
    fun appLeft() { leftAt = SystemClock.elapsedRealtime() }
    /** Back in the app: lock again if it was away at least as long as chosen in Settings. */
    fun appReturned() {
        val l = leftAt ?: return; leftAt = null
        val away = SystemClock.elapsedRealtime() - l
        if (shouldRelock(pinSet.value, away, LOCK_DELAYS_MS[lockDelay.value])) { if (lockOn.value) locked.value = true; lockHiddenNow() }
    }

    // Batch actions for the selection toolbar. Each changes many scraps with one query per 500, and each has a matching restore that Undo uses
    // to put every scrap back the way the snapshot [items] had it. None of them touches a scrap's edit date.
    private fun List<Item>.ids(): List<Long> = map { it.id }
    /** Moves the scraps into [box]. Moving into a hidden Inbox brings Inbox back, like any other arrival there (see revealsInbox). */
    fun moveAll(items: List<Item>, box: String) {
        viewModelScope.launch {
            items.ids().chunked(500).forEach { dao.moveByIds(it, box) }
            if (items.any { it.collection != box } && revealsInbox(inboxHidden.value, null, box)) setInboxHidden(false)
        }
    }
    fun restoreBoxes(items: List<Item>) {
        viewModelScope.launch { items.groupBy { it.collection }.forEach { (box, l) -> l.ids().chunked(500).forEach { dao.moveByIds(it, box) } } }
    }
    fun pinAll(items: List<Item>, pinned: Boolean) { viewModelScope.launch { items.ids().chunked(500).forEach { dao.pinByIds(it, pinned) } } }
    fun restorePins(items: List<Item>) {
        viewModelScope.launch { items.groupBy { it.pinned }.forEach { (p, l) -> l.ids().chunked(500).forEach { dao.pinByIds(it, p) } } }
    }
    /** Moves the scraps to the Bin (30 days, like a single delete). */
    fun deleteAll(items: List<Item>) {
        viewModelScope.launch { val now = System.currentTimeMillis(); items.ids().chunked(500).forEach { dao.markDeletedByIds(it, now) } }
    }
    fun undeleteAll(items: List<Item>) { items.forEach { restoreFromBin(it.id) } }
    /** Adds the tags a scrap does not have yet; the tags it has stay. */
    fun addTags(items: List<Item>, tags: List<String>) {
        viewModelScope.launch {
            items.forEach { i ->
                val cur = dao.byIdAny(i.id) ?: return@forEach
                val merged = mergeTags(cur.tags, tags)
                if (merged != cur.tags) dao.upsert(cur.copy(tags = merged))
            }
        }
    }
    /** Puts each scrap's tags back as the snapshot had them (only the tags: anything edited since stays). */
    fun restoreTags(items: List<Item>) {
        viewModelScope.launch { items.forEach { o -> dao.byIdAny(o.id)?.let { cur -> dao.upsert(cur.copy(tags = o.tags)) } } }
    }
    fun setLayout(id: Long, layout: Layout) { items.value.firstOrNull { it.id == id }?.let { save(it.copy(layout = layout)) } }

    companion object {
        val sample = listOf(
            Item(1, "An idea I had at 2 AM", "A town where every street is named after something forgotten.\n\n## To explore\n- [ ] Sketch the map\n- [x] Pick a name", Kind.Note, "Ideas", listOf("fiction"), color = 0, pinned = true),
            Item(2, "Collioure, July", "The harbour before anyone woke.", Kind.Image, "Memories", layout = Layout.Gallery, color = 1, pinned = true),
            Item(3, "Movie thoughts", "Slow films ask you to stay.", Kind.Note, "Movies", color = 2),
            Item(4, "Van Gogh references", "Letters, sketches, links.", Kind.Image, "References", color = 3, pinned = true),
            Item(5, "Quote cards", "I dream my painting, and then I paint my dream.", Kind.Quote, "Quotes", layout = Layout.Quote, color = 4),
        )
    }
}
