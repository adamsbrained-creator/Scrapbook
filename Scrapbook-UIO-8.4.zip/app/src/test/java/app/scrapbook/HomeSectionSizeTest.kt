package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeSectionSizeTest {
    private fun sec(id: String = "a", title: String = "T", layout: SectionLayout = SectionLayout.Cards, anchor: String = "", show: Boolean = true, w: Int = 0, h: Int = 0,
                    rule: SectionRule? = null, card: SectionCard? = null) =
        HomeSection(id, title, layout, anchor, emptyList(), rule, card, show, w, h)

    @Test fun aNewSectionHasANameAndAnAutomaticSize() {
        val s = HomeSection("a")
        assertTrue(s.showTitle); assertEquals(0, s.width); assertEquals(0, s.height); assertFalse(s.sized)
    }

    @Test fun aSizeKeepsInsideItsLimits() {
        val list = listOf(sec())
        assertEquals(HomeSections.MIN_WIDTH, HomeSections.sized(list, "a", 5, 10)[0].width)
        assertEquals(HomeSections.MIN_HEIGHT, HomeSections.sized(list, "a", 5, 10)[0].height)
        assertEquals(HomeSections.MAX_WIDTH, HomeSections.sized(list, "a", 500, 5000)[0].width)
        assertEquals(HomeSections.MAX_HEIGHT, HomeSections.sized(list, "a", 500, 5000)[0].height)
        assertEquals(60, HomeSections.sized(list, "a", 60, 240)[0].width)
        assertEquals(240, HomeSections.sized(list, "a", 60, 240)[0].height)
    }

    @Test fun zeroGivesASideBackToAutomatic() {
        assertFalse(HomeSections.sized(listOf(sec(w = 50, h = 200)), "a", 0, 0)[0].sized)
        assertTrue(HomeSections.sized(listOf(sec()), "a", 50, 0)[0].sized)
        assertTrue(HomeSections.sized(listOf(sec()), "a", 0, 200)[0].sized)
    }

    @Test fun resizingAnotherSectionChangesNothing() {
        val list = listOf(sec("a"), sec("b"))
        assertEquals(list, HomeSections.sized(list, "zzz", 50, 200))
        assertEquals(sec("b"), HomeSections.sized(list, "a", 50, 200)[1])
    }

    @Test fun aUsualSectionIsSavedAsBefore() {
        assertEquals("S|a|cards||T\n", HomeSections.encode(listOf(sec())))
        assertEquals("S|a|chips|pinned|T\n", HomeSections.encode(listOf(sec(layout = SectionLayout.Chips, anchor = "pinned"))))
    }

    @Test fun theNewFieldsAreSavedOnlyWhenTheyAreNotTheUsual() {
        assertEquals("S|a|cards||T|||||0|0|0\n", HomeSections.encode(listOf(sec(show = false))))
        assertEquals("S|a|rows|pinned|T|||||1|60|240\n", HomeSections.encode(listOf(sec(layout = SectionLayout.Rows, anchor = "pinned", w = 60, h = 240))))
        assertEquals("S|a|cards||T|tag%3Ax||||1|50|200\n", HomeSections.encode(listOf(sec(w = 50, h = 200, rule = SectionRule(SectionRule.TAG, "x")))))
    }

    @Test fun everythingSurvivesSavingAndReading() {
        val list = listOf(
            sec("a", "Reading | now", SectionLayout.Chips, "pinned", w = 40, h = 150),
            sec("b", "", SectionLayout.Grid, "", show = false),
            sec("c", "Smart", SectionLayout.Rows, "recent", show = false, w = 100, h = 300, rule = SectionRule(SectionRule.WEEK)),
            sec("d", "Plain"),
            sec("e", "Quote", card = SectionCard(SectionCard.QUOTE, "one\ntwo"), show = false, w = 80, h = 160),
            sec("f", "Count", card = SectionCard(SectionCard.COUNTER)),
        )
        assertEquals(list, HomeSections.decode(HomeSections.encode(list)))
    }

    @Test fun linesSavedBeforeTheNewFieldsStillRead() {
        val plain = HomeSections.decode("S|a|cards||Hello\n")[0]
        assertTrue(plain.showTitle); assertEquals(0, plain.width); assertEquals(0, plain.height)
        val smart = HomeSections.decode("S|a|cards||Hello|tag%3Ax\n")[0]
        assertEquals(SectionRule(SectionRule.TAG, "x"), smart.rule); assertTrue(smart.showTitle); assertFalse(smart.sized)
        val card = HomeSections.decode("S|a|cards||Note||text|Hi|\n")[0]
        assertEquals(SectionCard(SectionCard.TEXT, "Hi"), card.card); assertTrue(card.showTitle); assertFalse(card.sized)
    }

    @Test fun anUnreadableSizeIsAutomaticAndALargeOneIsBroughtBack() {
        val bad = HomeSections.decode("S|a|cards||T|||||1|abc|-5\n")[0]
        assertEquals(0, bad.width); assertEquals(0, bad.height)
        val big = HomeSections.decode("S|a|cards||T|||||1|7|9999\n")[0]
        assertEquals(HomeSections.MIN_WIDTH, big.width); assertEquals(HomeSections.MAX_HEIGHT, big.height)
    }

    @Test fun theCornerGivesAWidthInPercent() {
        assertEquals(50, HomeSections.widthPercent(500f, 1000f))
        assertEquals(100, HomeSections.widthPercent(960f, 1000f))
        assertEquals(HomeSections.MIN_WIDTH, HomeSections.widthPercent(100f, 1000f))
        assertEquals(100, HomeSections.widthPercent(2000f, 1000f))
        assertEquals(0, HomeSections.widthPercent(500f, 0f))
    }

    @Test fun theCornerGivesAHeightInDp() {
        assertEquals(220, HomeSections.heightDp(440f, 2f))
        assertEquals(HomeSections.MIN_HEIGHT, HomeSections.heightDp(10f, 2f))
        assertEquals(HomeSections.MAX_HEIGHT, HomeSections.heightDp(5000f, 2f))
        assertEquals(0, HomeSections.heightDp(100f, 0f))
    }

    @Test fun aGridTakesAsManyColumnsAsFit() {
        assertEquals(2, HomeSections.gridColumns(320f)); assertEquals(1, HomeSections.gridColumns(150f)); assertEquals(1, HomeSections.gridColumns(100f))
        assertEquals(3, HomeSections.gridColumns(500f))
    }

    @Test fun theRowsOfAGridShareTheHeight() {
        assertEquals(136f, HomeSections.gridCellHeight(0, 6, 2), 0.01f)
        assertEquals(144f, HomeSections.gridCellHeight(300, 4, 2), 0.01f)
        assertEquals(72f, HomeSections.gridCellHeight(100, 6, 2), 0.01f)
        assertEquals(220f, HomeSections.gridCellHeight(900, 2, 2), 0.01f)
    }

    @Test fun aCardIsAsWideAsTheBoxAllowsAndALittleWiderThanTall() {
        assertEquals(176f, HomeSections.cardWidth(320f, 0), 0.01f)
        assertEquals(100f, HomeSections.cardWidth(100f, 0), 0.01f)
        assertEquals(260f, HomeSections.cardWidth(320f, 200), 0.01f)
        assertEquals(110f, HomeSections.cardWidth(320f, 50), 0.01f)
        assertEquals(90f, HomeSections.cardWidth(90f, 200), 0.01f)
    }
}
