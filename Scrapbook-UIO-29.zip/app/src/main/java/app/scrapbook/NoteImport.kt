package app.scrapbook

import java.io.InputStream

/** What a file in an import folder is. */
enum class NoteFile { Word, Text, Samsung, Other }

/** What an import did, to be told to the person in one message. */
data class ImportReport(val added: Int = 0, val duplicates: Int = 0, val unreadable: Int = 0, val samsung: Int = 0, val other: Int = 0) {
    operator fun plus(o: ImportReport) = ImportReport(added + o.added, duplicates + o.duplicates, unreadable + o.unreadable, samsung + o.samsung, other + o.other)

    fun message(): String {
        val parts = ArrayList<String>()
        parts.add(if (added == 1) "Imported 1 scrap." else "Imported $added scraps.")
        if (duplicates > 0) parts.add(if (duplicates == 1) "1 was already here." else "$duplicates were already here.")
        if (unreadable > 0) parts.add(if (unreadable == 1) "1 couldn't be read." else "$unreadable couldn't be read.")
        if (samsung > 0) parts.add(
            (if (samsung == 1) "1 Samsung Notes file (.sdocx) can't be read directly" else "$samsung Samsung Notes files (.sdocx) can't be read directly") +
                ": in Samsung Notes use Save as file > Microsoft Word file.")
        if (other > 0) parts.add(if (other == 1) "1 other file was skipped." else "$other other files were skipped.")
        return parts.joinToString(" ")
    }
}

/** Reading the files of an import folder: Word files (what Samsung Notes saves), text and Markdown. Pure, so it can be tested without a phone. */
object NoteImport {
    private val SAMSUNG = setOf("sdocx", "sdoc", "snb", "spd", "memo")
    private val TEXT = setOf("txt", "md", "markdown", "text")

    fun kindOf(fileName: String): NoteFile {
        if (fileName.startsWith(".") || fileName.startsWith("~$")) return NoteFile.Other
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when {
            ext == "docx" -> NoteFile.Word
            ext in TEXT -> NoteFile.Text
            ext in SAMSUNG -> NoteFile.Samsung
            else -> NoteFile.Other
        }
    }

    fun nameWithoutExtension(fileName: String): String = if (fileName.contains('.')) fileName.substringBeforeLast('.') else fileName

    /** Reads one file. Null when it holds nothing to import or cannot be read. */
    fun parse(fileName: String, input: InputStream): ParsedNote? = when (kindOf(fileName)) {
        NoteFile.Word -> DocxReader.read(input, nameWithoutExtension(fileName))
        NoteFile.Text -> parseText(fileName, input.readBytes().toString(Charsets.UTF_8))
        else -> null
    }

    /** Text: a first "# Title" line becomes the title (the same rule as before); otherwise the file's name is the title. */
    fun parseText(fileName: String, raw: String): ParsedNote? {
        val text = raw.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n')
        val lines = text.lines(); val h = lines.indexOfFirst { it.startsWith("# ") }
        val title = (if (h >= 0) lines[h].drop(2).trim() else nameWithoutExtension(fileName).trim()).ifBlank { "Imported scrap" }.take(80)
        val body = (if (h >= 0) lines.filterIndexed { i, _ -> i != h } else lines).joinToString("\n").trim()
        if (body.isEmpty() && h < 0) return null
        return ParsedNote(title, body, null, null)
    }

    /** What makes two notes "the same" when a folder is imported again: the title and the text, without caring about capitals or spaces at the ends. */
    fun fingerprint(title: String, body: String): String = title.trim().lowercase() + "\u0000" + body.trim().lowercase()

    /** The boxes a file goes into: the folders between the import folder and the file, top down. Empty = the file is in the folder itself (it goes to Inbox). */
    fun boxPath(relative: List<String>): List<String> = relative.map { it.trim() }.filter { it.isNotEmpty() }
}
