package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class DocxReaderTest {
    private val W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
        "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\""

    private fun docx(body: String, rels: String = "", numbering: String = "", styles: String = "", core: String = "", media: Map<String, ByteArray> = emptyMap()): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            fun put(n: String, b: ByteArray) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() }
            put("[Content_Types].xml", "<Types/>".toByteArray())
            put("word/document.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:document $W><w:body>$body</w:body></w:document>".toByteArray())
            if (rels.isNotEmpty()) put("word/_rels/document.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">$rels</Relationships>".toByteArray())
            if (numbering.isNotEmpty()) put("word/numbering.xml", "<w:numbering $W>$numbering</w:numbering>".toByteArray())
            if (styles.isNotEmpty()) put("word/styles.xml", "<w:styles $W>$styles</w:styles>".toByteArray())
            if (core.isNotEmpty()) put("docProps/core.xml", ("<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dcterms=\"http://purl.org/dc/terms/\">$core</cp:coreProperties>").toByteArray())
            for ((n, b) in media) put("word/media/$n", b)
        }
        return bo.toByteArray()
    }
    private fun read(bytes: ByteArray, name: String = "My note") = DocxReader.read(ByteArrayInputStream(bytes), name)
    private fun p(text: String, ppr: String = "", rpr: String = "") = "<w:p>${if (ppr.isEmpty()) "" else "<w:pPr>$ppr</w:pPr>"}<w:r>${if (rpr.isEmpty()) "" else "<w:rPr>$rpr</w:rPr>"}<w:t xml:space=\"preserve\">$text</w:t></w:r></w:p>"

    @Test fun plainParagraphsKeepTheirOrderAndTheFileNameIsTheTitle() {
        val n = read(docx(p("First line") + p("Second line")), "Shopping")!!
        assertEquals("Shopping", n.title); assertEquals("First line\nSecond line", n.body)
    }

    @Test fun firstLineEqualToTheFileNameBecomesTheTitleAndIsNotRepeated() {
        val n = read(docx(p("Shopping") + p("") + p("milk")), "Shopping")!!
        assertEquals("Shopping", n.title); assertEquals("milk", n.body)
    }

    @Test fun emptyParagraphsMakeOneBlankLineAndEdgesAreTrimmed() {
        val n = read(docx(p("") + p("a") + p("") + p("") + p("b") + p("")))!!
        assertEquals("a\n\nb", n.body)
    }

    @Test fun headingsComeFromStyleNames() {
        val styles = "<w:style w:type=\"paragraph\" w:styleId=\"H1\"><w:name w:val=\"heading 1\"/></w:style><w:style w:type=\"paragraph\" w:styleId=\"H2\"><w:name w:val=\"heading 2\"/></w:style>"
        val n = read(docx(p("Big", "<w:pStyle w:val=\"H1\"/>") + p("Small", "<w:pStyle w:val=\"H2\"/>") + p("text"), styles = styles))!!
        assertEquals("# Big\n## Small\ntext", n.body)
    }

    @Test fun titleStyleFirstLineIsTheTitle() {
        val styles = "<w:style w:type=\"paragraph\" w:styleId=\"T\"><w:name w:val=\"Title\"/></w:style>"
        val n = read(docx(p("Trip to Prague", "<w:pStyle w:val=\"T\"/>") + p("pack bags"), styles = styles), "export 12")!!
        assertEquals("Trip to Prague", n.title); assertEquals("pack bags", n.body)
    }

    @Test fun inlineMarks() {
        val body = "<w:p>" +
            "<w:r><w:t xml:space=\"preserve\">a </w:t></w:r>" +
            "<w:r><w:rPr><w:b/></w:rPr><w:t>bold</w:t></w:r><w:r><w:t xml:space=\"preserve\"> </w:t></w:r>" +
            "<w:r><w:rPr><w:i/></w:rPr><w:t>it</w:t></w:r><w:r><w:t xml:space=\"preserve\"> </w:t></w:r>" +
            "<w:r><w:rPr><w:strike/></w:rPr><w:t>gone</w:t></w:r><w:r><w:t xml:space=\"preserve\"> </w:t></w:r>" +
            "<w:r><w:rPr><w:highlight w:val=\"yellow\"/></w:rPr><w:t>hl</w:t></w:r><w:r><w:t xml:space=\"preserve\"> </w:t></w:r>" +
            "<w:r><w:rPr><w:color w:val=\"FF0000\"/></w:rPr><w:t>red</w:t></w:r><w:r><w:t xml:space=\"preserve\"> </w:t></w:r>" +
            "<w:r><w:rPr><w:u w:val=\"single\"/></w:rPr><w:t>under</w:t></w:r></w:p>"
        assertEquals("a **bold** *it* ~~gone~~ ==hl== {c:ff0000|red} {u|under}", read(docx(body))!!.body)
    }

    @Test fun adjacentRunsWithTheSameLookAreOneMarkAndSpacesStayOutside() {
        val body = "<w:p><w:r><w:rPr><w:b/></w:rPr><w:t xml:space=\"preserve\">one </w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:t>two </w:t></w:r><w:r><w:t>three</w:t></w:r></w:p>"
        assertEquals("**one two** three", read(docx(body))!!.body)
    }

    @Test fun blackTextColorAndOffSwitchesAreIgnored() {
        val body = p("x", rpr = "<w:color w:val=\"000000\"/><w:b w:val=\"0\"/>")
        assertEquals("x", read(docx(body))!!.body)
    }

    @Test fun hyperlinksNeedHttp() {
        val rels = "<Relationship Id=\"rId1\" Type=\"x\" Target=\"https://example.com/a\" TargetMode=\"External\"/><Relationship Id=\"rId2\" Type=\"x\" Target=\"javascript:alert(1)\" TargetMode=\"External\"/>"
        val body = "<w:p><w:hyperlink r:id=\"rId1\"><w:r><w:t>site</w:t></w:r></w:hyperlink><w:r><w:t xml:space=\"preserve\"> and </w:t></w:r><w:hyperlink r:id=\"rId2\"><w:r><w:t>bad</w:t></w:r></w:hyperlink></w:p>"
        assertEquals("[site](https://example.com/a) and bad", read(docx(body, rels = rels))!!.body)
    }

    private val numbering = "<w:abstractNum w:abstractNumId=\"0\"><w:lvl w:ilvl=\"0\"><w:numFmt w:val=\"bullet\"/></w:lvl><w:lvl w:ilvl=\"1\"><w:numFmt w:val=\"bullet\"/></w:lvl></w:abstractNum>" +
        "<w:abstractNum w:abstractNumId=\"1\"><w:lvl w:ilvl=\"0\"><w:numFmt w:val=\"decimal\"/></w:lvl><w:lvl w:ilvl=\"1\"><w:numFmt w:val=\"decimal\"/></w:lvl></w:abstractNum>" +
        "<w:num w:numId=\"1\"><w:abstractNumId w:val=\"0\"/></w:num><w:num w:numId=\"2\"><w:abstractNumId w:val=\"1\"/></w:num>"
    private fun li(text: String, id: Int, lvl: Int = 0) = p(text, "<w:numPr><w:ilvl w:val=\"$lvl\"/><w:numId w:val=\"$id\"/></w:numPr>")

    @Test fun bulletsAndNumbersWithDepth() {
        val body = li("milk", 1) + li("oat", 1, 1) + li("eggs", 1) + p("gap") + li("one", 2) + li("two", 2) + li("two-a", 2, 1) + li("three", 2)
        assertEquals("- milk\n- {i:1}oat\n- eggs\ngap\n1. one\n2. two\n1. {i:1}two-a\n3. three", read(docx(body, numbering = numbering))!!.body)
    }

    @Test fun numberingRestartsAfterAParagraph() {
        val body = li("a", 2) + li("b", 2) + p("break") + li("c", 2)
        assertEquals("1. a\n2. b\nbreak\n1. c", read(docx(body, numbering = numbering))!!.body)
    }

    @Test fun checkboxCharactersBecomeChecklistLines() {
        val body = p("☐ buy milk") + p("☑ call mom") + li("☐ nested", 1)
        assertEquals("- [ ] buy milk\n- [x] call mom\n- [ ] nested", read(docx(body, numbering = numbering))!!.body)
    }

    @Test fun alignment() {
        val body = p("mid", "<w:jc w:val=\"center\"/>") + p("end", "<w:jc w:val=\"right\"/>") + p("start", "<w:jc w:val=\"left\"/>")
        assertEquals("{a:c}mid\n{a:r}end\nstart", read(docx(body))!!.body)
    }

    @Test fun tableRowsBecomeLines() {
        val cell = { t: String -> "<w:tc>${p(t)}</w:tc>" }
        val body = p("before") + "<w:tbl><w:tr>${cell("a")}${cell("b")}</w:tr><w:tr>${cell("c")}${cell("")}</w:tr></w:tbl>" + p("after")
        assertEquals("before\n\na | b\nc |\n\nafter", read(docx(body))!!.body)
    }

    @Test fun picturesAreCollectedInOrderOnceAndOnlyRaster() {
        val rels = "<Relationship Id=\"rId5\" Type=\"x\" Target=\"media/image1.png\"/><Relationship Id=\"rId6\" Type=\"x\" Target=\"media/image2.jpeg\"/><Relationship Id=\"rId7\" Type=\"x\" Target=\"media/shape.emf\"/>"
        fun pic(id: String) = "<w:p><w:r><w:drawing><wp:inline><a:graphic><a:graphicData><pic:pic><pic:blipFill><a:blip r:embed=\"$id\"/></pic:blipFill></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"
        val body = p("look") + pic("rId6") + pic("rId5") + pic("rId6") + pic("rId7")
        val n = read(docx(body, rels = rels, media = mapOf("image1.png" to byteArrayOf(1), "image2.jpeg" to byteArrayOf(2), "shape.emf" to byteArrayOf(3))))!!
        assertEquals(listOf("image2.jpeg", "image1.png"), n.images.map { it.name })
        assertEquals(listOf("jpg", "png"), n.images.map { it.extension })
        assertEquals("look", n.body)
    }

    @Test fun aNoteOfOnlyPicturesIsKept() {
        val rels = "<Relationship Id=\"rId5\" Type=\"x\" Target=\"media/a.jpg\"/>"
        val body = "<w:p><w:r><w:drawing><a:blip r:embed=\"rId5\"/></w:drawing></w:r></w:p>"
        val n = read(docx(body, rels = rels, media = mapOf("a.jpg" to byteArrayOf(9))))!!
        assertEquals("", n.body); assertEquals(1, n.images.size)
    }

    @Test fun datesComeFromTheFile() {
        val n = read(docx(p("x"), core = "<dcterms:created>2021-03-04T10:00:00Z</dcterms:created><dcterms:modified>2022-05-06T11:30:00Z</dcterms:modified>"))!!
        assertEquals(1614852000000L, n.created); assertEquals(1651836600000L, n.modified)
    }

    @Test fun missingOrBrokenDatesAreNull() {
        val n = read(docx(p("x"), core = "<dcterms:created>yesterday</dcterms:created>"))!!
        assertNull(n.created); assertNull(n.modified)
    }

    @Test fun emptyDocumentIsNothing() { assertNull(read(docx(p("") + p("  ")))) }

    @Test fun notAZipOrNotAWordFileIsNothing() {
        assertNull(DocxReader.read(ByteArrayInputStream("hello".toByteArray()), "x"))
        val bo = ByteArrayOutputStream(); ZipOutputStream(bo).use { it.putNextEntry(ZipEntry("note.note")); it.write(byteArrayOf(1, 2)); it.closeEntry() }
        assertNull(DocxReader.read(ByteArrayInputStream(bo.toByteArray()), "x"))
    }

    @Test fun xmlWithAnEntityDeclarationIsRefused() {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> z.putNextEntry(ZipEntry("word/document.xml")); z.write("<!DOCTYPE d [<!ENTITY x \"boom\">]><w:document $W><w:body><w:p><w:r><w:t>&x;</w:t></w:r></w:p></w:body></w:document>".toByteArray()); z.closeEntry() }
        assertNull(DocxReader.read(ByteArrayInputStream(bo.toByteArray()), "x"))
    }

    @Test fun veryLongTitleIsCut() {
        val n = read(docx(p("body")), "x".repeat(200))!!
        assertEquals(80, n.title.length)
    }

    @Test fun lineBreaksInsideAParagraphStayLines() {
        val body = "<w:p><w:r><w:t>one</w:t><w:br/><w:t>two</w:t></w:r></w:p>"
        assertEquals("one\ntwo", read(docx(body))!!.body)
    }

    @Test fun boldAcrossALineBreakIsMarkedPerLine() {
        val body = "<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>one</w:t><w:br/><w:t>two</w:t></w:r></w:p>"
        assertEquals("**one**\n**two**", read(docx(body))!!.body)
    }

    @Test fun aWordFileIsNotNullWhenOnlyTextExists() { assertNotNull(read(docx(p("hi")))); assertTrue(true) }
}
