package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NoteImportTest {
    @Test fun fileKinds() {
        assertEquals(NoteFile.Word, NoteImport.kindOf("Trip.docx")); assertEquals(NoteFile.Word, NoteImport.kindOf("Trip.DOCX"))
        assertEquals(NoteFile.Text, NoteImport.kindOf("a.txt")); assertEquals(NoteFile.Text, NoteImport.kindOf("a.md"))
        assertEquals(NoteFile.Samsung, NoteImport.kindOf("a.sdocx")); assertEquals(NoteFile.Samsung, NoteImport.kindOf("a.SDOC")); assertEquals(NoteFile.Samsung, NoteImport.kindOf("a.snb"))
        assertEquals(NoteFile.Other, NoteImport.kindOf("a.pdf")); assertEquals(NoteFile.Other, NoteImport.kindOf("noext"))
        assertEquals(NoteFile.Other, NoteImport.kindOf("~\$lock.docx")); assertEquals(NoteFile.Other, NoteImport.kindOf(".hidden.txt"))
    }

    @Test fun textTitleRule() {
        val a = NoteImport.parseText("file.txt", "# Real title\nbody\nmore")!!
        assertEquals("Real title", a.title); assertEquals("body\nmore", a.body)
        val b = NoteImport.parseText("Groceries.md", "milk\r\neggs")!!
        assertEquals("Groceries", b.title); assertEquals("milk\neggs", b.body)
        assertEquals("T", NoteImport.parseText("x.txt", "﻿# T\nbody")!!.title)
        assertNull(NoteImport.parseText("empty.txt", "  \n "))
    }

    @Test fun duplicatesIgnoreCaseAndEdgeSpaces() {
        assertEquals(NoteImport.fingerprint("Trip", "a\nb"), NoteImport.fingerprint(" trip ", "A\nb\n"))
        assertNotEquals(NoteImport.fingerprint("Trip", "a"), NoteImport.fingerprint("Trip", "b"))
    }

    @Test fun boxPathDropsBlanks() { assertEquals(listOf("Work", "2020"), NoteImport.boxPath(listOf(" Work", "", "2020 "))) }

    @Test fun messages() {
        assertEquals("Imported 1 scrap.", ImportReport(added = 1).message())
        assertEquals("Imported 480 scraps. 20 were already here. 5 couldn't be read. 12 Samsung Notes files (.sdocx) can't be read directly: in Samsung Notes use Save as file > Microsoft Word file.",
            ImportReport(480, 20, 5, 12, 0).message())
        assertEquals("Imported 0 scraps. 1 other file was skipped.", ImportReport(other = 1).message())
        assertEquals(ImportReport(3, 1, 0, 2, 0), ImportReport(1, 1, 0, 0, 0) + ImportReport(2, 0, 0, 2, 0))
    }
}
