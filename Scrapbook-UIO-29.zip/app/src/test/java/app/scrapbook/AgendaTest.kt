package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Locale
import java.util.TimeZone

/** The Agenda layout, the tabs card, the Pinned and Tasks rules and the choices that go with them (UIO 27). */
class AgendaTest {
    private val utc: TimeZone = TimeZone.getTimeZone("UTC")
    private val en = Locale.ENGLISH
    private fun at(y: Int, mo: Int, d: Int, h: Int = 12, mi: Int = 0): Long = LocalDateTime.of(y, mo, d, h, mi).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()
    private fun mk(title: String, box: String = "Inbox", body: String = "", tags: List<String> = emptyList(), pinned: Boolean = false, saved: Long = 1000L) =
        Item(title = title, body = body, kind = Kind.Note, collection = box, tags = tags, pinned = pinned, savedAt = saved)

    // ----- Days -----

    @Test fun aDayHasAHeadingLikeTheMockup() {
        assertEquals("13 Feb, Mon", Agenda.heading(at(2023, 2, 13, 9), utc, en))
        assertEquals("14 Feb, Tue", Agenda.heading(at(2023, 2, 14, 23, 59), utc, en))
    }

    @Test fun aDayStartsAtMidnight() {
        assertEquals(at(2023, 2, 13, 0), Agenda.dayStart(at(2023, 2, 13, 17, 45), utc))
        assertEquals(at(2023, 2, 13, 0), Agenda.dayStart(at(2023, 2, 13, 0), utc))
    }

    @Test fun thingsAreGroupedByDayNewestDayFirstAndNewestFirstInsideIt() {
        val times = listOf<Long?>(at(2023, 2, 13, 9), at(2023, 2, 14, 15), at(2023, 2, 13, 14, 30), at(2023, 2, 14, 16))
        val g = Agenda.groups(times, false, utc, en)
        assertEquals(listOf("14 Feb, Tue", "13 Feb, Mon"), g.map { it.heading })
        assertEquals(listOf(3, 1), g[0].indices)
        assertEquals(listOf(2, 0), g[1].indices)
    }

    @Test fun oldFirstTurnsBothTheDaysAndTheOrderInsideThemAround() {
        val times = listOf<Long?>(at(2023, 2, 13, 9), at(2023, 2, 14, 15), at(2023, 2, 13, 14, 30), at(2023, 2, 14, 16))
        val g = Agenda.groups(times, true, utc, en)
        assertEquals(listOf("13 Feb, Mon", "14 Feb, Tue"), g.map { it.heading })
        assertEquals(listOf(0, 2), g[0].indices)
        assertEquals(listOf(1, 3), g[1].indices)
    }

    @Test fun thingsWithNoDateAreAGroupOfTheirOwnAtTheTopInTheirOwnOrder() {
        val g = Agenda.groups(listOf(null, at(2023, 2, 13), null), false, utc, en)
        assertEquals(Agenda.UNDATED, g[0].heading)
        assertNull(g[0].start)
        assertEquals(listOf(0, 2), g[0].indices)
        assertEquals(1, g[1].indices.single())
    }

    @Test fun everyPlaceIsInExactlyOneGroup() {
        val times = List(23) { i -> if (i % 5 == 0) null else at(2023, 2, 1 + i % 9, i % 24) }
        listOf(false, true).forEach { old ->
            val g = Agenda.groups(times, old, utc, en)
            assertEquals(times.indices.toList(), Agenda.flat(g).sorted())
        }
    }

    @Test fun twoThingsAtTheSameMomentKeepTheirOrder() {
        val t = at(2023, 2, 13, 9)
        assertEquals(listOf(0, 1, 2), Agenda.groups(listOf(t, t, t), false, utc, en).single().indices)
        assertEquals(listOf(0, 1, 2), Agenda.groups(listOf(t, t, t), true, utc, en).single().indices)
    }

    @Test fun nothingIsNoGroups() {
        assertTrue(Agenda.groups(emptyList(), false, utc, en).isEmpty())
        assertTrue(Agenda.flat(emptyList()).isEmpty())
    }

    // ----- Tabs -----

    @Test fun aNewTabsCardStartsWithImportantGeneralAndTasks() {
        assertEquals(listOf("Important", "General", "Tasks"), SectionTabs.DEFAULT.map { it.label })
        assertEquals(listOf(SectionRule(SectionRule.PINNED), null, SectionRule(SectionRule.TASKS)), SectionTabs.DEFAULT.map { it.rule })
        assertTrue(SectionTabs.DEFAULT.size in SectionTabs.MIN_TABS..SectionTabs.MAX_TABS)
    }

    @Test fun tabsAreSavedAndReadBack() {
        val tabs = listOf(SectionTab("Ideas", SectionRule(SectionRule.TAG, "big idea")), SectionTab("Trips", SectionRule(SectionRule.BOX, "My | Trips & more")), SectionTab("All"), SectionTab("Week", SectionRule(SectionRule.WEEK)))
        assertEquals(tabs, SectionTabs.parse(SectionTabs.encode(tabs)))
    }

    @Test fun aLabelIsOneShortLineWithoutBars() {
        assertEquals("a b c", SectionTabs.cleanLabel("  a|b\nc  "))
        assertEquals(SectionTabs.MAX_LABEL, SectionTabs.cleanLabel("x".repeat(80)).length)
        assertEquals("", SectionTabs.cleanLabel("  |  "))
    }

    @Test fun unreadableTabsAreSkippedAndANamelessOneIsNumbered() {
        val t = SectionTabs.parse("junk\ntag%3Aa|\n%%%|Odd\nweek|Week")
        assertEquals(listOf("Tab 1", "Odd", "Week"), t.map { it.label })
        assertEquals(SectionRule(SectionRule.TAG, "a"), t[0].rule)
        assertNull(t[1].rule)
        assertEquals(SectionRule(SectionRule.WEEK), t[2].rule)
        assertTrue(SectionTabs.parse(null).isEmpty())
        assertTrue(SectionTabs.parse("").isEmpty())
    }

    @Test fun atMostFourTabsAreKept() {
        val text = (1..9).joinToString("\n") { "|T$it" }
        assertEquals(SectionTabs.MAX_TABS, SectionTabs.parse(text).size)
        assertEquals(SectionTabs.MAX_TABS, SectionTabs.encode(List(9) { SectionTab("T$it") }).lines().size)
    }

    @Test fun aCardWithNoTabsWrittenHasTheUsualThree() {
        assertEquals(SectionTabs.DEFAULT, SectionCard(SectionCard.TABS).tabs)
        assertEquals(SectionTabs.DEFAULT, SectionCard(SectionCard.TABS, "garbage").tabs)
        assertTrue(SectionCard(SectionCard.TEXT, "x|y").tabs.isEmpty())
    }

    @Test fun theShownTabStaysInsideTheList() {
        val t = SectionTabs.DEFAULT
        assertEquals(0, SectionTabs.selected(t, -3))
        assertEquals(2, SectionTabs.selected(t, 2))
        assertEquals(2, SectionTabs.selected(t, 9))
        assertEquals(0, SectionTabs.selected(emptyList(), 4))
    }

    @Test fun tabsCanBeRenamedGivenARuleAddedMovedAndTakenAway() {
        val t = SectionTabs.DEFAULT
        assertEquals("Now", SectionTabs.renamed(t, 1, "Now")[1].label)
        assertEquals(t, SectionTabs.renamed(t, 7, "Now"))
        val r = SectionTabs.withRule(t, 1, SectionRule(SectionRule.WEEK), "This week")[1]
        assertEquals(SectionTab("This week", SectionRule(SectionRule.WEEK)), r)
        assertEquals("General", SectionTabs.withRule(t, 1, SectionRule(SectionRule.WEEK))[1].label)
        assertEquals(SectionTab("Tab 4"), SectionTabs.added(t).last())
        assertEquals(t, SectionTabs.added(SectionTabs.added(t)).let { SectionTabs.removed(it, 3) })
        assertEquals(SectionTabs.MAX_TABS, SectionTabs.added(SectionTabs.added(SectionTabs.added(t))).size)
        assertEquals(listOf("General", "Important", "Tasks"), SectionTabs.moved(t, 0, 1).map { it.label })
        assertEquals(t, SectionTabs.moved(t, 0, -1))
        assertEquals(t, SectionTabs.moved(t, 2, 1))
        assertEquals(listOf("Important", "Tasks"), SectionTabs.removed(t, 1).map { it.label })
    }

    @Test fun theLastTabIsNeverTakenAway() {
        val one = listOf(SectionTab("Only"))
        assertEquals(one, SectionTabs.removed(one, 0))
    }

    @Test fun aNewTabGetsANumberThatIsNotTaken() {
        val t = listOf(SectionTab("Tab 3"), SectionTab("x"))
        assertEquals("Tab 4", SectionTabs.added(t).last().label)
    }

    @Test fun aNewScrapFromATabLandsInItsBoxOrCarriesItsTag() {
        assertEquals("Trips" to null, SectionTabs.starter(SectionRule(SectionRule.BOX, "Trips")))
        assertEquals(null to null, SectionTabs.starter(SectionRule(SectionRule.BOX, "Inbox")))
        assertEquals(null to "#ideas ", SectionTabs.starter(SectionRule(SectionRule.TAG, "ideas")))
        assertEquals(null to null, SectionTabs.starter(SectionRule(SectionRule.PINNED)))
        assertEquals(null to null, SectionTabs.starter(null))
    }

    // ----- The tabs card as a section -----

    private val tabsSection = HomeSection("ag", "Agenda", SectionLayout.Agenda, "header", emptyList(), card = SectionCard(SectionCard.TABS, SectionTabs.encode(SectionTabs.DEFAULT)),
        style = SectionStyle(fill = true, agDays = false, agSub = 2, agTile = 1, agChevron = false, agOldFirst = true, tabsBar = 1, tabsHead = false))

    @Test fun aTabsCardIsACardThatFillsItselfAndHoldsNothing() {
        assertTrue(tabsSection.isTabs && tabsSection.isCard)
        assertTrue(tabsSection.fillsItself)
        assertFalse(tabsSection.isSmart)
        assertFalse(HomeSection("x", card = SectionCard(SectionCard.TEXT)).isTabs)
        assertTrue(HomeSection("x", rule = SectionRule(SectionRule.WEEK)).fillsItself)
        assertFalse(HomeSection("x").fillsItself)
    }

    @Test fun aTabsCardAndItsLookAreSavedAndReadBackTheSame() {
        val back = HomeSections.decode(HomeSections.encode(listOf(tabsSection)))
        assertEquals(listOf(tabsSection), back)
        assertEquals(SectionLayout.Agenda, back.single().layout)
        assertEquals(SectionTabs.DEFAULT, back.single().card!!.tabs)
    }

    @Test fun aTabsCardHasANameAndIsKnownToTheCardKinds() {
        assertEquals("Tabs", SectionCard.label(SectionCard.TABS))
        assertTrue(SectionCard.defaultTitle(SectionCard.TABS).isNotBlank())
        assertEquals("Tabs", HomeSection("x", "", card = SectionCard(SectionCard.TABS)).name)
        assertFalse(SectionCard.TABS in SectionCard.KINDS)      // it has its own row in Add a section
        assertEquals(SectionCard.TABS, SectionCard.parse(SectionCard.TABS, "a", "")!!.kind)
    }

    @Test fun aTabsCardCanBeSharedInASkinCode() {
        val kept = SkinShare.portable(mapOf(SkinKeys.SECTIONS to HomeSections.encode(listOf(tabsSection))))
        assertEquals(listOf(tabsSection), HomeSections.decode(kept[SkinKeys.SECTIONS]))
    }

    // ----- Pinned and Tasks rules -----

    @Test fun thePinnedAndTasksRulesAreSavedAndReadBack() {
        listOf(SectionRule(SectionRule.PINNED), SectionRule(SectionRule.TASKS)).forEach { assertEquals(it, SectionRule.parse(it.encode())) }
        assertEquals("pinned", SectionRule(SectionRule.PINNED).encode())
        assertEquals("tasks", SectionRule(SectionRule.TASKS).encode())
        assertNull(SectionRule.parse("pinned2"))
    }

    @Test fun pinnedFindsThePinnedScrapsAndTasksTheOnesWithSomethingToDo() {
        val items = listOf(mk("a", pinned = true), mk("b", body = "- [ ] milk\n- [x] eggs"), mk("c", body = "- [x] done"), mk("d", body = "plain"), mk("e", pinned = true, body = "- [ ] x"))
        assertEquals(listOf("a", "e"), HomeSections.matching(SectionRule(SectionRule.PINNED), items, emptySet(), 0L).map { it.title })
        assertEquals(listOf("b", "e"), HomeSections.matching(SectionRule(SectionRule.TASKS), items, emptySet(), 0L).map { it.title })
        assertTrue(HomeSections.hasOpenTask("x\n- [ ] y"))
        assertFalse(HomeSections.hasOpenTask("- [x] y"))
    }

    @Test fun aTabShowsMoreThanASmartSectionAndNewestEditedFirst() {
        val items = List(30) { mk("n$it", pinned = true, saved = 1000L + it) }
        assertEquals(SectionRule.MAX_SHOWN, HomeSections.smartScraps(SectionRule(SectionRule.PINNED), items, emptySet(), 0L).size)
        val tab = HomeSections.smartScraps(SectionRule(SectionRule.PINNED), items, emptySet(), 0L, SectionTabs.MAX_SHOWN)
        assertEquals(SectionTabs.MAX_SHOWN, tab.size)
        assertEquals("n29", tab.first().title)
    }

    @Test fun aCounterSaysWhatItCountsForTheNewRules() {
        assertEquals("scraps pinned", HomeSections.counterText(3, SectionRule(SectionRule.PINNED), ""))
        assertEquals("scrap pinned", HomeSections.counterText(1, SectionRule(SectionRule.PINNED), ""))
        assertEquals("scraps with tasks to do", HomeSections.counterText(2, SectionRule(SectionRule.TASKS), ""))
        assertEquals("scraps edited this week", HomeSections.counterText(2, SectionRule(SectionRule.WEEK), ""))
    }

    // ----- The layout and the choices of its look -----

    @Test fun agendaIsTheLastLayoutSoEverySavedLayoutKeepsItsName() {
        assertEquals(SectionLayout.Agenda, SectionLayout.entries.last())
        assertEquals(SectionLayout.Agenda, SectionLayout.of("agenda"))
        assertEquals("agenda", SectionLayout.Agenda.key)
        assertTrue(SectionLayout.Agenda.note.isNotBlank())
        assertEquals(SectionLayout.Compact, SectionLayout.entries[SectionLayout.entries.lastIndex - 1])
    }

    @Test fun anAgendaSectionOfThingsIsSavedAndReadBack() {
        val s = HomeSection("a", "Plans", SectionLayout.Agenda, "pinned", listOf(SectionRef(false, "u1"), SectionRef(true, "Trips")), style = SectionStyle(agSub = 1))
        assertEquals(listOf(s), HomeSections.decode(HomeSections.encode(listOf(s))))
    }

    @Test fun thePinnedAndRecentPartsCanBeAnAgendaButBoxesAndContinueCannot() {
        assertTrue(SectionLayout.Agenda in PartShapes.layouts("pinnedStyle"))
        assertTrue(SectionLayout.Agenda in PartShapes.layouts("recentStyle"))
        assertFalse(SectionLayout.Agenda in PartShapes.layouts("boxesStyle"))
        assertFalse(SectionLayout.Agenda in PartShapes.layouts("continueStyle"))
        assertEquals("Agenda", HomeStyleKey.PinnedStyle.options.last())
        assertEquals("Agenda", HomeStyleKey.RecentStyle.options.last())
        assertFalse("Agenda" in HomeStyleKey.BoxesStyle.options)
    }

    @Test fun theAgendaDesignOfAPartSurvivesSavingAndLoading() {
        val i = HomeStyleKey.PinnedStyle.options.lastIndex
        val back = HomeStyles.decode(HomeStyles.Default.with(HomeStyleKey.PinnedStyle, i).encode())
        assertEquals(SectionLayout.Agenda, PartShapes.layoutFor("pinnedStyle", back[HomeStyleKey.PinnedStyle]))
    }

    @Test fun theAgendaChoicesAreOnlyWrittenWhenTheyAreNotTheUsualOnes() {
        assertEquals("", SectionStyle().encode())
        assertEquals("ad=0", SectionStyle(agDays = false).encode())
        assertEquals("as=2;at=1", SectionStyle(agSub = 2, agTile = 1).encode())
        assertEquals("ac=0;ao=1;tb=1;th=0", SectionStyle(agChevron = false, agOldFirst = true, tabsBar = 1, tabsHead = false).encode())
    }

    @Test fun everyAgendaChoiceIsReadBack() {
        val s = SectionStyle(fill = true, agDays = false, agSub = 3, agTile = 2, agChevron = false, agOldFirst = true, tabsBar = 1, tabsHead = false, icons = mapOf("n:a" to "🛒"))
        assertEquals(s, SectionStyle.decode(s.encode()))
    }

    @Test fun styleSavedBeforeTheAgendaStillReadsBackAsTheUsualAgenda() {
        val old = SectionStyle.decode("fill=1;w=70;s=1")
        assertTrue(old.agDays && old.agChevron && !old.agOldFirst && old.tabsHead)
        assertEquals(0, old.agSub); assertEquals(0, old.agTile); assertEquals(0, old.tabsBar)
    }

    @Test fun agendaNumbersAreKeptInTheirLimits() {
        val s = SectionStyle.decode("as=9;at=-4;tb=7;ad=x")
        assertEquals(3, s.agSub)
        assertEquals(0, s.agTile)
        assertEquals(1, s.tabsBar)
        assertTrue(s.agDays)
    }

    @Test fun theAgendaSkinAndTheOthersAreAllDifferent() {
        assertTrue(ReadySkins.all.map { it.key }.contains("agenda"))
        assertEquals("Agenda", ReadySkins.agenda.name)
        assertEquals(ReadySkins.agenda, ReadySkins.of("agenda"))
    }
}
