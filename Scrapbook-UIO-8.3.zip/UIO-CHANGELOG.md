Scrapbook — UI Overhaul (UIO) Development Log

Project: Scrapbook
Milestone: UI Overhaul (UIO)
Status: In progress
Base: Quality of Life update (scrapbook-QOL-88)

Goal: a complete overhaul of the app's look, with more customization, built section by section.
Entries are added in the order they are built. Each one says what the feature is for and what was built.

———

Section: Home

☑ 1. New greeting: account system (Scrapbook-UIO-1)
   For: the greeting needs to know who it is talking to, and the app needs a place for the person behind it.
   Built: an Account with name, nickname, a line about you, pronouns, birthday (no year) and a profile picture (photo, or initial on a chosen color).
   Stored only on this phone. New Account page, an account card at the top of Settings, a profile icon, picture cropping and saving (Avatar.kt).

☑ 2. More greeting options and views: greeting lines and settings (Scrapbook-UIO-1)
   For: a greeting that feels alive instead of the same line every day.
   Built: 170+ greetings across time of day (late night to night), weekdays, casual lines, lines about your scraps (Inbox, pinned, empty, large archive)
   and birthday / New Year's Day lines, in friendly, playful and calm voices. {name} drops out neatly when no name is set. The greeting changes by itself
   (never, 10, 20, 40 or 90 seconds), on every tap, and avoids repeating recent lines. New Settings > Greeting page: show or hide, show my picture,
   line under the greeting (date, about me, scrap count, nothing), change interval, tone, and switches for time-of-day, casual and scrap-related lines.
   The greeting on Home now uses the account's name and picture; tapping the picture opens the Account page.

☑ 3. Greeting: smaller by default, text and picture resize freely (Scrapbook-UIO-1.5)
   For: the greeting took too much room at the top of Home, and everyone wants a different size.
   Built: the greeting now starts smaller (text 24, picture 44 instead of 30 and 56). Settings > Greeting has a live preview and two sliders:
   Text size (14 to 44) and Picture size (20 to 96). The preview follows the slider while you drag, and the size is saved when you let go.
   The line under the greeting scales with the text, and a small picture still has a 44dp touch area.

☑ 4. Account card moved down in Settings (Scrapbook-UIO-1.5)
   For: the account card at the very top pushed the settings down; it belongs with the About page.
   Built: the account card now sits right above the About page, below the list of settings pages.

☑ 5. Greeting options moved into Customize home (Scrapbook-UIO-1.6)
   For: every part of Home is meant to keep its own options next to where it is moved and hidden, so the greeting's settings belong there and not in Settings.
   Built: a row in Customize home can now have a sliders button (and tapping its name does the same) that opens that part's own options page; the Greeting row has one.
   The page keeps the live preview pinned on top and holds text size, picture size, show my picture, the line under the greeting, how often it changes, the tone and the
   three switches for the kinds of lines. The Greeting page in Settings is gone (the Account card stays). Showing or hiding the greeting is still the eye on its row.
   Other parts can get their own options the same way (withOptions and options in HomeCustomize, ui/GreetingOptions.kt).

☑ 6. Home layout: move and hide every part (Scrapbook-UIO-2)
   For: Home should look the way you want it: any part can go anywhere, or be switched off.
   Built: Home is now made of eight parts (Header, Greeting, Quick capture, Continue, To sort, Boxes, Pinned, Recent), each with a place in the order and an on/off switch.
   New Customize home in the Home menu: one short row per part with a drag handle (hold and drag to move it) and an eye (tap to hide or bring it back), a Back to the usual order
   button, and Move up / Move down actions for screen readers. Hidden parts keep their place. The order and the hidden parts are saved on this phone (HomeLayout.kt, ui/HomeEdit.kt).
   Home reads the saved layout and draws its parts in that order. The old "Show greeting" and "Show boxes on home" switches in Settings now use the same on/off state,
   and an update keeps whatever they were set to. With the header hidden, a small menu button stays so the menu can always be reached.

☑ 7. Optional designs for the parts of Home (Scrapbook-UIO-3)
   For: every part of Home can look the way you like, but only if you want it to. Nothing changes until a design is chosen; each part keeps its classic look by default.
   Built: the sliders button on a row in Customize home now opens an options page for Capture, Continue, Boxes, Pinned and Recent as well (the Greeting already had one).
   Each page has a preview of the real part with your own scraps on top, one segmented choice per design under it with a line saying what it looks like, and a
   Back to the classic look button once something is chosen. The row in Customize home shows the chosen design under the name.
   Designs: Greeting (classic, centered, on a card; picture left or right, next to its size sliders), Quick capture (classic, slim one line, icons only),
   Continue (classic, thin line, with a preview of the text), Boxes (chips, grid of two columns, list), Pinned (cards in a row in three sizes, list, grid of two columns),
   Recent (cards, compact lines; 3, 4, 6 or 8 scraps). The choices are saved on this phone (HomeStyles.kt, ui/HomeDesignOptions.kt, the part designs in ui/HomePage.kt).

☑ 8. Home settings moved into Customize home (Scrapbook-UIO-3.1)
   For: every part of Home keeps its own settings next to where it is moved, hidden and styled, so Settings no longer holds the ones that are only about Home.
   Built: the Header row in Customize home now has a sliders button too. Its page has a preview of the real header and two choices, Layout (left, center, round) and Size
   (compact, regular, large), which used to be "Main page header" and "Header size" in Settings. Quick capture's page gets the Add button choice (pill, bottom bar, writing bar,
   one button an arc, swipe-up sheet). Boxes' page gets the switch that orders the boxes by activity. They are the same settings as before and keep their values; the header and
   the add button still apply to the other main pages. "Show boxes on home" is gone from Settings (it is the eye on the Boxes row, as the greeting's switch was before it).
   Settings keeps the lists settings (default view, sorting, box style, note preview) and gets a Customize home row on the Home and lists page that opens Customize home;
   searching Settings for header, add button or order of boxes finds it. The About page's tips for the add button styles now say where to find them.

☑ 9. Hold menus on Home (Scrapbook-UIO-4)
   For: every box and scrap on Home needs its actions one touch away, without opening it first.
   Built: hold a box, a scrap (pinned, recent or the Continue card), a part's title (Boxes, Pinned, Recent) or the greeting, and when you let go a small pop-up menu opens next to it.
   Boxes: open, new scrap here, edit, new box inside, add to a section, delete (Inbox has its own short list: sort, color, remove). Scraps: open, pin or unpin, add to a box,
   add to a section, tags, duplicate, delete. A part's title: move up, move down, hide, Customize home. The greeting: Customize home, Account. It works in every design of
   every part, and holding a recent scrap now opens this menu instead of asking to delete it right away (ui/HomeGestures.kt, HeldScrap and HeldBox in the designs of ui/HomePage.kt).

☑ 10. Hold and drag to carry things over the whole page (Scrapbook-UIO-4)
   For: moving something should not stop at the edge of its own row.
   Built: keep holding a box or a scrap and move: it lifts, follows your finger over the whole page (not clipped by its row) and the page scrolls by itself near the top and
   bottom edge. While you carry it, the place it would land is marked: a frame around a box or a section, or a bar with "New section here" between two parts. One listener
   watches the whole page, so a tap or a scroll is never affected and a carried thing is not lost when the page scrolls under it (HomeDrag, dragHost, DragOverlay).
   Letting go on the place it came from does nothing.

☑ 11. Sections made by dropping (Scrapbook-UIO-4)
   For: a row of Home that is entirely yours: a few scraps and boxes you want together, wherever you want them.
   Built: drop a carried scrap or box on an empty spot of Home and a new section appears right there, holding it. A section has a name, one of four layouts (cards, chips,
   rows, grid) and whatever you put in it: drop more things on it, or open Edit (tap the word, or hold the title) to rename it, change the layout, take things out and add boxes
   and scraps from a list with search. Hold the title to move the section up or down, or delete it. Things inside a section can be held and carried too: to another section,
   to a box, or into the open for a new section. A section only holds shortcuts: taking something out or deleting a section never touches a scrap or a box. "Add to a section"
   in a hold menu does the same without dragging. Every drop can be undone from the message that appears. Saved on this phone (HomeSections.kt, ui/HomeSectionsUi.kt; test HomeSectionsTest).

☑ 12. Drop a scrap on a box to file it (Scrapbook-UIO-4)
   For: sorting a scrap into a box in one move, right from Home.
   Built: carry a scrap onto a box (in the Boxes row, in any of its designs, or inside a section) and let go: the box gets a frame while you are over it, and the scrap is
   moved into it, with a message to undo. Dropping on the box it is already in does nothing.

☑ 13. Gestures switches in Customize home (Scrapbook-UIO-4)
   For: hold and drag are new, so each one can be switched off.
   Built: under the list of parts in Customize home, a Gestures group with three switches: hold for a menu, hold and drag to move, drop a scrap on a box to file it.
   All on by default. With the menu off, holding a recent scrap asks to delete it again, as before (GesturePrefs, saved as gesture_hold, gesture_drag and gesture_file).


☑ 14. Menus overhaul: skins, arranging and a new skin (Scrapbook-UIO-5)
   For: the menu and the small windows of the app should be changeable: how they look, what the menu holds and in what order (item 5 of the Home list).
   Built: a menu system. One skin is worn by the Home menu and by every sheet, pop-up menu and group of rows in the app (MenuSkins.kt); Classic is the look the app had, and a new
   skin, Float, is built after the two references: a floating card with a centered title, outlined groups with a name on top (Browse, Discover, Manage), icon tiles, Cancel and the
   action side by side, a line under the buttons ("128 scraps · 12 boxes · all on this phone"), and an option to show the main button as a floating pill. On top of any skin:
   row size, icons on or off, how much the page dims, the footer line and the main button style. A new Customize menu page (menu > Customize menu, or Settings > Home and lists)
   has the skin cards with small pictures, the options, Try the menu (the real menu opens over the page), and the menu itself as a list: drag an entry to move it, the eye hides
   it, group breaks split the menu into cards, Back to the usual menu undoes it. Settings can never be hidden. Saved on this phone (MenuLayout.kt, MenuStyle.kt,
   ui/MenuSkins.kt, ui/MenuEdit.kt; tests MenuLayoutTest).
   Outcome: works well; the menu is more minimal now and the options let you build any menu. Ticked as done.

☑ 15. Greeting looks: layouts, background, picture shape, animation (Scrapbook-UIO-1.7)
   For: the greeting should look the way you want, not only sit where you want. This finishes the greeting (item 6 of the Home list).
   Built: the greeting's Style choice in Customize home has three more layouts besides Classic, Centered and Card: Bubble (a chat bubble whose small corner points at your picture,
   with the date under it), Banner (a taller block with a color wash, a bigger greeting and two soft circles) and Minimal (one small quiet line with a tiny picture, no date).
   The styles are shown as small drawings you swipe along. New choices: Background (automatic, none, card, tint, accent, gradient, outline; automatic keeps what each style always had),
   Picture shape (circle, squircle, leaf) and New line appears (fade, slide, typing, pop; typing writes the line out letter by letter). A Back to the classic look button undoes all of them.
   Nothing changes until one is chosen (HomeStyles.kt, ui/GreetingHub.kt, ui/GreetingOptions.kt; test GreetingLooksTest).

☑ 16. The account is part of the backup (Scrapbook-UIO-1.7)
   For: restoring a backup on a new phone should bring back who you are, not only your scraps.
   Built: the manual backup zip now holds account.json (name, nickname, about, pronouns, birthday, picture color) and the profile picture. Restoring only fills in what the phone does not have yet:
   a name, a birthday or a picture that is already set is never overwritten.

☑ 17. Move and zoom the profile picture (Scrapbook-UIO-1.7)
   For: the middle of a photo is not always the part you want.
   Built: choosing a photo now opens a cropper: drag the photo to move it, pinch or use the slider to zoom, and a circle shows what will be kept. Nothing is saved until Use photo.
   The photo is turned upright first and never smaller than the circle. The rules for the cut are in AvatarCrop (Account.kt, ui/AvatarCropper.kt; test AvatarCropTest).
   The cropper fills the screen, so its header sits below the status bar and its slider above the navigation bar (Scrapbook-UIO-1.8).

☑ 18. Skins of Home: wear, make, copy, rename, reset, delete (Scrapbook-UIO-8)
   For: a whole Home you can put on and take off, so you can keep more than one arrangement and switch between them any time (item 3 of the Home list; the first round of the skins update).
   Built: a Skin card at the top of Customize home shows the skin you are wearing and opens the Skins page. Each skin is a card with a small picture of its page (one bar for each part that
   shows, in order, and a tinted bar for each section), its name and what it holds. Tap a skin to wear it: Home changes at once. A skin holds which parts show and in what order, their
   designs, your sections, the header layout and size, the add button, the boxes ordering, and the size and picture of the greeting. Classic, the look Home started with, is always first and
   stays in the list. If your Home already differed from Classic, it is kept as the skin "My home" and worn, so nothing changes when you update. What you change while wearing a skin stays
   with it (it is saved into the skin when you take it off). New skin from this Home makes a copy of the Home you have and wears it, so the one you came from stays as it was. Each skin's
   menu: wear, rename, make a copy, back to the classic look, and delete (not for Classic or the skin being worn; it asks twice). Saved on this phone (HomeSkins.kt, ui/HomeSkinsUi.kt,
   ArchiveViewModel; test HomeSkinsTest). Skins are not part of the backup zip yet.

☑ 19. Sections in Customize home (Scrapbook-UIO-9)
   For: your own sections should be arranged like every other part of Home, not only from their own menu.
   Built: the sections are now rows of Customize home, between the parts, in page order. Each shows its name, its layout and how many things it holds; tap it or the sliders button to
   edit it (the same sheet as on Home), and drag its handle to move it among the parts, or to move a part past it. A section stays after the part that was before it, so moving a part
   never leaves a section behind (HomeSections.reorderSlots, ui/HomeEdit.kt).

☑ 20. Reorder inside a section (Scrapbook-UIO-9)
   For: the things of a section should be in the order you want.
   Built: hold a thing of a section, move it over another thing of the same section and let go: it takes that place and the others make room. The thing it would replace gets a frame
   while you carry it. Works in every layout of a section (HomeSections.reorder, DropTarget.Reorder).

☑ 21. Hold an empty spot to open Customize home (Scrapbook-UIO-9)
   For: the way into Customize home should be on Home itself.
   Built: hold a finger on an empty spot of Home (nothing that can be held, no part or section, and above the strip where the add button is) and Customize home opens, with a small
   vibration (HomeDrag.isEmptyAt, dragHost).

☑ 22. Swipe a recent scrap: right pins, left deletes (Scrapbook-UIO-9)
   For: pinning or throwing away a recent scrap without opening anything.
   Built: a Recent row (the cards and the compact lines) follows the finger over a colored strip with an icon: right shows the star in the accent color and pins the scrap, left shows
   the bin and deletes it. Past the line the strip turns solid and a tick tells you to let go. Deleting shows the usual Undo message, pinning has its own. Both are also actions for
   screen readers (ui/HomeSwipes.kt, SwipeRow).

☑ 23. Quick capture gestures (Scrapbook-UIO-9)
   For: starting a checklist or a voice note straight from Home.
   Built: swipe the quick capture card up: it follows the finger and a small label says when to let go, and letting go past the line opens a new checklist. Hold the card: a new
   scrap opens and starts recording a voice note. It works with the classic, slim and icons-only designs. Dragging up from the card takes the drag, so the page does not scroll with it;
   starting anywhere else, or dragging down, scrolls as always (CaptureGestures).

☑ 24. Double tap the greeting (Scrapbook-UIO-9)
   For: getting back to your work from the top of Home with no extra tap.
   Built: a double tap on the greeting opens the scrap you edited last (the default), Inbox, or nothing, chosen under Gestures in Customize home. The taps still do what they did, so a
   greeting that changes on a tap changes twice (onDoubleTap).

☑ 25. Pull the page down to search (Scrapbook-UIO-9)
   For: search is one gesture away, wherever the page is.
   Built: at the top of Home, pull the page down: a round search button slides in from the top, fills with the accent color once letting go will open search, and a tick tells you when.
   Pulling counts half of the finger's travel, scrolling back takes the pull back first and a fling never counts (PullToSearch, PullIndicator).
   Gestures in Customize home now has a switch for each of 21, 22, 23 and 25, a Jump to choice for 24, and the footer tells how to reorder a section (GesturePrefs).

☑ 26. Swipe a pinned scrap to unpin it (Scrapbook-UIO-10)
   For: taking something off the pinned ones without opening a menu, the same way a recent scrap is pinned.
   Built: in the list design of Pinned, a row follows the finger over a colored strip with an outline star, either way, and past the line it is unpinned (with an Undo message).
   Cards and grid scroll or sit side by side, where a sideways drag belongs to scrolling, so they keep the hold menu (Unpin). It follows the same Gestures switch as the Recent swipe
   (HomeActions.unpin, PinnedDesign).

☑ 27. Hold the search button for recent searches (Scrapbook-UIO-10)
   For: searching for the same thing again without opening search first.
   Built: hold the search button in Home's header and a small menu opens: New search, your last six searches (tap one and search opens with it already typed in, and it moves to the top),
   and Clear recent searches. With none yet it says so. The search button of All scraps stays a plain button (SearchHold, RecentSearchMenu, ArchiveViewModel.pendingQuery, SearchScreen).

☑ 28. Gesture settings per skin (Scrapbook-UIO-10)
   For: a skin is a whole way of using Home, so it can have its own gestures too: a quiet one with everything off, a busy one with everything on.
   Built: a skin now holds the gesture switches and the double tap choice together with the rest of its settings (SkinKeys.GESTURES, GesturePrefs.encode and decode). Wearing a skin puts its
   gestures in; changing them while wearing it stays with it, like every other setting. A skin saved before this has the usual gestures (everything on, double tap to the Continue scrap),
   except the skin you are wearing, which keeps what you have now. The Gestures group in Customize home says the settings belong to the skin worn.


☑ 29. The look of every part: corners, cards, space (Scrapbook-UIO-8.1)
   For: a skin should be able to look different all over, not only arrange the same cards: round or sharp, filled or outlined, close together or far apart.
   Built: a Look card under the Skin card in Customize home opens the Look page: a preview of the quick capture, the Continue card and the boxes stays on top, and three choices change
   every part and section of Home at once. Corners: sharp, soft (as before) or round. Cards: filled (as before), outlined (a thin line), tinted (a wash of your accent color) or flat
   (no card, the content sits on the page). Space between parts: tight, regular (as before) or roomy. Nothing changes until one is chosen. The look belongs to the skin you wear (a new
   skin piece, SkinKeys.LOOK). It is only drawn on Home: the other pages keep the classic look, and scrap cards keep their own colors, with only their corners following the look
   (HomeLook.kt, ui/HomeLookUi.kt: LocalHomeLook and Modifier.homeCard; test HomeLookTest).

☑ 30. Ready-made skins: Minimal, Bold, Dense (Scrapbook-UIO-8.1)
   For: skins that look clearly different from Classic, to start from instead of from nothing.
   Built: a Ready-made list on the Skins page, each with its small picture and a line about it. Tap one and it is added to your skins as a copy and worn (so it can be changed, renamed or
   deleted like any other, and the ready-made one stays in the list). Minimal: thin lines instead of cards, the quiet one-line greeting, slim capture, thin Continue, boxes and pinned as
   lists, three recent scraps as short lines, a compact header, To sort hidden. Bold: round tinted cards, a banner greeting, Continue with a preview, boxes and pinned in a grid, a large
   round header and roomy space. Dense: the greeting hidden, icons-only capture, everything as short lines or a grid, eight recent scraps, sharp corners and tight space.
   They hold no sections and use the usual gestures (HomeReadySkins.kt, ArchiveViewModel.wearReadySkin; test ReadySkinsTest).

☑ 31. Smart sections (Scrapbook-UIO-11)
   For: a section that stays up to date by itself, instead of one you have to fill and keep tidy.
   Built: a section can fill itself with a rule: the scraps with a tag, the scraps in a box (and the boxes inside it), or everything edited in the last week. It shows up to eight, the
   newest edited first, in any of the four layouts, and carries the word Auto beside its Edit. Make one by holding a box and choosing Section of its scraps, by holding a scrap and
   choosing Section for its tag, or by editing any section and choosing Fill automatically; a smart one can go back to Choose the things myself, keeping the scraps it shows. Scraps in it
   can be held and carried to other sections or boxes like any other; nothing can be dropped on it, because it holds nothing of its own. Saved with the section (so it belongs to a skin
   like the rest), as one more field of its line (SectionRule, HomeSections.smartScraps, ui/HomeSectionsUi.kt; tests in HomeSectionsTest).

☑ 32. Hold the add button for a menu (Scrapbook-UIO-11)
   For: starting a checklist, a photo, a link or a voice note straight from the button you already press.
   Built: hold the New scrap button on Home and a small menu opens above it: New scrap, Checklist, Photo, Link, Voice note. Tapping the button still opens an empty scrap. The other add
   buttons already have their own way (the arc button opens on hold, the bottom bar pops the + out, the writing bar has its own + and Record), so this is for the pill; on every other page
   it is just the button (AddHold, used by AddNav).

☑ 33. Gesture hints and the gesture guide (Scrapbook-UIO-11)
   For: the gestures are invisible, so Home has to say they are there.
   Built: the first time, a small card rises above the add button a moment after Home appears ("Try holding something", with Got it and All gestures). It goes for good with Got it, with the
   guide, or with the first hold. The guide is a list of every gesture with how to do it (hold, carry, change the order, hold an empty spot, swipe a scrap, quick capture, the add button, the
   greeting, search, smart sections); it opens from the card and from Gesture guide at the top of Gestures in Customize home (ui/HomeGuide.kt, ArchiveViewModel.gestureHintSeen).

☐ 34. Menus, part 2 (Scrapbook-UIO-7)
   For: everything in the menu should be yours to change or remove, and the menu to be more customizable and polished (the follow-up to item 14).
   Built: nothing in the menu is fixed any more: Settings and Customize menu can be hidden (holding the menu's title opens Customize menu from anywhere, a question comes before the last way in is hidden,
   and the page says so), the New scrap button can be another action (New checklist, photo scrap, voice memo, Search) or none, Close can go, and the title, the card names and the line under
   the buttons can be renamed or hidden. Any entry can be renamed and given another icon. New things in the menu: shortcuts to a box, a scrap, a tag or the Binder app, and group breaks; an
   optional profile header (your picture and name); accent color for icons and buttons. Two new skins, Minimal and Bento. The Customize menu page was rebuilt with three tabs (Look,
   Entries, Setups), a live picture at the top that follows every change, Try the menu, Undo, and Setups: ready-made menus (Classic, Minimal, Everything) and your own saved ones. The menu is kept
   in the backup (menu.txt, menu-presets.txt). The editor's pop-up menus take the skin's corner (MenuLayout.kt, MenuStyle.kt, ui/MenuSkins.kt, ui/MenuEdit.kt, ui/Customize.kt, ui/Home.kt,
   BinderBridge.openBinderApp, MainActivity.menuActions; tests in MenuLayoutTest).

☑ 35. Card sections: text, quote, random scrap, counter, button (Scrapbook-UIO-8.2)
   For: a section no longer has to be a row of shortcuts. A section can be one thing of its own, so a skin can have a note, a line you like, a surprise from your archive, a number or a button.
   Built: an Add a section button in Customize home (under the parts, above Back to the usual order) opens a list of what the new section can be, adds it at the end of Home and opens it for
   editing; move it with the grip like any other. Text card: a note in your own words, shown as it is (tap it to edit). Quote card: lines you like, one on each line; Home shows one a day, in
   turn, and tapping the card shows another. Random scrap: a scrap drawn from all your scraps, or from a tag, a box or this week; a different one every time Home opens, an Another button
   draws again, tapping the scrap opens it. Counter: a big number counting all your scraps, or those with a tag, in a box or edited this week, with a line saying what it counts. Button: a
   button that opens a new scrap in the box you choose (the Inbox if you choose none), with text already written if you want (a checklist can start with - [ ] ). Every card has the same
   title row as other sections (hold it for Edit, Move up, Move down, Delete, or tap Edit), its own look from the skin's Look, and an editor sheet; nothing can be dropped onto a card, and
   a card only points at your things, so deleting one never touches a scrap or a box. Cards are saved with the skin you wear and added to the same saved text as other sections; texts saved
   by earlier versions read back unchanged (HomeSections.kt: SectionCard, matching, count, counterText, pickOne, quoteOf; ui/HomeSectionsUi.kt; test SectionCardsTest).

☑ 36. Skins in the backup (Scrapbook-UIO-8.3)
   For: a new phone, or a restore, should bring your Home back as you made it, not only your scraps.
   Built: the backup zip now holds every Home skin (home-skins.txt), with the worn one as Home is at that moment. Restoring on a phone whose Home is still as new puts the worn skin on and
   adds all the skins; restoring on a phone you have already customized only adds the skins it does not have yet (by name), next to your own, and never changes what Home looks like now.
   Scraps and boxes come back first with the same keys, so sections that point at them still work. Skins from a backup that has none (older backups) are simply skipped
   (ArchiveViewModel export and restore; HomeSkins.merged; test SkinShareTest).

☑ 37. Share a skin as a code, add one from a code (Scrapbook-UIO-8.3)
   For: send a skin to a friend, or move one to another phone, without a file.
   Built: in a skin's menu, Copy as a code to share puts one line of text on the clipboard (it starts with scrapbook-skin-v1:) that any message can carry. On the Skins page, Add a skin from a
   code takes a pasted code (it may sit inside other words), shows what skin it is and adds it next to yours without putting it on; text that is not a code is refused, and a code that is too
   long is not read. A shared skin keeps its look, parts, designs, header, add button, gestures, cards and sections that fill themselves; sections of shortcuts are left out, because they point
   at one phone's scraps and boxes. The added skin gets a name of its own (Night, then Night 2 if that is taken) (SkinShare.kt, ui/HomeSkinsUi.kt, ArchiveViewModel.importSkin; test SkinShareTest).
