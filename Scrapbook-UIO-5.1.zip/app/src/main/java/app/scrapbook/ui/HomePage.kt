package app.scrapbook.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import app.scrapbook.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// The Home page, the page the app starts on: a greeting, a quick way to write something down, the scrap you were last in,
// your boxes, your pinned scraps and the latest ones. The full list lives on the All scraps page (see Home.kt).

/** "5 min ago", "2 h ago", "yesterday", then the date. */
private fun ago(ms: Long): String {
    val mins = ((System.currentTimeMillis() - ms) / 60_000).coerceAtLeast(0)
    val day = Fmt.of("yyyyMMdd")
    return when {
        mins < 1 -> "just now"
        mins < 60 -> "$mins min ago"
        day.format(Date(ms)) == day.format(Date()) -> "${mins / 60} h ago"
        day.format(Date(ms)) == day.format(Date(System.currentTimeMillis() - 86_400_000L)) -> "yesterday"
        else -> Fmt.of("MMM d").format(Date(ms))
    }
}

/** A section title with a small grey link on the right. With [hold] the row can be held for the part's own menu (move it, hide it, Customize home). */
@Composable
private fun SectionHeader(title: String, action: String, hold: PartHold? = null, onClick: () -> Unit) {
    val g = LocalHomeGestures.current
    val row: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(title, Modifier.asHeading(), fontSize = 18.sp, fontWeight = FontWeight.Medium, fontFamily = headFont())
            Text(action, Modifier.tap("$title: $action", onClick).padding(vertical = 6.dp), fontSize = 14.sp, color = Sb.mute)
        }
    }
    if (hold != null && g != null) HoldSlot(g.drag, hold.id, null, Modifier.fillMaxWidth(), menu = hold.menu, content = row) else row()
}

/** A small round button in the capture card. */
@Composable
private fun MiniBtn(icon: String, desc: String, onClick: () -> Unit) {
    Box(Modifier.pressScale(.88f).size(44.dp).clip(CircleShape).background(Sb.paper).tapIcon(desc, onClick), Alignment.Center) { Ic(icon, 20.dp, Sb.ink) }
}

/** Write something down right away: tap the line to start a blank scrap, or use a shortcut (checklist, photo, link). */
@Composable
private fun CaptureCard(onOpen: () -> Unit, onChecklist: () -> Unit, onImage: () -> Unit, onLink: () -> Unit) {
    val acc = LocalSb.current.acc
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card).padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Jot something down…", Modifier.fillMaxWidth().tap("Write a new scrap", onOpen), fontSize = 17.sp, color = Sb.mute)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MiniBtn("check", "New checklist", onChecklist); MiniBtn("image", "New scrap with a photo", onImage); MiniBtn("link", "New scrap with a link", onLink)
            }
            Row(Modifier.pressScale(.94f).heightIn(min = 44.dp).clip(CircleShape).background(acc).tap("New scrap", onOpen).padding(start = 16.dp, end = 20.dp),
                Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                Ic("plus", 18.dp, onAccent(acc)); Text("New scrap", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = onAccent(acc))
            }
        }
    }
}

/** The scrap you edited last, one tap from picking up where you left off. */
@Composable
private fun ContinueCard(n: Item, dot: Color, withPreview: Boolean = false, onOpen: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.pressScale(.98f).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card).tap("Continue ${n.title}", onOpen).padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("CONTINUE", fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = accentText(acc))
            Text(n.displayTitle, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Text("${LocalShelves.current.displayName(n.collection)} · edited ${ago(n.savedAt)}", fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (withPreview) Text(remember(n.title, n.body) { previewHead(n.title, n.body) }, Modifier.padding(top = 4.dp), fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(48.dp).clip(CircleShape).background(Sb.ink), Alignment.Center) { Ic("arrow", 22.dp, Sb.paper) }
    }
}

/** Scraps are waiting in Inbox: one tap starts sorting them. Only shown while there are some, and never when Inbox is hidden. */
@Composable
private fun SortCard(count: Int, oldestDays: Int, onOpen: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.pressScale(.98f).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card).tap("Sort Inbox, $count waiting", onOpen).padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("TO SORT", fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = accentText(acc))
            Text(if (count == 1) "1 scrap in Inbox" else "$count scraps in Inbox", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (oldestDays >= 2) "The oldest has waited $oldestDays days" else "File them, keep them close or let them go", fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(48.dp).clip(CircleShape).background(Sb.ink), Alignment.Center) { Ic("arrow", 22.dp, Sb.paper) }
    }
}

@Composable
private fun HomeChip(b: BoxTile, onClick: () -> Unit) {
    Row(Modifier.pressScale(.95f).height(48.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Open ${b.label}, ${b.count}", onClick).padding(horizontal = 20.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(b.tab))
        Text(b.label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
        Text("${b.count}", fontSize = 15.sp, color = Sb.mute)
    }
}

@Composable
private fun NewBoxChip(onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(Modifier.height(48.dp).clip(shape).dashedOutline(Sb.mute.copy(alpha = .5f), shape).tap("New box", onClick).padding(horizontal = 18.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
        Ic("plus", 18.dp, Sb.mute); Text("New box", fontSize = 16.sp, color = Sb.mute)
    }
}

@Composable
private fun PinnedCard(n: Item, preview: Boolean, modifier: Modifier = Modifier, w: Dp = 176.dp, h: Dp = 136.dp, onClick: () -> Unit) {
    Column(modifier.pressScale(.96f).then(if (w == Dp.Unspecified) Modifier.fillMaxWidth() else Modifier.width(w)).height(h).clip(RoundedCornerShape(28.dp)).background(Sb.card).tap("Open ${n.title}", onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(n.displayTitle, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.width(6.dp)); Ic("star", 14.dp, Color(0xFFFFB400))
        }
        Text(fmtDate(n.savedAt, true), fontSize = 12.sp, color = Sb.mute)
        if (preview) Text(remember(n.title, n.body) { previewHead(n.title, n.body) }, Modifier.padding(top = 6.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

// The other designs of the parts of Home (Customize home > a part's options). Each part has a classic look, which is what you get until you choose another one.

/** Capture, slim: one line to write on and a small add button. */
@Composable
private fun CaptureSlim(onOpen: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Sb.card).padding(start = 22.dp, end = 8.dp), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Text("Jot something down…", Modifier.weight(1f).tap("Write a new scrap", onOpen).padding(vertical = 20.dp), fontSize = 17.sp, color = Sb.mute)
        Box(Modifier.pressScale(.9f).size(46.dp).clip(CircleShape).background(acc).tapIcon("New scrap", onOpen), Alignment.Center) { Ic("plus", 20.dp, onAccent(acc)) }
    }
}

/** Capture, icons only: a row of round buttons. */
@Composable
private fun CaptureIcons(onOpen: () -> Unit, onChecklist: () -> Unit, onImage: () -> Unit, onLink: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Sb.card).padding(horizontal = 14.dp, vertical = 12.dp), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
        Box(Modifier.pressScale(.9f).size(52.dp).clip(CircleShape).background(acc).tapIcon("New scrap", onOpen), Alignment.Center) { Ic("edit", 22.dp, onAccent(acc)) }
        listOf(Triple("check", "New checklist", onChecklist), Triple("image", "New scrap with a photo", onImage), Triple("link", "New scrap with a link", onLink)).forEach { (icon, desc, go) ->
            Box(Modifier.pressScale(.9f).size(52.dp).clip(CircleShape).background(Sb.paper).tapIcon(desc, go), Alignment.Center) { Ic(icon, 22.dp, Sb.ink) }
        }
    }
}

/** Continue, thin: the last scrap on a single line. */
@Composable
private fun ContinueThin(n: Item, dot: Color, onOpen: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(28.dp)).background(Sb.card).tap("Continue ${n.title}", onOpen).padding(horizontal = 20.dp, vertical = 12.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Text(n.displayTitle, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(ago(n.savedAt), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
        Ic("arrow", 20.dp, Sb.mute)
    }
}

/** Boxes, grid: two columns. */
@Composable
private fun BoxCell(b: BoxTile, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.pressScale(.97f).height(52.dp).clip(RoundedCornerShape(26.dp)).background(Sb.card).tap("Open ${b.label}, ${b.count}", onClick).padding(horizontal = 18.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(b.tab))
        Text(b.label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${b.count}", fontSize = 15.sp, color = Sb.mute)
    }
}

/** Boxes, list: one box per line. */
@Composable
private fun BoxLine(b: BoxTile, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().height(56.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Open ${b.label}, ${b.count}", onClick).padding(horizontal = 20.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(b.tab))
        Text(b.label, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${b.count}", fontSize = 15.sp, color = Sb.mute)
        Ic("chevron", 18.dp, Sb.mute)
    }
}

/** Pinned, list: one pinned scrap per line. */
@Composable
private fun PinnedLine(n: Item, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Open ${n.title}", onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        Text(n.displayTitle, Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(fmtDate(n.savedAt, true), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
        Ic("star", 14.dp, Color(0xFFFFB400))
    }
}

/** Recent, compact: one short line per scrap. */
@Composable
private fun RecentLine(n: Item, dot: Color, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 52.dp).clip(RoundedCornerShape(24.dp)).background(Sb.card).tap("Open ${n.title}", onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Text(n.displayTitle, Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(fmtDate(n.savedAt, false), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
    }
}

@Composable
private fun CaptureDesign(style: Int, onOpen: () -> Unit, onChecklist: () -> Unit, onImage: () -> Unit, onLink: () -> Unit) {
    when (style) {
        1 -> CaptureSlim(onOpen)
        2 -> CaptureIcons(onOpen, onChecklist, onImage, onLink)
        else -> CaptureCard(onOpen, onChecklist, onImage, onLink)
    }
}

@Composable
private fun ContinueDesign(style: Int, n: Item, dot: Color, onOpen: () -> Unit) {
    when (style) {
        1 -> ContinueThin(n, dot, onOpen)
        else -> ContinueCard(n, dot, withPreview = style == 2, onOpen = onOpen)
    }
}

/** The boxes under their title: chips in a row, a grid of two columns (up to 8) or a list (up to 6). */
@Composable
private fun BoxesDesign(style: Int, tiles: List<BoxTile>, onOpen: (BoxTile) -> Unit, onNew: () -> Unit) {
    when (style) {
        1 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            tiles.take(8).chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                    pair.forEach { b -> HeldBox(b.name, b.label, b.tab, Modifier.weight(1f)) { BoxCell(b, Modifier.fillMaxWidth()) { onOpen(b) } } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        2 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { tiles.take(6).forEach { b -> HeldBox(b.name, b.label, b.tab) { BoxLine(b) { onOpen(b) } } } }
        else -> LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tiles, key = { it.name }) { b -> HeldBox(b.name, b.label, b.tab) { HomeChip(b) { onOpen(b) } } }
            item { NewBoxChip(onNew) }
        }
    }
}

/** The pinned scraps under their title: cards in a row (small, regular or large), a list (up to 8) or a grid of two columns (up to 6). */
@Composable
private fun PinnedDesign(style: Int, size: Int, pinned: List<Item>, preview: Boolean, onOpen: (Item) -> Unit) {
    when (style) {
        1 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { pinned.take(8).forEach { n -> HeldScrap(n, "pinned") { PinnedLine(n) { onOpen(n) } } } }
        2 -> Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            pinned.take(6).chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                    pair.forEach { n -> HeldScrap(n, "pinned", Modifier.weight(1f)) { PinnedCard(n, preview, Modifier, Dp.Unspecified, 136.dp) { onOpen(n) } } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        else -> {
            val w = listOf(148.dp, 176.dp, 224.dp)[size.coerceIn(0, 2)]
            val h = listOf(116.dp, 136.dp, 168.dp)[size.coerceIn(0, 2)]
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(pinned, key = { it.id }) { n -> HeldScrap(n, "pinned", Modifier.animateItem()) { PinnedCard(n, preview && size != 0, Modifier, w, h) { onOpen(n) } } }
            }
        }
    }
}

/** The latest scraps under their title: the usual scrap cards, or one short line each. */
@Composable
private fun RecentDesign(style: Int, recent: List<Item>, nav: NavController, dot: (Item) -> Color, onHold: (Item) -> Unit) {
    val g = LocalHomeGestures.current
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(if (style == 1) 8.dp else 12.dp)) {
        recent.forEach { n ->
            HeldScrap(n, "recent") {
                // Holding a scrap card used to ask to delete it. With the hold menu on, the menu does that (and more), so the card's own hold stays quiet.
                if (style == 1) RecentLine(n, dot(n)) { nav.navigate("edit/${n.id}") } else NoteRow(n, nav, onHold = if (g?.holdOn == true) ({}) else ({ onHold(n) }))
            }
        }
    }
}

/** The Home page: where the app starts. */
@Composable
fun HomeScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    val inboxColor by vm.inboxColor.collectAsState(); val inboxHidden by vm.inboxHidden.collectAsState()
    val welcomed by vm.welcomed.collectAsState(); val deleted by vm.deleted.collectAsState(); val header by vm.headerStyle.collectAsState()
    val navStyle by vm.navStyle.collectAsState(); val headerSize by vm.headerSize.collectAsState()
    val account by vm.account.collectAsState(); val greet by vm.greetingPrefs.collectAsState()
    // Your own sections and the gestures (hold, drag): see HomeGestures.kt and HomeSections.kt.
    val sectionsStored by vm.homeSections.collectAsState(); val gestures by vm.gesturePrefs.collectAsState()
    val drag = remember { HomeDrag() }; val listState = rememberLazyListState(); val scope = rememberCoroutineScope()
    drag.fileOn = gestures.file
    // Which parts of the page show and in what order (Customize home). While it is being customized the screen keeps its own copy, so a drag follows the finger
    // without waiting for the saved settings to come back; the copy is let go of shortly after Done.
    val stored by vm.homeLayout.collectAsState()
    var editing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf<HomeLayout?>(null) }
    // The designs chosen for the parts (their options in Customize home) are kept the same way.
    val storedStyles by vm.homeStyles.collectAsState()
    var stylesDraft by remember { mutableStateOf<HomeStyles?>(null) }
    if ((stored == null && draft == null) || (storedStyles == null && stylesDraft == null) || sectionsStored == null) { Box(Modifier.fillMaxSize().background(t.paper)); return }   // the first instant, before the saved layout is read: nothing to flash
    val layout = draft ?: stored ?: HomeLayout.Default
    val styles = stylesDraft ?: storedStyles ?: HomeStyles.Default
    val sections = sectionsStored ?: emptyList()
    // Settings has a row that leads here: it asks Home to open Customize home as soon as it shows (once).
    LaunchedEffect(Unit) { if (vm.pendingCustomize) { vm.pendingCustomize = false; draft = layout; stylesDraft = styles; editing = true } }
    LaunchedEffect(editing, stored, storedStyles) {
        if (!editing && (draft != null || stylesDraft != null)) {
            if ((draft == null || stored == draft) && (stylesDraft == null || storedStyles == stylesDraft)) { draft = null; stylesDraft = null }
            else { delay(500); draft = null; stylesDraft = null }
        }
    }
    val hs = listOf(.8f, 1f, 1.2f)[headerSize.coerceIn(0, 2)]
    val snack = remember { SnackbarHostState() }
    var menuSheet by remember { mutableStateOf(false) }; var deletingScrap by remember { mutableStateOf<Item?>(null) }
    val clipboard = LocalClipboardManager.current
    LaunchedEffect(deleted) {
        if (deleted != null) { val r = snack.showSnackbar("Scrap deleted", "Undo", duration = SnackbarDuration.Long); if (r == SnackbarResult.ActionPerformed) vm.undoDelete() else vm.clearDeleted() }
    }
    val latest = remember(all) { all.maxByOrNull { it.savedAt } }
    val waiting = remember(all) { all.toSort().size }
    val oldestDays = remember(all) { oldestWaitingDays(all, System.currentTimeMillis()) }
    val pinned = remember(all) { all.filter { it.pinned }.sortedByDescending { it.savedAt } }
    // Recent is what is not already shown above: pinned scraps have their own row and the newest one is the Continue card.
    val recentCount = HomeStyleKey.RecentCount.number(styles[HomeStyleKey.RecentCount])
    val recent = remember(all, latest, recentCount) { all.filter { !it.pinned && it.id != latest?.id }.sortedByDescending { it.savedAt }.take(recentCount) }
    // The line under a part's name in Customize home: what it is, or the design chosen for it.
    fun noteOf(e: HomeElement, base: String) = styles.summary(e).let { if (it.isEmpty()) base else "Design: $it" }
    val notes = mapOf(
        HomeElement.Header to "Menu, wordmark and search",
        HomeElement.Greeting to noteOf(HomeElement.Greeting, "Your hello and picture"),
        HomeElement.Capture to if (navStyle == ADD_BUTTON_WRITING_BAR) "Hidden while the add button is the Writing bar" else noteOf(HomeElement.Capture, "Write something down"),
        HomeElement.Continue to if (latest == null) "Shows once you have a scrap" else noteOf(HomeElement.Continue, "The scrap you edited last"),
        HomeElement.Sort to if (inboxHidden) "Inbox is hidden" else "Shows while Inbox has scraps",
        HomeElement.Boxes to noteOf(HomeElement.Boxes, "Your boxes in a row"),
        HomeElement.Pinned to if (pinned.isEmpty()) "Shows once you pin a scrap" else noteOf(HomeElement.Pinned, "${pinned.size} pinned"),
        HomeElement.Recent to noteOf(HomeElement.Recent, "The latest scraps"),
    )
    val boxesByActivity by vm.homeBoxesActive.collectAsState()
    // When each box was last worked in (its newest scrap), found in one pass over the scraps.
    val newestByBox = remember(all) { HashMap<String, Long>().also { m -> all.forEach { n -> if (n.savedAt > (m[n.collection] ?: Long.MIN_VALUE)) m[n.collection] = n.savedAt } } }
    val countByBox = remember(all) { all.groupingBy { it.collection }.eachCount() }
    val showPreview = LocalShowPreview.current
    fun colorOf(box: String): Color =
        if (box == "Inbox") (if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size])
        else shelves.firstOrNull { it.name == box }?.let { TAB_COLORS[it.color % TAB_COLORS.size] } ?: TAB_GRAY
    /** Opens a new scrap, optionally with some text already in it or straight to the photo picker. */
    fun newScrap(body: String? = null, image: Boolean = false) { vm.pendingShelf = null; vm.pendingBody = body; vm.pendingImage = image; nav.navigate("edit/0") }
    fun linkStart(): String { val c = clipboard.getText()?.text?.trim().orEmpty(); return if (Regex("^https?://\\S+$").matches(c)) c else "https://" }

    // The boxes shown on Home, in order (also used by the preview of the Boxes options).
    val inbox = countByBox["Inbox"] ?: 0
    val inboxTile = if (inboxHidden) emptyList<BoxTile>() else listOf(BoxTile("Inbox", inbox, colorOf("Inbox")))
    val tiles0 = shelves.topLevel().map { BoxTile(it.name, countByBox[it.name] ?: 0, TAB_COLORS[it.color % TAB_COLORS.size], it.label, shelves.childrenOf(it.name).size) } + inboxTile
    // The row follows your work: Inbox first while it has scraps, then the boxes you edited most recently (counting the boxes inside them), empty ones last.
    // Switch it off in Settings for your own order.
    val tiles = if (!boxesByActivity) tiles0 else remember(newestByBox, shelves, inboxHidden, tiles0) {
        val last = HashMap<String, Long>()
        shelves.topLevel().forEach { b -> shelves.subtreeKeys(b.name).mapNotNull { k -> newestByBox[k] }.maxOrNull()?.let { t0 -> last[b.name] = t0 } }
        if (!inboxHidden) newestByBox["Inbox"]?.let { t0 -> last["Inbox"] = t0 }
        orderBoxesByActivity(tiles0.map { b -> b.name }, last).mapNotNull { nm -> tiles0.firstOrNull { b -> b.name == nm } }
    }
    /** A part as it looks with the designs now chosen, for the preview in its options. Only to look at: the options page puts a layer over it that blocks taps. */
    @Composable
    fun PartPreview(el: HomeElement) {
        val none = { }
        when (el) {
            HomeElement.Header -> Box(Modifier.padding(horizontal = 16.dp)) { MainHeader(header, hs, nav, none) }
            HomeElement.Capture -> Box(Modifier.padding(horizontal = 20.dp)) { CaptureDesign(styles[HomeStyleKey.CaptureStyle], none, none, none, none) }
            HomeElement.Continue -> latest?.let { n -> Box(Modifier.padding(horizontal = 20.dp)) { ContinueDesign(styles[HomeStyleKey.ContinueStyle], n, colorOf(n.collection), none) } }
                ?: Text("Shows once you have a scrap.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute)
            HomeElement.Boxes -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Boxes", "See all", onClick = none)
                BoxesDesign(styles[HomeStyleKey.BoxesStyle], tiles, { _ -> }, none)
            }
            HomeElement.Pinned -> if (pinned.isEmpty()) Text("Shows once you pin a scrap.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute) else Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Pinned", "${pinned.size} ${if (pinned.size == 1) "scrap" else "scraps"}", onClick = none)
                PinnedDesign(styles[HomeStyleKey.PinnedStyle], styles[HomeStyleKey.PinnedSize], pinned, showPreview) { _ -> }
            }
            HomeElement.Recent -> if (recent.isEmpty()) Text("Shows once you have more scraps.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute) else Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Recent", "All scraps", onClick = none)
                RecentDesign(styles[HomeStyleKey.RecentStyle], recent, nav, { n -> colorOf(n.collection) }) { _ -> }
            }
            else -> {}
        }
    }

    // ----- Gestures (UIO 4): the menus that open when something is held, what letting go of a carried thing does, and your sections. -----
    var editBoxKey by remember { mutableStateOf<String?>(null) }; var deleteBoxKey by remember { mutableStateOf<String?>(null) }
    var newBoxIn by remember { mutableStateOf<String?>(null) }; var inboxSheet by remember { mutableStateOf(false) }
    var moveScrap by remember { mutableStateOf<Item?>(null) }; var tagScrap by remember { mutableStateOf<Item?>(null) }
    var sectionEdit by remember { mutableStateOf<String?>(null) }; var toSection by remember { mutableStateOf<SectionRef?>(null) }
    val haptics = LocalHaptics.current
    fun say(msg: String, action: String? = null, onAction: () -> Unit = {}) {
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            val r = snack.showSnackbar(msg, action, duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) onAction()
        }
    }
    fun boxLabel(key: String) = if (key == "Inbox") "Inbox" else shelves.labelOf(key)
    // The newest saved sections, read at the moment of the change, so two quick changes never undo each other.
    fun cur(): List<HomeSection> = vm.homeSections.value.orEmpty()
    fun put(list: List<HomeSection>) = vm.setHomeSections(list)
    val ops = SectionOps(
        edit = { id -> sectionEdit = id },
        move = { id, dir -> haptics.tick(); put(HomeSections.move(layout.order, layout.hidden, cur(), id, dir)) },
        delete = { id -> val before = cur(); if (sectionEdit == id) sectionEdit = null; put(HomeSections.remove(before, id)); say("Section deleted", "Undo") { put(before) } },
        rename = { id, t -> put(HomeSections.update(cur(), id) { it.copy(title = t) }) },
        layout = { id, l -> put(HomeSections.update(cur(), id) { it.copy(layout = l) }) },
        toggle = { id, r -> val has = cur().firstOrNull { it.id == id }?.has(r) == true; put(if (has) HomeSections.withoutRef(cur(), id, r) else HomeSections.withRef(cur(), id, r)) },
        remove = { id, r -> put(HomeSections.withoutRef(cur(), id, r)) },
        newWith = { r ->
            val made = HomeSection(HomeSections.newId(), "", SectionLayout.Cards, "", listOf(r))
            val before = cur()
            put(HomeSections.insert(layout.order, before, made, HomeSections.slots(layout.order, before).lastOrNull()?.key))
            say("New section created", "Edit") { sectionEdit = made.id }
        },
    )
    val actions = HomeActions(
        open = { n -> nav.navigate("edit/${n.id}") },
        openBox = { b -> nav.navigate("shelf/$b") },
        newScrapIn = { b -> vm.pendingShelf = if (b == "Inbox") null else b; vm.pendingBody = null; vm.pendingImage = false; nav.navigate("edit/0") },
        editBox = { b -> editBoxKey = b },
        newBoxIn = { b -> newBoxIn = b },
        deleteBox = { b -> deleteBoxKey = b },
        inboxColor = { inboxSheet = true },
        sortInbox = { nav.navigate("sort") },
        moveScrap = { n -> moveScrap = n },
        tagScrap = { n -> tagScrap = n },
        deleteScrap = { n -> deletingScrap = n },
        toSection = { r -> toSection = r },
        customize = { draft = layout; stylesDraft = styles; editing = true },
        account = { nav.navigate("account") },
    )
    val env = HomeEnv(vm, nav, all, shelves, countByBox, inboxHidden, { b -> colorOf(b) }, drag, actions, ops, showPreview)
    val gestureEnv = HomeGestureEnv(drag, vm, actions, gestures.hold, gestures.drag)
    fun holdOf(e: HomeElement) = PartHold("part:${e.key}") { close -> PartMenu(e, layout, { next -> vm.setHomeLayout(next) }, actions, close) }
    fun LazyListScope.sectionItems(list: List<HomeSection>) {
        list.forEach { sec -> item(key = "section-${sec.id}") { SectionBlock(sec, env, Modifier.appear("sec-${sec.id}")) } }
    }
    /** What letting go of a carried thing does: file a scrap in a box, add it to a section, or start a new section. Every one can be undone. */
    fun handleDrop(p: DragPayload, at: Offset) {
        val before = cur()
        when (val t = drag.resolve(p, at)) {
            is DropTarget.None -> {}
            is DropTarget.File -> {
                val n = all.firstOrNull { it.uid == p.ref.key }
                if (n != null) {
                    if (n.collection == t.box) say("Already in ${boxLabel(t.box)}")
                    else { vm.save(n.copy(collection = t.box)); haptics.confirm(); say("Moved to ${boxLabel(t.box)}", "Undo") { vm.save(n) } }
                }
            }
            is DropTarget.Into -> {
                put(HomeSections.moveRef(before, p.sourceSection, t.section, p.ref)); haptics.confirm()
                say("Added to ${before.firstOrNull { it.id == t.section }?.name ?: "the section"}", "Undo") { put(before) }
            }
            is DropTarget.NewAt -> {
                val made = HomeSection(HomeSections.newId(), "", SectionLayout.Cards, "", listOf(p.ref))
                val src = p.sourceSection
                val base = if (src != null) HomeSections.withoutRef(before, src, p.ref) else before
                put(HomeSections.insert(layout.order, base, made, t.after)); haptics.confirm()
                say("New section created", "Edit") { sectionEdit = made.id }
            }
        }
    }
    // While something is carried near the top or bottom edge, the page scrolls on its own so it can be taken anywhere.
    val density = LocalDensity.current
    LaunchedEffect(drag.active != null) {
        if (drag.active == null) return@LaunchedEffect
        val edge = with(density) { 96.dp.toPx() }
        val speed = with(density) { 14.dp.toPx() }
        while (true) {
            delay(16)
            val y = drag.pos.y - drag.hostOrigin.y
            val up = ((edge - y) / edge).coerceIn(0f, 1f)
            val down = if (drag.hostHeight > 0f) ((y - (drag.hostHeight - edge)) / edge).coerceIn(0f, 1f) else 0f
            if (up > 0f) listState.scrollBy(-speed * (.3f + .7f * up)) else if (down > 0f) listState.scrollBy(speed * (.3f + .7f * down))
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.paper, snackbarHost = { SnackbarHost(snack) { d -> SwipeAway({ d.dismiss() }) { Snackbar(d, shape = RoundedCornerShape(20.dp), containerColor = Sb.ink, contentColor = Sb.card, actionColor = t.acc) } } }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad).dragHost(drag, gestures.hold, gestures.drag) { p, at -> handleDrop(p, at) }) {
                if (editing) {
                    HomeCustomize(layout, notes, { next -> draft = next; vm.setHomeLayout(next) }, { editing = false }, withOptions = HomeElement.entries.filter { it.hasOptions }.toSet(),
                        options = { el, back ->
                            if (el == HomeElement.Greeting) GreetingOptions(vm, back)
                            else HomeDesignOptions(el, styles, { next -> stylesDraft = next; vm.setHomeStyles(next) }, back, extras = { openPick -> HomeExtras(el, vm, openPick) }) { PartPreview(el) }
                        },
                        footer = { GestureSettings(gestures) { vm.setGesturePrefs(it) } })
                } else {
                CompositionLocalProvider(LocalHomeGestures provides gestureEnv) {
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = navClearance(navStyle, 140.dp)), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    // A hidden header still leaves the menu button, so the menu (and Customize home with it) can always be reached.
                    if (HomeElement.Header in layout.hidden) item(key = "menu") { Box(Modifier.appear("hdr").homeBlock("header").padding(horizontal = 16.dp)) { MenuOnlyHeader { menuSheet = true } } }
                    sectionItems(sections.filter { it.anchor.isEmpty() })
                    for (el in layout.order) {
                        if (el !in layout.hidden) when (el) {
                            HomeElement.Header -> item(key = "header") { Box(Modifier.appear("hdr").homeBlock("header").padding(horizontal = 16.dp)) { MainHeader(header, hs, nav) { menuSheet = true } } }
                            HomeElement.Greeting -> item(key = "greeting") { HoldSlot(drag, "part:greeting", null, Modifier.homeBlock("greeting"), menu = { close -> GreetingMenu(actions, close) }) { GreetingHub(account, greet, all.size, if (inboxHidden) 0 else waiting, pinned.size, Modifier.appear("greet"), style = styles[HomeStyleKey.GreetingStyle], picLeft = styles[HomeStyleKey.GreetingPicture] == 1,
                            bg = styles[HomeStyleKey.GreetingBackground], shape = styles[HomeStyleKey.GreetingShape], anim = styles[HomeStyleKey.GreetingAnimation]) { nav.navigate("account") } } }
                            HomeElement.Capture -> { if (navStyle != ADD_BUTTON_WRITING_BAR) item(key = "capture") { Box(Modifier.appear("capture").homeBlock("capture").padding(horizontal = 20.dp)) { CaptureDesign(styles[HomeStyleKey.CaptureStyle], { newScrap() }, { newScrap("- [ ] ") }, { newScrap(image = true) }, { newScrap(linkStart()) }) } } }
                            HomeElement.Continue -> { latest?.let { n -> item(key = "continue") { Box(Modifier.appear("continue").homeBlock("continue").padding(horizontal = 20.dp)) { HeldScrap(n, "continue") { ContinueDesign(styles[HomeStyleKey.ContinueStyle], n, colorOf(n.collection)) { nav.navigate("edit/${n.id}") } } } } } }
                            HomeElement.Sort -> { if (waiting > 0 && !inboxHidden) item(key = "sort") { Box(Modifier.appear("sort").homeBlock("sort").padding(horizontal = 20.dp)) { SortCard(waiting, oldestDays) { nav.navigate("sort") } } } }
                            HomeElement.Boxes -> {
                                item(key = "boxes") {
                                    Column(Modifier.appear("boxes").homeBlock("boxes"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader("Boxes", "See all", holdOf(HomeElement.Boxes)) { nav.navigate("collections") }
                                        BoxesDesign(styles[HomeStyleKey.BoxesStyle], tiles, { b -> nav.navigate("shelf/${b.name}") }) { nav.navigate("collections") }
                                    }
                                }
                            }
                            HomeElement.Pinned -> {
                                if (pinned.isNotEmpty()) item(key = "pinned") {
                                    Column(Modifier.appear("pinned").homeBlock("pinned"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader("Pinned", "${pinned.size} ${if (pinned.size == 1) "scrap" else "scraps"}", holdOf(HomeElement.Pinned)) { nav.navigate("shelf/Pinned") }
                                        PinnedDesign(styles[HomeStyleKey.PinnedStyle], styles[HomeStyleKey.PinnedSize], pinned, showPreview) { n -> nav.navigate("edit/${n.id}") }
                                    }
                                }
                            }
                            HomeElement.Recent -> {
                                if (recent.isNotEmpty()) item(key = "recent") {
                                    Column(Modifier.homeBlock("recent"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        SectionHeader("Recent", "All scraps", holdOf(HomeElement.Recent)) { nav.navigate("scraps") }
                                        RecentDesign(styles[HomeStyleKey.RecentStyle], recent, nav, { n -> colorOf(n.collection) }) { n -> deletingScrap = n }
                                    }
                                } else if (all.isEmpty()) item(key = "recent") { Text(if (navStyle == 2) "No scraps yet. Write your first one below." else "No scraps yet. Write your first one above.", Modifier.padding(horizontal = 24.dp), fontSize = 15.sp, color = Sb.mute) }
                            }
                        }
                        sectionItems(sections.filter { it.anchor == el.key })
                    }
                    sectionItems(sections.filter { it.anchor.isNotEmpty() && HomeElement.of(it.anchor) == null })
                }
                }
                Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(120.dp).background(Brush.verticalGradient(listOf(Color.Transparent, t.paper))))
                val addScrap = { newScrap() }
                AddNav(navStyle, vm, nav, "Inbox", { menuSheet = true }, addScrap)
                DragOverlay(drag)
                }
            }
        }
        if (menuSheet) MenuSheet(nav, { menuSheet = false }, { vm.switcherOpen.value = true }, onCustomize = { draft = layout; stylesDraft = styles; editing = true }, summary = menuSummary(all.size, shelves.size)) { vm.pendingShelf = null }
        deletingScrap?.let { n -> DeleteScrapSheet(n, vm) { deletingScrap = null } }
        editBoxKey?.let { k -> shelves.firstOrNull { it.name == k }?.let { sh -> ShelfSheet(vm, sh, { editBoxKey = null }) } }
        newBoxIn?.let { parent -> ShelfSheet(vm, null, { newBoxIn = null }, parent = parent) }
        deleteBoxKey?.let { k -> DeleteBoxSheet(k, vm, { deleteBoxKey = null }) }
        if (inboxSheet) InboxSheet(vm) { inboxSheet = false }
        moveScrap?.let { n -> MoveSheet(n, vm) { moveScrap = null } }
        tagScrap?.let { n -> TagSheet(n, vm) { tagScrap = null } }
        sectionEdit?.let { id -> sections.firstOrNull { it.id == id }?.let { sec -> SectionSheet(sec, env) { sectionEdit = null } } }
        toSection?.let { r -> AddToSectionSheet(r, sections, ops) { toSection = null } }
        if (!welcomed) Welcome({ vm.dismissWelcome() }, { vm.addExamples() })
    }
}
