package app.scrapbook.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.Date
import kotlin.random.Random

// The greeting at the top of Home: a line that fits the time of day (and now and then the day, your scraps or your birthday), your name from the Account page and your
// picture. It changes by itself every so often (Settings > Greeting), and a tap shows another one straight away. The rules for which lines exist and which fit are in
// Greetings.kt; this file only shows them.

private data class HubStats(val scraps: Int, val inbox: Int, val pinned: Int)

@Composable
fun GreetingHub(account: Account, prefs: GreetingPrefs, scraps: Int, inbox: Int, pinned: Int, modifier: Modifier = Modifier, onProfile: () -> Unit) {
    val haptics = LocalHaptics.current
    val acc = LocalSb.current.acc
    val stats by rememberUpdatedState(HubStats(scraps, inbox, pinned))
    val acct by rememberUpdatedState(account)
    val filter = prefs.filter()
    // Everything that makes the current line wrong when it changes: a new greeting is picked at once.
    val inputs = listOf(account.callName, account.birthMonth, account.birthDay, filter)

    /** Picks a greeting for this moment, remembers it as shown, and returns it with the name and counts filled in. */
    fun pickNow(): String {
        val cal = Calendar.getInstance()
        val a = acct; val s = stats
        val month = cal.get(Calendar.MONTH) + 1; val day = cal.get(Calendar.DAY_OF_MONTH)
        val ctx = GreetingContext(
            name = a.callName, hour = cal.get(Calendar.HOUR_OF_DAY), dayOfWeek = cal.get(Calendar.DAY_OF_WEEK), month = month, day = day,
            inbox = s.inbox, scraps = s.scraps, pinned = s.pinned, birthday = a.isBirthday(month, day, Account.isLeap(cal.get(Calendar.YEAR))),
        )
        val g = Greetings.pick(ctx, filter, GreetingHistory.recent(), Random.Default)
        GreetingHistory.add(g.id)
        return Greetings.render(g, ctx)
    }

    var text by remember(inputs) { mutableStateOf(pickNow()) }
    LaunchedEffect(inputs, prefs.everySec) {
        if (prefs.everySec > 0) while (true) { delay(prefs.everySec * 1000L); text = pickNow() }
    }

    val date = remember(text) { Fmt.of("EEEE, d MMMM").format(Date()) }
    val sub = when (prefs.sub) {
        0 -> date
        1 -> account.about.lineSequence().firstOrNull().orEmpty().ifBlank { date }
        2 -> when { scraps == 0 -> "Nothing saved yet"; inbox > 0 -> "${Greetings.count(scraps)} · $inbox in Inbox"; else -> Greetings.count(scraps) }
        else -> ""
    }

    Row(modifier.fillMaxWidth().padding(horizontal = 24.dp), Arrangement.spacedBy(16.dp), Alignment.CenterVertically) {
        Column(Modifier.weight(1f).tap("Show another greeting") { haptics.tick(); text = pickNow() }) {
            if (sub.isNotEmpty()) Text(sub, fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            AnimatedContent(text, transitionSpec = { fadeIn(tween(380)) togetherWith fadeOut(tween(220)) }, label = "greeting") { line ->
                Text(line, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.4).sp)
            }
            if (!account.hasName) Text("Tell me your name", Modifier.tap("Open your account", onProfile).padding(top = 6.dp, bottom = 4.dp), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = accentText(acc))
        }
        if (prefs.avatar) AvatarView(account, 56.dp, Modifier.pressScale(.92f).tap("Open your account", onProfile))
    }
}
