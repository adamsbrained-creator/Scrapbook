package app.scrapbook

import kotlin.random.Random

// The greetings on Home: what exists, which of them fit right now, and how one is picked. Nothing here touches Android, so the rules are tested on their own
// (GreetingsTest). A greeting is a template: {name} becomes what the account is called (and disappears neatly when there is no name yet), {inbox}, {scraps}
// and {pinned} become counts like "3 scraps".

enum class Tone { Friendly, Playful, Calm }

/** Which part of the day it is. */
enum class DayPart { LateNight, EarlyMorning, Morning, Afternoon, Evening, Night }

/** Time: fits the hour or the day of the week. Casual: fits any time. Notes: talks about your scraps. Special: a birthday or New Year's Day. */
enum class GreetingKind { Time, Casual, Notes, Special }

enum class Days { Any, Weekday, Weekend, Monday, Wednesday, Friday, Sunday }

/** What must be true for a greeting to be shown. */
enum class Need { None, Inbox, NoScraps, Pinned, Many, Birthday, NewYear }

class Greeting(val text: String, val tone: Tone, val kind: GreetingKind, val part: DayPart? = null, val days: Days = Days.Any, val need: Need = Need.None) {
    /** The template itself identifies a greeting, which is what the "recently shown" list remembers. */
    val id: String get() = text
}

/** Everything the rules need to know about this moment. [dayOfWeek] is java.util.Calendar's (Sunday is 1), [month] is 1 to 12. */
class GreetingContext(
    val name: String, val hour: Int, val dayOfWeek: Int, val month: Int, val day: Int,
    val inbox: Int = 0, val scraps: Int = 0, val pinned: Int = 0, val birthday: Boolean = false,
)

/** What the person switched on: a tone (null mixes all three) and which kinds of greeting may appear. */
data class GreetingFilter(val tone: Tone? = null, val time: Boolean = true, val casual: Boolean = true, val notes: Boolean = true)

/** The Greeting settings. [tone] is 0 mixed, 1 friendly, 2 playful, 3 calm; [sub] is the line under the greeting: 0 date, 1 about me, 2 scrap count, 3 nothing. */
data class GreetingPrefs(
    val on: Boolean = true, val tone: Int = 0, val time: Boolean = true, val casual: Boolean = true, val notes: Boolean = true,
    val everySec: Int = 20, val avatar: Boolean = true, val sub: Int = 0,
) {
    fun filter() = GreetingFilter(Tone.entries.getOrNull(tone - 1), time, casual, notes)

    companion object {
        /** The choices for "Change greeting every", in seconds (0 is never). */
        val EVERY = listOf(0, 10, 20, 40, 90)
        val TONES = listOf("Mixed", "Friendly", "Playful", "Calm")
        val SUBS = listOf("Date", "About me", "Scrap count", "Nothing")
    }
}

/** The greetings shown lately, newest first, kept while the app runs so Home does not open with the same line twice in a row. */
object GreetingHistory {
    private val ids = ArrayList<String>()
    @Synchronized fun recent(): List<String> = ids.toList()
    @Synchronized fun add(id: String) { ids.remove(id); ids.add(0, id); while (ids.size > 24) ids.removeAt(ids.lastIndex) }
}

object Greetings {
    fun partOf(hour: Int): DayPart = when (hour) {
        in 0..4 -> DayPart.LateNight
        in 5..7 -> DayPart.EarlyMorning
        in 8..11 -> DayPart.Morning
        in 12..16 -> DayPart.Afternoon
        in 17..20 -> DayPart.Evening
        else -> DayPart.Night
    }

    private fun dayMatches(d: Days, dow: Int): Boolean = when (d) {
        Days.Any -> true
        Days.Weekday -> dow in 2..6
        Days.Weekend -> dow == 1 || dow == 7
        Days.Monday -> dow == 2
        Days.Wednesday -> dow == 4
        Days.Friday -> dow == 6
        Days.Sunday -> dow == 1
    }

    private fun needMet(n: Need, c: GreetingContext): Boolean = when (n) {
        Need.None -> true
        Need.Inbox -> c.inbox > 0
        Need.NoScraps -> c.scraps == 0
        Need.Pinned -> c.pinned > 0
        Need.Many -> c.scraps >= 50
        Need.Birthday -> c.birthday
        Need.NewYear -> c.month == 1 && c.day == 1
    }

    /** True when the greeting fits this moment (hour, weekday, what the scraps look like), whatever the person's switches say. */
    fun fits(g: Greeting, c: GreetingContext): Boolean =
        (g.part == null || g.part == partOf(c.hour)) && dayMatches(g.days, c.dayOfWeek) && needMet(g.need, c)

    /** "1 scrap", "3 scraps". */
    fun count(n: Int): String = if (n == 1) "1 scrap" else "$n scraps"

    /** Puts the name (or nothing, tidily) and the counts into a template. */
    fun render(g: Greeting, c: GreetingContext): String {
        var s = g.text.replace("{inbox}", count(c.inbox)).replace("{scraps}", count(c.scraps)).replace("{pinned}", count(c.pinned))
        s = if (c.name.isNotBlank()) s.replace("{name}", c.name.trim())
        else s.replace(", {name}", "").replace(" {name}", "").replace("{name}, ", "").replace("{name}", "").trim().replaceFirstChar { it.uppercaseChar() }
        return s
    }

    /** Every greeting that may be shown now. A birthday or New Year's Day greeting is only in the list on that day. */
    fun pool(c: GreetingContext, f: GreetingFilter): List<Greeting> = ALL.filter { g ->
        fits(g, c) && when (g.kind) {
            GreetingKind.Time -> f.time
            GreetingKind.Casual -> f.casual
            GreetingKind.Notes -> f.notes
            GreetingKind.Special -> true
        }
    }

    /**
     * Picks one greeting. On a birthday (or New Year's Day) most picks are the special ones. Otherwise the kind is chosen by weight (time of day 50,
     * casual 35, about your scraps 15, among the kinds that are switched on and have something to say), then the greeting by chance, never one from
     * [recent] unless nothing else is left. The tone applies to every kind that has a greeting in it; a kind without one in that tone ignores it.
     */
    fun pick(c: GreetingContext, f: GreetingFilter, recent: List<String>, random: Random): Greeting {
        val all = pool(c, f)
        val special = all.filter { it.kind == GreetingKind.Special }
        if (special.isNotEmpty() && random.nextInt(100) < 70) return choose(special, recent, random)
        val kinds = listOf(GreetingKind.Time to 50, GreetingKind.Casual to 35, GreetingKind.Notes to 15).mapNotNull { (k, w) ->
            val ofKind = all.filter { it.kind == k }
            if (ofKind.isEmpty()) null else Triple(k, w, ofKind.filter { f.tone == null || it.tone == f.tone }.ifEmpty { ofKind })
        }
        if (kinds.isEmpty()) return special.firstOrNull() ?: FALLBACK
        var roll = random.nextInt(kinds.sumOf { it.second })
        for ((_, w, list) in kinds) { if (roll < w) return choose(list, recent, random); roll -= w }
        return choose(kinds.last().third, recent, random)
    }

    private fun choose(list: List<Greeting>, recent: List<String>, random: Random): Greeting {
        val fresh = list.filter { it.id !in recent }
        return (fresh.ifEmpty { list }).let { it[random.nextInt(it.size)] }
    }

    /** Shown when every kind is switched off. */
    val FALLBACK = Greeting("Hello, {name}", Tone.Friendly, GreetingKind.Casual)

    private fun time(part: DayPart, tone: Tone, vararg lines: String) = lines.map { Greeting(it, tone, GreetingKind.Time, part) }
    private fun day(days: Days, tone: Tone, vararg lines: String) = lines.map { Greeting(it, tone, GreetingKind.Time, days = days) }
    private fun casual(tone: Tone, vararg lines: String) = lines.map { Greeting(it, tone, GreetingKind.Casual) }
    private fun notes(need: Need, tone: Tone, vararg lines: String) = lines.map { Greeting(it, tone, GreetingKind.Notes, need = need) }
    private fun special(need: Need, vararg lines: String) = lines.map { Greeting(it, Tone.Friendly, GreetingKind.Special, need = need) }

    val ALL: List<Greeting> = buildList {
        // ---- Late night, 0 to 4 ----
        addAll(time(DayPart.LateNight, Tone.Friendly, "Still up, {name}?", "Late night, {name}?", "Night work this late, {name}?", "Burning the midnight oil, {name}?", "Don't forget to sleep, {name}."))
        addAll(time(DayPart.LateNight, Tone.Playful, "Insomnia or inspiration, {name}?", "The best ideas show up after midnight, {name}.", "Night owl mode, {name}.", "Who needs sleep when there are scraps?"))
        addAll(time(DayPart.LateNight, Tone.Calm, "The quiet hours, {name}.", "Everything is still. Write something small.", "A soft hour for a few thoughts, {name}.", "Take it slow tonight, {name}."))

        // ---- Early morning, 5 to 7 ----
        addAll(time(DayPart.EarlyMorning, Tone.Friendly, "Early start, {name}!", "Up with the sun, {name}?", "Good early morning, {name}.", "Morning already, {name}."))
        addAll(time(DayPart.EarlyMorning, Tone.Playful, "The early bird gets the scraps, {name}.", "Whoa, an early one, {name}.", "Is it even light out, {name}?", "Coffee first, ideas second, {name}."))
        addAll(time(DayPart.EarlyMorning, Tone.Calm, "A gentle start to the day, {name}.", "Fresh page, fresh morning.", "The day hasn't asked anything of you yet, {name}.", "Slowly does it this morning, {name}."))

        // ---- Morning, 8 to 11 ----
        addAll(time(DayPart.Morning, Tone.Friendly, "Good morning, {name}!", "Morning, {name}. How did you sleep?", "How's your morning, {name}?", "Ready for a good day, {name}?", "Hope your morning is going well, {name}."))
        addAll(time(DayPart.Morning, Tone.Playful, "Rise and scribble, {name}.", "Morning, {name}. Coffee loaded?", "A fresh day and a blank page, {name}. Dangerous.", "Let's make today interesting, {name}."))
        addAll(time(DayPart.Morning, Tone.Calm, "A calm morning to you, {name}.", "Start small today, {name}.", "One thing at a time this morning, {name}.", "Good morning. No rush, {name}."))

        // ---- Afternoon, 12 to 16 ----
        addAll(time(DayPart.Afternoon, Tone.Friendly, "Good afternoon, {name}.", "How's your day, {name}?", "Halfway through the day, {name}.", "How is the afternoon treating you, {name}?", "Hope lunch was good, {name}."))
        addAll(time(DayPart.Afternoon, Tone.Playful, "Afternoon slump or afternoon spark, {name}?", "Post-lunch genius hour, {name}?", "The afternoon is young, {name}. So are the ideas.", "Snack, then scraps, {name}."))
        addAll(time(DayPart.Afternoon, Tone.Calm, "A slow afternoon, {name}.", "Pause for a moment, {name}.", "Breathe. The afternoon is long, {name}.", "Take the afternoon at your own pace, {name}."))

        // ---- Evening, 17 to 20 ----
        addAll(time(DayPart.Evening, Tone.Friendly, "Good evening, {name}.", "How was your day, {name}?", "Winding down, {name}?", "Evening, {name}. Anything to keep from today?", "Hope today treated you well, {name}."))
        addAll(time(DayPart.Evening, Tone.Playful, "Dinner plans or scrap plans, {name}?", "Golden hour, {name}. Good light for ideas.", "The day is done. The scrapbook is not, {name}.", "Evening, {name}. What did you collect today?"))
        addAll(time(DayPart.Evening, Tone.Calm, "The day is settling, {name}.", "Soft light, quiet page.", "Let the day land, {name}.", "An easy evening to you, {name}."))

        // ---- Night, 21 to 23 ----
        addAll(time(DayPart.Night, Tone.Friendly, "Night work, {name}?", "Still at it, {name}?", "How did today go, {name}?", "Good evening, {name}. Or is it night already?", "A late one, {name}?"))
        addAll(time(DayPart.Night, Tone.Playful, "Night shift, {name}?", "The night crowd is the best crowd.", "Moonlight and scraps, {name}.", "Are we being productive or just awake, {name}?"))
        addAll(time(DayPart.Night, Tone.Calm, "Unwind a little, {name}.", "A calm night to write, {name}.", "Put the day down here, {name}.", "Nothing more is needed tonight, {name}."))

        // ---- Days of the week ----
        addAll(day(Days.Monday, Tone.Friendly, "Monday again, {name}. You've got this.", "A new week, {name}. Clean page.", "Happy Monday, {name}."))
        addAll(day(Days.Monday, Tone.Playful, "Monday, {name}. We meet again.", "It's Monday. Be gentle with yourself, {name}."))
        addAll(day(Days.Wednesday, Tone.Playful, "Hump day, {name}.", "Midweek already, {name}. Where did Monday go?"))
        addAll(day(Days.Wednesday, Tone.Calm, "Midweek, {name}. Take a breath."))
        addAll(day(Days.Friday, Tone.Friendly, "Friday, {name}! You made it.", "The weekend is almost here, {name}.", "Happy Friday, {name}."))
        addAll(day(Days.Friday, Tone.Playful, "Friday mode: on, {name}.", "It's Friday. Everything is a good idea, {name}."))
        addAll(day(Days.Weekend, Tone.Friendly, "Happy weekend, {name}!", "Enjoying the weekend, {name}?", "No alarms today, {name}?"))
        addAll(day(Days.Weekend, Tone.Calm, "A slow weekend to you, {name}.", "Nowhere to be, {name}. Nice."))
        addAll(day(Days.Sunday, Tone.Calm, "Slow Sunday, {name}.", "A quiet Sunday, {name}."))
        addAll(day(Days.Sunday, Tone.Playful, "Sunday scraps, {name}?", "Sunday: the day for tidying and daydreaming."))
        addAll(day(Days.Weekday, Tone.Friendly, "Hope the workday is going well, {name}.", "Another day, another good idea, {name}?"))

        // ---- Casual, any time ----
        addAll(casual(Tone.Friendly, "Hey {name}.", "Good to see you, {name}.", "Welcome back, {name}.", "Hi {name}, what's on your mind?", "What are we keeping today, {name}?",
            "Nice to have you here, {name}.", "Ready when you are, {name}.", "Anything worth remembering today?", "How are you doing, {name}?", "Look who's here, {name}!",
            "Glad you stopped by, {name}.", "Hello, {name}.", "What's new, {name}?", "Back again, {name}. Good.", "How's everything, {name}?", "What caught your eye today, {name}?"))
        addAll(casual(Tone.Playful, "Well, well, {name}.", "Back for more, {name}?", "Plot twist, {name}: you showed up.", "Scrap time, {name}!", "Pens up, {name}.", "Your pages missed you.",
            "Tape's ready, {name}.", "Let's make a little mess, {name}.", "Glue sticks at the ready.", "Hello again, {name}. Fancy seeing you here.", "The scrapbook is open. Impressive timing, {name}.",
            "Ooh, {name}. What did you find?", "Got something good for me, {name}?", "Scissors out, {name}.", "Today's mission: keep one good thing, {name}.", "I was just thinking about you, {name}.", "Ta-da! You're here, {name}."))
        addAll(casual(Tone.Calm, "Take your time, {name}.", "No rush, {name}.", "A quiet page awaits.", "Breathe in. Write it down.", "Whenever you're ready, {name}.", "One thought at a time.",
            "Slow down, {name}. It's all here.", "Let it settle, {name}.", "Nothing to prove here, {name}.", "Keep what matters, {name}.", "Small notes count too, {name}.", "Just a few words is enough, {name}.", "This is your quiet corner, {name}."))

        // ---- About your scraps ----
        addAll(notes(Need.Inbox, Tone.Friendly, "{inbox} waiting in your Inbox, {name}.", "Your Inbox is holding {inbox}.", "A quick tidy? {inbox} to sort, {name}."))
        addAll(notes(Need.Inbox, Tone.Playful, "The Inbox is calling, {name}: {inbox}.", "{inbox} are waiting patiently in the Inbox, {name}."))
        addAll(notes(Need.Inbox, Tone.Calm, "{inbox} in the Inbox whenever you have a moment, {name}."))
        addAll(notes(Need.NoScraps, Tone.Friendly, "A blank scrapbook. The best kind.", "Nothing here yet, {name}. Let's change that.", "Your first scrap whenever you're ready, {name}."))
        addAll(notes(Need.NoScraps, Tone.Playful, "So much empty space, {name}. So many possibilities."))
        addAll(notes(Need.NoScraps, Tone.Calm, "A clean page. Start with one line, {name}."))
        addAll(notes(Need.Pinned, Tone.Friendly, "Your pinned scraps are close by, {name}.", "{pinned} pinned and within reach, {name}."))
        addAll(notes(Need.Pinned, Tone.Playful, "{pinned} pinned. Look at you, being organized, {name}."))
        addAll(notes(Need.Many, Tone.Friendly, "{scraps} in your scrapbook, {name}. Quite the collection.", "{scraps} and counting, {name}."))
        addAll(notes(Need.Many, Tone.Playful, "{scraps}! Is the scrapbook growing, {name}, or are you?"))
        addAll(notes(Need.Many, Tone.Calm, "{scraps} kept safe, {name}."))

        // ---- Special days ----
        addAll(special(Need.Birthday, "Happy birthday, {name}!", "It's your day, {name}!", "Many happy returns, {name}!", "Happy birthday, {name}. Keep something good from today."))
        addAll(special(Need.NewYear, "Happy New Year, {name}!", "A new year, a new page, {name}."))
    }
}
