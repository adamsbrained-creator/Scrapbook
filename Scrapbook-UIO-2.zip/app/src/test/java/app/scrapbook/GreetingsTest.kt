package app.scrapbook

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GreetingsTest {
    private fun ctx(hour: Int = 10, dow: Int = 5, month: Int = 6, day: Int = 15, name: String = "John", inbox: Int = 0, scraps: Int = 10, pinned: Int = 0, birthday: Boolean = false) =
        GreetingContext(name, hour, dow, month, day, inbox, scraps, pinned, birthday)

    @Test fun everyGreetingHasItsOwnText() = assertEquals(Greetings.ALL.size, Greetings.ALL.map { it.id }.toSet().size)
    @Test fun thereAreALotOfGreetings() = assertTrue(Greetings.ALL.size >= 150)

    @Test fun everyPartOfTheDayHasEnoughLinesInEveryTone() {
        for (p in DayPart.entries) for (t in Tone.entries) {
            val n = Greetings.ALL.count { it.kind == GreetingKind.Time && it.part == p && it.tone == t }
            assertTrue("$p $t has $n", n >= 3)
        }
    }

    @Test fun theHourFindsThePartOfTheDay() {
        assertEquals(DayPart.LateNight, Greetings.partOf(0)); assertEquals(DayPart.LateNight, Greetings.partOf(4))
        assertEquals(DayPart.EarlyMorning, Greetings.partOf(5)); assertEquals(DayPart.EarlyMorning, Greetings.partOf(7))
        assertEquals(DayPart.Morning, Greetings.partOf(8)); assertEquals(DayPart.Morning, Greetings.partOf(11))
        assertEquals(DayPart.Afternoon, Greetings.partOf(12)); assertEquals(DayPart.Afternoon, Greetings.partOf(16))
        assertEquals(DayPart.Evening, Greetings.partOf(17)); assertEquals(DayPart.Evening, Greetings.partOf(20))
        assertEquals(DayPart.Night, Greetings.partOf(21)); assertEquals(DayPart.Night, Greetings.partOf(23))
    }

    @Test fun everyGreetingRendersCleanlyWithAndWithoutAName() {
        for (name in listOf("John", "")) for (g in Greetings.ALL) {
            val s = Greetings.render(g, ctx(name = name, inbox = 3, scraps = 60, pinned = 2))
            assertFalse("braces in: $s", s.contains('{') || s.contains('}'))
            assertTrue("blank: ${g.text}", s.isNotBlank())
            assertFalse("double space in: $s", s.contains("  "))
            assertFalse("stray comma in: $s", s.contains(" ,") || s.contains(",,") || s.contains(", ."))
            assertTrue("starts small: $s", !s.first().isLowerCase())
        }
    }

    @Test fun theNameDisappearsNeatly() {
        fun g(t: String) = Greeting(t, Tone.Friendly, GreetingKind.Casual)
        assertEquals("Night work?", Greetings.render(g("Night work, {name}?"), ctx(name = "")))
        assertEquals("Hey, ready to write?", Greetings.render(g("Hey {name}, ready to write?"), ctx(name = "")))
        assertEquals("It's late.", Greetings.render(g("{name}, it's late."), ctx(name = "")))
        assertEquals("Night work, John?", Greetings.render(g("Night work, {name}?"), ctx()))
    }

    @Test fun countsAreWrittenInWords() {
        assertEquals("1 scrap", Greetings.count(1)); assertEquals("3 scraps", Greetings.count(3)); assertEquals("0 scraps", Greetings.count(0))
        val g = Greeting("{inbox} waiting, {name}.", Tone.Friendly, GreetingKind.Notes, need = Need.Inbox)
        assertEquals("1 scrap waiting, John.", Greetings.render(g, ctx(inbox = 1)))
    }

    @Test fun onlyLinesThatFitTheHourAreOffered() {
        val night = Greetings.pool(ctx(hour = 23), GreetingFilter())
        assertTrue(night.none { it.part != null && it.part != DayPart.Night })
        assertTrue(night.any { it.part == DayPart.Night })
    }

    @Test fun weekdayLinesFollowTheDay() {
        val monday = Greeting("m", Tone.Friendly, GreetingKind.Time, days = Days.Monday)
        val weekend = Greeting("w", Tone.Friendly, GreetingKind.Time, days = Days.Weekend)
        assertTrue(Greetings.fits(monday, ctx(dow = 2))); assertFalse(Greetings.fits(monday, ctx(dow = 3)))
        assertTrue(Greetings.fits(weekend, ctx(dow = 1))); assertTrue(Greetings.fits(weekend, ctx(dow = 7))); assertFalse(Greetings.fits(weekend, ctx(dow = 4)))
    }

    @Test fun linesAboutYourScrapsOnlyAppearWhenTheyAreTrue() {
        val none = Greetings.pool(ctx(inbox = 0, scraps = 10, pinned = 0), GreetingFilter())
        assertTrue(none.none { it.need == Need.Inbox || it.need == Need.Pinned || it.need == Need.Many || it.need == Need.NoScraps })
        val some = Greetings.pool(ctx(inbox = 2, scraps = 80, pinned = 1), GreetingFilter())
        assertTrue(some.any { it.need == Need.Inbox }); assertTrue(some.any { it.need == Need.Pinned }); assertTrue(some.any { it.need == Need.Many })
        assertTrue(Greetings.pool(ctx(scraps = 0), GreetingFilter()).any { it.need == Need.NoScraps })
    }

    @Test fun specialDaysOnlyOnTheirDay() {
        assertTrue(Greetings.pool(ctx(), GreetingFilter()).none { it.kind == GreetingKind.Special })
        assertTrue(Greetings.pool(ctx(birthday = true), GreetingFilter()).any { it.need == Need.Birthday })
        assertTrue(Greetings.pool(ctx(month = 1, day = 1), GreetingFilter()).any { it.need == Need.NewYear })
    }

    @Test fun mostPicksOnABirthdayAreBirthdayGreetings() {
        val r = Random(7); var specials = 0
        repeat(400) { if (Greetings.pick(ctx(birthday = true), GreetingFilter(), emptyList(), r).kind == GreetingKind.Special) specials++ }
        assertTrue("specials: $specials", specials >= 200)
    }

    @Test fun theToneIsKept() {
        val r = Random(3); val c = ctx(hour = 22)
        repeat(200) { assertEquals(Tone.Calm, Greetings.pick(c, GreetingFilter(Tone.Calm), emptyList(), r).tone) }
        repeat(200) { assertEquals(Tone.Playful, Greetings.pick(c, GreetingFilter(Tone.Playful), emptyList(), r).tone) }
    }

    @Test fun kindsThatAreSwitchedOffNeverAppear() {
        val r = Random(5); val c = ctx(inbox = 4, scraps = 80, pinned = 2)
        repeat(300) { assertEquals(GreetingKind.Time, Greetings.pick(c, GreetingFilter(null, time = true, casual = false, notes = false), emptyList(), r).kind) }
        repeat(300) { assertEquals(GreetingKind.Casual, Greetings.pick(c, GreetingFilter(null, time = false, casual = true, notes = false), emptyList(), r).kind) }
        repeat(300) { assertEquals(GreetingKind.Notes, Greetings.pick(c, GreetingFilter(null, time = false, casual = false, notes = true), emptyList(), r).kind) }
    }

    @Test fun nothingSwitchedOnGivesAPlainHello() {
        val g = Greetings.pick(ctx(), GreetingFilter(null, time = false, casual = false, notes = false), emptyList(), Random(1))
        assertEquals("Hello, John", Greetings.render(g, ctx()))
    }

    @Test fun aRecentlyShownLineIsSkippedWhileOthersRemain() {
        val c = ctx(hour = 22); val f = GreetingFilter(Tone.Calm, time = true, casual = false, notes = false)
        val calm = Greetings.pool(c, f).filter { it.tone == Tone.Calm }
        assertTrue(calm.size >= 2)
        val recent = calm.drop(1).map { it.id }
        repeat(50) { assertEquals(calm.first().id, Greetings.pick(c, f, recent, Random(it)).id) }
    }

    @Test fun whenEverythingWasShownLatelyALineIsStillPicked() {
        val c = ctx(hour = 22); val f = GreetingFilter(Tone.Calm, time = true, casual = false, notes = false)
        val all = Greetings.pool(c, f).map { it.id }
        assertTrue(Greetings.pick(c, f, all, Random(1)).id in all)
    }

    @Test fun theHistoryIsNewestFirstAndCapped() {
        repeat(40) { GreetingHistory.add("line $it") }
        val r = GreetingHistory.recent()
        assertEquals("line 39", r.first()); assertTrue(r.size <= 24)
        GreetingHistory.add("line 38")
        assertEquals("line 38", GreetingHistory.recent().first()); assertEquals(1, GreetingHistory.recent().count { it == "line 38" })
    }

    @Test fun theSettingsMapToAFilter() {
        assertEquals(null, GreetingPrefs(tone = 0).filter().tone)
        assertEquals(Tone.Friendly, GreetingPrefs(tone = 1).filter().tone)
        assertEquals(Tone.Playful, GreetingPrefs(tone = 2).filter().tone)
        assertEquals(Tone.Calm, GreetingPrefs(tone = 3).filter().tone)
        assertFalse(GreetingPrefs(casual = false).filter().casual)
    }
}
