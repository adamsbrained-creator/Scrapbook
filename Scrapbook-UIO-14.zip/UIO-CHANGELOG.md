Scrapbook — UI Overhaul (UIO) Development Log

Project: Scrapbook
Milestone: UI Overhaul (UIO)
Status: In progress
Base: Quality of Life update (scrapbook-QOL-88)

Goal: a complete overhaul of the app's look, with more customization, built section by section.
Entries are added in the order they are built. Each one says what the feature is for and what was built.

———

Section: Home

☑ 1. New greeting: account system (Scrapbook-UIO-1)
   For: the greeting needs to know who it is talking to, and the app needs a place for the person behind it.
   Built: an Account with name, nickname, a line about you, pronouns, birthday (no year) and a profile picture (photo, or initial on a chosen color).
   Stored only on this phone. New Account page, an account card at the top of Settings, a profile icon, picture cropping and saving (Avatar.kt).

☑ 2. More greeting options and views: greeting lines and settings (Scrapbook-UIO-1)
   For: a greeting that feels alive instead of the same line every day.
   Built: 170+ greetings across time of day (late night to night), weekdays, casual lines, lines about your scraps (Inbox, pinned, empty, large archive)
   and birthday / New Year's Day lines, in friendly, playful and calm voices. {name} drops out neatly when no name is set. The greeting changes by itself
   (never, 10, 20, 40 or 90 seconds), on every tap, and avoids repeating recent lines. New Settings > Greeting page: show or hide, show my picture,
   line under the greeting (date, about me, scrap count, nothing), change interval, tone, and switches for time-of-day, casual and scrap-related lines.
   The greeting on Home now uses the account's name and picture; tapping the picture opens the Account page.

☑ 3. Greeting: smaller by default, text and picture resize freely (Scrapbook-UIO-1.5)
   For: the greeting took too much room at the top of Home, and everyone wants a different size.
   Built: the greeting now starts smaller (text 24, picture 44 instead of 30 and 56). Settings > Greeting has a live preview and two sliders:
   Text size (14 to 44) and Picture size (20 to 96). The preview follows the slider while you drag, and the size is saved when you let go.
   The line under the greeting scales with the text, and a small picture still has a 44dp touch area.

☑ 4. Account card moved down in Settings (Scrapbook-UIO-1.5)
   For: the account card at the very top pushed the settings down; it belongs with the About page.
   Built: the account card now sits right above the About page, below the list of settings pages.

☑ 5. Greeting options moved into Customize home (Scrapbook-UIO-1.6)
   For: every part of Home is meant to keep its own options next to where it is moved and hidden, so the greeting's settings belong there and not in Settings.
   Built: a row in Customize home can now have a sliders button (and tapping its name does the same) that opens that part's own options page; the Greeting row has one.
   The page keeps the live preview pinned on top and holds text size, picture size, show my picture, the line under the greeting, how often it changes, the tone and the
   three switches for the kinds of lines. The Greeting page in Settings is gone (the Account card stays). Showing or hiding the greeting is still the eye on its row.
   Other parts can get their own options the same way (withOptions and options in HomeCustomize, ui/GreetingOptions.kt).

☑ 6. Home layout: move and hide every part (Scrapbook-UIO-2)
   For: Home should look the way you want it: any part can go anywhere, or be switched off.
   Built: Home is now made of eight parts (Header, Greeting, Quick capture, Continue, To sort, Boxes, Pinned, Recent), each with a place in the order and an on/off switch.
   New Customize home in the Home menu: one short row per part with a drag handle (hold and drag to move it) and an eye (tap to hide or bring it back), a Back to the usual order
   button, and Move up / Move down actions for screen readers. Hidden parts keep their place. The order and the hidden parts are saved on this phone (HomeLayout.kt, ui/HomeEdit.kt).
   Home reads the saved layout and draws its parts in that order. The old "Show greeting" and "Show boxes on home" switches in Settings now use the same on/off state,
   and an update keeps whatever they were set to. With the header hidden, a small menu button stays so the menu can always be reached.

☑ 7. Optional designs for the parts of Home (Scrapbook-UIO-3)
   For: every part of Home can look the way you like, but only if you want it to. Nothing changes until a design is chosen; each part keeps its classic look by default.
   Built: the sliders button on a row in Customize home now opens an options page for Capture, Continue, Boxes, Pinned and Recent as well (the Greeting already had one).
   Each page has a preview of the real part with your own scraps on top, one segmented choice per design under it with a line saying what it looks like, and a
   Back to the classic look button once something is chosen. The row in Customize home shows the chosen design under the name.
   Designs: Greeting (classic, centered, on a card; picture left or right, next to its size sliders), Quick capture (classic, slim one line, icons only),
   Continue (classic, thin line, with a preview of the text), Boxes (chips, grid of two columns, list), Pinned (cards in a row in three sizes, list, grid of two columns),
   Recent (cards, compact lines; 3, 4, 6 or 8 scraps). The choices are saved on this phone (HomeStyles.kt, ui/HomeDesignOptions.kt, the part designs in ui/HomePage.kt).

☑ 8. Home settings moved into Customize home (Scrapbook-UIO-3.1)
   For: every part of Home keeps its own settings next to where it is moved, hidden and styled, so Settings no longer holds the ones that are only about Home.
   Built: the Header row in Customize home now has a sliders button too. Its page has a preview of the real header and two choices, Layout (left, center, round) and Size
   (compact, regular, large), which used to be "Main page header" and "Header size" in Settings. Quick capture's page gets the Add button choice (pill, bottom bar, writing bar,
   one button an arc, swipe-up sheet). Boxes' page gets the switch that orders the boxes by activity. They are the same settings as before and keep their values; the header and
   the add button still apply to the other main pages. "Show boxes on home" is gone from Settings (it is the eye on the Boxes row, as the greeting's switch was before it).
   Settings keeps the lists settings (default view, sorting, box style, note preview) and gets a Customize home row on the Home and lists page that opens Customize home;
   searching Settings for header, add button or order of boxes finds it. The About page's tips for the add button styles now say where to find them.

☑ 9. Hold menus on Home (Scrapbook-UIO-4)
   For: every box and scrap on Home needs its actions one touch away, without opening it first.
   Built: hold a box, a scrap (pinned, recent or the Continue card), a part's title (Boxes, Pinned, Recent) or the greeting, and when you let go a small pop-up menu opens next to it.
   Boxes: open, new scrap here, edit, new box inside, add to a section, delete (Inbox has its own short list: sort, color, remove). Scraps: open, pin or unpin, add to a box,
   add to a section, tags, duplicate, delete. A part's title: move up, move down, hide, Customize home. The greeting: Customize home, Account. It works in every design of
   every part, and holding a recent scrap now opens this menu instead of asking to delete it right away (ui/HomeGestures.kt, HeldScrap and HeldBox in the designs of ui/HomePage.kt).

☑ 10. Hold and drag to carry things over the whole page (Scrapbook-UIO-4)
   For: moving something should not stop at the edge of its own row.
   Built: keep holding a box or a scrap and move: it lifts, follows your finger over the whole page (not clipped by its row) and the page scrolls by itself near the top and
   bottom edge. While you carry it, the place it would land is marked: a frame around a box or a section, or a bar with "New section here" between two parts. One listener
   watches the whole page, so a tap or a scroll is never affected and a carried thing is not lost when the page scrolls under it (HomeDrag, dragHost, DragOverlay).
   Letting go on the place it came from does nothing.

☑ 11. Sections made by dropping (Scrapbook-UIO-4)
   For: a row of Home that is entirely yours: a few scraps and boxes you want together, wherever you want them.
   Built: drop a carried scrap or box on an empty spot of Home and a new section appears right there, holding it. A section has a name, one of four layouts (cards, chips,
   rows, grid) and whatever you put in it: drop more things on it, or open Edit (tap the word, or hold the title) to rename it, change the layout, take things out and add boxes
   and scraps from a list with search. Hold the title to move the section up or down, or delete it. Things inside a section can be held and carried too: to another section,
   to a box, or into the open for a new section. A section only holds shortcuts: taking something out or deleting a section never touches a scrap or a box. "Add to a section"
   in a hold menu does the same without dragging. Every drop can be undone from the message that appears. Saved on this phone (HomeSections.kt, ui/HomeSectionsUi.kt; test HomeSectionsTest).

☑ 12. Drop a scrap on a box to file it (Scrapbook-UIO-4)
   For: sorting a scrap into a box in one move, right from Home.
   Built: carry a scrap onto a box (in the Boxes row, in any of its designs, or inside a section) and let go: the box gets a frame while you are over it, and the scrap is
   moved into it, with a message to undo. Dropping on the box it is already in does nothing.

☑ 13. Gestures switches in Customize home (Scrapbook-UIO-4)
   For: hold and drag are new, so each one can be switched off.
   Built: under the list of parts in Customize home, a Gestures group with three switches: hold for a menu, hold and drag to move, drop a scrap on a box to file it.
   All on by default. With the menu off, holding a recent scrap asks to delete it again, as before (GesturePrefs, saved as gesture_hold, gesture_drag and gesture_file).


☑ 14. Menus overhaul: skins, arranging and a new skin (Scrapbook-UIO-5)
   For: the menu and the small windows of the app should be changeable: how they look, what the menu holds and in what order (item 5 of the Home list).
   Built: a menu system. One skin is worn by the Home menu and by every sheet, pop-up menu and group of rows in the app (MenuSkins.kt); Classic is the look the app had, and a new
   skin, Float, is built after the two references: a floating card with a centered title, outlined groups with a name on top (Browse, Discover, Manage), icon tiles, Cancel and the
   action side by side, a line under the buttons ("128 scraps · 12 boxes · all on this phone"), and an option to show the main button as a floating pill. On top of any skin:
   row size, icons on or off, how much the page dims, the footer line and the main button style. A new Customize menu page (menu > Customize menu, or Settings > Home and lists)
   has the skin cards with small pictures, the options, Try the menu (the real menu opens over the page), and the menu itself as a list: drag an entry to move it, the eye hides
   it, group breaks split the menu into cards, Back to the usual menu undoes it. Settings can never be hidden. Saved on this phone (MenuLayout.kt, MenuStyle.kt,
   ui/MenuSkins.kt, ui/MenuEdit.kt; tests MenuLayoutTest).
   Outcome: works well; the menu is more minimal now and the options let you build any menu. Ticked as done.

☑ 15. Greeting looks: layouts, background, picture shape, animation (Scrapbook-UIO-1.7)
   For: the greeting should look the way you want, not only sit where you want. This finishes the greeting (item 6 of the Home list).
   Built: the greeting's Style choice in Customize home has three more layouts besides Classic, Centered and Card: Bubble (a chat bubble whose small corner points at your picture,
   with the date under it), Banner (a taller block with a color wash, a bigger greeting and two soft circles) and Minimal (one small quiet line with a tiny picture, no date).
   The styles are shown as small drawings you swipe along. New choices: Background (automatic, none, card, tint, accent, gradient, outline; automatic keeps what each style always had),
   Picture shape (circle, squircle, leaf) and New line appears (fade, slide, typing, pop; typing writes the line out letter by letter). A Back to the classic look button undoes all of them.
   Nothing changes until one is chosen (HomeStyles.kt, ui/GreetingHub.kt, ui/GreetingOptions.kt; test GreetingLooksTest).

☑ 16. The account is part of the backup (Scrapbook-UIO-1.7)
   For: restoring a backup on a new phone should bring back who you are, not only your scraps.
   Built: the manual backup zip now holds account.json (name, nickname, about, pronouns, birthday, picture color) and the profile picture. Restoring only fills in what the phone does not have yet:
   a name, a birthday or a picture that is already set is never overwritten.

☑ 17. Move and zoom the profile picture (Scrapbook-UIO-1.7)
   For: the middle of a photo is not always the part you want.
   Built: choosing a photo now opens a cropper: drag the photo to move it, pinch or use the slider to zoom, and a circle shows what will be kept. Nothing is saved until Use photo.
   The photo is turned upright first and never smaller than the circle. The rules for the cut are in AvatarCrop (Account.kt, ui/AvatarCropper.kt; test AvatarCropTest).
   The cropper fills the screen, so its header sits below the status bar and its slider above the navigation bar (Scrapbook-UIO-1.8).

☑ 18. Skins of Home: wear, make, copy, rename, reset, delete (Scrapbook-UIO-8)
   For: a whole Home you can put on and take off, so you can keep more than one arrangement and switch between them any time (item 3 of the Home list; the first round of the skins update).
   Built: a Skin card at the top of Customize home shows the skin you are wearing and opens the Skins page. Each skin is a card with a small picture of its page (one bar for each part that
   shows, in order, and a tinted bar for each section), its name and what it holds. Tap a skin to wear it: Home changes at once. A skin holds which parts show and in what order, their
   designs, your sections, the header layout and size, the add button, the boxes ordering, and the size and picture of the greeting. Classic, the look Home started with, is always first and
   stays in the list. If your Home already differed from Classic, it is kept as the skin "My home" and worn, so nothing changes when you update. What you change while wearing a skin stays
   with it (it is saved into the skin when you take it off). New skin from this Home makes a copy of the Home you have and wears it, so the one you came from stays as it was. Each skin's
   menu: wear, rename, make a copy, back to the classic look, and delete (not for Classic or the skin being worn; it asks twice). Saved on this phone (HomeSkins.kt, ui/HomeSkinsUi.kt,
   ArchiveViewModel; test HomeSkinsTest). Skins are not part of the backup zip yet.

☑ 19. Sections in Customize home (Scrapbook-UIO-9)
   For: your own sections should be arranged like every other part of Home, not only from their own menu.
   Built: the sections are now rows of Customize home, between the parts, in page order. Each shows its name, its layout and how many things it holds; tap it or the sliders button to
   edit it (the same sheet as on Home), and drag its handle to move it among the parts, or to move a part past it. A section stays after the part that was before it, so moving a part
   never leaves a section behind (HomeSections.reorderSlots, ui/HomeEdit.kt).

☑ 20. Reorder inside a section (Scrapbook-UIO-9)
   For: the things of a section should be in the order you want.
   Built: hold a thing of a section, move it over another thing of the same section and let go: it takes that place and the others make room. The thing it would replace gets a frame
   while you carry it. Works in every layout of a section (HomeSections.reorder, DropTarget.Reorder).

☑ 21. Hold an empty spot to open Customize home (Scrapbook-UIO-9)
   For: the way into Customize home should be on Home itself.
   Built: hold a finger on an empty spot of Home (nothing that can be held, no part or section, and above the strip where the add button is) and Customize home opens, with a small
   vibration (HomeDrag.isEmptyAt, dragHost).

☑ 22. Swipe a recent scrap: right pins, left deletes (Scrapbook-UIO-9)
   For: pinning or throwing away a recent scrap without opening anything.
   Built: a Recent row (the cards and the compact lines) follows the finger over a colored strip with an icon: right shows the star in the accent color and pins the scrap, left shows
   the bin and deletes it. Past the line the strip turns solid and a tick tells you to let go. Deleting shows the usual Undo message, pinning has its own. Both are also actions for
   screen readers (ui/HomeSwipes.kt, SwipeRow).

☑ 23. Quick capture gestures (Scrapbook-UIO-9)
   For: starting a checklist or a voice note straight from Home.
   Built: swipe the quick capture card up: it follows the finger and a small label says when to let go, and letting go past the line opens a new checklist. Hold the card: a new
   scrap opens and starts recording a voice note. It works with the classic, slim and icons-only designs. Dragging up from the card takes the drag, so the page does not scroll with it;
   starting anywhere else, or dragging down, scrolls as always (CaptureGestures).

☑ 24. Double tap the greeting (Scrapbook-UIO-9)
   For: getting back to your work from the top of Home with no extra tap.
   Built: a double tap on the greeting opens the scrap you edited last (the default), Inbox, or nothing, chosen under Gestures in Customize home. The taps still do what they did, so a
   greeting that changes on a tap changes twice (onDoubleTap).

☑ 25. Pull the page down to search (Scrapbook-UIO-9)
   For: search is one gesture away, wherever the page is.
   Built: at the top of Home, pull the page down: a round search button slides in from the top, fills with the accent color once letting go will open search, and a tick tells you when.
   Pulling counts half of the finger's travel, scrolling back takes the pull back first and a fling never counts (PullToSearch, PullIndicator).
   Gestures in Customize home now has a switch for each of 21, 22, 23 and 25, a Jump to choice for 24, and the footer tells how to reorder a section (GesturePrefs).

☑ 26. Swipe a pinned scrap to unpin it (Scrapbook-UIO-10)
   For: taking something off the pinned ones without opening a menu, the same way a recent scrap is pinned.
   Built: in the list design of Pinned, a row follows the finger over a colored strip with an outline star, either way, and past the line it is unpinned (with an Undo message).
   Cards and grid scroll or sit side by side, where a sideways drag belongs to scrolling, so they keep the hold menu (Unpin). It follows the same Gestures switch as the Recent swipe
   (HomeActions.unpin, PinnedDesign).

☑ 27. Hold the search button for recent searches (Scrapbook-UIO-10)
   For: searching for the same thing again without opening search first.
   Built: hold the search button in Home's header and a small menu opens: New search, your last six searches (tap one and search opens with it already typed in, and it moves to the top),
   and Clear recent searches. With none yet it says so. The search button of All scraps stays a plain button (SearchHold, RecentSearchMenu, ArchiveViewModel.pendingQuery, SearchScreen).

☑ 28. Gesture settings per skin (Scrapbook-UIO-10)
   For: a skin is a whole way of using Home, so it can have its own gestures too: a quiet one with everything off, a busy one with everything on.
   Built: a skin now holds the gesture switches and the double tap choice together with the rest of its settings (SkinKeys.GESTURES, GesturePrefs.encode and decode). Wearing a skin puts its
   gestures in; changing them while wearing it stays with it, like every other setting. A skin saved before this has the usual gestures (everything on, double tap to the Continue scrap),
   except the skin you are wearing, which keeps what you have now. The Gestures group in Customize home says the settings belong to the skin worn.


☑ 29. The look of every part: corners, cards, space (Scrapbook-UIO-8.1)
   For: a skin should be able to look different all over, not only arrange the same cards: round or sharp, filled or outlined, close together or far apart.
   Built: a Look card under the Skin card in Customize home opens the Look page: a preview of the quick capture, the Continue card and the boxes stays on top, and three choices change
   every part and section of Home at once. Corners: sharp, soft (as before) or round. Cards: filled (as before), outlined (a thin line), tinted (a wash of your accent color) or flat
   (no card, the content sits on the page). Space between parts: tight, regular (as before) or roomy. Nothing changes until one is chosen. The look belongs to the skin you wear (a new
   skin piece, SkinKeys.LOOK). It is only drawn on Home: the other pages keep the classic look, and scrap cards keep their own colors, with only their corners following the look
   (HomeLook.kt, ui/HomeLookUi.kt: LocalHomeLook and Modifier.homeCard; test HomeLookTest).

☑ 30. Ready-made skins: Minimal, Bold, Dense (Scrapbook-UIO-8.1)
   For: skins that look clearly different from Classic, to start from instead of from nothing.
   Built: a Ready-made list on the Skins page, each with its small picture and a line about it. Tap one and it is added to your skins as a copy and worn (so it can be changed, renamed or
   deleted like any other, and the ready-made one stays in the list). Minimal: thin lines instead of cards, the quiet one-line greeting, slim capture, thin Continue, boxes and pinned as
   lists, three recent scraps as short lines, a compact header, To sort hidden. Bold: round tinted cards, a banner greeting, Continue with a preview, boxes and pinned in a grid, a large
   round header and roomy space. Dense: the greeting hidden, icons-only capture, everything as short lines or a grid, eight recent scraps, sharp corners and tight space.
   They hold no sections and use the usual gestures (HomeReadySkins.kt, ArchiveViewModel.wearReadySkin; test ReadySkinsTest).

☑ 31. Smart sections (Scrapbook-UIO-11)
   For: a section that stays up to date by itself, instead of one you have to fill and keep tidy.
   Built: a section can fill itself with a rule: the scraps with a tag, the scraps in a box (and the boxes inside it), or everything edited in the last week. It shows up to eight, the
   newest edited first, in any of the four layouts, and carries the word Auto beside its Edit. Make one by holding a box and choosing Section of its scraps, by holding a scrap and
   choosing Section for its tag, or by editing any section and choosing Fill automatically; a smart one can go back to Choose the things myself, keeping the scraps it shows. Scraps in it
   can be held and carried to other sections or boxes like any other; nothing can be dropped on it, because it holds nothing of its own. Saved with the section (so it belongs to a skin
   like the rest), as one more field of its line (SectionRule, HomeSections.smartScraps, ui/HomeSectionsUi.kt; tests in HomeSectionsTest).

☑ 32. Hold the add button for a menu (Scrapbook-UIO-11)
   For: starting a checklist, a photo, a link or a voice note straight from the button you already press.
   Built: hold the New scrap button on Home and a small menu opens above it: New scrap, Checklist, Photo, Link, Voice note. Tapping the button still opens an empty scrap. The other add
   buttons already have their own way (the arc button opens on hold, the bottom bar pops the + out, the writing bar has its own + and Record), so this is for the pill; on every other page
   it is just the button (AddHold, used by AddNav).

☑ 33. Gesture hints and the gesture guide (Scrapbook-UIO-11)
   For: the gestures are invisible, so Home has to say they are there.
   Built: the first time, a small card rises above the add button a moment after Home appears ("Try holding something", with Got it and All gestures). It goes for good with Got it, with the
   guide, or with the first hold. The guide is a list of every gesture with how to do it (hold, carry, change the order, hold an empty spot, swipe a scrap, quick capture, the add button, the
   greeting, search, smart sections); it opens from the card and from Gesture guide at the top of Gestures in Customize home (ui/HomeGuide.kt, ArchiveViewModel.gestureHintSeen).

☐ 34. Menus, part 2 (Scrapbook-UIO-7)
   For: everything in the menu should be yours to change or remove, and the menu to be more customizable and polished (the follow-up to item 14).
   Built: nothing in the menu is fixed any more: Settings and Customize menu can be hidden (holding the menu's title opens Customize menu from anywhere, a question comes before the last way in is hidden,
   and the page says so), the New scrap button can be another action (New checklist, photo scrap, voice memo, Search) or none, Close can go, and the title, the card names and the line under
   the buttons can be renamed or hidden. Any entry can be renamed and given another icon. New things in the menu: shortcuts to a box, a scrap, a tag or the Binder app, and group breaks; an
   optional profile header (your picture and name); accent color for icons and buttons. Two new skins, Minimal and Bento. The Customize menu page was rebuilt with three tabs (Look,
   Entries, Setups), a live picture at the top that follows every change, Try the menu, Undo, and Setups: ready-made menus (Classic, Minimal, Everything) and your own saved ones. The menu is kept
   in the backup (menu.txt, menu-presets.txt). The editor's pop-up menus take the skin's corner (MenuLayout.kt, MenuStyle.kt, ui/MenuSkins.kt, ui/MenuEdit.kt, ui/Customize.kt, ui/Home.kt,
   BinderBridge.openBinderApp, MainActivity.menuActions; tests in MenuLayoutTest).

☑ 35. Card sections: text, quote, random scrap, counter, button (Scrapbook-UIO-8.2)
   For: a section no longer has to be a row of shortcuts. A section can be one thing of its own, so a skin can have a note, a line you like, a surprise from your archive, a number or a button.
   Built: an Add a section button in Customize home (under the parts, above Back to the usual order) opens a list of what the new section can be, adds it at the end of Home and opens it for
   editing; move it with the grip like any other. Text card: a note in your own words, shown as it is (tap it to edit). Quote card: lines you like, one on each line; Home shows one a day, in
   turn, and tapping the card shows another. Random scrap: a scrap drawn from all your scraps, or from a tag, a box or this week; a different one every time Home opens, an Another button
   draws again, tapping the scrap opens it. Counter: a big number counting all your scraps, or those with a tag, in a box or edited this week, with a line saying what it counts. Button: a
   button that opens a new scrap in the box you choose (the Inbox if you choose none), with text already written if you want (a checklist can start with - [ ] ). Every card has the same
   title row as other sections (hold it for Edit, Move up, Move down, Delete, or tap Edit), its own look from the skin's Look, and an editor sheet; nothing can be dropped onto a card, and
   a card only points at your things, so deleting one never touches a scrap or a box. Cards are saved with the skin you wear and added to the same saved text as other sections; texts saved
   by earlier versions read back unchanged (HomeSections.kt: SectionCard, matching, count, counterText, pickOne, quoteOf; ui/HomeSectionsUi.kt; test SectionCardsTest).

☑ 36. Skins in the backup (Scrapbook-UIO-8.3)
   For: a new phone, or a restore, should bring your Home back as you made it, not only your scraps.
   Built: the backup zip now holds every Home skin (home-skins.txt), with the worn one as Home is at that moment. Restoring on a phone whose Home is still as new puts the worn skin on and
   adds all the skins; restoring on a phone you have already customized only adds the skins it does not have yet (by name), next to your own, and never changes what Home looks like now.
   Scraps and boxes come back first with the same keys, so sections that point at them still work. Skins from a backup that has none (older backups) are simply skipped
   (ArchiveViewModel export and restore; HomeSkins.merged; test SkinShareTest).

☑ 37. Share a skin as a code, add one from a code (Scrapbook-UIO-8.3)
   For: send a skin to a friend, or move one to another phone, without a file.
   Built: in a skin's menu, Copy as a code to share puts one line of text on the clipboard (it starts with scrapbook-skin-v1:) that any message can carry. On the Skins page, Add a skin from a
   code takes a pasted code (it may sit inside other words), shows what skin it is and adds it next to yours without putting it on; text that is not a code is refused, and a code that is too
   long is not read. A shared skin keeps its look, parts, designs, header, add button, gestures, cards and sections that fill themselves; sections of shortcuts are left out, because they point
   at one phone's scraps and boxes. The added skin gets a name of its own (Night, then Night 2 if that is taken) (SkinShare.kt, ui/HomeSkinsUi.kt, ArchiveViewModel.importSkin; test SkinShareTest).

☑ 38. Sections with no name (Scrapbook-UIO-8.4)
   For: a clean section that is only its cards, chips or one card, without a heading above it. Before, a section with an empty name was called "New section", so a nameless one could not exist.
   Built: every section (shortcuts, smart ones and card sections) has Name on Home in its Edit window: Show the name or No name. With No name the title row is gone and the section is only its content;
   its name is kept for the lists in Customize home, where its row says "no name". Hold the section itself, on a spot that is not one of its things, for the same menu the title gives (Edit, Resize, Move up,
   Move down, Delete). Saved with the section; older saved texts read back unchanged (HomeSection.showTitle, ui/HomeSectionsUi.kt).

☑ 39. Resizable sections (Scrapbook-UIO-8.4)
   For: a section should have the size and shape you give it, not only what its layout decides. The four layouts (Cards, Chips, Rows, Grid) stay as the starting points.
   Built: Resize on Home in a section's menu (hold its title, or the section when it has no name) or in its Edit window starts resizing: a dashed frame and a round handle appear at the bottom-right
   corner of the section, drag it to any width (25 to 100 percent of the page) and height (80 to 900 dp) and tap Done; Automatic size gives the layout its say again, and Back also ends it. Edit has a Size
   part with Automatic or My size and two sliders for the same numbers. A section with a size draws to fit it: Cards are as tall as the box and a little wider than tall, Chips wrap to fill it, Rows stack, the
   Grid takes as many columns as fit and shares the height among its rows, and a card section (text, quote, random scrap, counter, button) fills the box, with a bigger number or quote in a bigger box. What does not
   fit scrolls inside the box. A scrap card shows more of its text the taller it is. Saved with the section (HomeSections.kt: width, height, widthPercent, heightDp, gridColumns, gridCellHeight, cardWidth;
   ui/HomeSectionsUi.kt: SectionFrame, cornerResize; test HomeSectionSizeTest).

☑ 40. Space below a section (Scrapbook-UIO-8.5)
   For: the space between two sections should be yours to set, not only the three steps of the Look page (Tight, Regular, Roomy), which stay as the usual space.
   Built: every section's Edit window has Space below: Automatic (the Look page's space) or My space, with a slider from 0 to 120 dp. It is the space between that section and whatever comes next on Home,
   and it can be tighter than the Look page's space as well as wider (the section only changes the height it reports, so its real place and what can be dropped on it stay as they were). Customize home says
   "own space" on the row. Saved after the size fields, only when set; older saved texts read back unchanged (HomeSection.spaceBelow, HomeSections.spaced, Modifier.moreSpaceBelow; test HomeSectionSizeTest).

☑ 41. Draw gestures: shapes that open things (Scrapbook-UIO-12)
   For: opening a box or a scrap from anywhere, with a shape of your own, without going to Home first.
   Built: draw a shape with two fingers moving together, on any page, and what you bound to it happens. A gesture can open a box (Inbox, Pinned or any box of yours), open a scrap, start a
   new scrap, start a new checklist or open search. A box that is hidden and locked is not among the boxes, so a drawing can never open it; a scrap or box that is gone says so. Boxes are
   remembered by their permanent key and scraps by their uid, so a gesture survives renaming and a backup restore. How shapes are compared (DrawGestures.kt, no Android in it): a line
   becomes 64 evenly spaced points, centered and scaled, so where and how big it was drawn does not matter, but how it was drawn does (which end first, which way round); two shapes are alike
   from the average distance of their points. It counts as a gesture from 80% alike, and only if clearly more than the next one (4 points), so two look-alikes are never mixed up.
   Saved as one line per gesture (DrawGestures.encode and decode; tests in DrawGesturesTest).

☑ 42. Two fingers, on every page (Scrapbook-UIO-12)
   For: one finger already means tap, scroll and swipe everywhere, so drawing needs a gesture of its own that never gets in the way.
   Built: one listener around all the screens (DrawGestureLayer, in MainActivity) watches for two fingers that land together and then travel together, keeping their distance. Anything else is
   left completely alone: a finger that moves first is a scroll, two fingers that pinch or turn are a zoom (full-screen photos are a separate window and never see it), and nothing is
   touched until it is clear. While drawing, a line in the accent color follows the middle of the two fingers; when they lift, a match gives a small buzz and says what it was, no match gives a
   lighter tick and says so. It is off while the app is locked, on the Draw gestures page and on the account page (whose photo cropper moves with two fingers), and when no gesture
   has been taught, so nothing changes for anyone who does not use it.

☑ 43. The Draw gestures page (Scrapbook-UIO-12)
   For: teaching a shape, trying it and managing the ones you have.
   Built: Settings > Home and lists > Draw gestures, and a row at the top of Gestures in Customize home. An on/off switch; Try it, a pad to draw on with one finger that says which gesture
   it is and how alike (and, if none, the closest and what it needed); the list of your gestures, each with a picture of its shape, what it opens and a delete button; and Add a gesture:
   draw the shape three times (a try that looks nothing like the first is refused and a short one is asked again), then choose what it opens. A shape too close to one you already have is
   refused, so the two are never mixed up. The gesture guide on Home has a line for it (ui/DrawGestureUi.kt).

☐ 44. More layouts for sections (Scrapbook-UIO-13)
   For: Edit section had four layouts (Cards, Chips, Rows, Grid); sections of boxes, scraps and smart sections needed more ways to look.
   Built: eight new layouts, for boxes, scraps and sections that fill themselves alike: Carousel (big cards that stop on each one), Hero (the first thing big, the rest as small cards under
   it), Banner (wide tinted bands with a big title), Mosaic (two columns of cards as tall as their text), Tiles (small squares, three or more across), Timeline (a line with a dot for each
   thing), Lines (a plain list with thin lines, no cards) and Compact (two columns of slim rows). Edit section now shows all twelve as small pictures, with a line about the chosen one.
   Holding and carrying things, the menus on hold and dropping a scrap on a box work in every layout; Resize works too: with a height of its own a layout scrolls (or fills it) inside the
   box. A layout is saved by its name, so skins and backups keep it, and an older version shows an unknown one as Cards (SectionLayout, SectionShapes.kt, ui/SectionLooks.kt, the picker in
   ui/HomeSectionsUi.kt; test SectionShapesTest).

☐ 45. Stack taken out of the lists (Scrapbook-UIO-13.1)
   For: the Stack layout of the lists (All scraps and every box) is not wanted.
   Built: Stack is gone from the layout picker of the lists and from Settings > Default view, with its drawing code and icon (ListLayouts.kt, Icons.kt). A page or a default view that was
   set to Stack opens as Cards. The Stack look of the Boxes screen (Nested, Shelf, Cover, Stack) is a different thing and is untouched.

☐ 46. The hold menus stay where they open (Scrapbook-UIO-13.2)
   For: holding the greeting on Home and tapping Customize home: the menu opened on the right and, a moment later, jumped to the left.
   Built: a held thing grows a little (5%) and the menu was anchored to that growing box, so its edge was a few pixels off screen and the menu was put on the right; when the finger let go
   the box shrank and the menu moved. The menu is now anchored to the box around it, which does not grow, so it opens in its place and stays there. This is for every hold menu on Home
   (the greeting, scraps, boxes, section titles, parts), since they share HoldSlot (ui/HomeGestures.kt: holdSpot and liftOnHold, which pickUp now joins).


☑ 52. Accent color and page tint for Home (Scrapbook-UIO-8.6)
   For: a skin should be able to look different in color, not only in shape.
   Built: the Look page has two more choices. Accent color: the app's own (as before) or any of the app's accent colors (coral, teal, amber, violet, green, pink, blue), as round swatches. Page tint: none (as
   before), accent (a faint wash of the accent color), warm, cool or rose, in light and in dark mode. They only change Home (its buttons, chips, add button and page), not the rest of the app, and they
   belong to the skin you wear like the rest of the Look, so each skin can have its own. Nothing changes until one is chosen, and looks saved before read back unchanged
   (HomeLook.kt: Tint, Accent; ui/HomeLookUi.kt: rememberHomeTheme, homePageColor; test SkinExtrasTest).

☑ 53. Quick switch: double tap for the next skin (Scrapbook-UIO-8.6)
   For: change the skin without opening Customize home.
   Built: Gestures in Customize home has a new choice for double tapping the greeting: Next skin. It puts on the skin after the one you wear (going round to the first after the last) and tells you which.
   The gestures belong to the skin, so give the same double tap to the skins you want to go round. The gesture guide says so (HomeSkins.following, ArchiveViewModel.nextSkin; test SkinExtrasTest).

☑ 54. Scheduled skins (Scrapbook-UIO-8.6)
   For: Minimal at night, Bold by day: Home changes skin by itself at the times you choose.
   Built: a Schedule card on the Skins page opens a list of times (up to six). Each time has a skin, a From and an Until (in half hours), and the days it applies to; Until earlier than From runs through the
   night into the next morning, and the same time twice is the whole day. Home looks at the clock when it opens and every half minute while it is on screen (not while you are customizing). Going into a time
   puts its skin on and remembers the skin you were wearing; going out of every time puts that skin back; in between, whatever you put on yourself stays on. A time whose skin was deleted does nothing, and
   deleting a time while it is on puts your skin back. Saved on this phone (it is not in the backup, because the skins of a restored backup can have new ids)
   (SkinSchedule.kt, ArchiveViewModel.tickSkinSchedule and setSkinRules, ui/HomeSkinsUi.kt: ScheduleSheet; test SkinScheduleTest).

☐ 47. Home's own parts use the new layouts (Scrapbook-UIO-13.3)
   For: the layouts were built for sections, but Continue, Boxes, Pinned and Recent, the parts Home comes with, could not use them.
   Built: in Customize home, the options of those parts end with the section layouts. Boxes and Pinned: Carousel, Hero, Banner, Mosaic, Tiles, Timeline, Lines and Compact; Recent: the same
   without Compact (it has one already); Continue: Hero and Banner (it is one scrap). They are added after the old designs, so a choice already made, a skin you saved and a backup keep
   their numbers and look the same. Holding things, their menus and carrying work in them as in the old designs; the swipe to pin or delete stays with the list designs. Boxes shows up to
   12 boxes in them and Pinned up to 10 scraps. The choices wrap onto several lines now that there are many (HomeStyles.kt, SectionShapes.kt: PartShapes, ui/SectionLooks.kt: PartShape,
   ui/HomePage.kt, ui/HomeDesignOptions.kt; tests SectionShapesTest and HomeStylesTest).


☐ 48. Holding backspace keeps repeating next to hidden marks (Scrapbook-UIO-13.4)
   For: holding the delete key in the editor sometimes stopped or slowed and had to be tapped over and over.
   Built: backspace right behind a hidden mark (bold, italic, a link, a highlight) used to rewrite the text on every single character, and every rewrite makes the keyboard restart its
   input, which ends the key repeat. It now leaves the cursor in front of those marks after the first delete, so the rest goes through the keyboard's own deleting and the hold keeps
   going; the cursor looks the same on screen (ui/Editor.kt: smartEdit).

☐ 49. Marks never show when the text inside them is deleted (Scrapbook-UIO-13.4)
   For: deleting the last letter of bold, a highlight or a color made the hidden marks appear as plain symbols ("****", "{c:34c759|}").
   Built: when a delete leaves marks with nothing inside, they are taken away with it, one inside the other as well (a color inside a highlight goes completely), so the text just
   disappears. Bold, italic, strikethrough, highlight, color, size and underline (EmptyMarks.kt, ui/Editor.kt: smartEdit; test EmptyMarksTest).

☐ 50. Enter inside formatted text, empty marks in the reading view, Edit after a link (Scrapbook-UIO-13.5)
   For: pressing Enter at the end of a highlighted title left "==" alone on the next line; marks like {c:5e5ce6|} showed in the reading view and in the editor; and Edit in the reading view
   of a scrap you reached by a link opened the editor of the scrap you came from.
   Built: Enter inside bold, italic, strikethrough, highlight, color, size or underline closes the formatting on the line above and opens it again on the new line, from the inside out,
   so at the end of the text the new line simply starts outside it and no mark is ever left alone (EmptyMarks.kt: splitMarksAtBreak, ui/Editor.kt: breakMarksAtEnter). A color, size or
   underline with nothing inside is hidden in the editor like the empty bold already was, and is left out of the reading view and the small previews (withoutEmptyMarks, ui/Pages.kt,
   Share.kt). Edit in the reading view goes back to the editor underneath only when it is the same scrap's, otherwise it opens this one (ui/Pages.kt; test SplitMarksTest).

☐ 51. More ways for marks to show, closed (Scrapbook-UIO-13.6)
   For: a look through the app for anything else that could leave bold, highlight or color marks visible as plain symbols.
   Built: (1) deleting a selection, or typing over it, that takes one end of a bold, highlight or color but not the other no longer leaves the other end behind: what is left of the pair goes
   too (EmptyMarks.kt: replaceHealingMarks, ui/Editor.kt: smartEdit). (2) Bold, italic, strikethrough or highlight on a selection over several lines now gives every line its own pair, leaves list
   marks and empty lines out, and takes them all off again when every line has them (wrapEachLine). (3) The Two Column layout of a one-line scrap no longer cuts a bold or colored run
   between the columns (balancedHalf, ui/Pages.kt). (4) The quick switcher names a scrap without a title from its first line without marks (ui/Switcher.kt). Tests: HealMarksTest, WrapLinesTest.

☑ 55. Skin pictures show the look (Scrapbook-UIO-14)
   For: a skin's small picture on the Skins page should tell skins apart by more than their order of parts.
   Built: the picture now also shows the page tint as its background, the skin's accent color for its sections, how round the bars are, how close together they sit, and whether the cards are filled,
   outlined, tinted or flat (ui/HomeSkinsUi.kt: SkinThumb). A skin without a look is drawn as before.

☑ 56. Undo for deleting or resetting a skin (Scrapbook-UIO-14)
   For: a skin is hours of work; one tap in a menu should not lose it.
   Built: after Delete or Back to the classic look on the Skins page, a bar at the bottom says what happened and offers Undo for seven seconds. Undoing a delete puts the skin back where it was in the list
   with its own id (so a schedule that used it works again), and a name taken in the meantime gets a number; undoing a reset gives the skin its pieces back, and if it is the one worn, Home goes back to them too
   (HomeSkins.restored and withValues, ArchiveViewModel.restoreSkin and restoreSkinValues; test SkinUndoTest).

☑ 57. The ready-made Bold skin on a tinted page; Settings search finds Home's settings (Scrapbook-UIO-14)
   For: the ready-made skins should show what skins can now do, and the Customize home row in Settings should be found by the new words.
   Built: Bold now has a faint wash of its accent color over the page. Searching Settings for skin, schedule, look, corners, cards, space, tint, accent color, quote, counter, button, section or gestures finds the
   Customize home row (HomeReadySkins.kt, ui/Settings.kt).

Outcome: Home (Scrapbook-UIO-1 to 14). Draft: keep it once you say Home is done, or cut it.
   Home went from one fixed page to a page that is yours. Who it greets: a greeting with your name and picture, hundreds of lines, looks and a profile that is part of the backup (1 to 5, 15 to 17).
   How it is built: eight parts you can move, hide and give another design, each with its own options and all of Home's settings in one place, Customize home (6 to 8); sections of your own that you make by
   dropping or in Customize home, that can fill themselves from a tag, a box or this week, that can be a text, a quote, a random scrap, a counter or a button, and that can be resized, reshaped and given room
   (11, 19, 20, 31, 35, 38 to 40, 44, 45). What it feels like: gestures for almost everything, each one with a switch and a guide, shapes you draw, and holds and drags that carry things around the whole page
   (9, 10, 12, 13, 21 to 28, 32, 33, 41 to 43). How it looks: skins, a whole Home you wear, copy, share as a code, keep in the backup, switch with a double tap or by the clock, with a look of their own (corners, cards,
   space, accent color, page tint) and three ready-made ones to start from (18, 29, 30, 36, 37, 52 to 57).
   Still open: Menus, part 2 (34) and the entries marked open above belong to other rounds. Skins and the look only touch Home, not the other pages. The schedule is not in the backup and is read only while Home is
   open. Everything from 8.1 on was written without a compiler to hand, so the build and the phone are the real check.
