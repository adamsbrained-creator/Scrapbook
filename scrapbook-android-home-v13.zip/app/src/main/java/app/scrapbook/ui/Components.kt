package app.scrapbook.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.Item
import app.scrapbook.plainPreview
import app.scrapbook.Kind
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage

/** Flat illustrated placeholder: sky, sun, hill. Swap for real images (Coil) later. */
@Composable
fun FlatImage(i: Int, modifier: Modifier = Modifier, radius: Dp = LocalSb.current.radius) {
    val p = Sb.palettes[i % Sb.palettes.size]
    Canvas(modifier.clip(RoundedCornerShape(radius))) {
        drawRect(p[0])
        drawCircle(p[1], size.width * .13f, Offset(size.width * .78f, size.height * .24f))
        drawOval(p[2], Offset(-size.width * .12f, size.height * .7f), Size(size.width * 1.24f, size.height * .7f))
    }
}

@Composable
fun Chip(text: String, on: Boolean = false, onClick: () -> Unit = {}) {
    val bg by animateColorAsState(if (on) Sb.ink else Sb.line.copy(alpha = .5f), tween(160), label = "chip")
    val fg by animateColorAsState(if (on) Sb.card else Sb.ink, tween(160), label = "chipText")
    Text(text, fontSize = 13.sp, color = fg,
        modifier = Modifier.pressScale(.94f).minimumInteractiveComponentSize().semantics { selected = on }.clip(CircleShape).background(bg).tap(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp))
}

@Composable
fun RoundButton(label: String, dark: Boolean = false, desc: String = label, onClick: () -> Unit) {
    Box(Modifier.pressScale(.9f).size(46.dp).clip(CircleShape).background(if (dark) Sb.ink else Sb.card)
        .border(1.dp, Sb.line, CircleShape).tap(desc, onClick).semantics { contentDescription = desc }, contentAlignment = Alignment.Center) {
        Text(label, color = if (dark) Sb.card else Sb.ink, fontSize = 16.sp)
    }
}

@Composable
fun FanStack(items: List<Item>) {
    val xs = listOf(-86, -44, 0, 46, 88); val rs = listOf(-12f, -6f, 2f, 7f, 13f)
    Box(Modifier.fillMaxWidth().height(170.dp), contentAlignment = Alignment.Center) {
        items.take(5).forEachIndexed { i, it ->
            Box(Modifier.offset(x = xs[i].dp).rotate(rs[i]).size(82.dp, 112.dp)
                .clip(RoundedCornerShape(LocalSb.current.radius)).background(Sb.notes[it.color % 5])) {
                if (it.kind == Kind.Image) ItemImage(it, Modifier.fillMaxSize())
                else Text(it.title, fontSize = 9.sp, lineHeight = 12.sp, modifier = Modifier.padding(8.dp))
            }
        }
    }
}

@Composable
fun BottomBar(onShelves: () -> Unit, onNew: () -> Unit, onSearch: () -> Unit = {}) {
    Row(Modifier.navigationBarsPadding().padding(12.dp), Arrangement.spacedBy(7.dp), Alignment.CenterVertically) {
        Text("Search", color = Sb.mute, fontSize = 12.sp,
            modifier = Modifier.weight(1f).clip(CircleShape).background(Sb.card).border(1.dp, Sb.line, CircleShape)
                .tap(onClick = onSearch).padding(horizontal = 14.dp, vertical = 12.dp))
        RoundButton("▦", desc = "Collections", onClick = onShelves)
        RoundButton("+", dark = true, desc = "New note", onClick = onNew)
    }
}

@Composable
fun RecentCard(item: Item, onClick: () -> Unit) {
    val r = LocalSb.current.radius
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(r)).background(Sb.card)
        .border(1.dp, Sb.line, RoundedCornerShape(r)).tap(onClick = onClick).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.width(5.dp).height(38.dp).clip(CircleShape).background(Sb.notes[item.color % 5]))
        Column(Modifier.weight(1f)) {
            Text(item.title, fontFamily = headFont(), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, fontSize = 13.5.sp, maxLines = 1)
            Text(plainPreview(item.body), fontSize = 10.5.sp, color = Sb.mute, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        Chip(item.collection)
    }
}

/** A picked photo when the item has one, otherwise the flat placeholder illustration. */
@Composable
fun ItemImage(item: Item, modifier: Modifier = Modifier, radius: Dp = LocalSb.current.radius) {
    if (item.imageUri != null) AsyncImage(item.imageUri, item.title, modifier.clip(RoundedCornerShape(radius)), contentScale = ContentScale.Crop)
    else FlatImage(item.color, modifier, radius)
}

/** Tap opens; a long press runs onHold (for example to delete a box). */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.tapOrHold(label: String? = null, holdLabel: String? = null, onHold: () -> Unit, onClick: () -> Unit): Modifier =
    combinedClickable(onClickLabel = label, role = Role.Button, onLongClickLabel = holdLabel, onLongClick = onHold, onClick = onClick)

/** Clickable with a Button role and an optional spoken label. */
fun Modifier.tap(label: String? = null, onClick: () -> Unit): Modifier = clickable(onClickLabel = label, role = Role.Button, onClick = onClick)

/** Same, with a 48dp minimum touch target; for text links and small icons. */
fun Modifier.link(label: String? = null, onClick: () -> Unit): Modifier = minimumInteractiveComponentSize().tap(label, onClick)

/** Plain, then five pastel page colors. selected is the stored page color (0 = plain). */
@Composable
fun ColorDots(selected: Int, onPick: (Int) -> Unit) {
    val names = listOf("Plain", "Butter", "Sage", "Blue", "Rose", "Lilac")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        names.forEachIndexed { i, n ->
            val on = i == selected
            Box(Modifier.size(34.dp).clip(CircleShape).background(if (i == 0) Sb.paper else Sb.notes[i - 1])
                .border(if (on) 2.5.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape).tap(n) { onPick(i) }.semantics { this.selected = on }, Alignment.Center) {
                if (i == 0) Ic("none", 20.dp, Sb.mute) else if (on) Ic("check", 18.dp, Sb.ink)
            }
        }
    }
}

/** App accent (the crossed circle), then five page accents. */
@Composable
fun AccentDots(selected: Int, onPick: (Int) -> Unit) {
    val names = listOf("App accent", "Coral", "Sage", "Blue", "Gold", "Violet")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        names.forEachIndexed { i, n ->
            val on = i == selected
            Box(Modifier.size(34.dp).clip(CircleShape).background(if (i == 0) Sb.paper else PAGE_ACCENTS[i - 1])
                .border(if (on) 2.5.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape).tap(n) { onPick(i) }.semantics { this.selected = on }, Alignment.Center) {
                if (i == 0) Ic("none", 20.dp, Sb.mute) else if (on) Ic("check", 18.dp, Color.White)
            }
        }
    }
}
