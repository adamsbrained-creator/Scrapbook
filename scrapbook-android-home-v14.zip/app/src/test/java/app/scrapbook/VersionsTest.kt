package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VersionsTest {
    private val minute = 60_000L
    private val day = 86_400_000L
    private val now = 1_000 * day

    private fun item(body: String, savedAt: Long, title: String = "Note") = Item(id = 1, title = title, body = body, kind = Kind.Note, collection = "Inbox", savedAt = savedAt)
    private fun version(body: String, takenAt: Long, title: String = "Note") = ItemVersion(itemId = 1, takenAt = takenAt, savedAt = takenAt, title = title, body = body)
    private val long = "word ".repeat(60)   // 300 characters

    @Test fun unchangedTextIsNotKept() = assertFalse(shouldSnapshot(item("same", now - day), item("same", now), null, now))

    @Test fun anEmptyScrapIsNotWorthKeeping() = assertFalse(shouldSnapshot(item("", now - day, title = ""), item("hello", now), null, now))

    @Test fun startingToEditAnOldScrapKeepsHowItWas() = assertTrue(shouldSnapshot(item("old text", now - day), item("old text, now longer", now), null, now))

    @Test fun typingRightAfterASaveDoesNotKeepAnything() {
        val last = version("old text", now - 2_000)
        assertFalse(shouldSnapshot(item("old text, a", now - 400), item("old text, ab", now), last, now))
    }

    @Test fun aLongSessionGetsAPointAlongTheWay() {
        val last = version("first", now - 6 * minute)
        assertTrue(shouldSnapshot(item("typed so far", now - 400), item("typed so far.", now), last, now))
    }

    @Test fun aSessionUnderFiveMinutesDoesNot() {
        val last = version("first", now - 4 * minute)
        assertFalse(shouldSnapshot(item("typed so far", now - 400), item("typed so far.", now), last, now))
    }

    @Test fun theSameTextIsNeverKeptTwice() {
        val last = version("old text", now - day)
        assertFalse(shouldSnapshot(item("old text", now - day), item("old text!", now), last, now))
    }

    @Test fun aScrapBeingWrittenGetsItsFirstVersionOnceItIsSubstantial() {
        assertTrue(shouldSnapshot(item(long, now - 400), item(long + "x", now), null, now))
        assertFalse(shouldSnapshot(item("short", now - 400), item("short!", now), null, now))
    }

    @Test fun losingHalfTheTextAtOnceIsKeptEvenMidSession() {
        val last = version("an earlier draft", now - minute)
        assertTrue(shouldSnapshot(item(long, now - 400), item("", now), last, now))
        assertTrue(shouldSnapshot(item(long, now - 400), item("word ".repeat(10), now), last, now))
    }

    @Test fun smallDeletionsMidSessionAreNotKept() {
        val last = version("an earlier draft", now - minute)
        assertFalse(shouldSnapshot(item(long, now - 400), item(long.dropLast(20), now), last, now))
    }

    @Test fun aTitleChangeCounts() = assertTrue(shouldSnapshot(item("body", now - day, title = "Old"), item("body", now, title = "New"), null, now))

    @Test fun binDaysLeftCountsStartedDays() {
        assertEquals(30, binDaysLeft(now, now))
        assertEquals(30, binDaysLeft(now, now + 1))
        assertEquals(1, binDaysLeft(now, now + 29 * day + day / 2))
        assertEquals(0, binDaysLeft(now, now + 30 * day))
        assertEquals(0, binDaysLeft(now, now + 45 * day))
    }

    @Test fun binCutoffIsThirtyDaysBack() = assertEquals(now - 30 * day, binCutoff(now))
}
