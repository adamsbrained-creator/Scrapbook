package app.scrapbook.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

// The background behind every screen (UIO 34): the plain page as always, a gradient between two colors of your choice (like a page that is warm at the top and fades to dark), or a glow:
// soft blobs of a color of your choice that drift slowly (the animated glow of Needle, in any color). The screens paint nothing as their page while one is on (SbTheme.page), so it shows
// through; the editor keeps the plain page unless it is asked to show it too. The rules and the saved form are AppBackground.kt.
// Afterglow (UIO 81) is the glow with a slanted streak of light drifting across it and a dust of twinkling stars; every part has a color of its own and can be switched off.

/** The background itself, filling its parent. Draws nothing for the plain page (the screens already paint it). */
@Composable
fun AppBackgroundLayer(bg: AppBackground, modifier: Modifier = Modifier) {
    if (!bg.active) return
    val base = Sb.paper
    val dark = Sb.dark
    val period = AppBackgrounds.periodMs(bg.speed)
    // One slow back-and-forth drives every blob (read while drawing, so the page does not recompose on each frame). A still glow stays at a pleasing place.
    val drift = if (bg.glowLike && period > 0) {
        val t = rememberInfiniteTransition(label = "backgroundGlow")
        t.animateFloat(0f, 1f, infiniteRepeatable(tween(period, easing = LinearEasing), RepeatMode.Reverse), label = "drift")
    } else null
    // The stars twinkle on their own, slow cycle (still stars when the movement is Still).
    val twinkle = if (bg.kind == AppBackground.AFTERGLOW && bg.dust > 0 && period > 0) {
        val t = rememberInfiniteTransition(label = "backgroundDust")
        t.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Restart), label = "twinkle")
    } else null
    Box(modifier.fillMaxSize().drawBehind {
        when (bg.kind) {
            AppBackground.GRADIENT -> drawGradient(bg, base)
            AppBackground.GLOW -> drawGlow(bg, base, drift?.value ?: .35f)
            AppBackground.AFTERGLOW -> drawAfterglow(bg, base, dark, drift?.value ?: .35f, twinkle?.value)
        }
    })
}

private fun DrawScope.drawGradient(bg: AppBackground, base: Color) {
    val top = rgbColor(bg.top)
    val bottom = rgbColor(bg.bottom)
    // The color holds near the top and has almost turned into the other one by the lower third, which is how a fading page reads.
    val mid = lerp(top, bottom, .75f)
    val brush = when (bg.direction) {
        1 -> Brush.linearGradient(0f to top, .7f to mid, 1f to bottom, start = Offset.Zero, end = Offset(size.width, size.height))
        2 -> Brush.verticalGradient(0f to bottom, .3f to mid, 1f to top)
        else -> Brush.verticalGradient(0f to top, .7f to mid, 1f to bottom)
    }
    drawRect(base)
    drawRect(brush)
}

private fun DrawScope.drawGlow(bg: AppBackground, base: Color, drift: Float) {
    val w = size.width
    val h = size.height
    val k = AppBackgrounds.strengthFactor(bg.strength)
    val main = rgbColor(bg.glow)
    val (n2, n3) = if (bg.mix == 1) AppBackgrounds.companions(bg.glow) else bg.glow to bg.glow
    val second = rgbColor(n2)
    val third = rgbColor(n3)
    drawRect(base)
    // A wash from the top left corner, then three soft blobs that drift sideways and up and down, then the page color again at the very bottom, behind the add button.
    drawRect(Brush.linearGradient(listOf(main.copy(alpha = (.5f * k).coerceAtMost(1f)), base.copy(alpha = 0f)), start = Offset.Zero, end = Offset(w, h * .75f)))
    fun blob(color: Color, alpha: Float, cx: Float, cy: Float, r: Float) {
        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = (alpha * k).coerceAtMost(1f)), color.copy(alpha = 0f)), center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
    }
    blob(main, .45f, w * (.1f + .3f * drift), h * .3f, w * .9f)
    blob(second, .30f, w * (.95f - .3f * drift), h * .55f, w * .8f)
    blob(third, .25f, w * .4f, h * (.85f - .1f * drift), w * .7f)
    drawRect(Brush.verticalGradient(0.85f to Color.Transparent, 1f to base.copy(alpha = .55f)))
}

/**
 * The Afterglow: the glow's wash and three drifting blobs (placed as in the design), a slanted streak of light that slides sideways while it brightens, and star dust. [twinkle] is the
 * stars' cycle (0 to 1), or null for stars that stand still at half light. In dark mode the page under it is [AppBackground.base] when one is chosen; light mode keeps the app's page.
 */
private fun DrawScope.drawAfterglow(bg: AppBackground, base: Color, dark: Boolean, drift: Float, twinkle: Float?) {
    val w = size.width
    val h = size.height
    val k = AppBackgrounds.strengthFactor(bg.strength)
    val main = rgbColor(bg.glow)
    val (n2, n3) = if (bg.mix == 1) AppBackgrounds.companions(bg.glow) else bg.glow to bg.glow
    val second = rgbColor(n2)
    val third = rgbColor(n3)
    drawRect(if (dark && bg.base >= 0) rgbColor(bg.base) else base)
    // A wash from the top left, fading out by about two thirds of the way down.
    drawRect(Brush.linearGradient(listOf(main.copy(alpha = (.34f * k).coerceAtMost(1f)), main.copy(alpha = 0f)), start = Offset.Zero, end = Offset(w * .3f, h * .65f)))
    fun blob(color: Color, alpha: Float, cx: Float, cy: Float, r: Float) {
        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = (alpha * k).coerceAtMost(1f)), color.copy(alpha = 0f)), center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
    }
    blob(main, .52f, w * (.18f + .30f * drift), h * (.14f + .04f * drift), w * .82f)
    blob(second, .34f, w * (1.10f - .30f * drift), h * (.72f - .035f * drift), w * .72f)
    blob(third, .28f, w * (.49f + .10f * drift), h * (.97f - .10f * drift), w * .67f)
    if (bg.streak == 1) {
        val color = if (bg.streakColor >= 0) rgbColor(bg.streakColor) else main
        val sw = w * .51f
        val sl = h * .90f
        val cx = w * .90f - 46.dp.toPx() * drift
        val cy = h * .75f
        val a = ((.55f + .45f * drift) * .34f * k).coerceAtMost(1f)
        rotate(32f, Offset(cx, cy)) {
            drawRect(Brush.horizontalGradient(listOf(color.copy(alpha = 0f), color.copy(alpha = a), color.copy(alpha = 0f)), startX = cx - sw / 2, endX = cx + sw / 2),
                topLeft = Offset(cx - sw / 2, cy - sl / 2), size = Size(sw, sl))
        }
    }
    val stars = AppBackgrounds.dustPoints(bg.dust)
    if (stars.isNotEmpty()) {
        // Light mode has no pale page for pale stars to show on, so they take the glow's color there.
        val star = if (dark) rgbColor(bg.dustColor) else main
        stars.forEachIndexed { i, (fx, fy) ->
            val lit = if (twinkle == null) .5f else AppBackgrounds.twinkle(twinkle, i)
            val r = (if (i % 5 == 2) 1.5.dp else 1.dp).toPx() * (.8f + .45f * lit)
            drawCircle(star.copy(alpha = .1f + .85f * lit), r, Offset(fx * w, fy * h))
        }
    }
}

/** The card color as it would be with [bg]: a veil of white when the cards are frosted or clear, otherwise as usual. */
@Composable
private fun cardFor(bg: AppBackground): Color =
    (if (bg.active) AppBackgrounds.veilAlpha(bg.cards, Sb.dark) else null)?.let { Color.White.copy(alpha = it) } ?: Sb.card

@Composable
private fun BackgroundPreview(bg: AppBackground) {
    val card = cardFor(bg)
    Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(28.dp)).background(Sb.paper).border(1.dp, Sb.line, RoundedCornerShape(28.dp))) {
        AppBackgroundLayer(bg)
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Good morning, John.", fontSize = 20.sp, fontWeight = FontWeight.Medium, fontFamily = headFont())
            listOf("Morning routine", "A scrap with a few lines").forEach { t ->
                Box(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(20.dp)).background(card).padding(horizontal = 16.dp), Alignment.CenterStart) {
                    Text(t, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

/** A color to choose: its swatch, a row of colors to start from, and (when opened) the sliders and a box for a hex code like #1D4E89. [onLive] is called while a slider moves, [onCommit] when a color is chosen. */
@Composable
private fun ColorChoice(label: String, rgb: Int, presets: List<Int>, onLive: (Int) -> Unit, onCommit: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    var hex by remember(rgb) { mutableStateOf(AppBackgrounds.hex(rgb)) }
    SettingsCard {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth().tap("$label, choose any color") { open = !open }, Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(CircleShape).background(rgbColor(rgb)).border(1.dp, Sb.line, CircleShape))
                Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("#$hex", fontSize = 14.sp, color = Sb.mute)
                Ic(if (open) "up" else "down", 18.dp, Sb.mute)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(10.dp)) {
                presets.forEach { p ->
                    val on = p == rgb
                    Box(Modifier.size(38.dp).clip(CircleShape).background(rgbColor(p)).border(if (on) 3.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape).tapIcon("Use #${AppBackgrounds.hex(p)}") { onCommit(p) })
                }
            }
            if (open) {
                RgbSliders(rgb, onLive, onCommit)
                InputBox { Field(hex, { v -> hex = v.take(7); AppBackgrounds.parseHex(v)?.let { onCommit(it) } }, "#RRGGBB", 16.sp, headFont()) }
            }
        }
    }
}

@Composable
fun BackgroundScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current
    val saved by vm.appBackground.collectAsState()
    val grey by vm.greyBg.collectAsState()
    // While a slider moves the preview follows it without saving every step; the color is saved when it is let go.
    var live by remember { mutableStateOf<AppBackground?>(null) }
    val bg = live ?: saved
    fun commit(next: AppBackground) { live = null; vm.setAppBackground(next) }
    Scaffold(containerColor = t.page) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                CircleBtn("Go back", { nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
                Box(Modifier.weight(1f), Alignment.Center) {
                    Text("scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp, maxLines = 1)
                }
                Spacer(Modifier.size(44.dp))
            }
            Text("Background", Modifier.padding(start = 28.dp, top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { BackgroundPreview(bg) }
                item { ChoiceCard("Background", listOf("Plain", "Gradient", "Glow", "Afterglow"), bg.kind, when (bg.kind) {
                    1 -> "A color at the top that fades into another one, like a page that is warm at the top and dark below."
                    2 -> "Soft blobs of a color that drift slowly behind every screen."
                    3 -> "The glow with a slanted streak of light drifting across it and a dust of twinkling stars. Each part has its own color and can be switched off."
                    else -> "The page as it always was."
                }) { commit(bg.withKind(it)) } }
                when (bg.kind) {
                    AppBackground.GRADIENT -> {
                        item { ColorChoice("Top color", bg.top, AppBackgrounds.GRADIENT_PRESETS, { live = bg.copy(top = it) }, { commit(bg.copy(top = it)) }) }
                        item { ColorChoice("Bottom color", bg.bottom, listOf(0x0B0B0B, 0x15161A, 0x101820, 0x1A1022, 0x000000, 0xFFFFFF), { live = bg.copy(bottom = it) }, { commit(bg.copy(bottom = it)) }) }
                        item { ChoiceCard("Direction", listOf("Down", "Diagonal", "Up"), bg.direction, "Which way the color fades.") { commit(bg.copy(direction = it)) } }
                    }
                    AppBackground.GLOW, AppBackground.AFTERGLOW -> {
                        item { ColorChoice("Glow color", bg.glow, AppBackgrounds.GLOW_PRESETS, { live = bg.copy(glow = it) }, { commit(bg.copy(glow = it)) }) }
                        item { ChoiceCard("Colors", listOf("One color", "Soft mix"), bg.mix, if (bg.mix == 1) "The color with its two neighbors on the color wheel." else "Only the color you chose.") { commit(bg.copy(mix = it)) } }
                        item { ChoiceCard("Strength", listOf("Soft", "Usual", "Strong"), bg.strength, null) { commit(bg.copy(strength = it)) } }
                        item { ChoiceCard("Movement", listOf("Still", "Slow", "Usual", "Fast"), bg.speed, if (bg.speed == 0) "The glow stands still." else null) { commit(bg.copy(speed = it)) } }
                        if (bg.kind == AppBackground.AFTERGLOW) {
                            item { ChoiceCard("Light streak", listOf("Off", "On"), bg.streak, "A slanted band of light that slides slowly across the page.") { commit(bg.copy(streak = it)) } }
                            if (bg.streak == 1) {
                                // The streak's color starts as the glow's own; any color can be chosen for it.
                                item { ColorChoice("Streak color", if (bg.streakColor >= 0) bg.streakColor else bg.glow, AppBackgrounds.GLOW_PRESETS, { live = bg.copy(streakColor = it) }, { commit(bg.copy(streakColor = it)) }) }
                                if (bg.streakColor >= 0) item { SettingsCard { IconRow("close", "Streak takes the glow's color") { commit(bg.copy(streakColor = AppBackground.SAME)) } } }
                            }
                            item { ChoiceCard("Star dust", listOf("None", "A few", "Many"), bg.dust, if (bg.dust > 0 && bg.speed == 0) "The stars stand still." else if (bg.dust > 0) "Tiny stars that twinkle, each in its own time." else null) { commit(bg.copy(dust = it)) } }
                            if (bg.dust > 0) item { ColorChoice("Star color", bg.dustColor, AppBackgrounds.DUST_PRESETS, { live = bg.copy(dustColor = it) }, { commit(bg.copy(dustColor = it)) }) }
                            item { ColorChoice("Dark page color", if (bg.base >= 0) bg.base else 0x0B0B0B, AppBackgrounds.BASE_PRESETS, { live = bg.copy(base = it) }, { commit(bg.copy(base = it)) }) }
                            item { HomeFooter("The dark page color is the page under the glow in dark mode. Light mode always keeps its own page, and the stars take the glow's color there.") }
                        }
                    }
                    else -> {
                        item { SettingsCard { SwitchRow("page", "Soft grey page", grey) { vm.setGreyBg(it) } } }
                        item { HomeFooter("In light mode the plain page can be a soft grey instead of white, which makes the cards stand out.") }
                    }
                }
                if (bg.active) {
                    item { ChoiceCard("Cards", listOf("Solid", "Frosted", "Clear", "Glass"), bg.cards, when (bg.cards) {
                        0 -> "Cards stay solid, as they are on the plain page."
                        2 -> "A thin white veil: the background shows through the cards."
                        3 -> "A faint white gradient with a hairline edge, like frosted glass lit from a corner."
                        else -> "A frosted white veil over the background."
                    }) { commit(bg.copy(cards = it)) } }
                    item { SettingsCard { SwitchRow("edit", "Show it in the editor too", bg.inEditor) { commit(bg.copy(inEditor = it)) } } }
                    item { HomeFooter("The editor keeps the plain page unless you turn this on, because long text is easiest to read on it.") }
                    if (!bg.readable(Sb.dark)) item {
                        Text("Text may be hard to read on this background in ${if (Sb.dark) "dark" else "light"} mode. Choose ${if (Sb.dark) "darker" else "lighter"} colors, or change the Theme.",
                            Modifier.padding(horizontal = 8.dp), fontSize = 14.sp, lineHeight = 20.sp, color = Sb.danger)
                    }
                    item { SettingsCard { IconRow("close", "Back to the plain page") { commit(AppBackground()) } } }
                }
            }
        }
    }
}
