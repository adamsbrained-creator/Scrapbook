package app.scrapbook.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.unit.dp
import app.scrapbook.*

// Settings that used to be on the Settings page and are about Home. Each lives on the options page of the part it changes (Customize home > the sliders button on its row):
// the header's look and size (HeaderSettings.kt), the add button (with Quick capture, which the Writing bar replaces), and the order of the boxes. They save at once, like everything else
// there. They are still the same settings: the header and the add button also apply to the other main pages.

/** The add button styles, in the order the saved number means them (see NavStyles.kt and Home.kt). */
val ADD_BUTTON_OPTIONS = listOf("Pill", "Bottom bar", "Writing bar", "One button, an arc", "Swipe-up sheet", "No buttons")

/** The index of No buttons in [ADD_BUTTON_OPTIONS]: nothing is drawn over the pages, so the screen is just the page. New scraps start from the menu or the quick capture card, and the swipes (Settings > Home and lists) move between pages. */
const val ADD_BUTTON_NONE = 5

/** The index of the Writing bar in [ADD_BUTTON_OPTIONS]: it holds its own writing card, so Home does not show the quick capture card with it. */
const val ADD_BUTTON_WRITING_BAR = 2

/** The extra settings of one part, under its designs. [openPick] opens a picker sheet over the options page. */
@Composable
internal fun ColumnScope.HomeExtras(el: HomeElement, vm: ArchiveViewModel, openPick: (SettingPick) -> Unit) {
    when (el) {
        HomeElement.Header -> {
            val layout by vm.headerStyle.collectAsState()
            val size by vm.headerSize.collectAsState()
            HeaderSettings(layout, size, { vm.setHeader(it) }, { vm.setHeaderSize(it) })
        }
        HomeElement.Capture -> {
            val nav by vm.navStyle.collectAsState()
            val i = nav.coerceIn(0, ADD_BUTTON_OPTIONS.lastIndex)
            SectionLabel("Add button")
            SettingsCard { IconRow("plus", "Add button", ADD_BUTTON_OPTIONS[i]) { openPick(SettingPick("Add button", ADD_BUTTON_OPTIONS, i) { vm.setNav(it) }) } }
            HomeFooter("How you start a scrap from Home and the other main pages. With the Writing bar the quick capture card is not shown, because the bar does its job. With No buttons nothing is drawn over the pages: start a scrap from the menu in the header, or from the quick capture card on Home.")
        }
        HomeElement.Boxes -> {
            val active by vm.homeBoxesActive.collectAsState()
            SectionLabel("Order")
            SettingsCard { SwitchRow("sort", "Order boxes by activity", active) { vm.setHomeBoxesActive(it) } }
            HomeFooter("On: Inbox comes first while it has scraps, then the boxes you edited most recently, empty ones last. Off: your own order.")
        }
        else -> {}
    }
}

/**
 * Customize home > Buttons: the add button and the menu button, set here whichever parts are shown (the add button used to be found only under the quick capture part, which a skin such as Timeline
 * hides). The menu button only matters while the header is hidden; with the header shown, the menu is its button. [openPick] opens a picker sheet.
 */
@Composable
internal fun ButtonsSettings(navStyle: Int, menuButton: Int, onNav: (Int) -> Unit, onMenuButton: (Int) -> Unit, openPick: (SettingPick) -> Unit) {
    val nav = navStyle.coerceIn(0, ADD_BUTTON_OPTIONS.lastIndex)
    val key = HomeStyleKey.MenuButton
    val menu = menuButton.coerceIn(0, key.options.lastIndex)
    SectionLabel("Buttons")
    SettingsCard {
        IconRow("plus", "Add button", ADD_BUTTON_OPTIONS[nav]) { openPick(SettingPick("Add button", ADD_BUTTON_OPTIONS, nav) { onNav(it) }) }
        RowLine()
        IconRow("menu", "Menu button", key.options[menu]) { openPick(SettingPick("Menu button when the header is hidden", key.options, menu, note = key.hints[menu]) { onMenuButton(it) }) }
    }
    HomeFooter("The add button starts a scrap from Home and the other main pages; No buttons leaves the screen clean. The menu button is only used while the header is hidden; with the header shown, the menu is its button.")
}
