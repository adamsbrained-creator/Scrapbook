package app.scrapbook.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// The Week card of Home (UIO 81, "Your week" in the Afterglow skin): a row of glass tiles you swipe along. Scraps (this week, with a small glowing line over the last seven days),
// Continue (the scrap you edited last, one tap from picking it up) and To sort (the Inbox). It only reads scraps and opens pages; nothing here changes one. The tiles are drawn with
// cardFill, so they are glass with Glass cards and an ordinary card otherwise.

@Composable
private fun WeekTile(onClick: () -> Unit, desc: String, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Column(Modifier.size(width = 158.dp, height = 188.dp).pressScale(.97f).clip(shape).cardFill(shape).tap(desc, onClick).padding(16.dp), verticalArrangement = Arrangement.SpaceBetween, content = content)
}

@Composable
private fun TileHead(title: String, sub: String, arrow: Boolean) {
    Column {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (arrow) Ic("chevron", 16.dp, Sb.mute)
        }
        Text(sub, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun BigNumber(n: Int, unit: String) {
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("$n", fontFamily = headFont(), fontSize = 52.sp, lineHeight = 52.sp, fontWeight = FontWeight.Light, letterSpacing = (-1.5).sp, maxLines = 1)
        Text(unit, Modifier.padding(bottom = 6.dp), fontSize = 14.sp, color = Sb.mute, maxLines = 1)
    }
}

/** The small line over the last seven days: a soft copy under a bright one, which glows. [points] are 0 to 1. */
@Composable
private fun Spark(points: List<Float>, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        if (points.size < 2) return@Canvas
        val pad = 4.dp.toPx()
        val w = size.width
        val h = size.height - pad * 2
        val step = w / (points.size - 1)
        fun path(lift: Float) = Path().apply {
            points.forEachIndexed { i, v ->
                val x = i * step
                val y = pad + (1f - v) * h + lift
                if (i == 0) moveTo(x, y)
                else {
                    val px = (i - 1) * step
                    val py = pad + (1f - points[i - 1]) * h + lift
                    cubicTo(px + step / 2f, py, x - step / 2f, y, x, y)
                }
            }
        }
        drawPath(path(4.dp.toPx()), color.copy(alpha = .28f), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        drawPath(path(0f), color.copy(alpha = .30f), style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
        drawPath(path(0f), color, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round))
    }
}

/** The card: [outer] is the shape it has been given by the section. */
@Composable
internal fun WeekCardBody(s: HomeSection, env: HomeEnv, outer: Modifier) {
    val now = System.currentTimeMillis()
    val acc = LocalSb.current.acc
    val bright = accentText(acc)
    val perDay = remember(env.items, now / 60_000L) { WeekStats.perDay(env.items, now) }
    val total = WeekStats.total(perDay)
    val last = remember(env.items) { WeekStats.lastEdited(env.items) }
    val waiting = remember(env.items) { WeekStats.waiting(env.items) }
    Row(outer.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(12.dp)) {
        WeekTile({ env.nav.navigate("timeline") }, "Scraps this week, $total. Open the timeline") {
            TileHead("Scraps", "this week", arrow = true)
            Spark(WeekStats.spark(perDay), bright, Modifier.align(Alignment.CenterHorizontally).size(width = 126.dp, height = 40.dp))
            BigNumber(total, if (total == 1) "scrap" else "scraps")
        }
        if (last != null) WeekTile({ env.nav.navigate("edit/${last.id}") }, "Continue ${last.displayTitle}") {
            TileHead("Continue", WeekStats.editedText(last.savedAt, now), arrow = true)
            Column(Modifier.padding(horizontal = 2.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(1f to .16f, .82f to .12f, .54f to .09f).forEach { (w, a) ->
                    Box(Modifier.fillMaxWidth(w).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Sb.ink.copy(alpha = a)))
                }
            }
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text(last.displayTitle, fontFamily = headFont(), fontSize = 21.sp, lineHeight = 23.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(Modifier.padding(top = 5.dp), Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(env.colorOf(last.collection)))
                        Text(env.shelves.labelOf(last.collection).ifBlank { "Inbox" }, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Box(Modifier.size(40.dp).clip(CircleShape).background(acc), Alignment.Center) { Ic("arrow", 20.dp, onAccent(acc)) }
            }
        }
        if (waiting > 0 && !env.inboxHidden) WeekTile({ env.nav.navigate("sort") }, "To sort, $waiting waiting in the Inbox") {
            TileHead("To sort", "Inbox", arrow = false)
            BigNumber(waiting, "waiting")
        }
    }
}
