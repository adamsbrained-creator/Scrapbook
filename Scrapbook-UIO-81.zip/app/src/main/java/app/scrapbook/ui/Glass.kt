package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

// Glass cards (UIO 81, Settings > Look > Background > Cards > Glass): a card that is a faint white gradient, a little brighter at the top left, with a hairline edge, like frosted
// glass lit from a corner. Nothing here blurs what is behind (the background is soft already); it only draws the fill and the edge. With any other card choice both modifiers
// do what the app always did, so a card drawn with them looks as before unless Glass is chosen.

/** The hairline edge of a glass card: nothing unless cards are Glass. */
fun Modifier.glassEdge(shape: Shape): Modifier =
    if (!Sb.glass) this else border(1.dp, Color.White.copy(alpha = if (Sb.dark) .13f else .75f), shape)

/** What a card is filled with: the usual card color (or the veil of Frosted and Clear cards), or, with Glass cards, the gradient and the hairline edge. Use it in place of `background(Sb.surface)`. */
fun Modifier.cardFill(shape: Shape): Modifier =
    if (!Sb.glass) background(Sb.surface, shape)
    else background(Brush.linearGradient(listOf(Color.White.copy(alpha = if (Sb.dark) .09f else .62f), Color.White.copy(alpha = if (Sb.dark) .035f else .36f))), shape).glassEdge(shape)
