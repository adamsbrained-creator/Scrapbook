package app.scrapbook

/**
 * The parts of the Afterglow look that are not Home (UIO 81), so that wearing the Afterglow skin (HomeReadySkins.kt) can bring the whole look in one tap: the Afterglow background with Glass
 * cards, and the Glow tiles box style. Each of them is an ordinary setting that works on its own (Settings > Look > Background, Settings > Box style), so nothing here is special: after
 * the look is worn, any part can be changed or switched off without touching the others.
 */
object Afterglow {
    /** The key of the ready skin that brings this look. */
    const val SKIN = "afterglow"

    /** The position of Glow tiles in the box styles (ui/BoxStyles.kt BOX_STYLES). */
    const val BOX_STYLE = 8

    /** The background of the look; [keep] is the background worn now, of which only the choice to show it in the editor is kept. */
    fun background(keep: AppBackground = AppBackground()): AppBackground =
        AppBackground(kind = AppBackground.AFTERGLOW, glow = AppBackground.AFTERGLOW_GLOW, base = AppBackground.AFTERGLOW_BASE, cards = AppBackground.CARDS_GLASS, inEditor = keep.inEditor)
}
