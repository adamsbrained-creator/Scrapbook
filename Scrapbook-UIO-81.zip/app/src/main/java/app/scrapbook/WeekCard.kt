package app.scrapbook

import java.util.TimeZone

/**
 * The facts of the Week card (Home > Add a section > Your week, UIO 81): how many scraps were made on each of the last seven days (the small line of its first tile), the scrap you
 * edited last (its second tile) and how many are waiting in the Inbox (its third). Pure Kotlin so the rules are tested alone (WeekCardTest); ui/WeekParts.kt draws it. Scraps in the Bin never count.
 */
object WeekStats {
    const val DAYS = 7

    /** The scraps made on each of the last [DAYS] days, the oldest first and today last. A scrap is on the day it was made, never the day it was edited (as in the Calendar). */
    fun perDay(items: List<Item>, now: Long, zone: TimeZone = TimeZone.getDefault()): List<Int> {
        val today = Agenda.dayStart(now, zone)
        val byDay = CalendarMonth.byDay(items, zone)
        // Noon of each day is used to find its start, so a day with a clock change in it is still found.
        return (DAYS - 1 downTo 0).map { back -> byDay[Agenda.dayStart(today - back * 86_400_000L + 12 * 3_600_000L, zone)]?.size ?: 0 }
    }

    /** The count of the tile: everything made in the last seven days. */
    fun total(perDay: List<Int>): Int = perDay.sum()

    /** The small line's points, 0 to 1 against the busiest day; all 0 when nothing was made. */
    fun spark(perDay: List<Int>): List<Float> {
        val top = perDay.maxOrNull() ?: 0
        return if (top <= 0) perDay.map { 0f } else perDay.map { it / top.toFloat() }
    }

    /** The scrap edited last, or null when there is none. */
    fun lastEdited(items: List<Item>): Item? = items.filter { it.deletedAt == 0L }.maxByOrNull { it.savedAt }

    /** How many scraps are waiting in the Inbox. */
    fun waiting(items: List<Item>): Int = items.count { it.deletedAt == 0L && it.collection == "Inbox" }

    /** "edited 2 h ago": the age of [ms] at [now] in a few words (minutes, hours, yesterday, then days). */
    fun editedText(ms: Long, now: Long): String {
        val mins = ((now - ms) / 60_000L).coerceAtLeast(0)
        return "edited " + when {
            mins < 1 -> "just now"
            mins < 60 -> "$mins min ago"
            mins < 24 * 60 -> "${mins / 60} h ago"
            mins < 48 * 60 -> "yesterday"
            else -> "${mins / (24 * 60)} days ago"
        }
    }
}
