package app.scrapbook

/**
 * Ready-made skins: arrangements that look clearly different from Classic, to start from. One is added to your skins as a copy and worn (so it can be changed or deleted like
 * any other), and adding it twice gives two copies. They use the usual gestures (everything on). Only Timeline, Agenda and Calendar hold a section, one that fills itself, so they need none of
 * your own scraps; what the others do with sections is left to you.
 */
data class ReadySkin(val key: String, val name: String, val blurb: String, val values: Map<String, String>)

object ReadySkins {
    private fun styles(vararg p: Pair<HomeStyleKey, Int>): String = p.fold(HomeStyles.Default) { s, (k, i) -> s.with(k, i) }.encode()
    private fun look(vararg p: Pair<HomeLookKey, Int>): String = p.fold(HomeLook.Default) { s, (k, i) -> s.with(k, i) }.encode()
    private fun layout(order: List<HomeElement>, hidden: Set<HomeElement> = emptySet()) = HomeLayout(order, hidden)

    private fun skin(key: String, name: String, blurb: String, l: HomeLayout, styles: String, look: String, header: Int, headerSize: Int, greetText: Int? = null, greetPic: Int? = null, sections: List<HomeSection> = emptyList(), addButton: Int? = null): ReadySkin {
        val v = HashMap<String, String>()
        v[SkinKeys.ORDER] = l.encodeOrder(); v[SkinKeys.HIDDEN] = l.encodeHidden(); v[SkinKeys.STYLES] = styles; v[SkinKeys.LOOK] = look
        v[SkinKeys.HEADER] = header.toString(); v[SkinKeys.HEADER_SIZE] = headerSize.toString()
        if (greetText != null) v[SkinKeys.GREET_TEXT] = greetText.toString()
        if (greetPic != null) v[SkinKeys.GREET_PIC] = greetPic.toString()
        if (addButton != null) v[SkinKeys.ADD_BUTTON] = addButton.toString()
        if (sections.isNotEmpty()) v[SkinKeys.SECTIONS] = HomeSections.encode(sections)
        return ReadySkin(key, name, blurb, HomeSkins.sparse(v))
    }

    /** Quiet and light: thin lines instead of cards, one-line parts, a small greeting, a few scraps. */
    val minimal = skin("minimal", "Minimal", "Thin lines, one-line parts and a quiet greeting.",
        layout(HomeElement.entries.toList(), setOf(HomeElement.Sort)),
        styles(HomeStyleKey.GreetingStyle to 5, HomeStyleKey.CaptureStyle to 1, HomeStyleKey.ContinueStyle to 1, HomeStyleKey.BoxesStyle to 2,
            HomeStyleKey.PinnedStyle to 1, HomeStyleKey.RecentStyle to 1, HomeStyleKey.RecentCount to 0),
        look(HomeLookKey.Cards to 1, HomeLookKey.Spacing to 0), header = 0, headerSize = 0)

    /** Big and friendly: round tinted cards on a page with a wash of the accent color, a banner greeting, grids and previews, plenty of room. */
    val bold = skin("bold", "Bold", "Round cards, a banner greeting and room to breathe.",
        layout(listOf(HomeElement.Header, HomeElement.Greeting, HomeElement.Capture, HomeElement.Continue, HomeElement.Pinned, HomeElement.Boxes, HomeElement.Recent, HomeElement.Sort)),
        styles(HomeStyleKey.GreetingStyle to 4, HomeStyleKey.ContinueStyle to 2, HomeStyleKey.BoxesStyle to 1, HomeStyleKey.PinnedStyle to 2, HomeStyleKey.RecentCount to 2),
        look(HomeLookKey.Corners to 2, HomeLookKey.Cards to 2, HomeLookKey.Spacing to 2, HomeLookKey.Tint to 1), header = 2, headerSize = 2, greetText = 32)

    /** A dashboard: everything close together, short parts first and a long list of recent scraps. */
    val dense = skin("dense", "Dense", "Everything close together, with a long list of recent scraps.",
        layout(listOf(HomeElement.Header, HomeElement.Capture, HomeElement.Continue, HomeElement.Sort, HomeElement.Pinned, HomeElement.Boxes, HomeElement.Recent, HomeElement.Greeting),
            setOf(HomeElement.Greeting)),
        styles(HomeStyleKey.CaptureStyle to 2, HomeStyleKey.ContinueStyle to 1, HomeStyleKey.BoxesStyle to 1, HomeStyleKey.PinnedStyle to 1, HomeStyleKey.RecentStyle to 1, HomeStyleKey.RecentCount to 3),
        look(HomeLookKey.Corners to 0, HomeLookKey.Spacing to 0), header = 1, headerSize = 0)

    /**
     * One big timeline and nothing else: the header and a quiet greeting, then a section that fills itself with this week's scraps and fills the page, its dots sharing the height.
     * The section is only a section, so it can be edited, or made again anywhere (Customize home > Add a section > Timeline) in any other skin.
     */
    val timeline = skin("timeline", "Timeline", "One big timeline of this week, filling the page.",
        layout(HomeElement.entries.toList(), HomeElement.entries.toSet() - setOf(HomeElement.Header, HomeElement.Greeting)),
        styles(HomeStyleKey.GreetingStyle to 5), look(), header = 1, headerSize = 1,
        sections = listOf(HomeSection("timeline", "This week", SectionLayout.Timeline, HomeElement.Greeting.key, emptyList(), SectionRule(SectionRule.WEEK),
            style = SectionStyle(fill = true, tlSpread = true))))

    /**
     * The task-list mockup as a skin: Home's header, then one section that fills the page. It is a tabs card in the Agenda layout: the big name of the tab with Edit and Add pills,
     * the scraps of the tab as soft rows under a heading for each day (an emoji tile, the title, the time, an arrow), and floating pill tabs at the bottom (Important is the pinned
     * scraps, General all of them, Tasks the ones with a checklist item still to do), on round corners and a lime accent. It is an ordinary section, so it can be edited like any other
     * (its tabs, its rows, its size), and its two pieces can be used in any skin of your own: the Agenda layout in any section's layout choice, and Customize home > Add a section > Agenda.
     */
    val agenda = skin("agenda", "Agenda", "Scraps by day in soft rows, with pill tabs and a lime accent.",
        layout(HomeElement.entries.toList(), HomeElement.entries.toSet() - HomeElement.Header),
        styles(HomeStyleKey.GreetingStyle to 5), look(HomeLookKey.Corners to 2, HomeLookKey.Accent to 8), header = 0, headerSize = 0,
        sections = listOf(HomeSection("agenda", "Agenda", SectionLayout.Agenda, HomeElement.Header.key, emptyList(),
            card = SectionCard(SectionCard.TABS, SectionTabs.encode(SectionTabs.DEFAULT)), style = SectionStyle(fill = true))))

    /**
     * A month calendar as the whole of Home: the header, then one card section with no name line (the month is its own big title). Every day is a round cell with the scraps made on it as
     * small dots in their boxes' colors; a tap on a day opens a list of that day's scraps. It is an ordinary section, so it can be made again in any skin (Customize home > Add a section > Calendar).
     */
    val calendar = skin("calendar", "Calendar", "A month of round days, with the scraps made on each one.",
        layout(HomeElement.entries.toList(), HomeElement.entries.toSet() - HomeElement.Header),
        styles(HomeStyleKey.GreetingStyle to 5), look(), header = 0, headerSize = 0,
        sections = listOf(HomeSection("calendar", SectionCard.defaultTitle(SectionCard.CALENDAR), SectionLayout.Cards, HomeElement.Header.key, emptyList(),
            card = SectionCard(SectionCard.CALENDAR), showTitle = false)))

    /**
     * The Afterglow mockups as a skin (UIO 81): the Pill header (its pill opens the pages), a big centered statement greeting, the Prompt bar with its shortcut chips, then one Your week section
     * (glass tiles: Scraps this week, Continue, To sort) and the latest scraps as soft rows. No add button is drawn, so the bottom of every page stays clean. Wearing it from Home > Skins also
     * brings the rest of the look ([Afterglow]: the Afterglow background with Glass cards, and the Glow tiles box style), each of which can be changed or switched off on its own afterwards.
     */
    val afterglow = skin("afterglow", "Afterglow", "Glass cards on a glowing page: a pill header, a big statement, a prompt bar and your week in tiles.",
        layout(HomeElement.entries.toList(), setOf(HomeElement.Continue, HomeElement.Sort, HomeElement.Boxes, HomeElement.Pinned)),
        styles(HomeStyleKey.GreetingStyle to 6, HomeStyleKey.CaptureStyle to 3, HomeStyleKey.RecentStyle to HomeStyleKey.RecentStyle.options.indexOf("Agenda")),
        look(), header = 4, headerSize = 1, greetText = 36, addButton = ADD_BUTTON_NONE_INDEX,
        sections = listOf(HomeSection("week", SectionCard.defaultTitle(SectionCard.WEEK), SectionLayout.Cards, HomeElement.Capture.key, emptyList(), card = SectionCard(SectionCard.WEEK))))

    /** The index of "No buttons" in the add button choices (ui/HomeExtras.kt keeps the same number as ADD_BUTTON_NONE). */
    private const val ADD_BUTTON_NONE_INDEX = 5

    val all: List<ReadySkin> = listOf(minimal, bold, dense, timeline, agenda, calendar, afterglow)

    fun of(key: String): ReadySkin? = all.firstOrNull { it.key == key }
}
