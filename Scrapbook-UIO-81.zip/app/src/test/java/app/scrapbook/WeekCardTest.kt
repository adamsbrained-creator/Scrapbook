package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.TimeZone

/** The Week card of Home (UIO 81): the scraps of the last seven days, the one edited last and the Inbox. */
class WeekCardTest {
    private val utc: TimeZone = TimeZone.getTimeZone("UTC")
    private fun at(d: Int, h: Int = 12): Long = LocalDateTime.of(2026, 6, d, h, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()
    private fun made(created: Long, saved: Long = created, box: String = "Inbox", deleted: Long = 0L) =
        Item(title = "t", body = "", kind = Kind.Note, collection = box, savedAt = saved, createdAt = created, deletedAt = deleted)

    @Test fun sevenDaysOldestFirstAndTodayLast() {
        val now = at(12, 15)
        val items = listOf(made(at(12, 9)), made(at(12, 10)), made(at(11)), made(at(6)), made(at(5)))   // the 5th is eight days back
        assertEquals(listOf(1, 0, 0, 0, 0, 1, 2), WeekStats.perDay(items, now, utc))
        assertEquals(4, WeekStats.total(WeekStats.perDay(items, now, utc)))
    }

    @Test fun aScrapIsOnTheDayItWasMadeAndTheBinNeverCounts() {
        val now = at(12)
        val items = listOf(made(at(8), saved = at(12)), made(at(12), deleted = at(12)))
        assertEquals(listOf(0, 0, 1, 0, 0, 0, 0), WeekStats.perDay(items, now, utc))
    }

    @Test fun theLineRunsAgainstTheBusiestDayAndStaysFlatWhenNothingWasMade() {
        assertEquals(listOf(0f, .5f, 1f), WeekStats.spark(listOf(0, 2, 4)))
        assertEquals(listOf(0f, 0f), WeekStats.spark(listOf(0, 0)))
        assertEquals(emptyList<Float>(), WeekStats.spark(emptyList()))
    }

    @Test fun theLastEditedScrapSkipsTheBin() {
        assertNull(WeekStats.lastEdited(emptyList()))
        val a = made(at(1), saved = at(3)); val b = made(at(2), saved = at(9)); val bin = made(at(3), saved = at(11), deleted = at(11))
        assertEquals(b, WeekStats.lastEdited(listOf(a, b, bin)))
    }

    @Test fun waitingIsTheInboxWithoutTheBin() {
        assertEquals(2, WeekStats.waiting(listOf(made(1), made(2), made(3, box = "Ideas"), made(4, deleted = 5))))
    }

    @Test fun theAgeIsSaidInAFewWords() {
        val now = at(12)
        assertEquals("edited just now", WeekStats.editedText(now, now))
        assertEquals("edited 5 min ago", WeekStats.editedText(now - 5 * 60_000L, now))
        assertEquals("edited 2 h ago", WeekStats.editedText(now - 2 * 3_600_000L, now))
        assertEquals("edited yesterday", WeekStats.editedText(now - 30 * 3_600_000L, now))
        assertEquals("edited 4 days ago", WeekStats.editedText(now - 4 * 86_400_000L, now))
        assertTrue(WeekStats.editedText(now + 1000, now).endsWith("just now"))
    }

    @Test fun theWeekCardIsACardKindWithANameAndSurvivesSaving() {
        assertTrue(SectionCard.WEEK in SectionCard.KINDS)
        assertEquals("Your week", SectionCard.label(SectionCard.WEEK))
        val s = HomeSection("w", "Your week", SectionLayout.Cards, "capture", card = SectionCard(SectionCard.WEEK))
        val back = HomeSections.decode(HomeSections.encode(listOf(s))).single()
        assertEquals(SectionCard.WEEK, back.card?.kind)
    }
}
