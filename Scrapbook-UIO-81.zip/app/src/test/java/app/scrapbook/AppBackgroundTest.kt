package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppBackgroundTest {
    @Test fun noChoicesIsThePlainPageAndSavesNothing() {
        val b = AppBackground()
        assertTrue(b.isDefault)
        assertFalse(b.active)
        assertEquals("", b.encode())
        assertEquals(b, AppBackground.decode(null))
        assertEquals(b, AppBackground.decode(""))
    }

    @Test fun everyChoiceIsSavedAndReadBack() {
        val b = AppBackground(kind = AppBackground.GLOW, top = 0x6B5A4E, bottom = 0x101820, direction = 2, glow = 0xFF6FB1, mix = 0, strength = 2, speed = 3, cards = 2, inEditor = true)
        assertEquals(b, AppBackground.decode(b.encode()))
        assertTrue(b.active)
    }

    @Test fun onlyWhatIsNotTheUsualIsWritten() {
        assertEquals("k=1", AppBackground(kind = AppBackground.GRADIENT).encode())
        assertEquals("k=1;t=6B5A4E;cd=0", AppBackground(kind = 1, top = 0x6B5A4E, cards = 0).encode())
    }

    @Test fun numbersAndColorsAreKeptInTheirLimits() {
        val b = AppBackground.decode("k=9;d=7;m=3;s=-4;p=99;cd=8;t=1FFFFFFF")
        assertEquals(3, b.kind)
        assertEquals(2, b.direction)
        assertEquals(1, b.mix)
        assertEquals(0, b.strength)
        assertEquals(3, b.speed)
        assertEquals(3, b.cards)
        assertEquals(AppBackground.DEFAULT_TOP, b.top)   // a number that is not a color is skipped
    }

    @Test fun nonsenseIsSkipped() {
        val b = AppBackground.decode("junk;=3;k=abc;t=zzz;b=12;g=;cd=0;ed=0;q=1")
        assertEquals(AppBackground(cards = 0), b)
    }

    @Test fun aColorIsWrittenAsSixHexDigits() {
        assertEquals("1D4E89", AppBackgrounds.hex(0x1D4E89))
        assertEquals("00000F", AppBackgrounds.hex(0xF))
        assertEquals("FFFFFF", AppBackgrounds.hex(-1))
    }

    @Test fun hexIsReadInTheUsualWays() {
        assertEquals(0x1D4E89, AppBackgrounds.parseHex("#1D4E89"))
        assertEquals(0x1D4E89, AppBackgrounds.parseHex(" 1d4e89 "))
        assertEquals(0x1144EE, AppBackgrounds.parseHex("#14e"))
        assertNull(AppBackgrounds.parseHex(""))
        assertNull(AppBackgrounds.parseHex("#12345"))
        assertNull(AppBackgrounds.parseHex("#GGGGGG"))
        assertNull(AppBackgrounds.parseHex("1D4E89A"))
    }

    @Test fun lightnessGoesFromBlackToWhite() {
        assertEquals(0f, AppBackgrounds.luminance(0x000000), 1e-4f)
        assertEquals(1f, AppBackgrounds.luminance(0xFFFFFF), 1e-4f)
        assertEquals(0.299f, AppBackgrounds.luminance(0xFF0000), 1e-3f)
        assertTrue(AppBackgrounds.luminance(0xFFFF00) > AppBackgrounds.luminance(0x0000FF))
    }

    @Test fun theNeighborsOnTheColorWheelAreFortyDegreesAway() {
        assertEquals(0xFFAA00 to 0xFF00AA, AppBackgrounds.companions(0xFF0000))
        // A grey has no color to turn: its neighbors are the same grey.
        assertEquals(0x808080 to 0x808080, AppBackgrounds.companions(0x808080))
    }

    @Test fun darkTextNeedsALightBackgroundAndTheOtherWayRound() {
        val dark = AppBackground(kind = 1, top = 0x1D4E89, bottom = 0x0B0B0B)
        val pale = AppBackground(kind = 1, top = 0xF4E9C9, bottom = 0xFFFFFF)
        assertTrue(dark.readable(true))
        assertFalse(dark.readable(false))
        assertFalse(pale.readable(true))
        assertTrue(pale.readable(false))
        assertTrue(AppBackground().readable(true) && AppBackground().readable(false))
    }

    @Test fun aGlowIsJudgedByHowMuchOfItIsDrawn() {
        val soft = AppBackground(kind = 2, glow = 0xFFFFFF, strength = 0)
        val strong = AppBackground(kind = 2, glow = 0xFFFFFF, strength = 2)
        assertTrue(soft.readable(true))
        assertFalse(strong.readable(true))
        assertTrue(AppBackground(kind = 2, glow = 0x4DA3FF).readable(true))
    }

    @Test fun glowSpeedsAreSlowerToFaster() {
        assertEquals(0, AppBackgrounds.periodMs(0))
        assertTrue(AppBackgrounds.periodMs(1) > AppBackgrounds.periodMs(2) && AppBackgrounds.periodMs(2) > AppBackgrounds.periodMs(3))
        assertTrue(AppBackgrounds.strengthFactor(0) < AppBackgrounds.strengthFactor(1) && AppBackgrounds.strengthFactor(1) < AppBackgrounds.strengthFactor(2))
    }

    @Test fun solidCardsHaveNoVeilAndTheOthersAreFrostedWhite() {
        assertEquals(null, AppBackgrounds.veilAlpha(AppBackground.CARDS_SOLID, true))
        assertEquals(null, AppBackgrounds.veilAlpha(AppBackground.CARDS_SOLID, false))
        assertTrue(AppBackgrounds.veilAlpha(1, true)!! > AppBackgrounds.veilAlpha(2, true)!!)
        assertTrue(AppBackgrounds.veilAlpha(1, false)!! > AppBackgrounds.veilAlpha(2, false)!!)
        // On a light page the veil must be strong enough to be seen, on a dark one it is only a hint.
        assertTrue(AppBackgrounds.veilAlpha(1, false)!! > AppBackgrounds.veilAlpha(1, true)!!)
        assertEquals(AppBackground.CARDS_FROSTED, AppBackground().cards)
    }

    // ---- Afterglow (UIO 81) ----

    @Test fun anAfterglowIsSavedAndReadBackWithEveryPart() {
        val b = AppBackground(kind = AppBackground.AFTERGLOW, glow = 0xFF6FB1, mix = 0, strength = 2, speed = 1, streak = 0, streakColor = 0x3CCB8E, dust = 2, dustColor = 0xFFFFFF, base = 0x120A14, cards = 3, inEditor = true)
        assertEquals(b, AppBackground.decode(b.encode()))
        assertTrue(b.active && b.glowLike)
    }

    @Test fun theNewPartsAreOnlyWrittenWhenTheyDifferFromTheUsual() {
        assertEquals("k=3", AppBackground(kind = AppBackground.AFTERGLOW).encode())
        assertEquals("k=3;sk=0", AppBackground(kind = 3, streak = 0).encode())
        assertEquals("k=3;sc=3CCB8E;du=0;bs=0B0A14", AppBackground(kind = 3, streakColor = 0x3CCB8E, dust = 0, base = 0x0B0A14).encode())
        assertTrue(AppBackground(kind = 3).glowLike && AppBackground(kind = 2).glowLike && !AppBackground(kind = 1).glowLike)
    }

    @Test fun theNewPartsKeepToTheirLimitsAndNonsenseIsSkipped() {
        val b = AppBackground.decode("k=3;sk=7;du=-3;sc=zzz;dc=1FFFFFFF;bs=12345")
        assertEquals(1, b.streak)
        assertEquals(0, b.dust)
        assertEquals(AppBackground.SAME, b.streakColor)
        assertEquals(AppBackground.DEFAULT_DUST, b.dustColor)
        assertEquals(AppBackground.SAME, b.base)
        assertEquals(AppBackground.SAME, AppBackground(base = -5, streakColor = -9).clamped().base)
    }

    @Test fun anOlderSavedBackgroundStillReadsTheSame() {
        val old = AppBackground.decode("k=2;g=FF6FB1;m=0;s=2;p=3;cd=2;ed=1")
        assertEquals(AppBackground(kind = 2, glow = 0xFF6FB1, mix = 0, strength = 2, speed = 3, cards = 2, inEditor = true), old)
    }

    @Test fun choosingAfterglowFromThePlainPageBringsTheDesignsVioletButAGlowKeepsItsColors() {
        val fromPlain = AppBackground().withKind(AppBackground.AFTERGLOW)
        assertEquals(AppBackground.AFTERGLOW_GLOW, fromPlain.glow)
        assertEquals(AppBackground.AFTERGLOW_BASE, fromPlain.base)
        val fromGlow = AppBackground(kind = 2, glow = 0xFF6FB1).withKind(AppBackground.AFTERGLOW)
        assertEquals(0xFF6FB1, fromGlow.glow)
        assertEquals(AppBackground.SAME, fromGlow.base)
        // Going back to a glow keeps the afterglow's colors, and a kind out of range is brought in.
        assertEquals(AppBackground.AFTERGLOW_GLOW, fromPlain.withKind(2).glow)
        assertEquals(3, AppBackground().withKind(9).kind)
        assertEquals(0, fromPlain.withKind(-2).kind)
    }

    @Test fun anAfterglowIsJudgedOnItsOwnDarkPage() {
        val violet = AppBackground(kind = 3, glow = 0x8B6BFF, base = 0x0B0A14)
        assertTrue(violet.readable(true))
        // A pale page under it cannot be read with the light text of dark mode.
        assertFalse(AppBackground(kind = 3, glow = 0x8B6BFF, base = 0xF0F0F0, strength = 0).readable(true))
        assertTrue(AppBackground(kind = 3, glow = 0x8B6BFF).readable(true))
    }

    @Test fun starsAreFewOrManyAndNeverBlinkTogether() {
        assertEquals(0, AppBackgrounds.dustPoints(0).size)
        assertTrue(AppBackgrounds.dustPoints(1).size in 1 until AppBackgrounds.dustPoints(2).size)
        assertTrue(AppBackgrounds.dustPoints(2).all { (x, y) -> x in 0f..1f && y in 0f..1f })
        for (t in listOf(0f, .25f, .5f, .9f)) for (i in 0 until 20) assertTrue(AppBackgrounds.twinkle(t, i) in 0f..1f)
        assertEquals(0f, AppBackgrounds.twinkle(0f, 0), 1e-4f)
        assertEquals(1f, AppBackgrounds.twinkle(.5f, 0), 1e-4f)
        assertTrue(AppBackgrounds.twinkle(.3f, 0) != AppBackgrounds.twinkle(.3f, 1))
    }

    @Test fun glassCardsAreAFaintVeilWithAnEdgeOfTheirOwn() {
        assertEquals(AppBackground.CARDS_GLASS, AppBackground(cards = 9).clamped().cards)
        assertTrue(AppBackgrounds.veilAlpha(AppBackground.CARDS_GLASS, true)!! < AppBackgrounds.veilAlpha(AppBackground.CARDS_CLEAR, true)!! * 2)
        assertTrue(AppBackgrounds.veilAlpha(AppBackground.CARDS_GLASS, false)!! > AppBackgrounds.veilAlpha(AppBackground.CARDS_GLASS, true)!!)
    }
}
