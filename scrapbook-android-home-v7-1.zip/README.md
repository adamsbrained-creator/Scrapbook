# Scrapbook (v0.1)

A personal notes and archive app for Android: notes, quotes, links and photos with eight page layouts,
collections, search, a Rediscover swipe, per-page styling, a Settings page (theme, white or soft grey background,
accent, lists, boxes, backup/restore; seven box styles: Tabbed, Paper stack, Tinted tiles, Folder tabs, Chips, List rows, Notebook covers; and five looks for the Boxes screen: Default, Nested, Shelf, Cover, Stack), an About page (version, What's new, feedback, licenses, and links to the other apps in the family), a home-screen widget, and sharing into the app from other apps. The app reopens in the box you were last in (switch off in Settings).

## Get it on your phone

**Easiest, no tools to install (GitHub):**
1. Create a GitHub repository and push this folder to it (branch `main`).
2. Do the one-time key setup in `SIGNING.md` (about 10 minutes). This is what lets every new version
   install over the old one without deleting the app.
3. Open the repo's **Actions** tab, open the latest **Android CI** run, and download the
   `scrapbook-release-apk` artifact (a zip containing `app-release.apk`).
4. Copy the APK to your phone and open it. Android will ask you to allow installing from that source.

**With Android Studio:** open this folder, let Gradle sync, plug in a phone (USB debugging on) or start an
emulator, and press Run.

**From a phone, with a zip:** keep one zip of the whole project at the top of the repo, plus
`.github/workflows/scrapbook-zip.yml`. Uploading a new zip starts **Scrapbook (from zip)**, which unpacks it and builds
the signed APK (same key setup, see `SIGNING.md`). If there is more than one zip, the one uploaded last is built.

`scrapbook-debug-apk` is also built and signed with the same key, but use the release one day to day.
Fonts: see `FONTS.md`. Widget: long-press your home screen, Widgets, Scrapbook.
