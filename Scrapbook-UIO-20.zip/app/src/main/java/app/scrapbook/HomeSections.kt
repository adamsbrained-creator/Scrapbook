package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

// Home sections: your own rows on the Home page, made by dragging a scrap or a box out of Home and letting go (see ui/HomeGestures.kt).
// A section only POINTS at things: it never moves, copies or deletes a scrap or a box, so removing a section (or an item from it) is always safe.
// This file holds only the rules (where a section sits, what it holds, how it is saved), so they are tested on their own (HomeSectionsTest).

/** How a section lays out what it holds. [key] is what is saved, so never rename one. */
enum class SectionLayout(val key: String, val label: String, val icon: String, val note: String = "") {
    Cards("cards", "Cards", "layout", "A row of cards you swipe sideways."),
    Chips("chips", "Chips", "tag", "Small pills, one line of names."),
    Rows("rows", "Rows", "list", "One full-width row for each thing."),
    Grid("grid", "Grid", "grid", "Cards two (or more) to a row."),
    Carousel("carousel", "Carousel", "play", "Big cards that stop on each one as you swipe. Good for a few things you want to read."),
    Hero("hero", "Hero", "star", "The first thing big, the rest as small cards under it."),
    Banner("banner", "Banner", "page", "Wide tinted bands with a big title, one under another."),
    Mosaic("mosaic", "Mosaic", "layout", "Two columns of cards as tall as what is in them."),
    Tiles("tiles", "Tiles", "grid", "Small squares, three or more across, with just a name. Good for many boxes."),
    Timeline("timeline", "Timeline", "clock", "A line down the side with a dot for each thing."),
    Lines("lines", "Lines", "numbered", "A plain list with thin lines between, no cards. The quietest one."),
    Compact("compact", "Compact", "list", "Two columns of slim rows, to fit many names in a little space.");

    companion object {
        fun of(key: String?): SectionLayout = entries.firstOrNull { it.key == key } ?: Cards
    }
}

/** One thing a section holds: a box (by its permanent key, "Inbox" included) or a scrap (by its uid, which survives a backup restore). */
data class SectionRef(val box: Boolean, val key: String) {
    /** A name for this thing that is different for every box and scrap; used to tell the things of a section apart. */
    val token: String get() = (if (box) "b:" else "n:") + key
}

/**
 * What a smart section collects by itself instead of holding things you put in it: the scraps with a tag ([TAG], [arg] is the tag), the scraps in a box and the boxes inside it
 * ([BOX], [arg] is the box's key) or the scraps edited in the last week ([WEEK]). The newest edited come first and at most [MAX_SHOWN] are shown.
 */
data class SectionRule(val kind: String, val arg: String = "") {
    /** The rule as one short text ("tag:ideas", "box:Trips", "week"), how a section is saved. */
    fun encode(): String = if (arg.isEmpty()) kind else "$kind:$arg"

    companion object {
        const val TAG = "tag"
        const val BOX = "box"
        const val WEEK = "week"
        const val WEEK_MS = 7L * 24 * 60 * 60 * 1000
        const val MAX_SHOWN = 8

        /** Reads what [encode] wrote. Null for nothing, for a rule that is not known, and for a tag or box with no name. */
        fun parse(text: String?): SectionRule? {
            val t = text.orEmpty()
            if (t.isEmpty()) return null
            val kind = t.substringBefore(':')
            val arg = if (':' in t) t.substringAfter(':') else ""
            return when (kind) {
                TAG, BOX -> if (arg.isEmpty()) null else SectionRule(kind, arg)
                WEEK -> SectionRule(WEEK)
                else -> null
            }
        }
    }
}

/**
 * A card section: a block of Home that is not a row of shortcuts but one thing of its own. [kind] says which ([TEXT] your own words in [text], [QUOTE] lines in [text] one per
 * line of which one shows each day, [RANDOM] a scrap drawn from the scraps [arg] names, [COUNTER] a number counting the scraps [arg] names, [BUTTON] a button that starts a new scrap
 * in the box [arg] with [text] already written). For RANDOM and COUNTER [arg] is a rule as [SectionRule.encode] writes it, or empty for every scrap; for BUTTON it is a box's key
 * (empty is the Inbox). Like every section it only POINTS at things: nothing here moves, copies or deletes a scrap or a box.
 */
data class SectionCard(val kind: String, val text: String = "", val arg: String = "") {
    /** The lines of a quote card: every line with something on it, trimmed. */
    val lines: List<String> get() = text.split('\n').map { it.trim() }.filter { it.isNotEmpty() }

    /** The scraps a random or counter card looks at, as a rule; null for every scrap. */
    val scope: SectionRule? get() = if (kind == RANDOM || kind == COUNTER) SectionRule.parse(arg) else null

    /** The key of the box a button card writes in; the Inbox is "Inbox". */
    val destination: String get() = arg.ifEmpty { "Inbox" }

    companion object {
        const val TEXT = "text"
        const val QUOTE = "quote"
        const val RANDOM = "random"
        const val COUNTER = "counter"
        const val BUTTON = "button"
        const val MAX_TEXT = 600

        /** Every kind, in the order the Add a section window lists them. */
        val KINDS = listOf(TEXT, QUOTE, RANDOM, COUNTER, BUTTON)

        fun label(kind: String): String = when (kind) {
            TEXT -> "Text card"
            QUOTE -> "Quote card"
            RANDOM -> "Random scrap"
            COUNTER -> "Counter"
            BUTTON -> "Button"
            else -> "Card"
        }

        /** What a new card of this kind is called until you rename it. */
        fun defaultTitle(kind: String): String = when (kind) {
            TEXT -> "A note"
            QUOTE -> "Quote"
            RANDOM -> "From your archive"
            COUNTER -> "Count"
            BUTTON -> "Quick start"
            else -> ""
        }

        /** A card as saved. Null for a kind that is not known (so a skin made by a newer version never breaks an older one); the text is cut to [MAX_TEXT]. */
        fun parse(kind: String, text: String, arg: String): SectionCard? = if (kind in KINDS) SectionCard(kind, text.take(MAX_TEXT), arg) else null
    }
}

/**
 * A section of Home. [anchor] is the key of the Home part it sits right after (see HomeElement), or "" for the very top.
 * Sections with the same anchor sit in the order of the list. With a [rule] the section is smart: it shows what the rule finds and [refs] is not used.
 */
data class HomeSection(
    val id: String,
    val title: String = "",
    val layout: SectionLayout = SectionLayout.Cards,
    val anchor: String = "",
    val refs: List<SectionRef> = emptyList(),
    val rule: SectionRule? = null,
    /** Set for a card section (see [SectionCard]); then [refs] and [rule] are not used. */
    val card: SectionCard? = null,
    /** False: the section has no name line on Home, only its things (a clean section). [title] is kept, for the lists in Customize home and the menus. */
    val showTitle: Boolean = true,
    /** The size you gave it: [width] as a percent of the page's width and [height] in dp. 0 is automatic (what the layout gives it). Both are set when you resize it. */
    val width: Int = 0,
    val height: Int = 0,
    /** The space between this section and whatever comes next, in dp. -1 is automatic: the space of the Look page (Space between parts). */
    val spaceBelow: Int = -1,
    /** The extra choices (fill the page, the Timeline's look, the icons of its things); see SectionStyle. */
    val style: SectionStyle = SectionStyle(),
) {
    val isSmart: Boolean get() = rule != null
    val isCard: Boolean get() = card != null

    /** True when you gave the section a size of your own. */
    val sized: Boolean get() = width > 0 || height > 0

    /** What the section is called on screen. */
    val name: String get() = title.ifBlank { card?.let { SectionCard.label(it.kind) } ?: "New section" }
    fun has(r: SectionRef): Boolean = r in refs
}

/** One block of the Home page from top to bottom: one of its parts, or one of your sections. [key] is also what the page reports its place under. */
sealed class HomeSlot {
    abstract val key: String

    data class Part(val element: HomeElement) : HomeSlot() {
        override val key: String get() = element.key
    }

    data class Sec(val section: HomeSection) : HomeSlot() {
        override val key: String get() = "section:" + section.id
    }
}

/** Where a block of the page is on the screen, top to bottom, in px. */
class BlockSpan(val key: String, val top: Float, val bottom: Float)

/**
 * The gesture settings (Customize home > Gestures). [hold] opens a menu, [drag] lets a held thing be picked up, [file] lets a scrap dropped on a box go into it,
 * [empty] makes a hold on an empty spot of Home open Customize home, [swipe] lets a Recent row be swiped (right pins, left deletes), [capture] turns on the swipe up and
 * the hold on the quick capture card, [doubleTap] is what a double tap on the greeting does (0 nothing, 1 the Continue scrap, 2 Inbox) and [pull] opens search when the page is pulled down.
 */
data class GesturePrefs(
    val hold: Boolean = true, val drag: Boolean = true, val file: Boolean = true,
    val empty: Boolean = true, val swipe: Boolean = true, val capture: Boolean = true, val doubleTap: Int = 1, val pull: Boolean = true,
) {
    /** The settings as one short text, how a skin holds them (see HomeSkins.kt): the seven switches as 1 or 0 (hold, drag, file, empty, swipe, capture, pull), then the double tap choice. */
    fun encode(): String = listOf(hold, drag, file, empty, swipe, capture, pull).joinToString(",") { if (it) "1" else "0" } + ",$doubleTap"

    companion object {
        val DOUBLE_TAP_OPTIONS = listOf("Nothing", "Continue scrap", "Inbox", "Next skin")

        /** Reads what [encode] wrote. Anything missing or unreadable is the usual setting (everything on, double tap to the Continue scrap). */
        fun decode(text: String?): GesturePrefs {
            val p = text.orEmpty().split(',')
            fun on(i: Int): Boolean = p.getOrNull(i) != "0"
            return GesturePrefs(on(0), on(1), on(2), on(3), on(4), on(5), (p.getOrNull(7)?.toIntOrNull() ?: 1).coerceIn(0, DOUBLE_TAP_OPTIONS.lastIndex), on(6))
        }
    }
}

object HomeSections {
    const val MAX_TITLE = 40

    // The limits of a section's size you set: its width as a percent of the page, its height in dp.
    const val MIN_WIDTH = 25
    const val MAX_WIDTH = 100
    const val MIN_HEIGHT = 80
    const val MAX_HEIGHT = 900

    /** The most space you can put below a section, in dp. */
    const val MAX_SPACE = 120

    /** [id]'s section with [dp] of space below it, kept between 0 and [MAX_SPACE]; a negative number gives it back to automatic. */
    fun spaced(sections: List<HomeSection>, id: String, dp: Int): List<HomeSection> = update(sections, id) { it.copy(spaceBelow = if (dp < 0) -1 else dp.coerceAtMost(MAX_SPACE)) }

    /** [id]'s section with the size [width] percent by [height] dp, each kept between its limits; 0 gives that side back to automatic. */
    fun sized(sections: List<HomeSection>, id: String, width: Int, height: Int): List<HomeSection> = update(sections, id) {
        it.copy(width = if (width <= 0) 0 else width.coerceIn(MIN_WIDTH, MAX_WIDTH), height = if (height <= 0) 0 else height.coerceIn(MIN_HEIGHT, MAX_HEIGHT))
    }

    /** The width, in percent of the page, that a section dragged to [widthPx] pixels would have when the page leaves [availablePx] for it. Close to the full width counts as the full width. */
    fun widthPercent(widthPx: Float, availablePx: Float): Int {
        if (availablePx <= 0f) return 0
        val p = (widthPx / availablePx * 100f).roundToInt().coerceIn(MIN_WIDTH, MAX_WIDTH)
        return if (p >= 96) 100 else p
    }

    /** The height, in dp, of a section dragged to [heightPx] pixels on a screen with [density] pixels to the dp. */
    fun heightDp(heightPx: Float, density: Float): Int = if (density <= 0f) 0 else (heightPx / density).roundToInt().coerceIn(MIN_HEIGHT, MAX_HEIGHT)

    /** How many grid columns fit a box [widthDp] wide: cells about 150dp wide with 12dp between them, never fewer than one. */
    fun gridColumns(widthDp: Float): Int = max(1, ((widthDp + 12f) / 162f).toInt())

    /** The height, in dp, of one grid cell: the usual 136 while the height is automatic ([boxHeightDp] 0), otherwise the rows of [count] things in [cols] columns share the box, between 72 and 220. */
    fun gridCellHeight(boxHeightDp: Int, count: Int, cols: Int): Float {
        if (boxHeightDp <= 0) return 136f
        val rows = max(1, ceil(count / max(1, cols).toFloat()).toInt())
        return ((boxHeightDp - 12f * (rows - 1)) / rows).coerceIn(72f, 220f)
    }

    /** The width, in dp, of one card of the Cards layout in a box [boxWidthDp] wide and [boxHeightDp] tall (0 is automatic): as before while the height is automatic, otherwise a little wider than tall. */
    fun cardWidth(boxWidthDp: Float, boxHeightDp: Int): Float =
        if (boxHeightDp <= 0) minOf(176f, boxWidthDp) else minOf(boxWidthDp, max(110f, boxHeightDp * 1.3f))

    /** A saved size: 0 (automatic) for nothing or something that is not a positive number, otherwise kept between the limits. */
    private fun sizeField(text: String?, min: Int, max: Int): Int = (text?.toIntOrNull() ?: 0).let { if (it <= 0) 0 else it.coerceIn(min, max) }

    fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(10)

    fun cleanTitle(s: String): String = s.trim().take(MAX_TITLE)

    /**
     * Every block of the page in order, hidden parts included (a hidden part keeps its place, and the sections after it stay where they are).
     * Sections that sit at the very top come first; a section whose part no longer exists goes last.
     */
    fun slots(order: List<HomeElement>, sections: List<HomeSection>): List<HomeSlot> {
        val out = ArrayList<HomeSlot>()
        val known = order.map { it.key }.toSet()
        sections.filter { it.anchor.isEmpty() }.forEach { out.add(HomeSlot.Sec(it)) }
        for (e in order) {
            out.add(HomeSlot.Part(e))
            sections.filter { it.anchor == e.key }.forEach { out.add(HomeSlot.Sec(it)) }
        }
        sections.filter { it.anchor.isNotEmpty() && it.anchor !in known }.forEach { out.add(HomeSlot.Sec(it)) }
        return out
    }

    /** The sections as the blocks say they are placed: each one now sits after the part before it. The list comes out in page order. */
    fun reanchor(slots: List<HomeSlot>): List<HomeSection> {
        val out = ArrayList<HomeSection>()
        var anchor = ""
        for (s in slots) {
            when (s) {
                is HomeSlot.Part -> anchor = s.element.key
                is HomeSlot.Sec -> out.add(s.section.copy(anchor = anchor))
            }
        }
        return out
    }

    /** Adds [section] right after the block [afterKey] (a part's key or "section:<id>"); null puts it at the very top. A key that is not on the page puts it last. */
    fun insert(order: List<HomeElement>, sections: List<HomeSection>, section: HomeSection, afterKey: String?): List<HomeSection> {
        val all = slots(order, sections).toMutableList()
        val at = if (afterKey == null) 0 else all.indexOfFirst { it.key == afterKey }.let { if (it < 0) all.size else it + 1 }
        all.add(at, HomeSlot.Sec(section))
        return reanchor(all)
    }

    /** Moves a section one place up ([dir] = -1) or down (+1) the page, past one block (hidden parts do not count). At the end of the page nothing changes. */
    fun move(order: List<HomeElement>, hidden: Set<HomeElement>, sections: List<HomeSection>, id: String, dir: Int): List<HomeSection> {
        val all = slots(order, sections).toMutableList()
        val i = all.indexOfFirst { it is HomeSlot.Sec && it.section.id == id }
        if (i < 0 || dir == 0) return sections
        var j = i + dir
        while (j in all.indices && all[j].let { it is HomeSlot.Part && it.element in hidden }) j += dir
        if (j !in all.indices) return sections
        val s = all.removeAt(i)
        all.add(j, s)
        return reanchor(all)
    }

    /**
     * Moves the block at [from] to [to] among every block of the page, hidden parts included (Customize home lists them all, so these are its row numbers).
     * Returns the new order of the parts and the sections, each now sitting after the part that is before it.
     */
    fun reorderSlots(order: List<HomeElement>, sections: List<HomeSection>, from: Int, to: Int): Pair<List<HomeElement>, List<HomeSection>> {
        val all = slots(order, sections).toMutableList()
        if (from == to || from !in all.indices || to !in all.indices) return order to sections
        all.add(to, all.removeAt(from))
        return all.filterIsInstance<HomeSlot.Part>().map { it.element } to reanchor(all)
    }

    /** Puts [ref] at place [toIndex] of the section's things (the place the thing there had; the others make room). A thing that is not in the section changes nothing. */
    fun reorder(sections: List<HomeSection>, id: String, ref: SectionRef, toIndex: Int): List<HomeSection> = update(sections, id) { s ->
        if (ref !in s.refs) s
        else {
            val rest = s.refs - ref
            val at = toIndex.coerceIn(0, rest.size)
            s.copy(refs = rest.take(at) + ref + rest.drop(at))
        }
    }

    /**
     * The scraps a smart section shows, newest edited first. [boxKeys] is the box of a box rule and every box inside it (the caller works that out), [now] the time in milliseconds.
     * Scraps in the Bin are not given here, so they never show.
     */
    fun smartScraps(rule: SectionRule, items: List<Item>, boxKeys: Set<String>, now: Long): List<Item> =
        matching(rule, items, boxKeys, now).sortedByDescending { it.savedAt }.take(SectionRule.MAX_SHOWN)

    /** Every scrap [rule] finds, in the order of [items]; with no rule, every scrap. [boxKeys] and [now] are as for [smartScraps]. */
    fun matching(rule: SectionRule?, items: List<Item>, boxKeys: Set<String>, now: Long): List<Item> {
        if (rule == null) return items
        return when (rule.kind) {
            SectionRule.TAG -> items.filter { n -> n.tags.any { it.equals(rule.arg, ignoreCase = true) } }
            SectionRule.BOX -> items.filter { it.collection in boxKeys }
            SectionRule.WEEK -> items.filter { it.savedAt >= now - SectionRule.WEEK_MS }
            else -> emptyList()
        }
    }

    /** How many scraps [rule] finds (every scrap with no rule). */
    fun count(rule: SectionRule?, items: List<Item>, boxKeys: Set<String>, now: Long): Int = matching(rule, items, boxKeys, now).size

    /** What a counter says under its number: "scraps in total", "scrap edited this week", "scraps tagged #ideas", "scraps in Trips" ([boxLabel] is the box's name). */
    fun counterText(n: Int, rule: SectionRule?, boxLabel: String): String {
        val noun = if (n == 1) "scrap" else "scraps"
        if (rule == null) return "$noun in total"
        return when (rule.kind) {
            SectionRule.TAG -> "$noun tagged #${rule.arg}"
            SectionRule.BOX -> "$noun in $boxLabel"
            else -> "$noun edited this week"
        }
    }

    /** One of [candidates] picked by [seed] (the same seed always gives the same one); null if there are none. */
    fun pickOne(candidates: List<Item>, seed: Long): Item? =
        if (candidates.isEmpty()) null else candidates[Math.floorMod(seed, candidates.size.toLong()).toInt()]

    /** The quote for day number [day] (days since 1970): the lines in turn, one a day, starting over at the end. Empty if there are no lines. */
    fun quoteOf(lines: List<String>, day: Long): String =
        if (lines.isEmpty()) "" else lines[Math.floorMod(day, lines.size.toLong()).toInt()]

    fun update(sections: List<HomeSection>, id: String, change: (HomeSection) -> HomeSection): List<HomeSection> =
        sections.map { if (it.id == id) change(it) else it }

    fun remove(sections: List<HomeSection>, id: String): List<HomeSection> = sections.filterNot { it.id == id }

    /** Puts [ref] in the section (nothing changes if it is already there). */
    fun withRef(sections: List<HomeSection>, id: String, ref: SectionRef): List<HomeSection> =
        update(sections, id) { if (it.has(ref)) it else it.copy(refs = it.refs + ref) }

    fun withoutRef(sections: List<HomeSection>, id: String, ref: SectionRef): List<HomeSection> =
        update(sections, id) { it.copy(refs = it.refs - ref) }

    /** Takes [ref] out of section [from] (null = it was not in a section) and puts it in section [to]. */
    fun moveRef(sections: List<HomeSection>, from: String?, to: String, ref: SectionRef): List<HomeSection> =
        withRef(if (from == null || from == to) sections else withoutRef(sections, from, ref), to, ref)

    /** The key of the block a thing dropped at height [y] would go after: the last block whose middle is above [y]. Null if it is above them all. */
    fun dropAfter(blocks: List<BlockSpan>, y: Float): String? =
        blocks.sortedBy { it.top }.lastOrNull { (it.top + it.bottom) / 2f < y }?.key

    // ----- Saved form: one line per section ("S|id|layout|anchor|title", and "|rule" after it for a smart one, "|rule|kind|text|arg" for a card, then "|name shown (1 or 0)|width|height" when it has no name line or a size of its own, then "|space below" when that is set) followed by one per thing in it ("B|box key" or "N|scrap uid"). Every text is URL-encoded, so no | or line break can appear inside one. -----

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    fun encode(sections: List<HomeSection>): String = buildString {
        for (s in sections) {
            append("S|").append(enc(s.id)).append('|').append(s.layout.key).append('|').append(enc(s.anchor)).append('|').append(enc(s.title))
            // After the title: the rule, the card (kind, text, arg), then whether the name shows and the size. A field is written only when something after it (or it) is not the usual.
            val styled = !s.style.isDefault
            val extras = !s.showTitle || s.width > 0 || s.height > 0 || s.spaceBelow >= 0 || styled
            if (s.rule != null || s.card != null || extras) append('|').append(enc(s.rule?.encode().orEmpty()))
            if (s.card != null || extras) append('|').append(enc(s.card?.kind.orEmpty())).append('|').append(enc(s.card?.text.orEmpty())).append('|').append(enc(s.card?.arg.orEmpty()))
            if (extras) append('|').append(if (s.showTitle) "1" else "0").append('|').append(s.width).append('|').append(s.height)
            if (s.spaceBelow >= 0 || styled) append('|').append(s.spaceBelow)
            if (styled) append('|').append(enc(s.style.encode()))   // the last field: after the space below
            append('\n')
            for (r in s.refs) append(if (r.box) "B|" else "N|").append(enc(r.key)).append('\n')
        }
    }

    /** Reads what [encode] wrote. Anything that does not make sense (a thing before any section, a repeated id, a half line) is skipped, never an error. */
    fun decode(text: String?): List<HomeSection> {
        val out = ArrayList<HomeSection>()
        val seen = HashSet<String>()
        var cur: HomeSection? = null
        for (line in text.orEmpty().split('\n')) {
            val p = line.split('|')
            when (p[0]) {
                "S" -> {
                    cur?.let { out.add(it) }
                    cur = null
                    if (p.size >= 5 && p[1].isNotEmpty() && seen.add(dec(p[1]))) cur = HomeSection(dec(p[1]), dec(p[4]), SectionLayout.of(p[2]), dec(p[3]), rule = SectionRule.parse(p.getOrNull(5)?.let { dec(it) }),
                        card = if (p.size >= 9) SectionCard.parse(dec(p[6]), dec(p[7]), dec(p[8])) else null,
                        showTitle = p.getOrNull(9) != "0", width = sizeField(p.getOrNull(10), MIN_WIDTH, MAX_WIDTH), height = sizeField(p.getOrNull(11), MIN_HEIGHT, MAX_HEIGHT),
                        spaceBelow = p.getOrNull(12)?.toIntOrNull()?.let { if (it < 0) -1 else it.coerceAtMost(MAX_SPACE) } ?: -1,
                        style = SectionStyle.decode(p.getOrNull(13)?.let { dec(it) }))
                }
                "B", "N" -> {
                    val c = cur
                    if (c != null && p.size >= 2 && p[1].isNotEmpty()) {
                        val r = SectionRef(p[0] == "B", dec(p[1]))
                        if (r !in c.refs) cur = c.copy(refs = c.refs + r)
                    }
                }
            }
        }
        cur?.let { out.add(it) }
        return out
    }
}

/** Moves a part one place up or down among the parts that are shown (hidden ones are stepped over). At the top or bottom nothing changes. */
fun HomeLayout.shifted(e: HomeElement, dir: Int): HomeLayout {
    val i = order.indexOf(e)
    if (i < 0 || dir == 0) return this
    var j = i + dir
    while (j in order.indices && order[j] in hidden) j += dir
    return if (j in order.indices) move(i, j) else this
}
