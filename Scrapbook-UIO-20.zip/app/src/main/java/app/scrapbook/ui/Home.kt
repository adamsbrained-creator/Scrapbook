package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.onLongClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.draw.alpha
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val TAB_COLORS = listOf(Color(0xFF3DD9D6), Color(0xFFFF5A44), Color(0xFFFFC107), Color(0xFF00A97F), Color(0xFF8E7CF0), Color(0xFF3B82F6), Color(0xFFFF6FAE), Color(0xFFFF8A3D))
val TAB_NAMES = listOf("Teal", "Red", "Amber", "Green", "Violet", "Blue", "Pink", "Orange")
val TAB_GRAY = Color(0xFFB4B4B4)

internal fun fmtDate(ms: Long, long: Boolean): String {
    val d = Date(ms); val day = Fmt.of("yyyyMMdd")
    val time = Fmt.of("h:mm a").format(d)
    return if (day.format(d) == day.format(Date())) (if (long) "Today · $time" else time) else Fmt.of("MMM d").format(d)
}

@Composable
private fun TopBtn(kind: String, desc: String, onClick: () -> Unit) {
    Box(Modifier.pressScale(.88f).size(44.dp).tapIcon(desc, onClick), Alignment.Center) { Ic(kind, 24.dp, Sb.ink) }
}

@Composable
fun SegIcon(kind: String, on: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (on) Sb.raised else Sb.raised.copy(alpha = 0f), tween(180), label = "segIcon")
    Box(Modifier.size(58.dp, 38.dp).clip(RoundedCornerShape(22.dp)).background(bg).tapIcon(kind, onClick), Alignment.Center) {
        Ic(kind, 22.dp, if (on) Sb.ink else Sb.mute)
    }
}

/** A box tile for the two square looks: a card with a colored tab (default), or a card with two sheets peeking out behind it. The other Box styles are in BoxStyles.kt. */
@Composable
fun TileBox(name: String, count: Int, tab: Color, modifier: Modifier, onHold: () -> Unit, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    if (LocalBoxStyle.current == 1) {
        Box(modifier.aspectRatio(1f)) {
            Box(Modifier.matchParentSize().padding(start = 6.dp, end = 2.dp, top = 2.dp, bottom = 6.dp).rotate(-4f).clip(shape).background(tab.copy(alpha = .45f)))
            Box(Modifier.matchParentSize().padding(start = 2.dp, end = 6.dp, top = 6.dp, bottom = 2.dp).rotate(3f).clip(shape).background(Sb.line))
            Box(Modifier.matchParentSize().padding(3.dp).clip(shape).background(Sb.card).tapOrHold(name, "Delete box", onHold, onClick)) {
                Row(Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(tab)); Spacer(Modifier.width(6.dp))
                    Text("$count", fontSize = 12.sp, color = Sb.mute)
                }
                Text(name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 12.dp, end = 4.dp))
            }
        }
    } else Box(modifier.aspectRatio(1f).clip(shape).background(Sb.card).tapOrHold(name, "Delete box", onHold, onClick)) {
        Box(Modifier.align(Alignment.TopEnd).padding(end = 16.dp).width(32.dp).height(8.dp)
            .clip(RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)).background(tab))
        Text("$count", fontSize = 12.sp, color = Sb.mute, modifier = Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 22.dp))
        Text(name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 12.dp, end = 4.dp))
    }
}

@Composable
private fun Meta(n: Item, hasPreview: Boolean) {
    val pop = justTurnedOn(n.pinned)
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmtDate(n.savedAt, hasPreview), fontSize = 13.sp, color = Sb.mute)
            if (n.pinned) { Spacer(Modifier.width(6.dp)); PinStar(14.dp, pop) }
        }
        if (n.tags.isNotEmpty()) Text(tagLine(n.tags), fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun RowTitle(n: Item, size: TextUnit = 19.sp, lines: Int = 1, terms: List<String> = emptyList()) {
    Text(hlTerms(n.displayTitle, terms, LocalSb.current.acc.copy(alpha = .28f)), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = size, maxLines = lines, overflow = TextOverflow.Ellipsis)
}

/** Height of a scrap's cover image when it sits on top of its card in a list. */
private val COVER_H = 88.dp

/** One scrap in the list. It follows the scrap's page layout, so changing the layout changes how it looks here. Hold it to run onHold (delete). */
@Composable
fun NoteRow(n: Item, nav: NavController, modifier: Modifier = Modifier, holdLabel: String = "Delete scrap", pick: Pick? = null, terms: List<String> = emptyList(), onHold: () -> Unit = {}) {
    // While searching ([terms] not empty) the preview shows the part of the text around the first match, and every match is marked.
    val mark = LocalSb.current.acc.copy(alpha = .28f)
    val imgs = n.allImages(); val showPreview = LocalShowPreview.current
    // Only the start of the text is needed to fill the card; the whole text is read when it has to be (searching).
    val preview = remember(n.title, n.body, n.layout, terms, showPreview) {
        if (!showPreview) "" else if (terms.isEmpty()) previewHead(n.title, n.body) else snippet(cachedPreview(n.title, n.body), terms)
    }
    val shape = RoundedCornerShape(LocalHomeLook.current.radius(28f).dp); val tint = LocalSb.current.tint   // the corners follow the look of Home; elsewhere that is the classic 28
    val open = { nav.navigate("edit/${n.id}") }
    val lead = modifier.appear("n${n.id}").pressScale(.98f)
    // The card dresses itself the way the scrap was customized: page color as a soft tint, accent as a bar on the left edge, cover image on top.
    // The layout below only fills the inside, so every layout gets the same dressing.
    val card = Modifier.fillMaxWidth()
    Column(lead.fillMaxWidth().clip(shape).selectMark(pick != null, pick?.selected == true).background(Sb.card).background(pageTint(n.color) ?: Color.Transparent)
        .accentEdge(n.accent, if (n.cover != null) COVER_H else 0.dp).tapOrHold(if (pick != null) "Select ${n.title}" else "Open ${n.title}", holdLabel, onHold, pick?.onToggle ?: open)) {
    if (n.cover != null) ItemImage(n.copy(imageUri = n.cover), Modifier.fillMaxWidth().height(COVER_H), 0.dp)
    Box(Modifier.padding(20.dp)) {
    when (n.layout) {
        Layout.Classic -> Row(card, verticalAlignment = Alignment.CenterVertically) {
            // Cards: the box (color dot and name) and the date on top, then the bold title with its pin, the preview and the tags.
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(boxDotColor(n.collection)))
                    Spacer(Modifier.width(8.dp))
                    Text(LocalShelves.current.displayName(n.collection).ifBlank { "Inbox" }, Modifier.weight(1f), fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(fmtDate(n.savedAt, false), fontSize = 12.sp, color = Sb.mute)
                }
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(hlTerms(n.displayTitle, terms, mark), Modifier.weight(1f, fill = false), fontFamily = headFont(), fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (n.pinned) { Spacer(Modifier.width(8.dp)); PinStar(16.dp, justTurnedOn(n.pinned)) }
                }
                if (preview.isNotBlank()) Text(hlTerms(preview, terms, mark), fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (n.tags.isNotEmpty()) Text(tagLine(n.tags), fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            }
            if (imgs.isNotEmpty()) {
                Box(Modifier.padding(start = 12.dp).size(88.dp, 96.dp)) {
                    if (imgs.size > 1) ItemImage(n.copy(imageUri = imgs[1]), Modifier.size(58.dp, 74.dp).align(Alignment.CenterStart).rotate(-8f), 10.dp)
                    ItemImage(n.copy(imageUri = imgs[0]), Modifier.size(58.dp, 74.dp).align(Alignment.CenterEnd).rotate(6f)
                        .border(2.dp, Color.White, RoundedCornerShape(10.dp)), 10.dp)
                }
            }
        }
    }
    }
    }
}

/** A scrap in the two-column grid. Same dressing as NoteRow; a cover image takes the place of the little drawing, so every tile keeps the same height. */
@Composable
fun NoteTile(n: Item, nav: NavController, modifier: Modifier, holdLabel: String = "Delete scrap", pick: Pick? = null, terms: List<String> = emptyList(), onHold: () -> Unit = {}) {
    Column(modifier.appear("t${n.id}").pressScale(.97f).clip(RoundedCornerShape(28.dp)).selectMark(pick != null, pick?.selected == true).background(Sb.card).background(pageTint(n.color) ?: Color.Transparent)
        .accentEdge(n.accent).tapOrHold(if (pick != null) "Select ${n.title}" else "Open ${n.title}", holdLabel, onHold, pick?.onToggle ?: { nav.navigate("edit/${n.id}") }).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(hlTerms(n.displayTitle, terms, LocalSb.current.acc.copy(alpha = .28f)), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Meta(n, false)
        Box(Modifier.fillMaxWidth().padding(top = 10.dp).height(140.dp), Alignment.Center) {
            if (n.cover != null) ItemImage(n.copy(imageUri = n.cover), Modifier.fillMaxSize(), 18.dp) else NotePreviewArt(n)
        }
    }
}

/** A small drawing of what is inside a note: its photos, a checklist, or a page of text. */
@Composable
fun NotePreviewArt(n: Item) {
    val imgs = n.allImages(); val dark = Sb.dark
    val checks = remember(n.body) {
        // A "- [ ]" line inside a code block is code, not a task: a scrap that has a block is read line by line with that in mind.
        if ("```" in n.body) n.body.lines().let { ls -> val cs = codeLineStates(ls); ls.filterIndexed { i, l -> cs[i] == CodeLine.NONE && (l.startsWith("- [ ] ") || l.startsWith("- [x] ")) }.take(4) }
        else n.body.lineSequence().filter { it.startsWith("- [ ] ") || it.startsWith("- [x] ") }.take(4).toList()
    }
    val barC = Sb.mute.copy(alpha = .45f); val lineC = Sb.mute.copy(alpha = .22f)
    when {
        imgs.isNotEmpty() -> Box(Modifier.size(120.dp, 130.dp)) {
            if (imgs.size > 1) ItemImage(n.copy(imageUri = imgs[1]), Modifier.size(84.dp, 108.dp).align(Alignment.TopEnd).rotate(7f).border(3.dp, Color.White, RoundedCornerShape(10.dp)), 10.dp)
            ItemImage(n.copy(imageUri = imgs[0]), Modifier.size(84.dp, 108.dp).align(Alignment.BottomStart).rotate(-5f).border(3.dp, Color.White, RoundedCornerShape(10.dp)), 10.dp)
        }
        checks.isNotEmpty() -> {
            val green = if (dark) Color(0xFF26332A) else Color(0xFFE3EEDD); val gd = Color(0xFF5E8F4F)
            Box(Modifier.size(130.dp, 120.dp)) {
                Box(Modifier.align(Alignment.BottomEnd).size(110.dp, 100.dp).rotate(5f).clip(RoundedCornerShape(16.dp)).background(green.copy(alpha = .6f)))
                Column(Modifier.align(Alignment.TopStart).size(112.dp, 104.dp).clip(RoundedCornerShape(16.dp)).background(green).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    checks.take(4).forEach { l ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.size(13.dp).clip(CircleShape).background(if (l.startsWith("- [x]")) gd else Color.Transparent).border(1.5.dp, gd, CircleShape))
                            Box(Modifier.height(4.dp).weight(1f).clip(RoundedCornerShape(2.dp)).background(gd.copy(alpha = .45f)))
                        }
                    }
                }
            }
        }
        else -> Box(Modifier.size(118.dp, 132.dp)) {
            Box(Modifier.align(Alignment.TopEnd).size(88.dp, 118.dp).rotate(6f).clip(RoundedCornerShape(8.dp)).background(lineC))
            Column(Modifier.align(Alignment.BottomStart).size(88.dp, 118.dp).shadow(3.dp, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))
                .background(if (dark) Color(0xFF2A2A2A) else Color.White).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth(.6f).height(5.dp).clip(RoundedCornerShape(3.dp)).background(barC))
                repeat(minOf(6, maxOf(2, n.body.length / 28))) { i -> Box(Modifier.fillMaxWidth(if (i % 3 == 2) .5f else 1f).height(3.dp).clip(RoundedCornerShape(2.dp)).background(lineC)) }
            }
        }
    }
}

/** Lets the content be flicked left or right to dismiss it. */
@Composable
fun SwipeAway(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    var x by remember { mutableFloatStateOf(0f) }
    Box(Modifier.offset { IntOffset(x.roundToInt(), 0) }.alpha((1f - abs(x) / 900f).coerceIn(0.2f, 1f))
        .pointerInput(Unit) { detectHorizontalDragGestures(onDragEnd = { if (abs(x) > 220f) onDismiss() else x = 0f }) { c, d -> c.consume(); x += d } }) { content() }
}

@Composable
private fun Wordmark(modifier: Modifier, center: Boolean = false, size: TextUnit = 30.sp) {
    Text("scrapbook", modifier, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = size, letterSpacing = (-0.03).em, textAlign = if (center) TextAlign.Center else TextAlign.Start)
}

/** A round white button, used by the "Round" header. */
@Composable
private fun RoundTop(kind: String, desc: String, onClick: () -> Unit) {
    Box(Modifier.pressScale(.9f).size(48.dp).clip(CircleShape).background(Sb.card).tapIcon(desc, onClick), Alignment.Center) { Ic(kind, 22.dp, Sb.ink) }
}

@Composable
private fun MoreMenu(open: Boolean, onDismiss: () -> Unit, onRediscover: () -> Unit, onCollections: () -> Unit, onSettings: () -> Unit) {
    PopupMenu(open, onDismiss) {
        PopupItem("Rediscover", "sparkle", onClick = onRediscover)
        PopupItem("Boxes", "folder", onClick = onCollections)
        PopupItem("Settings", "sliders", onClick = onSettings)
    }
}

/** The header the Home page and the All scraps page share: menu, wordmark and search, laid out the way the Main page header setting says. */
@Composable
internal fun MainHeader(header: Int, hs: Float, nav: NavController, onMenu: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val moreMenu: @Composable () -> Unit = {
        MoreMenu(menu, { menu = false }, { menu = false; nav.navigate("rediscover") }, { menu = false; nav.navigate("collections") }, { menu = false; nav.navigate("settings") })
    }
    when (header) {
        0 -> Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TopBtn("menu", "Menu", onMenu)
            Wordmark(Modifier.weight(1f).padding(start = 8.dp), size = 30.sp * hs)
            SearchHold(nav) { TopBtn("search", "Search") { nav.navigate("search") } }
            Box { TopBtn("more", "More") { menu = true }; moreMenu() }
        }
        1 -> Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f)) { TopBtn("menu", "Menu", onMenu) }
            Wordmark(Modifier, size = 30.sp * hs)
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                SearchHold(nav) { TopBtn("search", "Search") { nav.navigate("search") } }
                Box { TopBtn("more", "More") { menu = true }; moreMenu() }
            }
        }
        else -> Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundTop("menu", "Menu", onMenu)
            Wordmark(Modifier.weight(1f), center = true, size = 34.sp * hs)
            SearchHold(nav) { RoundTop("search", "Search") { nav.navigate("search") } }
        }
    }
}

/** What stays of the header when it is hidden: only the menu button, at the left or the right (Customize home > Header), or none (then the greeting's hold menu and an empty spot still open the menu and Customize home). */
@Composable
internal fun MenuOnlyHeader(right: Boolean = false, onMenu: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), if (right) Arrangement.End else Arrangement.Start, Alignment.CenterVertically) { TopBtn("menu", "Menu", onMenu) }
}

/** After a scrap is deleted: back to the All scraps page if it is open underneath, otherwise to the Home page. */
/** Opens a box. When the box is already the screen just underneath (you came from it), Back is used instead of stacking the same box twice. */
fun NavController.openBox(name: String) {
    val prev = previousBackStackEntry
    if (prev?.destination?.route == "shelf/{name}" && prev.arguments?.getString("name") == name) popBackStack() else navigate("shelf/$name")
}

fun NavController.backToLists() { if (!popBackStack("scraps", false)) popBackStack("home", false) }

/**
 * The menu: the places to browse, then Settings and About, plus a big New scrap button. Opened from the menu button in the header or the bottom bar.
 * App style, backup and box management live on the Settings page now, so they are not repeated here.
 *
 * What it shows, and in what order, is the saved MenuLayout (LocalMenuLayout; Customize menu changes it), and how it looks is the menu skin (MenuSkins.kt).
 * [summary] is the small line some skins print under the buttons. With [preview] the rows do nothing, so Customize menu can show the real menu without leaving.
 */
@Composable
fun MenuSheet(nav: NavController, onClose: () -> Unit, onGoTo: () -> Unit = {}, onCustomize: (() -> Unit)? = null, summary: String? = null, preview: Boolean = false, onNew: () -> Unit) {
    val layout = LocalMenuLayout.current; val o = menuOptions(); val actions = LocalMenuActions.current
    // Customize home only makes sense on the Home page, which is the one that passes onCustomize.
    val groups = remember(layout, onCustomize != null) { layout.groups { !(it is MenuItem.Entry && it.entry == MenuEntry.CustomizeHome && onCustomize == null) } }
    fun go(route: String) { onClose(); nav.navigate(route) }
    fun open(item: MenuItem) {
        if (preview) return
        when (item) {
            is MenuItem.Gap -> {}
            is MenuItem.Shortcut -> { onClose(); actions.open(item.shortcut) }
            is MenuItem.Entry -> when (item.entry) {
                MenuEntry.Home -> { onClose(); nav.popBackStack("home", false) }
                MenuEntry.AllScraps -> go("scraps")
                MenuEntry.Pinned -> go("shelf/Pinned")
                MenuEntry.Recent -> go("shelf/Recent")
                MenuEntry.Rediscover -> go("rediscover")
                MenuEntry.Timeline -> go("timeline")   // [timeline hook 2]
                MenuEntry.GoTo -> { onClose(); onGoTo() }
                MenuEntry.Search -> go("search")
                MenuEntry.Bin -> go("bin")
                MenuEntry.CustomizeHome -> { onClose(); onCustomize?.invoke() }
                MenuEntry.CustomizeMenu -> go("menus")
                MenuEntry.Settings -> go("settings")
                MenuEntry.About -> go("about")
            }
        }
    }
    // The big button at the bottom is whatever Customize menu chose: a new scrap (the usual), a checklist, a photo, a voice memo, Search, or nothing.
    val bottom = o.bottom
    val newScrap: () -> Unit = { onClose(); if (!preview) { onNew(); nav.navigate("edit/0") } }
    val other: () -> Unit = { onClose(); if (!preview) actions.start(bottom) }
    val run: (() -> Unit)? = when (bottom) { MenuBottom.None -> null; MenuBottom.NewScrap -> newScrap; else -> other }
    // Holding the title always opens Customize menu, even when the menu has no Settings and no Customize menu in it.
    val hold: (() -> Unit)? = if (preview) null else ({ onClose(); actions.customize() })
    Sheet(o.titleOrDefault, onClose, doneLabel = if (run != null) bottom.label else "Close", primary = run, cancelLabel = "Close",
        footer = o.footerText.ifBlank { summary }, capsule = run?.let { SheetCapsule(bottom.icon, bottom.label, bottom.sub.ifBlank { null }, it) },
        showTitle = o.showTitle, showCancel = when (o.cancel) { 1 -> true; 2 -> false; else -> null }, showButtons = run != null || o.cancel != 2,
        accent = o.accent, onTitleHold = hold) {
        Spacer(Modifier.height(8.dp))   // air between the title and the first group
        if (o.profile) MenuProfile { if (!preview) { onClose(); actions.account() } }
        groups.forEach { g -> MenuCard(layout.groupTitle(g), g) { open(it) } }
        if (groups.isEmpty()) Text("Nothing is in the menu. Hold the title at the top to open Customize menu and bring things back.", Modifier.padding(horizontal = 6.dp, vertical = 12.dp),
            fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute)
    }
}

/** The "New scrap" pill, one add button per page. */
@Composable
fun NewScrapPill(modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.padding(20.dp).pressScale(.95f).shadow(10.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp)).background(Sb.ink)
        .tap("New scrap", onClick).padding(horizontal = 24.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Ic("edit", 24.dp, Sb.card); Text("New scrap", color = Sb.card, fontWeight = FontWeight.Medium, fontSize = 17.sp)
    }
}

/**
 * Bottom bar option, copied from Binder: one round menu button. Tap it for the menu. Hold it and the round + button pops out beside it
 * (tap + to add a scrap). Tap anywhere else, or the menu button again, to put the + away. Place it with Modifier.matchParentSize() inside a Box.
 */
@Composable
fun BottomNav(modifier: Modifier, onMenu: () -> Unit, onAdd: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val pop by animateFloatAsState(if (open) 1f else 0f, spring(dampingRatio = .6f, stiffness = Spring.StiffnessMedium), label = "addPop")
    val ring by animateDpAsState(if (open) 4.dp else 0.dp, tween(150), label = "menuRing")
    val press by animateFloatAsState(if (open) .94f else 1f, tween(150), label = "menuPress")
    val ringColor = Sb.line
    Box(modifier) {
        // While the + is out, a tap anywhere else only puts it away.
        if (open) Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { open = false } })
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 18.dp)) {
            Box(Modifier.align(Alignment.BottomEnd).offset(x = (-68).dp).size(58.dp)
                .graphicsLayer { alpha = pop.coerceIn(0f, 1f); scaleX = .4f + .6f * pop; scaleY = .4f + .6f * pop; translationX = (1f - pop) * 36.dp.toPx() }
                .clip(CircleShape).background(Sb.ink).border(1.dp, Sb.line, CircleShape)
                .then(if (open) Modifier.tap("Add scrap") { open = false; onAdd() } else Modifier), Alignment.Center) { Ic("plus", 28.dp, Sb.card) }
            Box(Modifier.align(Alignment.BottomEnd).size(58.dp)
                .graphicsLayer { scaleX = press; scaleY = press }
                .drawBehind { if (ring > 0.dp) drawCircle(ringColor, radius = size.minDimension / 2 + ring.toPx()) }
                .clip(CircleShape).background(Sb.ink)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onLongPress = { open = true; haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                        onTap = { open = false; onMenu() })
                }
                .semantics(mergeDescendants = true) {
                    contentDescription = "Menu"; role = Role.Button
                    onClick("Open menu") { open = false; onMenu(); true }
                    onLongClick("Add scrap") { open = false; onAdd(); true }
                }, Alignment.Center) { Ic("menu", 26.dp, Sb.card) }
        }
    }
}

/** The All scraps page: collection tiles on top, then every scrap as a list or grid. Opened from the Home page and the menu. */
@Composable
fun AllScrapsScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    val inboxColor by vm.inboxColor.collectAsState(); val deleted by vm.deleted.collectAsState(); val header by vm.headerStyle.collectAsState()
    val snack = remember { SnackbarHostState() }
    val inboxHidden by vm.inboxHidden.collectAsState(); var deleting by remember { mutableStateOf<String?>(null) }; var deletingScrap by remember { mutableStateOf<Item?>(null) }
    var menuSheet by remember { mutableStateOf(false) }; val navStyle by vm.navStyle.collectAsState()
    // The layout starts as the Default view setting. Picking another one with the layout picker only changes it until you leave the app.
    val defaultLayout by vm.defaultLayout.collectAsState(); var layoutPick by rememberSaveable { mutableStateOf<String?>(null) }
    val layout = layoutPick?.let { ListLayout.of(it) } ?: defaultLayout
    var filter by rememberSaveable(stateSaver = ScrapFilterSaver) { mutableStateOf(ScrapFilter()) }; var filterSheet by remember { mutableStateOf(false) }
    // Sorting is saved, so the Sort by and Sort order settings and the sort controls on this page always agree.
    val sortMode by vm.sortMode.collectAsState(); val asc by vm.sortAsc.collectAsState()
    val showBoxes by vm.showBoxes.collectAsState(); val headerSize by vm.headerSize.collectAsState()
    val hs = listOf(.8f, 1f, 1.2f)[headerSize.coerceIn(0, 2)]
    LaunchedEffect(deleted) {
        if (deleted != null) { val r = snack.showSnackbar("Scrap deleted", "Undo", duration = SnackbarDuration.Long); if (r == SnackbarResult.ActionPerformed) vm.undoDelete() else vm.clearDeleted() }
    }
    val sorted = remember(all, sortMode, asc, filter) { all.filteredBy(filter, System.currentTimeMillis()).sortedFor(sortMode, asc) }
    val inbox = all.count { it.collection == "Inbox" }
    // Selection toolbar: long-press a scrap to start picking (see Selecting.kt). Picks that leave the list (filtered out, moved, deleted) drop out by themselves.
    var picked by rememberSaveable { mutableStateOf(emptyList<Long>()) }
    var batchSheet by remember { mutableIntStateOf(0) }   // 0 none, 1 Add to box, 2 Tags
    val scope = rememberCoroutineScope(); val haptics = LocalHaptics.current
    val selecting = picked.isNotEmpty(); val shownIds = sorted.map { it.id }; val chosen = sorted.filter { it.id in picked }
    fun pickFor(n: Item): Pick? = if (selecting) Pick(n.id in picked) { picked = picked.toggled(n.id) } else null
    LaunchedEffect(shownIds) { picked = picked.stillShown(shownIds) }
    BackHandler(enabled = selecting) { picked = emptyList() }

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.paper, snackbarHost = { SnackbarHost(snack) { d -> SwipeAway({ d.dismiss() }) { Snackbar(d, shape = RoundedCornerShape(20.dp), containerColor = Sb.ink, contentColor = Sb.card, actionColor = t.acc) } } }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = navClearance(navStyle, 120.dp)), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item { if (selecting) SelectionHeader(chosen.size, shownIds.size, { picked = emptyList() }, { picked = if (chosen.size >= shownIds.size) emptyList() else shownIds }) else MainHeader(header, hs, nav) { menuSheet = true } }
                    // The page's title sits small under the menu button, the way the other pages (Settings and the rest) show theirs.
                    item { Text("All scraps", Modifier.padding(start = 12.dp).offset(y = (-4).dp), fontSize = 16.sp, fontWeight = FontWeight.Medium) }
                    if (showBoxes && layout != ListLayout.ByBox) item {
                        val inboxTile = if (inboxHidden) emptyList<BoxTile>() else listOf(BoxTile("Inbox", inbox, if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]))
                        val tiles = shelves.topLevel().map { BoxTile(it.name, all.count { n -> n.collection == it.name }, TAB_COLORS[it.color % TAB_COLORS.size], it.label, shelves.childrenOf(it.name).size) } + inboxTile
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            BoxGrid(tiles, onHold = { deleting = it }, onNew = { nav.navigate("collections") }) { nav.navigate("shelf/$it") }
                            if (shelves.isEmpty() && LocalBoxStyle.current != 4 && LocalBoxStyle.current != 6) NewBoxPill("Create your first box") { nav.navigate("collections") }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                LayoutPicker(layout) { layoutPick = it.key }
                                FilterButton(filter) { filterSheet = true }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Ic("sort", 22.dp, Sb.mute)
                                // Tapping the label goes to the next sort field (edited, created, title) and resets the order to its natural one: newest first, or A to Z.
                                Text(sortMode.label, color = Sb.mute, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 8.dp).tap("Change sort order type") { vm.setSort(SortMode.entries[(sortMode.ordinal + 1) % SortMode.entries.size]) })
                                Box(Modifier.width(1.5.dp).height(22.dp).background(Sb.ink))
                                Box(Modifier.size(44.dp).tapIcon("Reverse order") { vm.setSortAsc(!asc) }, Alignment.Center) { Ic(if (asc) "up" else "down", 22.dp, Sb.mute) }
                            }
                        }
                    }
                    if (sorted.isEmpty()) item { AllEmpty(vm, nav, filter.isOn && all.isNotEmpty()) { filter = ScrapFilter() } }   // [empty-states hook 4]
                    else scrapLayout(layout, sorted, nav, emptyList(), sortMode, asc, { pickFor(it) }) { picked = picked.added(it.id) }
                }
                val addScrap = { vm.pendingShelf = null; nav.navigate("edit/0") }
                if (selecting) SelectionBar(Modifier.align(Alignment.BottomCenter), allPinned(chosen), { batchSheet = 1 },
                    { haptics.toggle(!allPinned(chosen)); batchPin(vm, chosen, scope, snack); picked = emptyList() }, { batchSheet = 2 }, { batchDelete(vm, chosen, scope, snack); picked = emptyList() })
                else AddNav(navStyle, vm, nav, "Inbox", { menuSheet = true }, addScrap)
            }
        }
        if (menuSheet) MenuSheet(nav, { menuSheet = false }, { vm.switcherOpen.value = true }, summary = menuSummary(all.size, shelves.size)) { vm.pendingShelf = null }
        deleting?.let { n -> DeleteBoxSheet(n, vm, { deleting = null }) }
        deletingScrap?.let { n -> DeleteScrapSheet(n, vm) { deletingScrap = null } }
        if (batchSheet == 1) PickBoxSheet(vm, { box -> batchMove(vm, chosen, box, scope, snack); picked = emptyList() }, { batchSheet = 0 }, withInbox = true, subtitle = scrapsLabel(chosen.size))
        if (batchSheet == 2) AddTagsSheet(vm, chosen.size, { tags -> batchTag(vm, chosen, tags, scope, snack); picked = emptyList() }, { batchSheet = 0 })
        if (filterSheet) FilterSheet(filter, { filter = it }, all, listOf("Inbox") + shelves.map { it.name }, sorted.size) { filterSheet = false }
    }
}
