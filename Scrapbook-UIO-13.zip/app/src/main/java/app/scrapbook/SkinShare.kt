package app.scrapbook

import java.util.Base64

// Sharing a Home skin as a piece of text (see HomeSkins.kt): one line starting with [PREFIX] that can be sent in any message and added on another phone from the Skins page.
// A skin made of shortcuts to your own scraps and boxes would be empty somewhere else, so those sections are left out; cards and sections that fill themselves are kept.
// Only rules here, so they are tested on their own (SkinShareTest).

object SkinShare {
    const val PREFIX = "scrapbook-skin-v1:"

    /** The longest code that is read; a real skin is a few thousand characters at most. */
    const val MAX_CODE = 24_000

    /** [values] without the sections that point at things only this phone has (the ones that are neither smart nor a card). */
    fun portable(values: Map<String, String>): Map<String, String> {
        val text = values[SkinKeys.SECTIONS] ?: return values
        val kept = HomeSections.decode(text).filter { it.isSmart || it.isCard }
        return HomeSkins.sparse(values + (SkinKeys.SECTIONS to HomeSections.encode(kept)))
    }

    /** The code for [skin]: [PREFIX] and the skin written as URL-safe text. */
    fun export(skin: HomeSkin): String {
        val one = HomeSkins(listOf(HomeSkin(HomeSkins.CLASSIC_ID, HomeSkins.CLASSIC_NAME), HomeSkin("shared", skin.name, portable(skin.values))), "shared")
        return PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(one.encode().toByteArray(Charsets.UTF_8))
    }

    /**
     * The skin a piece of text carries, or null if it carries none. The code may sit inside other words (a message around it), and only the first one is read.
     * What comes out has a name and only real pieces of Home; the caller adds it as a skin of its own, which gives it a new id.
     */
    fun parse(text: String?): HomeSkin? {
        val t = text.orEmpty().take(MAX_CODE + 200)
        val at = t.indexOf(PREFIX)
        if (at < 0) return null
        val code = t.substring(at + PREFIX.length).takeWhile { !it.isWhitespace() }
        if (code.isEmpty() || code.length > MAX_CODE) return null
        val raw = try { String(Base64.getUrlDecoder().decode(code), Charsets.UTF_8) } catch (e: IllegalArgumentException) { return null }
        val skin = HomeSkins.decode(raw).skins.firstOrNull { !it.builtIn } ?: return null
        return skin.copy(values = portable(skin.values))
    }
}
