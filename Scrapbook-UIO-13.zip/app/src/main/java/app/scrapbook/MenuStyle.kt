package app.scrapbook

/**
 * The skins a menu can wear. [key] is what is saved, so never rename one. What each skin looks like is in ui/MenuSkins.kt; this is only the list and the names.
 * Add a skin: add it here, give it a MenuSkin in MenuSkins.kt and a case in MenuSkins.of.
 */
enum class MenuSkinId(val key: String, val label: String, val blurb: String) {
    Classic("classic", "Classic", "The sheet you know: docked to the bottom, soft grey groups, one big button."),
    Floating("float", "Float", "A card that floats above the page, with a centered title, outlined groups, icon tiles and two buttons."),
    Minimal("minimal", "Minimal", "Plain rows on a quiet sheet: no cards, no arrows, a small title. The calmest one."),
    Bento("bento", "Bento", "A floating sheet where every entry is a tile, two to a row, like a small control panel.");

    companion object {
        /** An unknown or missing name falls back to Classic, so a skin removed in a later version never leaves the menu without a look. */
        fun of(key: String?): MenuSkinId = entries.firstOrNull { it.key == key } ?: Classic
    }
}

/** What the big button at the bottom of the menu does. [None] leaves the menu without one. */
enum class MenuBottom(val key: String, val label: String, val icon: String, val sub: String) {
    NewScrap("scrap", "New scrap", "plus", "A blank page, saved as you type"),
    NewChecklist("checklist", "New checklist", "taskcheck", "A page that starts as a list"),
    Photo("photo", "New photo scrap", "image", "Pick a photo, then write"),
    Voice("voice", "Voice memo", "mic", "Record, then write"),
    Search("search", "Search", "search", "Find any scrap"),
    None("none", "No main button", "none", "");

    companion object { fun of(key: String?): MenuBottom = entries.firstOrNull { it.key == key } ?: NewScrap }
}

/**
 * The choices that work on top of any skin. Whether a skin uses one is up to the skin: Classic has no footer line and no floating pill, so those two do nothing there.
 * [rowSize] 0 compact, 1 comfortable, 2 roomy; [dim] 0 light, 1 normal, 2 strong; [action] 0 buttons, 1 a floating pill.
 * [groupNames] and [cancel] are "0 the skin decides, 1 always, 2 never". [title] and [footerText] blank mean the usual words.
 */
data class MenuOptions(
    val rowSize: Int = 1,
    val icons: Boolean = true,
    val dim: Int = 1,
    val footer: Boolean = true,
    val action: Int = 0,
    val title: String = "",
    val showTitle: Boolean = true,
    val groupNames: Int = 0,
    val cancel: Int = 0,
    val bottom: MenuBottom = MenuBottom.NewScrap,
    val footerText: String = "",
    val accent: Boolean = false,
    val profile: Boolean = false,
) {
    fun clamped(): MenuOptions = copy(
        rowSize = rowSize.coerceIn(0, 2), dim = dim.coerceIn(0, 2), action = action.coerceIn(0, 1),
        groupNames = groupNames.coerceIn(0, 2), cancel = cancel.coerceIn(0, 2),
        title = title.trim().take(MAX_TITLE), footerText = footerText.trim().take(MAX_FOOTER),
    )

    /** How dark the page behind a sheet goes. */
    val dimAlpha: Float get() = DIM_ALPHA[dim.coerceIn(0, 2)]

    /** How many dp taller (or shorter, when negative) than the usual a row is. */
    val rowDelta: Int get() = (rowSize.coerceIn(0, 2) - 1) * 8

    /** The word at the top of the menu. */
    val titleOrDefault: String get() = title.ifBlank { DEFAULT_TITLE }

    companion object {
        const val DEFAULT_TITLE = "scrapbook"
        const val MAX_TITLE = 24
        const val MAX_FOOTER = 60
        val ROW_SIZES = listOf("Compact", "Comfortable", "Roomy")
        val DIMS = listOf("Light", "Normal", "Strong")
        val ACTIONS = listOf("Buttons", "Floating pill")
        val TRI = listOf("Skin decides", "Always", "Never")
        private val DIM_ALPHA = listOf(.22f, .4f, .58f)
    }
}

/** The skin and the choices on top of it. */
data class MenuStyle(val skin: MenuSkinId = MenuSkinId.Classic, val options: MenuOptions = MenuOptions())

/** The whole menu: what it holds ([layout]) and how it looks ([style]). This is what a preset keeps. */
data class MenuConfig(val layout: MenuLayout = MenuLayout.Default, val style: MenuStyle = MenuStyle()) {

    /** One text holding everything, for presets and the backup. Every value is URL-encoded, so a name can hold any character. */
    fun encode(): String {
        val o = style.options.clamped()
        return listOf(
            "v" to "1",
            "order" to layout.encodeOrder(), "hidden" to layout.encodeHidden(), "shortcuts" to layout.encodeShortcuts(), "looks" to layout.encodeLooks(), "sections" to layout.encodeSections(),
            "skin" to style.skin.key, "rows" to o.rowSize.toString(), "icons" to o.icons.toString(), "dim" to o.dim.toString(), "footer" to o.footer.toString(), "action" to o.action.toString(),
            "title" to o.title, "showTitle" to o.showTitle.toString(), "groups" to o.groupNames.toString(), "cancel" to o.cancel.toString(), "bottom" to o.bottom.key,
            "footerText" to o.footerText, "accent" to o.accent.toString(), "profile" to o.profile.toString(),
        ).joinToString("\n") { (k, v) -> "$k=${MenuLayout.enc(v)}" }
    }

    companion object {
        /** Reads what [encode] wrote. Anything unreadable falls back to the usual value, so a damaged preset still gives a working menu. A text with no known key gives null. */
        fun decode(s: String?): MenuConfig? {
            if (s.isNullOrBlank()) return null
            val m = HashMap<String, String>()
            s.lineSequence().forEach { line ->
                val i = line.indexOf('=')
                if (i > 0) MenuLayout.dec(line.substring(i + 1))?.let { m[line.substring(0, i).trim()] = it }
            }
            if (m.isEmpty() || "order" !in m && "skin" !in m) return null
            val d = MenuOptions()
            fun int(k: String, def: Int) = m[k]?.toIntOrNull() ?: def
            fun bool(k: String, def: Boolean) = m[k]?.toBooleanStrictOrNull() ?: def
            val options = MenuOptions(
                rowSize = int("rows", d.rowSize), icons = bool("icons", d.icons), dim = int("dim", d.dim), footer = bool("footer", d.footer), action = int("action", d.action),
                title = m["title"].orEmpty(), showTitle = bool("showTitle", d.showTitle), groupNames = int("groups", d.groupNames), cancel = int("cancel", d.cancel),
                bottom = MenuBottom.of(m["bottom"]), footerText = m["footerText"].orEmpty(), accent = bool("accent", d.accent), profile = bool("profile", d.profile),
            ).clamped()
            return MenuConfig(MenuLayout.decode(m["order"], m["hidden"], m["shortcuts"], m["looks"], m["sections"]), MenuStyle(MenuSkinId.of(m["skin"]), options))
        }
    }
}

/** A named menu setup. [blob] is a [MenuConfig.encode] text. */
data class MenuPreset(val name: String, val blob: String)

/** The presets that come with the app, and the ones you saved. */
object MenuPresets {
    const val MAX_SAVED = 6
    const val MAX_NAME = 24

    private val quiet = listOf(MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Bin, MenuEntry.CustomizeHome, MenuEntry.CustomizeMenu, MenuEntry.About)

    /** The menu as the app ships it. */
    val Classic = MenuConfig()

    /** Few entries, the calm skin, small rows and no icons. */
    val Minimal = MenuConfig(
        MenuLayout(hidden = quiet.map { it.key }.toSet()),
        MenuStyle(MenuSkinId.Minimal, MenuOptions(rowSize = 0, icons = false, dim = 0, footer = false)),
    )

    /** Every entry, in cards with names, on the floating skin. */
    val Everything = MenuConfig(
        MenuLayout(),
        MenuStyle(MenuSkinId.Floating, MenuOptions(groupNames = 1, footer = true)),
    )

    val builtIn: List<Pair<String, MenuConfig>> = listOf("Classic" to Classic, "Minimal" to Minimal, "Everything" to Everything)

    /** The saved presets as one text: a line per preset, name and blob URL-encoded. */
    fun encode(list: List<MenuPreset>): String = list.joinToString("\n") { "${MenuLayout.enc(it.name)}|${MenuLayout.enc(it.blob)}" }

    /** Presets that can not be read, or whose blob is not a menu, are dropped; there are never more than [MAX_SAVED]; a name used twice keeps its first. */
    fun decode(s: String?): List<MenuPreset> {
        val out = mutableListOf<MenuPreset>()
        s.orEmpty().lineSequence().forEach { line ->
            val p = line.split('|')
            if (p.size != 2) return@forEach
            val name = MenuLayout.dec(p[0])?.trim()?.take(MAX_NAME).orEmpty()
            val blob = MenuLayout.dec(p[1]).orEmpty()
            if (name.isNotBlank() && MenuConfig.decode(blob) != null && out.none { it.name.equals(name, true) } && out.size < MAX_SAVED) out.add(MenuPreset(name, blob))
        }
        return out
    }

    /** Saves [config] under [name], replacing a preset of that name. When there is no room the oldest one goes. A blank name changes nothing. */
    fun save(list: List<MenuPreset>, name: String, config: MenuConfig): List<MenuPreset> {
        val n = name.trim().take(MAX_NAME)
        if (n.isBlank()) return list
        val rest = list.filterNot { it.name.equals(n, true) }
        return (rest + MenuPreset(n, config.encode())).takeLast(MAX_SAVED)
    }

    fun remove(list: List<MenuPreset>, name: String): List<MenuPreset> = list.filterNot { it.name.equals(name, true) }
}

/**
 * A short history of the menu, for Undo on the Customize menu page. [push] remembers the layout as it was before a change (a change that leaves it the same is
 * not remembered), [pop] gives it back. Only the last [LIMIT] are kept.
 */
class MenuHistory {
    private val steps = ArrayDeque<MenuConfig>()

    val canUndo: Boolean get() = steps.isNotEmpty()

    fun push(before: MenuConfig) {
        if (steps.lastOrNull() == before) return
        steps.addLast(before)
        while (steps.size > LIMIT) steps.removeFirst()
    }

    fun pop(): MenuConfig? = steps.removeLastOrNull()

    fun clear() = steps.clear()

    companion object { const val LIMIT = 30 }
}
