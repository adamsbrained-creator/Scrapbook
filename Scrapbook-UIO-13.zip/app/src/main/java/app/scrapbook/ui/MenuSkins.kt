package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// Menu skins: how the app's menus and small windows look. One skin is worn by every sheet (Sheet in Customize.kt), every pop-up menu (PopupMenu in Windows.kt),
// every group of rows in a sheet (SheetGroup) and the Home menu itself (MenuSheet in Home.kt), so changing the skin changes all of them at once.
// The skin and the choices on top of it (MenuStyle) are saved on this phone and handed down through LocalMenuStyle; which things the Home menu shows, what they are
// called and in what order is MenuLayout (LocalMenuLayout). Customize menu (ui/MenuEdit.kt) is where both are changed.
//
// To add a skin: add it to MenuSkinId (MenuStyle.kt), describe it here as another MenuSkin and add it to MenuSkins.of and MenuSkins.all; the Customize menu page lists it by itself.
// Everything a skin can change is a field of MenuSkin, so a new skin is mostly numbers; Float, Minimal and Bento are the examples.

/** The numbers and switches that make up one skin. Colors that depend on light or dark come from the functions at the bottom, so they follow the theme. */
@Immutable
class MenuSkin(
    val id: MenuSkinId,
    /** True: the sheet is a card that floats clear of the screen edges. False: it is docked to the bottom edge. */
    val floating: Boolean,
    /** Corner of the sheet (the top corners only, when it is docked). */
    val corner: Dp,
    /** Space between a floating sheet and the screen edges. */
    val inset: Dp,
    val centerTitle: Boolean,
    val titleSize: TextUnit,
    /** True: groups of rows are outlined cards, and may carry a name on top. False: soft fill, no outline. */
    val outlined: Boolean,
    val groupCorner: Dp,
    /** True: a row's icon sits on a small rounded tile. */
    val tiles: Boolean,
    /** True: a sheet with a real action shows Cancel and the action side by side instead of one big button (unless the menu is set otherwise). */
    val split: Boolean,
    val popupCorner: Dp,
    val popupWidth: Dp,
    /** Whether the skin has a footer line under the buttons, and a floating pill as another way to show the main button. */
    val canFooter: Boolean,
    val canPill: Boolean,
    /** Height of a row in the Home menu (of a tile, in a skin with a grid), before the row size choice adds to it or takes from it. */
    val rowHeight: Dp,
    /** False: no arrow at the end of a row. */
    val chevrons: Boolean = true,
    /** True: the groups of the Home menu have no card behind them, only the rows. */
    val flatRows: Boolean = false,
    /** True: the Home menu shows its entries as tiles, two to a row. */
    val grid: Boolean = false,
    /** Whether the cards of the Home menu carry their names (Browse, Discover, Manage) unless the menu is set otherwise. */
    val groupNames: Boolean = false,
) {
    /** The fill of a group of rows. */
    fun groupFill(): Color = when (id) {
        MenuSkinId.Classic -> Sb.line.copy(alpha = .5f)
        MenuSkinId.Floating -> if (Sb.dark) Color(0xFF262626) else Color(0xFFF6F6F6)
        MenuSkinId.Minimal -> Sb.line.copy(alpha = .3f)
        MenuSkinId.Bento -> if (Sb.dark) Color(0xFF2A2A2A) else Color(0xFFF1F1F1)
    }

    /** The outline of a group, and the hairlines between its rows. */
    fun groupLine(): Color = if (Sb.dark) Color(0xFF383838) else Color(0xFFE4E4E4)

    /** Whether the Home menu shows card names, with the choice in [o] applied. */
    fun showsNames(o: MenuOptions): Boolean = when (o.groupNames) { 1 -> true; 2 -> false; else -> groupNames }

    /** Whether a sheet with an action shows Cancel next to it, with the choice in [o] applied. */
    fun showsCancel(o: MenuOptions): Boolean = when (o.cancel) { 1 -> true; 2 -> false; else -> split }
}

object MenuSkins {
    /** The sheet as it has always been. Every number here is what the sheet used before skins existed, so choosing Classic changes nothing. */
    val Classic = MenuSkin(
        id = MenuSkinId.Classic, floating = false, corner = 32.dp, inset = 0.dp, centerTitle = false, titleSize = 22.sp, outlined = false, groupCorner = 26.dp,
        tiles = false, split = false, popupCorner = 24.dp, popupWidth = 248.dp, canFooter = false, canPill = false, rowHeight = 54.dp,
    )

    /** A floating card, after the Smart WiFi Transfer and Art-direction references: centered title, outlined groups with a name on top, icon tiles, two pill buttons, a footer line, or a floating pill. */
    val FloatSkin = MenuSkin(
        id = MenuSkinId.Floating, floating = true, corner = 34.dp, inset = 10.dp, centerTitle = true, titleSize = 20.sp, outlined = true, groupCorner = 22.dp,
        tiles = true, split = true, popupCorner = 28.dp, popupWidth = 262.dp, canFooter = true, canPill = true, rowHeight = 52.dp, groupNames = true,
    )

    /** The calm one: a docked sheet with a small title and plain rows, no cards and no arrows. */
    val MinimalSkin = MenuSkin(
        id = MenuSkinId.Minimal, floating = false, corner = 28.dp, inset = 0.dp, centerTitle = false, titleSize = 18.sp, outlined = false, groupCorner = 18.dp,
        tiles = false, split = false, popupCorner = 20.dp, popupWidth = 232.dp, canFooter = false, canPill = true, rowHeight = 48.dp,
        chevrons = false, flatRows = true,
    )

    /** A floating sheet where each entry is a tile, two to a row. */
    val BentoSkin = MenuSkin(
        id = MenuSkinId.Bento, floating = true, corner = 30.dp, inset = 8.dp, centerTitle = false, titleSize = 20.sp, outlined = false, groupCorner = 20.dp,
        tiles = false, split = true, popupCorner = 22.dp, popupWidth = 252.dp, canFooter = true, canPill = true, rowHeight = 84.dp,
        chevrons = false, grid = true, groupNames = true,
    )

    val all: List<MenuSkin> = listOf(Classic, FloatSkin, MinimalSkin, BentoSkin)

    fun of(id: MenuSkinId): MenuSkin = when (id) {
        MenuSkinId.Classic -> Classic
        MenuSkinId.Floating -> FloatSkin
        MenuSkinId.Minimal -> MinimalSkin
        MenuSkinId.Bento -> BentoSkin
    }
}

/** The skin and options in use. Provided once in MainActivity, so every window follows them. */
val LocalMenuStyle = compositionLocalOf { MenuStyle() }

/** What the Home menu shows, what it calls things and in what order (Customize menu). Provided once in MainActivity. */
val LocalMenuLayout = compositionLocalOf { MenuLayout.Default }

/** What the Home menu's rows and buttons do. Provided once in MainActivity, which knows the screens; the menu itself only says what was chosen. */
class MenuActions(
    /** The big button at the bottom of the menu (anything but No main button and New scrap, which the screen starts itself). */
    val start: (MenuBottom) -> Unit = {},
    /** A shortcut of your own. */
    val open: (MenuShortcut) -> Unit = {},
    /** Customize menu (a hold on the menu's title always opens it). */
    val customize: () -> Unit = {},
    /** The Account page, from the picture at the top of the menu. */
    val account: () -> Unit = {},
)

val LocalMenuActions = compositionLocalOf { MenuActions() }

/** The account, for the picture and name at the top of the menu when it is switched on. Null until it has been read. */
val LocalMenuAccount = compositionLocalOf<Account?> { null }

@Composable
fun menuSkin(): MenuSkin = MenuSkins.of(LocalMenuStyle.current.skin)

@Composable
fun menuOptions(): MenuOptions = LocalMenuStyle.current.options

/** The fill (and, in an outlined skin, the outline) of a group of rows or a field, with the corner of the skin unless [corner] is given. */
@Composable
fun Modifier.skinCard(corner: Dp? = null): Modifier {
    val skin = menuSkin()
    val shape = RoundedCornerShape(corner ?: skin.groupCorner)
    return this.clip(shape).background(skin.groupFill()).then(if (skin.outlined) Modifier.border(1.dp, skin.groupLine(), shape) else Modifier)
}

// ---------------------------------------------------------------------------------------------------------------------------------
// The Home menu's own pieces
// ---------------------------------------------------------------------------------------------------------------------------------

/** The color of the icons in the menu: the ink, or the accent color when the menu is set to use it. */
@Composable
private fun menuIconTint(): Color = if (menuOptions().accent) accentText(LocalSb.current.acc) else Sb.ink

/** A small name above a group of rows, in the skins that do not put it inside the card. */
@Composable
private fun GroupName(text: String) {
    Text(text.uppercase(), Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 6.dp).asHeading(),
        color = Sb.mute, fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.4.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

/**
 * One card of the Home menu with its things. [title] is the name of the card (Browse, Discover, Manage or what you called them) or null. How it is drawn depends on the skin:
 * rows on a soft or outlined card, plain rows, or tiles two to a row. [onOpen] is told which thing was tapped.
 */
@Composable
fun MenuCard(title: String?, items: List<MenuItem>, onOpen: (MenuItem) -> Unit) {
    val skin = menuSkin(); val o = menuOptions()
    val name = title.takeIf { skin.showsNames(o) }
    when {
        skin.grid -> Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            name?.let { GroupName(it) }
            items.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                    pair.forEach { item -> MenuTile(item, Modifier.weight(1f)) { onOpen(item) } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        skin.flatRows -> Column(Modifier.fillMaxWidth()) {
            name?.let { GroupName(it) }
            items.forEach { item -> MenuRow(item, true) { onOpen(item) } }
        }
        else -> Column(Modifier.fillMaxWidth()) {
            if (!skin.outlined) name?.let { GroupName(it) }
            Column(Modifier.fillMaxWidth().skinCard()) {
                if (skin.outlined) name?.let {
                    Text(it, Modifier.fillMaxWidth().background(Sb.ink.copy(alpha = .05f)).padding(vertical = 9.dp).asHeading(),
                        color = Sb.mute, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, letterSpacing = .3.sp, textAlign = TextAlign.Center)
                }
                items.forEachIndexed { i, item -> MenuRow(item, i == items.lastIndex) { onOpen(item) } }
            }
        }
    }
}

/** One row of the Home menu: icon (on a tile, in some skins), name and an arrow. The last row of a group has no hairline under it. */
@Composable
fun MenuRow(item: MenuItem, last: Boolean, onClick: () -> Unit) {
    val skin = menuSkin(); val o = menuOptions(); val layout = LocalMenuLayout.current
    val label = layout.labelOf(item); val icon = layout.iconOf(item); val tint = menuIconTint()
    val h = skin.rowHeight + o.rowDelta.dp
    if (skin.tiles) {
        val tile = RoundedCornerShape(12.dp)
        Column {
            Row(Modifier.pressScale(.98f).fillMaxWidth().height(h).tap(label, onClick).padding(horizontal = 12.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                if (o.icons) Box(Modifier.size(36.dp).clip(tile).background(Sb.raised).border(1.dp, skin.groupLine(), tile), Alignment.Center) { Ic(icon, 20.dp, tint) }
                Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (skin.chevrons) Ic("chevron", 16.dp, Sb.mute)
            }
            if (!last) Box(Modifier.padding(start = if (o.icons) 60.dp else 16.dp, end = 16.dp).fillMaxWidth().height(1.dp).background(skin.groupLine().copy(alpha = .7f)))
        }
    } else if (skin.flatRows) {
        Row(Modifier.pressScale(.98f).fillMaxWidth().height(h).clip(RoundedCornerShape(14.dp)).tap(label, onClick).padding(horizontal = 8.dp), Arrangement.spacedBy(16.dp), Alignment.CenterVertically) {
            if (o.icons) Ic(icon, 22.dp, tint)
            Text(label, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (skin.chevrons) Ic("chevron", 16.dp, Sb.mute)
        }
    } else {
        Column {
            Row(Modifier.fillMaxWidth().height(h).tap(label, onClick).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                if (o.icons) { Ic(icon, 24.dp, tint); Spacer(Modifier.width(14.dp)) }
                Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (skin.chevrons) Ic("chevron", 18.dp, Sb.mute)
            }
            if (!last) Box(Modifier.padding(start = if (o.icons) 56.dp else 18.dp, end = 18.dp).fillMaxWidth().height(1.dp).background(Sb.line))
        }
    }
}

/** One tile of the Home menu in a skin with a grid. */
@Composable
private fun MenuTile(item: MenuItem, modifier: Modifier, onClick: () -> Unit) {
    val skin = menuSkin(); val o = menuOptions(); val layout = LocalMenuLayout.current
    val label = layout.labelOf(item); val tint = menuIconTint()
    Column(modifier.pressScale(.97f).height(skin.rowHeight + (o.rowDelta * 2).dp).clip(RoundedCornerShape(skin.groupCorner)).background(skin.groupFill())
        .tap(label, onClick).padding(14.dp), Arrangement.SpaceBetween) {
        if (o.icons) Ic(layout.iconOf(item), 26.dp, tint) else Spacer(Modifier.height(1.dp))
        Text(label, fontSize = 15.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/** Your picture and name at the top of the menu (switched on in Customize menu). A tap opens the Account page. */
@Composable
fun MenuProfile(onClick: () -> Unit) {
    val account = LocalMenuAccount.current ?: return
    val skin = menuSkin()
    Row(Modifier.pressScale(.98f).fillMaxWidth().skinCard().tap("Account", onClick).padding(12.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        AvatarView(account, 44.dp)
        Column(Modifier.weight(1f)) {
            Text(if (account.hasName) account.callName else "Set up your profile", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(account.about.lineSequence().firstOrNull().orEmpty().ifBlank { "Your account" }, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (skin.chevrons) Ic("chevron", 16.dp, Sb.mute)
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// The floating pill
// ---------------------------------------------------------------------------------------------------------------------------------

/** The main action of a sheet shown as a floating pill (after the Art-direction reference): a round icon, the action and a line under it, and an arrow. See Sheet. */
class SheetCapsule(val icon: String, val label: String, val sub: String? = null, val onClick: () -> Unit)

/** [accent] fills the pill with the app's accent color instead of the ink. */
@Composable
fun CapsuleButton(c: SheetCapsule, modifier: Modifier = Modifier, accent: Boolean = false) {
    val fill = if (accent) LocalSb.current.acc else Sb.ink
    val text = if (accent) onAccent(fill) else Sb.card
    Row(modifier.fillMaxWidth(.9f).pressScale(.97f).shadow(14.dp, CircleShape).clip(CircleShape).background(fill).tap(c.label, c.onClick)
        .padding(start = 10.dp, end = 22.dp, top = 10.dp, bottom = 10.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(text), Alignment.Center) { Ic(c.icon, 22.dp, fill) }
        Column(Modifier.weight(1f)) {
            Text(c.label, color = text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            if (c.sub != null) Text(c.sub, color = text.copy(alpha = .65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Ic("arrow", 22.dp, text)
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// A small picture of a menu, for choosing a skin and for seeing a change at once
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * A tiny phone with a dimmed page and a menu in the given skin, drawn with plain boxes in the colors of the current theme. With no [options] and [layout] it
 * shows the skin as it comes; with yours it shows your menu: the cards you have, what is hidden, the title, the buttons and the line under them.
 * [maxRows] is how many rows it draws before it stops (a taller picture can hold more).
 */
@Composable
fun SkinPreview(skin: MenuSkin, modifier: Modifier = Modifier, options: MenuOptions = MenuOptions(), layout: MenuLayout = MenuLayout.Default, height: Dp = 150.dp, maxRows: Int = 5) {
    val sheetShape = if (skin.floating) RoundedCornerShape(12.dp) else RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
    val frame = RoundedCornerShape(18.dp)
    val fill = skin.groupFill(); val line = skin.groupLine()
    val acc = LocalSb.current.acc
    val main = if (options.accent) acc else Sb.ink
    val iconTint = if (options.accent) acc else Sb.ink.copy(alpha = .3f)
    val names = skin.showsNames(options)
    // What the menu holds, cut to what fits: a few rows from each card, in order.
    var left = maxRows
    val cards = layout.groups().mapNotNull { g ->
        if (left <= 0) null else g.take(left).also { left -= it.size }.let { rows -> rows to layout.groupTitle(g) }
    }
    val hasMain = options.bottom != MenuBottom.None
    val pill = hasMain && skin.canPill && options.action == 1
    val two = hasMain && !pill && skin.showsCancel(options)
    val oneSoft = !hasMain && options.cancel != 2
    Box(modifier.height(height).clip(frame).background(Sb.paper).border(1.dp, Sb.line, frame)) {
        // The page behind the sheet, dimmed.
        Column(Modifier.fillMaxSize().padding(10.dp), Arrangement.spacedBy(6.dp)) {
            Box(Modifier.width(44.dp).height(7.dp).clip(RoundedCornerShape(4.dp)).background(Sb.ink.copy(alpha = .35f)))
            Box(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(7.dp)).background(Sb.card))
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = options.dimAlpha * .8f)))
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().then(if (skin.floating) Modifier.padding(6.dp) else Modifier)
            .clip(sheetShape).background(Sb.raised).padding(horizontal = 8.dp, vertical = 7.dp),
            Arrangement.spacedBy(5.dp), if (skin.centerTitle) Alignment.CenterHorizontally else Alignment.Start) {
            Box(Modifier.align(Alignment.CenterHorizontally).width(16.dp).height(2.dp).clip(RoundedCornerShape(1.dp)).background(Sb.line))
            if (options.showTitle) Box(Modifier.width(34.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Sb.ink))
            if (options.profile) Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(5.dp), Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(acc)); Box(Modifier.width(30.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Sb.ink.copy(alpha = .3f)))
            }
            cards.forEach { (rows, title) ->
                if (names && title != null && !skin.outlined) Box(Modifier.width(20.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Sb.mute.copy(alpha = .5f)))
                if (skin.grid) {
                    rows.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(4.dp)) {
                            pair.forEach { _ ->
                                Column(Modifier.weight(1f).height(if (options.rowSize == 0) 13.dp else 17.dp).clip(RoundedCornerShape(5.dp)).background(fill).padding(3.dp), Arrangement.SpaceBetween) {
                                    if (options.icons) Box(Modifier.size(4.dp).clip(CircleShape).background(iconTint))
                                    Box(Modifier.width(14.dp).height(2.dp).clip(RoundedCornerShape(1.dp)).background(Sb.ink.copy(alpha = .35f)))
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                } else {
                    val cardMod = if (skin.flatRows) Modifier.fillMaxWidth()
                        else Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).background(fill).then(if (skin.outlined) Modifier.border(1.dp, line, RoundedCornerShape(7.dp)) else Modifier)
                    Column(cardMod.padding(horizontal = 6.dp, vertical = if (skin.flatRows) 0.dp else 5.dp), Arrangement.spacedBy(if (options.rowSize == 0) 3.dp else 5.dp)) {
                        if (names && title != null && skin.outlined) Box(Modifier.align(Alignment.CenterHorizontally).width(20.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Sb.mute.copy(alpha = .5f)))
                        rows.forEach { _ ->
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (options.icons) {
                                    if (skin.tiles) Box(Modifier.size(8.dp).clip(RoundedCornerShape(3.dp)).background(Sb.raised).border(1.dp, line, RoundedCornerShape(3.dp)))
                                    else Box(Modifier.size(5.dp).clip(CircleShape).background(iconTint))
                                }
                                Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Sb.ink.copy(alpha = .3f)))
                            }
                        }
                    }
                }
            }
            when {
                pill -> Box(Modifier.align(Alignment.CenterHorizontally).fillMaxWidth(.8f).height(11.dp).clip(CircleShape).background(main))
                two -> Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.weight(1f).height(10.dp).clip(CircleShape).background(Sb.line))
                    Box(Modifier.weight(1.5f).height(10.dp).clip(CircleShape).background(main))
                }
                hasMain -> Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(main))
                oneSoft -> Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(Sb.line))
            }
            if (skin.canFooter && options.footer) Box(Modifier.align(Alignment.CenterHorizontally).width(46.dp).height(2.dp).clip(RoundedCornerShape(1.dp)).background(Sb.mute.copy(alpha = .4f)))
        }
    }
}
