package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder

// Home skins: a skin is a whole Home that can be put on and taken off: which parts show and in what order, their designs, your sections, the header, the add button and the
// size of the greeting. The page itself still reads those settings one by one, so nothing about how Home is drawn depends on skins; a skin is a saved copy of them.
// Wearing a skin copies its settings in; whatever you change while wearing it stays with it (it is saved into the skin when you take the skin off, and the list always
// shows the worn skin as it is now). Only the pieces that differ from the classic look are kept in a skin, so the Classic skin is simply an empty one.
// This file holds only the rules, so they are tested on their own (HomeSkinsTest). Putting a skin on and reading the pieces from the settings is in ArchiveViewModel.

/** The pieces of Home a skin holds, by the name each is saved under. Never rename one. */
object SkinKeys {
    const val ORDER = "order"
    const val HIDDEN = "hidden"
    const val STYLES = "styles"
    const val SECTIONS = "sections"
    const val HEADER = "header"
    const val HEADER_SIZE = "headerSize"
    const val ADD_BUTTON = "addButton"
    const val BOXES_ACTIVE = "boxesActive"
    const val GREET_TEXT = "greetText"
    const val GREET_PIC = "greetPic"
    const val GREET_AVATAR = "greetAvatar"
    const val GESTURES = "gestures"
    const val LOOK = "look"

    /** What each piece is in the classic look. A skin keeps a piece only when it is something else. */
    val DEFAULTS: Map<String, String> = mapOf(
        ORDER to HomeLayout.Default.encodeOrder(), HIDDEN to "", STYLES to "", SECTIONS to "",
        HEADER to "1", HEADER_SIZE to "1", ADD_BUTTON to "0", BOXES_ACTIVE to "true",
        GREET_TEXT to GreetingPrefs.TEXT_DEFAULT.toString(), GREET_PIC to GreetingPrefs.PIC_DEFAULT.toString(), GREET_AVATAR to "true",
        GESTURES to GesturePrefs().encode(),
        LOOK to "",
    )
}

/** One skin. [values] holds only the pieces that differ from the classic look, so the Classic skin has none. */
data class HomeSkin(val id: String, val name: String, val values: Map<String, String> = emptyMap()) {
    val builtIn: Boolean get() = id == HomeSkins.CLASSIC_ID

    /** The order and the hidden parts this skin has. */
    val layout: HomeLayout get() = HomeLayout(HomeLayout.decodeOrder(values[SkinKeys.ORDER]), HomeLayout.decodeHidden(values[SkinKeys.HIDDEN]))

    /** The sections this skin has. */
    val sections: List<HomeSection> get() = HomeSections.decode(values[SkinKeys.SECTIONS])

    /** The gesture settings this skin has. */
    val gestures: GesturePrefs get() = GesturePrefs.decode(values[SkinKeys.GESTURES])

    /** Whether this skin differs from the classic look at all. */
    val changed: Boolean get() = values.isNotEmpty()
}

/** All the skins and which one is worn. Classic is always the first and can never be removed. */
data class HomeSkins(val skins: List<HomeSkin>, val active: String) {
    /** The worn skin. */
    val current: HomeSkin get() = skins.firstOrNull { it.id == active } ?: skins.first()

    fun get(id: String): HomeSkin? = skins.firstOrNull { it.id == id }

    /** The worn skin as it is right now: [live] is what the settings hold at this moment. */
    fun withLive(live: Map<String, String>): HomeSkins {
        val id = current.id
        return copy(active = id, skins = skins.map { if (it.id == id) it.copy(values = sparse(live)) else it })
    }

    /**
     * Wears skin [id]. Call [withLive] first, so the skin that is taken off keeps what you changed on it. Null if there is no such skin;
     * the settings to put in are then [HomeSkin.values] of the skin that is now [current].
     */
    fun activate(id: String): HomeSkins? = if (get(id) == null) null else copy(active = id)

    /** Adds a skin made of [values] (named [name], or a variation of it when that name is taken). Returns the new list and the new skin. It is not worn. */
    fun add(name: String, values: Map<String, String>): Pair<HomeSkins, HomeSkin> {
        val skin = HomeSkin(newId(), uniqueName(cleanName(name).ifEmpty { "My skin" }, skins.map { it.name }.toSet()), sparse(values))
        return copy(skins = skins + skin) to skin
    }

    /** Renames a skin. Classic keeps its name, and a name with nothing in it changes nothing. */
    fun rename(id: String, name: String): HomeSkins {
        val n = cleanName(name)
        return if (n.isEmpty() || get(id)?.builtIn != false) this else copy(skins = skins.map { if (it.id == id) it.copy(name = n) else it })
    }

    /** A skin that can be removed: not Classic and not the one worn. */
    fun canDelete(id: String): Boolean = get(id)?.let { !it.builtIn && it.id != current.id } ?: false

    fun delete(id: String): HomeSkins = if (canDelete(id)) copy(skins = skins.filterNot { it.id == id }) else this

    /** Back to the classic look for one skin. If it is the worn one, the settings must be set to the classic look too. */
    fun reset(id: String): HomeSkins = copy(skins = skins.map { if (it.id == id) it.copy(values = emptyMap()) else it })

    /** Saved as one line per skin (`K|id|name`) followed by one per piece (`V|piece|value`), and `A|id` for the worn one. Every text is URL-encoded. */
    fun encode(): String = buildString {
        append("A|").append(enc(active)).append('\n')
        for (s in skins) {
            append("K|").append(enc(s.id)).append('|').append(enc(s.name)).append('\n')
            for (k in SkinKeys.DEFAULTS.keys) s.values[k]?.let { append("V|").append(enc(k)).append('|').append(enc(it)).append('\n') }
        }
    }

    companion object {
        const val CLASSIC_ID = "classic"
        const val CLASSIC_NAME = "Classic"
        const val MAX_NAME = 30

        fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(10)

        fun cleanName(s: String): String = s.trim().take(MAX_NAME).trim()

        /** [values] without the pieces that are the classic look, and without anything that is not a piece of Home. */
        fun sparse(values: Map<String, String>): Map<String, String> =
            SkinKeys.DEFAULTS.keys.mapNotNull { k -> values[k]?.takeIf { it != SkinKeys.DEFAULTS[k] }?.let { k to it } }.toMap()

        /** [base], or [base] 2, [base] 3 and so on until the name is not in [taken]. */
        fun uniqueName(base: String, taken: Set<String>): String {
            if (base !in taken) return base
            var n = 2
            while ("$base $n" in taken) n++
            return "$base $n"
        }

        /** The skins before any was saved: Classic, and, if the settings already differ from the classic look, "My home" holding them, worn. */
        fun initial(live: Map<String, String>): HomeSkins {
            val classic = HomeSkin(CLASSIC_ID, CLASSIC_NAME)
            val mine = sparse(live)
            return if (mine.isEmpty()) HomeSkins(listOf(classic), CLASSIC_ID) else HomeSkins(listOf(classic, HomeSkin("mine", "My home", mine)), "mine")
        }

        /** Reads what [encode] wrote. Classic is put back if it is missing, repeated ids and unknown pieces are dropped, and an unknown worn skin becomes Classic. */
        fun decode(text: String?): HomeSkins {
            val skins = ArrayList<HomeSkin>()
            val seen = HashSet<String>()
            var active = CLASSIC_ID
            var cur: HomeSkin? = null
            fun flush() { cur?.let { skins.add(it) }; cur = null }
            for (line in text.orEmpty().split('\n')) {
                val p = line.split('|')
                when (p[0]) {
                    "A" -> if (p.size >= 2) active = dec(p[1])
                    "K" -> {
                        flush()
                        if (p.size >= 3 && p[1].isNotEmpty() && seen.add(dec(p[1]))) cur = HomeSkin(dec(p[1]), cleanName(dec(p[2])).ifEmpty { "My skin" })
                    }
                    "V" -> {
                        val c = cur
                        if (c != null && p.size >= 3) {
                            val k = dec(p[1])
                            if (k in SkinKeys.DEFAULTS) cur = c.copy(values = sparse(c.values + (k to dec(p[2]))))
                        }
                    }
                }
            }
            flush()
            val classic = skins.firstOrNull { it.id == CLASSIC_ID }?.copy(name = CLASSIC_NAME) ?: HomeSkin(CLASSIC_ID, CLASSIC_NAME)
            val all = listOf(classic) + skins.filter { it.id != CLASSIC_ID }
            return HomeSkins(all, if (all.any { it.id == active }) active else CLASSIC_ID)
        }

        /**
         * [mine] with the skins of [theirs] (from a backup) added: one whose name is already here is skipped, Classic is never added again, and every skin added gets an id of its own.
         * What is worn stays what [mine] wears.
         */
        fun merged(mine: HomeSkins, theirs: HomeSkins): HomeSkins {
            var out = mine
            for (s in theirs.skins) {
                if (s.builtIn || out.skins.any { it.name.equals(s.name, ignoreCase = true) }) continue
                out = out.add(s.name, s.values).first
            }
            return out
        }

        private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
        private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }
    }
}
