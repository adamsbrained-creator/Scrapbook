package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder
import kotlin.math.roundToInt
import kotlin.math.sqrt

// Draw gestures: draw a shape with two fingers together, anywhere in the app, and a box or a scrap opens (or a new scrap starts, or search).
// This file is only the rules, with no Android in it, so they are tested on their own (DrawGesturesTest): how a drawn line is turned into something that
// can be compared, how two are compared, and how gestures are saved. The drawing itself is in ui/DrawGestureUi.kt.

/** One point of a drawn line. */
data class Pt(val x: Float, val y: Float)

/** What a drawn gesture does. A box or a scrap is stored as "box:<key>" or "scrap:<uid>" (the same permanent names Home's sections use). */
object DrawActions {
    const val NEW = "new"
    const val CHECKLIST = "checklist"
    const val SEARCH = "search"
    fun box(key: String) = "box:$key"
    fun scrap(uid: String) = "scrap:$uid"
    fun boxOf(action: String): String? = if (action.startsWith("box:")) action.removePrefix("box:").ifEmpty { null } else null
    fun scrapOf(action: String): String? = if (action.startsWith("scrap:")) action.removePrefix("scrap:").ifEmpty { null } else null
    fun isKnown(action: String): Boolean = action == NEW || action == CHECKLIST || action == SEARCH || boxOf(action) != null || scrapOf(action) != null
}

/**
 * A gesture someone taught: [samples] are the tries, each already made comparable (see [Strokes.normalize]). [label] is what it is called on screen.
 */
data class DrawGesture(val id: String, val label: String, val action: String, val samples: List<List<Pt>>)

/** A recognized gesture and how well the drawing matched it, 0 to 1. */
data class DrawMatch(val gesture: DrawGesture, val score: Float)

/** Turning a drawn line into something that can be compared with another, and comparing. */
object Strokes {
    /** Every line is made of this many points before it is compared. */
    const val N = 64

    fun length(pts: List<Pt>): Float {
        var d = 0f
        for (i in 1 until pts.size) d += dist(pts[i - 1], pts[i])
        return d
    }

    private fun dist(a: Pt, b: Pt): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        return sqrt(dx * dx + dy * dy)
    }

    /** The line as exactly [n] points spread evenly along it, so a slow drawing and a fast one, a long one and a short one, give the same points. */
    fun resample(pts: List<Pt>, n: Int = N): List<Pt> {
        if (pts.isEmpty()) return emptyList()
        val total = length(pts)
        if (total <= 0f) return List(n) { pts[0] }
        val step = total / (n - 1)
        val src = pts.toMutableList()
        val out = ArrayList<Pt>(n)
        out.add(src[0])
        var carried = 0f
        var i = 1
        while (i < src.size) {
            val d = dist(src[i - 1], src[i])
            if (d > 0f && carried + d >= step) {
                val t = (step - carried) / d
                val q = Pt(src[i - 1].x + t * (src[i].x - src[i - 1].x), src[i - 1].y + t * (src[i].y - src[i - 1].y))
                out.add(q)
                src.add(i, q)   // the rest of this piece starts from the new point
                carried = 0f
            } else carried += d
            i++
        }
        while (out.size < n) out.add(src.last())
        return if (out.size > n) out.subList(0, n).toList() else out
    }

    /** The line made comparable: [N] points, moved so its middle is at the origin and scaled so its longer side is 1 (the shape stays as it is; where and how big it was drawn does not matter). */
    fun normalize(pts: List<Pt>): List<Pt> {
        val r = resample(pts)
        if (r.isEmpty()) return r
        val cx = r.sumOf { it.x.toDouble() }.toFloat() / r.size
        val cy = r.sumOf { it.y.toDouble() }.toFloat() / r.size
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (p in r) { if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x; if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y }
        val side = maxOf(maxX - minX, maxY - minY).let { if (it < 1e-3f) 1f else it }
        return r.map { Pt((it.x - cx) / side, (it.y - cy) / side) }
    }

    /** How alike two comparable lines are, 0 (nothing alike) to 1 (the same): from the average distance between their points, one by one. The way they are drawn counts: which end first, which way round. */
    fun score(a: List<Pt>, b: List<Pt>): Float {
        if (a.size != b.size || a.isEmpty()) return 0f
        var sum = 0f
        for (i in a.indices) sum += dist(a[i], b[i])
        return (1f - (sum / a.size) / HALF_DIAGONAL).coerceIn(0f, 1f)
    }

    private const val HALF_DIAGONAL = 0.7071f
}

object DrawGestures {
    /** How alike a drawing must be to a gesture to count as it. */
    const val MIN_SCORE = 0.80f
    /** How much better than the next gesture the best one must be, so two that look alike are never mixed up. */
    const val MARGIN = 0.04f
    /** A new gesture this alike to one that exists is refused: they would be mixed up. */
    const val CLASH = 0.82f
    /** The tries needed to teach a gesture, and how alike to the first they must be (otherwise it was a different shape). */
    const val SAMPLES = 3
    const val SAME_TRY = 0.72f
    /** A line shorter than this (in the units it was drawn in) is a touch, not a drawing. */
    const val MIN_POINTS = 8

    fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(10)

    /** How alike the drawing is to this gesture: its best try. */
    fun scoreOf(stroke: List<Pt>, g: DrawGesture): Float = g.samples.maxOfOrNull { Strokes.score(stroke, it) } ?: 0f

    /** Every gesture with how alike it is to the drawing, best first. [stroke] is a raw drawing. */
    fun ranked(stroke: List<Pt>, gestures: List<DrawGesture>): List<DrawMatch> {
        if (stroke.size < MIN_POINTS) return emptyList()
        val n = Strokes.normalize(stroke)
        return gestures.map { DrawMatch(it, scoreOf(n, it)) }.sortedByDescending { it.score }
    }

    /** The gesture the drawing is, or null: it must be alike enough, and clearly more than the next one. */
    fun match(stroke: List<Pt>, gestures: List<DrawGesture>): DrawMatch? {
        val r = ranked(stroke, gestures)
        val best = r.firstOrNull() ?: return null
        if (best.score < MIN_SCORE) return null
        val next = r.getOrNull(1)
        if (next != null && best.score - next.score < MARGIN) return null
        return best
    }

    /** The existing gesture a new one (given as its raw tries) would be mixed up with, if any. */
    fun clash(newSamples: List<List<Pt>>, existing: List<DrawGesture>): DrawMatch? {
        val norm = newSamples.map { Strokes.normalize(it) }
        return existing.map { g -> DrawMatch(g, norm.maxOfOrNull { s -> scoreOf(s, g) } ?: 0f) }.filter { it.score >= CLASH }.maxByOrNull { it.score }
    }

    // ----- Saved form: one line per gesture, "G|id|label|action|tries", the tries separated by ";" and each one a list of whole numbers (the points, x then y, in thousandths). -----

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    fun encode(list: List<DrawGesture>): String = buildString {
        for (g in list) {
            append("G|").append(enc(g.id)).append('|').append(enc(g.label)).append('|').append(enc(g.action)).append('|')
            append(g.samples.joinToString(";") { s -> s.joinToString(",") { "${(it.x * 1000f).roundToInt()},${(it.y * 1000f).roundToInt()}" } })
            append('\n')
        }
    }

    /** Reads what [encode] wrote. A line or a try that does not make sense is skipped, never an error. */
    fun decode(text: String?): List<DrawGesture> {
        val out = ArrayList<DrawGesture>()
        val seen = HashSet<String>()
        for (line in text.orEmpty().split('\n')) {
            val p = line.split('|')
            if (p.size < 5 || p[0] != "G") continue
            val id = dec(p[1])
            val action = dec(p[3])
            if (id.isEmpty() || !DrawActions.isKnown(action) || !seen.add(id)) continue
            val samples = p[4].split(';').mapNotNull { s ->
                val nums = s.split(',').mapNotNull { it.trim().toIntOrNull() }
                if (nums.size == Strokes.N * 2) List(Strokes.N) { i -> Pt(nums[2 * i] / 1000f, nums[2 * i + 1] / 1000f) } else null
            }
            if (samples.isNotEmpty()) out.add(DrawGesture(id, dec(p[2]), action, samples))
        }
        return out
    }
}
