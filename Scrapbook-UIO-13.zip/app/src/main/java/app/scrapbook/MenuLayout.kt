package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder

/**
 * The three kinds of place the menu has by default. A skin may print one on top of a group when everything in that group comes from the same section, so the
 * name never lies after you have moved things around. [title] is the usual name; the menu can give each section a name of its own ([MenuLayout.sections]).
 */
enum class MenuSection(val key: String, val title: String) {
    Browse("browse", "Browse"), Discover("discover", "Discover"), Manage("manage", "Manage");

    companion object { fun of(key: String): MenuSection? = entries.firstOrNull { it.key == key } }
}

/**
 * Everything the menu can hold by default. [key] is what is saved, so never rename one; [label] and [icon] (a name Ic draws) are what the menu shows
 * unless you gave the entry a name or an icon of your own. The order of the entries here is the default order of the menu.
 * Nothing is locked: every entry can be hidden, Settings and Customize menu too (see [MenuLayout.reachesCustomize] for how you get back).
 */
enum class MenuEntry(val key: String, val label: String, val icon: String, val section: MenuSection) {
    Home("home", "Home", "home", MenuSection.Browse),
    AllScraps("scraps", "All scraps", "list", MenuSection.Browse),
    Pinned("pinned", "Pinned", "star", MenuSection.Browse),
    Recent("recent", "Recently edited", "clock", MenuSection.Browse),
    Rediscover("rediscover", "Rediscover", "sparkle", MenuSection.Discover),
    Timeline("timeline", "Timeline", "book", MenuSection.Discover),
    GoTo("goto", "Go to…", "jump", MenuSection.Discover),
    Search("search", "Search", "search", MenuSection.Discover),
    Bin("bin", "Bin", "trash", MenuSection.Manage),
    CustomizeHome("customize", "Customize home", "layout", MenuSection.Manage),
    CustomizeMenu("custmenu", "Customize menu", "menu", MenuSection.Manage),
    Settings("settings", "Settings", "sliders", MenuSection.Manage),
    About("about", "About", "info", MenuSection.Manage);

    companion object {
        fun of(key: String): MenuEntry? = entries.firstOrNull { it.key == key }
    }
}

/** What a shortcut in the menu opens. [target] is the box name, the scrap's permanent id, or the tag; a Binder shortcut needs none. */
enum class ShortcutKind(val key: String, val label: String, val icon: String) {
    Box("box", "Box", "folder"),
    Scrap("scrap", "Scrap", "edit"),
    Tag("tag", "Tag", "tag"),
    Binder("binder", "Binder app", "link");

    companion object { fun of(key: String): ShortcutKind? = entries.firstOrNull { it.key == key } }
}

/** A place of your own in the menu. [id] tells shortcuts apart (it is saved as "s1", "s2" and so on); [label] is what the row says unless renamed. */
data class MenuShortcut(val id: Int, val kind: ShortcutKind, val target: String, val label: String)

/** A name and an icon you gave an entry. Blank means "the usual one". */
data class MenuLook(val label: String = "", val icon: String = "") {
    val isBlank: Boolean get() = label.isBlank() && icon.isBlank()
}

/** The icons the menu lets you pick from (names Ic draws). */
object MenuIcons {
    val ALL = listOf(
        "home", "list", "star", "clock", "sparkle", "book", "jump", "search", "trash", "layout", "sliders", "info", "menu", "folder", "edit", "tag", "link",
        "image", "camera", "file", "mic", "taskcheck", "check", "person", "plus", "arrow", "lock", "grid", "palette", "backup", "sort", "share", "play",
        "quote", "code", "page", "eye", "external",
    )
}

/** One thing in the menu's order: an entry, a shortcut of your own, or a break between two groups. [key] is what a screen can use to tell them apart. */
sealed class MenuItem {
    abstract val key: String

    data class Entry(val entry: MenuEntry) : MenuItem() {
        override val key: String get() = entry.key
    }

    /** A break between two groups. [id] tells breaks apart (it is saved as "-1", "-2" and so on). */
    data class Gap(val id: Int) : MenuItem() {
        override val key: String get() = "-$id"
    }

    data class Shortcut(val shortcut: MenuShortcut) : MenuItem() {
        override val key: String get() = "s${shortcut.id}"
    }
}

/**
 * What the menu shows and in what order, top to bottom. [order] always holds every entry once (hidden ones keep their place, so showing one again puts it back
 * where it was), your shortcuts, and any number of group breaks up to [MAX_GAPS]; [hidden] are the keys of the things that are switched off; [looks] the names
 * and icons you gave things; [sections] the names you gave Browse, Discover and Manage. A break starts a new card in the menu.
 * Nothing here touches Android, so the rules are tested on their own (MenuLayoutTest).
 */
data class MenuLayout(
    val order: List<MenuItem> = DEFAULT_ORDER,
    val hidden: Set<String> = emptySet(),
    val looks: Map<String, MenuLook> = emptyMap(),
    val sections: Map<MenuSection, String> = emptyMap(),
) {
    fun isHidden(item: MenuItem): Boolean = item.key in hidden
    fun isHidden(e: MenuEntry): Boolean = e.key in hidden

    /** The group breaks, in the order they sit in. */
    val gaps: List<MenuItem.Gap> get() = order.filterIsInstance<MenuItem.Gap>()

    /** Your shortcuts, in the order they sit in. */
    val shortcuts: List<MenuShortcut> get() = order.filterIsInstance<MenuItem.Shortcut>().map { it.shortcut }

    /** Moves the item at [from] to position [to]. Anything outside the list changes nothing. */
    fun move(from: Int, to: Int): MenuLayout {
        if (from == to || from !in order.indices || to !in order.indices) return this
        val list = order.toMutableList()
        list.add(to, list.removeAt(from))
        return copy(order = list)
    }

    /** Switches a thing off or on. A group break can not be switched off (remove it instead). */
    fun withHidden(item: MenuItem, hide: Boolean): MenuLayout =
        if (item is MenuItem.Gap) this else copy(hidden = if (hide) hidden + item.key else hidden - item.key)

    /** What a row says: the name you gave it, or the usual one. */
    fun labelOf(item: MenuItem): String = looks[item.key]?.label?.takeIf { it.isNotBlank() } ?: when (item) {
        is MenuItem.Entry -> item.entry.label
        is MenuItem.Shortcut -> item.shortcut.label
        is MenuItem.Gap -> "Group break"
    }

    /** The icon of a row: the one you picked, or the usual one. */
    fun iconOf(item: MenuItem): String = looks[item.key]?.icon?.takeIf { it.isNotBlank() } ?: when (item) {
        is MenuItem.Entry -> item.entry.icon
        is MenuItem.Shortcut -> item.shortcut.kind.icon
        is MenuItem.Gap -> "divider"
    }

    fun hasOwnLook(item: MenuItem): Boolean = looks[item.key]?.isBlank == false

    /** Gives a thing a name and an icon of its own; blank for either is the usual one. Both blank takes the look away. */
    fun withLook(item: MenuItem, label: String, icon: String): MenuLayout {
        if (item is MenuItem.Gap) return this
        val look = MenuLook(label.trim().take(MAX_LABEL), icon.takeIf { it in MenuIcons.ALL }.orEmpty())
        return copy(looks = if (look.isBlank) looks - item.key else looks + (item.key to look))
    }

    /** What a section is called on the card that holds it. */
    fun sectionTitle(s: MenuSection): String = sections[s]?.takeIf { it.isNotBlank() } ?: s.title

    fun withSectionTitle(s: MenuSection, name: String): MenuLayout {
        val n = name.trim().take(MAX_LABEL)
        return copy(sections = if (n.isBlank() || n == s.title) sections - s else sections + (s to n))
    }

    /** Adds a shortcut of your own at position [at] (the end by default). Nothing happens once [MAX_SHORTCUTS] are in use. */
    fun addShortcut(kind: ShortcutKind, target: String, label: String, at: Int = order.size): MenuLayout {
        if (shortcuts.size >= MAX_SHORTCUTS) return this
        val used = shortcuts.map { it.id }.toSet()
        val id = (1..MAX_ID).first { it !in used }
        val name = label.trim().ifBlank { kind.label }.take(MAX_LABEL)
        val list = order.toMutableList()
        list.add(at.coerceIn(0, list.size), MenuItem.Shortcut(MenuShortcut(id, kind, target.trim().take(MAX_TARGET), name)))
        return copy(order = list)
    }

    fun removeShortcut(id: Int): MenuLayout {
        val key = "s$id"
        return copy(order = order.filterNot { it is MenuItem.Shortcut && it.shortcut.id == id }, hidden = hidden - key, looks = looks - key)
    }

    /** Puts a new group break at position [at] (the end by default, where the Add button is). Nothing happens once [MAX_GAPS] are in use. */
    fun addGap(at: Int = order.size): MenuLayout {
        if (gaps.size >= MAX_GAPS) return this
        val used = gaps.map { it.id }.toSet()
        val id = (1..MAX_ID).first { it !in used }
        val list = order.toMutableList()
        list.add(at.coerceIn(0, list.size), MenuItem.Gap(id))
        return copy(order = list)
    }

    fun removeGap(id: Int): MenuLayout = copy(order = order.filterNot { it is MenuItem.Gap && it.id == id })

    /**
     * The cards the menu draws: the things that are shown, split wherever there is a break. Empty cards (everything in them hidden, or breaks side by side,
     * or at either end) are left out. [available] lets the screen leave out a thing that makes no sense where the menu was opened (Customize home away from Home).
     */
    fun groups(available: (MenuItem) -> Boolean = { true }): List<List<MenuItem>> {
        val out = mutableListOf<List<MenuItem>>()
        var current = mutableListOf<MenuItem>()
        for (item in order) {
            if (item is MenuItem.Gap) { if (current.isNotEmpty()) out.add(current); current = mutableListOf() }
            else if (item.key !in hidden && available(item)) current.add(item)
        }
        if (current.isNotEmpty()) out.add(current)
        return out
    }

    /** The name a card goes by (Browse, Discover, Manage, or what you called them) when everything in it comes from the same section; otherwise null. */
    fun groupTitle(group: List<MenuItem>): String? {
        val sections = group.map { (it as? MenuItem.Entry)?.entry?.section ?: return null }.distinct()
        return sections.singleOrNull()?.let { sectionTitle(it) }
    }

    /**
     * True while Settings or Customize menu is still in the menu. When neither is, the menu can no longer be changed from itself (Settings > Home and lists > Customize menu
     * is gone with Settings), so the screen warns first and a hold on the menu's title always opens Customize menu.
     */
    val reachesCustomize: Boolean get() = !isHidden(MenuEntry.Settings) || !isHidden(MenuEntry.CustomizeMenu)

    fun encodeOrder(): String = order.joinToString(",") { it.key }

    /** Hidden things in the default order (entries first, then shortcuts by number), so the saved text does not depend on the order they were switched off in. */
    fun encodeHidden(): String = encodeHidden(hidden)

    fun encodeShortcuts(): String = shortcuts.joinToString("\n") { s -> "${s.id}|${s.kind.key}|${enc(s.target)}|${enc(s.label)}" }

    fun encodeLooks(): String = looks.entries.filter { !it.value.isBlank }.sortedBy { it.key }.joinToString("\n") { (k, v) -> "$k|${enc(v.label)}|${enc(v.icon)}" }

    fun encodeSections(): String = sections.entries.sortedBy { it.key.ordinal }.joinToString("\n") { (k, v) -> "${k.key}|${enc(v)}" }

    companion object {
        const val MAX_GAPS = 6
        const val MAX_SHORTCUTS = 12
        const val MAX_LABEL = 28
        const val MAX_TARGET = 200
        private const val MAX_ID = 99

        /** The menu as it has always been: Home to Recently edited, then Rediscover to Search, then Bin to About, plus Customize menu. */
        val DEFAULT_ORDER: List<MenuItem> = buildList {
            MenuEntry.entries.forEach { e ->
                if (e == MenuEntry.Rediscover) add(MenuItem.Gap(1))
                if (e == MenuEntry.Bin) add(MenuItem.Gap(2))
                add(MenuItem.Entry(e))
            }
        }

        val Default = MenuLayout()

        fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
        fun dec(s: String): String? = try { URLDecoder.decode(s, "UTF-8") } catch (e: IllegalArgumentException) { null }

        /** The saved shortcuts by number. A line that can not be read, or names an unknown kind, is dropped. */
        fun decodeShortcuts(s: String?): Map<Int, MenuShortcut> {
            val out = LinkedHashMap<Int, MenuShortcut>()
            s.orEmpty().lineSequence().forEach { line ->
                val p = line.split('|')
                if (p.size != 4) return@forEach
                val id = p[0].trim().toIntOrNull()?.takeIf { it in 1..MAX_ID } ?: return@forEach
                val kind = ShortcutKind.of(p[1].trim()) ?: return@forEach
                val target = dec(p[2]) ?: return@forEach
                val label = dec(p[3]) ?: return@forEach
                if (id !in out && out.size < MAX_SHORTCUTS) out[id] = MenuShortcut(id, kind, target.take(MAX_TARGET), label.trim().ifBlank { kind.label }.take(MAX_LABEL))
            }
            return out
        }

        /**
         * The saved order. Nothing saved (or nothing readable) gives the usual menu. Unknown names and repeats are dropped, breaks past the limit are dropped,
         * a shortcut that is not in [shortcuts] is dropped, any entry that is missing (one added by a newer version) goes at the end, and so does any shortcut
         * that was saved but left out of the order.
         */
        fun decodeOrder(s: String?, shortcuts: Map<Int, MenuShortcut> = emptyMap()): List<MenuItem> {
            if (s.isNullOrBlank()) return DEFAULT_ORDER + shortcuts.values.map { MenuItem.Shortcut(it) }
            val entries = LinkedHashSet<MenuEntry>()
            val gapIds = HashSet<Int>()
            val shortcutIds = HashSet<Int>()
            val out = mutableListOf<MenuItem>()
            s.split(',').map { it.trim() }.forEach { t ->
                val gap = if (t.startsWith("-")) t.drop(1).toIntOrNull()?.takeIf { it in 1..MAX_ID } else null
                val sc = if (t.startsWith("s") && t.length > 1) t.drop(1).toIntOrNull()?.let { shortcuts[it] } else null
                when {
                    gap != null -> if (gapIds.size < MAX_GAPS && gapIds.add(gap)) out.add(MenuItem.Gap(gap))
                    sc != null -> if (shortcutIds.add(sc.id)) out.add(MenuItem.Shortcut(sc))
                    else -> MenuEntry.of(t)?.let { if (entries.add(it)) out.add(MenuItem.Entry(it)) }
                }
            }
            if (entries.isEmpty()) return DEFAULT_ORDER + shortcuts.values.map { MenuItem.Shortcut(it) }
            MenuEntry.entries.forEach { if (entries.add(it)) out.add(MenuItem.Entry(it)) }
            shortcuts.values.forEach { if (shortcutIds.add(it.id)) out.add(MenuItem.Shortcut(it)) }
            return out
        }

        /** The saved set of hidden things: unknown names are dropped (checked against what the order really holds by [decode]). */
        fun decodeHidden(s: String?): Set<String> =
            s.orEmpty().split(',').map { it.trim() }.filter { MenuEntry.of(it) != null || (it.startsWith("s") && it.drop(1).toIntOrNull() != null) }.toSet()

        fun decodeLooks(s: String?): Map<String, MenuLook> {
            val out = LinkedHashMap<String, MenuLook>()
            s.orEmpty().lineSequence().forEach { line ->
                val p = line.split('|')
                if (p.size != 3) return@forEach
                val key = p[0].trim()
                val label = dec(p[1]) ?: return@forEach
                val icon = dec(p[2])?.takeIf { it in MenuIcons.ALL }.orEmpty()
                val look = MenuLook(label.trim().take(MAX_LABEL), icon)
                if (!look.isBlank) out[key] = look
            }
            return out
        }

        fun decodeSections(s: String?): Map<MenuSection, String> {
            val out = LinkedHashMap<MenuSection, String>()
            s.orEmpty().lineSequence().forEach { line ->
                val p = line.split('|')
                if (p.size != 2) return@forEach
                val sec = MenuSection.of(p[0].trim()) ?: return@forEach
                val name = dec(p[1])?.trim()?.take(MAX_LABEL).orEmpty()
                if (name.isNotBlank() && name != sec.title) out[sec] = name
            }
            return out
        }

        /** Builds a layout from the five saved texts, keeping only what refers to something the menu really holds. */
        fun decode(order: String?, hidden: String?, shortcuts: String?, looks: String?, sections: String?): MenuLayout {
            val sc = decodeShortcuts(shortcuts)
            val list = decodeOrder(order, sc)
            val keys = list.filter { it !is MenuItem.Gap }.map { it.key }.toSet()
            return MenuLayout(list, decodeHidden(hidden).filter { it in keys }.toSet(), decodeLooks(looks).filterKeys { it in keys }, decodeSections(sections))
        }

        /** Hidden things in the default order, so the saved text does not depend on the order they were switched off in. */
        fun encodeHidden(set: Set<String>): String {
            val entries = MenuEntry.entries.filter { it.key in set }.map { it.key }
            val shortcuts = set.filter { it.startsWith("s") && it.drop(1).toIntOrNull() != null }.sortedBy { it.drop(1).toInt() }
            return (entries + shortcuts).joinToString(",")
        }
    }
}

/** The small line under the menu in skins that have one. */
fun menuSummary(scraps: Int, boxes: Int): String {
    if (scraps == 0 && boxes == 0) return "Nothing saved yet · stays on this phone"
    val s = if (scraps == 1) "1 scrap" else "$scraps scraps"
    val b = if (boxes == 1) "1 box" else "$boxes boxes"
    return "$s · $b · all on this phone"
}
