package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SectionShapesTest {
    @Test fun everyLayoutHasItsOwnKeyAndReadsBack() {
        val keys = SectionLayout.entries.map { it.key }
        assertEquals(keys.size, keys.toSet().size)
        SectionLayout.entries.forEach { assertEquals(it, SectionLayout.of(it.key)) }
    }

    @Test fun theFirstFourKeepTheirSavedNames() {
        assertEquals(listOf("cards", "chips", "rows", "grid"), SectionLayout.entries.take(4).map { it.key })
    }

    @Test fun anUnknownLayoutFromALaterVersionIsCards() {
        assertEquals(SectionLayout.Cards, SectionLayout.of("hologram"))
        assertEquals(SectionLayout.Cards, SectionLayout.of(null))
    }

    @Test fun aNewLayoutSurvivesSavingAndLoading() {
        val s = HomeSection("a", "Reading", SectionLayout.Mosaic, "pinned", listOf(SectionRef(true, "Trips")))
        val back = HomeSections.decode(HomeSections.encode(listOf(s)))
        assertEquals(SectionLayout.Mosaic, back.single().layout)
        assertEquals(s, back.single())
    }

    @Test fun everyLayoutHasANote() = SectionLayout.entries.forEach { assertTrue(it.label, it.note.isNotBlank()) }

    @Test fun tilesNeverFewerThanTwo() {
        assertEquals(2, SectionShapes.tileColumns(100f))
        assertEquals(3, SectionShapes.tileColumns(320f))
        assertEquals(6, SectionShapes.tileColumns(640f))
    }

    @Test fun carouselLetsTheNextCardPeekInButStaysInTheBox() {
        assertEquals(344f * .86f, SectionShapes.carouselWidth(344f), .01f)
        assertEquals(100f, SectionShapes.carouselWidth(100f), .01f)
        assertEquals(140f, SectionShapes.carouselWidth(150f), .01f)
    }

    @Test fun heroSharesTheHeight() {
        assertEquals(176f to 104f, SectionShapes.heroHeights(0))
        val (hero, strip) = SectionShapes.heroHeights(300)
        assertTrue(hero > strip)
        assertEquals(300f, hero + strip + 12f, 1f)
        val (h2, s2) = SectionShapes.heroHeights(100)
        assertTrue(h2 >= 96f && s2 >= 72f)
    }

    @Test fun mosaicGrowsWithTheText() {
        assertEquals(104f, SectionShapes.mosaicHeight(true, 500), 0f)
        assertEquals(120f, SectionShapes.mosaicHeight(false, 0), 0f)
        assertEquals(220f, SectionShapes.mosaicHeight(false, 5000), 0f)
        assertTrue(SectionShapes.mosaicHeight(false, 100) < SectionShapes.mosaicHeight(false, 200))
    }

    @Test fun mosaicColumnsStayBalancedAndKeepOrder() {
        val (l, r) = SectionShapes.splitColumns(listOf(100f, 200f, 100f, 100f, 100f))
        assertEquals(listOf(0, 2, 3), l)
        assertEquals(listOf(1, 4), r)
        assertEquals(emptyList<Int>() to emptyList<Int>(), SectionShapes.splitColumns(emptyList()))
        assertEquals(listOf(0) to emptyList<Int>(), SectionShapes.splitColumns(listOf(50f)))
    }

    @Test fun everyThingIsInExactlyOneMosaicColumn() {
        val hs = List(11) { 100f + it * 7f }
        val (l, r) = SectionShapes.splitColumns(hs)
        assertEquals(hs.indices.toList(), (l + r).sorted())
    }

    @Test fun previewLinesAtLeastOne() {
        assertEquals(1, SectionShapes.previewLines(50f, 90f))
        assertEquals(4, SectionShapes.previewLines(170f, 98f))
    }
}
