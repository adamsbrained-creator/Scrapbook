package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun entries(group: List<MenuItem>): List<MenuEntry> = group.map { (it as MenuItem.Entry).entry }
private fun item(e: MenuEntry) = MenuItem.Entry(e)

class MenuLayoutTest {
    private val all = MenuEntry.entries.toList()
    private fun e(vararg k: MenuEntry) = k.toList()

    @Test fun theDefaultMenuIsTheMenuThatWasThereBefore() {
        val g = MenuLayout.Default.groups()
        assertEquals(3, g.size)
        assertEquals(e(MenuEntry.Home, MenuEntry.AllScraps, MenuEntry.Pinned, MenuEntry.Recent), entries(g[0]))
        assertEquals(e(MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search), entries(g[1]))
        assertEquals(e(MenuEntry.Bin, MenuEntry.CustomizeHome, MenuEntry.CustomizeMenu, MenuEntry.Settings, MenuEntry.About), entries(g[2]))
        assertEquals(all, entries(g.flatten()))
    }

    @Test fun theDefaultOrderHoldsEveryEntryOnceAndTwoBreaks() {
        val order = MenuLayout.Default.order
        assertEquals(all, order.filterIsInstance<MenuItem.Entry>().map { it.entry })
        assertEquals(listOf(1, 2), MenuLayout.Default.gaps.map { it.id })
        assertEquals(all.size + 2, order.size)
    }

    @Test fun keysAreUniqueSoAScreenCanUseThemToTellRowsApart() {
        val keys = MenuLayout.Default.order.map { it.key }
        assertEquals(keys.size, keys.toSet().size)
        assertEquals(all.size, all.map { it.key }.toSet().size)
    }

    @Test fun movingAnItemKeepsTheOthersInOrder() {
        val l = MenuLayout.Default
        val i = l.order.indexOf(item(MenuEntry.Search))
        val moved = l.move(i, 0)
        assertEquals(item(MenuEntry.Search), moved.order.first())
        assertEquals(l.order.size, moved.order.size)
        assertEquals(l.order.toSet(), moved.order.toSet())
        assertEquals(MenuEntry.Search, entries(moved.groups()[0])[0])
        assertEquals(e(MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo), entries(moved.groups()[1]))
    }

    @Test fun movingNowhereOrOutsideTheListChangesNothing() {
        val l = MenuLayout.Default
        assertEquals(l, l.move(2, 2)); assertEquals(l, l.move(-1, 2)); assertEquals(l, l.move(2, 99)); assertEquals(l, l.move(99, 0))
    }

    @Test fun movingABreakRegroupsTheMenu() {
        val l = MenuLayout.Default
        val gap = l.order.indexOf(MenuItem.Gap(1))
        val moved = l.move(gap, gap - 2)
        assertEquals(e(MenuEntry.Home, MenuEntry.AllScraps), entries(moved.groups()[0]))
        assertEquals(e(MenuEntry.Pinned, MenuEntry.Recent, MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search), entries(moved.groups()[1]))
    }

    @Test fun aHiddenEntryIsLeftOutButKeepsItsPlace() {
        val l = MenuLayout.Default.withHidden(item(MenuEntry.Pinned), true)
        assertTrue(l.isHidden(MenuEntry.Pinned))
        assertFalse(MenuEntry.Pinned in entries(l.groups().flatten()))
        assertEquals(MenuLayout.Default.order, l.order)
        assertEquals(all, entries(l.withHidden(item(MenuEntry.Pinned), false).groups().flatten()))
    }

    @Test fun everyEntryCanBeHiddenSettingsAndCustomizeMenuToo() {
        var l = MenuLayout.Default
        all.forEach { l = l.withHidden(item(it), true) }
        assertTrue(l.groups().isEmpty())
        assertTrue(all.all { l.isHidden(it) })
        assertEquals(all.map { it.key }.toSet(), l.hidden)
    }

    @Test fun aBreakCanNotBeHidden() {
        assertEquals(MenuLayout.Default, MenuLayout.Default.withHidden(MenuItem.Gap(1), true))
    }

    @Test fun theMenuCanStillBeChangedWhileSettingsOrCustomizeMenuIsThere() {
        val l = MenuLayout.Default
        assertTrue(l.reachesCustomize)
        assertTrue(l.withHidden(item(MenuEntry.Settings), true).reachesCustomize)
        assertTrue(l.withHidden(item(MenuEntry.CustomizeMenu), true).reachesCustomize)
        assertFalse(l.withHidden(item(MenuEntry.Settings), true).withHidden(item(MenuEntry.CustomizeMenu), true).reachesCustomize)
    }

    @Test fun aCardWhoseEntriesAreAllHiddenDisappears() {
        var l = MenuLayout.Default
        e(MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search).forEach { l = l.withHidden(item(it), true) }
        val g = l.groups()
        assertEquals(2, g.size)
        assertEquals(MenuEntry.Home, entries(g[0])[0])
        assertEquals(MenuEntry.Bin, entries(g[1])[0])
    }

    @Test fun breaksAtTheEndsOrSideBySideDoNotMakeEmptyCards() {
        val l = MenuLayout(listOf(MenuItem.Gap(1), item(MenuEntry.Home), MenuItem.Gap(2), MenuItem.Gap(3), item(MenuEntry.Settings), MenuItem.Gap(4)))
        assertEquals(listOf(e(MenuEntry.Home), e(MenuEntry.Settings)), l.groups().map { entries(it) })
    }

    @Test fun anEntryThatDoesNotFitTheScreenIsLeftOut() {
        val g = MenuLayout.Default.groups { it != item(MenuEntry.CustomizeHome) }
        assertFalse(MenuEntry.CustomizeHome in entries(g.flatten()))
        assertEquals(e(MenuEntry.Bin, MenuEntry.CustomizeMenu, MenuEntry.Settings, MenuEntry.About), entries(g[2]))
    }

    @Test fun addingABreakPutsItAtTheEndWithTheSmallestFreeNumber() {
        val l = MenuLayout.Default.addGap()
        assertEquals(MenuItem.Gap(3), l.order.last())
        assertEquals(3, l.gaps.size)
        assertEquals(MenuItem.Gap(1), l.removeGap(1).addGap().order.last())
        assertEquals(MenuItem.Gap(3), MenuLayout.Default.addGap(0).order.first())
    }

    @Test fun thereIsALimitToTheNumberOfBreaks() {
        var l = MenuLayout.Default
        repeat(10) { l = l.addGap() }
        assertEquals(MenuLayout.MAX_GAPS, l.gaps.size)
        assertEquals(l, l.addGap())
        assertEquals(l.gaps.map { it.id }.toSet().size, l.gaps.size)
    }

    @Test fun removingABreakJoinsTheTwoCards() {
        val l = MenuLayout.Default.removeGap(1)
        assertEquals(2, l.groups().size)
        assertEquals(e(MenuEntry.Home, MenuEntry.AllScraps, MenuEntry.Pinned, MenuEntry.Recent, MenuEntry.Rediscover, MenuEntry.Timeline, MenuEntry.GoTo, MenuEntry.Search), entries(l.groups()[0]))
        assertEquals(MenuLayout.Default, MenuLayout.Default.removeGap(42))
    }

    // ---- names and icons
    @Test fun anEntryCanHaveANameAndAnIconOfItsOwn() {
        val l = MenuLayout.Default.withLook(item(MenuEntry.AllScraps), "  Everything ", "grid")
        assertEquals("Everything", l.labelOf(item(MenuEntry.AllScraps)))
        assertEquals("grid", l.iconOf(item(MenuEntry.AllScraps)))
        assertTrue(l.hasOwnLook(item(MenuEntry.AllScraps)))
        // The others keep theirs.
        assertEquals("Pinned", l.labelOf(item(MenuEntry.Pinned)))
        assertEquals("star", l.iconOf(item(MenuEntry.Pinned)))
    }

    @Test fun aBlankLookGivesTheUsualOneBack() {
        val l = MenuLayout.Default.withLook(item(MenuEntry.Bin), "Trash", "").withLook(item(MenuEntry.Bin), "", "")
        assertEquals("Bin", l.labelOf(item(MenuEntry.Bin)))
        assertEquals("trash", l.iconOf(item(MenuEntry.Bin)))
        assertTrue(l.looks.isEmpty())
        assertFalse(l.hasOwnLook(item(MenuEntry.Bin)))
    }

    @Test fun onlyOnePartOfALookCanBeSet() {
        val l = MenuLayout.Default.withLook(item(MenuEntry.Bin), "", "folder")
        assertEquals("Bin", l.labelOf(item(MenuEntry.Bin)))
        assertEquals("folder", l.iconOf(item(MenuEntry.Bin)))
    }

    @Test fun anIconThatIsNotOnTheListIsIgnoredAndALongNameIsCut() {
        val l = MenuLayout.Default.withLook(item(MenuEntry.Home), "x".repeat(80), "nonsense")
        assertEquals(MenuLayout.MAX_LABEL, l.labelOf(item(MenuEntry.Home)).length)
        assertEquals("home", l.iconOf(item(MenuEntry.Home)))
        assertEquals(MenuLayout.Default, MenuLayout.Default.withLook(MenuItem.Gap(1), "x", "home"))
    }

    @Test fun sectionsCanBeRenamedAndGoBackToTheirOwnName() {
        val l = MenuLayout.Default.withSectionTitle(MenuSection.Browse, " Places ")
        assertEquals("Places", l.sectionTitle(MenuSection.Browse))
        assertEquals("Discover", l.sectionTitle(MenuSection.Discover))
        assertEquals("Places", l.groupTitle(l.groups()[0]))
        assertEquals(MenuLayout.Default, l.withSectionTitle(MenuSection.Browse, ""))
        assertEquals(MenuLayout.Default, l.withSectionTitle(MenuSection.Browse, "Browse"))
    }

    @Test fun aGroupIsNamedOnlyWhenAllOfItComesFromOneSection() {
        val l = MenuLayout.Default; val g = l.groups()
        assertEquals("Browse", l.groupTitle(g[0])); assertEquals("Discover", l.groupTitle(g[1])); assertEquals("Manage", l.groupTitle(g[2]))
        assertNull(l.groupTitle(listOf(item(MenuEntry.Home), item(MenuEntry.Search))))
        assertNull(l.groupTitle(emptyList()))
        assertEquals("Browse", l.groupTitle(listOf(item(MenuEntry.Pinned))))
    }

    // ---- shortcuts
    @Test fun aShortcutIsAddedAtTheEndWithTheSmallestFreeNumber() {
        val l = MenuLayout.Default.addShortcut(ShortcutKind.Box, "Recipes", "Recipes")
        assertEquals(1, l.shortcuts.size)
        assertEquals(MenuShortcut(1, ShortcutKind.Box, "Recipes", "Recipes"), l.shortcuts[0])
        assertEquals("s1", l.order.last().key)
        val two = l.addShortcut(ShortcutKind.Tag, "ideas", "")
        assertEquals("s2", two.order.last().key)
        assertEquals("tag", two.shortcuts[1].label.lowercase())
        assertEquals("s1", two.removeShortcut(1).addShortcut(ShortcutKind.Box, "Home stuff", "x").order.last().key)
    }

    @Test fun aShortcutShowsInTheMenuLikeAnEntryAndCanBeHiddenAndRenamed() {
        val l = MenuLayout.Default.addShortcut(ShortcutKind.Box, "Recipes", "Recipes", at = 0)
        val s = l.order.first()
        assertEquals("Recipes", l.labelOf(s))
        assertEquals("folder", l.iconOf(s))
        assertTrue(s in l.groups()[0])
        assertEquals("Cooking", l.withLook(s, "Cooking", "star").labelOf(s))
        assertFalse(s in l.withHidden(s, true).groups().flatten())
        assertNull(l.groupTitle(l.groups()[0]))      // a shortcut is not in a section, so the card has no name
    }

    @Test fun removingAShortcutTakesItsHiddenFlagAndLookWithIt() {
        val l0 = MenuLayout.Default.addShortcut(ShortcutKind.Scrap, "abc", "A scrap")
        val s = l0.order.last()
        val l = l0.withHidden(s, true).withLook(s, "Mine", "star").removeShortcut(1)
        assertEquals(MenuLayout.Default, l)
    }

    @Test fun thereIsALimitToTheNumberOfShortcuts() {
        var l = MenuLayout.Default
        repeat(30) { l = l.addShortcut(ShortcutKind.Box, "b$it", "b$it") }
        assertEquals(MenuLayout.MAX_SHORTCUTS, l.shortcuts.size)
        assertEquals(l, l.addShortcut(ShortcutKind.Box, "more", "more"))
    }

    @Test fun aLongNameOrTargetIsCut() {
        val l = MenuLayout.Default.addShortcut(ShortcutKind.Box, "t".repeat(500), "n".repeat(100))
        assertEquals(MenuLayout.MAX_TARGET, l.shortcuts[0].target.length)
        assertEquals(MenuLayout.MAX_LABEL, l.shortcuts[0].label.length)
    }

    // ---- saving and reading
    private fun roundTrip(l: MenuLayout) = MenuLayout.decode(l.encodeOrder(), l.encodeHidden(), l.encodeShortcuts(), l.encodeLooks(), l.encodeSections())

    @Test fun theWholeLayoutIsSavedAndReadBackTheSame() {
        val l = MenuLayout.Default.move(0, 8).move(3, 1).addGap(5).removeGap(2)
            .addShortcut(ShortcutKind.Box, "Recipes & more | x\nline", "Recipes, \"2\"").addShortcut(ShortcutKind.Binder, "", "Binder")
            .withHidden(item(MenuEntry.About), true).withHidden(item(MenuEntry.Settings), true)
            .withLook(item(MenuEntry.Pinned), "Starred ★", "star").withLook(MenuItem.Shortcut(MenuShortcut(1, ShortcutKind.Box, "", "")), "Cooking", "")
            .withSectionTitle(MenuSection.Manage, "Admin|stuff")
        val back = roundTrip(l)
        assertEquals(l.order, back.order)
        assertEquals(l.hidden, back.hidden)
        assertEquals(l.looks, back.looks)
        assertEquals(l.sections, back.sections)
        assertEquals(l, back)
        assertEquals(MenuLayout.Default, roundTrip(MenuLayout.Default))
    }

    @Test fun nothingSavedOrUnreadableGivesTheUsualMenu() {
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder(null))
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder(""))
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder("   "))
        assertEquals(MenuLayout.DEFAULT_ORDER, MenuLayout.decodeOrder("nonsense,,??,-x"))
        assertEquals(MenuLayout.Default, MenuLayout.decode(null, null, null, null, null))
    }

    @Test fun unknownNamesAndRepeatsAreDroppedAndMissingEntriesGoLast() {
        val order = MenuLayout.decodeOrder("search, home,home,wat,-1,-1,about")
        assertEquals(listOf("search", "home", "-1", "about"), order.take(4).map { it.key })
        assertEquals(all.toSet(), order.filterIsInstance<MenuItem.Entry>().map { it.entry }.toSet())
        assertEquals(all.size, order.filterIsInstance<MenuItem.Entry>().size)
        assertEquals(1, order.filterIsInstance<MenuItem.Gap>().size)
        assertEquals(MenuEntry.AllScraps, (order[4] as MenuItem.Entry).entry)
    }

    @Test fun savedBreaksAreKeptAsTheyAreAndTooManyAreDropped() {
        val s = (1..9).joinToString(",") { "-$it" } + ",home"
        val order = MenuLayout.decodeOrder(s)
        assertEquals(MenuLayout.MAX_GAPS, order.filterIsInstance<MenuItem.Gap>().size)
        assertEquals(listOf(-1, -2, -3, -4, -5, -6), order.filterIsInstance<MenuItem.Gap>().map { -it.id })
        assertTrue(MenuLayout.decodeOrder(all.joinToString(",") { it.key }).none { it is MenuItem.Gap })
    }

    @Test fun aSavedMenuFromBeforeShortcutsStillReadsTheSame() {
        // What UIO-5 wrote: an order with breaks and a list of hidden entries, nothing else.
        val l = MenuLayout.decode("home,scraps,-1,rediscover,-2,about,settings", "about,bin", null, null, null)
        assertEquals(setOf("about", "bin"), l.hidden)
        assertTrue(l.shortcuts.isEmpty())
        assertEquals(all.toSet(), l.order.filterIsInstance<MenuItem.Entry>().map { it.entry }.toSet())
    }

    @Test fun aSavedSettingsNowCountsAsHidden() {
        assertEquals(setOf("settings", "bin"), MenuLayout.decodeHidden("settings,bin"))
    }

    @Test fun hiddenThingsAreSavedInTheDefaultOrderAndUnknownOnesDropped() {
        assertEquals("home,about,s2", MenuLayout.encodeHidden(setOf("s2", "about", "home")))
        assertEquals(setOf("about", "home"), MenuLayout.decodeHidden("about,?,home,about"))
        assertEquals("", MenuLayout.Default.encodeHidden())
        assertEquals(emptySet<String>(), MenuLayout.decodeHidden(null))
    }

    @Test fun hiddenAndNamedThingsThatAreNoLongerInTheMenuAreForgotten() {
        val l = MenuLayout.decode("home,scraps", "s5,about", null, "s5|x|y\nabout|Info|", null)
        assertTrue("s5" !in l.hidden)
        assertTrue("s5" !in l.looks)
        assertEquals("Info", l.looks["about"]?.label)
    }

    @Test fun shortcutsThatCanNotBeReadAreDroppedAndOnesLeftOutOfTheOrderGoLast() {
        val saved = "1|box|Recipes|Recipes\n2|wat|x|y\nbroken\n3|scrap|%ZZ|bad\n4|tag|ideas|ideas"
        val l = MenuLayout.decode("home,s1", null, saved, null, null)
        assertEquals(listOf(1, 4), l.shortcuts.map { it.id })
        assertEquals("s4", l.order.last().key)
        assertEquals("s1", l.order[1].key)
        assertNotNull(MenuLayout.decodeShortcuts(saved)[1])
    }

    @Test fun anOrderThatNamesAMissingShortcutDropsIt() {
        val order = MenuLayout.decodeOrder("home,s9,scraps", emptyMap())
        assertEquals(listOf("home", "scraps"), order.take(2).map { it.key })
        assertTrue(order.none { it is MenuItem.Shortcut })
    }

    @Test fun theSummaryCountsRightAndReadsNaturally() {
        assertEquals("1 scrap · 1 box · all on this phone", menuSummary(1, 1))
        assertEquals("128 scraps · 12 boxes · all on this phone", menuSummary(128, 12))
        assertEquals("0 scraps · 3 boxes · all on this phone", menuSummary(0, 3))
        assertEquals("Nothing saved yet · stays on this phone", menuSummary(0, 0))
    }

    @Test fun everyIconOnTheListIsUniqueAndTheUsualOnesAreOnIt() {
        assertEquals(MenuIcons.ALL.size, MenuIcons.ALL.toSet().size)
        assertTrue(all.all { it.icon in MenuIcons.ALL })
        assertTrue(ShortcutKind.entries.all { it.icon in MenuIcons.ALL })
    }
}

class MenuStyleTest {
    @Test fun anUnknownSkinFallsBackToClassic() {
        assertEquals(MenuSkinId.Classic, MenuSkinId.of(null))
        assertEquals(MenuSkinId.Classic, MenuSkinId.of("gone"))
        assertEquals(MenuSkinId.Floating, MenuSkinId.of("float"))
        MenuSkinId.entries.forEach { assertEquals(it, MenuSkinId.of(it.key)) }
    }

    @Test fun skinKeysAreUnique() {
        assertEquals(MenuSkinId.entries.size, MenuSkinId.entries.map { it.key }.toSet().size)
        assertEquals(MenuBottom.entries.size, MenuBottom.entries.map { it.key }.toSet().size)
    }

    @Test fun optionsAreKeptInRange() {
        val o = MenuOptions(rowSize = 9, dim = -3, action = 7, groupNames = 5, cancel = -1).clamped()
        assertEquals(2, o.rowSize); assertEquals(0, o.dim); assertEquals(1, o.action); assertEquals(2, o.groupNames); assertEquals(0, o.cancel)
    }

    @Test fun theTitleAndTheFooterLineAreCutAndTrimmed() {
        val o = MenuOptions(title = "  " + "t".repeat(60) + " ", footerText = " f ".repeat(60)).clamped()
        assertEquals(MenuOptions.MAX_TITLE, o.title.length)
        assertTrue(o.footerText.length <= MenuOptions.MAX_FOOTER)
        assertEquals("scrapbook", MenuOptions().titleOrDefault)
        assertEquals("Mine", MenuOptions(title = "Mine").titleOrDefault)
        assertEquals("scrapbook", MenuOptions(title = "   ").titleOrDefault)
    }

    @Test fun rowSizeAndDimGiveUsableNumbers() {
        assertEquals(-8, MenuOptions(rowSize = 0).rowDelta); assertEquals(0, MenuOptions(rowSize = 1).rowDelta); assertEquals(8, MenuOptions(rowSize = 2).rowDelta)
        assertTrue(MenuOptions(dim = 0).dimAlpha < MenuOptions(dim = 1).dimAlpha)
        assertTrue(MenuOptions(dim = 1).dimAlpha < MenuOptions(dim = 2).dimAlpha)
        assertEquals(3, MenuOptions.ROW_SIZES.size); assertEquals(3, MenuOptions.DIMS.size); assertEquals(2, MenuOptions.ACTIONS.size); assertEquals(3, MenuOptions.TRI.size)
    }

    @Test fun theUsualStyleIsClassicWithComfortableRowsAndTheNewScrapButton() {
        val s = MenuStyle()
        assertEquals(MenuSkinId.Classic, s.skin)
        assertEquals(1, s.options.rowSize)
        assertTrue(s.options.icons)
        assertEquals(1, s.options.dim)
        assertEquals(MenuBottom.NewScrap, s.options.bottom)
        assertEquals(0, s.options.cancel)
        assertFalse(s.options.accent)
        assertFalse(s.options.profile)
    }

    @Test fun anUnknownBottomButtonIsTheNewScrapButton() {
        assertEquals(MenuBottom.NewScrap, MenuBottom.of(null))
        assertEquals(MenuBottom.NewScrap, MenuBottom.of("gone"))
        MenuBottom.entries.forEach { assertEquals(it, MenuBottom.of(it.key)) }
    }
}

class MenuConfigTest {
    private val custom = MenuConfig(
        MenuLayout.Default.addShortcut(ShortcutKind.Box, "A=b&c", "Box = 1").withHidden(item(MenuEntry.Bin), true).withLook(item(MenuEntry.Home), "Start", "star"),
        MenuStyle(MenuSkinId.Bento, MenuOptions(rowSize = 2, icons = false, dim = 2, footer = false, action = 1, title = "My = menu\nx", showTitle = false, groupNames = 2, cancel = 1,
            bottom = MenuBottom.Voice, footerText = "Only mine | here", accent = true, profile = true)),
    )

    @Test fun aWholeConfigIsSavedAndReadBackTheSame() {
        assertEquals(custom, MenuConfig.decode(custom.encode()))
        assertEquals(MenuConfig(), MenuConfig.decode(MenuConfig().encode()))
    }

    @Test fun nothingOrJunkIsNotAConfig() {
        assertNull(MenuConfig.decode(null)); assertNull(MenuConfig.decode("")); assertNull(MenuConfig.decode("hello world")); assertNull(MenuConfig.decode("a=b"))
    }

    @Test fun aDamagedConfigStillGivesAWorkingMenu() {
        val c = MenuConfig.decode("skin=gone\nrows=99\nbottom=gone\ndim=x\nicons=maybe")!!
        assertEquals(MenuSkinId.Classic, c.style.skin)
        assertEquals(2, c.style.options.rowSize)
        assertEquals(MenuBottom.NewScrap, c.style.options.bottom)
        assertEquals(1, c.style.options.dim)
        assertTrue(c.style.options.icons)
        assertEquals(MenuLayout.Default, c.layout)
    }

    @Test fun theBuiltInPresetsAreAllReadable() {
        MenuPresets.builtIn.forEach { (_, c) -> assertEquals(c, MenuConfig.decode(c.encode())) }
        assertEquals(MenuConfig(), MenuPresets.Classic)
        assertEquals(MenuSkinId.Minimal, MenuPresets.Minimal.style.skin)
        assertTrue(MenuEntry.Settings.key !in MenuPresets.Minimal.layout.hidden)
        assertTrue(MenuPresets.Minimal.layout.reachesCustomize)
        assertEquals(MenuEntry.entries.size - 7, MenuPresets.Minimal.layout.groups().flatten().size)
        assertTrue(MenuPresets.Everything.layout.hidden.isEmpty())
    }

    @Test fun savedPresetsKeepTheirNamesAndConfigs() {
        var list = MenuPresets.save(emptyList(), "My menu", custom)
        list = MenuPresets.save(list, "Plain", MenuPresets.Classic)
        val back = MenuPresets.decode(MenuPresets.encode(list))
        assertEquals(listOf("My menu", "Plain"), back.map { it.name })
        assertEquals(custom, MenuConfig.decode(back[0].blob))
    }

    @Test fun savingUnderTheSameNameReplacesAndABlankNameDoesNothing() {
        var list = MenuPresets.save(emptyList(), "A", custom)
        list = MenuPresets.save(list, "a", MenuPresets.Minimal)
        assertEquals(1, list.size)
        assertEquals(MenuPresets.Minimal, MenuConfig.decode(list[0].blob))
        assertEquals(list, MenuPresets.save(list, "   ", custom))
        assertEquals(emptyList<MenuPreset>(), MenuPresets.remove(list, "A"))
    }

    @Test fun thereIsALimitToSavedPresetsAndTheOldestGoesFirst() {
        var list = emptyList<MenuPreset>()
        repeat(10) { list = MenuPresets.save(list, "p$it", custom) }
        assertEquals(MenuPresets.MAX_SAVED, list.size)
        assertEquals("p9", list.last().name)
        assertEquals("p4", list.first().name)
        assertEquals(MenuPresets.MAX_SAVED, MenuPresets.decode(MenuPresets.encode(list)).size)
    }

    @Test fun savedPresetsThatCanNotBeReadAreDropped() {
        val good = MenuPresets.encode(MenuPresets.save(emptyList(), "ok", custom))
        val text = good + "\nbroken\n" + MenuLayout.enc("x") + "|" + MenuLayout.enc("not a menu")
        assertEquals(listOf("ok"), MenuPresets.decode(text).map { it.name })
        assertTrue(MenuPresets.decode(null).isEmpty())
    }
}

class MenuHistoryTest {
    private val a = MenuConfig()
    private val b = MenuConfig(MenuLayout.Default.withHidden(item(MenuEntry.Bin), true))
    private val c = MenuConfig(MenuLayout.Default.withHidden(item(MenuEntry.About), true))

    @Test fun undoGivesBackTheLastStateFirst() {
        val h = MenuHistory()
        assertFalse(h.canUndo)
        h.push(a); h.push(b)
        assertTrue(h.canUndo)
        assertEquals(b, h.pop()); assertEquals(a, h.pop()); assertNull(h.pop())
        assertFalse(h.canUndo)
    }

    @Test fun theSameStateTwiceIsRememberedOnce() {
        val h = MenuHistory()
        h.push(a); h.push(a)
        assertEquals(a, h.pop()); assertNull(h.pop())
    }

    @Test fun onlyTheLastFewAreKept() {
        val h = MenuHistory()
        repeat(MenuHistory.LIMIT + 10) { i -> h.push(if (i % 2 == 0) b else c) }
        var n = 0
        while (h.pop() != null) n++
        assertEquals(MenuHistory.LIMIT, n)
    }

    @Test fun clearForgetsEverything() {
        val h = MenuHistory(); h.push(a); h.push(b); h.clear()
        assertFalse(h.canUndo)
    }
}
