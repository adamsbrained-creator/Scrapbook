package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinShareTest {
    private val manual = HomeSection("m1", "Week", SectionLayout.Cards, "pinned", listOf(SectionRef(true, "Inbox"), SectionRef(false, "uid1")))
    private val smart = HomeSection("s1", "Ideas", SectionLayout.Rows, "", rule = SectionRule(SectionRule.TAG, "ideas"))
    private val card = HomeSection("c1", "Note", SectionLayout.Cards, "recent", card = SectionCard(SectionCard.TEXT, "hello | world\nsecond line"))

    private fun skin(values: Map<String, String> = mapOf(SkinKeys.HEADER to "0", SkinKeys.STYLES to "boxesStyle=2")) = HomeSkin("abc", "Night & day", values)

    @Test fun aSkinSurvivesTheTripThroughACode() {
        val back = SkinShare.parse(SkinShare.export(skin()))
        assertNotNull(back)
        assertEquals("Night & day", back!!.name)
        assertEquals(skin().values, back.values)
    }

    @Test fun theCodeIsOneLineWithoutSpacesThatStartsWithThePrefix() {
        val code = SkinShare.export(skin())
        assertTrue(code.startsWith(SkinShare.PREFIX))
        assertFalse(code.any { it.isWhitespace() })
        assertTrue(code.length < SkinShare.MAX_CODE)
    }

    @Test fun sectionsOfShortcutsAreLeftOutAndTheRestIsKept() {
        val v = mapOf(SkinKeys.SECTIONS to HomeSections.encode(listOf(manual, smart, card)))
        val back = SkinShare.parse(SkinShare.export(skin(v)))!!
        assertEquals(listOf("s1", "c1"), back.sections.map { it.id })
        assertEquals(card, back.sections.last())
        assertTrue(back.sections.none { it.refs.isNotEmpty() })
    }

    @Test fun aSkinWithOnlyShortcutSectionsHasNoSectionsAfterwards() {
        val back = SkinShare.parse(SkinShare.export(skin(mapOf(SkinKeys.SECTIONS to HomeSections.encode(listOf(manual))))))!!
        assertTrue(back.sections.isEmpty())
        assertFalse(SkinKeys.SECTIONS in back.values)
    }

    @Test fun aSkinMadeOfNothingIsStillASkin() {
        val back = SkinShare.parse(SkinShare.export(skin(emptyMap())))
        assertNotNull(back)
        assertTrue(back!!.values.isEmpty())
    }

    @Test fun theCodeCanSitInsideAMessage() {
        val code = SkinShare.export(skin())
        val back = SkinShare.parse("hey, try this one!\n$code\nit looks good  ")
        assertNotNull(back)
        assertEquals("Night & day", back!!.name)
    }

    @Test fun onlyTheFirstCodeIsRead() {
        val a = SkinShare.export(skin().copy(name = "First"))
        val b = SkinShare.export(skin().copy(name = "Second"))
        assertEquals("First", SkinShare.parse("$a $b")!!.name)
    }

    @Test fun textThatIsNotACodeIsRefused() {
        assertNull(SkinShare.parse(null))
        assertNull(SkinShare.parse(""))
        assertNull(SkinShare.parse("hello"))
        assertNull(SkinShare.parse(SkinShare.PREFIX))
        assertNull(SkinShare.parse(SkinShare.PREFIX + "%%%not base64%%%"))
        assertNull(SkinShare.parse(SkinShare.PREFIX + "aGVsbG8"))
    }

    @Test fun aCodeThatIsTooLongIsRefused() {
        assertNull(SkinShare.parse(SkinShare.PREFIX + "A".repeat(SkinShare.MAX_CODE + 10)))
    }

    @Test fun aCodeNeverBringsAClassicSkinOrAnUnknownPiece() {
        val text = "A|classic\nK|classic|Classic\nV|header|2\nK|x|Mine\nV|header|2\nV|nonsense|1\nV|look|corners%3D0\n"
        val code = SkinShare.PREFIX + java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(text.toByteArray())
        val s = SkinShare.parse(code)!!
        assertEquals("Mine", s.name)
        assertEquals(mapOf(SkinKeys.HEADER to "2", SkinKeys.LOOK to "corners=0"), s.values)
    }

    @Test fun mergingAddsOnlyTheSkinsThatAreNotHereYet() {
        val (mine, a) = HomeSkins.initial(emptyMap()).add("Mine", mapOf(SkinKeys.HEADER to "0"))
        val (t1, b) = HomeSkins.initial(emptyMap()).add("Theirs", mapOf(SkinKeys.HEADER to "2"))
        val (theirs, c) = t1.add("mine", mapOf(SkinKeys.HEADER to "2"))
        val m = HomeSkins.merged(mine, theirs)
        assertEquals(listOf("Classic", "Mine", "Theirs"), m.skins.map { it.name })
        assertEquals(mapOf(SkinKeys.HEADER to "0"), m.skins.first { it.name == "Mine" }.values)
        assertTrue(m.skins.first { it.name == "Theirs" }.id != b.id)
        assertEquals(mine.active, m.active)
        assertEquals(a.id, m.get(a.id)!!.id)
        assertNotNull(c)
    }

    @Test fun mergingNeverBringsClassicAgainOrChangesTheClassicLook() {
        val theirs = HomeSkins.decode("A|classic\nK|classic|Classic\nV|header|2\n")
        val m = HomeSkins.merged(HomeSkins.initial(emptyMap()), theirs)
        assertEquals(listOf("classic"), m.skins.map { it.id })
        assertTrue(m.current.values.isEmpty())
    }
}
