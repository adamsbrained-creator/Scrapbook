package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

class DrawGesturesTest {
    // Some shapes, drawn from corner to corner of a unit square.
    private fun poly(vararg v: Pair<Float, Float>, per: Int = 20): List<Pt> {
        val out = ArrayList<Pt>()
        for (i in 0 until v.size - 1) for (k in 0 until per) {
            val t = k / per.toFloat()
            out.add(Pt(v[i].first + t * (v[i + 1].first - v[i].first), v[i].second + t * (v[i + 1].second - v[i].second)))
        }
        out.add(Pt(v.last().first, v.last().second))
        return out
    }
    private val zShape = poly(0f to 0f, 1f to 0f, 0f to 1f, 1f to 1f)
    private val lShape = poly(0f to 0f, 0f to 1f, 1f to 1f)
    private val vShape = poly(0f to 0f, .5f to 1f, 1f to 0f)
    private val circleShape = (0..80).map { i -> val a = 2.0 * Math.PI * i / 80; Pt(cos(a).toFloat(), sin(a).toFloat()) }
    private val sShape: List<Pt> = run {
        val out = ArrayList<Pt>()
        for (i in 0..40) { val a = Math.toRadians(-20.0 - i * 5.0); out.add(Pt((0.5 * cos(a)).toFloat(), (-0.5 + 0.5 * sin(a)).toFloat())) }
        for (i in 1..40) { val a = Math.toRadians(-90.0 + i * 5.0); out.add(Pt((0.5 * cos(a)).toFloat(), (0.5 + 0.5 * sin(a)).toFloat())) }
        out
    }
    /** The shape as it would be drawn on a phone: big, and somewhere on the screen. */
    private fun placed(p: List<Pt>) = p.map { Pt(100f + 300f * it.x, 50f + 300f * it.y) }
    /** The same, drawn a little unevenly (a fixed wobble of up to [amp] pixels, so the tests never change). */
    private fun wobbly(p: List<Pt>, amp: Float = 10f) = p.mapIndexed { i, q -> Pt(q.x + (sin(i * 12.9898) * amp).toFloat(), q.y + (sin(i * 78.233) * amp).toFloat()) }
    private fun gesture(id: String, shape: List<Pt>, action: String = DrawActions.NEW) = DrawGesture(id, id, action, listOf(Strokes.normalize(placed(shape))))

    @Test fun aLineBecomesTheSameNumberOfEvenlySpacedPoints() {
        val r = Strokes.resample(sShape)
        assertEquals(Strokes.N, r.size)
        assertEquals(sShape.first(), r.first())
        assertTrue(Math.hypot((r.last().x - sShape.last().x).toDouble(), (r.last().y - sShape.last().y).toDouble()) < 1e-3)
        assertEquals(Strokes.N, Strokes.resample(listOf(Pt(5f, 5f), Pt(5f, 5f))).size)
        assertTrue(Strokes.resample(emptyList()).isEmpty())
    }

    @Test fun aComparableLineIsCenteredAndOneUnitLong() {
        val n = Strokes.normalize(placed(sShape))
        assertEquals(Strokes.N, n.size)
        assertEquals(0.0, n.map { it.x.toDouble() }.average(), 1e-3)
        assertEquals(0.0, n.map { it.y.toDouble() }.average(), 1e-3)
        val side = maxOf(n.maxOf { it.x } - n.minOf { it.x }, n.maxOf { it.y } - n.minOf { it.y })
        assertEquals(1f, side, 1e-3f)
    }

    @Test fun whereAndHowBigItIsDrawnDoesNotMatter() {
        listOf(sShape, zShape, circleShape, lShape, vShape).forEach { shape ->
            val a = Strokes.normalize(shape)
            val b = Strokes.normalize(placed(shape))
            assertTrue(Strokes.score(a, b) > 0.99f)
        }
    }

    @Test fun anUnevenDrawingOfTheSameShapeStillScoresHigh() {
        listOf(sShape, zShape, circleShape, lShape, vShape).forEach { shape ->
            assertTrue(Strokes.score(Strokes.normalize(shape), Strokes.normalize(wobbly(placed(shape)))) > 0.90f)
        }
    }

    @Test fun differentShapesScoreLow() {
        val s = Strokes.normalize(sShape); val z = Strokes.normalize(zShape); val c = Strokes.normalize(circleShape); val v = Strokes.normalize(vShape)
        assertTrue(Strokes.score(s, z) < 0.6f)
        assertTrue(Strokes.score(z, c) < 0.5f)
        assertTrue(Strokes.score(s, c) < 0.5f)
        assertTrue(Strokes.score(v, s) < 0.5f)
        assertEquals(0f, Strokes.score(s, emptyList()), 0f)
    }

    @Test fun aDrawingMatchesTheGestureItIs() {
        val all = listOf(gesture("S", sShape), gesture("Z", zShape), gesture("C", circleShape))
        assertEquals("S", DrawGestures.match(wobbly(placed(sShape)), all)?.gesture?.id)
        assertEquals("Z", DrawGestures.match(wobbly(placed(zShape)), all)?.gesture?.id)
        assertEquals("C", DrawGestures.match(wobbly(placed(circleShape)), all)?.gesture?.id)
    }

    @Test fun aDrawingThatIsNoGestureMatchesNothing() {
        val all = listOf(gesture("S", sShape), gesture("Z", zShape), gesture("C", circleShape))
        assertNull(DrawGestures.match(placed(vShape), all))
        assertNull(DrawGestures.match(placed(sShape), emptyList()))
        assertNull(DrawGestures.match(listOf(Pt(1f, 1f), Pt(2f, 2f)), all))
    }

    @Test fun twoGesturesThatLookAlikeAreNeverMixedUp() {
        val near = gesture("S2", wobbly(sShape, 0.01f))
        val all = listOf(gesture("S", sShape), near)
        assertNull(DrawGestures.match(placed(sShape), all))
    }

    @Test fun aNewGestureLikeAnExistingOneIsFound() {
        val existing = listOf(gesture("S", sShape), gesture("Z", zShape))
        assertEquals("S", DrawGestures.clash(listOf(placed(sShape), wobbly(placed(sShape))), existing)?.gesture?.id)
        assertNull(DrawGestures.clash(listOf(placed(vShape)), existing))
        assertNull(DrawGestures.clash(listOf(placed(sShape)), emptyList()))
    }

    @Test fun gesturesAreSavedAndReadBack() {
        val g = DrawGesture("g1", "Open | Trips ✓", DrawActions.box("Trips"), listOf(Strokes.normalize(placed(sShape)), Strokes.normalize(wobbly(placed(sShape)))))
        val h = DrawGesture("g2", "Note", DrawActions.scrap("abc123"), listOf(Strokes.normalize(placed(zShape))))
        val back = DrawGestures.decode(DrawGestures.encode(listOf(g, h)))
        assertEquals(listOf("g1", "g2"), back.map { it.id })
        assertEquals("Open | Trips ✓", back[0].label)
        assertEquals(DrawActions.box("Trips"), back[0].action)
        assertEquals(2, back[0].samples.size)
        assertEquals(Strokes.N, back[0].samples[0].size)
        // Saving rounds to thousandths, which must not change what the gesture is.
        assertTrue(Strokes.score(g.samples[0], back[0].samples[0]) > 0.99f)
        assertEquals("g1", DrawGestures.match(wobbly(placed(sShape)), back)?.gesture?.id)
    }

    @Test fun unreadableSavedGesturesAreSkipped() {
        val good = DrawGestures.encode(listOf(gesture("ok", sShape)))
        val junk = "nothing\nG|x\nG|dup|L|bogus|1,2\nG||L|new|" + "1,1,".repeat(64) + "\n" + "G|short|L|new|1,2,3,4\n"
        assertEquals(listOf("ok"), DrawGestures.decode(junk + good).map { it.id })
        assertTrue(DrawGestures.decode(null).isEmpty())
        assertTrue(DrawGestures.decode("").isEmpty())
        assertTrue(DrawGestures.encode(emptyList()).isEmpty())
        // The same id twice: the first one stays.
        assertEquals(1, DrawGestures.decode(good + good).size)
    }

    @Test fun actionsKnowWhatTheyAre() {
        assertEquals("Trips", DrawActions.boxOf(DrawActions.box("Trips")))
        assertNull(DrawActions.boxOf("box:"))
        assertNull(DrawActions.boxOf(DrawActions.scrap("x")))
        assertEquals("abc", DrawActions.scrapOf(DrawActions.scrap("abc")))
        assertTrue(DrawActions.isKnown(DrawActions.NEW) && DrawActions.isKnown(DrawActions.CHECKLIST) && DrawActions.isKnown(DrawActions.SEARCH))
        assertTrue(DrawActions.isKnown(DrawActions.box("A")))
        assertTrue(!DrawActions.isKnown("fly") && !DrawActions.isKnown("scrap:"))
    }

    @Test fun rankedListsTheBestFirstAndNeedsEnoughPoints() {
        val all = listOf(gesture("Z", zShape), gesture("S", sShape))
        val r = DrawGestures.ranked(placed(sShape), all)
        assertEquals("S", r.first().gesture.id)
        assertTrue(r.first().score > r.last().score)
        assertNotNull(r.first())
        assertTrue(DrawGestures.ranked(listOf(Pt(0f, 0f), Pt(1f, 1f)), all).isEmpty())
    }
}
