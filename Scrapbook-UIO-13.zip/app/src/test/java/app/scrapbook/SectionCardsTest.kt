package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SectionCardsTest {
    private fun mk(title: String, box: String = "Inbox", tags: List<String> = emptyList(), at: Long = 1000L) =
        Item(title = title, body = "", kind = Kind.Note, collection = box, tags = tags, savedAt = at)

    private fun card(kind: String, text: String = "", arg: String = "") = HomeSection("id1", "Title", SectionLayout.Cards, "pinned", card = SectionCard(kind, text, arg))

    @Test fun everyKindHasANameAndADefaultTitle() {
        SectionCard.KINDS.forEach {
            assertTrue(it, SectionCard.label(it).isNotBlank())
            assertTrue(it, SectionCard.defaultTitle(it).isNotBlank())
        }
        assertEquals(SectionCard.KINDS.size, SectionCard.KINDS.toSet().size)
    }

    @Test fun aCardSectionIsACardAndNotSmart() {
        val s = card(SectionCard.TEXT, "hello")
        assertTrue(s.isCard)
        assertFalse(s.isSmart)
        assertFalse(HomeSection("x").isCard)
    }

    @Test fun aSectionWithoutATitleIsCalledAfterItsKind() {
        assertEquals("Quote card", HomeSection("x", "", card = SectionCard(SectionCard.QUOTE)).name)
        assertEquals("New section", HomeSection("x").name)
        assertEquals("Mine", HomeSection("x", "Mine", card = SectionCard(SectionCard.TEXT)).name)
    }

    @Test fun everyKindIsSavedAndReadBackTheSame() {
        val all = SectionCard.KINDS.mapIndexed { i, k ->
            HomeSection("c$i", "Card $i", SectionLayout.Cards, "", card = SectionCard(k, "line one\nline | two & three\n\nlast", if (k == SectionCard.COUNTER) "tag:ideas" else "Trips"))
        }
        assertEquals(all, HomeSections.decode(HomeSections.encode(all)))
    }

    @Test fun aCardWithNothingInItIsKept() {
        val s = listOf(HomeSection("e", "", SectionLayout.Cards, "", card = SectionCard(SectionCard.TEXT)))
        assertEquals(s, HomeSections.decode(HomeSections.encode(s)))
    }

    @Test fun sectionsSavedBeforeCardsStillReadBack() {
        val old = "S|a|cards||Week\nB|Inbox\nS|b|rows|pinned|Tag|tag%3Aideas\n"
        val d = HomeSections.decode(old)
        assertEquals(2, d.size)
        assertNull(d[0].card)
        assertNull(d[1].card)
        assertEquals(SectionRule(SectionRule.TAG, "ideas"), d[1].rule)
        assertEquals(listOf(SectionRef(true, "Inbox")), d[0].refs)
    }

    @Test fun anOldSectionIsWrittenTheOldWay() {
        val plain = HomeSection("a", "Week", SectionLayout.Cards, "", listOf(SectionRef(true, "Inbox")))
        assertEquals("S|a|cards||Week\nB|Inbox\n", HomeSections.encode(listOf(plain)))
        val smart = HomeSection("b", "Tag", SectionLayout.Rows, "pinned", rule = SectionRule(SectionRule.TAG, "ideas"))
        assertEquals("S|b|rows|pinned|Tag|tag%3Aideas\n", HomeSections.encode(listOf(smart)))
    }

    @Test fun anUnknownKindIsReadAsASectionWithoutACard() {
        val d = HomeSections.decode("S|a|cards||Hi||future|x|y\n")
        assertEquals(1, d.size)
        assertNull(d[0].card)
        assertEquals("Hi", d[0].title)
    }

    @Test fun aLongTextIsCutWhenRead() {
        val c = SectionCard.parse(SectionCard.TEXT, "x".repeat(2000), "")
        assertNotNull(c)
        assertEquals(SectionCard.MAX_TEXT, c!!.text.length)
        assertNull(SectionCard.parse("nope", "a", "b"))
    }

    @Test fun theLinesOfAQuoteCardSkipBlanksAndAreTrimmed() {
        assertEquals(listOf("one", "two", "three"), SectionCard(SectionCard.QUOTE, "  one \n\n two\n\n\nthree  ").lines)
        assertEquals(emptyList<String>(), SectionCard(SectionCard.QUOTE, " \n ").lines)
    }

    @Test fun theQuoteOfTheDayGoesRoundInOrder() {
        val lines = listOf("a", "b", "c")
        assertEquals("a", HomeSections.quoteOf(lines, 0))
        assertEquals("b", HomeSections.quoteOf(lines, 1))
        assertEquals("a", HomeSections.quoteOf(lines, 3))
        assertEquals("c", HomeSections.quoteOf(lines, 20000L * 3 + 2))
        assertEquals("", HomeSections.quoteOf(emptyList(), 5))
        assertEquals("c", HomeSections.quoteOf(lines, -1))
    }

    @Test fun aSeedPicksTheSameScrapEveryTimeAndNothingFromNothing() {
        val items = listOf(mk("a"), mk("b"), mk("c"))
        assertEquals(HomeSections.pickOne(items, 41), HomeSections.pickOne(items, 41))
        assertEquals(items[1], HomeSections.pickOne(items, 1))
        assertEquals(items[0], HomeSections.pickOne(items, 3))
        assertEquals(items[2], HomeSections.pickOne(items, -1))
        assertNull(HomeSections.pickOne(emptyList(), 7))
    }

    @Test fun aCardOnlyLooksAtTheScrapsItsScopeNames() {
        assertNull(SectionCard(SectionCard.COUNTER).scope)
        assertEquals(SectionRule(SectionRule.WEEK), SectionCard(SectionCard.RANDOM, arg = "week").scope)
        assertEquals(SectionRule(SectionRule.BOX, "Trips"), SectionCard(SectionCard.COUNTER, arg = "box:Trips").scope)
        assertNull(SectionCard(SectionCard.BUTTON, arg = "box:Trips").scope)
        assertNull(SectionCard(SectionCard.RANDOM, arg = "garbage").scope)
    }

    @Test fun aButtonWritesInTheInboxUnlessABoxIsChosen() {
        assertEquals("Inbox", SectionCard(SectionCard.BUTTON).destination)
        assertEquals("Trips", SectionCard(SectionCard.BUTTON, arg = "Trips").destination)
    }

    @Test fun matchingAndCountingAgree() {
        val now = 10L * SectionRule.WEEK_MS
        val items = listOf(mk("a", "Trips", listOf("ideas"), now - 1000), mk("b", "Trips", emptyList(), now - 2 * SectionRule.WEEK_MS), mk("c", "Inbox", listOf("Ideas"), now - 10))
        assertEquals(3, HomeSections.count(null, items, emptySet(), now))
        assertEquals(items, HomeSections.matching(null, items, emptySet(), now))
        assertEquals(2, HomeSections.count(SectionRule(SectionRule.TAG, "ideas"), items, emptySet(), now))
        assertEquals(2, HomeSections.count(SectionRule(SectionRule.BOX, "Trips"), items, setOf("Trips"), now))
        assertEquals(2, HomeSections.count(SectionRule(SectionRule.WEEK), items, emptySet(), now))
        assertEquals(0, HomeSections.count(SectionRule("nope"), items, emptySet(), now))
    }

    @Test fun smartSectionsStillShowTheNewestFirstAndAtMostEight() {
        val items = (1..12).map { mk("n$it", at = it.toLong()) }
        val shown = HomeSections.smartScraps(SectionRule(SectionRule.BOX, "Inbox"), items, setOf("Inbox"), 100L)
        assertEquals(SectionRule.MAX_SHOWN, shown.size)
        assertEquals("n12", shown.first().title)
    }

    @Test fun theCounterSaysWhatItCounts() {
        assertEquals("scraps in total", HomeSections.counterText(5, null, ""))
        assertEquals("scrap in total", HomeSections.counterText(1, null, ""))
        assertEquals("scraps tagged #ideas", HomeSections.counterText(3, SectionRule(SectionRule.TAG, "ideas"), ""))
        assertEquals("scraps in Trips", HomeSections.counterText(0, SectionRule(SectionRule.BOX, "Trips"), "Trips"))
        assertEquals("scraps edited this week", HomeSections.counterText(2, SectionRule(SectionRule.WEEK), ""))
    }

    @Test fun cardsTakePartInTheOrderOfTheBlocksLikeAnySection() {
        val a = card(SectionCard.TEXT, "x").copy(id = "a", anchor = "")
        val order = HomeElement.entries.toList()
        val inserted = HomeSections.insert(order, listOf(a), card(SectionCard.QUOTE).copy(id = "b"), "recent")
        assertEquals(listOf("a", "b"), inserted.map { it.id })
        assertEquals("recent", inserted.last().anchor)
        assertTrue(inserted.all { it.isCard })
    }
}
