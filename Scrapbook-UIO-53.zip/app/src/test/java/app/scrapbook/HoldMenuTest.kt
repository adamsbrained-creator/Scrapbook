package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HoldMenuTest {
    private val d = HoldMenuConfig.DEFAULT

    @Test fun defaultMenuIsTheOneFromTheMockup() {
        assertEquals(listOf(HoldAction.Pin, HoldAction.AddToBox, HoldAction.Tags, HoldAction.Share), d.quick)
        assertEquals(listOf(HoldAction.Select, HoldAction.Duplicate), d.plainRows)
        assertEquals(listOf(HoldAction.Delete), d.dangerRows)
        assertTrue(d.isDefault)
        assertEquals(d, d.sanitized())
    }

    @Test fun pinReadsUnpinForAPinnedScrapAndNothingElseChanges() {
        assertEquals("Pin", HoldAction.Pin.title(false)); assertEquals("Unpin", HoldAction.Pin.title(true))
        assertEquals("starline", HoldAction.Pin.iconFor(false)); assertEquals("star", HoldAction.Pin.iconFor(true))
        HoldAction.entries.filter { it != HoldAction.Pin }.forEach { assertEquals(it.label, it.title(true)); assertEquals(it.icon, it.iconFor(true)) }
    }

    @Test fun onlyDeleteIsDestructive() = assertEquals(listOf(HoldAction.Delete), HoldAction.entries.filter { it.danger })

    @Test fun idsAreUniqueAndFindable() {
        assertEquals(HoldAction.entries.size, HoldAction.entries.map { it.id }.toSet().size)
        HoldAction.entries.forEach { assertEquals(it, HoldAction.of(it.id)) }
        assertNull(HoldAction.of("nope")); assertNull(HoldAction.of(""))
    }

    @Test fun anActionAppearsOnceAndTheTopRowWins() {
        val s = HoldMenuConfig(listOf(HoldAction.Pin, HoldAction.Pin, HoldAction.Tags), listOf(HoldAction.Pin, HoldAction.Select, HoldAction.Select, HoldAction.Delete)).sanitized()
        assertEquals(listOf(HoldAction.Pin, HoldAction.Tags), s.quick)
        assertEquals(listOf(HoldAction.Select, HoldAction.Delete), s.rows)
    }

    @Test fun topRowHasAtMostFourAndACutOffActionCanStillBeInTheList() {
        val s = HoldMenuConfig(listOf(HoldAction.Pin, HoldAction.AddToBox, HoldAction.Tags, HoldAction.Share, HoldAction.Duplicate), listOf(HoldAction.Select, HoldAction.Duplicate)).sanitized()
        assertEquals(4, s.quick.size)
        assertFalse(HoldAction.Duplicate in s.quick)
        assertEquals(listOf(HoldAction.Select, HoldAction.Duplicate), s.rows)
    }

    @Test fun selectIsNeverMissing() {
        val none = HoldMenuConfig(emptyList(), listOf(HoldAction.Delete)).sanitized()
        assertEquals(listOf(HoldAction.Select, HoldAction.Delete), none.rows)
        val inTop = HoldMenuConfig(listOf(HoldAction.Select), emptyList()).sanitized()   // a button on the top row counts
        assertEquals(emptyList<HoldAction>(), inTop.rows)
        assertEquals(listOf(HoldAction.Select), HoldMenuConfig(emptyList(), emptyList()).sanitized().rows)
    }

    @Test fun theDefaultMenuSavesAsNothing() {
        assertEquals("", d.encode())
        assertEquals(d, HoldMenuConfig.decode(null)); assertEquals(d, HoldMenuConfig.decode("")); assertEquals(d, HoldMenuConfig.decode("  "))
    }

    @Test fun onlyTheHalfThatChangedIsSaved() {
        val c = d.copy(quick = listOf(HoldAction.Share, HoldAction.Pin))
        assertEquals("q=share,pin", c.encode())
        val r = d.copy(rows = listOf(HoldAction.Duplicate, HoldAction.Select))
        assertEquals("r=duplicate,select", r.encode())
    }

    @Test fun aSavedMenuComesBackTheSame() {
        val c = HoldMenuConfig(listOf(HoldAction.Tags, HoldAction.Open), listOf(HoldAction.Duplicate, HoldAction.Select, HoldAction.Pin, HoldAction.Delete))
        assertEquals(c, HoldMenuConfig.decode(c.encode()))
        val empty = HoldMenuConfig(emptyList(), listOf(HoldAction.Select, HoldAction.Delete))
        assertEquals("q=;r=select,delete", empty.encode())
        assertEquals(empty, HoldMenuConfig.decode(empty.encode()))   // "q=" is an empty top row, not the default one
    }

    @Test fun badTextNeverBreaksTheMenu() {
        assertEquals(d, HoldMenuConfig.decode("junk;;=;q;x=1"))
        val c = HoldMenuConfig.decode("q=pin,wat,pin,share;r=;z=1")
        assertEquals(listOf(HoldAction.Pin, HoldAction.Share), c.quick)
        assertEquals(listOf(HoldAction.Select), c.rows)   // an empty list still gets Select back
        assertEquals(HoldMenuConfig.MAX_QUICK, HoldMenuConfig.decode("q=pin,box,tags,share,duplicate").quick.size)
    }

    // ---- where the menu goes ----

    @Test fun opensUnderTheCardLinedUpWithItsRightEdge() {
        val s = placePopover(anchorTop = 100f, anchorRight = 380f, anchorBottom = 240f, width = 290f, height = 250f, viewW = 400f, viewH = 800f)
        assertEquals(PopoverSpot(x = 84f, y = 252f, above = false), s)   // 380 - 290 - 6, and 240 + 12
    }

    @Test fun opensAboveWhenThereIsNoRoomBelow() {
        val s = placePopover(anchorTop = 560f, anchorRight = 380f, anchorBottom = 700f, width = 290f, height = 250f, viewW = 400f, viewH = 800f)
        assertEquals(PopoverSpot(x = 84f, y = 298f, above = true), s)   // 560 - 12 - 250
    }

    @Test fun exactlyFittingBelowStaysBelow() {
        // room for the menu to end exactly one margin above the bottom
        val s = placePopover(anchorTop = 0f, anchorRight = 400f, anchorBottom = 526f, width = 100f, height = 250f, viewW = 400f, viewH = 800f)
        assertEquals(538f, s.y); assertFalse(s.above)
        val over = placePopover(anchorTop = 400f, anchorRight = 400f, anchorBottom = 527f, width = 100f, height = 250f, viewW = 400f, viewH = 800f)
        assertTrue(over.above)
    }

    @Test fun aCardTallerThanTheScreenGetsTheMenuAtTheBottomOverIt() {
        val s = placePopover(anchorTop = 50f, anchorRight = 380f, anchorBottom = 900f, width = 290f, height = 250f, viewW = 400f, viewH = 800f)
        assertEquals(PopoverSpot(x = 84f, y = 538f, above = false), s)
    }

    @Test fun neverLeavesTheSidesOfTheScreen() {
        assertEquals(12f, placePopover(100f, 100f, 200f, 290f, 250f, 400f, 800f).x)   // a narrow card at the left edge: pushed in by the margin
        assertEquals(98f, placePopover(100f, 400f, 200f, 290f, 250f, 400f, 800f).x)   // 400 - 290 - 12, not 104
        assertEquals(12f, placePopover(100f, 380f, 200f, 290f, 250f, 200f, 800f).x)   // a screen narrower than the menu
    }

    @Test fun neverAboveTheTopOfTheScreen() {
        val s = placePopover(anchorTop = 20f, anchorRight = 380f, anchorBottom = 780f, width = 290f, height = 250f, viewW = 400f, viewH = 800f)
        assertTrue(s.y >= 12f)
    }
}
