package app.scrapbook

import app.scrapbook.BubblePlace.Side
import org.junit.Assert.assertEquals
import org.junit.Test

class BubblePlaceTest {
    private fun p(selTop: Float, selBottom: Float, visBottom: Float = 1000f, canScroll: Float = 0f, visTop: Float = 0f) =
        BubblePlace.place(selTop, selBottom, h = 50f, visTop = visTop, visBottom = visBottom, belowGap = 30f, aboveGap = 10f, clearAbove = 60f, margin = 8f, canScroll = canScroll, maxStep = 150f)

    @Test fun underTheTextWhenThereIsRoom() {
        val s = p(200f, 220f)
        assertEquals(Side.Below, s.side); assertEquals(250f, s.top, 0.01f); assertEquals(0f, s.scrollBy, 0.01f)
    }

    @Test fun scrollsALittleWhenItCan() {
        // under the text would end 58 below the bottom of what is visible
        val s = p(950f, 970f, canScroll = 400f)
        assertEquals(Side.Below, s.side); assertEquals(58f, s.scrollBy, 0.01f); assertEquals(1000f, s.top, 0.01f)
    }

    @Test fun neverScrollsMoreThanTheStepOrThePageAllows() {
        // the page can only scroll 40 of the 58 needed: above the phone's own bar instead
        val short = p(950f, 970f, canScroll = 40f)
        assertEquals(Side.Above, short.side); assertEquals(950f - 10f - 60f - 50f, short.top, 0.01f); assertEquals(0f, short.scrollBy, 0.01f)
        // more than one small step is not scrolled either
        val far = BubblePlace.place(950f, 970f, 50f, 0f, 1000f, 30f, 10f, 60f, 8f, canScroll = 400f, maxStep = 20f)
        assertEquals(Side.Above, far.side)
    }

    @Test fun aboveClearsThePhonesCopyBar() {
        val s = p(940f, 960f)
        assertEquals(Side.Above, s.side)
        assertEquals(940f - 120f, s.top + 0f, 0.01f)   // 10 gap + 60 bar + 50 bubble above the top of the text
    }

    @Test fun dockedOnlyWhenNothingFits() {
        val s = p(10f, 990f)
        assertEquals(Side.Docked, s.side); assertEquals(1000f - 50f - 8f, s.top, 0.01f)
    }

    @Test fun staysInsideTheFieldSideways() {
        assertEquals(0f, BubblePlace.left(20f, 288f, 360f), 0.01f)
        assertEquals(72f, BubblePlace.left(340f, 288f, 360f), 0.01f)
        assertEquals(0f, BubblePlace.left(100f, 400f, 360f), 0.01f)
    }

    @Test fun linkBubbleGoesAboveFirst() {
        val up = BubblePlace.placeAboveFirst(300f, 320f, 44f, 0f, 1000f, 30f, 12f, 8f)
        assertEquals(Side.Above, up.side); assertEquals(300f - 12f - 44f, up.top, 0.01f)
        val down = BubblePlace.placeAboveFirst(20f, 40f, 44f, 0f, 1000f, 30f, 12f, 8f)
        assertEquals(Side.Below, down.side); assertEquals(70f, down.top, 0.01f)
        val none = BubblePlace.placeAboveFirst(20f, 990f, 44f, 0f, 1000f, 30f, 12f, 8f)
        assertEquals(Side.Docked, none.side)
    }
}
