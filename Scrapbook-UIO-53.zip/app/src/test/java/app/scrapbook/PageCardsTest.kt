package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PageCardsTest {
    private fun card(id: String, x: Float = .1f, y: Float = 50f, w: Float = .5f) = PageCard(id, x, y, w)

    @Test fun noCardsIsAnEmptyTextAndAnEmptyTextHoldsNoCards() {
        assertEquals("", PageCards.encode(emptyList()))
        assertEquals(emptyList<PageCard>(), PageCards.parse(""))
        assertEquals(emptyList<PageCard>(), PageCards.parse(null))
    }

    @Test fun anOldCanvasTextHoldsNoCards() {
        assertEquals(emptyList<PageCard>(), PageCards.parse("text|0.1|0.2|hello\nbox|3"))
        assertEquals(emptyList<PageCard>(), PageCards.parse("C|a|0.1|10|0.5|0|0|t|x|b|i|c|l"))
    }

    @Test fun cardsAreSavedAndReadBackTheSame() {
        val a = PageCard("a1", .12f, 80.5f, .6f, "Discuss your kid's schedule", "I can meticulously learn | your plans\nand more", "Topic", "\u2731", "\uD83D\uDE00", "example.com/x?a=1&b=2", -4, 2)
        val b = PageCard("b2", .3f, 400f, .45f, "", "", "", "pic:file:///data/img_1.jpg", "pic:file:///data/img_2.jpg", "", 12, 4)
        assertEquals(listOf(a, b), PageCards.parse(PageCards.encode(listOf(a, b))))
    }

    @Test fun theOrderFromBackToFrontIsKept() {
        val l = listOf(card("c"), card("a"), card("b"))
        assertEquals(listOf("c", "a", "b"), PageCards.parse(PageCards.encode(l)).map { it.id })
    }

    @Test fun numbersAreBroughtIntoRangeWhenRead() {
        val c = PageCards.parse("cards1\nC|a|-3|-50|0.01|99|99||||||\n").single()
        assertEquals(0f, c.x)
        assertEquals(0f, c.y)
        assertEquals(PageCards.MIN_W, c.w)
        assertEquals(PageCards.MAX_TILT, c.tilt)
        assertEquals(PageCards.TONES - 1, c.tone)
    }

    @Test fun aCardNeverRunsOffTheRightEdge() {
        val c = PageCards.clamp(PageCard("a", .9f, 10f, .5f))
        assertEquals(.5f, c.x, 1e-6f)
        assertTrue(c.x + c.w <= 1f + 1e-6f)
    }

    @Test fun lineThatCannotBeReadIsSkippedAndTheRestIsKept() {
        val text = "cards1\nC|a|0.1|10|0.5|0|0||||||\nC|b|oops|10|0.5|0|0||||||\nnonsense\nC||0.1|10|0.5|0|0||||||\nC|c|0.2|20|0.5|0|0||||||\n"
        assertEquals(listOf("a", "c"), PageCards.parse(text).map { it.id })
    }

    @Test fun repeatedIdsAreDroppedAndAtMostSixtyCardsAreKept() {
        val dup = "cards1\nC|a|0.1|10|0.5|0|0||||||\nC|a|0.2|20|0.5|0|0||||||\n"
        assertEquals(1, PageCards.parse(dup).size)
        val many = (1..80).map { card("c$it") }
        assertEquals(PageCards.MAX_CARDS, PageCards.parse(PageCards.encode(many)).size)
    }

    @Test fun longTextsAreCut() {
        val c = PageCards.clamp(PageCard("a", 0f, 0f, .5f, "t".repeat(500), "x".repeat(5000), "b".repeat(100), "i".repeat(900), "j".repeat(900), " " + "l".repeat(900)))
        assertEquals(PageCards.MAX_TITLE, c.title.length)
        assertEquals(PageCards.MAX_TEXT, c.text.length)
        assertEquals(PageCards.MAX_BADGE, c.badge.length)
        assertEquals(PageCards.MAX_ICON, c.icon.length)
        assertEquals(PageCards.MAX_ICON, c.badgeIcon.length)
        assertEquals(PageCards.MAX_LINK, c.link.length)
    }

    @Test fun savingKeepsAnOldCanvasUntilThereAreCards() {
        assertEquals("old canvas", PageCards.save(emptyList(), "old canvas"))
        assertEquals("", PageCards.save(emptyList(), PageCards.encode(listOf(card("a")))))
        assertEquals(PageCards.encode(listOf(card("a"))), PageCards.save(listOf(card("a")), "old canvas"))
    }

    @Test fun movingKeepsTheCardOnThePage() {
        val l = listOf(card("a", w = .5f), card("b"))
        val m = PageCards.move(l, "a", .9f, -20f)
        assertEquals(.5f, m[0].x, 1e-6f)
        assertEquals(0f, m[0].y)
        assertEquals(l[1], m[1])
        assertEquals(PageCards.MAX_Y, PageCards.move(l, "a", .1f, 1e9f)[0].y)
    }

    @Test fun movingFarDownIsAllowedSoThePageCanGrow() {
        assertEquals(1500f, PageCards.move(listOf(card("a")), "a", .1f, 1500f)[0].y)
    }

    @Test fun resizingStaysBetweenTheLimitsAndOnThePage() {
        val l = listOf(card("a", x = .6f, w = .3f))
        assertEquals(PageCards.MIN_W, PageCards.resize(l, "a", .05f)[0].w)
        val big = PageCards.resize(l, "a", .7f)[0]
        assertEquals(.7f, big.w, 1e-6f)
        assertEquals(.3f, big.x, 1e-6f)
        assertEquals(1f, PageCards.resize(l, "a", 3f)[0].w)
    }

    @Test fun aCardCanBeBroughtToTheFront() {
        val l = listOf(card("a"), card("b"), card("c"))
        assertEquals(listOf("b", "c", "a"), PageCards.toFront(l, "a").map { it.id })
        assertEquals(l, PageCards.toFront(l, "c"))
        assertEquals(l, PageCards.toFront(l, "zzz"))
    }

    @Test fun removingAndDuplicating() {
        val l = listOf(card("a", x = .2f, y = 100f), card("b"))
        assertEquals(listOf("b"), PageCards.remove(l, "a").map { it.id })
        val d = PageCards.duplicate(l, "a")
        assertEquals(3, d.size)
        assertEquals("a", d[0].id)
        assertNotEquals("a", d[2].id)
        assertEquals(128f, d[2].y)
        assertEquals(.25f, d[2].x, 1e-6f)
        assertEquals(l, PageCards.duplicate(l, "zzz"))
    }

    @Test fun newCardsStartNearWhatYouAreLookingAtAndSpreadOut() {
        val first = PageCards.newCard(emptyList(), 600f)
        assertTrue(first.y >= 600f)
        assertEquals(PageCards.DEFAULT_W, first.w)
        val second = PageCards.newCard(listOf(first), 600f)
        assertTrue(second.x > first.x)
        assertTrue(second.y > first.y)
        assertTrue(PageCards.newCard(emptyList(), -100f).y >= 0f)
        assertNotEquals(first.id, second.id)
        (0..9).forEach { n -> val c = PageCards.newCard(List(n) { card("k$it") }, 0f); assertTrue(c.x + c.w <= 1f + 1e-6f) }
    }

    @Test fun thePageIsTallEnoughForTheLowestCard() {
        assertEquals(0f, PageCards.bottomDp(emptyList()))
        assertEquals(1320f, PageCards.bottomDp(listOf(card("a", y = 100f), card("b", y = 1000f))))
    }

    @Test fun picturesAreFoundAndRewrittenForABackup() {
        val l = listOf(PageCard("a", .1f, 10f, .5f, icon = "pic:file:///f/img_1.jpg", badgeIcon = "\u2731"), PageCard("b", .1f, 10f, .5f, icon = "pic:file:///f/img_1.jpg", badgeIcon = "pic:file:///f/img_2.jpg"))
        assertEquals(listOf("file:///f/img_1.jpg", "file:///f/img_2.jpg"), PageCards.pictures(l))
        val mapped = PageCards.parse(PageCards.mapPictures(PageCards.encode(l)) { "images/" + it.substringAfterLast('/') })
        assertEquals("pic:images/img_1.jpg", mapped[0].icon)
        assertEquals("\u2731", mapped[0].badgeIcon)
        assertEquals("pic:images/img_2.jpg", mapped[1].badgeIcon)
        assertEquals("not cards", PageCards.mapPictures("not cards") { "x" })
        assertFalse(PageCards.pictures(listOf(card("a"))).isNotEmpty())
    }
}
