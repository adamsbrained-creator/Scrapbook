package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NoteImportTest {
    @Test fun fileKinds() {
        assertEquals(NoteFile.Word, NoteImport.kindOf("Trip.docx")); assertEquals(NoteFile.Word, NoteImport.kindOf("Trip.DOCX"))
        assertEquals(NoteFile.Text, NoteImport.kindOf("a.txt")); assertEquals(NoteFile.Text, NoteImport.kindOf("a.md"))
        assertEquals(NoteFile.Sdocx, NoteImport.kindOf("a.sdocx")); assertEquals(NoteFile.Samsung, NoteImport.kindOf("a.SDOC")); assertEquals(NoteFile.Samsung, NoteImport.kindOf("a.snb"))
        assertEquals(NoteFile.Zip, NoteImport.kindOf("a.ZIP")); assertEquals(NoteFile.Other, NoteImport.kindOf("a.pdf")); assertEquals(NoteFile.Other, NoteImport.kindOf("noext"))
        assertEquals(NoteFile.Other, NoteImport.kindOf("~\$lock.docx")); assertEquals(NoteFile.Other, NoteImport.kindOf(".hidden.txt"))
    }

    @Test fun textTitleRule() {
        val a = NoteImport.parseText("file.txt", "# Real title\nbody\nmore")!!
        assertEquals("Real title", a.title); assertEquals("body\nmore", a.body)
        val b = NoteImport.parseText("Groceries.md", "milk\r\neggs")!!
        assertEquals("Groceries", b.title); assertEquals("milk\neggs", b.body)
        assertEquals("T", NoteImport.parseText("x.txt", "﻿# T\nbody")!!.title)
        assertNull(NoteImport.parseText("empty.txt", "  \n "))
    }

    @Test fun duplicatesIgnoreCaseAndEdgeSpaces() {
        assertEquals(NoteImport.fingerprint("Trip", "a\nb"), NoteImport.fingerprint(" trip ", "A\nb\n"))
        assertNotEquals(NoteImport.fingerprint("Trip", "a"), NoteImport.fingerprint("Trip", "b"))
    }

    private val utc = java.time.ZoneOffset.UTC
    private fun at(y: Int, mo: Int, d: Int, h: Int, mi: Int, sec: Int) = java.time.LocalDateTime.of(y, mo, d, h, mi, sec).toInstant(utc).toEpochMilli()

    @Test fun samsungFileNamesGiveTheTitleAndTheTime() {
        assertEquals("Logs" to at(2026, 10, 8, 12, 23, 29), NoteImport.splitName("Logs_261008_122329.docx", utc))
        assertEquals("Lineup" to at(2026, 10, 17, 9, 35, 45), NoteImport.splitName("Lineup__261017_093545.pdf", utc))
        assertEquals("Logs" to at(2026, 10, 8, 12, 23, 29), NoteImport.splitName("Logs_261008_122329_2.docx", utc))
        assertEquals("My trip 2" to at(2026, 9, 17, 14, 26, 52), NoteImport.splitName("My trip 2_260917_142652 (1).txt", utc))
    }

    @Test fun otherNamesStayAsTheyAre() {
        assertEquals("Shopping" to null, NoteImport.splitName("Shopping.docx", utc))
        assertEquals("261008_122329" to null, NoteImport.splitName("261008_122329.docx", utc))
        assertEquals("Note_269999_999999" to null, NoteImport.splitName("Note_269999_999999.txt", utc))
        assertEquals("a_b_c" to null, NoteImport.splitName("a_b_c.md", utc))
    }

    private fun zip(vararg parts: Pair<String, ByteArray>): ByteArray {
        val bo = java.io.ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z -> for ((n, b) in parts) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bo.toByteArray()
    }

    @Test fun aZipOfNotesGivesEachNoteWithItsFolder() {
        val z = zip("one_261008_122329.txt" to "hello".toByteArray(), "Work/two.md" to "# Two\nbody".toByteArray(), "Work/pic.jpg" to byteArrayOf(1), "x.sdoc" to byteArrayOf(2), "__MACOSX/._x.txt" to byteArrayOf(3))
        val r = NoteImport.parseFile("batch.zip", z)
        assertEquals(listOf("one", "Two"), r.notes.map { it.note.title })
        assertEquals(listOf(emptyList<String>(), listOf("Work")), r.notes.map { it.folders })
        assertEquals(1, r.report.other); assertEquals(1, r.report.samsung); assertEquals(0, r.report.unreadable)
    }

    @Test fun aTextFileThatIsReallyAZipIsOpenedAsAZip() {
        val z = zip("a.txt" to "alpha".toByteArray(), "b.txt" to "beta".toByteArray())
        assertEquals(listOf("a", "b"), NoteImport.parseFile("notes.txt", z).notes.map { it.note.title })
    }

    @Test fun unreadableThingsAreCounted() {
        assertEquals(1, NoteImport.parseFile("broken.docx", byteArrayOf(1, 2, 3)).report.unreadable)
        assertEquals(1, NoteImport.parseFile("broken.zip", byteArrayOf(1, 2, 3)).report.unreadable)
        assertEquals(1, NoteImport.parseFile("empty.txt", "  ".toByteArray()).report.unreadable)
        assertEquals(1, NoteImport.parseFile("page.pdf", byteArrayOf(1)).report.other)
        assertEquals(1, NoteImport.parseFile("a.sdoc", byteArrayOf(1)).report.samsung)
        assertEquals(1, NoteImport.parseFile("a.sdocx", byteArrayOf(1)).report.unreadable)
    }

    @Test fun theTimeInTheNameBeatsTheFile() {
        val n = NoteImport.parseFile("Todo_261008_122329.txt", "x".toByteArray()).notes.single().note
        assertEquals(n.created, n.modified); assertNotEquals(null, n.created)
    }

    @Test fun boxPathDropsBlanks() { assertEquals(listOf("Work", "2020"), NoteImport.boxPath(listOf(" Work", "", "2020 "))) }

    @Test fun messages() {
        assertEquals("Imported 1 scrap.", ImportReport(added = 1).message())
        assertEquals("Imported 480 scraps. 20 were already here. 5 couldn't be read. 12 older Samsung Notes files (.sdoc, .snb) can't be read: share those notes as a Samsung Notes file (.sdocx) or a Word file instead.",
            ImportReport(480, 20, 5, 12, 0).message())
        assertEquals("Imported 0 scraps. 1 other file was skipped.", ImportReport(other = 1).message())
        assertEquals(ImportReport(3, 1, 0, 2, 0), ImportReport(1, 1, 0, 0, 0) + ImportReport(2, 0, 0, 2, 0))
    }
}
