package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TypingStyleTest {
    private fun size(n: Int?) = { a: SpanAttrs -> a.copy(size = n) }

    @Test fun plainTextGetsAnEmptySpanAtTheCursor() = assertEquals(TextEdit("hello{s:24|}", 11, 11), typingStyleAt("hello", 5, size(24)))
    @Test fun insideAWordTheSpanIsPutInTheMiddle() = assertEquals(TextEdit("he{s:24|}llo", 8, 8), typingStyleAt("hello", 2, size(24)))
    @Test fun insideASpanItIsSplitAroundTheNewLook() = assertEquals(TextEdit("{s:20|ab}{s:30|}{s:20|cd}", 15, 15), typingStyleAt("{s:20|abcd}", 8, size(30)))
    @Test fun atTheEndOfASpanTheNewLookGoesAfterIt() = assertEquals(TextEdit("{s:20|ab}{s:30|}", 15, 15), typingStyleAt("{s:20|ab}", 8, size(30)))
    @Test fun backToNormalStepsOutOfTheSpan() = assertEquals(TextEdit("{s:20|ab}", 9, 9), typingStyleAt("{s:20|ab}", 8, size(null)))
    @Test fun anEmptySpanIsChanged() = assertEquals(TextEdit("a{s:30|}", 7, 7), typingStyleAt("a{s:20|}", 7, size(30)))
    @Test fun anEmptySpanCanBeTakenAway() = assertEquals(TextEdit("a", 1, 1), typingStyleAt("a{s:20|}", 7, size(null)))
    @Test fun otherAttributesStay() = assertEquals(TextEdit("{c:ff0000 s:30|}", 15, 15), typingStyleAt("{c:ff0000|}", 10, size(30)))
    @Test fun nothingChangesNothingHappens() { assertNull(typingStyleAt("hello", 3) { it }); assertNull(typingStyleAt("hello", 3, size(null))); assertNull(typingStyleAt("{s:20|ab}", 8, size(20))) }
    @Test fun aListLineKeepsItsMark() { assertEquals(TextEdit("- item{s:24|}", 12, 12), typingStyleAt("- item", 6, size(24))); assertEquals(TextEdit("- {s:24|}item", 8, 8), typingStyleAt("- item", 0, size(24))) }
    @Test fun codeAndLinkAddressesAreLeftAlone() {
        assertNull(typingStyleAt("```\ncode\n```", 6, size(24)))
        assertNull(typingStyleAt("[a](http://x)", 6, size(24)))
        assertNull(typingStyleAt("`code`", 3, size(24)))
    }
    @Test fun otherLinesAreNotTouched() = assertEquals(TextEdit("one\ntwo{s:24|}\nthree", 13, 13), typingStyleAt("one\ntwo\nthree", 7, size(24)))

    @Test fun lookAtTheCursor() {
        assertEquals(SpanAttrs(size = 20), attrsAtCursor("{s:20|abc}", 8))
        assertEquals(SpanAttrs(size = 20), attrsAtCursor("{s:20|abc}", 9))
        assertEquals(SpanAttrs(), attrsAtCursor("{s:20|abc}", 10))
        assertEquals(SpanAttrs(color = "ff0000", underline = true), attrsAtCursor("x{c:ff0000 u|}", 13))
        assertEquals(SpanAttrs(), attrsAtCursor("plain", 2))
    }

    @Test fun enterInAnEmptySpanLiftsTheSpanOut() = assertEquals(TextEdit("ab\ncd", 3, 3), enterInEmptySpan("ab{s:24|}cd", 8))
    @Test fun enterElsewhereIsNotThisFunctionsBusiness() = assertNull(enterInEmptySpan("ab{s:24|cd}", 8))

    @Test fun enterAtTheEndOfASpanCarriesTheLook() =
        assertEquals(TextEdit("{s:24|abc}\n{s:24|}", 17, 17), carryStyleOverEnter("{s:24|abc}", 9, "{s:24|abc}\n", 11))
    @Test fun enterInAnEmptySpanCarriesIt() = assertEquals(TextEdit("ab\n{s:24|}cd", 9, 9), carryStyleOverEnter("ab{s:24|}cd", 8, "ab\ncd", 3))
    @Test fun plainTextCarriesNothing() = assertNull(carryStyleOverEnter("abc", 3, "abc\n", 4))
    @Test fun aLineThatAlreadyHasTheLookIsLeftAlone() = assertNull(carryStyleOverEnter("{s:24|abc}", 9, "{s:24|abc}\n{s:24|}", 17))
}
