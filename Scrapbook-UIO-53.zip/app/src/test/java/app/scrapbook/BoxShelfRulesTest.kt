package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BoxShelfRulesTest {
    @Test fun slimShelfIsTheLastStyleSlot() { assertEquals(7, SLIM_SHELF_STYLE) }

    @Test fun styleThatDrawNewBoxThemselves() {
        assertTrue(boxStyleDrawsOwnNewButton(4)); assertTrue(boxStyleDrawsOwnNewButton(6)); assertTrue(boxStyleDrawsOwnNewButton(SLIM_SHELF_STYLE))
        listOf(0, 1, 2, 3, 5).forEach { assertFalse("style $it", boxStyleDrawsOwnNewButton(it)) }
    }

    @Test fun seeAllOnlyWhenThereIsSomethingToSpreadOut() {
        assertFalse(showSeeAll(0)); assertFalse(showSeeAll(3)); assertTrue(showSeeAll(4)); assertTrue(showSeeAll(11))
    }

    @Test fun scrapCountIsPlainUnlessNarrowedDown() {
        assertEquals("6", scrapsHeadingCount(6, 6)); assertEquals("0", scrapsHeadingCount(0, 0))
        assertEquals("3 of 6", scrapsHeadingCount(3, 6)); assertEquals("0 of 6", scrapsHeadingCount(0, 6))
    }
}
