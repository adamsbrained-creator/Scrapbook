package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppIconTest {
    @Test fun thereAreFourIconsWithDistinctKeysAndNames() {
        assertEquals(4, AppIcon.choices.size)
        assertEquals(4, AppIcon.choices.map { it.key }.toSet().size)
        assertEquals(4, AppIcon.choices.map { it.label }.toSet().size)
        AppIcon.choices.forEach { assertTrue(it.key, it.about.isNotBlank()) }
    }

    @Test fun everyIconHasAGlassyAndANormalLauncherEntry() {
        assertEquals(8, AppIcon.aliases.size)
        assertEquals(8, AppIcon.aliases.toSet().size)
        assertEquals("IconCutoutGlassy", AppIcon.alias("Cutout", true))
        assertEquals("IconCutoutFlat", AppIcon.alias("Cutout", false))
    }

    @Test fun theGlassyWordmarkIsTheDefault() {
        assertEquals("Wordmark", AppIcon.DEFAULT_KEY)
        assertTrue(AppIcon.DEFAULT_GLASSY)
        assertEquals("IconWordmarkGlassy", AppIcon.alias(AppIcon.DEFAULT_KEY, AppIcon.DEFAULT_GLASSY))
        assertEquals(AppIcon.DEFAULT_KEY, AppIcon.choices.first().key)
    }

    @Test fun anUnknownOrMissingIconIsTheDefault() {
        assertEquals("Wordmark", AppIcon.keyOrDefault(null))
        assertEquals("Wordmark", AppIcon.keyOrDefault(""))
        assertEquals("Wordmark", AppIcon.keyOrDefault("Teal"))
        assertEquals("Sticky", AppIcon.keyOrDefault("Sticky"))
        assertEquals("IconWordmarkFlat", AppIcon.alias("nonsense", false))
    }

    @Test fun theOldAccentIconNamesAreGone() {
        listOf("Coral", "Teal", "Amber", "Violet", "Green", "Pink", "Blue").forEach { assertFalse(it, AppIcon.aliases.contains("Icon$it")) }
    }

    @Test fun theManifestHasEveryAliasAndOnlyTheDefaultStartsEnabled() {
        val manifest = java.io.File("src/main/AndroidManifest.xml").takeIf { it.exists() }?.readText() ?: return
        AppIcon.aliases.forEach { assertTrue(it, manifest.contains("android:name=\".$it\"")) }
        val enabled = Regex("""<activity-alias android:name="\.(Icon\w+)"[^>]*android:enabled="true"""").findAll(manifest).map { it.groupValues[1] }.toList()
        assertEquals(listOf(AppIcon.alias(AppIcon.DEFAULT_KEY, AppIcon.DEFAULT_GLASSY)), enabled)
    }

    @Test fun everyAliasHasItsIconResources() {
        val res = java.io.File("src/main/res").takeIf { it.exists() } ?: return
        AppIcon.choices.forEach { c ->
            listOf("glassy", "flat").forEach { style ->
                val n = "ic_${c.key.lowercase()}_$style"
                listOf("background", "foreground", "monochrome").forEach { layer -> assertTrue("$n $layer", java.io.File(res, "drawable-nodpi/${n}_$layer.png").exists()) }
                assertTrue(n, java.io.File(res, "mipmap-anydpi-v26/$n.xml").exists())
                assertTrue("${n}_round", java.io.File(res, "mipmap-anydpi-v26/${n}_round.xml").exists())
                assertTrue("preview $n", java.io.File(res, "drawable-nodpi/icon_preview_${c.key.lowercase()}_$style.png").exists())
            }
        }
    }
}
