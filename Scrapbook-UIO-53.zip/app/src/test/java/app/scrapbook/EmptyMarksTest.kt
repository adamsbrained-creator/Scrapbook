package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class EmptyMarksTest {
    @Test fun emptyBoldGoesAway() = assertEquals("" to 0, dropEmptyMarks("****", 2))
    @Test fun emptyBoldKeepsTheRestOfTheText() = assertEquals("a b" to 2, dropEmptyMarks("a ****b", 4))
    @Test fun colorInsideHighlight() = assertEquals("" to 0, dropEmptyMarks("=={c:34c759|}==", 12))
    @Test fun highlightInsideColor() = assertEquals("" to 0, dropEmptyMarks("{c:34c759|====}", 12))
    @Test fun colorSizeUnderline() = assertEquals("x" to 1, dropEmptyMarks("x{c:ff0000 s:20 u|}", 18))
    @Test fun strikeAndItalic() { assertEquals("" to 0, dropEmptyMarks("~~~~", 2)); assertEquals("" to 0, dropEmptyMarks("**", 1)) }
    @Test fun cursorNotThereLeavesItAlone() { assertNull(dropEmptyMarks("****", 0)); assertNull(dropEmptyMarks("**a**", 3)) }
    @Test fun spanWithTextIsKept() = assertNull(dropEmptyMarks("{c:34c759|a}", 11))
    @Test fun threeStarsIsNotAnEmptyItalic() = assertNull(dropEmptyMarks("***", 1))
}

class SplitMarksTest {
    private fun split(line: String, p: Int) = splitMarksAtBreak(line, line, p)
    @Test fun endOfHighlightMovesTheBreakOutside() = assertEquals("==Test==" to "", split("==Test==", 6))
    @Test fun startOfHighlightMovesTheTextDown() = assertEquals("" to "==Test==", split("==Test==", 2))
    @Test fun middleClosesAndReopens() = assertEquals("==Te==" to "==st==", split("==Test==", 4))
    @Test fun nestedMarksCloseInnerFirst() = assertEquals("**a==b==**" to "**==c==d**", split("**a==bc==d**", 6))
    @Test fun nestedAtTheEnd() = assertEquals("**==Test==**" to "", split("**==Test==**", 8))
    @Test fun colorSpan() = assertEquals("{c:34c759|a}" to "{c:34c759|bc}", split("{c:34c759|abc}", 11))
    @Test fun outsideAnythingNothingHappens() { assertNull(split("abc", 1)); assertNull(split("==a== b", 7)) }
    @Test fun starsWithSpacesAreNotItalic() = assertNull(split("2 * 3 * 4", 4))
    @Test fun listLineKeepsItsPrefix() = assertEquals("- **a**" to "**b**", split("- **ab**", 5))
    @Test fun withoutEmptyMarks() {
        assertEquals("a – b", withoutEmptyMarks("a{c:5e5ce6|} – b"))
        assertEquals("x", withoutEmptyMarks("x=={c:ff0000|}=="))
        assertEquals("plain", withoutEmptyMarks("plain"))
    }
}

class HealMarksTest {
    @Test fun deletingTheClosingEndRemovesTheOpening() = assertEquals("ad" to 1, replaceHealingMarks("**ab** cd", 3, 8, ""))
    @Test fun deletingTheOpeningEndRemovesTheClosing() = assertEquals("x b y" to 2, replaceHealingMarks("x **ab** y", 2, 5, ""))
    @Test fun contentOnlyIsLeftAlone() = assertNull(replaceHealingMarks("x **ab** y", 4, 5, ""))
    @Test fun wholeWrapperGoingIsFine() = assertNull(replaceHealingMarks("x **ab** y", 2, 8, ""))
    @Test fun colorSpan() = assertEquals("bc" to 0, replaceHealingMarks("{c:ff0000|abc}", 0, 11, ""))
    @Test fun typedOverTheSelection() = assertEquals("aXd" to 2, replaceHealingMarks("**ab** cd", 3, 8, "X"))
    @Test fun nestedHighlightInBold() = assertEquals("**ad**" to 3, replaceHealingMarks("**a==bc==d**", 5, 9, ""))
}

class WrapLinesTest {
    private val noLead = { _: String -> 0 }
    private val lead = { l: String -> if (l.startsWith("- ")) 2 else 0 }
    @Test fun twoLinesGetOnePairEach() = assertEquals(Triple("**ab**\n**cd**", 2, 11), wrapEachLine("ab\ncd", 0, 5, "**", noLead))
    @Test fun blankLinesStayEmpty() = assertEquals(Triple("==a==\n\n==b==", 2, 10), wrapEachLine("a\n\nb", 0, 4, "==", noLead))
    @Test fun listMarksStayOutside() = assertEquals(Triple("- **a**\n- **b**", 4, 13), wrapEachLine("- a\n- b", 0, 7, "**", lead))
    @Test fun halfSelectedLines() = assertEquals(Triple("ab**c**\n**d**ef", 4, 11), wrapEachLine("abc\ndef", 2, 5, "**", noLead))
    @Test fun takingTheMarksOff() = assertEquals(Triple("ab\ncd", 0, 5), wrapEachLine("**ab**\n**cd**", 2, 11, "**", noLead))
    @Test fun nothingToWrap() = assertNull(wrapEachLine("\n\n", 0, 2, "**", noLead))
    @Test fun halvesNotCutInsideBold() { assertEquals(2, balancedHalf("a b **c d** e".split(" ")).let { if (it == 2) 2 else it }) }
    @Test fun halfOfPlainWords() = assertEquals(2, balancedHalf(listOf("a", "b", "c", "d")))
    @Test fun noGoodCut() = assertEquals(-1, balancedHalf(listOf("**a", "b", "c**")))
}
