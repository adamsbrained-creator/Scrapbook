package app.scrapbook

import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EditorToolsTest {
    // ---- share and copy ----
    @Test fun sharedTextHasNoFormattingCodes() {
        val body = "# Plan\n- [ ] book **flights**\n- [x] pack\n- tea\n1. one\n> quote\n---\n[docs](https://e.com/x)\n{c:ff0000|red} text"
        assertEquals(
            "Trip\n\nPlan\n☐ book flights\n☑ pack\n• tea\n1. one\n> quote\n———\ndocs (https://e.com/x)\nred text",
            plainText("Trip", body),
        )
    }
    @Test fun indentStaysInSharedText() = assertEquals("T\n\n    • item", plainText("T", "- {i:2}item"))
    @Test fun firstLineThatRepeatsTheTitleIsDropped() = assertEquals("Groceries\n\n• milk", plainText("Groceries", "Groceries\n- milk"))
    @Test fun noTitleMeansJustTheText() = assertEquals("a\nb", plainText("", "a\nb"))
    @Test fun noTextMeansJustTheTitle() = assertEquals("T", plainText("T", ""))
    @Test fun aLinkWhoseLabelIsItsAddressIsNotRepeated() = assertEquals("https://e.com", plainText("", "[https://e.com](https://e.com)"))

    // ---- date ----
    @Test fun todayIsWrittenOut() = assertTrue(todayText(1_000_036_800_000L, Locale.US).contains("2001"))
    @Test fun insertReplacesTheSelection() {
        assertEquals(TextEdit("aXYd", 3, 3), insertAt("abcd", 1, 3, "XY"))
        assertEquals(TextEdit("a-b", 2, 2), insertAt("ab", 1, 1, "-"))
    }

    // ---- move lines ----
    @Test fun lineMovesUp() = assertEquals(TextEdit("b\na\nc", 0, 0), moveLines("a\nb\nc", 2, 2, up = true))
    @Test fun lineMovesDownAndCursorFollows() = assertEquals(TextEdit("b\na\nc", 3, 3), moveLines("a\nb\nc", 1, 1, up = false))
    @Test fun firstLineCannotGoUpAndLastCannotGoDown() {
        assertNull(moveLines("a\nb", 0, 0, up = true))
        assertNull(moveLines("a\nb", 3, 3, up = false))
    }
    @Test fun selectedLinesMoveTogether() = assertEquals(TextEdit("b\nc\na\nd", 0, 3), moveLines("a\nb\nc\nd", 2, 5, up = true))
    @Test fun selectionEndingAtTheStartOfALineLeavesThatLineOut() = assertEquals(TextEdit("b\na\nc", 2, 3), moveLines("a\nb\nc", 0, 2, up = false))
    @Test fun numbersStayInPlaceInANumberedList() = assertEquals(TextEdit("1. b\n2. a\n3. c", 3, 3), moveLines("1. a\n2. b\n3. c", 5, 5, up = true))

    // ---- checklists ----
    private val list = "- [ ] a\n- [x] b\n- [ ] c\n- [x] d"
    @Test fun countsItemsAndTicks() = assertEquals(4 to 2, checklistCounts(list))
    @Test fun tickedItemsGoToTheBottomInOrder() = assertEquals(TextEdit("- [ ] a\n- [ ] c\n- [x] b\n- [x] d", 0, 0), applyChecklist(list, 0, CheckAction.TickedToBottom))
    @Test fun tickedItemsCanBeCleared() = assertEquals(TextEdit("- [ ] a\n- [ ] c", 0, 0), applyChecklist(list, 0, CheckAction.ClearTicked))
    @Test fun everythingCanBeUnticked() = assertEquals(TextEdit("- [ ] a\n- [ ] b\n- [ ] c\n- [ ] d", 0, 0), applyChecklist(list, 0, CheckAction.UntickAll))
    @Test fun nothingToDoGivesNull() {
        assertNull(applyChecklist("- [ ] a\n- [x] b", 0, CheckAction.TickedToBottom))
        assertNull(applyChecklist("just text", 0, CheckAction.UntickAll))
    }
    @Test fun onlyTheListUnderTheCursorIsTidied() = assertEquals(TextEdit("\n- [x] b", 0, 0), applyChecklist("- [x] a\n\n- [x] b", 0, CheckAction.ClearTicked))
    @Test fun cursorOutsideAnyListTidiesEveryList() = assertEquals(TextEdit("\nplain\n", 0, 0), applyChecklist("- [x] a\n\nplain\n\n- [x] b", 10, CheckAction.ClearTicked))

    // ---- find and replace ----
    @Test fun plainTextMatchesAreAllFound() = assertEquals(listOf(0..2, 4..6, 8..10), visibleOccurrences("Red red RED", "red", { it }, "Red red RED"))
    @Test fun marksAroundAMatchDoNotHideIt() {
        // "**bold** x" is shown as "bold x"; the two stars on each side take no room.
        val toShown = { i: Int -> when { i <= 2 -> 0; i <= 6 -> i - 2; i <= 8 -> 4; else -> i - 4 } }
        assertEquals(listOf(2..5), visibleOccurrences("**bold** x", "bold", toShown, "bold x"))
    }
    @Test fun hiddenCodesAreNeverMatched() {
        // "{c:ff0000|red}" is shown as "red": the color code takes no room.
        val toShown = { i: Int -> when { i <= 10 -> 0; i <= 13 -> i - 10; else -> 3 } }
        assertEquals(emptyList<IntRange>(), visibleOccurrences("{c:ff0000|red}", "ff", toShown, "red"))
        assertEquals(listOf(10..12), visibleOccurrences("{c:ff0000|red}", "red", toShown, "red"))
    }
    @Test fun rangesAreReplacedFromTheEnd() {
        assertEquals("a X X", replaceRanges("a red red", listOf(2..4, 6..8), "X"))
        assertEquals("a longer longer", replaceRanges("a red red", listOf(6..8, 2..4), "longer"))
    }

    // ---- font sizes ----
    @Test fun fontSizeListRunsFrom6To64() {
        assertEquals(6, FONT_SIZES.first()); assertEquals(64, FONT_SIZES.last())
        assertEquals(FONT_SIZES.sorted(), FONT_SIZES); assertEquals(FONT_SIZES.distinct(), FONT_SIZES)
        assertTrue(17 in FONT_SIZES); assertEquals(38, FONT_SIZES.size)
        assertEquals(listOf(48, 52, 56, 60, 64), FONT_SIZES.takeLast(5))
    }

    // ---- font colors typed, pasted and remembered ----
    @Test fun hexColorsAreRecognised() {
        assertEquals("ff8800", parseColorText("#FF8800")); assertEquals("ff8800", parseColorText("ff8800")); assertEquals("ff8800", parseColorText("0xff8800"))
        assertEquals("ff8800", parseColorText("#f80")); assertEquals("123456", parseColorText("123456"))
    }
    @Test fun rgbColorsAreRecognised() {
        assertEquals("ff8800", parseColorText("rgb(255, 136, 0)")); assertEquals("ff8800", parseColorText("255,136,0")); assertEquals("ff8800", parseColorText("255 136 0"))
        assertEquals("ff8800", parseColorText(" 255 , 136 , 0 ")); assertEquals("0a141e", parseColorText("RGB(10,20,30)"))
    }
    @Test fun thingsThatAreNotColorsAreRefused() {
        for (bad in listOf("rgb(300,0,0)", "12345", "red", "#ff88", "", "f80", "255", "1,2", "#gg0000", "255,136,0,5")) assertNull(bad, parseColorText(bad))
    }
    @Test fun hexAndRgbNumbersConvert() {
        assertEquals(0xFF8800, hexToRgb("ff8800")); assertEquals("ff8800", rgbToHex(0xFF8800)); assertEquals("0a84ff", rgbToHex(0x0A84FF)); assertEquals("000000", rgbToHex(0))
    }
    @Test fun recentColorsKeepTheNewestFirst() {
        assertEquals(listOf("bbbbbb", "aaaaaa"), addRecentColor(listOf("aaaaaa"), "BBBBBB"))
        assertEquals(listOf("aaaaaa", "bbbbbb"), addRecentColor(listOf("bbbbbb", "aaaaaa"), "aaaaaa"))
    }
    @Test fun recentColorsIgnoreNonColorsAndStopAtTheLimit() {
        assertEquals(listOf("aaaaaa"), addRecentColor(listOf("aaaaaa"), "red")); assertEquals(listOf("aaaaaa"), addRecentColor(listOf("aaaaaa"), "#fff"))
        var l = emptyList<String>()
        for (i in 1..9) l = addRecentColor(l, "00000$i")
        assertEquals(MAX_RECENT_COLORS, l.size); assertEquals("000009", l.first())
    }
    @Test fun savedRecentColorsRoundTrip() {
        val l = listOf("aaaaaa", "0a84ff")
        assertEquals(l, parseRecentColors(encodeRecentColors(l)))
        assertEquals(listOf("aaaaaa", "bbbbbb"), parseRecentColors("AAAAAA\nnot\n\nbbbbbb")); assertEquals(emptyList<String>(), parseRecentColors(null))
    }

    // ---- lists on every selected line ----
    private fun lines(text: String, a: Int, b: Int, p: String) = toggleLines(text, a, b, p)
    @Test fun oneLineJustGetsTheMark() { val r = lines("milk", 2, 2, "- "); assertEquals("- milk", r.text); assertEquals(4, r.start) }
    @Test fun everySelectedLineGetsTheBullet() {
        val t = "milk\neggs\nbread"; val r = lines(t, 0, t.length, "- ")
        assertEquals("- milk\n- eggs\n- bread", r.text); assertEquals(0, r.start); assertEquals(r.text.length, r.end)
    }
    @Test fun tappingAgainTakesItOffEveryLine() {
        val t = "milk\neggs\nbread"; val on = lines(t, 0, t.length, "- ")
        assertEquals(t, lines(on.text, on.start, on.end, "- ").text)
    }
    @Test fun checklistOnAllLines() = assertEquals("- [ ] a\n- [ ] b", lines("a\nb", 0, 3, "- [ ] ").text)
    @Test fun numbersCountUp() = assertEquals("1. a\n2. b\n3. c", lines("a\nb\nc", 0, 5, "1. ").text)
    @Test fun numbersAreRedoneWhenSomeLinesAlreadyHaveThem() = assertEquals("1. a\n2. b\n3. c", lines("a\n7. b\nc", 0, 9, "1. ").text)
    @Test fun otherMarksAreSwitched() = assertEquals("- [ ] a\n- [ ] b\n- [ ] c", lines("- a\n1. b\nc", 0, 11, "- [ ] ").text)
    @Test fun aTickedLineKeepsItsTickWhenOthersJoinTheChecklist() = assertEquals("- [x] a\n- [ ] b", lines("- [x] a\nb", 0, 9, "- [ ] ").text)
    @Test fun allChecklistLinesEvenTickedOnesLoseTheMark() = assertEquals("a\nb", lines("- [x] a\n- [ ] b", 0, 15, "- [ ] ").text)
    @Test fun blankLinesStayBlankInASelection() = assertEquals("- a\n\n- b", lines("a\n\nb", 0, 4, "- ").text)
    @Test fun aSelectionEndingAtTheStartOfALineLeavesThatLineAlone() = assertEquals("- a\n- b\nc", lines("a\nb\nc", 0, 4, "- ").text)
    @Test fun onlyTheTouchedLinesChange() = assertEquals("a\n> b\n> c\nd", lines("a\nb\nc\nd", 3, 5, "> ").text)
    @Test fun codeBlocksAreLeftAlone() = assertEquals("- a\n```\nb\n```\n- c", lines("a\n```\nb\n```\nc", 0, 15, "- ").text)
    @Test fun theIndentOfALineSurvives() = assertEquals("- {i:1}a", lines("{i:1}a", 0, 0, "- ").text.let { it })
    @Test fun headingsApplyToEveryLine() = assertEquals("## a\n## b", lines("a\nb", 0, 3, "## ").text)

    // ---- quick tools ----
    @Test fun duplicateCopiesTheLineBelowItAndMovesOnto() {
        val r = duplicateLines("a\nbb\nc", 3, 3); assertEquals("a\nbb\nbb\nc", r.text); assertEquals(6, r.start)
    }
    @Test fun duplicateCopiesEverySelectedLine() {
        val r = duplicateLines("a\nb\nc", 0, 3); assertEquals("a\nb\na\nb\nc", r.text); assertEquals(4, r.start); assertEquals(7, r.end)
    }
    @Test fun duplicateOfTheLastLine() = assertEquals("a\nb\nb", duplicateLines("a\nb", 3, 3).text)
    @Test fun deleteTakesTheLineAndItsBreak() { val r = deleteLines("a\nb\nc", 3, 3)!!; assertEquals("a\nc", r.text); assertEquals(2, r.start) }
    @Test fun deleteOfTheLastLineTakesTheBreakBefore() = assertEquals("a\nb", deleteLines("a\nb\nc", 5, 5)!!.text)
    @Test fun deleteOfSeveralLines() = assertEquals("d", deleteLines("a\nb\nc\nd", 0, 5)!!.text)
    @Test fun deleteOfTheOnlyLineLeavesNothing() = assertEquals("", deleteLines("abc", 1, 1)!!.text)
    @Test fun deleteOfNothingIsNothing() = assertNull(deleteLines("", 0, 0))
    @Test fun sortedAToZ() = assertEquals("apple\nbanana\ncherry", sortLines("cherry\napple\nbanana", 0, 20, true)!!.text)
    @Test fun sortedZToAIgnoringCapitals() = assertEquals("pear\nBanana\napple", sortLines("apple\nBanana\npear", 0, 18, false)!!.text)
    @Test fun sortingLooksPastTheMarks() = assertEquals("- [ ] a\n- [ ] b\n- [x] c", sortLines("- [x] c\n- [ ] a\n- [ ] b", 0, 23, true)!!.text)
    @Test fun aSortedNumberedListIsNumberedAgain() = assertEquals("1. a\n2. b\n3. c", sortLines("1. c\n2. a\n3. b", 0, 14, true)!!.text)
    @Test fun oneLineCannotBeSorted() = assertNull(sortLines("b", 0, 0, true))
    @Test fun alreadySortedChangesNothing() = assertNull(sortLines("a\nb", 0, 3, true))
    @Test fun blankLinesGoFromTheWholeTextWhenNothingIsSelected() = assertEquals("a\nb\nc", removeBlankLines("a\n\nb\n\n\nc", 0, 0)!!.text)
    @Test fun blankLinesGoOnlyFromTheSelection() = assertEquals("a\n\nb\nc", removeBlankLines("a\n\nb\n\nc", 3, 8)!!.text)
    @Test fun noBlankLinesNoChange() = assertNull(removeBlankLines("a\nb", 0, 0))
    @Test fun capitals() = assertEquals("hello WORLD", changeCase("hello world", 6, 11, CaseChange.Upper)!!.text)
    @Test fun smallLetters() = assertEquals("Hello world", changeCase("Hello WORLD", 6, 11, CaseChange.Lower)!!.text)
    @Test fun capitalOnEveryWord() = assertEquals("The quick Brown Fox", changeCase("The quick brown fox", 10, 19, CaseChange.Title)!!.text)
    @Test fun titleCaseKeepsApostrophes() = assertEquals("Don't Stop", changeCase("dON'T sTOP", 0, 10, CaseChange.Title)!!.text)
    @Test fun nothingSelectedNothingChanged() = assertNull(changeCase("abc", 1, 1, CaseChange.Upper))
    @Test fun colorCodesAndLinkAddressesAreNotChanged() {
        val t = "{c:ff00aa|red} see [docs](https://e.com/a)"
        assertEquals("{c:ff00aa|RED} SEE [DOCS](https://e.com/a)", changeCase(t, 0, t.length, CaseChange.Upper)!!.text)
    }
    @Test fun statsCountWhatIsShown() {
        val s = textStats("# Plan\n- [ ] buy **milk**\n\n- eggs"); assertEquals(4, s.words); assertEquals(3, s.lines)
    }
    @Test fun statsSayOneWord() = assertEquals("1 word · 1 character · 1 line", TextStats(1, 1, 1).say())
    @Test fun tickAllChecksEveryItem() = assertEquals("- [x] a\n- [x] b", applyChecklist("- [ ] a\n- [x] b", 0, CheckAction.TickAll)!!.text)
    @Test fun timeAndDateTimeAreWritten() {
        assertTrue(timeText(1_000_036_800_000L, Locale.US).contains(":"))
        assertTrue(dateTimeText(1_000_036_800_000L, Locale.US).contains("2001"))
    }
}
