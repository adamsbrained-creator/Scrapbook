package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Builds .sdocx files the way Samsung Notes 4.4 writes them (format 4000), so the reader can be tested without a note of anybody's. */
class SdocxReaderTest {
    private class W { val o = ByteArrayOutputStream()
        fun u8(v: Int) = apply { o.write(v) }
        fun u16(v: Int) = apply { o.write(v and 255); o.write(v shr 8 and 255) }
        fun u32(v: Long) = apply { for (i in 0..3) o.write((v shr (8 * i) and 255).toInt()) }
        fun u32(v: Int) = u32(v.toLong() and 0xFFFFFFFFL)
        fun i64(v: Long) = apply { for (i in 0..7) o.write((v shr (8 * i) and 255).toInt()) }
        fun raw(b: ByteArray) = apply { o.write(b) }
        fun utf16(s: String) = raw(s.toByteArray(Charsets.UTF_16LE))
        fun bytes() = o.toByteArray() }

    /** One typed frame: size, type, where the flexible data starts, a property mask and a field mask, then the fixed and the flexible data. */
    private fun frame(kind: Int, fields: ByteArray = byteArrayOf(0), fixed: ByteArray = ByteArray(0), flex: ByteArray = ByteArray(0)): ByteArray {
        val headerLen = 2 + 4 + 1 + 1 + 1 + fields.size
        val data = W().u16(kind).u32(4 + headerLen + fixed.size).u8(1).u8(0).u8(fields.size).raw(fields).raw(fixed).raw(flex).bytes()
        return W().u32(data.size + 4).raw(data).bytes()
    }

    private class S(val kind: Int, val a: Int, val b: Int, val payload: ByteArray)
    private class P(val kind: Int, val a: Int, val b: Int, val payload: ByteArray)

    private fun u16le(v: Int) = byteArrayOf((v and 255).toByte(), (v shr 8).toByte())
    private fun u32le(v: Int) = W().u32(v).bytes()

    private fun textObject(text: String, spans: List<S> = emptyList(), paras: List<P> = emptyList(), objects: List<Pair<Int, ByteArray>> = emptyList()): ByteArray {
        val c = W().u32(text.length).utf16(text).u32(spans.size)
        for (s in spans) { val rec = W().u32(s.kind).u32(s.a).u32(s.b).u32(1).raw(s.payload).bytes(); c.u16(rec.size).raw(rec) }
        c.u32(paras.size)
        for (p in paras) { val rec = W().u32(p.kind).u32(p.a).u32(p.b).raw(p.payload).bytes(); c.u16(rec.size).raw(rec) }
        c.raw(ByteArray(16)).u8(0).u16(0).u32(if (objects.isEmpty()) 0 else 1).u32(0)
        if (objects.isNotEmpty()) {
            c.u32(objects.size)
            for ((index, data) in objects) { val sp = W().u32(data.size).u32(3).raw(data).u32(index).bytes(); c.u32(sp.size).raw(sp) }
        }
        val common = c.bytes()
        return frame(0).plus(frame(6)).plus(frame(7, byteArrayOf(1), flex = W().u32(common.size).raw(common).bytes()))
    }

    private fun imageObject(mediaId: Int): ByteArray {
        val fill = W().u8(0).u32(mediaId).bytes()
        val flex = W().u32(fill.size).u8(2).raw(fill).bytes()
        return frame(0).plus(frame(6)).plus(frame(7, byteArrayOf(0x20), flex = flex)).plus(frame(3))
    }

    private fun note(title: String, body: ByteArray, created: Long = 0, modified: Long = 0): ByteArray {
        val t = textObject(title)
        return W().u32(0).u8(1).u8(0).u8(1).u8(0).u32(4000).u16(0).u32(1).i64(created).i64(modified).u32(0).u32(0).u32(0).u32(0).u32(0)
            .u32(t.size).raw(t).u32(body.size).raw(body).raw(ByteArray(32)).bytes()
    }

    private fun sdocx(note: ByteArray, media: Map<String, ByteArray> = emptyMap()): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            z.putNextEntry(ZipEntry("note.note")); z.write(note); z.closeEntry()
            for ((n, b) in media) { z.putNextEntry(ZipEntry("media/$n")); z.write(b); z.closeEntry() }
        }
        return bo.toByteArray()
    }

    private fun read(body: ByteArray, title: String = "T", media: Map<String, ByteArray> = emptyMap(), created: Long = 0, modified: Long = 0) =
        SdocxReader.read(sdocx(note(title, body, created, modified), media), "file name")

    private val on = u16le(1); private val off = u16le(0)

    @Test fun plainTextAndTitle() {
        val n = read(textObject("first\nsecond"), title = "My note")!!
        assertEquals("My note", n.title); assertEquals("first\nsecond", n.body)
    }

    @Test fun aNoteWithoutATitleUsesTheFileName() { assertEquals("file name", read(textObject("x"), title = "")!!.title) }

    @Test fun datesAreMicrosecondsAndZeroMeansNone() {
        val n = read(textObject("x"), created = 1_789_571_730_961_064L, modified = 1_789_657_306_627_132L)!!
        assertEquals(1_789_571_730_961L, n.created); assertEquals(1_789_657_306_627L, n.modified)
        val m = read(textObject("x"))!!
        assertNull(m.created); assertNull(m.modified)
    }

    @Test fun boldItalicUnderlineStrikeAndColor() {
        val text = "aa bb cc dd ee ff"
        val spans = listOf(S(5, 3, 5, on), S(6, 6, 8, on), S(7, 9, 11, on), S(20, 12, 14, on), S(1, 15, 17, byteArrayOf(0x1e, 0x88.toByte(), 0xe5.toByte(), 0xff.toByte())))
        // the color payload is little-endian ARGB: bytes B, G, R, A
        val body = read(textObject(text, spans))!!.body
        assertEquals("aa **bb** *cc* {u|dd} ~~ee~~ {c:e5881e|ff}", body)
    }

    @Test fun ordinaryInkIsNotAColor() {
        val dark = byteArrayOf(0x25, 0x25, 0x25, 0xff.toByte()); val light = byteArrayOf(0xd9.toByte(), 0xd9.toByte(), 0xd9.toByte(), 0xff.toByte())
        assertEquals("abcd", read(textObject("abcd", listOf(S(1, 0, 2, dark), S(1, 2, 4, light))))!!.body)
    }

    @Test fun aSpanSwitchedOffAfterwardsIsOff() {
        assertEquals("ab **c**d", read(textObject("ab cd", listOf(S(5, 0, 4, on), S(5, 0, 3, off), S(5, 4, 5, off))))!!.body)
    }

    @Test fun numberedBulletedAndCheckboxLines() {
        val body = textObject("one\ntwo\nthree\nfour\nfive", paras = listOf(
            P(5, 0, 1, W().u32(4).u32(1).bytes()), P(5, 1, 2, W().u32(4).u32(2).bytes()),
            P(5, 2, 3, W().u32(8).u32(0).u32(0).bytes()),
            P(5, 3, 4, W().u32(2).u32(0).u32(0).bytes()), P(5, 4, 5, W().u32(2).u32(0).u32(1).bytes())))
        assertEquals("1. one\n2. two\n- three\n- [ ] four\n- [x] five", read(body)!!.body)
    }

    @Test fun headingsIndentAndAlignment() {
        val body = textObject("Big\nSmall\nplain\ncentre\nright\nnested", paras = listOf(
            P(10, 0, 1, W().u32(0).u32(3).bytes()), P(10, 1, 2, W().u32(1).u32(3).bytes()), P(10, 2, 3, W().u32(3).u32(3).bytes()),
            P(3, 3, 4, W().u32(2).u32(0).bytes()), P(3, 4, 5, W().u32(1).u32(0).bytes()),
            P(5, 5, 6, W().u32(8).u32(0).u32(0).bytes()), P(2, 5, 6, W().u32(2).u32(0).bytes())))
        assertEquals("# Big\n## Small\nplain\n{a:c}centre\n{a:r}right\n- {i:2}nested", read(body)!!.body)
    }

    @Test fun linksNeedHttp() {
        fun link(url: String) = W().u32(0).u32(0).u32(url.length).utf16(url).bytes()
        assertEquals("go [site](https://example.com/a) now", read(textObject("go site now", listOf(S(9, 3, 7, link("https://example.com/a")))))!!.body)
        assertEquals("go site now", read(textObject("go site now", listOf(S(9, 3, 7, link("javascript:alert(1)")))))!!.body)
        assertEquals("[https://a.org/x](https://a.org/x)", read(textObject("https://a.org/x", listOf(S(9, 0, 15, link("")))))!!.body)
    }

    @Test fun picturesFollowTheTextAndThePageCopyIsLeftOut() {
        val body = textObject("a￼\nb￼", objects = listOf(1 to imageObject(7), 4 to imageObject(3)))
        val media = mapOf("3@files_x.png" to byteArrayOf(3), "7@files_y.jpg" to byteArrayOf(7), "9@page_0000001.spi" to byteArrayOf(9), "5@files_z.jpeg" to byteArrayOf(5), "6@page_000.png" to byteArrayOf(6))
        val n = read(body, media = media)!!
        assertEquals("a\nb", n.body)
        assertEquals(listOf("files_y.jpg", "files_x.png", "files_z.jpeg"), n.images.map { it.name })   // in the text, then the others by number
        assertEquals(listOf("jpg", "png", "jpg"), n.images.map { it.extension })
    }

    @Test fun aNoteOfOnlyAPictureIsKept() {
        val n = read(textObject("￼"), media = mapOf("0@files_a.png" to byteArrayOf(1)))!!
        assertEquals("", n.body); assertEquals(1, n.images.size)
    }

    @Test fun anEmptyNoteIsNothing() { assertNull(read(textObject("\n\n"))) }

    @Test fun blankRunsAreShortenedAndEdgesTrimmed() {
        assertEquals("a\n\n\nb", read(textObject("\n\n\n\na\n\n\n\n\n\nb\n\n\n"))!!.body)
    }

    @Test fun garbageIsNothing() {
        assertNull(SdocxReader.read(byteArrayOf(1, 2, 3), "x"))
        assertNull(SdocxReader.read(sdocx(byteArrayOf(1, 2, 3, 4)), "x"))
    }

    @Test fun brokenParagraphDataKeepsTheText() {
        // the text is complete, but the data after it is cut short
        val c = W().u32(3).utf16("abc").u32(2).bytes()
        val body = frame(0).plus(frame(6)).plus(frame(7, byteArrayOf(1), flex = W().u32(c.size).raw(c).bytes()))
        assertEquals("abc", read(body)!!.body)
    }

    @Test fun theImporterReadsItAndTheNameGivesTheTitleWhenTheNoteHasNone() {
        val r = NoteImport.parseFile("Trip _261008_122329.sdocx", sdocx(note("", textObject("hello"), 1_789_571_730_961_064L)))
        val n = r.notes.single().note
        assertEquals("Trip", n.title); assertEquals(1_789_571_730_961L, n.created); assertNotNull(n.modified)
    }
}
