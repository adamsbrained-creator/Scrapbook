package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinScheduleTest {
    private val ids = setOf("classic", "night", "day", "other")
    private val night = ScheduleRule("r1", "night", 21 * 60, 7 * 60)            // 21:00 to 07:00, every day
    private val work = ScheduleRule("r2", "day", 9 * 60, 17 * 60, 0b0011111)     // 09:00 to 17:00, Monday to Friday

    private fun at(h: Int, m: Int = 0) = h * 60 + m

    @Test fun aWindowDuringTheDayCoversItsHoursOnItsDaysOnly() {
        assertTrue(work.covers(at(9), 0))
        assertTrue(work.covers(at(16, 59), 4))
        assertFalse(work.covers(at(17), 0))
        assertFalse(work.covers(at(8, 59), 0))
        assertFalse(work.covers(at(12), 5))
        assertFalse(work.covers(at(12), 6))
    }

    @Test fun aWindowThroughTheNightCoversBothSidesOfMidnight() {
        assertTrue(night.covers(at(21), 2))
        assertTrue(night.covers(at(23, 59), 2))
        assertTrue(night.covers(at(0), 3))
        assertTrue(night.covers(at(6, 59), 3))
        assertFalse(night.covers(at(7), 3))
        assertFalse(night.covers(at(12), 3))
    }

    @Test fun aNightWindowBelongsToTheDayItStartedOn() {
        val fri = ScheduleRule("f", "night", at(22), at(6), 0b0010000)       // Friday nights only
        assertTrue(fri.covers(at(23), 4))
        assertTrue(fri.covers(at(3), 5))      // the small hours of Saturday
        assertFalse(fri.covers(at(3), 4))     // the small hours of Friday belong to Thursday night
        assertFalse(fri.covers(at(23), 5))
        val sun = ScheduleRule("s", "night", at(22), at(6), 0b1000000)       // Sunday nights run into Monday
        assertTrue(sun.covers(at(3), 0))
    }

    @Test fun theSameStartAndEndIsTheWholeDayOnItsDays() {
        val all = ScheduleRule("a", "day", at(8), at(8), 0b0000001)
        assertTrue(all.covers(at(3), 0))
        assertTrue(all.covers(at(23, 59), 0))
        assertFalse(all.covers(at(12), 1))
    }

    @Test fun theFirstRuleThatIsOnIsTheActiveOne() {
        val s = SkinSchedule(listOf(night, work))
        assertEquals("r2", s.active(at(10), 1)?.id)
        assertEquals("r1", s.active(at(22), 1)?.id)
        assertNull(s.active(at(18), 1))
    }

    @Test fun goingIntoAWindowPutsItsSkinOnAndRemembersTheOne() {
        val r = SkinSchedule(listOf(night)).step(at(22), 1, "classic", ids)
        assertEquals("night", r.wear)
        assertEquals("r1", r.schedule.lastRule)
        assertEquals("classic", r.schedule.restore)
    }

    @Test fun stayingInTheSameWindowChangesNothingEvenIfYouWearAnotherSkin() {
        val s = SkinSchedule(listOf(night), "r1", "classic")
        val r = s.step(at(23), 1, "other", ids)
        assertNull(r.wear)
        assertEquals(s, r.schedule)
    }

    @Test fun goingOutOfEveryWindowPutsTheRememberedSkinBack() {
        val s = SkinSchedule(listOf(night), "r1", "classic")
        val r = s.step(at(8), 1, "night", ids)
        assertEquals("classic", r.wear)
        assertNull(r.schedule.lastRule)
        assertNull(r.schedule.restore)
    }

    @Test fun movingFromOneWindowIntoAnotherKeepsWhatWasRemembered() {
        val a = ScheduleRule("a", "night", at(18), at(21))
        val b = ScheduleRule("b", "day", at(21), at(23))
        val s = SkinSchedule(listOf(a, b), "a", "classic")
        val r = s.step(at(21), 0, "night", ids)
        assertEquals("day", r.wear)
        assertEquals("b", r.schedule.lastRule)
        assertEquals("classic", r.schedule.restore)
    }

    @Test fun aSkinThatIsAlreadyWornIsNotPutOnAgain() {
        val r = SkinSchedule(listOf(night)).step(at(22), 1, "night", ids)
        assertNull(r.wear)
        assertEquals("r1", r.schedule.lastRule)
        assertEquals("night", r.schedule.restore)
    }

    @Test fun aRuleForADeletedSkinPutsNothingOnButIsStillRemembered() {
        val r = SkinSchedule(listOf(ScheduleRule("g", "gone", at(20), at(23)))).step(at(21), 0, "classic", ids)
        assertNull(r.wear)
        assertEquals("g", r.schedule.lastRule)
    }

    @Test fun aRememberedSkinThatNoLongerExistsIsNotPutBack() {
        val s = SkinSchedule(listOf(night), "r1", "deleted")
        val r = s.step(at(8), 1, "night", ids)
        assertNull(r.wear)
        assertNull(r.schedule.lastRule)
    }

    @Test fun aRuleDeletedWhileItsWindowWasOnPutsTheRememberedSkinBack() {
        val s = SkinSchedule(emptyList(), null, "classic")
        val r = s.step(at(23), 1, "night", ids)
        assertEquals("classic", r.wear)
        assertNull(r.schedule.restore)
    }

    @Test fun withNoRulesAndNothingRememberedThereIsNothingToDo() {
        val s = SkinSchedule()
        assertTrue(s.isIdle)
        val r = s.step(at(12), 1, "classic", ids)
        assertNull(r.wear)
        assertEquals(s, r.schedule)
        assertFalse(SkinSchedule(listOf(night)).isIdle)
        assertFalse(SkinSchedule(emptyList(), null, "x").isIdle)
    }

    @Test fun aFullDayThroughTheClock() {
        var s = SkinSchedule(listOf(night, work))
        var worn = "classic"
        fun tick(h: Int, day: Int = 1) { val r = s.step(at(h), day, worn, ids); r.wear?.let { worn = it }; s = r.schedule }
        tick(8); assertEquals("classic", worn)
        tick(9); assertEquals("day", worn)
        tick(12); assertEquals("day", worn)
        tick(17); assertEquals("classic", worn)
        tick(21); assertEquals("night", worn)
        tick(2, 2); assertEquals("night", worn)
        tick(7, 2); assertEquals("classic", worn)
    }

    @Test fun timeAndDayTextsAreReadable() {
        assertEquals("21:30", SkinSchedule.timeText(21 * 60 + 30))
        assertEquals("0:00", SkinSchedule.timeText(0))
        assertEquals("7:05", SkinSchedule.timeText(425))
        assertEquals("0:00", SkinSchedule.timeText(1440))
        assertEquals("Every day", SkinSchedule.daysText(127))
        assertEquals("Weekdays", SkinSchedule.daysText(0b0011111))
        assertEquals("Weekends", SkinSchedule.daysText(0b1100000))
        assertEquals("Mon, Wed", SkinSchedule.daysText(0b0000101))
    }

    @Test fun theScheduleIsSavedAndReadBackTheSame() {
        val s = SkinSchedule(listOf(night, work), "r2", "classic")
        assertEquals(s, SkinSchedule.decode(s.encode()))
        val plain = SkinSchedule(listOf(work))
        assertEquals(plain, SkinSchedule.decode(plain.encode()))
        assertEquals("", SkinSchedule().encode())
    }

    @Test fun unreadableSavedTextIsAnEmptySchedule() {
        assertEquals(SkinSchedule(), SkinSchedule.decode(null))
        assertEquals(SkinSchedule(), SkinSchedule.decode(""))
        assertEquals(SkinSchedule(), SkinSchedule.decode("garbage\nR|x\nR|a|b|c|d|e\nS"))
    }

    @Test fun savedRulesAreBroughtIntoRange() {
        val d = SkinSchedule.decode("R|a|night|-50|99999|0\nR|a|day|60|120|127\nR||x|1|2|3\nR|b||1|2|3\n")
        assertEquals(1, d.rules.size)
        assertEquals(ScheduleRule("a", "night", 0, 1439, 127), d.rules[0])
    }

    @Test fun atMostSixRulesAreKept() {
        val text = (1..9).joinToString("\n") { "R|r$it|night|60|120|127" }
        assertEquals(ScheduleRule.MAX_RULES, SkinSchedule.decode(text).rules.size)
    }

    @Test fun aRememberedRuleThatIsGoneIsForgottenWhenRead() {
        val d = SkinSchedule.decode("R|a|night|60|120|127\nS|ghost|classic\n")
        assertNull(d.lastRule)
        assertEquals("classic", d.restore)
    }
}
