package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NavSwipesTest {
    private fun plan(route: String?, back: Boolean = true, swipeBack: Boolean = true, tabs: Boolean = false) = NavSwipes.plan(route, back, swipeBack, tabs)

    @Test fun routesAreNamedByTheirFirstPart() {
        assertEquals("shelf", NavSwipes.name("shelf/{name}")); assertEquals("edit", NavSwipes.name("edit/12")); assertEquals("home", NavSwipes.name("home")); assertNull(NavSwipes.name(null))
    }

    @Test fun mainPagesAreTheFourInOrder() {
        assertEquals(listOf("home", "scraps", "collections", "settings"), NavSwipes.MAIN_PAGES)
        assertTrue(NavSwipes.isMain("home")); assertTrue(NavSwipes.isMain("settings")); assertFalse(NavSwipes.isMain("shelf/{name}")); assertFalse(NavSwipes.isMain("search")); assertFalse(NavSwipes.isMain(null))
    }

    @Test fun neighboursStopAtTheEnds() {
        assertEquals("scraps", NavSwipes.neighbour("home", 1)); assertNull(NavSwipes.neighbour("home", -1))
        assertEquals("collections", NavSwipes.neighbour("scraps", 1)); assertEquals("home", NavSwipes.neighbour("scraps", -1))
        assertEquals("collections", NavSwipes.neighbour("settings", -1)); assertNull(NavSwipes.neighbour("settings", 1)); assertNull(NavSwipes.neighbour("shelf/{name}", 1))
    }

    @Test fun swipeRightGoesBackWhenThereIsAPageBefore() {
        assertEquals(SwipeMove.Back, plan("shelf/{name}").right); assertNull(plan("shelf/{name}").left)
        assertEquals(SwipeMove.Back, plan("settings").right)
    }

    @Test fun nothingToGoBackToMeansNothing() {
        assertTrue(plan("home", back = false).isEmpty); assertTrue(plan("shelf/{name}", back = false).isEmpty)
    }

    @Test fun backSwitchedOffMeansNoBackSwipe() {
        assertTrue(plan("shelf/{name}", swipeBack = false).isEmpty); assertTrue(plan("search", swipeBack = false).isEmpty)
    }

    @Test fun mainPagesSwipeBetweenEachOtherWhenSwitchedOn() {
        assertEquals(SwipePlan(SwipeMove.Main("home"), SwipeMove.Main("collections")), plan("scraps", tabs = true))
        assertEquals(SwipePlan(null, SwipeMove.Main("scraps")), plan("home", tabs = true))
        assertEquals(SwipePlan(SwipeMove.Main("collections"), null), plan("settings", tabs = true))
    }

    @Test fun onAMainPageTheTabSwipeTakesTheRightSwipeFromBack() {
        assertNull(plan("home", back = true, tabs = true).right)
        assertEquals(SwipeMove.Main("home"), plan("scraps", back = true, tabs = true).right)
    }

    @Test fun otherPagesKeepBackWhenTabsAreOn() {
        assertEquals(SwipeMove.Back, plan("shelf/{name}", tabs = true).right); assertNull(plan("shelf/{name}", tabs = true).left)
    }

    @Test fun tabsWorkWithoutTheBackSwitch() {
        assertEquals(SwipeMove.Main("home"), plan("scraps", swipeBack = false, tabs = true).right)
    }

    @Test fun pagesWithTheirOwnDragsAreLeftAlone() {
        listOf("edit/{id}", "layouts/{id}", "draw", "capture", "account").forEach { assertTrue(it, plan(it, tabs = true).isEmpty) }
        assertTrue(plan(null).isEmpty)
    }

    @Test fun aSwipeNeedsDistanceAndToBeMostlySideways() {
        assertEquals(1, NavSwipes.direction(100f, 5f, 80f)); assertEquals(-1, NavSwipes.direction(-100f, 5f, 80f))
        assertEquals(0, NavSwipes.direction(79f, 0f, 80f)); assertEquals(1, NavSwipes.direction(80f, 0f, 80f))
        assertEquals(0, NavSwipes.direction(100f, 60f, 80f)); assertEquals(1, NavSwipes.direction(100f, 50f, 80f)); assertEquals(0, NavSwipes.direction(0f, 300f, 80f))
    }
}
