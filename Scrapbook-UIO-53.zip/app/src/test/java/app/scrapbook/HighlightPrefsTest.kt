package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HighlightPrefsTest {
    @Test fun strengthStaysBetween25And100() {
        assertEquals(25, HighlightPrefs.opacity(0)); assertEquals(25, HighlightPrefs.opacity(-40))
        assertEquals(100, HighlightPrefs.opacity(250)); assertEquals(60, HighlightPrefs.opacity(60))
    }

    @Test fun sliderMovesInFiveSteps() {
        assertEquals(25, HighlightPrefs.fromSlider(0f)); assertEquals(100, HighlightPrefs.fromSlider(1f))
        assertEquals(25, HighlightPrefs.fromSlider(-3f)); assertEquals(100, HighlightPrefs.fromSlider(7f))
        for (i in 0..200) assertEquals(0, HighlightPrefs.fromSlider(i / 200f) % 5)
        assertEquals(65, HighlightPrefs.fromSlider(.5333f))
    }

    @Test fun sliderAndStrengthMatchBothWays() {
        for (p in 25..100 step 5) assertEquals(p, HighlightPrefs.fromSlider(HighlightPrefs.toSlider(p)))
        assertEquals(0f, HighlightPrefs.toSlider(0), 0.0001f); assertEquals(1f, HighlightPrefs.toSlider(500), 0.0001f)
    }

    @Test fun readyColorsAreChoicesOneToFive() {
        assertNull(HighlightPrefs.preset(0)); assertEquals(0xFFE066, HighlightPrefs.preset(1)); assertEquals(0xFFB366, HighlightPrefs.preset(5)); assertNull(HighlightPrefs.preset(6))
        assertEquals(HighlightPrefs.PRESETS.size + 1, HighlightPrefs.NAMES.size)
    }

    @Test fun inkFollowsHowBrightTheHighlightLooksOnThePage() {
        // a strong marker on a dark page is bright: dark ink
        assertTrue(HighlightPrefs.darkInk(HighlightPrefs.blend(.9f, .04f, 1f)))
        // the same marker at 25 percent on that page is dark: the text keeps its own light color
        assertFalse(HighlightPrefs.darkInk(HighlightPrefs.blend(.9f, .04f, .25f)))
        // on a light page even a soft one stays bright
        assertTrue(HighlightPrefs.darkInk(HighlightPrefs.blend(.9f, .98f, .25f)))
    }
}
