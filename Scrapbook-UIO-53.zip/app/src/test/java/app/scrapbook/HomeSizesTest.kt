package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeSizesTest {
    @Test fun everyPartStartsAutomatic() {
        val s = HomeSizes()
        HomeElement.entries.forEach { assertFalse(s[it].sized); assertEquals(0, s[it].width); assertEquals(0, s[it].height) }
        assertEquals("", s.encode())
    }

    @Test fun aSizeKeepsInsideItsLimits() {
        val s = HomeSizes().with(HomeElement.Boxes, 5, 10)
        assertEquals(HomeSections.MIN_WIDTH, s[HomeElement.Boxes].width); assertEquals(HomeSections.MIN_HEIGHT, s[HomeElement.Boxes].height)
        val big = HomeSizes().with(HomeElement.Boxes, 500, 5000)
        assertEquals(HomeSections.MAX_WIDTH, big[HomeElement.Boxes].width); assertEquals(HomeSections.MAX_HEIGHT, big[HomeElement.Boxes].height)
    }

    @Test fun zeroGivesASideBackAndZeroOnBothTakesThePartOut() {
        val s = HomeSizes().with(HomeElement.Pinned, 60, 240)
        assertTrue(s[HomeElement.Pinned].sized)
        assertEquals(0, s.with(HomeElement.Pinned, 60, 0)[HomeElement.Pinned].height)
        assertTrue(s.with(HomeElement.Pinned, 0, 240)[HomeElement.Pinned].sized)
        val none = s.with(HomeElement.Pinned, 0, 0)
        assertFalse(none[HomeElement.Pinned].sized); assertTrue(none.sizes.isEmpty()); assertEquals("", none.encode())
    }

    @Test fun resizingOnePartLeavesTheOthers() {
        val s = HomeSizes().with(HomeElement.Boxes, 60, 200).with(HomeElement.Recent, 100, 400)
        assertEquals(PartSize(60, 200), s[HomeElement.Boxes]); assertEquals(PartSize(100, 400), s[HomeElement.Recent])
        assertEquals(PartSize(60, 200), s.with(HomeElement.Recent, 0, 0)[HomeElement.Boxes])
        assertFalse(s[HomeElement.Header].sized)
    }

    @Test fun theSizesAreSavedInTheOrderOfTheParts() {
        val s = HomeSizes().with(HomeElement.Recent, 100, 400).with(HomeElement.Boxes, 60, 200).with(HomeElement.Header, 80, 0)
        assertEquals("header=80x0,boxes=60x200,recent=100x400", s.encode())
    }

    @Test fun everythingSurvivesSavingAndReading() {
        var s = HomeSizes()
        HomeElement.entries.forEachIndexed { i, e -> s = s.with(e, 30 + i * 10, 100 + i * 50) }
        assertEquals(s, HomeSizes.decode(s.encode()))
    }

    @Test fun anUnreadableTextIsLeftOutAndALargeSizeIsBroughtBack() {
        assertEquals(HomeSizes(), HomeSizes.decode(null)); assertEquals(HomeSizes(), HomeSizes.decode("")); assertEquals(HomeSizes(), HomeSizes.decode("nonsense"))
        assertEquals(HomeSizes(), HomeSizes.decode("boxes=axb,pinned=60,foo=50x50,=1x1"))
        val d = HomeSizes.decode("boxes=7x9999,recent=60x240,header=abc")
        assertEquals(HomeSections.MIN_WIDTH, d[HomeElement.Boxes].width); assertEquals(HomeSections.MAX_HEIGHT, d[HomeElement.Boxes].height)
        assertEquals(PartSize(60, 240), d[HomeElement.Recent]); assertFalse(d[HomeElement.Header].sized)
    }

    @Test fun aSkinHoldsTheSizesAndTheClassicLookHasNone() {
        assertEquals("", SkinKeys.DEFAULTS[SkinKeys.SIZES])
        assertTrue(SkinKeys.SIZES in SkinKeys.DEFAULTS.keys)
    }
}
