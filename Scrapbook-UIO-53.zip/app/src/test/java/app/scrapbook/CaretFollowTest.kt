package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class CaretFollowTest {
    // A screen 1000 px tall, the page scrolled 500 down, margins 28 (top) and 64 (bottom).
    private fun g(top: Float, bottom: Float) = CaretFollow.goal(top, bottom, 500f, 1000f, 28f, 64f)

    @Test fun nothingToDoWhileTheCursorIsComfortablyInView() {
        assertNull(g(900f, 930f)); assertNull(g(540f, 570f)); assertNull(g(1400f, 1436f))   // 1436 is exactly at the margin
    }

    @Test fun scrollsJustEnoughWhenTheCursorNearsTheBottom() {
        // the cursor's bottom is at 1560, past the bottom of the screen (1500): it must end 64 above the bottom
        assertEquals(1560f - 1000f + 64f, g(1530f, 1560f)!!, 0.01f)
    }

    @Test fun scrollsBackUpWhenTheCursorIsAboveTheTop() {
        assertEquals(400f - 28f, g(400f, 430f)!!, 0.01f)
    }

    @Test fun neverAboveTheStartOfThePage() {
        assertEquals(0f, CaretFollow.goal(0f, 30f, 200f, 1000f, 28f, 64f)!!, 0.01f)
        assertNull(CaretFollow.goal(10f, 30f, 0f, 1000f, 28f, 64f))   // at the start already: nothing to scroll
    }

    @Test fun aGlideEndsOnTheGoalWithoutOvershootingAndInUnderHalfASecond() {
        for (r in listOf(7f, 14f, 28f)) {
            var left = 300f; var frames = 0
            while (abs(left) > 0.001f && frames < 600) {
                val s = CaretFollow.step(left, r, 1f / 60f)
                assertTrue("never backwards or past the goal", s > 0f && s <= left + 0.0001f)
                left -= s; frames++
            }
            assertEquals(0f, left, 0.01f)
            if (r >= 14f) assertTrue("rate $r took $frames frames", frames <= 60)
        }
    }

    @Test fun quickerRatesTakeFewerFrames() {
        fun frames(rate: Float): Int { var left = 300f; var n = 0; while (abs(left) > 0.001f && n < 1000) { left -= CaretFollow.step(left, rate, 1f / 60f); n++ }; return n }
        assertTrue(frames(28f) < frames(14f)); assertTrue(frames(14f) < frames(7f))
    }

    @Test fun stepsGoBothWaysAndEndExactly() {
        assertEquals(-0.5f, CaretFollow.step(-0.5f, 14f, 1f / 60f), 0.0001f)
        assertTrue(CaretFollow.step(-200f, 14f, 1f / 60f) < 0f)
    }

    @Test fun aLongFrameDoesNotThrowThePageFar() {
        // a frame that took a whole second moves no more than the 50 ms cap would
        assertEquals(CaretFollow.step(200f, 14f, 0.05f), CaretFollow.step(200f, 14f, 1f), 0.0001f)
    }

    @Test fun speedsAreFourChoicesAndInstantHasNoRate() {
        assertEquals(4, CaretFollow.SPEEDS.size); assertNull(CaretFollow.rate(3)); assertNotNull(CaretFollow.rate(0))
        assertEquals(1, CaretFollow.DEFAULT); assertEquals(3, CaretFollow.speed(99)); assertEquals(0, CaretFollow.speed(-5))
    }
}
