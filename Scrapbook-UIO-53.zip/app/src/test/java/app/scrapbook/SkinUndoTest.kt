package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinUndoTest {
    private val vals = mapOf(SkinKeys.HEADER to "0", SkinKeys.LOOK to "corners=0")

    private fun three(): Triple<HomeSkins, HomeSkin, HomeSkin> {
        val (s1, a) = HomeSkins.initial(emptyMap()).add("A", vals)
        val (s2, b) = s1.add("B", mapOf(SkinKeys.HEADER to "2"))
        return Triple(s2, a, b)
    }

    @Test fun aDeletedSkinComesBackWhereItWasWithItsIdAndPieces() {
        val (s, a, b) = three()
        val index = s.skins.indexOfFirst { it.id == a.id }
        val gone = s.delete(a.id)
        assertEquals(listOf("classic", b.id), gone.skins.map { it.id })
        val back = gone.restored(a, index)
        assertEquals(listOf("classic", a.id, b.id), back.skins.map { it.id })
        assertEquals(a, back.get(a.id))
    }

    @Test fun aSkinIsNeverPutBackBeforeClassicOrPastTheEnd() {
        val (s, a, _) = three()
        assertEquals("classic", s.delete(a.id).restored(a, 0).skins.first().id)
        assertEquals(a.id, s.delete(a.id).restored(a, 99).skins.last().id)
        assertEquals(a.id, s.delete(a.id).restored(a, -5).skins[1].id)
    }

    @Test fun restoringASkinThatIsStillThereOrClassicChangesNothing() {
        val (s, a, _) = three()
        assertEquals(s, s.restored(a, 1))
        assertEquals(s, s.restored(s.get("classic")!!, 1))
    }

    @Test fun aNameTakenMeanwhileGetsANumber() {
        val (s, a, _) = three()
        val gone = s.delete(a.id)
        val (taken, _) = gone.add("A", emptyMap())
        val back = taken.restored(a, 1)
        assertEquals(a.id, back.skins[1].id)
        assertEquals("A 2", back.skins[1].name)
        assertEquals(a.values, back.skins[1].values)
    }

    @Test fun aWornSkinCannotBeDeletedSoItIsNeverRestored() {
        val (s, a, _) = three()
        val worn = s.activate(a.id)!!
        assertEquals(worn, worn.delete(a.id))
    }

    @Test fun resettingAndGivingThePiecesBackIsTheSameAsBefore() {
        val (s, a, _) = three()
        val before = s.get(a.id)!!.values
        val reset = s.reset(a.id)
        assertTrue(reset.get(a.id)!!.values.isEmpty())
        assertEquals(s, reset.withValues(a.id, before))
    }

    @Test fun withValuesKeepsOnlyRealPiecesThatDifferFromClassic() {
        val (s, a, _) = three()
        val v = s.withValues(a.id, mapOf(SkinKeys.HEADER to "1", "junk" to "x", SkinKeys.ADD_BUTTON to "3")).get(a.id)!!.values
        assertEquals(mapOf(SkinKeys.ADD_BUTTON to "3"), v)
    }

    @Test fun otherSkinsAreLeftAloneWhenOneGetsItsPiecesBack() {
        val (s, a, b) = three()
        val after = s.withValues(a.id, emptyMap())
        assertEquals(s.get(b.id), after.get(b.id))
        assertEquals(s.get("classic"), after.get("classic"))
    }
}
