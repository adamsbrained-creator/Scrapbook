package app.scrapbook

import app.scrapbook.SmartSelect.Span
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SmartSelectTest {
    private fun word(t: String, o: Int): String? = SmartSelect.word(t, o)?.let { t.substring(it.start, it.end) }
    private fun sentence(t: String, o: Int): String = SmartSelect.sentence(t, o).let { t.substring(it.start, it.end) }

    @Test fun aWordIsFoundAtAnyPlaceInIt() {
        val t = "Hello world"
        assertEquals("Hello", word(t, 0)); assertEquals("Hello", word(t, 2)); assertEquals("world", word(t, 6)); assertEquals("world", word(t, 11))
    }

    @Test fun aCaretAtTheEndOfAWordTakesThatWord() = assertEquals("Hello", word("Hello world", 5))

    @Test fun blankSpaceBetweenWordsSelectsNothing() { assertNull(word("a    b", 2)); assertNull(word("", 0)) }

    @Test fun anApostropheAHyphenAndAnUnderscoreKeepAWordTogether() {
        assertEquals("don't", word("don't stop", 2)); assertEquals("well-known", word("well-known fact", 1)); assertEquals("snake_case", word("snake_case var", 3))
    }

    @Test fun hashtagsAndMentionsKeepTheirSign() {
        val t = "#idea for @sam"
        assertEquals("#idea", word(t, 3)); assertEquals("#idea", word(t, 0)); assertEquals("@sam", word(t, 12))
    }

    @Test fun numbersStayWhole() { assertEquals("3.14", word("pi is 3.14 ok", 7)); assertEquals("1,000", word("1,000 euros", 2)); assertEquals("10:30", word("at 10:30 pm", 5)) }

    @Test fun aWebAddressIsOneWordWithoutThePunctuationAfterIt() {
        val t = "see https://example.com/a?b=1, then"
        assertEquals("https://example.com/a?b=1", word(t, 10))
        assertEquals("www.example.com", word("go to (www.example.com).", 12))
    }

    @Test fun anEmailAddressIsOneWordAndASentenceEndingPeriodIsNot() {
        assertEquals("john@site.com", word("mail me at john@site.com.", 15)); assertEquals("end", word("end. Next", 2))
    }

    @Test fun lettersWithAccentsAreWordLetters() = assertEquals("café", word("café au lait", 2))

    @Test fun aSentenceEndsAtItsFullStop() {
        val t = "One two. Three four! Five"
        assertEquals("One two.", sentence(t, 2)); assertEquals("Three four!", sentence(t, 12)); assertEquals("Five", sentence(t, 24))
    }

    @Test fun aSentenceNeverCrossesALineBreak() = assertEquals("C d.", sentence("A b.\nC d.", 6))

    @Test fun anAbbreviationDoesNotEndASentence() {
        assertEquals("see e.g. this one.", sentence("see e.g. this one. Next", 5))
        assertEquals("Wait... what?", sentence("Wait... what? Yes!", 2)); assertEquals("Yes!", sentence("Wait... what? Yes!", 16))
    }

    @Test fun theMarksAroundASentenceEndStayWithIt() = assertEquals("**Hello.**", sentence("**Hello.** Next one", 4))

    @Test fun aSentenceStartsAfterTheStartOfALineThatIsNotText() {
        val lead = { line: String -> if (line.startsWith("- ")) 2 else 0 }
        val t = "- item one. two"
        assertEquals(Span(2, 15), SmartSelect.sentence(t, 5, lead))
        assertEquals(Span(2, 15), SmartSelect.lineText(t, 5, lead))
    }

    @Test fun aSelectionGrowsFromWordToSentenceToLineToEverything() {
        val t = "One two. Three four!\nSecond line here."
        val sentenceSpan = SmartSelect.grow(t, Span(9, 14)); assertEquals(Span(9, 20), sentenceSpan)
        val lineSpan = SmartSelect.grow(t, sentenceSpan); assertEquals(Span(0, 20), lineSpan)
        assertEquals(Span(0, t.length), SmartSelect.grow(t, lineSpan))
        assertEquals(Span(0, t.length), SmartSelect.grow(t, Span(0, t.length)))
    }

    @Test fun aSelectionOnTwoLinesGrowsToEverything() {
        val t = "One two.\nThree four."
        assertEquals(Span(0, t.length), SmartSelect.grow(t, Span(4, 14)))
    }

    @Test fun draggingAfterADoubleTapTakesWholeWordsBothWays() {
        val t = "One two. Three four!\nSecond line here."
        assertEquals(Span(0, 14), SmartSelect.extend(t, Span(9, 14), 3))
        assertEquals(Span(9, 32), SmartSelect.extend(t, Span(9, 14), 30))
        assertEquals(Span(9, 14), SmartSelect.extend(t, Span(9, 14), 11))
    }
}
