package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkupTest {
    private fun states(vararg lines: String) = codeLineStates(lines.toList()).toList()
    private val N = CodeLine.NONE; private val O = CodeLine.OPEN; private val B = CodeLine.BODY; private val C = CodeLine.CLOSE

    // ---- fenced blocks ----
    @Test fun aBlockIsOpenBodyClose() = assertEquals(listOf(N, O, B, C, N), states("a", "```", "x", "```", "b"))
    @Test fun aFenceWithoutPartnerStartsNothing() = assertEquals(listOf(N, N, N, N), states("a", "```", "x", "b"))
    @Test fun aLanguageWordIsAllowedOnTheOpeningFence() = assertEquals(listOf(O, B, C, N, O, B, C), states("```kotlin", "x", "```", "y", "```", "z", "```"))
    @Test fun threeBackticksInsideALineAreNotAFence() = assertEquals(listOf(N, N, N), states("```inline```", "x", "```"))
    @Test fun anEmptyBlockIsStillABlock() = assertEquals(listOf(O, C), states("```", "```"))
    @Test fun spacesAfterTheClosingFenceAreFine() = assertEquals(listOf(O, B, C), states("```", "x", "```   "))
    @Test fun theStateOfTheLineAnOffsetIsOn() {
        val t = "a\n```\nx\n```\nb"
        assertEquals(N, codeStateAt(t, 0)); assertEquals(O, codeStateAt(t, 3)); assertEquals(B, codeStateAt(t, 6)); assertEquals(N, codeStateAt(t, t.length))
    }

    // ---- code spans ----
    @Test fun aCodeSpanIsBlankedOut() { assertEquals("a xxx c ``", maskCodeSpans("a `b` c ``")); assertEquals("plain", maskCodeSpans("plain")) }
    @Test fun maskCodeBlanksBlocksAndSpansButKeepsLineBreaks() {
        val t = "x `a`\n```\n# c\n```\ny"
        val m = maskCode(t)
        assertEquals(t.length, m.length); assertEquals("x xxx\nxxx\nxxx\nxxx\ny", m)
    }
    @Test fun hashtagsInCodeAreNotHashtags() {
        assertEquals(listOf(0..4, 14..18), hashtagRanges("#real `#fake` #also"))
        assertEquals(listOf(27..30), hashtagRanges("```\n# comment\n#include\n```\n#tag"))
    }

    // ---- plain previews ----
    @Test fun previewsDropFencesAndKeepCodeAsWritten() = assertEquals("intro · val x = 1 · item", plainPreview("intro\n```kotlin\nval x = 1\n```\n- item"))
    @Test fun previewsDropBackticks() = assertEquals("use foo now", plainPreview("use `foo` now"))

    // ---- web addresses ----
    @Test fun bareAddressesLoseTrailingPunctuationAndSkipMarkdownLinks() {
        assertEquals(listOf(4..18), bareUrlRanges("see https://a.com/x. and [t](https://b.com) and https://"))
        assertEquals(listOf(5..32), bareUrlRanges("open scrapbook://scrap/abcd1234ef now"))
    }
    @Test fun aMarkdownLinkIsFoundFromAnywhereInItsText() {
        val t = "go to [Site](https://a.com) now"
        val s = linkSpotAt(t, 9)!!
        assertEquals("https://a.com", s.url); assertEquals(7..10, s.label); assertTrue(s.markdown)
        assertNull(linkSpotAt(t, 6)); assertTrue(linkSpotAt(t, 11) != null); assertNull(linkSpotAt(t, 20)); assertNull(linkSpotAt(t, 0))
    }
    @Test fun aBareAddressIsFoundWithoutItsPunctuation() {
        val t = "visit https://example.com/page, ok"
        val s = linkSpotAt(t, 10)!!
        assertEquals("https://example.com/page", s.url); assertEquals(6..29, s.label); assertFalse(s.markdown)
        assertTrue(linkSpotAt(t, 30) != null); assertNull(linkSpotAt(t, 31)); assertNull(linkSpotAt(t, 5))
    }
    @Test fun nothingInCodeIsALink() {
        assertNull(linkSpotAt("```\nhttps://a.com\n```", 8)); assertNull(linkSpotAt("see `https://a.com` x", 8))
    }

    // ---- the Code button for words ----
    @Test fun codeSpanWrapsASelection() = assertEquals(MarkupEdit("one `two` three", 5, 8), toggleCodeSpan("one two three", 4, 7))
    @Test fun codeSpanUnwrapsASelectionThatHasBackticks() = assertEquals(MarkupEdit("one two three", 4, 7), toggleCodeSpan("one `two` three", 5, 8))
    @Test fun codeSpanTypesAPairAtACaret() = assertEquals(MarkupEdit("one`` two", 4, 4), toggleCodeSpan("one two", 3, 3))
    @Test fun codeSpanAtACaretInsideOneRemovesIt() = assertEquals(MarkupEdit("a b c", 3, 3), toggleCodeSpan("a `b` c", 4, 4))
    @Test fun codeSpanDoesNotApplyAcrossLines() = assertNull(toggleCodeSpan("a\nb", 0, 3))
    @Test fun knowsWhenTheSelectionIsInACodeSpan() {
        assertTrue(inCodeSpan("one `two` three", 5, 8)); assertFalse(inCodeSpan("one two", 4, 7))
        assertTrue(inCodeSpan("a `bc` d", 5, 5)); assertTrue(inCodeSpan("a `bc` d", 3, 3)); assertFalse(inCodeSpan("a `bc` d", 2, 2)); assertFalse(inCodeSpan("a `bc` d", 6, 6))
    }

    // ---- the extra tools leave code alone ----
    @Test fun aCleanCopyIndentsCodeAndDropsItsFences() = assertEquals("intro\n    - x\nend", plainText("", "intro\n```\n- x\n```\nend"))
    @Test fun aTaskInsideCodeIsNotCounted() = assertEquals(2 to 1, checklistCounts("- [ ] a\n- [x] b\n```\n- [ ] c\n- [x] d\n```"))
    @Test fun tidyingNeverTouchesCode() {
        assertNull(applyChecklist("```\n- [x] a\n- [ ] b\n```", 0, CheckAction.TickedToBottom))
        assertEquals(TextEdit("- [ ] b\n- [x] a\n```\n- [x] c\n- [ ] d\n```", 0, 0), applyChecklist("- [x] a\n- [ ] b\n```\n- [x] c\n- [ ] d\n```", 0, CheckAction.TickedToBottom))
    }

    // ---- the Code block button ----
    @Test fun blockOnAnEmptyNote() = assertEquals(MarkupEdit("```\n\n```", 4, 4), toggleCodeBlock("", 0, 0))
    @Test fun blockOnAnEmptyLine() = assertEquals(MarkupEdit("a\n```\n\n```\nb", 6, 6), toggleCodeBlock("a\n\nb", 2, 2))
    @Test fun blockBelowALineWithText() = assertEquals(MarkupEdit("hello\n```\n\n```", 10, 10), toggleCodeBlock("hello", 5, 5))
    @Test fun blockAroundSelectedLines() = assertEquals(MarkupEdit("```\nhello\nworld\n```", 4, 15), toggleCodeBlock("hello\nworld", 0, 11))
    @Test fun aTripleTapSelectionDoesNotTakeTheNextLine() = assertEquals(MarkupEdit("```\na\nb\n```\nc", 4, 7), toggleCodeBlock("a\nb\nc", 0, 4))
    @Test fun insideABlockTheButtonTakesTheFencesAway() {
        assertEquals(MarkupEdit("a\nx\nb", 2, 2), toggleCodeBlock("a\n```\nx\n```\nb", 6, 6))
        assertEquals(MarkupEdit("x\ncode", 2, 2), toggleCodeBlock("x\n```py\ncode\n```", 8, 8))
    }

    @Test fun noFenceMeansNoCodeAnywhere() {
        val plain = "one\ntwo\n`inline` three"
        assertEquals(CodeLine.NONE, codeStateAt(plain, 0)); assertEquals(CodeLine.NONE, codeStateAt(plain, plain.length))
        assertEquals(List(3) { CodeLine.NONE }, codeLineStates(plain.split("\n")).toList())
    }

    @Test fun aFencedBlockIsStillFound() {
        val t = "a\n```kotlin\nval x = 1\n```\nb"
        assertEquals(listOf(CodeLine.NONE, CodeLine.OPEN, CodeLine.BODY, CodeLine.CLOSE, CodeLine.NONE), codeLineStates(t.split("\n")).toList())
        assertEquals(CodeLine.BODY, codeStateAt(t, t.indexOf("val")))
        assertEquals(CodeLine.NONE, codeStateAt(t, t.length))
    }
}
