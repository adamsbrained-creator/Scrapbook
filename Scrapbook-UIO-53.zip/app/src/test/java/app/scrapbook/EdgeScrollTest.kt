package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EdgeScrollTest {
    private val h = 1600f
    private val zone = 200f

    @Test fun theMiddleOfThePageDoesNotScroll() {
        assertEquals(0f, EdgeScroll.speed(800f, h, zone), 0f)
        assertEquals(0f, EdgeScroll.speed(zone, h, zone), 0f)          // the inner border of the top zone
        assertEquals(0f, EdgeScroll.speed(h - zone, h, zone), 0f)      // the inner border of the bottom zone
    }

    @Test fun theTopScrollsUpAndTheBottomScrollsDown() {
        assertTrue(EdgeScroll.speed(100f, h, zone) < 0f)
        assertTrue(EdgeScroll.speed(h - 100f, h, zone) > 0f)
    }

    @Test fun theNearerTheEdgeTheFaster() {
        val speeds = listOf(1420f, 1480f, 1540f, 1600f, 1680f, 1800f).map { EdgeScroll.speed(it, h, zone) }
        for (i in 1 until speeds.size) assertTrue("step $i: ${speeds[i]} after ${speeds[i - 1]}", speeds[i] > speeds[i - 1])
        assertTrue(speeds.first() > 0f)
    }

    @Test fun theEdgeIsFastAndPastTheEdgeIsFaster() {
        assertEquals(EdgeScroll.MAX_SPEED, EdgeScroll.speed(h, h, zone), 0.01f)
        assertEquals(-EdgeScroll.MAX_SPEED, EdgeScroll.speed(0f, h, zone), 0.01f)
        assertTrue(EdgeScroll.speed(h + 100f, h, zone) > EdgeScroll.MAX_SPEED)
    }

    @Test fun thereIsALimitPastTheEdge() {
        val limit = EdgeScroll.MAX_SPEED * (1f + EdgeScroll.BEYOND)
        assertEquals(limit, EdgeScroll.speed(h + zone, h, zone), 0.01f)
        assertEquals(limit, EdgeScroll.speed(h + 5000f, h, zone), 0.01f)
        assertEquals(-limit, EdgeScroll.speed(-5000f, h, zone), 0.01f)
    }

    @Test fun upAndDownAreTheSameBySymmetry() {
        for (d in listOf(10f, 90f, 150f, 200f)) assertEquals(-EdgeScroll.speed(d, h, zone), EdgeScroll.speed(h - d, h, zone), 0.01f)
    }

    @Test fun noVisiblePageOrNoZoneMeansNoScrolling() {
        assertEquals(0f, EdgeScroll.speed(10f, 0f, zone), 0f)
        assertEquals(0f, EdgeScroll.speed(10f, h, 0f), 0f)
    }

    @Test fun theZoneIsAThumbOrAFifthOfThePageButNeverMoreThanHalf() {
        assertEquals(200f, EdgeScroll.zone(1000f, 72f), 0.01f)         // a fifth
        assertEquals(72f, EdgeScroll.zone(200f, 72f), 0.01f)           // the minimum
        assertEquals(50f, EdgeScroll.zone(100f, 72f), 0.01f)           // a tiny window: half of it
    }
}
