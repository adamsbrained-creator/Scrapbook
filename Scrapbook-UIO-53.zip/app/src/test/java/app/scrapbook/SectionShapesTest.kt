package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SectionShapesTest {
    @Test fun everyLayoutHasItsOwnKeyAndReadsBack() {
        val keys = SectionLayout.entries.map { it.key }
        assertEquals(keys.size, keys.toSet().size)
        SectionLayout.entries.forEach { assertEquals(it, SectionLayout.of(it.key)) }
    }

    @Test fun theFirstFourKeepTheirSavedNames() {
        assertEquals(listOf("cards", "chips", "rows", "grid"), SectionLayout.entries.take(4).map { it.key })
    }

    @Test fun anUnknownLayoutFromALaterVersionIsCards() {
        assertEquals(SectionLayout.Cards, SectionLayout.of("hologram"))
        assertEquals(SectionLayout.Cards, SectionLayout.of(null))
    }

    @Test fun aNewLayoutSurvivesSavingAndLoading() {
        val s = HomeSection("a", "Reading", SectionLayout.Mosaic, "pinned", listOf(SectionRef(true, "Trips")))
        val back = HomeSections.decode(HomeSections.encode(listOf(s)))
        assertEquals(SectionLayout.Mosaic, back.single().layout)
        assertEquals(s, back.single())
    }

    @Test fun everyLayoutHasANote() = SectionLayout.entries.forEach { assertTrue(it.label, it.note.isNotBlank()) }

    @Test fun tilesNeverFewerThanTwo() {
        assertEquals(2, SectionShapes.tileColumns(100f))
        assertEquals(3, SectionShapes.tileColumns(320f))
        assertEquals(6, SectionShapes.tileColumns(640f))
    }

    @Test fun carouselLetsTheNextCardPeekInButStaysInTheBox() {
        assertEquals(344f * .86f, SectionShapes.carouselWidth(344f), .01f)
        assertEquals(100f, SectionShapes.carouselWidth(100f), .01f)
        assertEquals(140f, SectionShapes.carouselWidth(150f), .01f)
    }

    @Test fun heroSharesTheHeight() {
        assertEquals(176f to 104f, SectionShapes.heroHeights(0))
        val (hero, strip) = SectionShapes.heroHeights(300)
        assertTrue(hero > strip)
        assertEquals(300f, hero + strip + 12f, 1f)
        val (h2, s2) = SectionShapes.heroHeights(100)
        assertTrue(h2 >= 96f && s2 >= 72f)
    }

    @Test fun mosaicGrowsWithTheText() {
        assertEquals(104f, SectionShapes.mosaicHeight(true, 500), 0f)
        assertEquals(120f, SectionShapes.mosaicHeight(false, 0), 0f)
        assertEquals(220f, SectionShapes.mosaicHeight(false, 5000), 0f)
        assertTrue(SectionShapes.mosaicHeight(false, 100) < SectionShapes.mosaicHeight(false, 200))
    }

    @Test fun mosaicColumnsStayBalancedAndKeepOrder() {
        val (l, r) = SectionShapes.splitColumns(listOf(100f, 200f, 100f, 100f, 100f))
        assertEquals(listOf(0, 2, 3), l)
        assertEquals(listOf(1, 4), r)
        assertEquals(emptyList<Int>() to emptyList<Int>(), SectionShapes.splitColumns(emptyList()))
        assertEquals(listOf(0) to emptyList<Int>(), SectionShapes.splitColumns(listOf(50f)))
    }

    @Test fun everyThingIsInExactlyOneMosaicColumn() {
        val hs = List(11) { 100f + it * 7f }
        val (l, r) = SectionShapes.splitColumns(hs)
        assertEquals(hs.indices.toList(), (l + r).sorted())
    }

    @Test fun previewLinesAtLeastOne() {
        assertEquals(1, SectionShapes.previewLines(50f, 90f))
        assertEquals(4, SectionShapes.previewLines(170f, 98f))
    }

    // ----- The layouts as designs of the parts of Home -----

    @Test fun partDesignsKeepTheirOwnNumbersAndAddTheLayoutsAfterThem() {
        assertEquals(listOf("Chips", "Grid", "List"), HomeStyleKey.BoxesStyle.options.take(3))
        assertEquals(listOf("Cards", "List", "Grid"), HomeStyleKey.PinnedStyle.options.take(3))
        assertEquals(listOf("Cards", "Compact"), HomeStyleKey.RecentStyle.options.take(2))
        assertEquals(listOf("Classic", "Thin", "With preview"), HomeStyleKey.ContinueStyle.options.take(3))
    }

    @Test fun everyAddedDesignIsALayoutAndHasAHint() {
        listOf(HomeStyleKey.BoxesStyle, HomeStyleKey.PinnedStyle, HomeStyleKey.RecentStyle, HomeStyleKey.ContinueStyle).forEach { k ->
            assertEquals(k.key, k.options.size, k.hints.size)
            val first = PartShapes.firstAdded(k.key)
            val added = PartShapes.layouts(k.key)
            assertTrue(k.key, added.isNotEmpty())
            assertEquals(k.key, first + added.size, k.options.size)
            added.forEachIndexed { i, l ->
                assertEquals(l.label, k.options[first + i])
                assertEquals(l, PartShapes.layoutFor(k.key, first + i))
            }
            // The designs the part already had are not layouts.
            for (i in 0 until first) assertEquals(null, PartShapes.layoutFor(k.key, i))
        }
    }

    @Test fun recentHasNoSecondCompactAndContinueOnlyTheTwoThatSuitOneScrap() {
        assertEquals(1, HomeStyleKey.RecentStyle.options.count { it == "Compact" })
        assertEquals(listOf(SectionLayout.Hero, SectionLayout.Banner), PartShapes.layouts("continueStyle"))
    }

    @Test fun otherChoicesHaveNoLayouts() {
        assertEquals(emptyList<SectionLayout>(), PartShapes.layouts("captureStyle"))
        assertEquals(null, PartShapes.layoutFor("captureStyle", 1))
    }

    @Test fun anAddedDesignSurvivesSavingAndLoading() {
        val styles = HomeStyles.Default.with(HomeStyleKey.PinnedStyle, 6).with(HomeStyleKey.BoxesStyle, 3)
        val back = HomeStyles.decode(styles.encode())
        assertEquals(6, back[HomeStyleKey.PinnedStyle])
        assertEquals(3, back[HomeStyleKey.BoxesStyle])
        assertEquals(SectionLayout.Mosaic, PartShapes.layoutFor("pinnedStyle", back[HomeStyleKey.PinnedStyle]))
    }

    @Test fun aChoiceFromANewerVersionIsBroughtBackIntoRange() {
        assertEquals(HomeStyleKey.ContinueStyle.options.lastIndex, HomeStyles.decode("continueStyle=99")[HomeStyleKey.ContinueStyle])
    }
}

