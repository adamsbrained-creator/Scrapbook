package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SectionStyleTest {
    @Test fun noChoicesIsTheUsualStyleAndSavesNothing() {
        assertTrue(SectionStyle().isDefault)
        assertEquals("", SectionStyle().encode())
        assertEquals(SectionStyle(), SectionStyle.decode(null))
        assertEquals(SectionStyle(), SectionStyle.decode(""))
    }

    @Test fun everyChoiceIsSavedAndReadBack() {
        val s = SectionStyle(fill = true, tlWidth = 70, tlAlign = 1, tlMax = 8, tlGap = 40, tlNode = 44, tlLine = 2, tlText = 1, tlSpread = true,
            tlSide = 1, tlShape = 2, tlColor = 1, tlLineW = 4, tlGlow = 2, tlOldest = true, tlTextSize = 2, editLabel = 2,
            icons = mapOf("n:abc" to "star", "b:Trips" to "🌴", "n:x y" to "a~b;c=d"))
        assertEquals(s, SectionStyle.decode(s.encode()))
        assertFalse(s.isDefault)
    }

    @Test fun onlyWhatIsNotTheUsualIsWritten() {
        assertEquals("fill=1", SectionStyle(fill = true).encode())
        assertEquals("w=60;n=5", SectionStyle(tlWidth = 60, tlMax = 5).encode())
    }

    @Test fun numbersAreKeptInTheirLimits() {
        val s = SectionStyle.decode("w=5;a=9;n=999;g=1;z=500;l=7;t=-3;sd=4;sh=9;co=5;lw=99;gl=-2;ts=7;el=8")
        assertEquals(SectionStyle.MIN_WIDTH, s.tlWidth)
        assertEquals(2, s.tlAlign)
        assertEquals(SectionStyle.MAX_THINGS, s.tlMax)
        assertEquals(SectionStyle.MIN_GAP, s.tlGap)
        assertEquals(SectionStyle.MAX_NODE, s.tlNode)
        assertEquals(2, s.tlLine)
        assertEquals(0, s.tlText)
        assertEquals(1, s.tlSide)
        assertEquals(2, s.tlShape)
        assertEquals(1, s.tlColor)
        assertEquals(SectionStyle.MAX_LINE, s.tlLineW)
        assertEquals(0, s.tlGlow)
        assertEquals(2, s.tlTextSize)
        assertEquals(2, s.editLabel)
    }

    @Test fun theNewestIsRankedFirstWhicheverEndItIsAt() {
        assertEquals(0, TimelineMetrics.rank(0, 5, SectionStyle()))
        assertEquals(4, TimelineMetrics.rank(4, 5, SectionStyle()))
        assertEquals(4, TimelineMetrics.rank(0, 5, SectionStyle(tlOldest = true)))
        assertEquals(0, TimelineMetrics.rank(4, 5, SectionStyle(tlOldest = true)))
    }

    @Test fun theNewChoicesAreWrittenOnlyWhenTheyAreNotTheUsualOnes() {
        assertEquals("", SectionStyle(tlLineW = 2, tlTextSize = 1, editLabel = 0).encode())
        assertEquals("sd=1;lw=5;ol=1;el=2", SectionStyle(tlSide = 1, tlLineW = 5, tlOldest = true, editLabel = 2).encode())
    }

    @Test fun nonsenseIsSkipped() {
        val s = SectionStyle.decode("junk;=3;w=abc;fill=1;ic=;ic=~x;ic=a~;;q=1")
        assertTrue(s.fill)
        assertEquals(100, s.tlWidth)
        assertTrue(s.icons.isEmpty())
    }

    @Test fun anIconCanBeGivenAndTakenBack() {
        val s = SectionStyle().withIcon("n:a", "star").withIcon("n:b", "🌱")
        assertEquals("star", s.iconOf("n:a"))
        assertEquals("🌱", s.iconOf("n:b"))
        assertNull(s.iconOf("n:c"))
        val back = s.withIcon("n:a", null).withIcon("n:b", "")
        assertTrue(back.isDefault)
    }

    @Test fun theTimelineShowsAsManyAsAreAsked() {
        assertEquals(12, TimelineMetrics.shown(12, SectionStyle()))
        assertEquals(5, TimelineMetrics.shown(12, SectionStyle(tlMax = 5)))
        assertEquals(3, TimelineMetrics.shown(3, SectionStyle(tlMax = 5)))
    }

    @Test fun aHeightIsSharedOnlyWhenEveryoneGetsEnoughOfIt() {
        assertEquals(100f, TimelineMetrics.spreadRow(400, 4)!!, 0.001f)
        assertNull(TimelineMetrics.spreadRow(0, 4))
        assertNull(TimelineMetrics.spreadRow(400, 1))
        assertNull(TimelineMetrics.spreadRow(300, 6))
    }

    @Test fun aSectionSavesItsStyleAfterEverythingElseAndOneWithoutSavesAsBefore() {
        val plain = HomeSection("p", "Plain", SectionLayout.Cards, "", listOf(SectionRef(false, "u")))
        assertEquals("S|p|cards||Plain\nN|u\n", HomeSections.encode(listOf(plain)))
        val styled = HomeSection("t", "Week", SectionLayout.Timeline, "pinned", emptyList(), SectionRule(SectionRule.WEEK), style = SectionStyle(fill = true, tlMax = 6, icons = mapOf("n:u" to "star")))
        val back = HomeSections.decode(HomeSections.encode(listOf(plain, styled)))
        assertEquals(listOf(plain, styled), back)
        assertTrue(back[1].style.fill)
        assertEquals("star", back[1].style.iconOf("n:u"))
    }
}
