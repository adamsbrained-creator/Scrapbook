package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReadySkinsTest {
    @Test fun thereAreSeveralReadySkinsWithOwnKeysAndNames() {
        val all = ReadySkins.all
        assertTrue(all.size >= 3)
        assertEquals(all.size, all.map { it.key }.toSet().size)
        assertEquals(all.size, all.map { it.name }.toSet().size)
        assertFalse(all.any { it.name == HomeSkins.CLASSIC_NAME })
        all.forEach { assertTrue(it.blurb.isNotBlank()) }
    }

    @Test fun eachOneIsFoundByItsKey() {
        ReadySkins.all.forEach { assertEquals(it, ReadySkins.of(it.key)) }
        assertEquals(null, ReadySkins.of("nope"))
    }

    @Test fun everyPieceIsARealPieceAndNotTheClassicValue() {
        ReadySkins.all.forEach { r ->
            assertTrue(r.name, r.values.isNotEmpty())
            r.values.forEach { (k, v) ->
                assertTrue("${r.name}: $k", k in SkinKeys.DEFAULTS)
                assertTrue("${r.name}: $k is the classic value", v != SkinKeys.DEFAULTS[k])
            }
            assertEquals(r.values, HomeSkins.sparse(r.values))
        }
    }

    @Test fun theLayoutOfEachHoldsEveryPartOnce() {
        ReadySkins.all.forEach { r ->
            val order = HomeLayout.decodeOrder(r.values[SkinKeys.ORDER])
            assertEquals(r.name, HomeElement.entries.toSet(), order.toSet())
            assertEquals(r.name, HomeElement.entries.size, order.size)
        }
    }

    @Test fun theStylesAndLookOfEachReadBackAsWritten() {
        ReadySkins.all.forEach { r ->
            val styles = r.values[SkinKeys.STYLES].orEmpty()
            assertEquals(r.name, styles, HomeStyles.decode(styles).encode())
            val look = r.values[SkinKeys.LOOK].orEmpty()
            assertEquals(r.name, look, HomeLook.decode(look).encode())
            assertFalse(r.name, HomeStyles.decode(styles) == HomeStyles.Default)
        }
    }

    @Test fun headersStayInsideTheirChoices() {
        ReadySkins.all.forEach { r ->
            assertTrue(r.name, (r.values[SkinKeys.HEADER]?.toIntOrNull() ?: 1) in 0..2)
            assertTrue(r.name, (r.values[SkinKeys.HEADER_SIZE]?.toIntOrNull() ?: 1) in 0..2)
            r.values[SkinKeys.GREET_TEXT]?.toIntOrNull()?.let { assertTrue(it in GreetingPrefs.TEXT_MIN..GreetingPrefs.TEXT_MAX) }
        }
    }

    @Test fun noTwoReadySkinsAreTheSame() {
        val vs = ReadySkins.all.map { it.values }
        assertEquals(vs.size, vs.toSet().size)
    }

    @Test fun theyHoldNoGesturesAndOnlyTimelineAndAgendaHoldASection() {
        ReadySkins.all.forEach { r ->
            assertEquals(r.name, r.key == "timeline" || r.key == "agenda", SkinKeys.SECTIONS in r.values)
            assertFalse(r.name, SkinKeys.GESTURES in r.values)
        }
        val section = HomeSections.decode(ReadySkins.timeline.values[SkinKeys.SECTIONS]).single()
        assertEquals(SectionLayout.Timeline, section.layout)
        assertTrue(section.style.fill && section.style.tlSpread)
        assertEquals(SectionRule(SectionRule.WEEK), section.rule)
        val layout = HomeSkin("t", "t", ReadySkins.timeline.values).layout
        assertEquals(HomeElement.entries.toSet() - setOf(HomeElement.Header, HomeElement.Greeting), layout.hidden)
        assertEquals(HomeElement.Greeting.key, section.anchor)
    }

    @Test fun minimalHidesToSortAndDenseHidesTheGreeting() {
        assertTrue(HomeElement.Sort in HomeSkin("m", "m", ReadySkins.minimal.values).layout.hidden)
        assertTrue(HomeElement.Greeting in HomeSkin("d", "d", ReadySkins.dense.values).layout.hidden)
    }

    @Test fun addingOneTwiceGivesTwoCopiesWithTheSameLook() {
        val classic = HomeSkins.initial(emptyMap())
        val (s1, a) = classic.add(ReadySkins.minimal.name, ReadySkins.minimal.values)
        val (s2, b) = s1.add(ReadySkins.minimal.name, ReadySkins.minimal.values)
        assertEquals("Minimal", a.name)
        assertEquals("Minimal 2", b.name)
        assertEquals(a.values, b.values)
        assertEquals(ReadySkins.minimal.values, a.values)
        assertNotNull(s2.get(b.id))
    }

    // ----- Agenda (UIO 27) -----

    @Test fun agendaIsATabsCardInTheAgendaLayoutThatFillsThePage() {
        val section = HomeSections.decode(ReadySkins.agenda.values[SkinKeys.SECTIONS]).single()
        assertEquals(SectionLayout.Agenda, section.layout)
        assertTrue(section.isTabs && section.isCard && !section.isSmart && section.fillsItself)
        assertTrue(section.style.fill)
        assertEquals(SectionTabs.DEFAULT, section.card!!.tabs)
        assertEquals(HomeElement.Header.key, section.anchor)
    }

    @Test fun agendaKeepsTheHeaderAndHidesEveryOtherPart() {
        val skin = HomeSkin("a", "a", ReadySkins.agenda.values)
        assertEquals(HomeElement.entries.toSet() - HomeElement.Header, skin.layout.hidden)
        assertEquals("0", ReadySkins.agenda.values[SkinKeys.HEADER])
        assertEquals("0", ReadySkins.agenda.values[SkinKeys.HEADER_SIZE])
    }

    @Test fun agendaHasRoundCornersAndALimeAccentFromTheListOfAccents() {
        val look = HomeLook.decode(ReadySkins.agenda.values[SkinKeys.LOOK])
        assertEquals(2, look[HomeLookKey.Corners])
        assertEquals("Lime", HomeLookKey.Accent.options[look[HomeLookKey.Accent]])
        assertEquals(7, look.accentChoice)
    }

    @Test fun agendaCanBeSharedAsACodeWithItsTabsAndKeepsItsLook() {
        val skin = HomeSkin("a", "Agenda", ReadySkins.agenda.values)
        val back = SkinShare.parse(SkinShare.export(skin))!!
        assertEquals(ReadySkins.agenda.values, back.values)
        assertTrue(HomeSkin("b", "b", back.values).sections.single().isTabs)
    }
}
