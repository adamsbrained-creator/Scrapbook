package app.scrapbook

import org.junit.Assert.assertEquals
import org.junit.Test

class ConvertersTest {
    private val c = Converters()

    @Test fun tagsRoundTrip() = assertEquals(listOf("a", "b c"), c.toTags(c.fromTags(listOf("a", "b c"))))
    @Test fun emptyTags() = assertEquals(emptyList<String>(), c.toTags(c.fromTags(emptyList())))
    /** Scraps saved with a layout that no longer exists read as Classic; nothing in them is lost. */
    @Test fun removedLayoutsReadAsClassic() {
        assertEquals(Layout.Classic, c.toLayout("Journal"))
        assertEquals(Layout.Classic, c.toLayout("Gallery"))
        assertEquals(Layout.Classic, c.toLayout("nonsense"))
    }
    @Test fun enumsRoundTrip() {
        assertEquals(Layout.Classic, c.toLayout(c.fromLayout(Layout.Classic)))
        assertEquals(Kind.Quote, c.toKind(c.fromKind(Kind.Quote)))
    }
}
