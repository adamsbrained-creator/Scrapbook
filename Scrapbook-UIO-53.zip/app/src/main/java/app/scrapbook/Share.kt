package app.scrapbook

private val URL = Regex("^https?://\\S+$")

fun isUrl(text: String) = URL.matches(text.trim())

/** What kind of item a shared payload should become. */
fun classifyShare(text: String, hasImage: Boolean): Kind = when {
    hasImage -> Kind.Image
    isUrl(text) -> Kind.Link
    text.trimStart().firstOrNull() in listOf('"', '“') -> Kind.Quote
    else -> Kind.Note
}

/** A sensible default title for something shared into the app. */
fun shareTitle(subject: String, text: String, hasImage: Boolean): String = when {
    subject.isNotBlank() -> subject.trim()
    isUrl(text) -> runCatching { java.net.URI(text.trim()).host }.getOrNull()?.removePrefix("www.") ?: "Link"
    text.isNotBlank() -> text.lines().first { it.isNotBlank() }.trim().take(60)
    hasImage -> "Shared image"
    else -> "Untitled"
}

/** Character ranges of web links in a text, without trailing punctuation. */
fun findUrls(text: String): List<IntRange> = Regex("https?://\\S+").findAll(text).map { m ->
    var end = m.range.last
    while (end > m.range.first && text[end] in ".,;:!?)\"”'") end--
    m.range.first..end
}.toList()

/** The <title> of an HTML page, decoded and trimmed; null if there is none. */
fun extractTitle(html: String): String? =
    Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)
        ?.replace("&amp;", "&")?.replace("&quot;", "\"")?.replace("&#39;", "'")?.replace(Regex("\\s+"), " ")?.trim()
        ?.takeIf { it.isNotEmpty() }?.take(120)

/** A formatting span in a note: {c:ff0000 s:20 u|text}. c is the text color (hex), s the size in sp, u underlines. */
val SPAN_RE = Regex("\\{((?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2})\\|(.+?)\\}")

data class SpanAttrs(val color: String? = null, val size: Int? = null, val underline: Boolean = false) {
    val none get() = color == null && size == null && !underline
    /** The attribute list as written inside the braces, for example "c:ff0000 s:20 u". */
    fun tag() = listOfNotNull(color?.let { "c:$it" }, size?.let { "s:$it" }, if (underline) "u" else null).joinToString(" ")
}

fun parseSpanAttrs(src: String): SpanAttrs {
    var c: String? = null; var s: Int? = null; var u = false
    for (tok in src.split(' ')) when {
        tok.startsWith("c:") -> c = tok.substring(2).lowercase()
        tok.startsWith("s:") -> s = tok.substring(2).toIntOrNull()?.coerceIn(6, 96)
        tok == "u" -> u = true
    }
    return SpanAttrs(c, s, u)
}

/** Layout tags that sit right after a line's prefix: {i:1} to {i:4} indents the line, {a:c} centers it, {a:r} right-aligns it. */
val LINE_TAGS = Regex("^(?:\\{i:([1-4])\\})?(?:\\{a:([cr])\\})?")
val LINE_PREFIX_RE = Regex("^(?:## |# |> |- \\[[ x]\\] |- |\\d+\\. )")

/** Plain-text preview of a formatted scrap: drops list, heading and quote markers, layout tags, inline formatting marks and dividers. */
fun plainPreview(text: String, sep: String = " · "): String {
    val lines = text.lines(); val code = codeLineStates(lines)
    // The fences of a code block are left out and its lines are kept as they are: nothing inside code is formatting.
    return lines.mapIndexedNotNull { i, l ->
        when (code[i]) {
            CodeLine.OPEN, CodeLine.CLOSE -> null
            CodeLine.BODY -> l.trim()
            else -> stripInline(l.replace(LINE_PREFIX_RE, "").replace(LINE_TAGS, ""))
        }
    }.filter { it.isNotBlank() && it != "---" }.joinToString(sep)
}

/** Removes **bold**, *italic*, ~~strike~~, ==highlight==, `code` and {color|size|underline} marks and [link](url) syntax, keeping the text. */
fun stripInline(s00: String): String = withoutEmptyMarks(s00).let { s0 -> SPAN_RE.replace(s0) { it.groupValues[2] }.let { s -> s.replace(PV_LINK_RE, "\$1").replace(PV_BOLD_RE, "\$1").replace(PV_STRIKE_RE, "\$1")
    .replace(PV_MARK_RE, "\$1").replace(PV_ITALIC_RE, "\$1").replace(CODE_SPAN, "\$1") } }

// Built once. They used to be built again for every line of every scrap each time a card was drawn, which is slow.
private val PV_LINK_RE = Regex("\\[([^\\]\\n]+)\\]\\([^)\\s]*\\)")
private val PV_BOLD_RE = Regex("\\*\\*(.+?)\\*\\*")
private val PV_STRIKE_RE = Regex("~~(.+?)~~")
private val PV_MARK_RE = Regex("==(.+?)==")
private val PV_ITALIC_RE = Regex("\\*(.+?)\\*")
private val PV_QUOTE_OR_LIST_RE = Regex("^(> |- |\\d+\\. )")

/** The lines of [lines] as [plainPreview] shows them, joined with [sep], reading only until [limit] characters are in hand. */
private fun previewOf(lines: Sequence<String>, sep: String, limit: Int): String {
    val sb = StringBuilder()
    for (l in lines) {
        val s = stripInline(l.replace(LINE_PREFIX_RE, "").replace(LINE_TAGS, ""))
        if (s.isBlank() || s == "---") continue
        if (sb.isNotEmpty()) sb.append(sep)
        sb.append(s)
        if (sb.length >= limit) break
    }
    return sb.toString()
}

/**
 * The start of [plainPreview] (at least [limit] characters of it, or all of it when it is shorter), without reading the rest of the scrap.
 * Anything drawn with a line limit looks exactly the same, but a long scrap is no longer read to its end just to show two lines.
 */
fun plainPreviewHead(text: String, sep: String = " · ", limit: Int = 800): String =
    if ("```" in text) plainPreview(text, sep) else previewOf(text.lineSequence(), sep, limit)   // a scrap with a code block needs the whole text to know where the block ends

/** The start of plainPreview(bodyWithoutTitle(title, body)) with the same rules as [bodyWithoutTitle], without reading the whole scrap. */
fun previewHead(title: String, body: String, limit: Int = 800): String {
    if ("```" in body) return plainPreview(bodyWithoutTitle(title, body))
    val lines = body.lineSequence()
    val first = lines.indexOfFirst { it.isNotBlank() }
    if (first < 0) return ""
    val line = lines.elementAt(first)
    if (PV_QUOTE_OR_LIST_RE.containsMatchIn(line) || plainPreview(line).trim() != title.trim()) return previewOf(lines, " · ", limit)
    return previewOf(lines.drop(first + 1).dropWhile { it.isBlank() }, " · ", limit)
}

// Created on first use (not when the file loads), so the plain unit tests that use this file never touch an Android class.
private val previewCache: android.util.LruCache<String, String> by lazy {
    object : android.util.LruCache<String, String>(1_500_000) {
        override fun sizeOf(key: String, value: String): Int = key.length + value.length
    }
}

/** plainPreview(bodyWithoutTitle(title, body)) in full, remembered for the next time the same text is shown (a card scrolled back into view, a list that redraws). */
fun cachedPreview(title: String, body: String): String {
    val key = title + "\u0000" + body
    previewCache.get(key)?.let { return it }
    return plainPreview(bodyWithoutTitle(title, body)).also { previewCache.put(key, it) }
}

/**
 * A note without a typed title gets its first line as title. This drops that first line from the body
 * when showing the note, so the title is not repeated. Only plain lines and # headings count, never list items.
 */
fun bodyWithoutTitle(title: String, body: String): String {
    val lines = body.lines(); val i = lines.indexOfFirst { it.isNotBlank() }
    if (i < 0 || PV_QUOTE_OR_LIST_RE.containsMatchIn(lines[i]) || plainPreview(lines[i]).trim() != title.trim()) return body
    return lines.drop(i + 1).dropWhile { it.isBlank() }.joinToString("\n")
}
