package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder

// The Cards page layout: a scrap that is an ordinary page of text and photos with free cards laid over it. A card is a small rounded panel with a title, some text, a badge
// (a pill such as "Topic"), an icon and, if you want, a round arrow button that opens a link. A card can sit on any spot of the page, over the text or over a photo, and it
// does not push anything aside. The cards live in the scrap's `canvas` column, a text that starts with [HEADER], so nothing about the database changes and a scrap that has
// no cards (or an old canvas text from before) simply has none. Only rules here, so they are tested on their own (PageCardsTest).

/**
 * One card. [x] is the left edge as a fraction of the page's width and [w] the width the same way, so a card keeps its place when the phone turns; [y] is the top edge in dp from the
 * top of the page (the page grows to hold the lowest card). [badge], [badgeIcon] and [icon] may be empty; an icon is an emoji or a symbol you typed, or "pic:" followed by the address
 * of a picture you added. [link] is a web address (empty: no arrow button). [tilt] is in degrees and [tone] picks the card's color (0 is the plain card).
 */
data class PageCard(
    val id: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val title: String = "",
    val text: String = "",
    val badge: String = "",
    val badgeIcon: String = "",
    val icon: String = "",
    val link: String = "",
    val tilt: Int = 0,
    val tone: Int = 0,
)

object PageCards {
    const val HEADER = "cards1"
    const val MAX_CARDS = 60
    const val MIN_W = .28f
    const val DEFAULT_W = .62f
    const val MAX_TILT = 12
    const val TONES = 5
    const val MAX_TITLE = 120
    const val MAX_TEXT = 1200
    const val MAX_BADGE = 24
    const val MAX_ICON = 400
    const val MAX_LINK = 300
    const val MAX_Y = 20000f
    const val PIC = "pic:"

    /** Ready symbols for a badge or an icon, besides any emoji you type. */
    val SYMBOLS = listOf("\u2731", "\u2605", "\u2726", "\u25CF", "\u25C6", "\u2665", "\u2713", "!", "?", "\u2192")

    fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(8)

    fun isPic(s: String): Boolean = s.startsWith(PIC)
    fun picAddress(s: String): String = s.removePrefix(PIC)

    /** [c] with every number brought into range and every text cut to its limit. */
    fun clamp(c: PageCard): PageCard {
        val w = c.w.coerceIn(MIN_W, 1f)
        return c.copy(
            x = c.x.coerceIn(0f, 1f - w), y = c.y.coerceIn(0f, MAX_Y), w = w,
            title = c.title.take(MAX_TITLE), text = c.text.take(MAX_TEXT), badge = c.badge.take(MAX_BADGE),
            badgeIcon = c.badgeIcon.take(MAX_ICON), icon = c.icon.take(MAX_ICON), link = c.link.trim().take(MAX_LINK),
            tilt = c.tilt.coerceIn(-MAX_TILT, MAX_TILT), tone = c.tone.coerceIn(0, TONES - 1),
        )
    }

    /** A new, empty card near the top of what you are looking at ([viewTopDp] is how far the page is scrolled), each one a little further along than the last so they do not hide each other. */
    fun newCard(existing: List<PageCard>, viewTopDp: Float): PageCard {
        val k = existing.size % 5
        return clamp(PageCard(newId(), x = .08f + k * .06f, y = maxOf(0f, viewTopDp) + 56f + k * 28f, w = DEFAULT_W))
    }

    /** The cards a canvas text holds, in order from back to front. Anything that is not in this format (an old canvas text, nothing at all) holds none. */
    fun parse(canvas: String?): List<PageCard> {
        val lines = canvas.orEmpty().split('\n')
        if (lines.firstOrNull() != HEADER) return emptyList()
        val out = ArrayList<PageCard>(); val seen = HashSet<String>()
        for (line in lines.drop(1)) {
            val p = line.split('|')
            if (p.size < 13 || p[0] != "C" || p[1].isEmpty() || out.size >= MAX_CARDS || !seen.add(p[1])) continue
            val x = p[2].toFloatOrNull(); val y = p[3].toFloatOrNull(); val w = p[4].toFloatOrNull(); val tilt = p[5].toIntOrNull(); val tone = p[6].toIntOrNull()
            if (x == null || y == null || w == null || tilt == null || tone == null) continue
            out.add(clamp(PageCard(p[1], x, y, w, dec(p[7]), dec(p[8]), dec(p[9]), dec(p[10]), dec(p[11]), dec(p[12]), tilt, tone)))
        }
        return out
    }

    /** The canvas text for these cards; empty for none. */
    fun encode(cards: List<PageCard>): String {
        if (cards.isEmpty()) return ""
        return buildString {
            append(HEADER).append('\n')
            cards.take(MAX_CARDS).map { clamp(it) }.forEach { c ->
                append("C|").append(c.id).append('|').append(c.x).append('|').append(c.y).append('|').append(c.w).append('|').append(c.tilt).append('|').append(c.tone)
                    .append('|').append(enc(c.title)).append('|').append(enc(c.text)).append('|').append(enc(c.badge)).append('|').append(enc(c.badgeIcon))
                    .append('|').append(enc(c.icon)).append('|').append(enc(c.link)).append('\n')
            }
        }
    }

    /** What to keep in the canvas column: the cards, or, when there are none, what was there before unless it was a cards text (so an old canvas of another kind is never wiped). */
    fun save(cards: List<PageCard>, old: String): String =
        if (cards.isNotEmpty()) encode(cards) else if (old.startsWith(HEADER)) "" else old

    fun update(cards: List<PageCard>, id: String, f: (PageCard) -> PageCard): List<PageCard> = cards.map { if (it.id == id) clamp(f(it)) else it }

    /** Moves a card so its left edge is at [x] (a fraction of the width) and its top at [y] dp, keeping it on the page. */
    fun move(cards: List<PageCard>, id: String, x: Float, y: Float): List<PageCard> = update(cards, id) { it.copy(x = x, y = y) }

    /** Gives a card the width [w] (a fraction of the page); if it would run off the right edge it moves left to stay on the page. */
    fun resize(cards: List<PageCard>, id: String, w: Float): List<PageCard> = update(cards, id) { it.copy(w = w) }

    /** Puts a card in front of all the others. */
    fun toFront(cards: List<PageCard>, id: String): List<PageCard> {
        val c = cards.firstOrNull { it.id == id } ?: return cards
        return if (cards.last().id == id) cards else cards.filter { it.id != id } + c
    }

    fun remove(cards: List<PageCard>, id: String): List<PageCard> = cards.filter { it.id != id }

    /** A copy of a card a little down and to the right, in front. */
    fun duplicate(cards: List<PageCard>, id: String): List<PageCard> {
        val c = cards.firstOrNull { it.id == id } ?: return cards
        if (cards.size >= MAX_CARDS) return cards
        return cards + clamp(c.copy(id = newId(), x = c.x + .05f, y = c.y + 28f))
    }

    /** How tall the page has to be to hold the cards: the lowest card's top plus room for a tall card. */
    fun bottomDp(cards: List<PageCard>): Float = if (cards.isEmpty()) 0f else cards.maxOf { it.y } + 320f

    /** The addresses of the pictures the cards use (as icons), without the "pic:". */
    fun pictures(cards: List<PageCard>): List<String> =
        cards.flatMap { listOf(it.icon, it.badgeIcon) }.filter { isPic(it) }.map { picAddress(it) }.filter { it.isNotEmpty() }.distinct()

    /** The canvas text with the address of every picture changed by [f] (a backup writes them as files in the zip and a restore points them at the copies). Text that holds no cards stays as it is. */
    fun mapPictures(canvas: String, f: (String) -> String): String {
        val cards = parse(canvas)
        if (cards.isEmpty()) return canvas
        fun m(s: String) = if (isPic(s)) PIC + f(picAddress(s)) else s
        return encode(cards.map { it.copy(icon = m(it.icon), badgeIcon = m(it.badgeIcon)) })
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }
}
