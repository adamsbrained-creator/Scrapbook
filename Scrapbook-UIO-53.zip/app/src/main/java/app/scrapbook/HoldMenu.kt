package app.scrapbook

/**
 * The menu that opens on the card when you hold a scrap on All scraps or inside a box (Scrapbook-UIO-42). It has no Android in it, so the rules are tested on their own
 * (HoldMenuTest); the drawing is in ui/ScrapPopover.kt.
 *
 * The menu is a list of choices, not fixed code, so a settings page can later let you reorder, hide and bring back actions: [HoldMenuConfig] is what such a page would edit and save
 * ([HoldMenuConfig.encode] and [HoldMenuConfig.decode] are ready for it), and [HoldMenuConfig.DEFAULT] is the menu everyone starts with.
 */
enum class HoldAction(val id: String, val label: String, val icon: String) {
    Pin("pin", "Pin", "starline"),
    AddToBox("box", "Add to box", "folder"),
    Tags("tags", "Tags", "tag"),
    Share("share", "Share", "share"),
    Select("select", "Select", "check"),
    Duplicate("duplicate", "Duplicate", "copy"),
    Open("open", "Open", "arrow"),
    Delete("delete", "Delete", "trash");

    /** Destructive actions are drawn last, after a line, in the danger color. */
    val danger: Boolean get() = this == Delete

    /** Pin turns into Unpin for a scrap that is pinned already; every other action reads the same. */
    fun title(pinned: Boolean): String = if (this == Pin && pinned) "Unpin" else label

    /** The pinned scrap shows a filled star, the others an outlined one. */
    fun iconFor(pinned: Boolean): String = if (this == Pin && pinned) "star" else icon

    companion object {
        fun of(id: String): HoldAction? = entries.firstOrNull { it.id == id }
    }
}

/**
 * Which actions the hold menu offers: [quick] are the big icon buttons along the top (at most [MAX_QUICK]), [rows] are the list under them.
 * Destructive rows always come last. A menu always keeps Select somewhere, because holding a scrap used to be the way to start picking several, and this is the way now.
 */
data class HoldMenuConfig(val quick: List<HoldAction>, val rows: List<HoldAction>) {
    /** The list rows apart from the destructive ones, in order. */
    val plainRows: List<HoldAction> get() = rows.filter { !it.danger }
    val dangerRows: List<HoldAction> get() = rows.filter { it.danger }
    val isDefault: Boolean get() = this == DEFAULT

    /** The same menu made valid: an action appears once (the top row wins over the list), the top row has at most [MAX_QUICK] (an action pushed out of it is simply gone, unless the list has it), and Select is never missing. */
    fun sanitized(): HoldMenuConfig {
        val q = quick.distinct().take(MAX_QUICK)
        val seen = q.toMutableSet()
        val r = rows.filter { seen.add(it) }.toMutableList()
        if (HoldAction.Select !in seen) r.add(0, HoldAction.Select)
        return HoldMenuConfig(q, r)
    }

    /**
     * The menu as one short text for the settings, a part for each half that is not the usual one (`q=pin,box;r=select,delete`); nothing at all for the default menu.
     * A part with nothing after the equals sign is an empty half (no icon buttons on top).
     */
    fun encode(): String {
        val s = sanitized(); val out = ArrayList<String>()
        if (s.quick != DEFAULT.quick) out.add("q=" + s.quick.joinToString(",") { it.id })
        if (s.rows != DEFAULT.rows) out.add("r=" + s.rows.joinToString(",") { it.id })
        return out.joinToString(";")
    }

    companion object {
        const val MAX_QUICK = 4

        val DEFAULT = HoldMenuConfig(
            quick = listOf(HoldAction.Pin, HoldAction.AddToBox, HoldAction.Tags, HoldAction.Share),
            rows = listOf(HoldAction.Select, HoldAction.Duplicate, HoldAction.Delete),
        )

        /** Reads what [encode] wrote. Anything missing, unknown or doubled is dropped, never an error; null or empty gives the default menu. */
        fun decode(text: String?): HoldMenuConfig {
            if (text.isNullOrBlank()) return DEFAULT
            var q = DEFAULT.quick; var r = DEFAULT.rows
            text.split(';').forEach { part ->
                val at = part.indexOf('=')
                if (at < 0) return@forEach
                val list = part.substring(at + 1).split(',').mapNotNull { HoldAction.of(it.trim()) }
                when (part.substring(0, at).trim()) { "q" -> q = list; "r" -> r = list }
            }
            return HoldMenuConfig(q, r).sanitized()
        }
    }
}

/** Where the hold menu goes: its top-left corner, and whether it opened above the card (it grows from the card's edge it is next to). */
data class PopoverSpot(val x: Float, val y: Float, val above: Boolean)

/**
 * Places a menu of [width] by [height] next to a card, all in the same units (pixels) and in the coordinates of the area it may use ([viewW] by [viewH]).
 * It opens right under the card, lined up with the card's right edge (pulled in by [edge] so it sits inside the rounded corner). If it would run off the bottom it opens above the card
 * instead. If it fits neither way (a card taller than the screen) it sits at the bottom of the screen over the card. It never leaves the area, [margin] from each side.
 */
fun placePopover(
    anchorTop: Float, anchorRight: Float, anchorBottom: Float,
    width: Float, height: Float, viewW: Float, viewH: Float,
    gap: Float = 12f, margin: Float = 12f, edge: Float = 6f,
): PopoverSpot {
    val maxX = (viewW - width - margin).coerceAtLeast(margin)
    val x = (anchorRight - width - edge).coerceIn(margin, maxX)
    val below = anchorBottom + gap
    if (below + height <= viewH - margin) return PopoverSpot(x, below, false)
    val above = anchorTop - gap - height
    if (above >= margin) return PopoverSpot(x, above, true)
    return PopoverSpot(x, (viewH - height - margin).coerceAtLeast(margin), false)
}
