package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder

/**
 * The extra choices of a Home section that the older ones (layout, size, space) have no room for: whether it fills the page, how its Timeline layout looks, how its Agenda layout and its
 * tabs look, and the icons you gave to its things. Only choices that differ from the usual are saved, so a section without any saves exactly what it saved before (it is one more field at the end of its line, see HomeSections).
 * Nothing here touches Android, so the rules are tested on their own (SectionStyleTest).
 */
data class SectionStyle(
    /** The section takes all the height the page has left under what is above it, and scrolls inside that if there is more. */
    val fill: Boolean = false,
    /** Timeline: how wide it is, in percent of the section, and where it sits when it is narrower (0 left, 1 middle, 2 right). */
    val tlWidth: Int = 100,
    val tlAlign: Int = 0,
    /** Timeline: the most things it shows (0 is all of them), the space between two of them and the size of a dot, in dp. */
    val tlMax: Int = 0,
    val tlGap: Int = DEFAULT_GAP,
    val tlNode: Int = DEFAULT_NODE,
    /** Timeline: the line between the dots (0 fades down the page, 1 is plain, 2 is dotted) and the text beside a dot (0 title, date and start of the text; 1 title and date; 2 title only). */
    val tlLine: Int = 0,
    val tlText: Int = 0,
    /** Timeline: when the section has a height, share it between the things instead of leaving the space at the bottom. */
    val tlSpread: Boolean = false,
    /** Timeline: which side the line is on (0 left, 1 right), the shape of a dot (0 round, 1 rounded square, 2 none: only the icon), and the color of the bright ones (0 the page's ink, 1 the accent). */
    val tlSide: Int = 0,
    val tlShape: Int = 0,
    val tlColor: Int = 0,
    /** Timeline: how thick the line is, in dp, and which dots are bright (0 the newest, ringed the next one; 1 none; 2 all). */
    val tlLineW: Int = DEFAULT_LINE,
    val tlGlow: Int = 0,
    /** Timeline: the oldest thing at the top instead of the newest, and the size of the text (0 small, 1 usual, 2 large). */
    val tlOldest: Boolean = false,
    val tlTextSize: Int = 1,
    /** Any layout: the word at the right of the section's title (0 \"Auto · Edit\" or \"Edit\", 1 only \"Edit\", 2 nothing: the section is still edited from its hold menu and from Customize home). */
    val editLabel: Int = 0,
    /** Agenda: whether each day has a heading ("13 Feb, Mon"), the line under a title (0 the time, 1 the box, 2 the start of the text, 3 nothing), the tile before it (0 an emoji or icon tile, 1 a small dot, 2 nothing), the arrow at the end and the order (the oldest day first). */
    val agDays: Boolean = true,
    val agSub: Int = 0,
    val agTile: Int = 0,
    val agChevron: Boolean = true,
    val agOldFirst: Boolean = false,
    /** Tabs: where the pill tabs sit (0 docked to the bottom of the screen like a navigation bar, 1 at the top of the section, 2 under the list inside the section) and whether the big name of the tab with the Edit and Add pills shows over the list. */
    val tabsBar: Int = 0,
    val tabsHead: Boolean = true,
    /** Agenda: whether a pinned scrap shows its star (a list of only pinned scraps leaves it out whatever this says). */
    val agStar: Boolean = true,
    /** The icon you gave to a thing: [SectionRef.token] to an icon name (see Ic) or an emoji. A thing with none shows its own emoji, or an icon for what it is. */
    val icons: Map<String, String> = emptyMap(),
) {
    val isDefault: Boolean get() = this == SectionStyle()

    /** The icon chosen for a thing, or null. */
    fun iconOf(token: String): String? = icons[token]?.takeIf { it.isNotEmpty() }

    fun withIcon(token: String, icon: String?): SectionStyle =
        copy(icons = if (icon.isNullOrEmpty()) icons - token else icons + (token to icon))

    /** A copy with every number brought back into its limits. */
    fun clamped(): SectionStyle = copy(
        tlWidth = tlWidth.coerceIn(MIN_WIDTH, 100), tlAlign = tlAlign.coerceIn(0, 2), tlMax = tlMax.coerceIn(0, MAX_THINGS),
        tlGap = tlGap.coerceIn(MIN_GAP, MAX_GAP), tlNode = tlNode.coerceIn(MIN_NODE, MAX_NODE), tlLine = tlLine.coerceIn(0, 2), tlText = tlText.coerceIn(0, 2),
        tlSide = tlSide.coerceIn(0, 1), tlShape = tlShape.coerceIn(0, 2), tlColor = tlColor.coerceIn(0, 1), tlLineW = tlLineW.coerceIn(MIN_LINE, MAX_LINE),
        tlGlow = tlGlow.coerceIn(0, 2), tlTextSize = tlTextSize.coerceIn(0, 2), editLabel = editLabel.coerceIn(0, 2),
        agSub = agSub.coerceIn(0, 3), agTile = agTile.coerceIn(0, 2), tabsBar = tabsBar.coerceIn(0, 2),
    )

    /** The style as one short text (written as `fill=1;w=70;ic=<token>~<icon>`, a part for each choice that is not the usual one). */
    fun encode(): String {
        val d = SectionStyle()
        val out = ArrayList<String>()
        if (fill) out.add("fill=1")
        if (tlWidth != d.tlWidth) out.add("w=$tlWidth")
        if (tlAlign != d.tlAlign) out.add("a=$tlAlign")
        if (tlMax != d.tlMax) out.add("n=$tlMax")
        if (tlGap != d.tlGap) out.add("g=$tlGap")
        if (tlNode != d.tlNode) out.add("z=$tlNode")
        if (tlLine != d.tlLine) out.add("l=$tlLine")
        if (tlText != d.tlText) out.add("t=$tlText")
        if (tlSpread) out.add("s=1")
        if (tlSide != d.tlSide) out.add("sd=$tlSide")
        if (tlShape != d.tlShape) out.add("sh=$tlShape")
        if (tlColor != d.tlColor) out.add("co=$tlColor")
        if (tlLineW != d.tlLineW) out.add("lw=$tlLineW")
        if (tlGlow != d.tlGlow) out.add("gl=$tlGlow")
        if (tlOldest) out.add("ol=1")
        if (tlTextSize != d.tlTextSize) out.add("ts=$tlTextSize")
        if (editLabel != d.editLabel) out.add("el=$editLabel")
        if (agDays != d.agDays) out.add("ad=0")
        if (agSub != d.agSub) out.add("as=$agSub")
        if (agTile != d.agTile) out.add("at=$agTile")
        if (agChevron != d.agChevron) out.add("ac=0")
        if (agOldFirst) out.add("ao=1")
        if (tabsBar != d.tabsBar) out.add("tb=$tabsBar")
        if (tabsHead != d.tabsHead) out.add("th=0")
        if (agStar != d.agStar) out.add("ap=0")
        icons.forEach { (k, v) -> if (v.isNotEmpty()) out.add("ic=" + enc(k) + "~" + enc(v)) }
        return out.joinToString(";")
    }

    companion object {
        const val MIN_WIDTH = 30
        const val MIN_GAP = 8
        const val MAX_GAP = 72
        const val DEFAULT_GAP = 28
        const val MIN_NODE = 28
        const val MAX_NODE = 56
        const val DEFAULT_NODE = 38
        const val MAX_THINGS = 50
        const val MIN_LINE = 1
        const val MAX_LINE = 6
        const val DEFAULT_LINE = 2

        private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
        private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

        /** Reads what [encode] wrote. A part that makes no sense is skipped, and every number is kept in its limits. */
        fun decode(text: String?): SectionStyle {
            var s = SectionStyle()
            val icons = LinkedHashMap<String, String>()
            for (part in text.orEmpty().split(';')) {
                val eq = part.indexOf('=')
                if (eq <= 0) continue
                val k = part.substring(0, eq)
                val v = part.substring(eq + 1)
                val n = v.toIntOrNull()
                when (k) {
                    "fill" -> s = s.copy(fill = v == "1")
                    "w" -> if (n != null) s = s.copy(tlWidth = n)
                    "a" -> if (n != null) s = s.copy(tlAlign = n)
                    "n" -> if (n != null) s = s.copy(tlMax = n)
                    "g" -> if (n != null) s = s.copy(tlGap = n)
                    "z" -> if (n != null) s = s.copy(tlNode = n)
                    "l" -> if (n != null) s = s.copy(tlLine = n)
                    "t" -> if (n != null) s = s.copy(tlText = n)
                    "s" -> s = s.copy(tlSpread = v == "1")
                    "sd" -> if (n != null) s = s.copy(tlSide = n)
                    "sh" -> if (n != null) s = s.copy(tlShape = n)
                    "co" -> if (n != null) s = s.copy(tlColor = n)
                    "lw" -> if (n != null) s = s.copy(tlLineW = n)
                    "gl" -> if (n != null) s = s.copy(tlGlow = n)
                    "ol" -> s = s.copy(tlOldest = v == "1")
                    "ts" -> if (n != null) s = s.copy(tlTextSize = n)
                    "el" -> if (n != null) s = s.copy(editLabel = n)
                    "ad" -> s = s.copy(agDays = v != "0")
                    "as" -> if (n != null) s = s.copy(agSub = n)
                    "at" -> if (n != null) s = s.copy(agTile = n)
                    "ac" -> s = s.copy(agChevron = v != "0")
                    "ao" -> s = s.copy(agOldFirst = v == "1")
                    "tb" -> if (n != null) s = s.copy(tabsBar = n)
                    "th" -> s = s.copy(tabsHead = v != "0")
                    "ap" -> s = s.copy(agStar = v != "0")
                    "ic" -> {
                        val tilde = v.indexOf('~')
                        if (tilde > 0 && tilde < v.length - 1) icons[dec(v.substring(0, tilde))] = dec(v.substring(tilde + 1))
                    }
                }
            }
            return s.copy(icons = icons).clamped()
        }
    }
}

/** The numbers the Timeline layout is drawn with. */
object TimelineMetrics {
    /** The things to show, out of [count]: all of them, or [style]'s limit. */
    fun shown(count: Int, style: SectionStyle): Int = if (style.tlMax <= 0) count else minOf(count, style.tlMax)

    /**
     * How tall each of [count] things is, in dp, when a section [heightDp] tall shares its height between them: equal shares. Null when there is no height to share, the things would have
     * fewer than [MIN_ROW] dp each (then the section scrolls, with each as tall as its text needs), or only one thing.
     */
    fun spreadRow(heightDp: Int, count: Int): Float? {
        if (heightDp <= 0 || count < 2) return null
        val row = heightDp.toFloat() / count
        return if (row >= MIN_ROW) row else null
    }

    const val MIN_ROW = 76f

    /** How new the thing at place [i] of [count] is, 0 for the newest: places are counted from the top, and with the oldest at the top the newest is at the bottom. */
    fun rank(i: Int, count: Int, style: SectionStyle): Int = if (style.tlOldest) count - 1 - i else i
}
