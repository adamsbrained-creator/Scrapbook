package app.scrapbook

/**
 * What a double tap, a long press or a drag selects in the editor: words the way a writer means them (hashtags, mentions, web addresses, e-mail addresses, numbers like 3.14 or 1,000, words
 * with an apostrophe or a hyphen), and the ladder a selection grows along: word, sentence, line, everything. Nothing here touches Android, so the rules are tested on their own (SmartSelectTest).
 * Positions are offsets into the text that is given; a [Span] runs from [Span.start] up to, not including, [Span.end].
 */
object SmartSelect {
    data class Span(val start: Int, val end: Int) {
        val length: Int get() = end - start
        fun contains(offset: Int): Boolean = offset in start..end
    }

    private fun isWord(c: Char) = c.isLetterOrDigit() || c == '_'

    /** Whether the character at [i] sits between two word characters and joins them into one word: don't, well-known, john@site.com, file.txt, 3.14, 1,000, 10:30. */
    private fun joins(s: String, i: Int): Boolean {
        if (i <= 0 || i >= s.length - 1) return false
        val l = s[i - 1]; val r = s[i + 1]
        if (!isWord(l) || !isWord(r)) return false
        return when (s[i]) {
            '\'', '\u2019', '-', '\u2011', '@', '.' -> true
            ',', ':' -> l.isDigit() && r.isDigit()
            else -> false
        }
    }

    /** The word that has the word character at [p] in it. A hashtag or a mention keeps its # or @. */
    private fun tokenAt(s: String, p: Int): Span {
        var a = p
        while (a > 0 && (isWord(s[a - 1]) || joins(s, a - 1))) a--
        var b = p + 1
        while (b < s.length && (isWord(s[b]) || joins(s, b))) b++
        if (a > 0 && (s[a - 1] == '#' || s[a - 1] == '@') && (a == 1 || !isWord(s[a - 2]))) a--
        return Span(a, b)
    }

    /** The web address that the character at [p] belongs to, without the brackets, quotes and punctuation around it, or null. */
    private fun urlAt(s: String, p: Int): Span? {
        var a = p
        while (a > 0 && !s[a - 1].isWhitespace()) a--
        var b = p
        while (b < s.length && !s[b].isWhitespace()) b++
        while (a < b && s[a] in "([{<\"'") a++
        while (b > a && s[b - 1] in ".,;:!?)]}>\"'") b--
        if (p < a || p >= b) return null
        val chunk = s.substring(a, b).lowercase()
        return if (chunk.startsWith("http://") || chunk.startsWith("https://") || chunk.startsWith("www.") || "://" in chunk) Span(a, b) else null
    }

    /**
     * The word at [offset] (a caret position, so the character after it, or the one before it when it stands at the end of a word), or null when it is on blank space or punctuation with
     * no word next to it.
     */
    fun word(text: String, offset: Int): Span? {
        if (text.isEmpty()) return null
        val o = offset.coerceIn(0, text.length)
        for (q in intArrayOf(o, o - 1)) {
            if (q < 0 || q >= text.length) continue
            urlAt(text, q)?.let { return it }
            if (isWord(text[q])) return tokenAt(text, q)
            if ((text[q] == '#' || text[q] == '@') && q + 1 < text.length && isWord(text[q + 1])) return tokenAt(text, q + 1)
        }
        return null
    }

    /** While a selection is dragged by words: the anchor word and the word under the finger at [offset], and everything between them. */
    fun extend(text: String, anchor: Span, offset: Int): Span {
        val o = offset.coerceIn(0, text.length)
        val w = word(text, o) ?: Span(o, o)
        return Span(minOf(anchor.start, w.start), maxOf(anchor.end, w.end))
    }

    private const val ENDERS = ".!?\u2026"
    private const val CLOSERS = "\")]}'\u201d\u2019*~=_`"

    /** The line that holds [offset], as the offsets of its first character and of its end (the line break, or the end of the text). */
    private fun lineBounds(text: String, offset: Int): Pair<Int, Int> {
        val o = offset.coerceIn(0, text.length)
        val ls = if (o == 0) 0 else text.lastIndexOf('\n', o - 1) + 1
        val le = text.indexOf('\n', o).let { if (it < 0) text.length else it }
        return ls to le
    }

    /** The end (after any closing quotes or marks) of the sentence that ends at the . ! ? or … at [i], or -1 when the character at [i] does not end a sentence. */
    private fun sentenceEnd(text: String, i: Int, le: Int): Int {
        val j = i + 1
        if (j < le && text[j] in ENDERS) return -1   // "..." or "?!": the last one ends it
        var k = j
        while (k < le && text[k] in CLOSERS) k++
        if (k >= le) return k
        if (!text[k].isWhitespace()) return -1       // 3.14, file.txt
        var m = k
        while (m < le && text[m].isWhitespace()) m++
        if (m >= le) return k
        if (text[i] == '.' && text[m].isLowerCase()) return -1   // e.g. this
        return k
    }

    /** The sentence that holds [offset], within its line. [leadLen] is how long the start of a line that is not text is (a bullet, a number, a # heading mark); the sentence starts after it. */
    fun sentence(text: String, offset: Int, leadLen: (String) -> Int = { 0 }): Span {
        val o = offset.coerceIn(0, text.length)
        val (ls, le) = lineBounds(text, o)
        var start = minOf(ls + leadLen(text.substring(ls, le)), le)
        while (start < le && text[start].isWhitespace()) start++
        var i = start
        while (i < le) {
            if (text[i] in ENDERS) {
                val e = sentenceEnd(text, i, le)
                if (e >= 0) {
                    if (o <= e) return Span(start, e)
                    start = e
                    while (start < le && text[start].isWhitespace()) start++
                    i = start
                    continue
                }
            }
            i++
        }
        var end = le
        while (end > start && text[end - 1].isWhitespace()) end--
        return Span(start, end)
    }

    /** The text of the line that holds [offset], without the start of the line that is not text (see [sentence]). */
    fun lineText(text: String, offset: Int, leadLen: (String) -> Int = { 0 }): Span {
        val (ls, le) = lineBounds(text, offset)
        return Span(minOf(ls + leadLen(text.substring(ls, le)), le), le)
    }

    /** The next bigger thing than [sel]: its sentence, then its line, then everything. */
    fun grow(text: String, sel: Span, leadLen: (String) -> Int = { 0 }): Span {
        val all = Span(0, text.length)
        return listOf(sentence(text, sel.start, leadLen), lineText(text, sel.start, leadLen), all)
            .firstOrNull { it.start <= sel.start && it.end >= sel.end && it.length > sel.length } ?: all
    }
}
