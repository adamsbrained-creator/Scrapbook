package app.scrapbook

import java.io.InputStream

/** What a file in an import folder is. */
enum class NoteFile { Word, Text, Zip, Sdocx, Samsung, Other }

/** What an import did, to be told to the person in one message. */
data class ImportReport(val added: Int = 0, val duplicates: Int = 0, val unreadable: Int = 0, val samsung: Int = 0, val other: Int = 0) {
    operator fun plus(o: ImportReport) = ImportReport(added + o.added, duplicates + o.duplicates, unreadable + o.unreadable, samsung + o.samsung, other + o.other)

    fun message(): String {
        val parts = ArrayList<String>()
        parts.add(if (added == 1) "Imported 1 scrap." else "Imported $added scraps.")
        if (duplicates > 0) parts.add(if (duplicates == 1) "1 was already here." else "$duplicates were already here.")
        if (unreadable > 0) parts.add(if (unreadable == 1) "1 couldn't be read." else "$unreadable couldn't be read.")
        if (samsung > 0) parts.add(
            (if (samsung == 1) "1 older Samsung Notes file (.sdoc, .snb) can't be read" else "$samsung older Samsung Notes files (.sdoc, .snb) can't be read") +
                ": share those notes as a Samsung Notes file (.sdocx) or a Word file instead.")
        if (other > 0) parts.add(if (other == 1) "1 other file was skipped." else "$other other files were skipped.")
        return parts.joinToString(" ")
    }
}

/** Reading the files of an import folder: Word files (what Samsung Notes saves), text and Markdown. Pure, so it can be tested without a phone. */
object NoteImport {
    private val SAMSUNG = setOf("sdoc", "snb", "spd", "memo")   // Samsung Notes formats from before .sdocx, which cannot be read
    private val TEXT = setOf("txt", "md", "markdown", "text")

    fun kindOf(fileName: String): NoteFile {
        if (fileName.startsWith(".") || fileName.startsWith("~$")) return NoteFile.Other
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when {
            ext == "docx" -> NoteFile.Word
            ext == "sdocx" -> NoteFile.Sdocx
            ext in TEXT -> NoteFile.Text
            ext == "zip" -> NoteFile.Zip
            ext in SAMSUNG -> NoteFile.Samsung
            else -> NoteFile.Other
        }
    }

    fun nameWithoutExtension(fileName: String): String = if (fileName.contains('.')) fileName.substringBeforeLast('.') else fileName

    private val STAMPED = Regex("^(.*?)[_\\s]*(\\d{6})_(\\d{6})(?:[_ ]\\d{1,3}| \\(\\d{1,3}\\))?$")

    /**
     * Samsung Notes names what it saves "title_yymmdd_hhmmss" (the note's title and the time of the note, e.g. "Shopping_261008_122329.docx"). This gives the title
     * and that time (in [zone]); a name that is not like that is the title as it is, with no time.
     */
    fun splitName(fileName: String, zone: java.time.ZoneId = java.time.ZoneId.systemDefault()): Pair<String, Long?> {
        val base = nameWithoutExtension(fileName)
        val m = STAMPED.matchEntire(base) ?: return base to null
        val d = m.groupValues[2]; val t = m.groupValues[3]
        val time = try {
            java.time.LocalDateTime.of(2000 + d.substring(0, 2).toInt(), d.substring(2, 4).toInt(), d.substring(4, 6).toInt(), t.substring(0, 2).toInt(), t.substring(2, 4).toInt(), t.substring(4, 6).toInt())
                .atZone(zone).toInstant().toEpochMilli()
        } catch (e: Exception) { return base to null }
        val title = m.groupValues[1].trim('_', ' ', '-').ifBlank { return base to null }
        return title to time
    }

    /** A note read from a file, and the folders it was in inside a zip (top down; empty when it was not in a folder). */
    class Imported(val folders: List<String>, val note: ParsedNote)

    /** What reading one file gave: the notes in it, and what was counted but not read ([report]'s unreadable, samsung and other). */
    class Parsed(val notes: List<Imported> = emptyList(), val report: ImportReport = ImportReport())

    private fun isZip(b: ByteArray) = b.size > 4 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte() && b[2].toInt() == 3 && b[3].toInt() == 4

    /**
     * Reads one file: a Word file, a text file, or a zip of them (Samsung Notes packs several notes, or the pages of one, into a zip). A file that is called text
     * but is really a zip is opened as a zip. Notes inside zips carry the folders they were in.
     */
    fun parseFile(fileName: String, bytes: ByteArray, depth: Int = 0): Parsed {
        val kind = kindOf(fileName)
        return when {
            kind == NoteFile.Samsung -> Parsed(report = ImportReport(samsung = 1))
            kind == NoteFile.Sdocx -> {
                val (name, stamp) = splitName(fileName)
                val note = try { SdocxReader.read(bytes, name) } catch (e: Exception) { null }
                if (note == null) Parsed(report = ImportReport(unreadable = 1))
                else Parsed(listOf(Imported(emptyList(), note.copy(created = note.created ?: stamp, modified = note.modified ?: stamp))))
            }
            kind == NoteFile.Zip || (kind == NoteFile.Text && isZip(bytes)) -> unzip(bytes, depth)
            kind == NoteFile.Word || kind == NoteFile.Text -> {
                val (name, stamp) = splitName(fileName)
                val note = try {
                    if (kind == NoteFile.Word) DocxReader.read(java.io.ByteArrayInputStream(bytes), name) else parseText("$name.txt", bytes.toString(Charsets.UTF_8))
                } catch (e: Exception) { null }
                if (note == null) Parsed(report = ImportReport(unreadable = 1))
                else Parsed(listOf(Imported(emptyList(), if (stamp != null) note.copy(created = stamp, modified = stamp) else note)))
            }
            else -> Parsed(report = ImportReport(other = 1))
        }
    }

    private fun unzip(bytes: ByteArray, depth: Int): Parsed {
        if (depth >= 2) return Parsed(report = ImportReport(other = 1))
        val notes = ArrayList<Imported>(); var report = ImportReport()
        try {
            java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes)).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val path = e.name.replace('\\', '/')
                    if (!e.isDirectory && !path.startsWith("__MACOSX/") && !path.substringAfterLast('/').startsWith("._")) {
                        val data = readCapped(z)
                        if (data == null) report += ImportReport(unreadable = 1)
                        else {
                            val sub = parseFile(path.substringAfterLast('/'), data, depth + 1)
                            val folders = boxPath(path.split('/').dropLast(1))
                            sub.notes.forEach { notes.add(Imported(folders + it.folders, it.note)) }
                            report += sub.report
                        }
                    }
                    e = z.nextEntry
                }
            }
        } catch (e: Exception) { report += ImportReport(unreadable = if (notes.isEmpty()) 1 else 0) }
        if (notes.isEmpty() && report == ImportReport()) report = ImportReport(unreadable = 1)   // not a zip, or nothing in it
        return Parsed(notes, report)
    }

    private fun readCapped(z: java.io.InputStream): ByteArray? {
        val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(16 * 1024); var total = 0
        while (true) { val n = z.read(buf); if (n < 0) break; total += n; if (total > 64 shl 20) return null; out.write(buf, 0, n) }
        return out.toByteArray()
    }

    /** Reads one file and returns its first note (used by tests and by anything that expects one note per file). */
    fun parse(fileName: String, input: InputStream): ParsedNote? = parseFile(fileName, input.readBytes()).notes.firstOrNull()?.note

    /** Text: a first "# Title" line becomes the title (the same rule as before); otherwise the file's name is the title. */
    fun parseText(fileName: String, raw: String): ParsedNote? {
        val text = raw.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n')
        val lines = text.lines(); val h = lines.indexOfFirst { it.startsWith("# ") }
        val title = (if (h >= 0) lines[h].drop(2).trim() else nameWithoutExtension(fileName).trim()).ifBlank { "Imported scrap" }.take(80)
        val body = (if (h >= 0) lines.filterIndexed { i, _ -> i != h } else lines).joinToString("\n").trim()
        if (body.isEmpty() && h < 0) return null
        return ParsedNote(title, body, null, null)
    }

    /** What makes two notes "the same" when a folder is imported again: the title and the text, without caring about capitals or spaces at the ends. */
    fun fingerprint(title: String, body: String): String = title.trim().lowercase() + "\u0000" + body.trim().lowercase()

    /** The boxes a file goes into: the folders between the import folder and the file, top down. Empty = the file is in the folder itself (it goes to Inbox). */
    fun boxPath(relative: List<String>): List<String> = relative.map { it.trim() }.filter { it.isNotEmpty() }
}
