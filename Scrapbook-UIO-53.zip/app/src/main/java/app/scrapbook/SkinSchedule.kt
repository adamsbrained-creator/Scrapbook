package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder

// Scheduled skins: a rule says that between two times of the day, on the days you pick, Home wears a skin (Minimal at night, Bold by day). The rules only ever PUT A SKIN ON; they
// change nothing else. To keep a rule from fighting you, it acts only when the time slot changes: going into a window puts its skin on (and remembers the skin you were wearing),
// going out of every window puts that skin back, and in between whatever you put on yourself stays on. Only rules here, so they are tested on their own (SkinScheduleTest).

/**
 * One rule. [start] and [end] are minutes after midnight (0 to 1439); a window that ends before it starts runs through the night, and one with the same start and end is the whole day.
 * [days] is a mask of the days it applies to, bit 0 for Monday up to bit 6 for Sunday; for a window through the night a day is the day it starts on.
 */
data class ScheduleRule(val id: String, val skinId: String, val start: Int, val end: Int, val days: Int = ALL_DAYS) {
    /** Whether the rule is on at [minute] of the day [day] (0 Monday to 6 Sunday). */
    fun covers(minute: Int, day: Int): Boolean {
        fun on(d: Int) = (days shr Math.floorMod(d, 7)) and 1 == 1
        return when {
            start == end -> on(day)
            start < end -> on(day) && minute in start until end
            else -> (minute >= start && on(day)) || (minute < end && on(day - 1))
        }
    }

    companion object {
        const val ALL_DAYS = 127
        const val MAX_RULES = 6
    }
}

/** The rules, and what the last time of the schedule did: [lastRule] is the rule whose window Home is in (null for none) and [restore] the skin to put back when it ends. */
data class SkinSchedule(val rules: List<ScheduleRule> = emptyList(), val lastRule: String? = null, val restore: String? = null) {
    /** What to do now: the skin to put on (null for none) and the schedule to keep. */
    data class Step(val wear: String?, val schedule: SkinSchedule)

    /** The first rule that is on at this moment. */
    fun active(minute: Int, day: Int): ScheduleRule? = rules.firstOrNull { it.covers(minute, day) }

    /**
     * Looks at the clock: [worn] is the skin on now and [skinIds] every skin there is. Does nothing while the window is the same as last time. Going into a window puts its skin on
     * and remembers [worn]; going from one window into another keeps what was remembered; going out of every window puts the remembered skin back if it still exists.
     */
    fun step(minute: Int, day: Int, worn: String, skinIds: Set<String>): Step {
        val rule = active(minute, day)
        // Same window as last time: nothing to do (unless a rule was deleted while its window was on, which leaves something to put back).
        if (rule?.id == lastRule && (rule != null || restore == null)) return Step(null, this)
        if (rule != null) {
            val remembered = if (lastRule == null) worn else restore
            return Step(rule.skinId.takeIf { it in skinIds && it != worn }, copy(lastRule = rule.id, restore = remembered))
        }
        val back = restore?.takeIf { it in skinIds && it != worn }
        return Step(back, copy(lastRule = null, restore = null))
    }

    /** Whether looking at the clock can change anything at all. */
    val isIdle: Boolean get() = rules.isEmpty() && lastRule == null && restore == null

    /** Saved as `R|id|skin|start|end|days` for every rule and `S|lastRule|restore`, every text URL-encoded. */
    fun encode(): String = buildString {
        rules.forEach { append("R|").append(enc(it.id)).append('|').append(enc(it.skinId)).append('|').append(it.start).append('|').append(it.end).append('|').append(it.days).append('\n') }
        if (lastRule != null || restore != null) append("S|").append(enc(lastRule.orEmpty())).append('|').append(enc(restore.orEmpty())).append('\n')
    }

    companion object {
        fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(8)

        /** "21:30" for 1290. */
        fun timeText(minute: Int): String = Math.floorMod(minute, 1440).let { "%d:%02d".format(it / 60, it % 60) }

        /** "Every day", "Weekdays", "Weekends", or the days by name ("Mon, Wed"). */
        fun daysText(days: Int): String {
            val d = days and ALL
            val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
            return when (d) {
                ALL -> "Every day"
                0b0011111 -> "Weekdays"
                0b1100000 -> "Weekends"
                else -> names.filterIndexed { i, _ -> (d shr i) and 1 == 1 }.joinToString(", ")
            }
        }

        private const val ALL = ScheduleRule.ALL_DAYS

        /** Reads what [encode] wrote. A rule that cannot be read is dropped, times are brought into a day, days with none picked become every day, repeated ids are dropped, and at most [ScheduleRule.MAX_RULES] are kept. */
        fun decode(text: String?): SkinSchedule {
            val rules = ArrayList<ScheduleRule>(); val seen = HashSet<String>()
            var last: String? = null; var restore: String? = null
            for (line in text.orEmpty().split('\n')) {
                val p = line.split('|')
                when (p[0]) {
                    "R" -> if (p.size >= 6) {
                        val id = dec(p[1]); val skin = dec(p[2]); val s = p[3].toIntOrNull(); val e = p[4].toIntOrNull(); val d = p[5].toIntOrNull()
                        if (id.isNotEmpty() && skin.isNotEmpty() && s != null && e != null && d != null && seen.add(id) && rules.size < ScheduleRule.MAX_RULES)
                            rules.add(ScheduleRule(id, skin, s.coerceIn(0, 1439), e.coerceIn(0, 1439), (d and ALL).let { if (it == 0) ALL else it }))
                    }
                    "S" -> if (p.size >= 3) { last = dec(p[1]).ifEmpty { null }; restore = dec(p[2]).ifEmpty { null } }
                }
            }
            return SkinSchedule(rules, last?.takeIf { l -> rules.any { it.id == l } }, restore)
        }

        private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
        private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }
    }
}
