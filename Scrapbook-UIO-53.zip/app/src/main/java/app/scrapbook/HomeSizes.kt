package app.scrapbook

/** The size you gave a part of Home: [width] as a percent of the page's width and [height] in dp. 0 is automatic: the part is as its design draws it. */
data class PartSize(val width: Int = 0, val height: Int = 0) {
    val sized: Boolean get() = width > 0 || height > 0
}

/**
 * The sizes of the eight parts of Home (header, greeting, quick capture, continue, to sort, boxes, pinned, recent), for the parts you resized. A part that is not here is automatic.
 * Sections of your own keep their size in the section itself (HomeSection.width and height); these use the same limits. Kept as one short text ("boxes=60x200,pinned=100x0"), which is
 * also how a skin holds them. Nothing here touches Android, so the rules are tested on their own (HomeSizesTest).
 */
data class HomeSizes(val sizes: Map<HomeElement, PartSize> = emptyMap()) {
    operator fun get(e: HomeElement): PartSize = sizes[e] ?: PartSize()

    /** [e] with the size [width] percent by [height] dp, each kept between its limits; 0 gives that side back to automatic, and 0 on both takes the part out of the list. */
    fun with(e: HomeElement, width: Int, height: Int): HomeSizes {
        val w = if (width <= 0) 0 else width.coerceIn(HomeSections.MIN_WIDTH, HomeSections.MAX_WIDTH)
        val h = if (height <= 0) 0 else height.coerceIn(HomeSections.MIN_HEIGHT, HomeSections.MAX_HEIGHT)
        val next = sizes.toMutableMap()
        if (w == 0 && h == 0) next.remove(e) else next[e] = PartSize(w, h)
        return HomeSizes(next)
    }

    /** The parts that have a size of their own, in the order of the parts. */
    fun encode(): String = HomeElement.entries.mapNotNull { e -> sizes[e]?.let { "${e.key}=${it.width}x${it.height}" } }.joinToString(",")

    companion object {
        /** Reads what [encode] wrote. A part it does not know, or a size that is not numbers, is left out; a size outside its limits is brought back inside. */
        fun decode(text: String?): HomeSizes = text.orEmpty().split(',').fold(HomeSizes()) { acc, piece ->
            val key = piece.substringBefore('=', "").trim()
            val dims = piece.substringAfter('=', "").split('x')
            val e = HomeElement.of(key)
            val w = dims.getOrNull(0)?.trim()?.toIntOrNull()
            val h = dims.getOrNull(1)?.trim()?.toIntOrNull()
            if (e == null || w == null || h == null) acc else acc.with(e, w, h)
        }
    }
}
