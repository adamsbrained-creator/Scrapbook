package app.scrapbook

// ---------------------------------------------------------------------------------------------------------------------------------
// Typing style: what the size, color and underline buttons do with nothing selected
// ---------------------------------------------------------------------------------------------------------------------------------
// With a selection those buttons change the selected text (see formatSpan in the editor). With only a cursor they set how the NEXT letters look: an
// empty span, {s:24|}, is put at the cursor (it is never shown, see EMPTY_SPAN) and what is typed goes inside it. The functions here work on plain text
// and say what the text becomes; the editor applies it.

private val LINK_AT = Regex("\\[([^\\]\\n]+)\\]\\(([^)\\s]*)\\)")

/** How long the hidden start of a line is: its list, heading or quote mark and its layout tags. */
private fun leadLength(line: String): Int {
    val prefix = LINE_PREFIX_RE.find(line)?.value ?: ""
    return prefix.length + (LINE_TAGS.find(line.substring(prefix.length))?.value?.length ?: 0)
}

private fun wrapped(text: String, a: SpanAttrs) = if (text.isEmpty() || a.none) text else "{${a.tag()}|$text}"
private fun emptySpanOf(a: SpanAttrs) = if (a.none) "" else "{${a.tag()}|}"
private fun attrsOfEmpty(span: String) = parseSpanAttrs(span.substring(1, span.length - 2))

/** The line [pos] is on: where it starts, and the line itself. */
private fun lineAt(text: String, pos: Int): Pair<Int, String> {
    val p = pos.coerceIn(0, text.length)
    val ls = text.lastIndexOf('\n', p - 1) + 1
    val le = text.indexOf('\n', ls).let { if (it < 0) text.length else it }
    return ls to text.substring(ls, le)
}

/** The empty span ({s:24|}) that the cursor is at, as a range of the whole text; null when there is none or the line is code. */
fun emptySpanAt(text: String, pos: Int): IntRange? {
    if (codeStateAt(text, pos) != CodeLine.NONE) return null
    val (ls, line) = lineAt(text, pos); val x = pos.coerceIn(0, text.length) - ls
    val m = EMPTY_SPAN.findAll(line).firstOrNull { x >= it.range.first && x <= it.range.last + 1 } ?: return null
    return (ls + m.range.first)..(ls + m.range.last)
}

/** The formatting new text typed at [pos] gets: that of the span the cursor is in (or of an empty one waiting there), otherwise none. */
fun attrsAtCursor(text: String, pos: Int): SpanAttrs {
    val (ls, line) = lineAt(text, pos); val x = pos.coerceIn(0, text.length) - ls
    EMPTY_SPAN.findAll(line).firstOrNull { x >= it.range.first && x <= it.range.last + 1 }?.let { return attrsOfEmpty(it.value) }
    SPAN_RE.findAll(line).firstOrNull { val c = it.groups[2]!!.range; x >= c.first && x <= c.last + 1 }?.let { return parseSpanAttrs(it.groupValues[1]) }
    return SpanAttrs()
}

/**
 * Makes [f] the formatting of what is typed next at [pos]. An empty span for it is put at the cursor, with the cursor inside it; a span the cursor is in
 * is split around it (a span cannot hold another one), and an empty span that is already there is changed. Null when nothing needs to change, the
 * line is code, or the cursor is in the address of a link.
 */
fun typingStyleAt(text: String, pos: Int, f: (SpanAttrs) -> SpanAttrs): TextEdit? {
    val p0 = pos.coerceIn(0, text.length)
    if (codeStateAt(text, p0) != CodeLine.NONE) return null
    val (ls, line) = lineAt(text, p0)
    val p = maxOf(p0 - ls, leadLength(line).coerceAtMost(line.length))   // never inside the hidden start of a line
    fun done(newLine: String, cursor: Int) = TextEdit(text.substring(0, ls) + newLine + text.substring(ls + line.length), ls + cursor, ls + cursor)
    // An empty span is waiting here: change it.
    EMPTY_SPAN.findAll(line).firstOrNull { p >= it.range.first && p <= it.range.last + 1 }?.let { m ->
        val old = attrsOfEmpty(m.value); val na = f(old)
        if (na == old) return null
        val rep = emptySpanOf(na)
        return done(line.replaceRange(m.range.first, m.range.last + 1, rep), m.range.first + if (rep.isEmpty()) 0 else rep.length - 1)
    }
    // The cursor is inside a span: the text before and after it keep the old look, and the new one goes between.
    SPAN_RE.findAll(line).firstOrNull { val c = it.groups[2]!!.range; p >= c.first && p <= c.last + 1 }?.let { m ->
        val c = m.groups[2]!!.range; val old = parseSpanAttrs(m.groupValues[1]); val na = f(old)
        if (na == old) return null
        val left = wrapped(line.substring(c.first, p), old); val right = wrapped(line.substring(p, c.last + 1), old); val mid = emptySpanOf(na)
        val head = line.substring(0, m.range.first)
        return done(head + left + mid + right + line.substring(m.range.last + 1), head.length + left.length + if (mid.isEmpty()) 0 else mid.length - 1)
    }
    // Plain text: nothing to do when the change leaves it plain. The address of a link and a code span are not places for a span.
    for (m in LINK_AT.findAll(line)) if (p > m.range.first + 1 + m.groupValues[1].length && p <= m.range.last) return null
    for (m in CODE_SPAN.findAll(line)) if (p > m.range.first && p <= m.range.last) return null
    val na = f(SpanAttrs()); if (na.none) return null
    val mid = emptySpanOf(na)
    return done(line.substring(0, p) + mid + line.substring(p), p + mid.length - 1)
}

/**
 * Enter pressed while the cursor is in an empty span would put the line break inside the braces. Returns the text without that span and the line
 * break put where it was, with the cursor after the break; null when the cursor is not in an empty span.
 */
fun enterInEmptySpan(text: String, pos: Int): TextEdit? {
    val r = emptySpanAt(text, pos) ?: return null
    val plain = text.removeRange(r.first, r.last + 1)
    return TextEdit(plain.substring(0, r.first) + "\n" + plain.substring(r.first), r.first + 1, r.first + 1)
}

/**
 * Enter pressed inside text that has a size, color or underline (or where one is waiting): the new line goes on in the same look, so everything that is
 * typed keeps it. [old] and [oldPos] are the text before Enter, [next] and [nextPos] after it (list marks and closed spans included). Returns the text with an
 * empty span at the cursor of the new line, or null when there is nothing to carry or the line already has the look.
 */
fun carryStyleOverEnter(old: String, oldPos: Int, next: String, nextPos: Int): TextEdit? {
    if (codeStateAt(old, oldPos) != CodeLine.NONE) return null
    val attrs = attrsAtCursor(old, oldPos); if (attrs.none) return null
    if (next.count { it == '\n' } != old.count { it == '\n' } + 1) return null
    val newLines = old.take(oldPos.coerceIn(0, old.length)).count { it == '\n' }
    var nl = -1; repeat(newLines + 1) { nl = next.indexOf('\n', nl + 1) }
    if (nl < 0 || nextPos <= nl || nextPos > next.length || codeStateAt(next, nextPos) != CodeLine.NONE) return null
    if (attrsAtCursor(next, nextPos) == attrs) return null
    val tag = emptySpanOf(attrs)
    val cursor = nextPos + tag.length - 1
    return TextEdit(next.substring(0, nextPos) + tag + next.substring(nextPos), cursor, cursor)
}
