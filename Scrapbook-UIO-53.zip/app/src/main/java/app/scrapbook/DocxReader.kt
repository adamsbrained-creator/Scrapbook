package app.scrapbook

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.time.Instant
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

/** A picture found in a Word file: its name there (for the file extension) and its bytes. */
class DocxImage(val name: String, val bytes: ByteArray) {
    val extension: String get() = name.substringAfterLast('.', "jpg").lowercase().let { if (it == "jpeg") "jpg" else it }
}

/** A note read from a file: [created] and [modified] are milliseconds, or null when the file does not say. */
data class ParsedNote(val title: String, val body: String, val created: Long?, val modified: Long?, val images: List<DocxImage> = emptyList())

/**
 * Reads a Word (.docx) file into a Scrapbook scrap, which is how a Samsung Notes note can leave Samsung Notes (Save as file > Microsoft Word file).
 *
 * Kept: the text, headings (as # and ##), bulleted and numbered lists (with their depth), checkboxes written as ☐ and ☑, bold, italic, strikethrough, underline,
 * highlight and text color, centered and right-aligned lines, web links, pictures (as the scrap's photos, in the order they appear) and the file's own dates.
 * A table becomes one line per row, the cells apart by " | ". Everything else (page setup, fonts, sizes, headers) is left out.
 * The first line is the title when it is the file's name (a note's title is its file name when Samsung Notes saves it); otherwise the file's name is the title.
 */
object DocxReader {
    private const val W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val VML = "urn:schemas-microsoft-com:vml"
    private const val DCTERMS = "http://purl.org/dc/terms/"
    private const val MAX_PART = 24 shl 20
    private val RASTER = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp")
    private val CHECK_OFF = setOf('☐', '⬜', '□', '❏')
    private val CHECK_ON = setOf('☑', '☒', '✅', '✔', '✓', '■')

    private class Line(val text: String, val plain: String, val title: Boolean = false)

    private class Ctx(val rels: Map<String, String>, val parts: Map<String, ByteArray>, val styles: Map<String, String>, val numFmt: (String, Int) -> String) {
        val images = ArrayList<DocxImage>(); val seen = HashSet<String>()
        val counters = HashMap<String, Int>()
    }

    fun read(input: InputStream, fallbackTitle: String): ParsedNote? {
        val parts = HashMap<String, ByteArray>()
        try {
            ZipInputStream(input).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name
                    if (!e.isDirectory && (n == "word/document.xml" || n == "word/_rels/document.xml.rels" || n == "word/numbering.xml" || n == "word/styles.xml" ||
                            n == "docProps/core.xml" || n.startsWith("word/media/"))) readUpTo(z)?.let { parts[n] = it }
                    e = z.nextEntry
                }
            }
        } catch (e: Exception) { return null }
        val doc = dom(parts["word/document.xml"]) ?: return null
        val body = doc.documentElement.kids().firstOrNull { it.named("body") } ?: return null

        val rels = HashMap<String, String>()
        dom(parts["word/_rels/document.xml.rels"])?.documentElement?.kids()?.forEach { r ->
            val id = r.getAttribute("Id"); val target = r.getAttribute("Target")
            if (id.isNotEmpty() && target.isNotEmpty()) rels[id] = if (r.getAttribute("TargetMode").equals("External", true)) target else resolve(target)
        }
        val styles = HashMap<String, String>()   // style id -> its name, lowercase
        dom(parts["word/styles.xml"])?.documentElement?.kids()?.filter { it.named("style") }?.forEach { s ->
            val id = s.wAttr("styleId"); val name = s.child("name")?.wAttr("val")
            if (id != null && name != null) styles[id] = name.lowercase()
        }
        val ctx = Ctx(rels, parts, styles, numberingOf(dom(parts["word/numbering.xml"])))

        val lines = ArrayList<Line>()
        fun addBlank() { if (lines.isNotEmpty() && lines.last().text.isNotEmpty()) lines.add(Line("", "")) }
        fun walk(parent: Element) {
            for (c in parent.kids()) when {
                c.named("p") -> {
                    val l = paragraph(c, ctx)
                    if (l == null) { addBlank() } else { lines.add(l) }
                }
                c.named("tbl") -> { addBlank(); table(c, ctx).forEach { lines.add(Line(it, it)) }; addBlank() }
                c.named("sdt") -> c.child("sdtContent")?.let { walk(it) }
                c.named("customXml") || c.named("ins") || c.named("moveTo") -> walk(c)
            }
        }
        walk(body)
        while (lines.isNotEmpty() && lines.last().text.isEmpty()) lines.removeAt(lines.lastIndex)
        while (lines.isNotEmpty() && lines.first().text.isEmpty()) lines.removeAt(0)

        // The title: a first line that is the file's name (or a Title paragraph) is the title and is not repeated in the text.
        var title = fallbackTitle.trim()
        val first = lines.firstOrNull()
        if (first != null && first.plain.isNotBlank() && (first.title || same(first.plain, fallbackTitle))) {
            title = first.plain.trim(); lines.removeAt(0)
            while (lines.isNotEmpty() && lines.first().text.isEmpty()) lines.removeAt(0)
        }
        val text = lines.joinToString("\n") { it.text }.trim()
        if (text.isEmpty() && ctx.images.isEmpty()) return null

        val core = dom(parts["docProps/core.xml"])?.documentElement
        // Samsung Notes writes its Word files with Apache POI and puts the time of the export, not of the note, in them, so those dates are left out.
        val exported = core?.getElementsByTagNameNS("http://purl.org/dc/elements/1.1/", "creator")?.item(0)?.textContent?.contains("Apache POI") == true
        fun date(local: String) = if (exported) null else core?.getElementsByTagNameNS(DCTERMS, local)?.item(0)?.textContent?.trim()?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() }
        return ParsedNote(title.ifBlank { "Imported scrap" }.take(80), text, date("created"), date("modified"), ctx.images)
    }

    // ---- paragraphs ----

    /** One paragraph as a line of Scrapbook text, or null for an empty one (it becomes a blank line). */
    private fun paragraph(p: Element, ctx: Ctx): Line? {
        val ppr = p.child("pPr")
        val segs = ArrayList<Seg>()
        runs(p, Fmt(), ctx, segs)
        val merged = Marks.merge(segs)
        val marked = Marks.emit(merged)
        val plain = merged.joinToString("") { it.text }.replace('\n', ' ')
        val style = ppr?.child("pStyle")?.wAttr("val")?.let { ctx.styles[it] ?: it.lowercase() } ?: ""
        val numPr = ppr?.child("numPr")
        val numId = numPr?.child("numId")?.wAttr("val"); val ilvl = numPr?.child("ilvl")?.wAttr("val")?.toIntOrNull() ?: 0
        val heading = Regex("^heading ?(\\d)").find(style)?.groupValues?.get(1)?.toIntOrNull()
        val isTitle = style == "title"
        val jc = ppr?.child("jc")?.wAttr("val")
        val align = when (jc) { "center" -> "{a:c}"; "right", "end" -> "{a:r}"; else -> "" }

        if (marked.isBlank()) return null
        // Anything that is not a list item ends the numbering that was running.
        val inList = numId != null && numId != "0" && heading == null
        if (!inList) ctx.counters.clear()

        val body = marked.trim()
        val prefix = when {
            heading != null -> if (heading == 1) "# " else "## "
            isTitle -> "# "
            inList -> {
                val bullet = ctx.numFmt(numId!!, ilvl) == "bullet"
                val check = body.firstOrNull()
                val mark = if (bullet || check in CHECK_OFF || check in CHECK_ON) "- " else {
                    val key = "$numId:$ilvl"
                    ctx.counters.keys.filter { it.startsWith("$numId:") && it.substringAfter(':').toInt() > ilvl }.forEach { ctx.counters.remove(it) }
                    val n = (ctx.counters[key] ?: 0) + 1; ctx.counters[key] = n; "$n. "
                }
                mark
            }
            else -> ""
        }
        var text = body
        var pre = prefix
        val c = text.firstOrNull()
        if (heading == null && !isTitle && (c in CHECK_OFF || c in CHECK_ON)) {
            pre = if (c in CHECK_ON) "- [x] " else "- [ ] "
            text = text.drop(1).trimStart()
        }
        val indent = if (inList) ilvl.coerceIn(0, 4) else 0
        val tags = (if (indent > 0) "{i:$indent}" else "") + align
        return Line(pre + tags + text, plain, title = isTitle)
    }

    private fun runs(parent: Element, fmt: Fmt, ctx: Ctx, out: MutableList<Seg>) {
        for (c in parent.kids()) when {
            c.named("r") -> run(c, fmt, ctx, out)
            c.named("hyperlink") -> {
                val url = c.getAttributeNS(R, "id").takeIf { it.isNotEmpty() }?.let { ctx.rels[it] }
                runs(c, if (url != null && Regex("^https?://[^)\\s]+$").matches(url)) Fmt(fmt.bold, fmt.italic, fmt.strike, fmt.underline, fmt.highlight, fmt.color, url) else fmt, ctx, out)
            }
            c.named("sdt") -> c.child("sdtContent")?.let { runs(it, fmt, ctx, out) }
            c.named("smartTag") || c.named("ins") || c.named("moveTo") || c.named("fldSimple") || c.named("customXml") -> runs(c, fmt, ctx, out)
        }
    }

    private fun run(r: Element, base: Fmt, ctx: Ctx, out: MutableList<Seg>) {
        val pr = r.child("rPr")
        fun on(name: String) = pr?.child(name).let { it != null && it.wAttr("val")?.lowercase() !in setOf("0", "false", "off") }
        val fmt = Fmt(
            bold = base.bold || on("b"), italic = base.italic || on("i"), strike = base.strike || on("strike") || on("dstrike"),
            underline = base.underline || (pr?.child("u")?.wAttr("val")?.let { it != "none" } ?: false),
            highlight = base.highlight || (pr?.child("highlight")?.wAttr("val")?.let { it != "none" } ?: false),
            color = base.color ?: pr?.child("color")?.wAttr("val")?.takeIf { Regex("^[0-9a-fA-F]{6}$").matches(it) && !Marks.plainInk(it) }?.lowercase(),
            link = base.link)
        for (c in r.kids()) when {
            c.named("t") -> out.add(Seg(c.textContent, fmt))
            c.named("tab") -> out.add(Seg(" ", fmt))
            c.named("br") || c.named("cr") -> out.add(Seg("\n", Fmt()))
            c.named("noBreakHyphen") -> out.add(Seg("-", fmt))
            c.named("sym") -> {}
            c.named("drawing") || c.named("pict") || c.named("object") -> picture(c, ctx)
            c.named("AlternateContent") -> picture(c, ctx)
        }
    }

    private fun picture(e: Element, ctx: Ctx) {
        val ids = ArrayList<String>()
        val blips = e.getElementsByTagNameNS(A, "blip")
        for (i in 0 until blips.length) (blips.item(i) as Element).getAttributeNS(R, "embed").takeIf { it.isNotEmpty() }?.let { ids.add(it) }
        val vml = e.getElementsByTagNameNS(VML, "imagedata")
        for (i in 0 until vml.length) (vml.item(i) as Element).getAttributeNS(R, "id").takeIf { it.isNotEmpty() }?.let { ids.add(it) }
        for (id in ids) {
            val path = ctx.rels[id] ?: continue
            val bytes = ctx.parts[path] ?: continue
            if (path.substringAfterLast('.').lowercase() !in RASTER || !ctx.seen.add(path)) continue
            ctx.images.add(DocxImage(path.substringAfterLast('/'), bytes))
        }
    }

    private fun table(t: Element, ctx: Ctx): List<String> {
        val rows = ArrayList<String>()
        for (tr in t.kids().filter { it.named("tr") }) {
            val cells = tr.kids().filter { it.named("tc") }.map { tc ->
                tc.kids().filter { it.named("p") }.map { p ->
                    val segs = ArrayList<Seg>(); runs(p, Fmt(), ctx, segs); Marks.merge(segs).joinToString("") { it.text }.replace('\n', ' ').trim()
                }.filter { it.isNotEmpty() }.joinToString(" ")
            }
            if (cells.any { it.isNotEmpty() }) rows.add(cells.joinToString(" | ").trim())
        }
        return rows
    }

    // ---- numbering, rels, helpers ----

    /** (numId, level) to the kind of list it is ("bullet", "decimal", ...), from numbering.xml; unknown is a bullet. */
    private fun numberingOf(doc: Document?): (String, Int) -> String {
        if (doc == null) return { _, _ -> "bullet" }
        val abstract = HashMap<String, Map<Int, String>>(); val nums = HashMap<String, String>()
        for (e in doc.documentElement.kids()) {
            if (e.named("abstractNum")) {
                val id = e.wAttr("abstractNumId") ?: continue
                abstract[id] = e.kids().filter { it.named("lvl") }.associate { (it.wAttr("ilvl")?.toIntOrNull() ?: 0) to (it.child("numFmt")?.wAttr("val") ?: "bullet") }
            } else if (e.named("num")) {
                val id = e.wAttr("numId") ?: continue; e.child("abstractNumId")?.wAttr("val")?.let { nums[id] = it }
            }
        }
        return { numId, lvl -> nums[numId]?.let { abstract[it] }?.get(lvl) ?: "bullet" }
    }

    private fun resolve(target: String): String {
        val t = target.removePrefix("/")
        return if (t.startsWith("word/")) t else "word/$t"
    }

    private fun readUpTo(z: ZipInputStream): ByteArray? {
        val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(16 * 1024); var total = 0
        while (true) { val n = z.read(buf); if (n < 0) break; total += n; if (total > MAX_PART) return null; out.write(buf, 0, n) }
        return out.toByteArray()
    }

    private fun dom(bytes: ByteArray?): Document? {
        if (bytes == null) return null
        return try {
            val f = DocumentBuilderFactory.newInstance(); f.isNamespaceAware = true
            for ((k, v) in listOf("http://apache.org/xml/features/disallow-doctype-decl" to true, "http://xml.org/sax/features/external-general-entities" to false,
                "http://xml.org/sax/features/external-parameter-entities" to false)) try { f.setFeature(k, v) } catch (_: Exception) { }
            f.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
        } catch (e: Exception) { null }
    }

    private fun Node.kids(): List<Element> { val out = ArrayList<Element>(); var n = firstChild; while (n != null) { if (n is Element) out.add(n); n = n.nextSibling }; return out }
    private fun Element.named(local: String) = namespaceURI == W && localName == local
    private fun Element.child(local: String): Element? = kids().firstOrNull { it.named(local) }
    private fun Element.wAttr(local: String): String? = getAttributeNS(W, local).takeIf { it.isNotEmpty() }
    private fun same(a: String, b: String): Boolean {
        fun n(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        return n(a).isNotEmpty() && n(a) == n(b)
    }
}
