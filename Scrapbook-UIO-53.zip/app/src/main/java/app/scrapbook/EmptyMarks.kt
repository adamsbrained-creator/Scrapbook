package app.scrapbook

/** A color / size / underline span with nothing inside it: {c:34c759|}. */
val EMPTY_SPAN = Regex("\\{(?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2}\\|\\}")

/**
 * When the last letter inside bold, a highlight, a color and so on is deleted, the marks around it have nothing left to wrap and would show up as
 * plain symbols ("****", "{c:34c759|}"). This takes off every empty wrapper that sits exactly at the cursor, from the inside out, so a nested
 * "=={c:34c759|}==" goes away completely. Returns the new text and cursor, or null when there is nothing to take off.
 */
fun dropEmptyMarks(text: String, cursor: Int): Pair<String, Int>? {
    var s = text; var p = cursor; var changed = false
    var guard = 0
    while (guard++ < 12) {
        if (p < 0 || p > s.length) break
        // {c:..|} with the cursor in front of its closing brace.
        val span = EMPTY_SPAN.findAll(s).firstOrNull { it.range.last == p }
        if (span != null) { s = s.removeRange(span.range.first, span.range.last + 1); p = span.range.first; changed = true; continue }
        // ****, ~~~~ and ==== with the cursor in the middle.
        val pair = listOf("****", "~~~~", "====").firstOrNull { p >= 2 && s.startsWith(it, p - 2) }
        if (pair != null) { s = s.removeRange(p - 2, p + 2); p -= 2; changed = true; continue }
        // An empty italic pair, *|*, not part of a longer run of stars.
        if (p >= 1 && p < s.length && s[p - 1] == '*' && s[p] == '*' && (p < 2 || s[p - 2] != '*') && (p + 1 >= s.length || s[p + 1] != '*')) {
            s = s.removeRange(p - 1, p + 1); p -= 1; changed = true; continue
        }
        break
    }
    return if (changed) s to p else null
}

private val EMPTY_PAIRS = Regex("\\*\\*\\*\\*|~~~~|====")

/** The text with every empty wrapper taken out ("****", "====", "~~~~", "{c:34c759|}"), also when one sits inside another. For showing text, never for saving it. */
fun withoutEmptyMarks(s: String): String {
    if ('|' !in s && !s.contains("****") && !s.contains("~~~~") && !s.contains("====")) return s
    var t = s
    for (i in 0 until 6) {
        val n = EMPTY_PAIRS.replace(EMPTY_SPAN.replace(t, ""), "")
        if (n == t) break
        t = n
    }
    return t
}

private val INLINE_MARKS = Regex("\\*\\*(.+?)\\*\\*|~~(.+?)~~|==(.+?)==|\\*(.+?)\\*")
private val SPAN_MARKS = Regex("\\{((?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)(?: (?:c:[0-9a-fA-F]{6}|s:\\d{1,3}|u)){0,2})\\|(.+?)\\}")

/** One bold / italic / strike / highlight / color run around a spot: how it opens and closes, and where the text inside it is (in the line). */
private class Wrap(val open: String, val close: String, val cs: Int, val ce: Int)

private fun enclosingMarks(masked: String, p: Int): List<Wrap> {
    val chain = mutableListOf<Wrap>()
    var a = 0; var b = masked.length
    while (chain.size < 8) {
        val sub = masked.substring(a, b)
        var best: Wrap? = null
        fun consider(open: String, close: String, cs: Int, ce: Int) {
            if (a + cs <= p && p <= a + ce && (best == null || cs - open.length < best!!.cs - a - best!!.open.length)) best = Wrap(open, close, a + cs, a + ce)
        }
        for (m in INLINE_MARKS.findAll(sub)) {
            val gi = (1..4).first { m.groups[it] != null }; val g = m.groups[gi]!!
            if (gi == 4 && (g.value.first().isWhitespace() || g.value.last().isWhitespace())) continue   // "2 * 3 * 4" is not italic
            consider(sub.substring(m.range.first, g.range.first), sub.substring(g.range.last + 1, m.range.last + 1), g.range.first, g.range.last + 1)
        }
        for (m in SPAN_MARKS.findAll(sub)) {
            val g = m.groups[2]!!
            consider(sub.substring(m.range.first, g.range.first), "}", g.range.first, g.range.last + 1)
        }
        val w = best ?: break
        chain += w; a = w.cs; b = w.ce
    }
    return chain
}

/**
 * Pressing Enter in the middle of bold, a highlight, a color and so on would leave the marks open on one line and closed on the next, and a mark that
 * has lost its partner shows up as plain symbols. So the formatting is closed at the end of the first line and opened again at the start of the
 * second, from the inside out; at the very end of the formatted text that just means the new line starts outside it, and at the very start, the
 * formatted text moves down whole. [line] is the line as saved, [masked] the same with code spans blanked out (same length), [p] the spot in it.
 * Returns what the line before the break and the line after it become, or null when the spot is not inside any formatting.
 */
fun splitMarksAtBreak(line: String, masked: String, p: Int): Pair<String, String>? {
    val chain = enclosingMarks(masked, p)
    if (chain.isEmpty()) return null
    var left = line.substring(0, p); var right = line.substring(p)
    for (w in chain.asReversed()) {
        left = if (left.endsWith(w.open)) left.dropLast(w.open.length) else left + w.close
        right = if (right.startsWith(w.close)) right.drop(w.close.length) else w.open + right
    }
    return left to right
}

/** Every wrapper in the part [from, to) of [masked]: where it opens and where it closes (both as ranges of the line), inner ones included. */
private fun wrapsIn(masked: String, from: Int, to: Int, out: MutableList<Pair<IntRange, IntRange>>) {
    val sub = masked.substring(from, to)
    fun add(m: MatchResult, g: MatchGroup) {
        val cs = from + g.range.first; val ce = from + g.range.last + 1
        out += (from + m.range.first until cs) to (ce until from + m.range.last + 1)
        wrapsIn(masked, cs, ce, out)
    }
    for (m in INLINE_MARKS.findAll(sub)) {
        val gi = (1..4).first { m.groups[it] != null }; val g = m.groups[gi]!!
        if (gi == 4 && (g.value.first().isWhitespace() || g.value.last().isWhitespace())) continue
        add(m, g)
    }
    for (m in SPAN_MARKS.findAll(sub)) add(m, m.groups[2]!!)
}

/**
 * Selecting text and deleting (or typing over it) can take one end of a bold, highlight or color with it and leave the other end behind, a mark with no
 * partner, which shows up as plain symbols. This replaces [a, b) of [old] by [ins] and also takes away whatever is left of any wrapper that lost one of its
 * ends. Returns the new text and where the cursor goes (after [ins]), or null when no wrapper was broken, so the plain edit is fine as it is.
 */
fun replaceHealingMarks(old: String, a: Int, b: Int, ins: String, inCode: (Int) -> Boolean = { false }): Pair<String, Int>? {
    if (b <= a || a < 0 || b > old.length) return null
    val ls = old.lastIndexOf('\n', a - 1) + 1; val le = old.indexOf('\n', b).let { if (it < 0) old.length else it }
    val drop = BooleanArray(old.length); var any = false
    var lineStart = ls
    while (lineStart <= le) {
        val lineEnd = old.indexOf('\n', lineStart).let { if (it < 0 || it > le) le else it }
        if (!inCode(lineStart)) {
            val line = old.substring(lineStart, lineEnd)
            val wraps = mutableListOf<Pair<IntRange, IntRange>>(); wrapsIn(maskCodeSpans(line), 0, line.length, wraps)
            for ((o0, c0) in wraps) {
                val o = (o0.first + lineStart)..(o0.last + lineStart); val c = (c0.first + lineStart)..(c0.last + lineStart)
                fun hit(r: IntRange) = r.first < b && r.last >= a
                fun inside(r: IntRange) = r.first >= a && r.last < b
                if (!hit(o) && !hit(c)) continue
                if (inside(o) && inside(c)) continue
                for (r in listOf(o, c)) if (!inside(r)) for (k in r) if (k < a || k >= b) { drop[k] = true; any = true }
            }
        }
        if (lineEnd >= le) break
        lineStart = lineEnd + 1
    }
    if (!any) return null
    val sb = StringBuilder(); var cursor = 0
    for (k in old.indices) {
        if (k == a) { sb.append(ins); cursor = sb.length }
        if (k in a until b || drop[k]) continue
        sb.append(old[k])
    }
    return sb.toString() to cursor
}

/**
 * Bold, italic, strike or highlight over a selection that crosses line breaks: every line gets its own pair (a pair across a line break would be shown as
 * plain symbols), without touching a line's hidden start (list marks, headings, layout tags) and leaving empty lines alone. When every line already has the
 * pair, the pairs come off instead. [lead] says how many characters at the start of a line are hidden marks. Returns the new text and selection.
 */
fun wrapEachLine(text: String, a: Int, b: Int, marker: String, lead: (String) -> Int): Triple<String, Int, Int>? {
    val m = marker.length
    val segs = mutableListOf<Pair<Int, Int>>()
    var ls = text.lastIndexOf('\n', a - 1) + 1
    while (ls <= b && ls <= text.length) {
        val le = text.indexOf('\n', ls).let { if (it < 0) text.length else it }
        var s0 = maxOf(a, ls); val e0 = minOf(b, le)
        if (s0 == ls) s0 = minOf(e0, ls + lead(text.substring(ls, le)))
        var e1 = e0
        // A selection that runs to the end of a formatted line also holds that line's hidden marks: the text itself is what gets wrapped.
        if (m > 1) { while (s0 + m < e1 && text.startsWith(marker, s0)) s0 += m; while (e1 - m > s0 && text.startsWith(marker, e1 - m)) e1 -= m }
        if (e1 > s0 && text.substring(s0, e1).isNotBlank()) segs += s0 to e1
        if (le >= text.length) break
        ls = le + 1
    }
    if (segs.isEmpty()) return null
    fun on(s: Pair<Int, Int>) = s.first >= m && s.second + m <= text.length && text.substring(s.first - m, s.first) == marker && text.substring(s.second, s.second + m) == marker
    val off = segs.all { on(it) }
    val sb = StringBuilder(); var at = 0; var shift = 0; var ns = 0; var ne = 0
    for ((i, s) in segs.withIndex()) {
        val (s0, e0) = s
        if (off) { sb.append(text, at, s0 - m); sb.append(text, s0, e0); at = e0 + m; if (i == 0) ns = s0 + shift - m; ne = e0 + shift - m; shift -= 2 * m }
        else if (on(s)) { sb.append(text, at, e0); at = e0; if (i == 0) ns = s0 + shift; ne = e0 + shift }
        else { sb.append(text, at, s0); sb.append(marker); sb.append(text, s0, e0); sb.append(marker); at = e0; if (i == 0) ns = s0 + shift + m; ne = e0 + shift + m; shift += 2 * m }
    }
    sb.append(text, at, text.length)
    return Triple(sb.toString(), ns, ne)
}

/** The index to cut a list of words in two so that no bold, highlight, color, link or code run is cut in half; as close to the middle as possible. -1 when there is none. */
fun balancedHalf(words: List<String>): Int {
    val mid = (words.size + 1) / 2
    fun balanced(n: Int): Boolean {
        val s = words.take(n).joinToString(" ")
        val noBold = s.replace("**", "")
        return (s.length - s.replace("**", "").length) / 2 % 2 == 0 && noBold.count { it == '*' } % 2 == 0 && s.split("~~").size % 2 == 1 &&
            s.split("==").size % 2 == 1 && s.count { it == '{' } == s.count { it == '}' } && s.count { it == '[' } == s.count { it == ']' } && s.count { it == '`' } % 2 == 0
    }
    for (d in 0..words.size) {
        if (mid - d in 1 until words.size && balanced(mid - d)) return mid - d
        if (mid + d in 1 until words.size && balanced(mid + d)) return mid + d
    }
    return -1
}
