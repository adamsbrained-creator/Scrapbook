package app.scrapbook

/**
 * What a sideways swipe on a page does (Scrapbook-UIO-44), copied from Paperback's step 30: a swipe to the right goes Back, and, when it is switched on, a swipe either way moves to the next or the
 * previous main page. This file holds the rules and has no Android in it, so they are tested on their own (NavSwipesTest); ui/SwipeNav.kt reads the finger and carries the move out.
 */
sealed class SwipeMove {
    /** The same as pressing Back: it closes a sheet or a Settings page that is open, and otherwise goes to the page before. */
    object Back : SwipeMove()
    /** Go to this main page (its route). */
    data class Main(val route: String) : SwipeMove()
}

/** What a swipe to the right and a swipe to the left do on the page that is open right now; null is nothing. */
data class SwipePlan(val right: SwipeMove?, val left: SwipeMove?) {
    val isEmpty: Boolean get() = right == null && left == null
}

object NavSwipes {
    /** The main pages in the order a swipe goes through them: Home, All scraps, Boxes, Settings. */
    val MAIN_PAGES = listOf("home", "scraps", "collections", "settings")

    /** Pages where a sideways drag already means something else (moving the cursor or the selection, drawing, cropping a picture), so a swipe never leaves them. */
    private val OWN_DRAGS = setOf("edit", "layouts", "draw", "capture", "account")

    /** How far a finger has to travel sideways, in dp, to count as a swipe; a shorter drag is a slip. */
    const val DISTANCE_DP = 80f

    /** A swipe counts when it is this many times further sideways than it is up or down, so scrolling that drifts a little never turns a page. */
    const val MIN_SIDEWAYS_OVER_VERTICAL = 2f

    /** "shelf/{name}" and "edit/12" are named by what comes before the first slash. */
    fun name(route: String?): String? = route?.substringBefore('/')?.substringBefore('?')

    fun isMain(route: String?): Boolean = name(route) in MAIN_PAGES

    fun usesOwnDrags(route: String?): Boolean = name(route) in OWN_DRAGS

    /** The main page [step] places along from [route] (-1 before, 1 after), or null at the ends and on pages that are not main pages. */
    fun neighbour(route: String?, step: Int): String? {
        val i = MAIN_PAGES.indexOf(name(route))
        return if (i < 0) null else MAIN_PAGES.getOrNull(i + step)
    }

    /**
     * What swiping does on [route]. [canGoBack] is whether there is a page before this one, [swipeBack] and [swipeTabs] are the two switches in Settings.
     * With [swipeTabs] on, a main page uses its swipes for the neighbouring main pages (and the ends do nothing), so a swipe to the right is not also Back there.
     */
    fun plan(route: String?, canGoBack: Boolean, swipeBack: Boolean, swipeTabs: Boolean): SwipePlan {
        if (route == null || usesOwnDrags(route)) return SwipePlan(null, null)
        val tabs = isMain(route) && swipeTabs
        val right = when {
            tabs -> neighbour(route, -1)?.let { SwipeMove.Main(it) }
            swipeBack && canGoBack -> SwipeMove.Back
            else -> null
        }
        val left = if (tabs) neighbour(route, 1)?.let { SwipeMove.Main(it) } else null
        return SwipePlan(right, left)
    }

    /** Which way a finished drag went: 1 to the right, -1 to the left, 0 if it was too short or too steep to be a swipe. [dx] and [dy] are in the same units as [distance]. */
    fun direction(dx: Float, dy: Float, distance: Float): Int {
        val ax = Math.abs(dx); val ay = Math.abs(dy)
        if (ax < distance || ax < ay * MIN_SIDEWAYS_OVER_VERTICAL) return 0
        return if (dx > 0f) 1 else -1
    }
}
