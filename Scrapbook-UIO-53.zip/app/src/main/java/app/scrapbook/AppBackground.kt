package app.scrapbook

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The page behind every screen (Settings > Look > Background): the plain page as always, a gradient between two colors you choose, or a slowly moving glow of a color you choose.
 * Colors are whole RGB numbers (0xRRGGBB). Only choices that differ from the usual are saved, as one short text in the settings. No Android in here, so the rules are tested on their own
 * (AppBackgroundTest); the drawing is in ui/BackgroundUi.kt.
 */
data class AppBackground(
    /** 0 the plain page (white, or Soft grey, or the dark page), 1 a gradient, 2 a glow. */
    val kind: Int = PLAIN,
    /** Gradient: the two colors and which way it runs (0 from the top down, 1 corner to corner, 2 from the bottom up). */
    val top: Int = DEFAULT_TOP,
    val bottom: Int = DEFAULT_BOTTOM,
    val direction: Int = 0,
    /** Glow: its color, whether it is one color (0) or that color with its two neighbors on the color wheel (1), how strong it is (0 soft, 1 usual, 2 strong) and how fast it drifts (0 still, 1 slow, 2 usual, 3 fast). */
    val glow: Int = DEFAULT_GLOW,
    val mix: Int = 1,
    val strength: Int = 1,
    val speed: Int = 2,
    /** How cards and grouped rows look on a background: 0 solid as always, 1 frosted (a veil of white over the background, the usual), 2 clear (a thinner veil). */
    val cards: Int = CARDS_FROSTED,
    /** Show the background behind the editor too (otherwise the editor keeps the plain page, where long text is read). */
    val inEditor: Boolean = false,
) {
    val active: Boolean get() = kind != PLAIN
    val isDefault: Boolean get() = this == AppBackground()

    fun clamped(): AppBackground = copy(
        kind = kind.coerceIn(0, 2), top = top and 0xFFFFFF, bottom = bottom and 0xFFFFFF, direction = direction.coerceIn(0, 2),
        glow = glow and 0xFFFFFF, mix = mix.coerceIn(0, 1), strength = strength.coerceIn(0, 2), speed = speed.coerceIn(0, 3), cards = cards.coerceIn(0, 2),
    )

    /**
     * Whether the page's text (near-white in dark mode, near-black in light mode) can be read on this background, judged from how light it is. A glow is judged as the page color
     * with the glow's color over it as strongly as it is drawn.
     */
    fun readable(dark: Boolean): Boolean {
        if (!active) return true
        val l = when (kind) {
            GRADIENT -> (AppBackgrounds.luminance(top) + AppBackgrounds.luminance(bottom)) / 2f
            else -> {
                val base = if (dark) 0.04f else 1f
                base + (AppBackgrounds.luminance(glow) - base) * minOf(1f, .5f * AppBackgrounds.strengthFactor(strength))
            }
        }
        return if (dark) l <= 0.55f else l >= 0.45f
    }

    /** The settings as one short text, a part for each choice that is not the usual one (`k=1;t=1D4E89;b=0B0B0B;gl=1`). */
    fun encode(): String {
        val d = AppBackground()
        val out = ArrayList<String>()
        if (kind != d.kind) out.add("k=$kind")
        if (top != d.top) out.add("t=" + AppBackgrounds.hex(top))
        if (bottom != d.bottom) out.add("b=" + AppBackgrounds.hex(bottom))
        if (direction != d.direction) out.add("d=$direction")
        if (glow != d.glow) out.add("g=" + AppBackgrounds.hex(glow))
        if (mix != d.mix) out.add("m=$mix")
        if (strength != d.strength) out.add("s=$strength")
        if (speed != d.speed) out.add("p=$speed")
        if (cards != d.cards) out.add("cd=$cards")
        if (inEditor) out.add("ed=1")
        return out.joinToString(";")
    }

    companion object {
        const val CARDS_SOLID = 0
        const val CARDS_FROSTED = 1
        const val CARDS_CLEAR = 2
        const val PLAIN = 0
        const val GRADIENT = 1
        const val GLOW = 2
        const val DEFAULT_TOP = 0x1D4E89
        const val DEFAULT_BOTTOM = 0x0B0B0B
        const val DEFAULT_GLOW = 0x4DA3FF

        /** Reads what [encode] wrote. A part that makes no sense is skipped and every number is kept in its limits. */
        fun decode(text: String?): AppBackground {
            var s = AppBackground()
            for (part in text.orEmpty().split(';')) {
                val eq = part.indexOf('=')
                if (eq <= 0) continue
                val k = part.substring(0, eq)
                val v = part.substring(eq + 1)
                val n = v.toIntOrNull()
                val c = AppBackgrounds.parseHex(v)
                when (k) {
                    "k" -> if (n != null) s = s.copy(kind = n)
                    "t" -> if (c != null) s = s.copy(top = c)
                    "b" -> if (c != null) s = s.copy(bottom = c)
                    "d" -> if (n != null) s = s.copy(direction = n)
                    "g" -> if (c != null) s = s.copy(glow = c)
                    "m" -> if (n != null) s = s.copy(mix = n)
                    "s" -> if (n != null) s = s.copy(strength = n)
                    "p" -> if (n != null) s = s.copy(speed = n)
                    "cd" -> if (n != null) s = s.copy(cards = n)
                    "ed" -> s = s.copy(inEditor = v == "1")
                }
            }
            return s.clamped()
        }
    }
}

object AppBackgrounds {
    /** Colors offered for a gradient's top (its bottom is dark): a warm brown like the reference, then blue, violet, green, rose, graphite. */
    val GRADIENT_PRESETS = listOf(0x6B5A4E, 0x1D4E89, 0x4B2F8C, 0x1F6B4F, 0x8C2F55, 0x3A3F47)
    /** Colors offered for a glow. */
    val GLOW_PRESETS = listOf(0x4DA3FF, 0x8B6BFF, 0xFF6FB1, 0x3CCB8E, 0xFFB020, 0xFF6B4A)

    /**
     * The veil a card is drawn as on a background: white over it, as strongly as [cards] says and as the mode needs (dark mode a faint white, light mode a frosted white, which
     * keeps dark text easy to read on a colored page). Null for solid cards, which keep the usual card color. Returned as the alpha of white.
     */
    fun veilAlpha(cards: Int, dark: Boolean): Float? = when (cards) {
        AppBackground.CARDS_FROSTED -> if (dark) .10f else .60f
        AppBackground.CARDS_CLEAR -> if (dark) .05f else .35f
        else -> null
    }

    /** How light a color is, 0 (black) to 1 (white). A simple weighted mix of its red, green and blue, enough to tell if text can be read on it. */
    fun luminance(rgb: Int): Float {
        val r = (rgb shr 16) and 0xFF
        val g = (rgb shr 8) and 0xFF
        val b = rgb and 0xFF
        return (0.299f * r + 0.587f * g + 0.114f * b) / 255f
    }

    /** The two colors next to [rgb] on the color wheel (40 degrees either way, same strength and lightness): what a glow mixes with. */
    fun companions(rgb: Int): Pair<Int, Int> {
        val (h, s, v) = toHsv(rgb)
        return fromHsv((h + 40f) % 360f, s, v) to fromHsv((h + 320f) % 360f, s, v)
    }

    /** How much stronger or weaker than usual a glow is drawn. */
    fun strengthFactor(strength: Int): Float = when (strength) { 0 -> 0.6f; 2 -> 1.5f; else -> 1f }

    /** How long a glow takes to drift one way, in milliseconds; 0 means it stands still. */
    fun periodMs(speed: Int): Int = when (speed) { 0 -> 0; 1 -> 14000; 3 -> 5000; else -> 9000 }

    fun hex(rgb: Int): String = "%06X".format(rgb and 0xFFFFFF)

    /** `#1D4E89`, `1d4e89` or `#14e` (each digit doubled) as a color; null if it is not one. */
    fun parseHex(text: String): Int? {
        val t = text.trim().removePrefix("#")
        if (t.isEmpty() || !t.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
        return when (t.length) {
            6 -> t.toInt(16)
            3 -> t.map { "$it$it" }.joinToString("").toInt(16)
            else -> null
        }
    }

    private fun toHsv(rgb: Int): Triple<Float, Float, Float> {
        val r = ((rgb shr 16) and 0xFF) / 255f
        val g = ((rgb shr 8) and 0xFF) / 255f
        val b = (rgb and 0xFF) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val d = max - min
        val h = when {
            d == 0f -> 0f
            max == r -> 60f * (((g - b) / d) % 6f)
            max == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }.let { if (it < 0f) it + 360f else it }
        return Triple(h, if (max == 0f) 0f else d / max, max)
    }

    private fun fromHsv(h: Float, s: Float, v: Float): Int {
        val c = v * s
        val x = c * (1f - abs((h / 60f) % 2f - 1f))
        val m = v - c
        val (r, g, b) = when ((h / 60f).toInt() % 6) {
            0 -> Triple(c, x, 0f)
            1 -> Triple(x, c, 0f)
            2 -> Triple(0f, c, x)
            3 -> Triple(0f, x, c)
            4 -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        fun ch(f: Float) = ((f + m) * 255f).roundToInt().coerceIn(0, 255)
        return (ch(r) shl 16) or (ch(g) shl 8) or ch(b)
    }
}
