package app.scrapbook

/**
 * Where the editor's small bubbles (the selection bubble and the link bubble) go, in the text field's own coordinates (y grows downward).
 *
 * The rules, in order: under the text (past the selection handles), so it never covers the words being selected; if there is no room under,
 * the page scrolls a little so there is (only when it can, and only a small step); if it cannot, above the text and above the phone's own
 * Copy / Paste bar (that bar sits right over the selection); and only when nothing fits (a selection as tall as the screen) the bubble sits
 * at the bottom edge of what is visible.
 */
object BubblePlace {
    enum class Side { Below, Above, Docked }

    /** top is where the bubble's top edge goes; scrollBy is how far the page should be scrolled down first (0 when it need not be). */
    data class Spot(val top: Float, val side: Side, val scrollBy: Float = 0f)

    fun place(
        selTop: Float, selBottom: Float, h: Float,
        visTop: Float, visBottom: Float,
        belowGap: Float, aboveGap: Float, clearAbove: Float,
        margin: Float, canScroll: Float, maxStep: Float,
    ): Spot {
        val belowTop = selBottom + belowGap
        val need = belowTop + h + margin - visBottom
        if (need <= 0f) return Spot(belowTop, Side.Below)
        if (need <= maxStep && need <= canScroll && selTop - need >= visTop + margin) return Spot(belowTop, Side.Below, need)
        val aboveTop = selTop - aboveGap - clearAbove - h
        if (aboveTop >= visTop + margin) return Spot(aboveTop, Side.Above)
        return Spot(maxOf(visTop + margin, visBottom - h - margin), Side.Docked)
    }

    /** For the link bubble: above the link first (it does not hide the line you are about to type on), under it when there is no room above, at the bottom edge only when neither fits. */
    fun placeAboveFirst(selTop: Float, selBottom: Float, h: Float, visTop: Float, visBottom: Float, belowGap: Float, aboveGap: Float, margin: Float): Spot {
        val aboveTop = selTop - aboveGap - h
        if (aboveTop >= visTop + margin) return Spot(aboveTop, Side.Above)
        val belowTop = selBottom + belowGap
        if (belowTop + h + margin <= visBottom) return Spot(belowTop, Side.Below)
        return Spot(maxOf(visTop + margin, visBottom - h - margin), Side.Docked)
    }

    /** Left edge of a bubble of width w centered at centerX, kept inside 0..fieldW. */
    fun left(centerX: Float, w: Float, fieldW: Float): Float = (centerX - w / 2f).coerceIn(0f, maxOf(0f, fieldW - w))
}
