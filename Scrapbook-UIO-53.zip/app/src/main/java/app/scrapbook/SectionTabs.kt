package app.scrapbook

import java.net.URLDecoder
import java.net.URLEncoder

// The tabs of a tabs card (see SectionCard.TABS): a row of pill tabs where each tab shows the scraps one rule finds. The Agenda skin is one section of this kind, drawn in the Agenda layout.
// A tab only POINTS at scraps through its rule, so nothing here ever moves, copies or deletes a scrap. Only rules live here (no Android), so they are tested on their own (AgendaTest).

/** One tab: its [label] and the [rule] of the scraps it shows (null is every scrap). */
data class SectionTab(val label: String, val rule: SectionRule? = null)

object SectionTabs {
    const val MIN_TABS = 1
    const val MAX_TABS = 4
    const val MAX_LABEL = 14

    /** The most scraps one tab shows (a smart section shows [SectionRule.MAX_SHOWN]; a tab is a whole page, so it shows more). */
    const val MAX_SHOWN = 20

    /** The three tabs a new tabs card starts with: the pinned scraps, all of them, and the ones with something still to do. */
    val DEFAULT: List<SectionTab> = listOf(
        SectionTab("Important", SectionRule(SectionRule.PINNED)),
        SectionTab("General"),
        SectionTab("Tasks", SectionRule(SectionRule.TASKS)),
    )

    /** A label as it is kept: one line, no |, trimmed and at most [MAX_LABEL] letters. */
    fun cleanLabel(s: String): String = s.replace('\n', ' ').replace('|', ' ').trim().take(MAX_LABEL).trim()

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    /** The tabs as the text a card keeps: one line for each, `rule|label`, the rule URL-encoded (empty for every scrap). */
    fun encode(tabs: List<SectionTab>): String = tabs.take(MAX_TABS).joinToString("\n") { enc(it.rule?.encode().orEmpty()) + "|" + cleanLabel(it.label) }

    /**
     * Reads what [encode] wrote. A line with no | is skipped, a tab with no label is called "Tab 1", "Tab 2" and so on, a rule that is not known shows every scrap, and at most [MAX_TABS] are kept.
     * Nothing readable gives an empty list (the card then uses [DEFAULT]).
     */
    fun parse(text: String?): List<SectionTab> {
        val out = ArrayList<SectionTab>()
        for (line in text.orEmpty().split('\n')) {
            val bar = line.indexOf('|')
            if (bar < 0 || out.size >= MAX_TABS) continue
            val rule = SectionRule.parse(dec(line.substring(0, bar)))
            out.add(SectionTab(cleanLabel(line.substring(bar + 1)).ifEmpty { "Tab ${out.size + 1}" }, rule))
        }
        return out
    }

    /** The place of the tab shown, kept inside the list ([index] may be left over from before a tab was taken away). */
    fun selected(tabs: List<SectionTab>, index: Int): Int = index.coerceIn(0, (tabs.size - 1).coerceAtLeast(0))

    fun renamed(tabs: List<SectionTab>, i: Int, label: String): List<SectionTab> =
        tabs.mapIndexed { n, t -> if (n == i) t.copy(label = cleanLabel(label)) else t }

    /** Tab [i] showing what [rule] finds (null is every scrap). The label changes too when [label] is given. */
    fun withRule(tabs: List<SectionTab>, i: Int, rule: SectionRule?, label: String? = null): List<SectionTab> =
        tabs.mapIndexed { n, t -> if (n == i) SectionTab(label?.let { cleanLabel(it) } ?: t.label, rule) else t }

    /** One more tab at the end, called "Tab 4" (or the next number not taken), showing every scrap. Nothing changes at [MAX_TABS]. */
    fun added(tabs: List<SectionTab>): List<SectionTab> {
        if (tabs.size >= MAX_TABS) return tabs
        var n = tabs.size + 1
        while (tabs.any { it.label == "Tab $n" }) n++
        return tabs + SectionTab("Tab $n")
    }

    /** Without tab [i]. The last tab is never taken away. */
    fun removed(tabs: List<SectionTab>, i: Int): List<SectionTab> = if (tabs.size <= MIN_TABS || i !in tabs.indices) tabs else tabs.filterIndexed { n, _ -> n != i }

    /** Tab [i] one place earlier ([dir] -1) or later (+1). At an end nothing changes. */
    fun moved(tabs: List<SectionTab>, i: Int, dir: Int): List<SectionTab> {
        val j = i + dir
        if (i !in tabs.indices || j !in tabs.indices || dir == 0) return tabs
        val m = tabs.toMutableList()
        m.add(j, m.removeAt(i))
        return m
    }

    /**
     * Where a new scrap started from a tab goes: the box a box tab shows (null is the Inbox) and the text it starts with ("#tag " for a tag tab, so it lands in the tab). Every other tab
     * starts an empty scrap in the Inbox.
     */
    fun starter(rule: SectionRule?): Pair<String?, String?> = when (rule?.kind) {
        SectionRule.BOX -> (if (rule.arg == "Inbox") null else rule.arg) to null
        SectionRule.TAG -> null to "#${rule.arg} "
        else -> null to null
    }

    /** Where the pill tabs sit ([SectionStyle.tabsBar]): docked to the screen, at the top of the section, or under the list inside the section. */
    const val BAR_DOCK = 0
    const val BAR_TOP = 1
    const val BAR_UNDER = 2

    /** The tabs card whose pill tabs are docked to the screen: the first one on the page that asks for it (only one bar can be docked, the others keep theirs inside their section). */
    fun dockHost(sections: List<HomeSection>): HomeSection? = sections.firstOrNull { it.isTabs && it.style.tabsBar == BAR_DOCK }

    /** Whether [rule] picks only pinned scraps, so a star on every row would say nothing. */
    fun onlyPinned(rule: SectionRule?): Boolean = rule?.kind == SectionRule.PINNED

    /**
     * Whether Home stops scrolling for a docked, page-filling section: only when the section has all the room it needs ([roomDp], what the page has left for it, is at least [minDp]) and
     * nothing comes after it ([belowDp] is the height of what does), so that nothing is out of reach and only the list inside the section moves.
     */
    fun pageLocked(roomDp: Int, belowDp: Int, minDp: Int): Boolean = roomDp >= minDp && belowDp <= 0
}
