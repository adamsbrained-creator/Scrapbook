package app.scrapbook

/**
 * The small rules behind the Slim shelf box style (Scrapbook-UIO-43), kept apart from the drawing (ui/BoxStyles.kt, ui/Browse.kt) so they can be tested on their own (BoxShelfRulesTest).
 *
 * Slim shelf: a box page shows its name and what it is, and the counts sit in the headings of the two things they count ("Boxes 11", "Scraps 6"). The boxes inside are slim chips on one
 * row that scrolls sideways, with See all to spread them out.
 */

/** The place of "Slim shelf" in BOX_STYLES, which is what Settings > Box style saves. Only ever add to the end of that list. */
const val SLIM_SHELF_STYLE = 7

/** Chips, Notebook covers and Slim shelf draw their own dashed "New box" button inside the boxes, so the separate one under them is left out. */
fun boxStyleDrawsOwnNewButton(style: Int): Boolean = style == 4 || style == 6 || style == SLIM_SHELF_STYLE

/** A row of slim chips shows about three at a time on a phone; from this many boxes on, See all is worth offering. */
const val SEE_ALL_FROM = 4

fun showSeeAll(boxCount: Int): Boolean = boxCount >= SEE_ALL_FROM

/** The number next to "Scraps": just the count, or "3 of 6" while a filter or a search leaves only some of them showing. */
fun scrapsHeadingCount(shown: Int, total: Int): String = if (shown == total) "$total" else "$shown of $total"
