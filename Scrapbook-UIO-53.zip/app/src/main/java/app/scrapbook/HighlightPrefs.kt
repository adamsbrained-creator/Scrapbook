package app.scrapbook

/**
 * What the highlighter (the "ab" tool, ==text==) is set to, for the whole app: its color (0 = the page's accent made bright, 1 to 5 = a ready color,
 * anything else = a color of your own, saved the way page colors are) and how strong it is (25 to 100 percent), so a highlight can be as soft as you like.
 */
object HighlightPrefs {
    const val MIN_OPACITY = 25
    const val DEFAULT_OPACITY = 100
    const val STEP = 5

    /** The ready colors (RGB): yellow, green, pink, blue, orange. */
    val PRESETS = listOf(0xFFE066, 0xA5E887, 0xFF9EC4, 0x8CCBFF, 0xFFB366)
    val NAMES = listOf("Page accent", "Yellow", "Green", "Pink", "Blue", "Orange")

    fun opacity(raw: Int): Int = raw.coerceIn(MIN_OPACITY, 100)

    /** A slider position (0 to 1) as a strength in whole steps of 5 percent, from 25 to 100. */
    fun fromSlider(v: Float): Int = opacity(MIN_OPACITY + Math.round(v.coerceIn(0f, 1f) * (100 - MIN_OPACITY) / STEP.toFloat()) * STEP)

    /** A strength as a slider position (0 to 1). */
    fun toSlider(percent: Int): Float = (opacity(percent) - MIN_OPACITY) / (100 - MIN_OPACITY).toFloat()

    /** The ready color for a saved choice 1 to 5, or null (0 is the accent, anything else is a color of your own). */
    fun preset(choice: Int): Int? = PRESETS.getOrNull(choice - 1)

    /** Whether dark ink is the one to use on a highlight whose color, as it looks on the page (the marker mixed into the page), has this luminance (0 to 1). */
    fun darkInk(blendedLuminance: Float): Boolean = blendedLuminance > .45f

    /** Mixes [fg] (0 to 1 per channel) into [bg] at [alpha]; used to judge how bright a soft highlight looks on the page. */
    fun blend(fg: Float, bg: Float, alpha: Float): Float = bg + (fg - bg) * alpha
}
