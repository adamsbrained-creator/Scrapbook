package app.scrapbook

/** The look of a stretch of text while it is read from another app's file (Word, Samsung Notes), and how that is written as Scrapbook's marks. */
internal class Fmt(val bold: Boolean = false, val italic: Boolean = false, val strike: Boolean = false, val underline: Boolean = false,
                  val highlight: Boolean = false, val color: String? = null, val link: String? = null) {
    override fun equals(other: Any?) = other is Fmt && bold == other.bold && italic == other.italic && strike == other.strike && underline == other.underline &&
        highlight == other.highlight && color == other.color && link == other.link
    override fun hashCode() = listOf(bold, italic, strike, underline, highlight, color, link).hashCode()
    val plain get() = !bold && !italic && !strike && !underline && !highlight && color == null
}

internal class Seg(var text: String, val fmt: Fmt)

/** Writing runs of text as Scrapbook markup: **bold**, *italic*, ~~strike~~, ==highlight==, {c:RRGGBB u|text} and [text](url). */
internal object Marks {
    fun merge(segs: List<Seg>): List<Seg> {
        val out = ArrayList<Seg>()
        for (s in segs) { if (s.text.isEmpty()) continue; val l = out.lastOrNull(); if (l != null && l.fmt == s.fmt) l.text += s.text else out.add(Seg(s.text, s.fmt)) }
        return out
    }

    fun emit(segs: List<Seg>): String {
        val sb = StringBuilder()
        for (s in segs) {
            if (s.text.isBlank() || (s.fmt.plain && s.fmt.link == null)) { sb.append(s.text); continue }
            val lead = s.text.takeWhile { it == ' ' || it == '\t' }; val trail = s.text.takeLast(s.text.length - lead.length).takeLastWhile { it == ' ' || it == '\t' }
            val core = s.text.substring(lead.length, s.text.length - trail.length)
            sb.append(lead).append(core.split('\n').joinToString("\n") { if (it.isBlank()) it else wrap(it, s.fmt) }).append(trail)
        }
        return sb.toString()
    }

    fun wrap(t: String, f: Fmt): String {
        var s = t
        if (f.strike) s = "~~$s~~"
        if (f.italic) s = "*$s*"
        if (f.bold) s = "**$s**"
        if (f.highlight) s = "==$s=="
        if (f.underline || f.color != null) s = "{" + listOfNotNull(f.color?.let { "c:$it" }, if (f.underline) "u" else null).joinToString(" ") + "|$s}"
        if (f.link != null) s = "[$s](${f.link})"
        return s
    }

    /** Black, dark grey and (almost) white are the page's ordinary ink (Samsung Notes writes its dark grey 252525 on everything), not a color somebody chose. */
    fun plainInk(hex: String): Boolean {
        val v = hex.toInt(16); val c = intArrayOf(v shr 16 and 255, v shr 8 and 255, v and 255)
        return c.max() <= 0x40 || c.min() >= 0xD0
    }
}
