package app.scrapbook

import java.util.zip.ZipInputStream

/**
 * Reads a Samsung Notes file (.sdocx) into a scrap: the title, the text with its look (bold, italic, underline, strikethrough, color, highlight, links), headings,
 * bulleted, numbered and checkbox lists with their depth, centered and right-aligned lines, the pictures that are in the text and the note's own dates.
 * Handwriting and drawings (the strokes on the pages) are not read, so a note that is only handwriting gives nothing.
 *
 * An .sdocx is a zip. Its note.note holds the title and the flowing text as little-endian binary frames; the layout used here follows the published
 * reverse-engineering notes of the format (github.com/twangodev/sdocx, file-format.md), checked against real files of Samsung Notes 4.4 (format 4000).
 * Anything that does not fit is left out rather than guessed: a part that cannot be read costs that part, not the whole note.
 */
object SdocxReader {
    private const val MAX_PART = 24 shl 20
    private val RASTER = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp")

    private class Fail(msg: String) : Exception(msg)

    private class Buf(val b: ByteArray, var p: Int = 0) {
        val left get() = b.size - p
        fun need(n: Int) { if (n < 0 || n > left) throw Fail("short data") }
        fun u8(): Int { need(1); return b[p++].toInt() and 255 }
        fun u16(): Int { need(2); val v = (b[p].toInt() and 255) or ((b[p + 1].toInt() and 255) shl 8); p += 2; return v }
        fun i16(): Int = u16().toShort().toInt()
        /** A 32-bit value that is a size or a count: more than Int's range is an error. */
        fun u32(): Int { need(4); val v = le32(b, p); p += 4; if (v < 0) throw Fail("size too large"); return v }
        fun raw32(): Int { need(4); val v = le32(b, p); p += 4; return v }
        fun i64(): Long { need(8); var v = 0L; for (i in 7 downTo 0) v = (v shl 8) or (b[p + i].toLong() and 255); p += 8; return v }
        fun bytes(n: Int): ByteArray { need(n); val r = b.copyOfRange(p, p + n); p += n; return r }
        fun utf16(units: Int): String { need(units * 2); val s = String(b, p, units * 2, Charsets.UTF_16LE); p += units * 2; return s }
        fun utf16u16(): String = utf16(u16())
        fun utf16u32(): String { val n = u32(); if (n > 8_000_000) throw Fail("text too long"); return utf16(n) }
    }

    private fun le32(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p + 1].toInt() and 255) shl 8) or ((b[p + 2].toInt() and 255) shl 16) or ((b[p + 3].toInt() and 255) shl 24)

    private class Frame(val kind: Int, val fields: ByteArray, val fixed: ByteArray, val flex: ByteArray) {
        fun has(bit: Int) = bit / 8 < fields.size && fields[bit / 8].toInt() and (1 shl (bit % 8)) != 0
    }

    private fun mask(r: Buf): ByteArray = r.bytes(r.u8())

    private fun frame(r: Buf): Frame {
        val size = r.u32(); if (size < 12) throw Fail("bad frame")
        val data = r.bytes(size - 4); val h = Buf(data)
        val kind = h.i16(); val flexOffset = h.u32(); mask(h); val fields = mask(h)
        val fixedEnd = if (flexOffset == 0 && fields.all { it.toInt() == 0 }) size else flexOffset
        if (fixedEnd < h.p + 4 || fixedEnd > size) throw Fail("bad frame offsets")
        return Frame(kind, fields, data.copyOfRange(h.p, fixedEnd - 4), data.copyOfRange(fixedEnd - 4, data.size))
    }

    private class Span(val kind: Int, val start: Int, val end: Int, val payload: ByteArray)
    private class Para(val kind: Int, val start: Long, val end: Long, val payload: ByteArray)
    private class Obj(val type: Int, val textIndex: Int, val data: ByteArray)
    private class Rich(val text: String, val spans: List<Span>, val paras: List<Para>, val objects: List<Obj>)

    fun read(bytes: ByteArray, fallbackTitle: String): ParsedNote? {
        var noteData: ByteArray? = null
        val media = HashMap<String, ByteArray>()
        try {
            ZipInputStream(bytes.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name
                    if (!e.isDirectory && (n == "note.note" || (n.startsWith("media/") && n.substringAfterLast('.').lowercase() in RASTER))) {
                        val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(16 * 1024); var total = 0; var ok = true
                        while (true) { val k = z.read(buf); if (k < 0) break; total += k; if (total > MAX_PART) { ok = false; break }; out.write(buf, 0, k) }
                        if (ok) { if (n == "note.note") noteData = out.toByteArray() else media[n.removePrefix("media/")] = out.toByteArray() }
                    }
                    e = z.nextEntry
                }
            }
        } catch (e: Exception) { if (noteData == null) return null }
        val data = noteData ?: return null

        val title: Rich; val body: Rich; val created: Long?; val modified: Long?
        try {
            val r = Buf(data)
            r.u32(); mask(r); mask(r)                       // where the optional fields start, then the two masks
            r.raw32(); r.utf16u16(); r.raw32()              // format, note id, revision
            val c = r.i64(); val m = r.i64()
            repeat(5) { r.raw32() }                         // size, paddings, minimum format
            title = textObject(r.bytes(r.u32()))
            body = textObject(r.bytes(r.u32()))
            created = millis(c); modified = millis(m)
        } catch (e: Exception) { return null }

        val lines = lines(body)
        val images = pictures(body, media)
        val text = collapseBlanks(lines).joinToString("\n").trim()
        if (text.isEmpty() && images.isEmpty()) return null
        val name = title.text.replace('￼', ' ').lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: fallbackTitle.trim()
        return ParsedNote(name.ifBlank { "Imported scrap" }.take(80), text, created, modified, images)
    }

    /** Microseconds since 1970 to milliseconds; null for zero or a time that cannot be right. */
    private fun millis(micro: Long): Long? = (micro / 1000).takeIf { it in 946_684_800_000L..4_102_444_800_000L }

    private fun textObject(data: ByteArray): Rich {
        val r = Buf(data)
        frame(r)                                            // the object's own data
        val shape = frame(r); val text = frame(r)
        if (shape.kind != 6 || text.kind != 7 || !text.has(0)) return Rich("", emptyList(), emptyList(), emptyList())
        val f = Buf(text.flex); val c = Buf(f.bytes(f.u32()))
        val s = c.utf16u32()
        val spans = ArrayList<Span>(); val paras = ArrayList<Para>(); val objs = ArrayList<Obj>()
        try {
            repeat(c.u32()) {
                val rec = Buf(c.bytes(c.u16())); val kind = rec.raw32(); val a = rec.raw32(); val b = rec.raw32(); rec.raw32()
                spans.add(Span(kind, a, b, rec.bytes(rec.left)))
            }
            repeat(c.u32()) {
                val rec = Buf(c.bytes(c.u16())); val kind = rec.raw32(); val a = rec.raw32().toLong() and 0xFFFFFFFFL; val b = rec.raw32().toLong() and 0xFFFFFFFFL
                paras.add(Para(kind, a, b, rec.bytes(rec.left)))
            }
            c.bytes(16); c.u8()                              // margins, gravity
            if (c.left >= 2) repeat(c.u16()) { c.raw32(); c.raw32() }   // page sections
            if (c.left >= 8) {
                val flags = c.raw32(); c.raw32()
                if (flags and 1 != 0) repeat(c.u32()) {
                    val sp = Buf(c.bytes(c.u32())); val size = sp.u32(); val type = sp.raw32()
                    val od = sp.bytes(size); val index = sp.raw32()
                    objs.add(Obj(type, index, od))
                }
            }
        } catch (e: Exception) { /* the text is kept; what could not be read after it is not */ }
        return Rich(s, spans, paras, objs)
    }

    // ---- text ----

    private fun lines(t: Rich): List<String> {
        val s = t.text; val n = s.length
        val bold = BooleanArray(n); val italic = BooleanArray(n); val under = BooleanArray(n); val strike = BooleanArray(n); val back = BooleanArray(n)
        val color = arrayOfNulls<String>(n); val link = arrayOfNulls<String>(n)
        for (sp in t.spans) {
            val a = sp.start.coerceIn(0, n); val b = sp.end.coerceIn(a, n)
            if (a == b) continue
            fun flag(arr: BooleanArray) { val v = sp.payload.size >= 2 && ((sp.payload[0].toInt() and 255) or ((sp.payload[1].toInt() and 255) shl 8)) == 1; for (i in a until b) arr[i] = v }
            when (sp.kind) {
                5 -> flag(bold); 6 -> flag(italic); 7 -> flag(under); 20 -> flag(strike)
                1 -> { val c = argb(sp.payload); val hex = if (c == null || c ushr 24 == 0) null else "%02x%02x%02x".format(c shr 16 and 255, c shr 8 and 255, c and 255)
                    val v = hex?.takeUnless { Marks.plainInk(it) }; for (i in a until b) color[i] = v }
                17 -> { val c = argb(sp.payload); val v = c != null && c ushr 24 != 0; for (i in a until b) back[i] = v }
                9 -> { val u = linkOf(sp.payload, s.substring(a, b)); for (i in a until b) link[i] = u }
            }
        }
        val bullets = HashMap<Int, Para>(); val indent = HashMap<Int, Int>(); val align = HashMap<Int, Int>(); val style = HashMap<Int, Int>()
        val count = s.count { it == '\n' || it == '\r' } + 1
        for (p in t.paras) {
            val from = p.start.coerceAtMost(count.toLong()).toInt(); val to = p.end.coerceAtMost(count.toLong()).toInt()
            for (i in from until to) when (p.kind) {
                5 -> bullets[i] = p
                2 -> u32At(p.payload, 0)?.let { indent[i] = it }
                3 -> u32At(p.payload, 0)?.let { align[i] = it }
                10 -> u32At(p.payload, 0)?.let { style[i] = it }
            }
        }

        val out = ArrayList<String>(); var start = 0; var ordinal = 0; var counter = 0; var lastNumbered = -2
        while (start <= n) {
            var end = start; while (end < n && s[end] != '\n' && s[end] != '\r') end++
            val segs = ArrayList<Seg>()
            for (i in start until end) {
                val ch = s[i]; if (ch == '￼' || (ch < ' ' && ch != '\t')) continue
                segs.add(Seg(ch.toString(), Fmt(bold[i], italic[i], strike[i], under[i], back[i], color[i], link[i])))
            }
            val body = Marks.emit(Marks.merge(segs)).trim()
            var prefix = ""
            val b = bullets[ordinal]
            if (body.isNotEmpty()) {
                val st = style[ordinal]
                if (st == 0) prefix = "# " else if (st == 1 || st == 2) prefix = "## "
                else if (b != null) {
                    val kind = u32At(b.payload, 0) ?: 0; val number = u32At(b.payload, 4) ?: 0; val checked = (u32At(b.payload, 8) ?: 0) != 0
                    prefix = when (kind) {
                        0 -> ""
                        2 -> if (checked) "- [x] " else "- [ ] "
                        4, 5, 6, 7, 10 -> "${if (number > 0) number else (if (lastNumbered == ordinal - 1) counter + 1 else 1)}. "
                        else -> "- "
                    }
                    if (kind in listOf(4, 5, 6, 7, 10)) { counter = if (number > 0) number else counter + 1; lastNumbered = ordinal }
                }
            }
            val tags = if (body.isEmpty()) "" else (indent[ordinal]?.takeIf { it in 1..4 && b != null }?.let { "{i:$it}" } ?: "") +
                (when (align[ordinal]) { 1 -> "{a:r}"; 2 -> "{a:c}"; else -> "" })
            out.add(if (body.isEmpty()) "" else prefix + tags + body)
            ordinal++; if (end >= n) break
            start = if (s[end] == '\r' && end + 1 < n && s[end + 1] == '\n') end + 2 else end + 1
            if (start > n) break
            if (start == n && s[end] == '\n' && end + 1 == n) { out.add(""); break }
        }
        return out
    }

    private fun collapseBlanks(lines: List<String>): List<String> {
        val out = ArrayList<String>(); var blank = 0
        for (l in lines) { if (l.isBlank()) { blank++; if (blank <= 2) out.add("") } else { blank = 0; out.add(l.trimEnd()) } }
        return out
    }

    private fun argb(p: ByteArray): Int? = if (p.size >= 4) le32(p, 0) else null
    private fun u32At(p: ByteArray, at: Int): Int? = if (p.size >= at + 4) le32(p, at) else null

    /** A link: the address stored with it, or the linked text itself when that is an address. Only http and https. */
    private fun linkOf(p: ByteArray, text: String): String? {
        val units = u32At(p, 8) ?: 0
        val stored = if (units > 0 && p.size >= 12 + units * 2) String(p, 12, units * 2, Charsets.UTF_16LE).trim() else ""
        return listOf(stored, text.trim()).firstOrNull { Regex("^https?://[^)\\s]+$").matches(it) }
    }

    // ---- pictures ----

    /** The pictures in the order they stand in the text, then any other pictures the note carries (placed on the page, not in the text). */
    private fun pictures(t: Rich, media: Map<String, ByteArray>): List<DocxImage> {
        val byId = HashMap<Int, String>()
        for (name in media.keys) name.substringBefore('@', "").toIntOrNull()?.let { byId.putIfAbsent(it, name) }
        val out = ArrayList<DocxImage>(); val used = HashSet<String>()
        fun add(name: String) { if (used.add(name)) out.add(DocxImage(name.substringAfter('@'), media.getValue(name))) }
        for (o in t.objects.sortedBy { it.textIndex }) {
            if (o.type != 3) continue
            val name = imageId(o.data)?.let { byId[it] } ?: continue
            add(name)
        }
        for (name in media.keys.sortedBy { it.substringBefore('@', "").toIntOrNull() ?: Int.MAX_VALUE }) {
            if (name.substringAfter('@').startsWith("page_")) continue   // the page's own picture of itself, not a photo
            add(name)
        }
        return out.take(60)
    }

    /** The media id an image object points at (its fill), or null. */
    private fun imageId(data: ByteArray): Int? = try {
        val r = Buf(data); frame(r); frame(r)
        val shape = frame(r); val f = Buf(shape.flex)
        if (shape.kind != 7) null else {
            if (shape.has(0)) f.bytes(f.u32())
            if (shape.has(1)) f.u8()
            if (shape.has(2)) f.raw32()
            if (shape.has(4)) f.raw32()
            if (!shape.has(5)) null else {
                val size = f.u32(); val kind = f.u8(); val fill = Buf(f.bytes(size))
                if (kind != 2) null else { fill.u8(); fill.raw32().takeIf { it >= 0 } }
            }
        }
    } catch (e: Exception) { null }
}
