package app.scrapbook

/**
 * How fast the page scrolls by itself while a finger drags a selection near the top or the bottom of what you can see (pixels per second, y growing downward).
 *
 * The finger sits at [y] from the top of the visible part of the page, which is [viewportH] tall. Inside the edge [zone] the page starts to move gently and gets quicker
 * the nearer the finger is to the edge (the speed grows with the square of the depth, so there is room to aim); at the edge it is fast, and a finger pushed past the edge,
 * onto the keyboard or the bar above it, goes faster still. Nothing here touches Android, so the rules are tested on their own (EdgeScrollTest).
 */
object EdgeScroll {
    const val MIN_SPEED = 120f
    const val MAX_SPEED = 2400f
    /** How much faster than [MAX_SPEED] a finger one whole zone beyond the edge goes (0.8 is 80 percent more). */
    const val BEYOND = 0.8f

    /** The size of each edge zone: [minZone] (a thumb's width or so) or a fifth of the visible page if that is more, never more than half of it so the two zones do not overlap. */
    fun zone(viewportH: Float, minZone: Float): Float = maxOf(minZone, viewportH * .2f).coerceAtMost(viewportH / 2f)

    /** Pixels per second to scroll by: negative (up) near the top, positive (down) near the bottom, 0 anywhere else. */
    fun speed(y: Float, viewportH: Float, zone: Float): Float {
        if (viewportH <= 0f || zone <= 0f) return 0f
        val top = y < viewportH / 2f
        // 0 at the inner border of the zone, 1 at the edge of the screen, more beyond it
        val depth = (if (top) zone - y else y - (viewportH - zone)) / zone
        if (depth <= 0f) return 0f
        val inZone = depth.coerceAtMost(1f)
        val beyond = 1f + BEYOND * (depth - 1f).coerceIn(0f, 1f)
        val s = (MIN_SPEED + (MAX_SPEED - MIN_SPEED) * inZone * inZone) * beyond
        return if (top) -s else s
    }
}
