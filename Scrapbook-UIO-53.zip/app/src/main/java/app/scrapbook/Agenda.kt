package app.scrapbook

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// The Agenda layout of a Home section: things grouped by the day they were last edited, each day under a heading like "13 Feb, Mon". This file is only the grouping (no Android),
// so it is tested on its own (AgendaTest); ui/AgendaParts.kt draws it.

/** One day of an agenda. [start] is the first millisecond of the day (null for the group of things that have no date, boxes), [heading] what is printed over it, [indices] the places in the grouped list, in the order they are shown. */
class AgendaGroup(val start: Long?, val heading: String, val indices: List<Int>)

object Agenda {
    /** The heading over the boxes of a section, which have no date. */
    const val UNDATED = "Boxes"

    /** The first millisecond of the day [ms] falls in. */
    fun dayStart(ms: Long, zone: TimeZone = TimeZone.getDefault()): Long {
        val c = Calendar.getInstance(zone)
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** The heading of a day: "13 Feb, Mon". */
    fun heading(ms: Long, zone: TimeZone = TimeZone.getDefault(), locale: Locale = Locale.getDefault()): String {
        val f = SimpleDateFormat("d MMM, EEE", locale)
        f.timeZone = zone
        return f.format(Date(ms))
    }

    /**
     * [times] are the times of the things to show, in the order they came (null for a thing with no date, a box). They come out in groups: the undated ones first (in their own order),
     * then one group for each day, the newest day first (or the oldest, with [oldFirst]); inside a day the newest thing is first (the oldest, with [oldFirst]). Every place of [times] is in exactly one group.
     */
    fun groups(times: List<Long?>, oldFirst: Boolean = false, zone: TimeZone = TimeZone.getDefault(), locale: Locale = Locale.getDefault()): List<AgendaGroup> {
        val out = ArrayList<AgendaGroup>()
        val undated = times.indices.filter { times[it] == null }
        if (undated.isNotEmpty()) out.add(AgendaGroup(null, UNDATED, undated))
        val byDay = LinkedHashMap<Long, MutableList<Int>>()
        times.forEachIndexed { i, t -> if (t != null) byDay.getOrPut(dayStart(t, zone)) { ArrayList() }.add(i) }
        val days = byDay.keys.sortedWith(if (oldFirst) compareBy<Long> { it } else compareByDescending<Long> { it })
        for (d in days) {
            val inside = byDay.getValue(d).sortedWith(if (oldFirst) compareBy<Int> { times[it]!! }.thenBy { it } else compareByDescending<Int> { times[it]!! }.thenBy { it })
            out.add(AgendaGroup(d, heading(d, zone, locale), inside))
        }
        return out
    }

    /** The places of all the groups one after the other: the order of the things when no day headings are shown. */
    fun flat(groups: List<AgendaGroup>): List<Int> = groups.flatMap { it.indices }
}
