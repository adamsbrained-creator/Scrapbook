package app.scrapbook

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * The launcher icon is one you choose (Settings > Look & Feel > App's icon): one of [choices], normal or glassy. Android can't change an icon in place, so the manifest has one
 * <activity-alias> per icon and style (".IconWordmarkGlassy", ".IconWordmarkFlat", ".IconCutoutGlassy", ...), each with its own icon, and exactly one is enabled at a time.
 * The glassy wordmark is the default and starts enabled in the manifest. The names here are the ones in the manifest and in the resources (ic_<key in lower case>_<glassy|flat>).
 */
object AppIcon {
    /** One icon you can choose. [key] is part of the names of its two launcher entries (Icon + key + Glassy or Flat). */
    class Choice(val key: String, val label: String, val about: String)

    val choices = listOf(
        Choice("Wordmark", "Scrap|", "The name in the app's own font, with a text cursor."),
        Choice("Cutout", "Cut-out S", "A letter S snipped from a paper strip."),
        Choice("Sticky", "Peeling sticky", "A sticky note lifting at one corner."),
        Choice("Ripped", "Ripped in two", "A scrap of paper torn in two."),
    )

    const val DEFAULT_KEY = "Wordmark"
    const val DEFAULT_GLASSY = true

    /** [key] if it is one of the icons, otherwise the default one. */
    fun keyOrDefault(key: String?): String = choices.firstOrNull { it.key == key }?.key ?: DEFAULT_KEY

    /** The name of the launcher entry (the alias in the manifest) for an icon and a style. */
    fun alias(key: String, glassy: Boolean): String = "Icon" + keyOrDefault(key) + if (glassy) "Glassy" else "Flat"

    /** Every launcher entry there is: two for each icon. */
    val aliases: List<String> get() = choices.flatMap { listOf(alias(it.key, true), alias(it.key, false)) }

    /** The picture of an icon for the picker (ic_<key>_<style> as a small image). */
    fun preview(key: String, glassy: Boolean): Int = when (keyOrDefault(key)) {
        "Cutout" -> if (glassy) R.drawable.icon_preview_cutout_glassy else R.drawable.icon_preview_cutout_flat
        "Sticky" -> if (glassy) R.drawable.icon_preview_sticky_glassy else R.drawable.icon_preview_sticky_flat
        "Ripped" -> if (glassy) R.drawable.icon_preview_ripped_glassy else R.drawable.icon_preview_ripped_flat
        else -> if (glassy) R.drawable.icon_preview_wordmark_glassy else R.drawable.icon_preview_wordmark_flat
    }

    /** Shows the icon [key] in the style [glassy] and hides the others. Does nothing if it is already showing. */
    fun apply(ctx: Context, key: String, glassy: Boolean) {
        val pm = ctx.packageManager
        val want = alias(key, glassy)
        val start = alias(DEFAULT_KEY, DEFAULT_GLASSY)
        fun comp(name: String) = ComponentName(ctx.packageName, "app.scrapbook.$name")
        fun on(name: String): Boolean = when (pm.getComponentEnabledSetting(comp(name))) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED -> false
            else -> name == start // never touched: the manifest starts with the default enabled and the rest disabled
        }
        runCatching {
            // Turn the new one on first, so there is never a moment with no launcher icon at all.
            if (!on(want)) pm.setComponentEnabledSetting(comp(want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            aliases.filter { it != want && on(it) }.forEach {
                pm.setComponentEnabledSetting(comp(it), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            }
        }
    }
}
