package app.scrapbook

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sign

/**
 * How the editor's page scrolls to keep the cursor in view while you type (all in pixels, y growing downward).
 *
 * [goal] says whether the cursor is outside the comfortable part of the screen and where the page should be scrolled to; [step] is one frame of getting there:
 * a share of what is left, so it glides in fast and settles softly, and since it depends only on where the page is now (there is no speed to carry over) a new goal
 * in the middle of the glide, from the next letter you type, just bends it, with no stop and start. [rate] is how quick, from the Settings choice.
 */
object CaretFollow {
    val SPEEDS = listOf("Calm", "Normal", "Quick", "Instant")
    const val DEFAULT = 1

    /** The share of the distance covered per second as an exponential rate (about 95 percent after 3 / rate seconds), or null for Instant (jump at once). */
    fun rate(speed: Int): Float? = when (speed) { 0 -> 7f; 1 -> 14f; 2 -> 28f; 3 -> null; else -> 14f }

    fun speed(raw: Int): Int = raw.coerceIn(0, SPEEDS.lastIndex)

    /**
     * Where to scroll to so the cursor (from [caretTop] to [caretBottom], measured from the top of the whole page) is comfortably in view, or null when it already is:
     * not nearer than [bottomMargin] to the bottom of what you can see, nor than [topMargin] to the top. The page never scrolls above its start.
     */
    fun goal(caretTop: Float, caretBottom: Float, scrollY: Float, viewportH: Float, topMargin: Float, bottomMargin: Float): Float? {
        val want = when {
            caretBottom > scrollY + viewportH - bottomMargin -> caretBottom - viewportH + bottomMargin
            caretTop < scrollY + topMargin -> caretTop - topMargin
            else -> return null
        }.coerceAtLeast(0f)
        return if (abs(want - scrollY) < 1f) null else want
    }

    /** How far to move this frame, [left] being what remains and [dt] the time since the last frame in seconds. Never past the goal, never less than a pixel (so it ends). */
    fun step(left: Float, rate: Float, dt: Float): Float {
        if (abs(left) <= 1f) return left
        val s = left * (1f - exp(-rate * dt.coerceIn(0.001f, 0.05f)))
        return if (abs(s) < 1f) sign(left) * min(1f, abs(left)) else s
    }
}
