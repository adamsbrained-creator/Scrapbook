package app.scrapbook.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

/**
 * The looks of the Boxes screen, chosen with the switcher next to the Inbox chip. The position in this list is what gets saved, so only ever add to the end.
 * 0 is the original card grid, drawn by CollectionsScreen in Shelves.kt; 1 to 4 are drawn here.
 */
class BoxesView(val label: String, val hint: String)
val BOXES_VIEWS = listOf(
    BoxesView("Default", "Cards with covers"), BoxesView("Nested", "Boxes inside their parent"), BoxesView("Shelf", "Compact rows"),
    BoxesView("Cover", "Bold color covers"), BoxesView("Stack", "Layered cards"),
)

private fun scrapCount(n: Int) = if (n == 1) "1 scrap" else "$n scraps"
private fun boxCount(n: Int) = if (n == 1) "1 box" else "$n boxes"
/** "3 scraps", or "3 scraps · 2 boxes" when the box has boxes inside it. */
private fun countLine(n: Int, boxes: Int) = scrapCount(n) + if (boxes > 0) " · " + boxCount(boxes) else ""
private fun tabOf(s: Shelf): Color = TAB_COLORS[s.color.mod(TAB_COLORS.size)]
private fun Modifier.boxDesc(name: String, count: Int): Modifier = semantics(mergeDescendants = true) { contentDescription = "$name, ${scrapCount(count)}" }

/** Text that sits on a solid box color. Fixed, so it stays readable in the dark theme too. */
private val CoverInk = Color(0xFF121212)

// ---------------------------------------------------------------------------------------------------------------------------------
// The view switcher
// ---------------------------------------------------------------------------------------------------------------------------------

/** The little line icon for each view, drawn in code like the rest of the icons. view is an index into BOXES_VIEWS. */
@Composable
private fun ViewIcon(view: Int, dp: Dp, ink: Color, accent: Color, fill: Color) {
    Canvas(Modifier.size(dp)) {
        val k = size.width / 24f
        val sw = 1.6f * k
        fun rect(x: Float, y: Float, w: Float, h: Float, r: Float, color: Color = ink, filled: Boolean = false) =
            drawRoundRect(color, Offset(x * k, y * k), Size(w * k, h * k), CornerRadius(r * k), style = if (filled) Fill else Stroke(sw, cap = StrokeCap.Round))
        fun dot(x: Float, y: Float, r: Float) = drawCircle(accent, r * k, Offset(x * k, y * k))
        fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Color = ink, w: Float = sw) =
            drawLine(color, Offset(x1 * k, y1 * k), Offset(x2 * k, y2 * k), strokeWidth = w, cap = StrokeCap.Round)
        when (view) {
            1 -> {
                rect(3.5f, 3.5f, 17f, 17f, 4.8f)
                rect(7f, 7f, 4f, 4f, 1.3f, accent, true); rect(13f, 7f, 4f, 4f, 1.3f)
                rect(7f, 13f, 4f, 4f, 1.3f); rect(13f, 13f, 4f, 4f, 1.3f, accent, true)
            }
            2 -> {
                rect(3.5f, 4.2f, 17f, 4.6f, 2.3f); rect(7f, 10f, 13.5f, 4.6f, 2.3f); rect(7f, 15.8f, 13.5f, 4.6f, 2.3f)
                dot(6.4f, 6.5f, 1.2f); dot(10.2f, 12.3f, 1.2f); dot(10.2f, 18.1f, 1.2f)
                line(9.5f, 6.5f, 16.5f, 6.5f); line(13.3f, 12.3f, 17.5f, 12.3f); line(13.3f, 18.1f, 17.5f, 18.1f)
            }
            3 -> {
                rect(3.5f, 3.5f, 7.5f, 10f, 2.2f, accent, true)
                rect(3.5f, 15.5f, 7.5f, 5f, 2.2f); rect(13f, 3.5f, 7.5f, 5.5f, 2.2f); rect(13f, 11f, 7.5f, 9.5f, 2.2f)
            }
            4 -> {
                rect(6f, 3.2f, 12f, 6f, 2.2f, fill, true); rect(6f, 3.2f, 12f, 6f, 2.2f)
                rect(4.5f, 7.2f, 15f, 6f, 2.2f, fill, true); rect(4.5f, 7.2f, 15f, 6f, 2.2f)
                rect(3f, 11.4f, 18f, 9.2f, 2.6f, fill, true); rect(3f, 11.4f, 18f, 9.2f, 2.6f)
                dot(6.8f, 16f, 1.3f); line(10f, 16f, 16.2f, 16f)
            }
            else -> {
                rect(3.5f, 4.5f, 7.5f, 7f, 2.2f); rect(13f, 4.5f, 7.5f, 7f, 2.2f); rect(3.5f, 13f, 7.5f, 7f, 2.2f); rect(13f, 13f, 7.5f, 7f, 2.2f)
                line(6.2f, 4.5f, 8.3f, 4.5f, accent, 2.8f * k); line(15.7f, 4.5f, 17.8f, 4.5f, accent, 2.8f * k)
                line(6.2f, 13f, 8.3f, 13f, accent, 2.8f * k); line(15.7f, 13f, 17.8f, 13f, accent, 2.8f * k)
            }
        }
    }
}

/** The pill at the right of the chip row: shows the current view's icon, and opens a menu to pick another one. */
@Composable
fun BoxesViewSwitcher(selected: Int, onPick: (Int) -> Unit) {
    val acc = LocalSb.current.acc
    val cur = selected.coerceIn(0, BOXES_VIEWS.lastIndex)
    var open by remember { mutableStateOf(false) }
    val pill = lerp(Sb.paper, Sb.line, .5f)
    val pillOn = lerp(Sb.paper, acc, .22f)
    Box {
        Box(Modifier.size(64.dp, 44.dp).tapIcon("Change view, current: ${BOXES_VIEWS[cur].label}") { open = true }, Alignment.Center) {
            Row(Modifier.height(34.dp).clip(RoundedCornerShape(17.dp)).background(if (open) pillOn else pill).padding(start = 10.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                ViewIcon(cur, 22.dp, Sb.ink, acc, if (open) pillOn else pill)
                Spacer(Modifier.width(2.dp))
                Ic("chevdown", 18.dp, Sb.mute)
            }
        }
        PopupMenu(open, { open = false }) {
            BOXES_VIEWS.forEachIndexed { i, v ->
                PopupItem(v.label, sub = v.hint, checked = i == cur,
                    leading = { Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(pill), Alignment.Center) { ViewIcon(i, 24.dp, Sb.ink, acc, pill) } }) { open = false; onPick(i) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Shared pieces
// ---------------------------------------------------------------------------------------------------------------------------------

/** The box's cover as a small tilted photo, or the flat placeholder picture when it has none. */
@Composable
private fun CoverThumb(s: Shelf, w: Dp, h: Dp, tilt: Float) {
    ItemImage(coverOf(s), Modifier.size(w, h).rotate(tilt).border(2.dp, Color.White, RoundedCornerShape(10.dp)), 10.dp)
}

/** The colored tab hanging off the top edge of a card. */
@Composable
private fun BoxScope.ColorTab(color: Color) {
    Box(Modifier.align(Alignment.TopEnd).padding(end = 22.dp).width(34.dp).height(9.dp).clip(RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)).background(color))
}

@Composable
private fun EditLink(s: Shelf, onEdit: (Shelf) -> Unit) {
    Text("Edit", fontSize = 13.sp, color = accentText(LocalSb.current.acc), modifier = Modifier.link("Edit ${s.label}") { onEdit(s) })
}

/** The dashed "New box" button at the bottom of the Nested view. */
@Composable
private fun NewBoxButton(onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(Modifier.fillMaxWidth().height(56.dp).clip(shape).dashedOutline(Sb.mute.copy(alpha = .5f), shape).tap("New box", onClick), Arrangement.Center, Alignment.CenterVertically) {
        Ic("plus", 20.dp, Sb.mute); Spacer(Modifier.width(8.dp)); Text("New box", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Nested: a box that has boxes inside it shows them as a grid inside its own card
// ---------------------------------------------------------------------------------------------------------------------------------

@Composable
fun BoxesNested(shelves: List<Shelf>, counts: Map<String, Int>, onOpen: (String) -> Unit, onHold: (String) -> Unit, onEdit: (Shelf) -> Unit, onNew: () -> Unit) {
    Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
        shelves.topLevel().forEach { s ->
            val kids = shelves.childrenOf(s.name); val n = counts[s.name] ?: 0
            if (kids.isEmpty()) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.surface)) {
                    ColorTab(tabOf(s))
                    Row(Modifier.fillMaxWidth().tapOrHold("Open ${s.label}", "Delete box", { onHold(s.name) }) { onOpen(s.name) }.boxDesc(s.label, n).padding(16.dp),
                        Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.label, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(countLine(n, LocalShelves.current.childrenOf(s.name).size), fontSize = 13.sp, color = Sb.mute)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) { EditLink(s, onEdit); Spacer(Modifier.width(6.dp)); CoverThumb(s, 36.dp, 44.dp, 6f) }
                    }
                }
            } else {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.surface)) {
                    ColorTab(tabOf(s))
                    Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 20.dp, bottom = 14.dp)) {
                        Row(Modifier.fillMaxWidth().tapOrHold("Open ${s.label}", "Delete box", { onHold(s.name) }) { onOpen(s.name) }.boxDesc(s.label, n).padding(horizontal = 2.dp),
                            Arrangement.SpaceBetween, Alignment.Top) {
                            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                                Text(s.label, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 30.sp, lineHeight = 33.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${scrapCount(n)} · ${boxCount(kids.size)}", fontSize = 13.sp, color = Sb.mute, modifier = Modifier.padding(top = 4.dp))
                                if (s.description.isNotBlank()) Text(s.description, fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) { CoverThumb(s, 48.dp, 58.dp, 6f); EditLink(s, onEdit) }
                        }
                        Spacer(Modifier.height(10.dp))
                        Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                            kids.chunked(2).forEach { pair ->
                                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                                    pair.forEach { k ->
                                        val kn = counts[k.name] ?: 0
                                        Row(Modifier.weight(1f).height(56.dp).clip(RoundedCornerShape(18.dp)).background(Sb.line.copy(alpha = if (Sb.dark) .9f else .6f))
                                            .tapOrHold("Open ${k.label}", "Delete box", { onHold(k.name) }) { onOpen(k.name) }.boxDesc(k.label, kn).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(10.dp).clip(CircleShape).background(tabOf(k))); Spacer(Modifier.width(10.dp))
                                            Text(k.label, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                            Text("$kn", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (kn > 0) Sb.ink else Sb.mute)
                                        }
                                    }
                                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
        NewBoxButton(onNew)
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Shelf: one compact row per box, with the boxes inside a box indented under it
// ---------------------------------------------------------------------------------------------------------------------------------

@Composable
fun BoxesShelf(shelves: List<Shelf>, counts: Map<String, Int>, onOpen: (String) -> Unit, onHold: (String) -> Unit) {
    Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
        shelves.inTreeOrder().forEach { (s, depth) ->
            val n = counts[s.name] ?: 0
            Row(Modifier.padding(start = 16.dp * depth.coerceIn(0, 3)).fillMaxWidth().height(if (depth > 0) 62.dp else 68.dp).clip(RoundedCornerShape(20.dp)).background(Sb.surface)
                .tapOrHold("Open ${s.label}", "Delete box", { onHold(s.name) }) { onOpen(s.name) }.boxDesc(s.label, n).padding(start = 12.dp, end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                CoverThumb(s, 34.dp, 42.dp, 5f)
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(s.label, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (s.description.isNotBlank()) Text(s.description, fontSize = 12.5.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("$n", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp, color = if (n > 0) tabOf(s) else Sb.mute)
                    Text(if (n == 1) "scrap" else "scraps", fontSize = 11.sp, color = Sb.mute)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Cover: two staggered columns of bold color covers. A box with scraps is solid color, an empty one is just outlined.
// ---------------------------------------------------------------------------------------------------------------------------------

private val COVER_HEIGHTS = listOf(176, 200, 160, 214, 188, 170)

@Composable
private fun CoverCard(s: Shelf, minHeight: Dp, n: Int, onOpen: (String) -> Unit, onHold: (String) -> Unit) {
    val c = tabOf(s); val filled = n > 0
    val fg = if (filled) CoverInk else Sb.ink; val sub = if (filled) CoverInk else Sb.mute
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().heightIn(min = minHeight).clip(shape).background(if (filled) c else Sb.card).border(2.dp, c, shape)
        .tapOrHold("Open ${s.label}", "Delete box", { onHold(s.name) }) { onOpen(s.name) }.boxDesc(s.label, n).padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 12.dp),
        Arrangement.SpaceBetween) {
        Column {
            Text(s.label, fontFamily = headFont(), fontWeight = FontWeight.SemiBold, fontSize = 23.sp, lineHeight = 25.sp, color = fg, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(countLine(n, LocalShelves.current.childrenOf(s.name).size), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = sub, modifier = Modifier.padding(top = 4.dp))
            if (s.parent.isNotBlank()) Text("in ${LocalShelves.current.pathOf(s.parent)}", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = if (filled) c else CoverInk, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 10.dp).clip(CircleShape).background(if (filled) CoverInk else c).padding(horizontal = 10.dp, vertical = 3.dp))
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), Arrangement.SpaceBetween, Alignment.Bottom) {
            if (s.description.isNotBlank()) Text(s.description, fontSize = 13.sp, lineHeight = 17.sp, color = sub, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(end = 8.dp))
            else Spacer(Modifier.weight(1f))
            CoverThumb(s, 56.dp, 68.dp, 8f)
        }
    }
}

@Composable
fun BoxesCover(shelves: List<Shelf>, counts: Map<String, Int>, onOpen: (String) -> Unit, onHold: (String) -> Unit) {
    val all = shelves.inTreeOrder().map { it.first }
    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp), Alignment.Top) {
        // The right column starts a little lower, so the covers stagger like books on a shelf.
        Column(Modifier.weight(1f), Arrangement.spacedBy(12.dp)) {
            all.forEachIndexed { i, s -> if (i % 2 == 0) CoverCard(s, COVER_HEIGHTS[i % COVER_HEIGHTS.size].dp, counts[s.name] ?: 0, onOpen, onHold) }
        }
        Column(Modifier.weight(1f).padding(top = 28.dp), Arrangement.spacedBy(12.dp)) {
            all.forEachIndexed { i, s -> if (i % 2 == 1) CoverCard(s, COVER_HEIGHTS[i % COVER_HEIGHTS.size].dp, counts[s.name] ?: 0, onOpen, onHold) }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Stack: layered cards. Tap a card's strip to bring it to the front, where it opens up to show its details.
// ---------------------------------------------------------------------------------------------------------------------------------

@Composable
fun BoxesStack(shelves: List<Shelf>, counts: Map<String, Int>, onOpen: (String) -> Unit, onHold: (String) -> Unit, onEdit: (Shelf) -> Unit) {
    val ordered = shelves.inTreeOrder().map { it.first }
    if (ordered.isEmpty()) return
    var front by rememberSaveable { mutableStateOf<String?>(null) }
    val frontName = ordered.firstOrNull { it.name == front }?.name ?: ordered.first().name
    // The front box is drawn last, so it sits on top of all the others.
    val items = ordered.filter { it.name != frontName } + ordered.filter { it.name == frontName }
    val step = 46.dp; val backHeight = 150.dp; val frontHeight = 196.dp
    val shape = RoundedCornerShape(26.dp)
    val base = if (Sb.dark) Color(0xFF141414) else Color.White
    Box(Modifier.fillMaxWidth().height(step * (items.size - 1) + frontHeight + 8.dp)) {
        items.forEachIndexed { i, s ->
            val isFront = i == items.lastIndex; val n = counts[s.name] ?: 0; val c = tabOf(s)
            Box(Modifier.offset(y = step * i).fillMaxWidth().height(if (isFront) frontHeight else backHeight).shadow(6.dp, shape, clip = false).clip(shape)
                .background(lerp(base, c, .22f)).border(1.dp, lerp(base, c, .45f), shape)) {
                if (isFront) {
                    Column(Modifier.fillMaxSize().tapOrHold("Open ${s.label}", "Delete box", { onHold(s.name) }) { onOpen(s.name) }.boxDesc(s.label, n)) {
                        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).clip(CircleShape).background(c)); Spacer(Modifier.width(10.dp))
                                Text(s.label, fontFamily = headFont(), fontSize = 26.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(countLine(n, LocalShelves.current.childrenOf(s.name).size), fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 12.dp))
                        }
                        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 8.dp), Arrangement.SpaceBetween, Alignment.Bottom) {
                            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                                if (s.parent.isNotBlank()) Text("in ${LocalShelves.current.pathOf(s.parent)}", fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (s.description.isNotBlank()) Text(s.description, fontSize = 15.sp, lineHeight = 20.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Open", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = accentText(LocalSb.current.acc), modifier = Modifier.link("Open ${s.label}") { onOpen(s.name) })
                                    Spacer(Modifier.width(6.dp))
                                    Text("Edit", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = accentText(LocalSb.current.acc), modifier = Modifier.link("Edit ${s.label}") { onEdit(s) })
                                }
                            }
                            Box(Modifier.padding(bottom = 14.dp)) { CoverThumb(s, 62.dp, 76.dp, 6f) }
                        }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().height(step).tapOrHold("Bring ${s.label} to the front", "Delete box", { onHold(s.name) }) { front = s.name }.boxDesc(s.label, n).padding(horizontal = 20.dp),
                        Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(c)); Spacer(Modifier.width(10.dp))
                            Text(s.label, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            if (s.parent.isNotBlank()) Text("in ${LocalShelves.current.pathOf(s.parent)}", fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp))
                        }
                        Text(countLine(n, LocalShelves.current.childrenOf(s.name).size), fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (n > 0) Sb.ink else Sb.mute, modifier = Modifier.padding(start = 12.dp))
                    }
                }
            }
        }
    }
}
