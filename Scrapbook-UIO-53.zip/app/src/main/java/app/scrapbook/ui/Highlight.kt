package app.scrapbook.ui

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import app.scrapbook.CustomColors
import app.scrapbook.HighlightPrefs
import app.scrapbook.matchRanges

/** [text] with every occurrence of the search [terms] marked. With no terms it is just the text. */
fun hlTerms(text: String, terms: List<String>, mark: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    matchRanges(text, terms).forEach { r ->
        append(text.substring(i, r.first))
        withStyle(SpanStyle(background = mark)) { append(text.substring(r.first, r.last + 1)) }
        i = r.last + 1
    }
    append(text.substring(i))
}

/** The ink of highlighted text: dark on the bright marker, on a light page and on a dark one alike. */
val MARKER_INK = Color(0xFF181818)

/** What the highlighter is set to (see HighlightPrefs): [color] 0 = the page's accent made bright, 1 to 5 a ready color, else a color of your own; [opacity] 25 to 100 percent. */
data class Marker(val color: Int = 0, val opacity: Int = HighlightPrefs.DEFAULT_OPACITY)

/** The highlighter of the page being drawn (the reading view provides it from the page; the editor passes its own). */
val LocalMarker = compositionLocalOf { Marker() }

/**
 * The highlighter's own color, before its strength: with the accent (the default) it is the page's accent made bright and clear, the same solid color on a light
 * page and a dark one, so a highlight looks alike in both; a ready color or a color of your own is used as it is.
 */
fun markerBase(acc: Color, mk: Marker = Marker()): Color = when {
    mk.color <= 0 -> accentMarker(acc)
    CustomColors.isCustom(mk.color) -> rgbColor(CustomColors.rgb(mk.color))
    else -> HighlightPrefs.preset(mk.color)?.let { rgbColor(it) } ?: accentMarker(acc)
}

private fun accentMarker(acc: Color): Color {
    val hsv = FloatArray(3); android.graphics.Color.colorToHSV(acc.toArgb(), hsv)
    hsv[1] = if (hsv[1] < .08f) hsv[1] else hsv[1].coerceIn(.45f, .7f)   // a gray accent stays gray; a colored one gets vivid
    hsv[2] = 1f
    var c = Color(android.graphics.Color.HSVToColor(hsv))
    var k = 0f
    while (c.luminance() < .45f && k < .6f) { k += .1f; c = lerp(Color(android.graphics.Color.HSVToColor(hsv)), Color.White, k) }   // deep blues and purples are lightened until dark ink reads on them
    return c
}

/** The color drawn behind highlighted text: the base color at the chosen strength. */
fun markerColor(acc: Color, mk: Marker = Marker()): Color = markerBase(acc, mk).copy(alpha = HighlightPrefs.opacity(mk.opacity) / 100f)

/**
 * The look of highlighted text: the marker behind it and, when the highlight is bright on the [page] (the color behind the text), dark ink on it. A soft highlight
 * on a dark page is dark, so there the text keeps its own color.
 */
fun markerStyle(acc: Color, mk: Marker = Marker(), page: Color = Color.White): SpanStyle {
    val base = markerBase(acc, mk); val a = HighlightPrefs.opacity(mk.opacity) / 100f
    val seen = HighlightPrefs.blend(base.luminance(), page.luminance(), a)
    return SpanStyle(background = base.copy(alpha = a), color = if (HighlightPrefs.darkInk(seen)) MARKER_INK else Color.Unspecified)
}
