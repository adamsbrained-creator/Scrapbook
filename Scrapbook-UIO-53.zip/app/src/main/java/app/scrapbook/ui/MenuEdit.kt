package app.scrapbook.ui

import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

// Customize menu: change how the Home menu looks (the skin and the choices on top of it), what it holds, what it calls things and in what order.
// Open it from the menu itself (Customize menu), from Settings > Home and lists, or by holding the menu's title (which works even when the menu holds
// neither). Everything is saved on this phone as you go (see MenuLayout.kt, MenuStyle.kt); no scrap or box is touched.
// Three tabs: Look (skin, words, options, buttons), Entries (arrange, rename, hide, add shortcuts and breaks) and Setups (ready-made and saved menus).
// A live picture at the top follows every change, "Try the menu" opens the real menu on top of the page, and Undo (top right) takes back the last changes.

/** What a window that asks for one line of text is for. */
private class Naming(val title: String, val hint: String, val initial: String, val max: Int, val note: String? = null, val resetLabel: String? = null, val onSave: (String) -> Unit)

/** A question before something that is hard to notice or to undo. */
private class Confirm(val title: String, val message: String, val action: String, val onConfirm: () -> Unit)

@Composable
fun MenuCustomizeScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val haptics = LocalHaptics.current
    val storedLayout by vm.menuLayout.collectAsState(); val storedStyle by vm.menuStyle.collectAsState(); val presets by vm.menuPresets.collectAsState()
    val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    val drag = remember { DragReorder(vertical = true) }
    // The page works on its own copy so a dragged row follows the finger at once; every change is saved straight away. Several swaps can happen in one drag
    // event, before the page has had time to show the first: each one starts from the layout the last one made (live).
    var layout by remember { mutableStateOf(storedLayout) }
    var style by remember { mutableStateOf(storedStyle) }
    val live = remember { arrayOf(storedLayout) }
    LaunchedEffect(storedLayout) { if (drag.active == null) { layout = storedLayout; live[0] = storedLayout } }
    LaunchedEffect(storedStyle) { style = storedStyle }
    val history = remember { MenuHistory() }
    var undoable by remember { mutableStateOf(false) }

    fun record(before: MenuConfig) { history.push(before); undoable = true }
    fun commitLayout(next: MenuLayout, keep: Boolean = true) {
        if (next == live[0]) return
        if (keep) record(MenuConfig(live[0], style))
        live[0] = next; layout = next; vm.setMenuLayout(next)
    }
    fun commitStyle(next: MenuStyle) {
        if (next == style) return
        record(MenuConfig(live[0], style))
        style = next; vm.setMenuStyle(next)
    }
    fun commitOptions(f: (MenuOptions) -> MenuOptions) = commitStyle(style.copy(options = f(style.options).clamped()))
    fun wear(c: MenuConfig) {
        if (c == MenuConfig(live[0], style)) return
        record(MenuConfig(live[0], style))
        live[0] = c.layout; layout = c.layout; style = c.style; vm.setMenuConfig(c)
    }
    fun undo() {
        val c = history.pop() ?: return
        live[0] = c.layout; layout = c.layout; style = c.style; vm.setMenuConfig(c); undoable = history.canUndo; haptics.tick()
    }
    val move: (Int, Int) -> Unit = { from, to -> commitLayout(live[0].move(from, to), keep = false) }
    val keys = remember(layout) { layout.order.map { it.key } }

    var tab by remember { mutableStateOf(0) }
    // The Look tab is a short list of groups; one is open at a time ("" is none).
    var openGroup by remember { mutableStateOf("") }
    fun toggleGroup(k: String) { openGroup = if (openGroup == k) "" else k }
    var trying by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<MenuItem?>(null) }
    var adding by remember { mutableStateOf(false) }
    var naming by remember { mutableStateOf<Naming?>(null) }
    var confirm by remember { mutableStateOf<Confirm?>(null) }

    val skin = MenuSkins.of(style.skin); val o = style.options
    fun hide(item: MenuItem, hide: Boolean) {
        val next = live[0].withHidden(item, hide)
        // Without Settings and Customize menu the menu can not be changed from itself any more: say how to get back, once, before it happens.
        if (hide && live[0].reachesCustomize && !next.reachesCustomize)
            confirm = Confirm("Hide the last way in?", "Settings and Customize menu would both be gone from the menu. You can always get back to this page: hold the title at the top of the menu.", "Hide it") { commitLayout(next) }
        else commitLayout(next)
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.page) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                ScreenHeader({ nav.popBackStack() }, title = "Customize menu", trailing = {
                    CircleBtn("Undo", { if (undoable) undo() }) { Ic("undo", 22.dp, if (undoable) Sb.ink else Sb.mute.copy(alpha = .4f)) }
                })
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp), userScrollEnabled = drag.active == null) {
                    // --- The real menu, and the three tabs
                    item(key = "preview") {
                        Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                            Row(Modifier.pressScale(.97f).fillMaxWidth().clip(CircleShape).background(Sb.ink).tap("Try the menu") { trying = true }.padding(vertical = 15.dp),
                                Arrangement.Center, Alignment.CenterVertically) {
                                Ic("menu", 20.dp, Sb.card); Spacer(Modifier.width(10.dp))
                                Text("Try the menu", color = Sb.card, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            }
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
                                listOf("Look", "Entries", "Setups").forEachIndexed { i, s -> SoftChip(s, on = tab == i) { tab = i } }
                            }
                        }
                    }

                    if (tab == 0) {
                        // --- Look: six groups, each a row with what it is now; a tap opens its choices
                        item(key = "gSkin") {
                            LookGroup("Skin", style.skin.label, openGroup == "skin", { toggleGroup("skin") }) {
                                MenuSkins.all.forEachIndexed { i, s ->
                                    if (i > 0) SheetDivider()
                                    val on = s.id == style.skin
                                    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).semantics { selected = on }.tap(s.id.label) { if (!on) { haptics.tick(); commitStyle(style.copy(skin = s.id)) } }
                                        .padding(horizontal = 18.dp, vertical = 10.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(s.id.label, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                                            Text(s.id.blurb, fontSize = 13.sp, lineHeight = 17.sp, color = Sb.mute)
                                        }
                                        if (on) Ic("check", 20.dp, accentText(t.acc))
                                    }
                                }
                            }
                        }
                        item(key = "gWords") {
                            LookGroup("Words", o.titleOrDefault, openGroup == "words", { toggleGroup("words") }) {
                                ValueRow("Title", o.titleOrDefault) {
                                    naming = Naming("Title of the menu", "scrapbook", o.title, MenuOptions.MAX_TITLE, resetLabel = "Use the usual word") { v -> commitOptions { it.copy(title = v) } }
                                }
                                SheetDivider()
                                ToggleRow(null, "Show the title", o.showTitle) { v -> commitOptions { it.copy(showTitle = v) } }
                                SheetDivider()
                                ChoiceRow("Names of the cards", MenuOptions.TRI, o.groupNames.coerceIn(0, 2)) { v -> commitOptions { it.copy(groupNames = v) } }
                                if (skin.canFooter) {
                                    SheetDivider()
                                    ToggleRow(null, "Line under the buttons", o.footer) { v -> commitOptions { it.copy(footer = v) } }
                                    if (o.footer) {
                                        SheetDivider()
                                        ValueRow("Line says", o.footerText.ifBlank { "Your scraps and boxes" }) {
                                            naming = Naming("The line under the buttons", "128 scraps · 12 boxes · all on this phone", o.footerText, MenuOptions.MAX_FOOTER,
                                                note = "Leave it empty to show how many scraps and boxes you have.", resetLabel = "Show my scraps and boxes") { v -> commitOptions { it.copy(footerText = v) } }
                                        }
                                    }
                                }
                                MenuSection.entries.forEach { sec ->
                                    SheetDivider()
                                    ValueRow("${sec.title} card", layout.sectionTitle(sec)) {
                                        naming = Naming("Name of the ${sec.title} card", sec.title, layout.sections[sec].orEmpty(), MenuLayout.MAX_LABEL,
                                            note = "Shown on top of a card when everything in it comes from here.", resetLabel = "Use ${sec.title}") { v -> commitLayout(live[0].withSectionTitle(sec, v)) }
                                    }
                                }
                            }
                        }
                        item(key = "gRows") {
                            LookGroup("Rows and icons", MenuOptions.ROW_SIZES[o.rowSize.coerceIn(0, 2)], openGroup == "rows", { toggleGroup("rows") }) {
                                ChoiceRow("Row size", MenuOptions.ROW_SIZES, o.rowSize.coerceIn(0, 2)) { v -> commitOptions { it.copy(rowSize = v) } }
                                SheetDivider()
                                ToggleRow(null, "Icons next to the names", o.icons) { v -> commitOptions { it.copy(icons = v) } }
                                SheetDivider()
                                ToggleRow(null, "Accent color on icons and buttons", o.accent) { v -> commitOptions { it.copy(accent = v) } }
                            }
                        }
                        item(key = "gTop") {
                            LookGroup("Top and dim", if (o.profile) "Your name on top" else "Dim: " + MenuOptions.DIMS[o.dim.coerceIn(0, 2)], openGroup == "top", { toggleGroup("top") }) {
                                ToggleRow(null, "Your picture and name on top", o.profile) { v -> commitOptions { it.copy(profile = v) } }
                                SheetDivider()
                                ChoiceRow("Dim behind the menu", MenuOptions.DIMS, o.dim.coerceIn(0, 2)) { v -> commitOptions { it.copy(dim = v) } }
                            }
                        }
                        item(key = "gButtons") {
                            LookGroup("Buttons", o.bottom.label, openGroup == "buttons", { toggleGroup("buttons") }) {
                                ChoiceRow("Main button", MenuBottom.entries.map { it.label }, o.bottom.ordinal) { v -> commitOptions { it.copy(bottom = MenuBottom.entries[v]) } }
                                SheetDivider()
                                ChoiceRow("Close button", MenuOptions.TRI, o.cancel.coerceIn(0, 2)) { v -> commitOptions { it.copy(cancel = v) } }
                                if (skin.canPill) { SheetDivider(); ChoiceRow("Main button looks like", MenuOptions.ACTIONS, o.action.coerceIn(0, 1)) { v -> commitOptions { it.copy(action = v) } } }
                                if (!skin.canFooter || !skin.canPill) Text("${style.skin.label} has no ${if (!skin.canFooter && !skin.canPill) "line under the buttons or floating button" else if (!skin.canFooter) "line under the buttons" else "floating button"}; a skin like Float does.",
                                    Modifier.padding(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 14.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
                            }
                        }
                        if (style != MenuStyle()) item(key = "resetLook") {
                            Text("Back to the Classic look", Modifier.pressScale(.97f).fillMaxWidth().padding(top = 14.dp).clip(CircleShape).background(Sb.line.copy(alpha = .6f))
                                .tap("Use the Classic skin and the usual options") { haptics.confirm(); commitStyle(MenuStyle()) }.padding(vertical = 14.dp),
                                color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                        }
                    }

                    if (tab == 1) {
                        // --- Entries: arrange, rename, hide, add
                        if (!layout.reachesCustomize) item(key = "warn") {
                            Column(Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(22.dp)).background(Sb.surface).padding(16.dp), Arrangement.spacedBy(4.dp)) {
                                Text("Settings and Customize menu are hidden", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                Text("To get back to this page, hold the title at the top of the menu.", fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
                            }
                        }
                        item(key = "arrangeLabel") { SheetLabel("Entries") }
                        item(key = "arrangeNote") {
                            SheetNote("Hold the handle to drag. The eye hides an entry. Tap a name to rename it or give it another icon. A group break starts a new card in the menu.")
                        }
                        items(layout.order, key = { it.key }) { entry ->
                            val i = layout.order.indexOf(entry)
                            val dragging = drag.active == entry.key
                            val name = layout.labelOf(entry)
                            val shape = RoundedCornerShape(22.dp)
                            // The row being dragged follows the finger, so it must not also slide to its new place; the others do.
                            Box(Modifier.animateItem(placementSpec = if (dragging) null else tween(220)).reorderLayer(drag, entry.key).fillMaxWidth()
                                .height(if (entry is MenuItem.Gap) 60.dp else 72.dp).padding(vertical = 4.dp)
                                .semantics {
                                    customActions = listOf(
                                        CustomAccessibilityAction("Move $name up") { if (i > 0) { haptics.tick(); move(i, i - 1); true } else false },
                                        CustomAccessibilityAction("Move $name down") { if (i < layout.order.lastIndex) { haptics.tick(); move(i, i + 1); true } else false },
                                    )
                                }) {
                                if (entry is MenuItem.Gap) {
                                    Row(Modifier.fillMaxSize().clip(shape).dashedOutline(Sb.mute.copy(alpha = .5f), shape).padding(start = 16.dp, end = 4.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                        Ic("divider", 24.dp, Sb.mute)
                                        Column(Modifier.weight(1f)) {
                                            Text("Group break", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.mute, maxLines = 1)
                                            Text("A new card starts below", fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon("Remove group break") { haptics.tick(); commitLayout(live[0].removeGap(entry.id)) }, Alignment.Center) { Ic("close", 20.dp, Sb.mute) }
                                        Box(Modifier.size(48.dp).reorderGesture(drag, entry.key, keys, true, move, onFirst = { record(MenuConfig(live[0], style)) }, handle = true).semantics { contentDescription = "Drag group break" }, Alignment.Center) {
                                            Ic("grip", 22.dp, Sb.mute)
                                        }
                                    }
                                } else {
                                    val hidden = layout.isHidden(entry)
                                    val usual = (entry as? MenuItem.Entry)?.entry?.label
                                    val sub = when {
                                        hidden -> "Hidden"
                                        entry is MenuItem.Shortcut -> entry.shortcut.kind.label + if (entry.shortcut.kind == ShortcutKind.Binder) "" else " · " + entry.shortcut.target.take(24)
                                        usual != null && usual != name -> "Usually $usual"
                                        else -> null
                                    }
                                    Row(Modifier.fillMaxSize().clip(shape).background(Sb.surface).padding(start = 16.dp, end = 4.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                        Row(Modifier.weight(1f).fillMaxHeight().alpha(if (hidden) .4f else 1f).tap("Rename $name or change its icon") { editing = entry }, Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                                            Ic(layout.iconOf(entry), 24.dp, Sb.ink)
                                            Column(Modifier.weight(1f)) {
                                                Text(name, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                if (sub != null) Text(sub, fontSize = 13.sp, lineHeight = 16.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                        Box(Modifier.size(48.dp).clip(CircleShape).tapIcon(if (hidden) "Show $name" else "Hide $name") { haptics.toggle(hidden); hide(entry, !hidden) }, Alignment.Center) {
                                            Ic(if (hidden) "eyeoff" else "eye", 22.dp, if (hidden) Sb.mute else Sb.ink)
                                        }
                                        Box(Modifier.size(48.dp).reorderGesture(drag, entry.key, keys, true, move, onFirst = { record(MenuConfig(live[0], style)) }, handle = true).semantics { contentDescription = "Drag $name" }, Alignment.Center) {
                                            Ic("grip", 22.dp, Sb.mute)
                                        }
                                    }
                                }
                            }
                        }
                        item(key = "addButtons") {
                            val fullGaps = layout.gaps.size >= MenuLayout.MAX_GAPS; val fullShortcuts = layout.shortcuts.size >= MenuLayout.MAX_SHORTCUTS
                            Column(Modifier.padding(top = 10.dp), Arrangement.spacedBy(2.dp)) {
                                AddPill("Add a shortcut", "A box, a scrap, a tag or Binder, one tap from the menu", fullShortcuts, "No more shortcuts fit") { adding = true }
                                AddPill("Add a group break", "Starts a new card in the menu", fullGaps, "No more group breaks fit") { haptics.tick(); commitLayout(live[0].addGap()) }
                            }
                        }
                        if (layout != MenuLayout.Default) item(key = "reset") {
                            Text("Back to the usual menu", Modifier.pressScale(.97f).fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f))
                                .tap("Put every entry back where it was, with its own name, and take the shortcuts away") {
                                    confirm = Confirm("Back to the usual menu?", "Every entry goes back to its place with its own name and icon, all of them show, and your shortcuts and group names go. You can undo it.", "Reset") { commitLayout(MenuLayout.Default) }
                                }.padding(vertical = 16.dp),
                                color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                        }
                    }

                    if (tab == 2) {
                        // --- Setups: whole menus to put on
                        item(key = "readyLabel") { SheetLabel("Ready-made") }
                        item(key = "ready") {
                            PageCard {
                                MenuPresets.builtIn.forEachIndexed { i, (name, c) ->
                                    if (i > 0) SheetDivider()
                                    SetupRow(name, c, c == MenuConfig(layout, style)) { haptics.tick(); wear(c) }
                                }
                            }
                        }
                        item(key = "yoursLabel") { SheetLabel("Yours") }
                        if (presets.isEmpty()) item(key = "yoursNote") { SheetNote("Make the menu the way you like it, then save it here to come back to it any time. A saved menu keeps the skin, the options, the names, the order and your shortcuts.") }
                        else item(key = "yours") {
                            PageCard {
                                presets.forEachIndexed { i, p ->
                                    val c = MenuConfig.decode(p.blob)
                                    if (c != null) { if (i > 0) SheetDivider(); SetupRow(p.name, c, c == MenuConfig(layout, style), onDelete = {
                                        confirm = Confirm("Delete \"${p.name}\"?", "The saved menu goes. The menu you have now does not change.", "Delete") { vm.setMenuPresets(MenuPresets.remove(presets, p.name)) }
                                    }) { haptics.tick(); wear(c) } }
                                }
                            }
                        }
                        item(key = "save") {
                            val full = presets.size >= MenuPresets.MAX_SAVED
                            AddPill("Save this menu as…", if (full) "The oldest one is replaced when there are ${MenuPresets.MAX_SAVED}" else "Keeps the look, entries, names and shortcuts", false, "") {
                                naming = Naming("Name this menu", "My menu", "", MenuPresets.MAX_NAME) { v -> vm.setMenuPresets(MenuPresets.save(presets, v, MenuConfig(live[0], style))) }
                            }
                        }
                    }
                }
            }
        }

        // --- Windows on top of the page. They wear the menu skin too, so a change can be judged on them as well.
        if (trying) MenuSheet(nav, { trying = false }, onCustomize = {}, summary = menuSummary(all.size, shelves.size), preview = true) {}
        editing?.let { item ->
            EntrySheet(item, layout, onClose = { editing = null }, onApply = { commitLayout(it) }, onRemoveShortcut = { id -> editing = null; commitLayout(live[0].removeShortcut(id)) })
        }
        if (adding) ShortcutSheet(vm, onClose = { adding = false }) { kind, target, label -> commitLayout(live[0].addShortcut(kind, target, label)) }
        naming?.let { n -> NameSheet(n, onClose = { naming = null }) }
        confirm?.let { c ->
            Sheet(c.title, { confirm = null }, doneLabel = c.action, primary = { c.onConfirm(); confirm = null }) { SheetNote(c.message) }
        }
    }
}

/** A card on the page (soft grey, whatever the menu skin is) that holds rows. */
@Composable
private fun PageCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(24.dp)).background(Sb.surface).padding(vertical = 4.dp), content = content)
}

/** A name with a row of pills under it, one chosen. The row scrolls sideways when the names do not fit. */
@Composable
private fun ChoiceRow(label: String, options: List<String>, on: Int, onPick: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), Arrangement.spacedBy(10.dp)) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, s -> SoftChip(s, on = i == on, container = Sb.paper) { onPick(i) } }
        }
    }
}

/** A row with a name on the left and what it is now on the right; a tap changes it. */
@Composable
private fun ValueRow(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 58.dp).tap("$label, now $value", onClick).padding(horizontal = 18.dp, vertical = 8.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text(value, Modifier.weight(1f), fontSize = 15.sp, color = Sb.mute, textAlign = TextAlign.End, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Ic("chevron", 18.dp, Sb.mute)
    }
}

/** The dashed button at the end of a list: a bold line and a quiet one under it. [full] greys it out and [fullNote] says why. */
@Composable
private fun AddPill(label: String, sub: String, full: Boolean, fullNote: String, onClick: () -> Unit) {
    Row(Modifier.pressScale(.97f).fillMaxWidth().heightIn(min = 56.dp).alpha(if (full) .4f else 1f).clip(RoundedCornerShape(24.dp))
        .tap(if (full) fullNote else label) { if (!full) onClick() }.padding(horizontal = 10.dp, vertical = 8.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Ic("plus", 20.dp, Sb.mute)
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 16.sp, color = Sb.ink)
            Text(if (full) fullNote else sub, fontSize = 13.sp, lineHeight = 17.sp, color = Sb.mute)
        }
    }
}

/** A whole menu to put on: its name, the skin it uses, a check when it is the one you have. [onDelete] adds a small remove button (your own saved menus). */
@Composable
private fun SetupRow(name: String, c: MenuConfig, on: Boolean, onDelete: (() -> Unit)? = null, onWear: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).semantics { selected = on }.tap("Wear $name", onWear).padding(start = 18.dp, end = if (onDelete != null) 6.dp else 18.dp, top = 8.dp, bottom = 8.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${c.style.skin.label} skin", fontSize = 13.sp, color = Sb.mute, maxLines = 1)
        }
        if (on) Ic("check", 20.dp, accentText(LocalSb.current.acc))
        if (onDelete != null) Box(Modifier.size(40.dp).clip(CircleShape).tapIcon("Delete $name") { onDelete() }, Alignment.Center) { Ic("trash", 18.dp, Sb.mute) }
    }
}

/** A group on the Look tab: one row with its name and what it is now; a tap opens its choices right under it. */
@Composable
private fun LookGroup(title: String, summary: String, open: Boolean, onToggle: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(24.dp)).background(Sb.surface)) {
        Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).tap(if (open) "Close $title" else "Open $title", onToggle).padding(horizontal = 18.dp, vertical = 8.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Text(summary, Modifier.weight(1f), fontSize = 15.sp, color = Sb.mute, textAlign = TextAlign.End, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Box(Modifier.rotate(if (open) 90f else 0f)) { Ic("chevron", 18.dp, Sb.mute) }
        }
        if (open) { SheetDivider(); content() }
    }
}

/** One line of text in a box that fits the page, with the keyboard up. */
@Composable
private fun TextLine(value: String, onChange: (String) -> Unit, hint: String, focus: FocusRequester? = null) {
    InputBox {
        BasicTextField(value, onChange, Modifier.fillMaxWidth().then(if (focus != null) Modifier.focusRequester(focus) else Modifier), singleLine = true,
            textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(Sb.ink),
            decorationBox = { inner -> Box { if (value.isEmpty()) Text(hint, color = Sb.mute, fontSize = 16.sp); inner() } })
    }
}

/** A window that asks for one line: the title of the menu, the line under the buttons, the name of a card, the name of a saved menu. */
@Composable
private fun NameSheet(n: Naming, onClose: () -> Unit) {
    var text by remember { mutableStateOf(n.initial) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    Sheet(n.title, onClose, doneLabel = "Save", primary = { n.onSave(text.trim()); onClose() }, enabled = text.isNotBlank() || n.resetLabel != null) {
        TextLine(text, { if (it.length <= n.max) text = it.replace("\n", "") }, n.hint, focus)
        if (n.note != null) SheetNote(n.note)
        if (n.resetLabel != null && n.initial.isNotBlank()) SheetGroup { ActionRow("undo", n.resetLabel) { n.onSave(""); onClose() } }
    }
}

/** What one entry (or shortcut) is called and which icon it has. Nothing changes until Save; a shortcut can also be removed here. */
@Composable
private fun EntrySheet(item: MenuItem, layout: MenuLayout, onClose: () -> Unit, onApply: (MenuLayout) -> Unit, onRemoveShortcut: (Int) -> Unit) {
    val own = layout.looks[item.key]
    var name by remember { mutableStateOf(own?.label.orEmpty()) }
    var icon by remember { mutableStateOf(own?.icon.orEmpty()) }
    val usualName = when (item) { is MenuItem.Entry -> item.entry.label; is MenuItem.Shortcut -> item.shortcut.label; is MenuItem.Gap -> "" }
    val usualIcon = (item as? MenuItem.Entry)?.entry?.icon ?: (item as? MenuItem.Shortcut)?.shortcut?.kind?.icon ?: "menu"
    Sheet(name.ifBlank { usualName }, onClose, doneLabel = "Save", primary = { onApply(layout.withLook(item, name, icon)); onClose() }) {
        SheetLabel("Name")
        TextLine(name, { if (it.length <= MenuLayout.MAX_LABEL) name = it.replace("\n", "") }, usualName)
        SheetLabel("Icon")
        val cells = MenuIcons.ALL
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            cells.chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    row.forEach { g ->
                        val on = (icon.ifBlank { usualIcon }) == g
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(if (on) Sb.ink.copy(alpha = .1f) else Sb.line.copy(alpha = .0f))
                            .border(if (on) 2.dp else 0.dp, if (on) Sb.ink else Sb.line.copy(alpha = 0f), RoundedCornerShape(14.dp))
                            .tap("Icon $g") { icon = if (g == usualIcon) "" else g }.semantics { selected = on }, Alignment.Center) { Ic(g, 24.dp, Sb.ink) }
                    }
                    repeat(6 - row.size) { Spacer(Modifier.size(46.dp)) }
                }
            }
        }
        if (name.isNotBlank() || icon.isNotBlank()) SheetGroup { ActionRow("undo", "Back to the usual name and icon") { name = ""; icon = "" } }
        if (item is MenuItem.Shortcut) SheetGroup { ActionRow("trash", "Remove this shortcut", danger = true) { onRemoveShortcut(item.shortcut.id) } }
    }
}

/** Adds a shortcut: pick what kind, then which one. A box, a scrap and a tag are picked from what you have; Binder needs nothing more. */
@Composable
private fun ShortcutSheet(vm: ArchiveViewModel, onClose: () -> Unit, onPick: (ShortcutKind, String, String) -> Unit) {
    val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    var kind by remember { mutableStateOf<ShortcutKind?>(null) }
    var q by remember { mutableStateOf("") }
    fun add(k: ShortcutKind, target: String, label: String) { onPick(k, target, label); onClose() }
    val picked = kind
    val title = when (picked) { null -> "Add a shortcut"; ShortcutKind.Binder -> "Add Binder"; else -> "Add a ${picked.label.lowercase()}" }
    Sheet(title, onClose, doneLabel = "Close", soft = true) {
        val k = kind
        if (k == null) {
            SheetGroup {
                ShortcutKind.entries.forEachIndexed { i, sk ->
                    if (i > 0) SheetDivider(56.dp)
                    ActionRow(sk.icon, when (sk) { ShortcutKind.Box -> "A box"; ShortcutKind.Scrap -> "One scrap"; ShortcutKind.Tag -> "A tag"; ShortcutKind.Binder -> "The Binder app" },
                        when (sk) { ShortcutKind.Box -> "Opens it"; ShortcutKind.Scrap -> "Opens that page"; ShortcutKind.Tag -> "Shows the scraps with it"; ShortcutKind.Binder -> "Opens Binder, if it is on this phone" }) {
                        if (sk == ShortcutKind.Binder) add(sk, "", "Binder") else kind = sk
                    }
                }
            }
        } else {
            SheetGroup { ActionRow("back", "Back") { kind = null; q = "" } }
            when (k) {
                ShortcutKind.Box -> SheetGroup {
                    val boxes = listOf("Inbox" to "Inbox") + shelves.map { it.name to shelves.labelOf(it.name) }
                    boxes.forEachIndexed { i, (key, label) ->
                        if (i > 0) SheetDivider(56.dp)
                        ActionRow("folder", label) { add(k, key, label) }
                    }
                }
                ShortcutKind.Scrap -> {
                    TextLine(q, { q = it.replace("\n", "") }, "Search your scraps")
                    val found = remember(all, q) { all.filter { it.uid.isNotBlank() && (q.isBlank() || it.title.contains(q.trim(), true)) }.sortedByDescending { it.savedAt }.take(20) }
                    if (found.isEmpty()) SheetNote("No scrap found.")
                    else SheetGroup {
                        found.forEachIndexed { i, sc ->
                            if (i > 0) SheetDivider(56.dp)
                            ActionRow("edit", sc.title.ifBlank { "Untitled" }, sc.collection.takeIf { c -> c.isNotBlank() }?.let { c -> shelves.labelOf(c) }) { add(k, sc.uid, sc.title.ifBlank { "Untitled" }) }
                        }
                    }
                }
                ShortcutKind.Tag -> {
                    val tags = remember(all) { tagCounts(all) }
                    if (tags.isEmpty()) SheetNote("No tags yet. A tag is a word on a scrap, like #ideas.")
                    else SheetGroup {
                        tags.forEachIndexed { i, (tag, n) ->
                            if (i > 0) SheetDivider(56.dp)
                            ActionRow("tag", "#$tag", if (n == 1) "1 scrap" else "$n scraps") { add(k, tag, "#$tag") }
                        }
                    }
                }
                ShortcutKind.Binder -> {}
            }
        }
    }
}
