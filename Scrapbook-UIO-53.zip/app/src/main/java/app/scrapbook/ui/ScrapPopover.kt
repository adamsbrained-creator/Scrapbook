package app.scrapbook.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.ArchiveViewModel
import app.scrapbook.HoldAction
import app.scrapbook.HoldMenuConfig
import app.scrapbook.Item
import app.scrapbook.placePopover
import app.scrapbook.plainText
import kotlin.math.roundToInt

// The menu that opens on a scrap's card when you hold it (Scrapbook-UIO-42): the held card stays bright while the rest of the screen dims, and the menu opens right under it,
// or above it when there is no room below. What it offers is a HoldMenuConfig (HoldMenu.kt), so a settings page can change it later.
//
// How it fits together: a card built with Modifier.tapOrHoldCard tells LocalHoldSink where it is just before its long press runs. The list screen (ShelfScreen, AllScrapsScreen)
// provides the sink from its ScrapPopoverState, opens the state with the held scrap, and puts ScrapPopoverHost on top of everything.

/** Where a held card is in the window and how round its corners are. Provided by a list screen; the default does nothing, so a card anywhere else holds as before. */
val LocalHoldSink = compositionLocalOf<(Rect, Dp) -> Unit> { { _, _ -> } }

private class HoldAt { var bounds: Rect = Rect.Zero }

/**
 * Tap opens and a long press runs [onHold], like tapOrHold, and a scrap card also reports where it is (see [LocalHoldSink]) right before the hold runs.
 * [radius] is the card's corner radius, so the bright cut-out in the dim matches the card.
 */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.tapOrHoldCard(label: String?, holdLabel: String?, onHold: () -> Unit, onClick: () -> Unit, radius: Dp = 28.dp): Modifier = composed {
    val sink = LocalHoldSink.current; val at = remember { HoldAt() }
    onGloballyPositioned { at.bounds = it.boundsInWindow() }
        .combinedClickable(onClickLabel = label, role = Role.Button, onLongClickLabel = holdLabel, onLongClick = { sink(at.bounds, radius); onHold() }, onClick = onClick)
}

/** What a list screen keeps for the hold menu: the scrap that is held (null when the menu is closed) and where its card is. */
class ScrapPopoverState {
    var item by mutableStateOf<Item?>(null)
        private set
    var bounds by mutableStateOf(Rect.Zero)
        private set
    var radius by mutableStateOf(28.dp)
        private set
    /** Give this to LocalHoldSink. */
    val sink: (Rect, Dp) -> Unit = { r, d -> bounds = r; radius = d }
    fun open(n: Item) { item = n }
    fun close() { item = null }
}

@Composable
fun rememberScrapPopover(): ScrapPopoverState = remember { ScrapPopoverState() }

/**
 * Draws the hold menu over the screen while [state] has a held scrap, and does what a choice says: Pin, Add to box, Tags and Share, Select (calls [onSelect], which starts picking with
 * this scrap), Duplicate, Open and Delete (the Undo snackbar of the list screens brings it back). Put it last inside the screen's full-size Box.
 */
@Composable
fun ScrapPopoverHost(state: ScrapPopoverState, vm: ArchiveViewModel, nav: NavController, onSelect: (Item) -> Unit, config: HoldMenuConfig = HoldMenuConfig.DEFAULT) {
    val ctx = LocalContext.current; val haptics = LocalHaptics.current
    val all by vm.items.collectAsState()
    // The scrap is looked up again each time, so Pin reads Unpin right after it is pinned, and the menu goes away if the scrap does.
    val held = state.item?.let { h -> all.firstOrNull { it.id == h.id } }
    LaunchedEffect(state.item, held == null) { if (state.item != null && held == null) state.close() }
    var boxFor by remember { mutableStateOf<Item?>(null) }; var tagsFor by remember { mutableStateOf<Item?>(null) }

    if (held != null) ScrapPopoverLayer(held, state.bounds, state.radius, config.sanitized(), state::close) { action ->
        state.close()
        when (action) {
            HoldAction.Pin -> { haptics.toggle(!held.pinned); vm.togglePin(held) }
            HoldAction.AddToBox -> { boxFor = held }
            HoldAction.Tags -> { tagsFor = held }
            HoldAction.Share -> ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, held.title); putExtra(Intent.EXTRA_TEXT, plainText(held.title, held.body))
            }, "Share scrap"))
            HoldAction.Select -> onSelect(held)
            HoldAction.Duplicate -> { haptics.confirm(); vm.duplicate(held) }
            HoldAction.Open -> { nav.navigate("edit/${held.id}") }
            HoldAction.Delete -> { vm.delete(held) }
        }
    }
    boxFor?.let { MoveSheet(it, vm) { boxFor = null } }
    tagsFor?.let { TagSheet(it, vm) { tagsFor = null } }
}

@Composable
private fun ScrapPopoverLayer(n: Item, bounds: Rect, radius: Dp, config: HoldMenuConfig, onDismiss: () -> Unit, onAction: (HoldAction) -> Unit) {
    var origin by remember { mutableStateOf(Offset.Zero) }   // where this layer starts in the window, so window coordinates can be turned into its own
    val appear = remember { Animatable(0f) }
    val aboveHolder = remember { BooleanArray(1) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(180, easing = FastOutSlowInEasing)) }
    BackHandler(onBack = onDismiss)
    BlockSwipes()
    val dim = Color.Black.copy(alpha = if (Sb.dark) .6f else .4f)

    Box(Modifier.fillMaxSize().onGloballyPositioned { origin = it.positionInWindow() }.pointerInput(Unit) { detectTapGestures { onDismiss() } }) {
        // The dim covers everything except the held card.
        Canvas(Modifier.fillMaxSize()) {
            val r = bounds.translate(-origin)
            val hole = Path().apply { addRoundRect(RoundRect(r, CornerRadius(radius.toPx()))) }
            clipPath(hole, ClipOp.Difference) { drawRect(dim.copy(alpha = dim.alpha * appear.value)) }
        }
        Layout(content = {
            HoldMenuCard(n, config, onAction, Modifier.graphicsLayer {
                alpha = appear.value
                val s = .94f + .06f * appear.value
                scaleX = s; scaleY = s
                transformOrigin = TransformOrigin(.9f, if (aboveHolder[0]) 1f else 0f)
            })
        }, modifier = Modifier.fillMaxSize()) { measurables, c ->
            val p = measurables[0].measure(c.copy(minWidth = 0, minHeight = 0))
            val r = bounds.translate(-origin)
            val spot = placePopover(r.top, r.right, r.bottom, p.width.toFloat(), p.height.toFloat(), c.maxWidth.toFloat(), c.maxHeight.toFloat(), 10.dp.toPx(), 12.dp.toPx(), 6.dp.toPx())
            aboveHolder[0] = spot.above
            layout(c.maxWidth, c.maxHeight) { p.place(spot.x.roundToInt(), spot.y.roundToInt()) }
        }
    }
}

/** The menu itself: the quick buttons along the top, the list under them, and the destructive rows last. Its look follows the menu skin like the other pop-up menus. */
@Composable
private fun HoldMenuCard(n: Item, config: HoldMenuConfig, onAction: (HoldAction) -> Unit, modifier: Modifier) {
    val skin = menuSkin(); val shape = RoundedCornerShape(skin.popupCorner)
    val plain = config.plainRows; val danger = config.dangerRows
    Column(modifier.width(maxOf(skin.popupWidth, 292.dp)).shadow(18.dp, shape).background(Sb.menu, shape).border(1.dp, Sb.menuLine, shape).clip(shape)
        .pointerInput(Unit) { detectTapGestures { } }) {   // a tap on the menu's own padding does not close it
        if (config.quick.isNotEmpty()) Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp).padding(top = 8.dp, bottom = 4.dp)) {
            config.quick.forEach { a -> QuickButton(n, a, Modifier.weight(1f)) { onAction(a) } }
        }
        if (config.quick.isNotEmpty() && (plain.isNotEmpty() || danger.isNotEmpty())) PopupDivider()
        plain.forEach { a -> PopupItem(a.title(n.pinned), a.iconFor(n.pinned)) { onAction(a) } }
        if (plain.isNotEmpty() && danger.isNotEmpty()) PopupDivider()
        danger.forEach { a -> PopupItem(a.label, a.icon, tint = Sb.danger) { onAction(a) } }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun QuickButton(n: Item, a: HoldAction, modifier: Modifier, onClick: () -> Unit) {
    val tint = if (a.danger) Sb.danger else if (a == HoldAction.Pin && n.pinned) accentText(LocalSb.current.acc) else Sb.ink
    Column(modifier.pressScale(.92f).clip(RoundedCornerShape(16.dp)).tap(a.title(n.pinned), onClick).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Ic(a.iconFor(n.pinned), 24.dp, tint)
        Text(a.title(n.pinned), color = tint, fontSize = 12.sp, fontFamily = LocalFonts.current.second, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}
