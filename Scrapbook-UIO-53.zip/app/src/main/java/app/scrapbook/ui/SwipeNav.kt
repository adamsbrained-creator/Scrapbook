package app.scrapbook.ui

import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import app.scrapbook.ArchiveViewModel
import app.scrapbook.NavSwipes
import app.scrapbook.SwipeMove

// Swipes between pages (Scrapbook-UIO-44), copied from Paperback's step 30. Swipe a page to the right and it goes Back; with "Swipe between main pages" on, swipe either way to move along
// Home, All scraps, Boxes and Settings. Anything inside a page that already uses a sideways drag (a row that scrolls, a slider, swiping a scrap to pin or delete it, carrying a card) takes the
// drag first and the swipe never sees it. The rules (which page, which way) are in NavSwipes.kt.

/** Counts the windows over a page that should keep swipes from reaching the page under them (a sheet, the hold menu). A counter, because two can be open at once. */
@Stable
class SwipeGate {
    var blockers by mutableIntStateOf(0)
}

val LocalSwipeGate = staticCompositionLocalOf<SwipeGate?> { null }

/** Put this inside a sheet or any other window drawn over a page: while it is on screen, swipes do nothing, so a swipe over it cannot take the page under it away. */
@Composable
fun BlockSwipes() {
    val gate = LocalSwipeGate.current
    DisposableEffect(gate) { gate?.let { it.blockers++ }; onDispose { gate?.let { it.blockers-- } } }
}

/** Goes to a main page without piling pages up: Back from any main page returns to Home, whichever of them you came from. */
fun NavController.goMain(route: String) {
    if (route == "home") popBackStack("home", false)
    else navigate(route) { popUpTo("home") { inclusive = false }; launchSingleTop = true }
}

/**
 * Wraps the pages (the NavHost). [enabled] is false while the app is locked. A swipe to the right does what the Back button does, so it first closes whatever is open (a Settings page,
 * the search in it), and only then leaves the page.
 */
@Composable
fun SwipeNavLayer(nav: NavController, vm: ArchiveViewModel, enabled: Boolean, content: @Composable () -> Unit) {
    val swipeBack by vm.swipeBack.collectAsState(); val swipeTabs by vm.swipeTabs.collectAsState()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val gate = remember { SwipeGate() }
    val backDispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher
    val haptics = LocalHaptics.current
    val plan = NavSwipes.plan(route, entry != null && nav.previousBackStackEntry != null, swipeBack, swipeTabs)
    val on = enabled && gate.blockers == 0 && !plan.isEmpty
    val planNow by rememberUpdatedState(plan)
    val run: (SwipeMove) -> Unit = { move ->
        haptics.tick()
        when (move) {
            SwipeMove.Back -> backDispatcher?.onBackPressed()
            is SwipeMove.Main -> nav.goMain(move.route)
        }
    }
    val runNow by rememberUpdatedState(run)
    val distance = with(LocalDensity.current) { NavSwipes.DISTANCE_DP.dp.toPx() }
    CompositionLocalProvider(LocalSwipeGate provides gate) {
        Box(Modifier.fillMaxSize().pointerInput(on, distance) {
            if (!on) return@pointerInput
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                var dx = 0f; var dy = 0f
                while (true) {
                    val event = awaitPointerEvent()
                    // A second finger (two-finger drawing, pinching) or a part of the page that took the drag (it scrolls, slides, swipes a scrap) means this is not a page swipe.
                    if (event.changes.size > 1) return@awaitEachGesture
                    val change = event.changes.firstOrNull { it.id == down.id } ?: return@awaitEachGesture
                    if (change.isConsumed) return@awaitEachGesture
                    if (!change.pressed) break
                    val d = change.positionChange(); dx += d.x; dy += d.y
                }
                when (NavSwipes.direction(dx, dy, distance)) {
                    1 -> planNow.right?.let { runNow(it) }
                    -1 -> planNow.left?.let { runNow(it) }
                }
            }
        }, content = { content() })
    }
}
