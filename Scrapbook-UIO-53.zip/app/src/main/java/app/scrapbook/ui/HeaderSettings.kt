package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Customize home > Header, laid out like Paperback's Settings > App style > Header: a live sample of every look to tap, the chosen one outlined, the default and the chosen one
// badged, and the Size choice under them (the samples follow it at once). The saved numbers are the ones MainHeader in Home.kt draws.

private class HeaderLook(val name: String, val note: String?, val isDefault: Boolean = false)

/** In the order the saved number means them: 0 Left, 1 Center, 2 Round, 3 Buttons only. */
private val HEADER_LOOKS = listOf(
    HeaderLook("Left", "no circles, left-aligned"),
    HeaderLook("Center", "no circles, centered", isDefault = true),
    HeaderLook("Round", "round buttons"),
    HeaderLook("Buttons only", "no wordmark"),
)
private val HEADER_SIZES = listOf("Compact", "Regular", "Large")

/** What Size does: the wordmark, or, with Buttons only (no wordmark), the two buttons. */
private fun sizeHint(look: Int, size: Int): String =
    (if (look == HEADER_LOOKS.lastIndex) listOf("Smaller buttons.", "The usual size.", "Bigger buttons.") else listOf("A smaller wordmark.", "The usual size.", "A bigger wordmark."))[size.coerceIn(0, 2)]

@Composable
private fun LookBadge(text: String, selected: Boolean) {
    Text(
        text,
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) Sb.ink else Sb.line.copy(alpha = .6f)).padding(horizontal = 8.dp, vertical = 3.dp),
        fontSize = 12.sp, fontWeight = FontWeight.Medium, color = if (selected) Sb.paper else Sb.mute,
    )
}

/** The Header part of Customize home: [look] and [size] are the saved numbers, [onLook] and [onSize] save a new one. */
@Composable
internal fun HeaderSettings(look: Int, size: Int, onLook: (Int) -> Unit, onSize: (Int) -> Unit) {
    val chosen = look.coerceIn(0, HEADER_LOOKS.lastIndex)
    val s = size.coerceIn(0, 2)
    val hs = headerScale(s)
    SectionLabel("Header")
    Text(
        "Tap one to choose how the top bar looks on Home and All scraps. Buttons only gives your scraps the most room.",
        Modifier.padding(start = 24.dp, end = 24.dp), fontSize = 15.sp, lineHeight = 21.sp, color = Sb.mute,
    )
    HEADER_LOOKS.forEachIndexed { i, l ->
        val on = i == chosen
        Column(
            Modifier.padding(start = 20.dp, end = 20.dp, top = if (i == 0) 14.dp else 10.dp)
                .clip(RoundedCornerShape(22.dp))
                .selectable(selected = on, onClick = { onLook(i) }, role = Role.RadioButton)
                .padding(top = 6.dp),
        ) {
            Row(Modifier.padding(start = 4.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(l.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
                if (l.note != null) Text(l.note, fontSize = 12.sp, color = Sb.mute, maxLines = 1)
                if (l.isDefault) LookBadge("Default", selected = false)
                if (on) LookBadge("Selected", selected = true)
            }
            Box(
                Modifier.fillMaxWidth()
                    .border(if (on) 2.dp else 1.dp, if (on) Sb.ink else Sb.line, RoundedCornerShape(22.dp))
                    .padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
            ) { HeaderSample(i, hs) }
        }
    }
    Column(Modifier.padding(top = 18.dp)) { ChoiceCard("Size", HEADER_SIZES, s, sizeHint(chosen, s), onSize) }
    HomeFooter("The All scraps page uses the same header.")
}
