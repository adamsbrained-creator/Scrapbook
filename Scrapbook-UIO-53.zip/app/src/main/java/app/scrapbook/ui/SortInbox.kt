package app.scrapbook.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*
import kotlinx.coroutines.launch

/** "today", "3 days ago", "2 months ago". */
private fun savedAgo(ms: Long): String {
    val d = (System.currentTimeMillis() - ms) / 86_400_000L
    return when { d < 1 -> "today"; d == 1L -> "yesterday"; d < 30 -> "$d days ago"; else -> "${d / 30} months ago" }
}

/** One round action under the card, with its label. */
@Composable
private fun SortBtn(icon: String, label: String, primary: Boolean = false, tint: Color? = null, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.pressScale(.92f).size(60.dp).clip(CircleShape).background(if (primary) Sb.ink else Sb.card).tap(label, onClick), Alignment.Center) {
            Ic(icon, 24.dp, tint ?: if (primary) Sb.card else Sb.ink)
        }
        Text(label, fontSize = 12.sp, color = Sb.mute)
    }
}

/** The boxes a scrap can be filed in. Sort Inbox leaves Inbox out (that is where the scrap already is); the selection toolbar offers it ([withInbox]). */
@Composable
fun PickBoxSheet(vm: ArchiveViewModel, onPick: (String) -> Unit, onDone: () -> Unit, withInbox: Boolean = false, subtitle: String? = null) = Sheet("Add to box", onDone, doneLabel = "Cancel", soft = true, subtitle = subtitle) {
    val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState(); val haptics = LocalHaptics.current
    if (shelves.isEmpty() && !withInbox) SheetNote("No boxes yet. Create one from the Boxes screen.")
    else SheetGroup {
        if (withInbox) OptionRow(INBOX_BOX, false, dot = if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) { haptics.confirm(); onPick(INBOX_BOX); onDone() }
        BoxTreeRows(shelves, null, rowAbove = withInbox) { s -> haptics.confirm(); onPick(s.name); onDone() }
    }
}

/**
 * Sort Inbox: the scraps waiting in Inbox, one at a time, oldest first. Add to a box, keep close (pin), delete (to the Bin) or leave for later.
 * "Later" only skips it for now: it stays in Inbox and the Home card keeps counting it. Nothing here is automatic and nothing nags.
 * The list is fixed when the screen opens, so a scrap that arrives meanwhile does not shuffle the order under your thumb.
 */
@Composable
fun SortInboxScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val all by vm.items.collectAsState(); val scope = rememberCoroutineScope(); val haptics = LocalHaptics.current
    val snack = remember { SnackbarHostState() }
    val queue = rememberSaveable(all.isNotEmpty()) { all.toSort().map { it.id } }
    var handled by rememberSaveable { mutableStateOf(emptyList<Long>()) }
    var picking by remember { mutableStateOf(false) }
    val live = remember(all) { all.associateBy { it.id } }
    fun waiting(id: Long) = live[id]?.takeIf { it.collection == INBOX_BOX && !it.pinned }
    val cur = queue.firstNotNullOfOrNull { id -> if (id in handled) null else waiting(id) }
    val position = queue.count { it in handled } + 1

    /** Marks a scrap as dealt with and says so, with Undo. [settle] runs when the message goes away without Undo. */
    fun act(item: Item, msg: String, undo: () -> Unit, settle: () -> Unit = {}) {
        handled = handled + item.id
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            if (snack.showSnackbar(msg, "Undo", duration = SnackbarDuration.Short) == SnackbarResult.ActionPerformed) { handled = handled - item.id; undo() } else settle()
        }
    }
    fun fileIn(item: Item, box: String) { vm.save(item.copy(collection = box)); act(item, "Added to ${vm.shelves.value.labelOf(box)}", { vm.save(item) }) }
    fun pin(item: Item) { haptics.toggle(true); vm.togglePin(item); act(item, "Pinned", { vm.save(item) }) }
    fun bin(item: Item) {
        vm.delete(item)
        act(item, "Moved to the Bin", { vm.restoreFromBin(item.id) }, { if (vm.deleted.value?.id == item.id) vm.clearDeleted() })
    }

    Box(Modifier.fillMaxSize()) {
    Scaffold(containerColor = t.page, snackbarHost = { SnackbarHost(snack) { d -> SwipeAway({ d.dismiss() }) { Snackbar(d, shape = RoundedCornerShape(20.dp), containerColor = Sb.ink, contentColor = Sb.card, actionColor = t.acc) } } }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            ScreenHeader({ nav.popBackStack() }, title = "Sort Inbox", backIcon = "close", backDesc = "Close")
            if (queue.isNotEmpty()) Text("${minOf(position, queue.size)} of ${queue.size}", Modifier.padding(top = 14.dp).clip(CircleShape).background(Sb.surface).padding(horizontal = 14.dp, vertical = 6.dp), fontSize = 13.sp, color = Sb.mute)
            Spacer(Modifier.height(24.dp))
            if (cur == null) {
                val left = queue.count { waiting(it) != null }
                Text(if (queue.isEmpty()) "Inbox is empty. Nothing to sort." else "That's everything for now.", Modifier.padding(top = 70.dp, start = 24.dp, end = 24.dp), fontFamily = headFont(), fontSize = 20.sp, textAlign = TextAlign.Center)
                if (left > 0) Text("$left ${if (left == 1) "scrap is" else "scraps are"} still in Inbox for later.", Modifier.padding(top = 10.dp, start = 24.dp, end = 24.dp), fontSize = 15.sp, color = Sb.mute, textAlign = TextAlign.Center)
                Text("Done", Modifier.padding(top = 28.dp).pressScale(.95f).clip(RoundedCornerShape(28.dp)).background(Sb.ink).tap("Done") { nav.popBackStack() }.padding(horizontal = 36.dp, vertical = 14.dp),
                    color = Sb.card, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            } else {
                Column(Modifier.appear("card-${cur.id}").fillMaxWidth().padding(horizontal = 20.dp).clip(RoundedCornerShape(32.dp)).background(Sb.surface).padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${cur.kind.label} · saved ${savedAgo(cur.createdAt)}", fontSize = 13.sp, color = Sb.mute)
                    if (cur.imageUri != null) ItemImage(cur, Modifier.fillMaxWidth().height(140.dp), 20.dp)
                    Text(cur.displayTitle, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 26.sp, lineHeight = 30.sp)
                    val preview = plainPreview(bodyWithoutTitle(cur.title, cur.body), "\n")
                    if (preview.isNotBlank()) Text(preview, fontFamily = headFont(), fontSize = 16.sp, lineHeight = 24.sp, color = Sb.ink.copy(alpha = .8f), maxLines = 8, overflow = TextOverflow.Ellipsis)
                    Text("Open scrap", Modifier.padding(top = 6.dp).tap("Open scrap") { nav.navigate("edit/${cur.id}") }, fontSize = 14.sp, color = Sb.mute)
                }
                Row(Modifier.padding(top = 28.dp), Arrangement.spacedBy(18.dp)) {
                    SortBtn("clock", "Later") { handled = handled + cur.id }
                    SortBtn("trash", "Delete", tint = Sb.danger) { bin(cur) }
                    SortBtn("star", "Keep close") { pin(cur) }
                    SortBtn("folder", "Add to box", primary = true) { picking = true }
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
    if (picking && cur != null) PickBoxSheet(vm, { box -> fileIn(cur, box) }, { picking = false })
    }
}
