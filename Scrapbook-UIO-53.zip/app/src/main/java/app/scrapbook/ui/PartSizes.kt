package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlin.math.roundToInt

// Resizing the parts of Home themselves (header, greeting, quick capture, continue, to sort, boxes, pinned, recent), the way sections of your own can be resized. A part with a size of its
// own sits in a frame of that width (a percent of the page) and height (dp); the part is drawn as its design draws it, and what does not fit scrolls inside the frame. The corner handle,
// the dashed frame and the Done bar are the ones of the sections (cornerResize and dashedFrame in HomeSectionsUi.kt).

/**
 * Puts a part of Home in the frame of its size. While [size] is automatic and nobody is resizing, the part is drawn as it always was. [resizing] shows the dashed frame and the corner handle; [onSize]
 * gets the size when the finger lifts (and 0, 0 for Automatic size) and [onDone] ends resizing.
 */
@Composable
fun PartFrame(e: HomeElement, size: PartSize, resizing: Boolean, onSize: (Int, Int) -> Unit, onDone: () -> Unit, content: @Composable () -> Unit) {
    val acc = LocalSb.current.acc
    // The size while the corner is being dragged, before it is saved. It only counts while resizing; afterwards the saved size is what is used.
    var liveW by remember(e) { mutableStateOf<Int?>(null) }
    var liveH by remember(e) { mutableStateOf<Int?>(null) }
    var bodyPx by remember { mutableStateOf(IntSize.Zero) }
    val scroll = rememberScrollState()
    val insetPx = with(LocalDensity.current) { 22.dp.toPx() }
    val half = with(LocalDensity.current) { 18.dp.toPx() }
    val w = if (resizing) liveW ?: size.width else size.width
    val h = if (resizing) liveH ?: size.height else size.height
    if (w <= 0 && h <= 0 && !resizing) { content(); return }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // The page is not padded here (the part pads itself), so the handle sits a little inside the corner, where a thumb can reach it at the edge of the screen.
        Box(Modifier.fillMaxWidth().then(if (resizing) Modifier.cornerResize({ bodyPx }, 0f, { nw, nh -> liveW = nw; liveH = nh }, { nw, nh -> liveW = nw; liveH = nh; onSize(nw, nh) }, insetPx) else Modifier)) {
            Box(Modifier.fillMaxWidth(if (w > 0) w / 100f else 1f).then(if (h > 0) Modifier.height(h.dp) else Modifier).onSizeChanged { bodyPx = it }
                .then(if (resizing) Modifier.dashedFrame(acc) else Modifier)) {
                Column(Modifier.fillMaxWidth().then(if (h > 0) Modifier.verticalScroll(scroll) else Modifier)) { content() }
            }
            if (resizing) {
                Box(Modifier.offset { IntOffset((bodyPx.width - insetPx - half).roundToInt(), (bodyPx.height - insetPx - half).roundToInt()) }.size(36.dp).clip(CircleShape).background(acc), Alignment.Center) {
                    Ic("expand", 18.dp, onAccent(acc))
                }
            }
        }
        if (resizing) {
            Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                Box(Modifier.clip(CircleShape).background(acc).tap("Done resizing") { onDone() }.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    Text("Done", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = onAccent(acc))
                }
                SoftChip("Automatic size") { liveW = null; liveH = null; onSize(0, 0) }
                Text("Drag the corner", Modifier.padding(start = 4.dp), fontSize = 13.sp, color = Sb.mute)
            }
        }
    }
}

/** The Size part of a part's options page in Customize home: Automatic or My size with two sliders, and the way into resizing it on Home. */
@Composable
fun PartSizeSection(e: HomeElement, size: PartSize, onSize: (Int, Int) -> Unit, onResize: () -> Unit) {
    SectionLabel("Size and shape")
    // The frame and the way into resizing share one card.
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SettingsCard {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Frame of ${e.label}", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Sb.ink)
                Seg(listOf("Automatic", "My size"), if (size.sized) 1 else 0) { i -> if (i == 0) onSize(0, 0) else if (!size.sized) onSize(100, 220) }
                if (size.sized) {
                    val sw = if (size.width > 0) size.width else 100
                    val sh = if (size.height > 0) size.height else 220
                    SizeSlider("Width", sw, HomeSections.MIN_WIDTH..HomeSections.MAX_WIDTH, "%") { onSize(it, sh) }
                    SizeSlider("Height", sh, HomeSections.MIN_HEIGHT..HomeSections.MAX_HEIGHT, " dp") { onSize(sw, it) }
                }
            }
            RowLine(start = 18.dp)
            IconRow("expand", "Resize on Home", "") { onResize() }
        }
    }
    HomeFooter("With a size of its own the part sits in a frame; what does not fit scrolls inside it. Automatic gives the part its own size back.")
}
