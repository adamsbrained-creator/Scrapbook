package app.scrapbook.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

private val COLOR_NAMES = listOf("Butter", "Sage", "Blue", "Rose", "Lilac")
internal fun coverOf(s: Shelf) = Item(title = "", body = "", kind = Kind.Image, collection = "", imageUri = s.coverUri, color = s.color)

/** The boxes as an indented tree (each box under the one it sits in), one OptionRow each. Boxes in `blocked` are left out, and so is everything inside them. rowAbove says whether a row sits above (so the first box gets a divider). */
@Composable
fun BoxTreeRows(shelves: List<Shelf>, selected: String?, blocked: Set<String> = emptySet(), rowAbove: Boolean = true, divider: Dp = 46.dp, onPick: (Shelf) -> Unit) {
    shelves.inTreeOrder().filter { (s, _) -> s.name !in blocked }.forEachIndexed { i, (s, depth) ->
        if (i > 0 || rowAbove) SheetDivider(divider)
        OptionRow(s.label, selected == s.name, sub = if (shelves.count { it.label.equals(s.label, true) } > 1) shelves.pathOf(s.name) else null,
            dot = TAB_COLORS[s.color % TAB_COLORS.size], indent = (depth.coerceAtMost(5) * 18).dp) { onPick(s) }
    }
}

/**
 * Create (existing == null) or edit a box: name, where it sits, description, color, cover. A new box goes inside `parent` ("" = main page).
 * Renaming and moving never touch the scraps: they find the box by its key, and only the title changes.
 */
@Composable
fun ShelfSheet(vm: ArchiveViewModel, existing: Shelf?, onDone: () -> Unit, parent: String = "") {
    val all = vm.shelves.value
    var name by remember { mutableStateOf(existing?.label ?: "") }
    var inside by remember { mutableStateOf(existing?.parent ?: parent) }
    var choosing by remember { mutableStateOf(false) }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var color by remember { mutableIntStateOf(existing?.color ?: 0) }
    var cover by remember { mutableStateOf(existing?.coverUri) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) vm.importImage(u) { cover = it } }
    val clean = name.trim()
    val reserved = isReservedBoxName(clean)
    val clash = !reserved && all.titleTaken(clean, if (all.any { it.name == inside }) inside else "", existing?.name)
    val ok = clean.isNotEmpty() && !clash && !reserved
    // A box can't go into itself or into a box inside it.
    val blocked = if (existing != null) all.subtreeKeys(existing.name).toSet() else emptySet()
    val loc = if (inside.isBlank() || all.none { it.name == inside }) "Main page" else all.pathOf(inside)
    Sheet(if (existing != null) "Edit box" else if (parent.isNotBlank()) "New box in \"${all.labelOf(parent)}\"" else "New box", onDone, doneLabel = if (existing == null) "Create box" else "Save", enabled = ok,
        primary = {
            if (ok) {
                val key = existing?.name ?: vm.newBoxKey(clean)
                vm.saveShelf(Shelf(key, desc.trim(), color, cover, inside, clean, existing?.hidden ?: false)); onDone()
            }
        }) {
        SheetLabel("Name")
        InputBox { Field(name, { name = it.filterNot { c -> c in "/?#{}" } }, "Name", 18.sp, headFont(), FontWeight.Medium) }
        if (reserved) Text("\"$clean\" is a built-in name. Pick another.", Modifier.padding(horizontal = 6.dp), fontSize = 13.sp, color = Sb.danger)
        else if (clash) Text("There is already a box with that name in $loc.", Modifier.padding(horizontal = 6.dp), fontSize = 13.sp, color = Sb.danger)
        SheetLabel("Location")
        SheetGroup {
            ActionRow("folder", loc, sub = if (choosing) "Choose where it goes" else "Tap to move it") { choosing = !choosing }
            if (choosing) {
                SheetDivider(56.dp)
                OptionRow("Main page", inside.isBlank() || all.none { it.name == inside }, dot = null) { inside = ""; choosing = false }
                BoxTreeRows(all, inside, blocked) { inside = it.name; choosing = false }
            }
        }
        SheetLabel("Description")
        InputBox { Field(desc, { desc = it }, "Optional", 15.sp, headFont()) }
        SheetLabel("Color")
        SheetGroup { Box(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) { BoxColorDots(color) { color = it } } }
        SheetLabel("Cover")
        SheetGroup {
            ActionRow("image", if (cover == null) "Choose cover" else "Change cover") { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            if (cover != null) { SheetDivider(56.dp); ActionRow("close", "Remove cover") { cover = null } }
        }
        if (existing != null) {
            Spacer(Modifier.height(4.dp))
            val pinSet by vm.pinSet.collectAsState()
            SheetGroup {
                ActionRow("lock", if (existing.hidden) "Show this box again" else "Hide this box",
                    sub = if (existing.hidden) "Its scraps will appear everywhere again" else "Hidden, with everything in it, until you unlock it with your PIN") {
                    if (existing.hidden) { vm.setBoxHidden(existing.name, false); onDone() }
                    else {
                        val hide = { vm.setBoxHidden(existing.name, true); onDone() }
                        if (pinSet) hide() else vm.pinFlow.value = PinFlow.Create("Choose a PIN to hide boxes") { hide() }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            SheetGroup { ActionRow("trash", "Delete box", sub = "Scraps move to Inbox", danger = true) { vm.deleteShelf(existing.name); onDone() } }
        }
    }
}

/**
 * Confirm deleting a box (opened by long-pressing it, or from the box's menu). Deleting never loses scraps unless you pick
 * the second option and tap twice. Inbox is built in: removing it hides the box, and its scraps stay in All scraps.
 */
@Composable
fun DeleteBoxSheet(name: String, vm: ArchiveViewModel, onDone: () -> Unit, afterDelete: () -> Unit = {}) {
    val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    val inside = if (name == "Inbox") emptyList() else shelves.descendantsOf(name)
    val tree = setOf(name) + inside.map { it.name }
    val count = all.count { it.collection in tree }; val inbox = name == "Inbox"
    val scraps = (if (count == 1) "1 scrap" else "$count scraps") + (if (inside.isEmpty()) "" else if (inside.size == 1) " and 1 box inside" else " and ${inside.size} boxes inside")
    var sure by remember { mutableStateOf(false) }
    fun finish() { onDone(); afterDelete() }
    Sheet(if (inbox) "Remove Inbox?" else "Delete \"${shelves.labelOf(name)}\"?", onDone, doneLabel = "Cancel", soft = true) {
        SheetNote(if (inbox) "Inbox is where scraps land when you don't file them. Removing it hides the box. Your scraps stay in All scraps, and you can bring Inbox back from the Boxes screen."
            else "Your scraps are not lost: they move to Inbox." + (if (inside.isEmpty()) "" else " Boxes inside it move up one level."))
        SheetGroup {
            ActionRow("trash", if (inbox) "Remove Inbox, keep scraps" else "Delete box, keep scraps", sub = if (inbox) "Scraps stay in All scraps" else "Scraps move to Inbox") {
                if (inbox) vm.removeInbox(false) else vm.deleteShelf(name); finish()
            }
        }
        if (count > 0 || inside.isNotEmpty()) Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Sb.danger.copy(alpha = if (sure) .16f else .08f))) {
            ActionRow("trash", if (sure) "Yes, delete the box and $scraps" else "Delete the box and its $scraps…",
                sub = if (sure) "Moves $scraps to the Bin. You can restore them for $BIN_DAYS days." else null, danger = true) {
                if (!sure) sure = true else { if (inbox) vm.removeInbox(true) else vm.deleteShelfAndScraps(name); finish() }
            }
        }
    }
}

/** Confirm deleting a scrap (opened by long-pressing it in a list). It moves to the Bin; right after, an Undo snackbar brings it back. */
@Composable
fun DeleteScrapSheet(item: Item, vm: ArchiveViewModel, onDone: () -> Unit) {
    val title = item.title.ifBlank { "Untitled" }.let { if (it.length > 40) it.take(40) + "…" else it }
    Sheet("Delete \"$title\"?", onDone, doneLabel = "Cancel", soft = true) {
        SheetNote("The scrap moves to the Bin and stays there for $BIN_DAYS days. You can also tap Undo straight after.")
        SheetGroup { ActionRow("trash", "Delete scrap", danger = true) { vm.delete(item); onDone() } }
    }
}

/** Move a note into another collection. Boxes show as a tree, so a box inside another reads as "Trips > Italy" does. */
@Composable
fun MoveSheet(item: Item, vm: ArchiveViewModel, onDone: () -> Unit) = BoxPickSheet(item.collection, vm, { vm.save(item.copy(collection = it)) }, onDone)

/** The list of boxes to pick one from: [current] is the box now, [onPick] gets the choice. Used for a saved scrap (MoveSheet) and by the editor, where the box is part of what is being written. */
@Composable
fun BoxPickSheet(current: String, vm: ArchiveViewModel, onPick: (String) -> Unit, onDone: () -> Unit) = Sheet("Add to box", onDone, doneLabel = "Cancel", soft = true) {
    val shelves by vm.shelves.collectAsState(); val inboxColor by vm.inboxColor.collectAsState(); val haptics = LocalHaptics.current
    SheetGroup {
        OptionRow("Inbox", current == "Inbox", dot = if (inboxColor < 0) TAB_GRAY else TAB_COLORS[inboxColor % TAB_COLORS.size]) { haptics.confirm(); onPick("Inbox"); onDone() }
        BoxTreeRows(shelves, current) { s -> haptics.confirm(); onPick(s.name); onDone() }
    }
    if (shelves.isEmpty()) SheetNote("No boxes yet. Create one from the Boxes screen.")
}

/** Edit a note's tags. */
@Composable
fun TagSheet(item: Item, vm: ArchiveViewModel, onDone: () -> Unit) {
    var text by remember { mutableStateOf(item.tags.joinToString(", ")) }
    Sheet("Tags", { vm.save(item.copy(tags = text.split(",").map { it.trim() }.filter { it.isNotEmpty() })); onDone() }, doneLabel = "Save") {
        InputBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("tag", 20.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                Field(text, { text = it }, "Tags, separated by commas", 16.sp, headFont(), modifier = Modifier.weight(1f))
            }
        }
        SheetNote("Tags are searchable.")
    }
}

/** The box colors as tappable dots. With includeGray the first dot is gray (-1), used for Inbox. */
@Composable
fun BoxColorDots(selected: Int, includeGray: Boolean = false, onPick: (Int) -> Unit) {
    val ids = (if (includeGray) listOf(-1) else emptyList()) + TAB_COLORS.indices.toList()
    Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(10.dp)) {
        ids.forEach { i ->
            val c = if (i < 0) TAB_GRAY else TAB_COLORS[i]; val on = i == selected
            Box(Modifier.size(34.dp).clip(CircleShape).background(c).border(if (on) 2.5.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape)
                .tapIcon(if (i < 0) "Gray" else TAB_NAMES[i]) { onPick(i) }, Alignment.Center) {
                if (on) Ic("check", 18.dp, Color(0xFF161616))
            }
        }
    }
}

/** Pick a color for the Inbox box. */
@Composable
fun InboxSheet(vm: ArchiveViewModel, onDone: () -> Unit) {
    val sel by vm.inboxColor.collectAsState()
    Sheet("Inbox color", onDone, subtitle = "Shown on the Inbox tile.") {
        SheetGroup { Box(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) { BoxColorDots(sel, includeGray = true) { vm.setInboxColor(it) } } }
    }
}

@Composable
private fun ShelfCard(s: Shelf, count: Int, modifier: Modifier, nav: NavController, onHold: () -> Unit, onEdit: () -> Unit) {
    Box(modifier.appear("shelf-${s.name}").pressScale(.97f).heightIn(min = 176.dp).clip(RoundedCornerShape(28.dp)).background(Sb.surface)
        .tapOrHold("Open ${s.label}", "Delete box", onHold) { nav.navigate("shelf/${s.name}") }) {
        Box(Modifier.align(Alignment.TopEnd).padding(end = 22.dp).width(34.dp).height(9.dp)
            .clip(RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)).background(TAB_COLORS[s.color % TAB_COLORS.size]))
        Column(Modifier.padding(18.dp).fillMaxWidth()) {
            Text(s.label, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 19.sp, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
            val boxes = LocalShelves.current.childrenOf(s.name).size
            Text((if (count == 1) "1 scrap" else "$count scraps") + (if (boxes > 0) " · " + (if (boxes == 1) "1 box" else "$boxes boxes") else ""), fontSize = 13.sp, color = Sb.mute)
            if (s.parent.isNotBlank()) Text("in ${LocalShelves.current.pathOf(s.parent)}", fontSize = 12.sp, color = Sb.mute, maxLines = 1)
            if (s.description.isNotBlank()) Text(s.description, fontSize = 12.sp, color = Sb.mute, maxLines = 2, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.Bottom) {
                Box(Modifier.link("Edit ${s.label}") { onEdit() }) {
                    Text("Edit", Modifier.clip(CircleShape).background(Sb.paper).padding(horizontal = 14.dp, vertical = 7.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                ItemImage(coverOf(s), Modifier.size(54.dp, 66.dp).rotate(6f).border(2.dp, Color.White, RoundedCornerShape(10.dp)), 10.dp)
            }
        }
    }
}

/** All collections as cards with a colored tab, note count and cover. */
@Composable
fun CollectionsScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current; val all by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState()
    var edit by remember { mutableStateOf<Shelf?>(null) }; var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<String?>(null) }; val inboxHidden by vm.inboxHidden.collectAsState()
    val hasHidden by vm.hasHiddenBoxes.collectAsState(); val hiddenOpen by vm.hiddenUnlocked.collectAsState()
    // Which look the screen has (see BOXES_VIEWS). With no boxes there is nothing to lay out, so the empty message below is all that shows.
    val boxesView by vm.boxesView.collectAsState(); val counts = remember(all) { all.groupingBy { it.collection }.eachCount() }
    val view = if (shelves.isEmpty()) 0 else boxesView.coerceIn(0, BOXES_VIEWS.lastIndex)
    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = t.page) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    ScreenHeader({ nav.popBackStack() }, pad = 2.dp, trailing = { CircleBtn("New box", { creating = true }) { Ic("plus", 22.dp, Sb.ink) } })
                }
                item {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("Boxes", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 36.sp)
                        Text("  ${shelves.size}", fontSize = 14.sp, color = Sb.mute, modifier = Modifier.padding(bottom = 7.dp))
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                        Chip("All scraps · ${all.size}") { nav.navigate("shelf/All") }
                        if (inboxHidden) Chip("Show Inbox") { vm.setInboxHidden(false) }
                        else Chip("Inbox · ${all.count { it.collection == "Inbox" }}") { nav.navigate("shelf/Inbox") }
                        Spacer(Modifier.weight(1f))
                        BoxesViewSwitcher(boxesView) { vm.setBoxesView(it) }
                    }
                }
                // Only shown if some box is hidden, and it shows no names or counts. Unlocking needs the PIN or a fingerprint.
                if (hasHidden) item {
                    Row {
                        if (hiddenOpen) Chip("Lock hidden boxes") { vm.lockHiddenNow() }
                        else Chip("Hidden") { vm.pinFlow.value = PinFlow.Verify("Show hidden boxes") { vm.showHiddenBoxes() } }
                    }
                }
                if (shelves.isEmpty()) item {
                    Column(Modifier.padding(vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("No boxes yet. Make one for books, trips or ideas, then file scraps into it.", fontSize = 15.sp, color = Sb.mute)
                        NewBoxPill { creating = true }
                    }
                }
                when (view) {
                    1 -> item { BoxesNested(shelves, counts, { nav.navigate("shelf/$it") }, { deleting = it }, { edit = it }) { creating = true } }
                    2 -> item { BoxesShelf(shelves, counts, { nav.navigate("shelf/$it") }) { deleting = it } }
                    3 -> item { BoxesCover(shelves, counts, { nav.navigate("shelf/$it") }) { deleting = it } }
                    4 -> item { BoxesStack(shelves, counts, { nav.navigate("shelf/$it") }, { deleting = it }) { edit = it } }
                    else -> items(shelves.chunked(2)) { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            pair.forEach { s -> ShelfCard(s, all.count { it.collection == s.name }, Modifier.weight(1f), nav, { deleting = s.name }) { edit = s } }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        if (creating) ShelfSheet(vm, null, onDone = { creating = false })
        edit?.let { ShelfSheet(vm, it, onDone = { edit = null }) }
        deleting?.let { n -> DeleteBoxSheet(n, vm, { deleting = null }) }
    }
}
