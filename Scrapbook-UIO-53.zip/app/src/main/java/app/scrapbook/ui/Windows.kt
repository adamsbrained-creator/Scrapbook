package app.scrapbook.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// The building blocks every small window shares: popup menus, sheet contents and screen headers.
// They use the same tokens, corners and row sizes as the Settings page and the editor's 3-dot menu, so a new window only has to put them together.

// ---------------------------------------------------------------------------------------------------------------------------------
// Popup menus
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * A popup menu that looks like the editor's 3-dot menu: 24dp corners, the lifted menu color and a hairline. Fill it with PopupItem rows.
 * The corners and the width come from the menu skin (24dp and 248dp in Classic), see MenuSkins.kt.
 */
@Composable
fun PopupMenu(expanded: Boolean, onDismiss: () -> Unit, container: Color = Sb.menu, line: Color = Sb.menuLine, content: @Composable ColumnScope.() -> Unit) {
    val skin = menuSkin()
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss, modifier = Modifier.width(skin.popupWidth),
        shape = RoundedCornerShape(skin.popupCorner), containerColor = container, tonalElevation = 0.dp, shadowElevation = 18.dp,
        border = BorderStroke(1.dp, line), content = content)
}

/**
 * One row of a PopupMenu: an icon (or your own leading content), the label, an optional second line, and a check mark for the current choice.
 * Use tint = Sb.danger for destructive rows.
 */
@Composable
fun PopupItem(label: String, icon: String? = null, sub: String? = null, checked: Boolean = false, tint: Color = Sb.ink,
              leading: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    val sans = LocalFonts.current.second; val acc = LocalSb.current.acc
    Row(Modifier.pressScale(.97f).fillMaxWidth().padding(horizontal = 8.dp).heightIn(min = if (sub != null) 58.dp else 52.dp).clip(RoundedCornerShape(16.dp))
        .tap(label, onClick).padding(horizontal = 12.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        if (leading != null) leading() else if (icon != null) Ic(icon, 22.dp, tint)
        Column(Modifier.weight(1f)) {
            Text(label, color = tint, fontSize = 16.sp, lineHeight = 20.sp, fontFamily = sans, fontWeight = if (checked) FontWeight.Medium else FontWeight.Normal,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) Text(sub, color = Sb.mute, fontSize = 12.5.sp, lineHeight = 16.sp, fontFamily = sans, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (checked) Ic("check", 20.dp, accentText(acc))
    }
}

@Composable
fun PopupDivider() {
    Box(Modifier.padding(horizontal = 20.dp, vertical = 4.dp).fillMaxWidth().height(1.dp).background(Sb.menuLine))
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Sheet contents
// ---------------------------------------------------------------------------------------------------------------------------------

/** Small uppercase label above a group in a sheet or panel. */
@Composable
fun SheetLabel(text: String, start: Dp = 6.dp) {
    Text(text.uppercase(), Modifier.padding(start = start, top = 10.dp).asHeading(), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp, color = Sb.mute)
}

/** Muted helper text under a label or group. */
@Composable
fun SheetNote(text: String) {
    Text(text, Modifier.padding(horizontal = 6.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
}

/** A rounded card holding rows, the same grouping the menu and Settings use (soft grey in Classic, outlined in Float). Put a SheetDivider between rows. */
@Composable
fun SheetGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().skinCard(), content = content)
}

/** The hairline between rows of a SheetGroup. start is how far in it begins (56dp lines up with the text after a 24dp icon). */
@Composable
fun SheetDivider(start: Dp = 18.dp) {
    Box(Modifier.padding(start = start, end = 18.dp).fillMaxWidth().height(1.dp).background(Sb.line))
}

/** A row that does something when tapped: icon, label and an optional second line. danger makes it red. */
@Composable
fun ActionRow(icon: String, label: String, sub: String? = null, danger: Boolean = false, onClick: () -> Unit) {
    val tint = if (danger) Sb.danger else Sb.ink
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 58.dp).tap(label, onClick).padding(horizontal = 18.dp, vertical = 8.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        Ic(icon, 24.dp, tint)
        Column(Modifier.weight(1f)) {
            Text(label, color = tint, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = Sb.mute, fontSize = 13.sp, lineHeight = 17.sp)
        }
    }
}

/** A row in a list of choices: optional color dot, label, an optional second line and a check on the current one. indent pushes it in, for a row that sits inside another. */
@Composable
fun OptionRow(label: String, on: Boolean, sub: String? = null, dot: Color? = null, indent: Dp = 0.dp, onClick: () -> Unit) {
    val acc = LocalSb.current.acc
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 56.dp).semantics { selected = on }.tap(label, onClick).padding(start = 18.dp + indent, end = 18.dp, top = 8.dp, bottom = 8.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        if (dot != null) Box(Modifier.size(14.dp).clip(CircleShape).background(dot))
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) Text(sub, color = Sb.mute, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (on) Ic("check", 22.dp, accentText(acc))
    }
}

/** A row with an on/off switch. icon is optional. */
@Composable
fun ToggleRow(icon: String?, label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val acc = LocalSb.current.acc; val off = if (Sb.dark) Color(0xFF3A3A3A) else Color(0xFFCFCFCF); val haptics = LocalHaptics.current
    val thumb by animateDpAsState(if (on) 20.dp else 0.dp, spring(dampingRatio = .75f, stiffness = Spring.StiffnessMedium), label = "thumb")
    val track by animateColorAsState(if (on) acc else off, tween(180), label = "track")
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 58.dp).toggleable(value = on, role = Role.Switch, onValueChange = { haptics.toggle(it); onChange(it) }).padding(horizontal = 18.dp, vertical = 8.dp),
        Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
        if (icon != null) Ic(icon, 24.dp, Sb.ink)
        Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Box(Modifier.size(50.dp, 30.dp).clip(CircleShape).background(track), Alignment.CenterStart) {
            Box(Modifier.padding(3.dp).offset(x = thumb).size(24.dp).shadow(1.dp, CircleShape).clip(CircleShape).background(Color.White))
        }
    }
}

/**
 * A pill to pick one option. The chosen one is filled with the ink color. container is the color of the others: leave it on a sheet,
 * and pass Sb.paper when the chip sits on a card (Sb.card), where the default would almost disappear.
 */
@Composable
fun SoftChip(text: String, on: Boolean = false, container: Color = Sb.line.copy(alpha = .5f), dot: Color? = null, onClick: () -> Unit) {
    val bg by animateColorAsState(if (on) Sb.ink else container, tween(160), label = "chip")
    val fg by animateColorAsState(if (on) Sb.paper else Sb.ink, tween(160), label = "chipText")
    Row(Modifier.pressScale(.94f).minimumInteractiveComponentSize().semantics { selected = on }.clip(CircleShape).background(bg).tap(text, onClick)
        .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (dot != null) { Box(Modifier.size(10.dp).clip(CircleShape).background(dot)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = fg, maxLines = 1)
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Screens
// ---------------------------------------------------------------------------------------------------------------------------------

/**
 * The header the inner screens share with Settings and About: a round back button, a centered title and room for one round button on the right.
 * pad is the space from the screen edge: 18dp, or less when the screen already has its own side padding.
 */
@Composable
fun ScreenHeader(onBack: () -> Unit, title: String = "scrapbook", backIcon: String = "back", backDesc: String = "Go back", pad: Dp = 18.dp, onHome: (() -> Unit)? = null,
                 trailing: @Composable RowScope.() -> Unit = { Spacer(Modifier.size(44.dp)) }) {
    Row(Modifier.fillMaxWidth().padding(start = pad, end = pad, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleBtn(backDesc, onBack, onHome, "Go to Home") { Ic(backIcon, 22.dp, Sb.ink) }
        Box(Modifier.weight(1f), Alignment.Center) {
            Text(title, Modifier.asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

/** The dashed "New box" button, with its own label. */
@Composable
fun NewBoxPill(label: String = "New box", onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(Modifier.pressScale(.95f).height(48.dp).clip(shape).dashedOutline(Sb.mute.copy(alpha = .5f), shape).tap(label, onClick).padding(horizontal = 18.dp),
        Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
        Ic("plus", 18.dp, Sb.mute); Text(label, fontSize = 16.sp, color = Sb.mute)
    }
}
