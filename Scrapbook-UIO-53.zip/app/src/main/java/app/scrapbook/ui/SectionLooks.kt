package app.scrapbook.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// The layouts of a Home section that came after Cards, Chips, Rows and Grid: Carousel, Hero, Banner, Mosaic, Tiles, Timeline, Lines, Compact and Agenda (ui/AgendaParts.kt).
// Each one draws the same things a section holds (boxes and scraps, and what a smart section finds) from the same Entry, is held and carried the same way
// (the [held] wrapper SectionBlock gives), and fits the size you give the section: it fills the height when there is one and scrolls inside it when it does not fit.
// The numbers (how many tiles, how tall a mosaic card is) are in SectionShapes.kt and tested there. The picker in Edit section is LayoutPicker at the bottom.

/** The wrapper that makes one thing holdable (its menu, carrying it); given by SectionBlock. */
internal typealias HeldWrap = @Composable (Entry, Modifier, @Composable () -> Unit) -> Unit

/**
 * Draws [entries] (never empty) in one of the newer layouts. [boxW] is the width the things have, [h] the height of the box in dp (0 is automatic), and [padded] is true when the
 * section has no size of its own and so sits between the page's 20dp margins, which the layout then adds itself.
 */
@Composable
internal fun SectionShapeBody(layout: SectionLayout, entries: List<Entry>, preview: Boolean, boxW: Dp, h: Int, padded: Boolean, held: HeldWrap, style: SectionStyle = SectionStyle(), open: (Entry) -> Unit) {
    val pad = if (padded) 20.dp else 0.dp
    when (layout) {
        SectionLayout.Carousel -> CarouselShape(entries, preview, boxW, h, pad, held, open)
        SectionLayout.Hero -> HeroShape(entries, preview, boxW, h, pad, held, open)
        SectionLayout.Banner -> ScrollColumn(h, pad) { entries.forEach { e -> held(e, Modifier.fillMaxWidth()) { BannerRow(e, preview) { open(e) } } } }
        SectionLayout.Mosaic -> MosaicShape(entries, preview, h, pad, held, open)
        SectionLayout.Tiles -> TilesShape(entries, boxW, h, pad, held, open)
        SectionLayout.Timeline -> TimelineShape(entries, preview, h, pad, style, held, open)
        SectionLayout.Agenda -> AgendaShape(entries, style, h, pad, held, open)
        SectionLayout.Lines -> ScrollColumn(h, pad, gap = 0.dp) {
            entries.forEachIndexed { i, e ->
                held(e, Modifier.fillMaxWidth()) { LineRow(e) { open(e) } }
                if (i < entries.lastIndex) Box(Modifier.fillMaxWidth().height(1.dp).background(Sb.line.copy(alpha = .7f)))
            }
        }
        SectionLayout.Compact -> ScrollColumn(h, pad, gap = 10.dp) {
            entries.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                    pair.forEach { e -> held(e, Modifier.weight(1f)) { CompactCell(e) { open(e) } } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        // The first four are drawn by SectionBlock itself.
        SectionLayout.Cards, SectionLayout.Chips, SectionLayout.Rows, SectionLayout.Grid -> {}
    }
}

/**
 * A part of Home (Continue, Boxes, Pinned, Recent) drawn in one of the section layouts, between the page's 20dp margins ([padded] false when the part already sits between
 * them). [held] makes each thing holdable like it is in the part's own designs and [open] opens it.
 */
@Composable
internal fun PartShape(layout: SectionLayout, entries: List<Entry>, preview: Boolean, held: HeldWrap, padded: Boolean = true, open: (Entry) -> Unit) {
    if (entries.isEmpty()) return
    BoxWithConstraints(Modifier.fillMaxWidth()) { SectionShapeBody(layout, entries, preview, if (padded) maxWidth - 40.dp else maxWidth, 0, padded, held, open = open) }
}

/** A scrap as one thing of a layout; [dot] is its box's color, if it should show one. */
internal fun scrapEntry(n: Item, dot: Color? = null) = Entry(SectionRef(false, n.uid), n, n.displayTitle, dot, 0)

/** A box as one thing of a layout. */
internal fun boxEntry(b: BoxTile) = Entry(SectionRef(true, b.name), null, b.label, b.tab, b.count)

/** Makes the things of a part of Home holdable the way the part's own designs do: a scrap with its menu (where it sits is [where]), a box with its menu. */
internal fun partHeld(where: String): HeldWrap = { e, m, c ->
    val n = e.scrap
    if (n != null) HeldScrap(n, where, m, c) else HeldBox(e.ref.key, e.label, e.dot ?: TAB_GRAY, m, c)
}

/** For a thing that is already held by whatever is around it (the Continue card). */
internal val NotHeld: HeldWrap = { _, m, c -> Box(m) { c() } }

/** A column of things 12dp apart (or [gap]) that scrolls inside the box when the section has a height of its own. */
@Composable
private fun ScrollColumn(h: Int, pad: Dp, gap: Dp = 12.dp, content: @Composable ColumnScope.() -> Unit) {
    val scroll = rememberScrollState()
    Column(Modifier.fillMaxWidth().then(if (h > 0) Modifier.fillMaxHeight().verticalScroll(scroll) else Modifier).padding(horizontal = pad), Arrangement.spacedBy(gap), content = content)
}

private fun Entry.accentOf(fallback: Color): Color = dot ?: fallback

/** The line under a title: a scrap's date, a box's count. */
private fun Entry.subText(): String = scrap?.let { fmtDate(it.savedAt, true) } ?: countText(count)

/** The first part of a scrap's text, cut short; empty for a box. */
@Composable
private fun previewOf(e: Entry, preview: Boolean, limit: Int = 160): String {
    val n = e.scrap ?: return ""
    if (!preview) return ""
    return remember(n.title, n.body) { previewHead(n.title, n.body, limit) }
}

// ----- Carousel and Hero: big cards -----

/** A big card: a scrap shows its date, its title and as much of its text as fits; a box its color, its name and how many scraps are in it. */
@Composable
private fun BigCard(e: Entry, preview: Boolean, modifier: Modifier, height: Dp, titleSp: Int, onClick: () -> Unit) {
    val n = e.scrap
    val acc = LocalSb.current.acc
    val tint = e.accentOf(acc)
    val lines = SectionShapes.previewLines(height.value, 100f + titleSp)
    val text = previewOf(e, preview, 600)
    Column(modifier.pressScale(.97f).height(height).homeCard(28.dp).then(if (n == null) Modifier.background(tint.copy(alpha = .14f)) else Modifier)
        .tap("Open ${e.label}", onClick).padding(horizontal = 20.dp, vertical = 18.dp), Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(tint))
            Spacer(Modifier.width(8.dp))
            Text(e.subText(), Modifier.weight(1f), fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n != null && n.pinned) Ic("star", 14.dp, Color(0xFFFFB400))
        }
        Text(e.label, Modifier.padding(top = 4.dp), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = titleSp.sp, lineHeight = (titleSp + 5).sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (n != null && text.isNotBlank()) Text(text, Modifier.padding(top = 4.dp), fontSize = 14.sp, lineHeight = 19.sp, color = Sb.mute, maxLines = lines, overflow = TextOverflow.Ellipsis)
        if (n == null) { Spacer(Modifier.weight(1f)); Text(countText(e.count), fontSize = 15.sp, color = Sb.mute) }
    }
}

/** A small card: a title (two lines) and the date or count. */
@Composable
private fun MiniCard(e: Entry, modifier: Modifier, height: Dp, onClick: () -> Unit) {
    val tint = e.accentOf(Sb.mute)
    Column(modifier.pressScale(.96f).height(height).homeCard(22.dp).tap("Open ${e.label}", onClick).padding(horizontal = 14.dp, vertical = 12.dp), Arrangement.SpaceBetween) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(tint))
        Column {
            Text(e.label, fontSize = 15.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(e.subText(), fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CarouselShape(entries: List<Entry>, preview: Boolean, boxW: Dp, h: Int, pad: Dp, held: HeldWrap, open: (Entry) -> Unit) {
    val state = rememberLazyListState()
    val cardW = SectionShapes.carouselWidth(boxW.value).dp
    LazyRow(if (h > 0) Modifier.fillMaxSize() else Modifier, state = state, contentPadding = PaddingValues(horizontal = pad), horizontalArrangement = Arrangement.spacedBy(12.dp),
        flingBehavior = rememberSnapFlingBehavior(state)) {
        items(entries, key = { it.token }) { e -> held(e, Modifier) { BigCard(e, preview, Modifier.width(cardW), if (h > 0) h.dp else 172.dp, 22) { open(e) } } }
    }
}

@Composable
private fun HeroShape(entries: List<Entry>, preview: Boolean, boxW: Dp, h: Int, pad: Dp, held: HeldWrap, open: (Entry) -> Unit) {
    val first = entries.first(); val rest = entries.drop(1)
    val (heroH, stripH) = SectionShapes.heroHeights(h)
    Column(Modifier.fillMaxWidth().padding(horizontal = pad), Arrangement.spacedBy(12.dp)) {
        held(first, Modifier.fillMaxWidth()) { BigCard(first, preview, Modifier.fillMaxWidth(), (if (rest.isEmpty() && h > 0) h.toFloat() else heroH).dp, 26) { open(first) } }
        if (rest.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(rest, key = { it.token }) { e -> held(e, Modifier) { MiniCard(e, Modifier.width(140.dp), stripH.dp) { open(e) } } }
        }
    }
}

// ----- Banner -----

/** A wide band: a bar in the color of the box (or the accent for a scrap), a big title, and the date and the start of the text, or the count. */
@Composable
private fun BannerRow(e: Entry, preview: Boolean, onClick: () -> Unit) {
    val n = e.scrap
    val tint = e.accentOf(LocalSb.current.acc)
    val text = previewOf(e, preview, 90).replace('\n', ' ')
    Row(Modifier.pressScale(.98f).fillMaxWidth().height(92.dp).homeCard(28.dp).background(tint.copy(alpha = if (n == null) .16f else .07f))
        .tap("Open ${e.label}", onClick), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.padding(start = 12.dp).width(6.dp).fillMaxHeight(.6f).clip(RoundedCornerShape(3.dp)).background(tint))
        Column(Modifier.weight(1f).padding(horizontal = 16.dp), Arrangement.spacedBy(2.dp)) {
            Text(e.label, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (text.isBlank()) e.subText() else e.subText() + " · " + text, fontSize = 13.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (n != null && n.pinned) { Ic("star", 16.dp, Color(0xFFFFB400)); Spacer(Modifier.width(14.dp)) }
        else Box(Modifier.padding(end = 16.dp)) { Ic("chevron", 18.dp, Sb.mute) }
    }
}

// ----- Mosaic -----

@Composable
private fun MosaicCard(e: Entry, preview: Boolean, height: Dp, onClick: () -> Unit) {
    val n = e.scrap
    val tint = e.accentOf(Sb.mute)
    val lines = SectionShapes.previewLines(height.value, 74f)
    val text = previewOf(e, preview, 300)
    Column(Modifier.pressScale(.97f).fillMaxWidth().height(height).homeCard(24.dp).then(if (n == null) Modifier.background(tint.copy(alpha = .14f)) else Modifier)
        .tap("Open ${e.label}", onClick).padding(horizontal = 16.dp, vertical = 14.dp), Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(tint)); Spacer(Modifier.width(7.dp))
            Text(e.subText(), Modifier.weight(1f), fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n != null && n.pinned) Ic("star", 13.dp, Color(0xFFFFB400))
        }
        Text(e.label, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 17.sp, lineHeight = 21.sp, maxLines = if (n == null) 2 else 3, overflow = TextOverflow.Ellipsis)
        if (n != null && text.isNotBlank()) Text(text, fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute, maxLines = lines, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun MosaicShape(entries: List<Entry>, preview: Boolean, h: Int, pad: Dp, held: HeldWrap, open: (Entry) -> Unit) {
    val heights = entries.map { SectionShapes.mosaicHeight(it.scrap == null, it.scrap?.body?.length ?: 0) }
    val (left, right) = remember(heights) { SectionShapes.splitColumns(heights) }
    val scroll = rememberScrollState()
    Row(Modifier.fillMaxWidth().then(if (h > 0) Modifier.fillMaxHeight().verticalScroll(scroll) else Modifier).padding(horizontal = pad), Arrangement.spacedBy(12.dp)) {
        listOf(left, right).forEach { column ->
            Column(Modifier.weight(1f), Arrangement.spacedBy(12.dp)) {
                column.forEach { i -> val e = entries[i]; held(e, Modifier.fillMaxWidth()) { MosaicCard(e, preview, heights[i].dp) { open(e) } } }
            }
        }
    }
}

// ----- Tiles -----

/** A small square: a round badge in the color of the box (a page for a scrap), the count for a box, and the name under it. */
@Composable
private fun Tile(e: Entry, modifier: Modifier, onClick: () -> Unit) {
    val tint = e.accentOf(Sb.mute)
    Column(modifier.pressScale(.95f).aspectRatio(1f).homeCard(24.dp).tap("Open ${e.label}", onClick).padding(12.dp), Arrangement.SpaceBetween) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(30.dp).clip(CircleShape).background(tint.copy(alpha = .25f)), Alignment.Center) { Ic(if (e.scrap == null) "folder" else "page", 16.dp, if (e.dot != null) tint else Sb.ink) }
            Spacer(Modifier.weight(1f))
            if (e.scrap == null) Text("${e.count}", fontSize = 13.sp, color = Sb.mute)
            else if (e.scrap.pinned) Ic("star", 13.dp, Color(0xFFFFB400))
        }
        Text(e.label, fontSize = 14.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TilesShape(entries: List<Entry>, boxW: Dp, h: Int, pad: Dp, held: HeldWrap, open: (Entry) -> Unit) {
    val cols = SectionShapes.tileColumns(boxW.value)
    ScrollColumn(h, pad, gap = 10.dp) {
        entries.chunked(cols).forEach { group ->
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                group.forEach { e -> held(e, Modifier.weight(1f)) { Tile(e, Modifier.fillMaxWidth()) { open(e) } } }
                repeat(cols - group.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

// ----- Timeline -----
// A line down the left with a round dot for each thing, as in the mockup: the newest dot is solid, the next one has a ring, the rest are dim, and the line fades down the page.
// Each dot shows an icon: the one you gave the thing, else the thing's own emoji, else one for what it is. How wide it is, how many things, the space between them, the size of the dots,
// the style of the line and how much text sits beside each one are the section's SectionStyle (Edit section); the same look is used, with the usual choices, by the Timeline design of the parts.

private fun kindIcon(n: Item): String = when (n.kind) {
    Kind.Link -> "link"
    Kind.Image -> "image"
    Kind.Voice -> "mic"
    Kind.Quote -> "quote"
    else -> if ("- [ ] " in n.body || "- [x] " in n.body) "taskcheck" else "page"
}

/** What is inside a dot: an emoji is drawn as text, anything else is the name of an icon. */
@Composable
internal fun NodeGlyph(e: Entry, style: SectionStyle, tint: Color, node: Dp) {
    val custom = style.iconOf(e.token)
    val n = e.scrap
    val own = n?.icon.orEmpty()
    val inner = (node.value * .5f).dp
    val emoji = (node.value * .46f).sp
    when {
        custom != null && custom.any { it.code > 127 } -> Text(custom, fontSize = emoji)
        custom != null -> Ic(custom, inner, tint)
        own.isNotEmpty() -> Text(own, fontSize = emoji)
        n == null -> Ic("folder", inner, e.dot ?: tint)
        else -> Ic(kindIcon(n), inner, tint)
    }
}

/**
 * One stop: the dot (with the line leaving it for the next one) and, beside it, the title, the date and the start of the text. Everything that can differ is a choice of [style]: which side the line
 * is on, the shape and color of the dots, which of them are bright, how thick the line is and how big the text is.
 */
@Composable
private fun TimelineStop(e: Entry, i: Int, count: Int, preview: Boolean, style: SectionStyle, spread: Boolean, onClick: () -> Unit) {
    val rank = TimelineMetrics.rank(i, count, style)
    val nextRank = TimelineMetrics.rank(i + 1, count, style)
    val last = i == count - 1
    val right = style.tlSide == 1
    val node = style.tlNode.dp
    val paper = Sb.paper
    val lineColor = Sb.line
    val acc = LocalSb.current.acc
    val strong = if (style.tlColor == 1) acc else Sb.ink
    val onStrong = if (style.tlColor == 1) onAccent(acc) else paper
    val bright = when (style.tlGlow) { 1 -> false; 2 -> true; else -> rank == 0 }
    val ringed = style.tlGlow == 0 && rank == 1
    val bare = style.tlShape == 2
    val shape: Shape = if (style.tlShape == 1) RoundedCornerShape((style.tlNode * .3f).dp) else CircleShape
    val fill = if (bare) Color.Transparent else if (bright) strong else if (ringed) paper else Sb.surface
    val tint = if (bare) (if (bright || ringed) strong else Sb.mute) else if (bright) onStrong else if (ringed) strong else Sb.mute
    val text = if (style.tlText == 0) previewOf(e, preview, 120).replace('\n', ' ') else ""
    val denom = if (count <= 1) 1f else count - 1f
    val from = rank / denom
    val to = nextRank / denom
    val size = when (style.tlTextSize) { 0 -> 0 ; 2 -> 2 ; else -> 1 }
    val titleSp = listOf(15, 17, 20)[size]
    val subSp = listOf(12, 14, 16)[size]
    val bodySp = listOf(13, 14, 16)[size]
    val strokeW = style.tlLineW
    val align = if (right) TextAlign.End else TextAlign.Start
    val textColumn: @Composable RowScope.() -> Unit = {
        Column(Modifier.weight(1f).padding(bottom = if (last) 0.dp else if (spread) 8.dp else style.tlGap.dp), Arrangement.spacedBy(2.dp), if (right) Alignment.End else Alignment.Start) {
            Text(e.label, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = titleSp.sp, lineHeight = (titleSp * 1.3f).sp, textAlign = align, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (style.tlText <= 1) Text(e.subText(), fontSize = subSp.sp, lineHeight = (subSp * 1.4f).sp, color = Sb.mute, textAlign = align, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (text.isNotBlank()) Text(text, Modifier.padding(top = 2.dp), fontSize = bodySp.sp, lineHeight = (bodySp * 1.35f).sp, color = Sb.mute.copy(alpha = .8f), textAlign = align, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
    val rail: @Composable RowScope.() -> Unit = {
        Box(Modifier.width(node).fillMaxHeight().drawBehind {
            if (!last) {
                // `size` is also a local (the text size step) in this function, so the drawing area's size is asked for with this.
                val x = this.size.width / 2f
                val y0 = node.toPx() - 2.dp.toPx()
                val y1 = this.size.height
                val w = strokeW.dp.toPx()
                when (style.tlLine) {
                    1 -> drawLine(lineColor, Offset(x, y0), Offset(x, y1), w, StrokeCap.Round)
                    2 -> drawLine(lineColor, Offset(x, y0), Offset(x, y1), w * 1.25f, StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(1f, 3.5f * w), 0f))
                    else -> drawLine(Brush.verticalGradient(listOf(lerp(strong, lineColor, from), lerp(strong, lineColor, to)), startY = y0, endY = y1), Offset(x, y0), Offset(x, y1), w, StrokeCap.Round)
                }
            }
        }) {
            Box(Modifier.size(node).clip(shape).background(fill).then(if (ringed && !bare) Modifier.border(3.dp, strong, shape) else Modifier), Alignment.Center) { NodeGlyph(e, style, tint, node) }
        }
    }
    Row(Modifier.pressScale(.98f).fillMaxWidth().then(if (spread) Modifier.fillMaxHeight() else Modifier.height(IntrinsicSize.Min)).tap("Open ${e.label}", onClick), Arrangement.spacedBy(16.dp)) {
        if (right) { textColumn(); rail() } else { rail(); textColumn() }
    }
}

/** The whole timeline: [style] says how wide it is and where it sits, which end is the newest, how many things it shows and how it uses a height (it scrolls inside it, or, when asked to, shares it between the things). */
@Composable
private fun TimelineShape(entries: List<Entry>, preview: Boolean, h: Int, pad: Dp, style: SectionStyle, held: HeldWrap, open: (Entry) -> Unit) {
    val limited = entries.take(TimelineMetrics.shown(entries.size, style))
    val shown = if (style.tlOldest) limited.reversed() else limited
    val spread = style.tlSpread && TimelineMetrics.spreadRow(h, shown.size) != null
    val corner = when (style.tlAlign) { 1 -> Alignment.TopCenter; 2 -> Alignment.TopEnd; else -> Alignment.TopStart }
    Box(Modifier.fillMaxWidth().then(if (h > 0) Modifier.fillMaxHeight() else Modifier).padding(horizontal = pad), corner) {
        val body = Modifier.fillMaxWidth(style.tlWidth / 100f).then(if (spread) Modifier.fillMaxHeight() else if (h > 0) Modifier.verticalScroll(rememberScrollState()) else Modifier)
        Column(body) {
            shown.forEachIndexed { i, e ->
                held(e, Modifier.fillMaxWidth().then(if (spread) Modifier.weight(1f) else Modifier)) { TimelineStop(e, i, shown.size, preview, style, spread) { open(e) } }
            }
        }
    }
}

// ----- Lines and Compact -----

/** A plain line: a dot (or a page icon), the name, and the date or count on the right. No card behind it. */
@Composable
private fun LineRow(e: Entry, onClick: () -> Unit) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().height(52.dp).tap("Open ${e.label}", onClick), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        if (e.dot != null) Box(Modifier.size(12.dp).clip(CircleShape).background(e.dot)) else Ic("page", 18.dp, Sb.mute)
        Text(e.label, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(e.subText(), fontSize = 13.sp, color = Sb.mute, maxLines = 1)
    }
}

/** One half of a compact row: a dot (or a page icon) and the name. */
@Composable
private fun CompactCell(e: Entry, onClick: () -> Unit) {
    Row(Modifier.pressScale(.96f).fillMaxWidth().height(48.dp).homeCard(18.dp).tap("Open ${e.label}", onClick).padding(horizontal = 14.dp), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
        if (e.dot != null) Box(Modifier.size(11.dp).clip(CircleShape).background(e.dot)) else Ic("page", 16.dp, Sb.mute)
        Text(e.label, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ----- The picker in Edit section -----

/** A tiny drawing of a layout, in the colors of the theme, for the picker. */
@Composable
private fun SectionGlyph(l: SectionLayout, modifier: Modifier = Modifier) {
    val fill = Sb.ink.copy(alpha = .22f); val strong = Sb.ink.copy(alpha = .45f)
    fun Modifier.shape(color: Color = fill, r: Int = 5) = clip(RoundedCornerShape(r.dp)).background(color)
    Box(modifier.fillMaxWidth().height(50.dp), Alignment.Center) {
        when (l) {
            SectionLayout.Cards -> Row(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) { repeat(3) { Box(Modifier.weight(1f).fillMaxHeight().shape()) } }
            SectionLayout.Chips -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(6.dp, Alignment.CenterVertically)) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { Box(Modifier.width(26.dp).height(14.dp).shape(r = 7)); Box(Modifier.width(18.dp).height(14.dp).shape(r = 7)); Box(Modifier.width(22.dp).height(14.dp).shape(r = 7)) }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { Box(Modifier.width(20.dp).height(14.dp).shape(r = 7)); Box(Modifier.width(28.dp).height(14.dp).shape(r = 7)) }
            }
            SectionLayout.Rows -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) { repeat(3) { Box(Modifier.fillMaxWidth().weight(1f).shape()) } }
            SectionLayout.Grid -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) {
                repeat(2) { Row(Modifier.weight(1f), Arrangement.spacedBy(5.dp)) { repeat(2) { Box(Modifier.weight(1f).fillMaxHeight().shape()) } } }
            }
            SectionLayout.Carousel -> Row(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) { Box(Modifier.weight(5f).fillMaxHeight().shape(strong)); Box(Modifier.weight(1.4f).fillMaxHeight().shape()) }
            SectionLayout.Hero -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) {
                Box(Modifier.fillMaxWidth().weight(1.6f).shape(strong))
                Row(Modifier.weight(1f), Arrangement.spacedBy(5.dp)) { repeat(3) { Box(Modifier.weight(1f).fillMaxHeight().shape()) } }
            }
            SectionLayout.Banner -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) {
                repeat(2) { Row(Modifier.fillMaxWidth().weight(1f).shape(), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.padding(start = 5.dp).width(3.dp).fillMaxHeight(.6f).shape(strong, 2)) } }
            }
            SectionLayout.Mosaic -> Row(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) {
                Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.spacedBy(5.dp)) { Box(Modifier.fillMaxWidth().weight(1.6f).shape()); Box(Modifier.fillMaxWidth().weight(1f).shape()) }
                Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.spacedBy(5.dp)) { Box(Modifier.fillMaxWidth().weight(1f).shape()); Box(Modifier.fillMaxWidth().weight(1.6f).shape()) }
            }
            SectionLayout.Tiles -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) {
                repeat(2) { Row(Modifier.weight(1f), Arrangement.spacedBy(5.dp)) { repeat(4) { Box(Modifier.weight(1f).fillMaxHeight().shape(r = 4)) } } }
            }
            SectionLayout.Timeline -> Row(Modifier.fillMaxSize(), Arrangement.spacedBy(6.dp)) {
                Box(Modifier.padding(start = 3.dp).width(2.dp).fillMaxHeight().shape(strong, 1))
                Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.SpaceEvenly) {
                    repeat(3) { Box(Modifier.fillMaxWidth(if (it == 1) .6f else .85f).height(8.dp).shape()) }
                }
            }
            SectionLayout.Lines -> Column(Modifier.fillMaxSize(), Arrangement.SpaceEvenly) {
                repeat(3) { Box(Modifier.fillMaxWidth().height(2.dp).shape(fill, 1)) }
            }
            SectionLayout.Compact -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(5.dp)) {
                repeat(3) { Row(Modifier.weight(1f), Arrangement.spacedBy(5.dp)) { repeat(2) { Box(Modifier.weight(1f).fillMaxHeight().shape(r = 4)) } } }
            }
            SectionLayout.Agenda -> Column(Modifier.fillMaxSize(), Arrangement.spacedBy(4.dp)) {
                Box(Modifier.width(22.dp).height(5.dp).shape(strong, 2))
                repeat(2) { Row(Modifier.fillMaxWidth().weight(1f).shape(r = 7), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.padding(start = 4.dp).size(14.dp).shape(strong, 4)) } }
            }
        }
    }
}

/** Every layout as a small picture with its name, three to a row, the chosen one outlined. The line under it says what the chosen layout is. */
@Composable
internal fun LayoutPicker(current: SectionLayout, onPick: (SectionLayout) -> Unit) {
    val haptics = LocalHaptics.current
    Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
        SectionLayout.entries.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                row.forEach { l ->
                    val on = l == current
                    val shape = RoundedCornerShape(18.dp)
                    Column(Modifier.weight(1f).pressScale(.96f).clip(shape).background(Sb.line.copy(alpha = .4f)).then(if (on) Modifier.border(2.dp, Sb.ink, shape) else Modifier)
                        .semantics { selected = on }.tap(l.label) { if (!on) { haptics.tick(); onPick(l) } }.padding(10.dp), Arrangement.spacedBy(8.dp)) {
                        SectionGlyph(l)
                        Text(l.label, Modifier.fillMaxWidth(), fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Text(current.note, Modifier.padding(horizontal = 6.dp), fontSize = 13.sp, lineHeight = 18.sp, color = Sb.mute)
    }
}
