package app.scrapbook.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import app.scrapbook.ArchiveViewModel

/** What the file picker offers when importing notes: text and Markdown, Word files, zips and Samsung Notes files (which Android calls "octet-stream"). */
val IMPORT_MIME_TYPES = arrayOf("text/*", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/zip", "application/octet-stream")

/** Import notes straight into a box: [files] picks files, [folder] picks a folder (its own folders become boxes inside the chosen box). */
class BoxImporter(val files: (String) -> Unit, val folder: (String) -> Unit)

/**
 * The two pickers behind "Import notes here" and "Import a folder here" in a box's menu. The notes go to the box that asked, and [say] gets the result
 * ("Imported 12 scraps. 2 were already here.") when the import is done.
 */
@Composable
fun rememberBoxImporter(vm: ArchiveViewModel, say: (String) -> Unit): BoxImporter {
    var target by remember { mutableStateOf("Inbox") }
    val speak by rememberUpdatedState(say)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        if (us.isNotEmpty()) { speak("Importing…"); vm.importTexts(us, target) { r -> speak(r.message()) } }
    }
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { speak("Importing…"); vm.importFolder(u, target) { r -> speak(r.message()) } }
    }
    return remember(picker, treePicker) {
        BoxImporter({ box -> target = box; picker.launch(IMPORT_MIME_TYPES) }, { box -> target = box; treePicker.launch(null) })
    }
}
