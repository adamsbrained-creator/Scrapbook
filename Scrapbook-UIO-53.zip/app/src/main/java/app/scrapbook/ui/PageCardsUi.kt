package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import app.scrapbook.*
import coil.compose.AsyncImage
import kotlin.math.roundToInt

// The cards of a Cards page (see PageCards.kt): small rounded panels laid over the page wherever you drop them, over the text, over a photo, on any spot. They sit in the same
// scrolling page as the text, so they move with it. Drag a card to move it, drag the little grip at its corner to make it wider or narrower, tap it to write on it, add a badge,
// an icon (an emoji, a symbol or a picture of your own), a color, a tilt or a link. In view-only mode they stay where they are and only a link's arrow button works.

private fun toneColor(tone: Int, dark: Boolean): Color = when (tone) {
    1 -> if (dark) Color(0xFF3A2F1C) else Color(0xFFFFF1D6)
    2 -> if (dark) Color(0xFF1C2A3F) else Color(0xFFE3EEFF)
    3 -> if (dark) Color(0xFF3F1F2A) else Color(0xFFFFE3EA)
    4 -> if (dark) Color(0xFF1C3A2D) else Color(0xFFDDF5E8)
    else -> if (dark) Sb.card else Color.White
}

/** An icon of a card: a picture of your own, or an emoji or symbol, at [size]. */
@Composable
private fun IconBit(value: String, size: Dp) {
    if (PageCards.isPic(value)) AsyncImage(PageCards.picAddress(value), null, Modifier.size(size).clip(RoundedCornerShape(size * .25f)), contentScale = ContentScale.Crop)
    else Text(value, fontSize = (size.value * .8f).sp, lineHeight = (size.value * 1.05f).sp, textAlign = TextAlign.Center)
}

/** The pill at the top of a card ("Topic", with a small icon in front of the words). */
@Composable
private fun BadgePill(words: String, icon: String) {
    Row(Modifier.clip(CircleShape).background(Sb.line.copy(alpha = .7f)).padding(horizontal = 10.dp, vertical = 5.dp), Arrangement.spacedBy(5.dp), Alignment.CenterVertically) {
        if (icon.isNotEmpty()) IconBit(icon, 14.dp)
        if (words.isNotBlank()) Text(words, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun PageCardView(card: PageCard, pageW: Dp, interactive: Boolean, onMove: (Float, Float) -> Unit, onResize: (Float) -> Unit, onEdit: () -> Unit) {
    val density = LocalDensity.current
    val d = density.density
    val ctx = LocalContext.current
    val move by rememberUpdatedState(onMove)
    val resize by rememberUpdatedState(onResize)
    val edit by rememberUpdatedState(onEdit)
    val pageWpx = with(density) { pageW.toPx() }
    // While a finger is down the card follows it by these amounts; when it lifts the new place is saved and they go back to zero.
    var dx by remember(card.id) { mutableFloatStateOf(0f) }
    var dy by remember(card.id) { mutableFloatStateOf(0f) }
    var dw by remember(card.id) { mutableFloatStateOf(0f) }
    var dragging by remember(card.id) { mutableStateOf(false) }
    val baseX by rememberUpdatedState(card.x)
    val baseY by rememberUpdatedState(card.y)
    val baseW by rememberUpdatedState(card.w)
    val pw by rememberUpdatedState(pageWpx)
    val widthPx = (card.w * pageWpx + dw).coerceIn(PageCards.MIN_W * pageWpx, pageWpx)
    val xPx = (card.x * pageWpx + dx).coerceIn(0f, (pageWpx - widthPx).coerceAtLeast(0f))
    val yPx = (card.y * d + dy).coerceAtLeast(0f)
    val cardShape = RoundedCornerShape(22.dp)
    val empty = card.title.isBlank() && card.text.isBlank() && card.badge.isBlank() && card.badgeIcon.isEmpty() && card.icon.isEmpty()
    Box(
        Modifier
            .zIndex(if (dragging) 1f else 0f)
            .offset { IntOffset(xPx.roundToInt(), yPx.roundToInt()) }
            .width(with(density) { widthPx.toDp() })
            .graphicsLayer {
                rotationZ = card.tilt.toFloat()
                shadowElevation = (if (dragging) 26f else 14f) * d
                shape = cardShape
                clip = true
                ambientShadowColor = Color.Black
                spotShadowColor = Color.Black
            }
            .background(toneColor(card.tone, Sb.dark))
            .then(if (interactive) Modifier.pointerInput(card.id) {
                detectDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { move((baseX * pw + dx) / pw, baseY + dy / d); dx = 0f; dy = 0f; dragging = false },
                    onDragCancel = { dx = 0f; dy = 0f; dragging = false },
                ) { change, drag -> change.consume(); dx += drag.x; dy += drag.y }
            } else Modifier)
            .then(if (interactive) Modifier.tap("Edit card") { edit() } else Modifier)
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (card.badge.isNotBlank() || card.badgeIcon.isNotEmpty()) BadgePill(card.badge, card.badgeIcon)
            if (card.icon.isNotEmpty()) IconBit(card.icon, 52.dp)
            if (card.title.isNotBlank()) Text(card.title, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 21.sp, lineHeight = 26.sp, textAlign = TextAlign.Center)
            if (card.text.isNotBlank()) Text(card.text, fontSize = 13.sp, lineHeight = 19.sp, color = Sb.mute, textAlign = TextAlign.Center)
            if (empty) Text(if (interactive) "Tap to write on this card" else "An empty card", fontSize = 14.sp, color = Sb.mute, textAlign = TextAlign.Center)
            if (card.link.isNotBlank()) {
                val acc = LocalSb.current.acc
                Row(Modifier.fillMaxWidth(), Arrangement.End) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(acc).tapIcon("Open ${card.link}") { openUrl(ctx, card.link) }, Alignment.Center) { Ic("arrow", 22.dp, onAccent(acc)) }
                }
            }
        }
        if (interactive) Box(
            Modifier.align(Alignment.BottomEnd).size(34.dp)
                .pointerInput(card.id) {
                    detectDragGestures(onDragEnd = { resize((baseW * pw + dw) / pw); dw = 0f }, onDragCancel = { dw = 0f }) { change, drag -> change.consume(); dw += drag.x }
                }
                .drawBehind {
                    val s = size.minDimension
                    val c = Color.Gray.copy(alpha = .55f)
                    drawLine(c, Offset(s * .45f, s * .85f), Offset(s * .85f, s * .45f), 3f)
                    drawLine(c, Offset(s * .65f, s * .85f), Offset(s * .85f, s * .65f), 3f)
                }
        )
    }
}

/**
 * The layer that holds the cards, laid over the whole scrolling page. [onCards] gets the new cards and a short name of what changed (for Undo); [onEdit] gets the card that was tapped.
 * It must be given the size of the page (the editor uses matchParentSize), so a card can go over any part of it.
 */
@Composable
internal fun CardsLayer(cards: List<PageCard>, interactive: Boolean, onCards: (List<PageCard>, String) -> Unit, onEdit: (String) -> Unit, modifier: Modifier = Modifier) {
    val latest by rememberUpdatedState(cards)
    BoxWithConstraints(modifier) {
        val pageW = maxWidth
        for (c in cards) key(c.id) {
            PageCardView(c, pageW, interactive,
                onMove = { x, y -> onCards(PageCards.move(PageCards.toFront(latest, c.id), c.id, x, y), "Move card") },
                onResize = { w -> onCards(PageCards.resize(latest, c.id, w), "Resize card") },
                onEdit = { onEdit(c.id) })
        }
    }
}

@Composable
private fun PickChip(selected: Boolean, label: String, onClick: () -> Unit, content: @Composable () -> Unit) {
    val acc = LocalSb.current.acc
    Box(Modifier.size(44.dp).clip(CircleShape).background(if (selected) acc.copy(alpha = .28f) else Sb.line.copy(alpha = .6f)).tap(label, onClick), Alignment.Center) { content() }
}

/** None, the ready symbols, and your own picture: one row to choose an icon from. */
@Composable
private fun SymbolRow(value: String, onPick: (String) -> Unit, onUpload: () -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
        PickChip(value.isEmpty(), "No icon", { onPick("") }) { Text("\u2014", fontSize = 18.sp, color = Sb.mute) }
        PageCards.SYMBOLS.forEach { s -> PickChip(value == s, "Symbol $s", { onPick(s) }) { Text(s, fontSize = 18.sp) } }
        PickChip(PageCards.isPic(value), "Choose a picture of your own", onUpload) {
            if (PageCards.isPic(value)) AsyncImage(PageCards.picAddress(value), null, Modifier.size(34.dp).clip(CircleShape), contentScale = ContentScale.Crop) else Ic("image", 22.dp, Sb.ink)
        }
    }
}

/** What can be done with one card: write on it, give it a badge, an icon, a link, a color, a width and a tilt, copy it, bring it forward or delete it. */
@Composable
internal fun CardsSheet(
    card: PageCard, onChange: (PageCard, String) -> Unit, onDuplicate: () -> Unit, onFront: () -> Unit, onDelete: () -> Unit,
    onPickPicture: (String) -> Unit, onDone: () -> Unit,
) {
    val acc = LocalSb.current.acc
    var title by remember(card.id) { mutableStateOf(card.title) }
    var text by remember(card.id) { mutableStateOf(card.text) }
    var badge by remember(card.id) { mutableStateOf(card.badge) }
    var link by remember(card.id) { mutableStateOf(card.link) }
    var iconText by remember(card.id) { mutableStateOf(if (PageCards.isPic(card.icon)) "" else card.icon) }
    var badgeText by remember(card.id) { mutableStateOf(if (PageCards.isPic(card.badgeIcon)) "" else card.badgeIcon) }
    val widths = listOf(.4f, .62f, .8f, 1f)
    val tilts = listOf(-10, -4, 0, 4, 10)
    Sheet("Card", onDone) {
        SheetLabel("Title")
        InputBox { Field(title, { title = it.take(PageCards.MAX_TITLE); onChange(card.copy(title = title), "title") }, "A short title", 18.sp, headFont(), FontWeight.Medium) }
        SheetLabel("Text")
        InputBox { Field(text, { text = it.take(PageCards.MAX_TEXT); onChange(card.copy(text = text), "text") }, "Whatever you want to say", 16.sp, headFont(), modifier = Modifier.heightIn(min = 96.dp)) }
        SheetLabel("Badge")
        InputBox { Field(badge, { badge = it.take(PageCards.MAX_BADGE); onChange(card.copy(badge = badge), "badge") }, "A word on a pill, like Topic", 16.sp, headFont()) }
        SheetLabel("Badge icon")
        SymbolRow(card.badgeIcon, { badgeText = if (PageCards.isPic(it)) "" else it; onChange(card.copy(badgeIcon = it), "badge icon") }) { onPickPicture("badge") }
        InputBox { Field(badgeText, { badgeText = it.take(4); onChange(card.copy(badgeIcon = badgeText), "badge icon") }, "Or type or paste an emoji", 16.sp, headFont()) }
        SheetLabel("Icon")
        SymbolRow(card.icon, { iconText = if (PageCards.isPic(it)) "" else it; onChange(card.copy(icon = it), "icon") }) { onPickPicture("icon") }
        InputBox { Field(iconText, { iconText = it.take(4); onChange(card.copy(icon = iconText), "icon") }, "Or type or paste an emoji", 16.sp, headFont()) }
        SheetLabel("Link")
        InputBox { Field(link, { link = it.take(PageCards.MAX_LINK); onChange(card.copy(link = link), "link") }, "A web address", 16.sp, headFont()) }
        SheetNote("With a link the card gets a round arrow button that opens it.")
        SheetLabel("Color")
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), Arrangement.spacedBy(12.dp)) {
            for (t in 0 until PageCards.TONES) Box(
                Modifier.size(40.dp).clip(CircleShape).background(toneColor(t, Sb.dark))
                    .border(if (card.tone == t) 3.dp else 1.dp, if (card.tone == t) acc else Sb.line, CircleShape)
                    .tap("Color ${t + 1}") { onChange(card.copy(tone = t), "color") }
            )
        }
        SheetLabel("Width")
        Seg(listOf("Narrow", "Medium", "Wide", "Full"), widths.indexOfFirst { kotlin.math.abs(it - card.w) < .12f }.let { if (it >= 0) it else 1 }) { onChange(card.copy(w = widths[it]), "width") }
        SheetLabel("Tilt")
        Seg(listOf("\u221210\u00B0", "\u22124\u00B0", "Flat", "+4\u00B0", "+10\u00B0"), tilts.indexOf(card.tilt).let { if (it >= 0) it else 2 }) { onChange(card.copy(tilt = tilts[it]), "tilt") }
        Spacer(Modifier.height(4.dp))
        SheetGroup {
            ActionRow("page", "Make a copy") { onDuplicate() }
            SheetDivider(46.dp)
            ActionRow("sort", "Bring to front") { onFront() }
            SheetDivider(46.dp)
            ActionRow("trash", "Delete card", danger = true) { onDelete() }
        }
        SheetNote("Drag a card to move it, and the grip at its corner to make it wider or narrower. Cards can sit over the text, over a photo, anywhere on the page.")
    }
}
