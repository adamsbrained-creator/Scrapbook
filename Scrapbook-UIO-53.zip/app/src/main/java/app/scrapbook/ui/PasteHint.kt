package app.scrapbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

/** A paste the editor offered to tidy: what was offered, where the pasted text sits in the body, and whether a link card is being fetched for it. */
data class PasteHint(val offer: PasteOffer, val range: IntRange, val busy: Boolean = false)

/**
 * The small offer above the toolbar after a paste: what was recognized, a button to format it, and a cross to dismiss it. A pasted web address has two
 * buttons, a plain link or a link card ([onCard]). While the card is being fetched ([busy]) it only says so. It leaves by itself.
 */
@Composable
fun PasteHintBar(offer: PasteOffer, busy: Boolean, onApply: () -> Unit, onCard: (() -> Unit)?, onDismiss: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
        Row(Modifier.clip(CircleShape).background(Sb.surface), verticalAlignment = Alignment.CenterVertically) {
            if (busy) {
                Text("Getting the link preview\u2026", fontSize = 14.sp, color = Sb.ink, modifier = Modifier.padding(start = 18.dp, end = 6.dp, top = 12.dp, bottom = 12.dp), maxLines = 1)
            } else if (onCard != null) {
                Text(offer.action, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Sb.ink, maxLines = 1,
                    modifier = Modifier.tap(offer.action, onApply).padding(start = 18.dp, end = 12.dp, top = 12.dp, bottom = 12.dp))
                Text("Link card", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Sb.ink, maxLines = 1,
                    modifier = Modifier.tap("Make a link card with the title, a short description and the photo", onCard).padding(horizontal = 12.dp, vertical = 12.dp))
            } else {
                Row(Modifier.tap(offer.action, onApply).padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(offer.what, fontSize = 12.sp, color = Sb.mute, maxLines = 1); Spacer(Modifier.width(10.dp))
                    Text(offer.action, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Sb.ink, maxLines = 1)
                }
            }
            Box(Modifier.tapIcon("Dismiss", onDismiss).padding(horizontal = 14.dp, vertical = 12.dp)) { Ic("close", 16.dp, Sb.mute) }
        }
    }
}
