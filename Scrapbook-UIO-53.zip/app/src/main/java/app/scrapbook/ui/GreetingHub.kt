package app.scrapbook.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.Date
import kotlin.random.Random

// The greeting at the top of Home: a line that fits the time of day (and now and then the day, your scraps or your birthday), your name from the Account page and your
// picture. It changes by itself every so often (the greeting options in Customize home), and a tap shows another one straight away. The rules for which lines exist and which fit are in
// Greetings.kt; this file only shows them. How it looks is chosen in the greeting options: the style (six layouts), the background, the shape of the picture and how a new line appears.

private data class HubStats(val scraps: Int, val inbox: Int, val pinned: Int)

/** How a new line replaces the old one: 0 fade, 1 slide, 2 typing (the line itself types out, so nothing moves here), 3 pop. */
private fun greetingTransition(anim: Int): ContentTransform = when (anim) {
    1 -> (slideInVertically(tween(420)) { it / 2 } + fadeIn(tween(420))) togetherWith (slideOutVertically(tween(300)) { -it / 2 } + fadeOut(tween(220)))
    2 -> EnterTransition.None togetherWith ExitTransition.None
    3 -> (scaleIn(spring(dampingRatio = .55f, stiffness = 380f), initialScale = .85f) + fadeIn(tween(200))) togetherWith fadeOut(tween(150))
    else -> fadeIn(tween(380)) togetherWith fadeOut(tween(220))
}

/** A line typed out letter by letter. The letters that are not typed yet are there but invisible, so the line never changes size while it types. */
@Composable
private fun TypedText(text: String, color: Color, sizeSp: Float, align: TextAlign, maxLines: Int) {
    // The letters already typed are remembered with the line (GreetingNow), so a line that was typed in full is not typed again when Home comes back into view, and one that was cut short goes on from where it was.
    var n by remember(text) { mutableIntStateOf(GreetingNow.typed(text).coerceIn(0, text.length)) }
    LaunchedEffect(text) { while (n < text.length) { delay(if (text[n] == ' ') 20L else 34L); n++; GreetingNow.typedTo(text, n) } }
    val shown = remember(n, text) { buildAnnotatedString { append(text.take(n)); withStyle(SpanStyle(color = Color.Transparent)) { append(text.drop(n)) } } }
    Text(shown, color = color, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = sizeSp.sp, lineHeight = (sizeSp * 1.2f).sp, letterSpacing = (-sizeSp * .013f).sp,
        textAlign = align, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

@Composable
fun GreetingHub(
    account: Account, prefs: GreetingPrefs, scraps: Int, inbox: Int, pinned: Int, modifier: Modifier = Modifier,
    /**
     * The look (Customize home > Greeting). [style]: 0 classic, 1 centered, 2 on a card, 3 chat bubble, 4 banner, 5 minimal. With [picLeft] the picture comes before the text.
     * [bg] is the background: 0 automatic (what suits the style), 1 none, 2 card, 3 tint, 4 accent, 5 gradient, 6 outline. [shape] is the picture's: 0 circle, 1 squircle, 2 leaf.
     * [anim] is how a new line appears: 0 fade, 1 slide, 2 typing, 3 pop. The sizes are the greeting's own sliders.
     */
    style: Int = 0, picLeft: Boolean = false, bg: Int = 0, shape: Int = 0, anim: Int = 0, onProfile: () -> Unit,
) {
    val haptics = LocalHaptics.current
    val acc = LocalSb.current.acc
    val card = Sb.card
    val stats by rememberUpdatedState(HubStats(scraps, inbox, pinned))
    val acct by rememberUpdatedState(account)
    val filter = prefs.filter()
    // Everything that makes the current line wrong when it changes: a new greeting is picked at once.
    val inputs = listOf(account.callName, account.birthMonth, account.birthDay, filter)

    /** Picks a greeting for this moment, remembers it as shown, and returns it with the name and counts filled in. */
    fun pickNow(): String {
        val cal = Calendar.getInstance()
        val a = acct; val s = stats
        val month = cal.get(Calendar.MONTH) + 1; val day = cal.get(Calendar.DAY_OF_MONTH)
        val ctx = GreetingContext(
            name = a.callName, hour = cal.get(Calendar.HOUR_OF_DAY), dayOfWeek = cal.get(Calendar.DAY_OF_WEEK), month = month, day = day,
            inbox = s.inbox, scraps = s.scraps, pinned = s.pinned, birthday = a.isBirthday(month, day, Account.isLeap(cal.get(Calendar.YEAR))),
        )
        val g = Greetings.pick(ctx, filter, GreetingHistory.recent(), Random.Default)
        GreetingHistory.add(g.id)
        return Greetings.render(g, ctx)
    }

    // The line is kept in GreetingNow, not only here: this function leaves the screen when Home is scrolled or another page opens, and a line that was just picked must not be lost with it.
    // It is replaced when its time is up (Change greeting every), when what it depends on changes, or when it is tapped.
    val key = inputs.joinToString("|")
    var text by remember(key) {
        val now = System.currentTimeMillis()
        mutableStateOf(GreetingNow.current(key, now, prefs.everySec * 1000L) ?: pickNow().also { GreetingNow.set(key, it, now) })
    }
    fun showAnother() { val line = pickNow(); GreetingNow.set(key, line, System.currentTimeMillis()); text = line }
    LaunchedEffect(key, prefs.everySec) {
        if (prefs.everySec > 0) {
            val every = prefs.everySec * 1000L
            // The first change comes when the line has been up for the whole time, wherever the timer stood when this came back into view.
            var wait = (every - GreetingNow.age(System.currentTimeMillis())).coerceIn(0L, every)
            while (true) { delay(wait); showAnother(); wait = every }
        }
    }

    val date = remember(text) { Fmt.of("EEEE, d MMMM").format(Date()) }
    val sub = when (prefs.sub) {
        0 -> date
        1 -> account.about.lineSequence().firstOrNull().orEmpty().ifBlank { date }
        2 -> when { scraps == 0 -> "Nothing saved yet"; inbox > 0 -> "${Greetings.count(scraps)} · $inbox in Inbox"; else -> Greetings.count(scraps) }
        else -> ""
    }

    val textSp = prefs.textSize.coerceIn(GreetingPrefs.TEXT_MIN, GreetingPrefs.TEXT_MAX)
    val picDp = prefs.picSize.coerceIn(GreetingPrefs.PIC_MIN, GreetingPrefs.PIC_MAX)
    val center = style == 1
    val bubble = style == 3
    val banner = style == 4
    val minimal = style == 5
    val align = if (center) TextAlign.Center else TextAlign.Start
    val titleSize = when { banner -> textSp * 1.15f; minimal -> textSp * .8f; else -> textSp.toFloat() }

    // The background: 1 none, 2 card, 3 tint, 4 accent, 5 gradient, 6 outline. Automatic is what the style has always had: a card for Card and Bubble, a gradient for Banner.
    val kind = if (bg == 0) when (style) { 2, 3 -> 2; 4 -> 5; else -> 1 } else bg.coerceIn(1, 6)
    val filled = kind == 4 || kind == 5
    val onFill = onAccent(acc)
    val ink = if (filled) onFill else Color.Unspecified
    val inkSub = if (filled) onFill.copy(alpha = .8f) else Sb.mute
    // The gradient moves away from the text color's side, so the text stays readable at both ends.
    val gradientEnd = lerp(acc, if (onFill.luminance() < .5f) Color.White else Color.Black, .35f)

    fun Modifier.surface(shape: Shape): Modifier = when (kind) {
        2 -> background(card, shape)
        3 -> background(acc.copy(alpha = .16f), shape)
        4 -> background(acc, shape)
        5 -> background(Brush.linearGradient(listOf(acc, gradientEnd)), shape)
        6 -> border(1.5.dp, acc, shape)
        else -> this
    }

    val tapNext = Modifier.tap("Show another greeting") { haptics.tick(); showAnother() }

    @Composable
    fun GreetingText() {
        AnimatedContent(text, transitionSpec = { greetingTransition(anim) }, label = "greeting") { line ->
            if (anim == 2) TypedText(line, ink, titleSize, align, if (minimal) 1 else Int.MAX_VALUE)
            else Text(line, color = ink, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = titleSize.sp, lineHeight = (titleSize * 1.2f).sp, letterSpacing = (-titleSize * .013f).sp,
                textAlign = align, maxLines = if (minimal) 1 else Int.MAX_VALUE, overflow = TextOverflow.Ellipsis)
        }
    }

    @Composable
    fun SubLine(m: Modifier = Modifier) {
        if (sub.isNotEmpty() && !minimal) Text(sub, m, fontSize = (textSp * .5f).coerceIn(11f, 15f).sp, color = inkSub, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align)
    }

    @Composable
    fun NameHint() {
        if (!account.hasName && !minimal) Text("Tell me your name", Modifier.tap("Open your account", onProfile).padding(top = 6.dp, bottom = 4.dp), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (filled) onFill else accentText(acc))
    }

    // A small picture still gets a 44dp touch area.
    @Composable
    fun Picture(sizeDp: Int) {
        if (prefs.avatar) Box(Modifier.sizeIn(minWidth = 44.dp, minHeight = 44.dp).tap("Open your account", onProfile), Alignment.Center) { AvatarView(account, sizeDp.dp, shape = avatarShape(shape)) }
    }

    /** Classic, centered and card: the date, the greeting and the picture. */
    @Composable
    fun Line() {
        if (center) Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp), Alignment.CenterHorizontally) {
            Picture(picDp)
            Column(tapNext.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) { SubLine(); GreetingText(); NameHint() }
        } else Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
            if (picLeft) Picture(picDp)
            Column(tapNext.weight(1f)) { SubLine(); GreetingText(); NameHint() }
            if (!picLeft) Picture(picDp)
        }
    }

    /** The greeting as a chat bubble whose small corner points at the picture, with the date under it. */
    @Composable
    fun BubbleLine() {
        val shapeOfBubble = RoundedCornerShape(22.dp, 22.dp, if (picLeft) 22.dp else 6.dp, if (picLeft) 6.dp else 22.dp)
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp), Alignment.Bottom) {
            if (picLeft) Picture(picDp)
            Column(Modifier.weight(1f)) {
                Box(tapNext.fillMaxWidth().surface(shapeOfBubble).padding(horizontal = 16.dp, vertical = 12.dp)) { GreetingText() }
                SubLine(Modifier.padding(start = 6.dp, top = 4.dp)); NameHint()
            }
            if (!picLeft) Picture(picDp)
        }
    }

    /** The banner: a taller block with a bigger greeting and two soft circles behind it. */
    @Composable
    fun BannerLine() {
        Row(Modifier.fillMaxWidth().heightIn(min = 90.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
            if (picLeft) Picture(picDp)
            Column(tapNext.weight(1f)) { SubLine(); GreetingText(); NameHint() }
            if (!picLeft) Picture(picDp)
        }
    }

    when {
        bubble -> Box(modifier.fillMaxWidth().padding(horizontal = 20.dp)) { BubbleLine() }
        banner -> {
            val blockShape = RoundedCornerShape(32.dp)
            val deco = (if (filled) onFill else Sb.mute).copy(alpha = .12f)
            Box(modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                Box(Modifier.fillMaxWidth().clip(blockShape).surface(blockShape).drawBehind {
                    drawCircle(deco, size.height * .9f, Offset(size.width * .92f, size.height * .1f))
                    drawCircle(deco, size.height * .55f, Offset(size.width * .08f, size.height * 1.05f))
                }.padding(horizontal = 22.dp, vertical = 18.dp)) { BannerLine() }
            }
        }
        minimal -> Box(modifier.fillMaxWidth().padding(horizontal = if (kind == 1) 24.dp else 20.dp)) {
            val pill = RoundedCornerShape(50)
            Row(Modifier.fillMaxWidth().then(if (kind != 1) Modifier.clip(pill).surface(pill).padding(horizontal = 16.dp, vertical = 8.dp) else Modifier), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                if (picLeft) Picture(minOf(picDp, 36))
                Box(tapNext.weight(1f)) { GreetingText() }
                if (!picLeft) Picture(minOf(picDp, 36))
            }
        }
        kind != 1 -> Box(modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            val blockShape = RoundedCornerShape(28.dp)
            Box(Modifier.fillMaxWidth().clip(blockShape).surface(blockShape).padding(horizontal = 20.dp, vertical = 16.dp)) { Line() }
        }
        else -> Box(modifier.fillMaxWidth().padding(horizontal = 24.dp)) { Line() }
    }
}
