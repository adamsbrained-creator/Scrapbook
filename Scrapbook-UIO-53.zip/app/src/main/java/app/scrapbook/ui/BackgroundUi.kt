package app.scrapbook.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.scrapbook.*

// The background behind every screen (UIO 34): the plain page as always, a gradient between two colors of your choice (like a page that is warm at the top and fades to dark), or a glow:
// soft blobs of a color of your choice that drift slowly (the animated glow of Needle, in any color). The screens paint nothing as their page while one is on (SbTheme.page), so it shows
// through; the editor keeps the plain page unless it is asked to show it too. The rules and the saved form are AppBackground.kt.

/** The background itself, filling its parent. Draws nothing for the plain page (the screens already paint it). */
@Composable
fun AppBackgroundLayer(bg: AppBackground, modifier: Modifier = Modifier) {
    if (!bg.active) return
    val base = Sb.paper
    val period = AppBackgrounds.periodMs(bg.speed)
    // One slow back-and-forth drives every blob (read while drawing, so the page does not recompose on each frame). A still glow stays at a pleasing place.
    val drift = if (bg.kind == AppBackground.GLOW && period > 0) {
        val t = rememberInfiniteTransition(label = "backgroundGlow")
        t.animateFloat(0f, 1f, infiniteRepeatable(tween(period, easing = LinearEasing), RepeatMode.Reverse), label = "drift")
    } else null
    Box(modifier.fillMaxSize().drawBehind {
        when (bg.kind) {
            AppBackground.GRADIENT -> drawGradient(bg, base)
            AppBackground.GLOW -> drawGlow(bg, base, drift?.value ?: .35f)
        }
    })
}

private fun DrawScope.drawGradient(bg: AppBackground, base: Color) {
    val top = rgbColor(bg.top)
    val bottom = rgbColor(bg.bottom)
    // The color holds near the top and has almost turned into the other one by the lower third, which is how a fading page reads.
    val mid = lerp(top, bottom, .75f)
    val brush = when (bg.direction) {
        1 -> Brush.linearGradient(0f to top, .7f to mid, 1f to bottom, start = Offset.Zero, end = Offset(size.width, size.height))
        2 -> Brush.verticalGradient(0f to bottom, .3f to mid, 1f to top)
        else -> Brush.verticalGradient(0f to top, .7f to mid, 1f to bottom)
    }
    drawRect(base)
    drawRect(brush)
}

private fun DrawScope.drawGlow(bg: AppBackground, base: Color, drift: Float) {
    val w = size.width
    val h = size.height
    val k = AppBackgrounds.strengthFactor(bg.strength)
    val main = rgbColor(bg.glow)
    val (n2, n3) = if (bg.mix == 1) AppBackgrounds.companions(bg.glow) else bg.glow to bg.glow
    val second = rgbColor(n2)
    val third = rgbColor(n3)
    drawRect(base)
    // A wash from the top left corner, then three soft blobs that drift sideways and up and down, then the page color again at the very bottom, behind the add button.
    drawRect(Brush.linearGradient(listOf(main.copy(alpha = (.5f * k).coerceAtMost(1f)), base.copy(alpha = 0f)), start = Offset.Zero, end = Offset(w, h * .75f)))
    fun blob(color: Color, alpha: Float, cx: Float, cy: Float, r: Float) {
        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = (alpha * k).coerceAtMost(1f)), color.copy(alpha = 0f)), center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
    }
    blob(main, .45f, w * (.1f + .3f * drift), h * .3f, w * .9f)
    blob(second, .30f, w * (.95f - .3f * drift), h * .55f, w * .8f)
    blob(third, .25f, w * .4f, h * (.85f - .1f * drift), w * .7f)
    drawRect(Brush.verticalGradient(0.85f to Color.Transparent, 1f to base.copy(alpha = .55f)))
}

/** The card color as it would be with [bg]: a veil of white when the cards are frosted or clear, otherwise as usual. */
@Composable
private fun cardFor(bg: AppBackground): Color =
    (if (bg.active) AppBackgrounds.veilAlpha(bg.cards, Sb.dark) else null)?.let { Color.White.copy(alpha = it) } ?: Sb.card

@Composable
private fun BackgroundPreview(bg: AppBackground) {
    val card = cardFor(bg)
    Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(28.dp)).background(Sb.paper).border(1.dp, Sb.line, RoundedCornerShape(28.dp))) {
        AppBackgroundLayer(bg)
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Good morning, John.", fontSize = 20.sp, fontWeight = FontWeight.Medium, fontFamily = headFont())
            listOf("Morning routine", "A scrap with a few lines").forEach { t ->
                Box(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(20.dp)).background(card).padding(horizontal = 16.dp), Alignment.CenterStart) {
                    Text(t, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

/** A color to choose: its swatch, a row of colors to start from, and (when opened) the sliders and a box for a hex code like #1D4E89. [onLive] is called while a slider moves, [onCommit] when a color is chosen. */
@Composable
private fun ColorChoice(label: String, rgb: Int, presets: List<Int>, onLive: (Int) -> Unit, onCommit: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    var hex by remember(rgb) { mutableStateOf(AppBackgrounds.hex(rgb)) }
    SettingsCard {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth().tap("$label, choose any color") { open = !open }, Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(CircleShape).background(rgbColor(rgb)).border(1.dp, Sb.line, CircleShape))
                Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("#$hex", fontSize = 14.sp, color = Sb.mute)
                Ic(if (open) "up" else "down", 18.dp, Sb.mute)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(10.dp)) {
                presets.forEach { p ->
                    val on = p == rgb
                    Box(Modifier.size(38.dp).clip(CircleShape).background(rgbColor(p)).border(if (on) 3.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape).tapIcon("Use #${AppBackgrounds.hex(p)}") { onCommit(p) })
                }
            }
            if (open) {
                RgbSliders(rgb, onLive, onCommit)
                InputBox { Field(hex, { v -> hex = v.take(7); AppBackgrounds.parseHex(v)?.let { onCommit(it) } }, "#RRGGBB", 16.sp, headFont()) }
            }
        }
    }
}

@Composable
fun BackgroundScreen(vm: ArchiveViewModel, nav: NavController) {
    val t = LocalSb.current
    val saved by vm.appBackground.collectAsState()
    val grey by vm.greyBg.collectAsState()
    // While a slider moves the preview follows it without saving every step; the color is saved when it is let go.
    var live by remember { mutableStateOf<AppBackground?>(null) }
    val bg = live ?: saved
    fun commit(next: AppBackground) { live = null; vm.setAppBackground(next) }
    Scaffold(containerColor = t.page) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).consumeWindowInsets(pad)) {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                CircleBtn("Go back", { nav.popBackStack() }) { Ic("back", 22.dp, Sb.ink) }
                Box(Modifier.weight(1f), Alignment.Center) {
                    Text("scrapbook", fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp, maxLines = 1)
                }
                Spacer(Modifier.size(44.dp))
            }
            Text("Background", Modifier.padding(start = 28.dp, top = 12.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { BackgroundPreview(bg) }
                item { ChoiceCard("Background", listOf("Plain", "Gradient", "Glow"), bg.kind, when (bg.kind) {
                    1 -> "A color at the top that fades into another one, like a page that is warm at the top and dark below."
                    2 -> "Soft blobs of a color that drift slowly behind every screen."
                    else -> "The page as it always was."
                }) { commit(bg.copy(kind = it)) } }
                when (bg.kind) {
                    AppBackground.GRADIENT -> {
                        item { ColorChoice("Top color", bg.top, AppBackgrounds.GRADIENT_PRESETS, { live = bg.copy(top = it) }, { commit(bg.copy(top = it)) }) }
                        item { ColorChoice("Bottom color", bg.bottom, listOf(0x0B0B0B, 0x15161A, 0x101820, 0x1A1022, 0x000000, 0xFFFFFF), { live = bg.copy(bottom = it) }, { commit(bg.copy(bottom = it)) }) }
                        item { ChoiceCard("Direction", listOf("Down", "Diagonal", "Up"), bg.direction, "Which way the color fades.") { commit(bg.copy(direction = it)) } }
                    }
                    AppBackground.GLOW -> {
                        item { ColorChoice("Glow color", bg.glow, AppBackgrounds.GLOW_PRESETS, { live = bg.copy(glow = it) }, { commit(bg.copy(glow = it)) }) }
                        item { ChoiceCard("Colors", listOf("One color", "Soft mix"), bg.mix, if (bg.mix == 1) "The color with its two neighbors on the color wheel." else "Only the color you chose.") { commit(bg.copy(mix = it)) } }
                        item { ChoiceCard("Strength", listOf("Soft", "Usual", "Strong"), bg.strength, null) { commit(bg.copy(strength = it)) } }
                        item { ChoiceCard("Movement", listOf("Still", "Slow", "Usual", "Fast"), bg.speed, if (bg.speed == 0) "The glow stands still." else null) { commit(bg.copy(speed = it)) } }
                    }
                    else -> {
                        item { SettingsCard { SwitchRow("page", "Soft grey page", grey) { vm.setGreyBg(it) } } }
                        item { HomeFooter("In light mode the plain page can be a soft grey instead of white, which makes the cards stand out.") }
                    }
                }
                if (bg.active) {
                    item { ChoiceCard("Cards", listOf("Solid", "Frosted", "Clear"), bg.cards, when (bg.cards) {
                        0 -> "Cards stay solid, as they are on the plain page."
                        2 -> "A thin white veil: the background shows through the cards."
                        else -> "A frosted white veil over the background."
                    }) { commit(bg.copy(cards = it)) } }
                    item { SettingsCard { SwitchRow("edit", "Show it in the editor too", bg.inEditor) { commit(bg.copy(inEditor = it)) } } }
                    item { HomeFooter("The editor keeps the plain page unless you turn this on, because long text is easiest to read on it.") }
                    if (!bg.readable(Sb.dark)) item {
                        Text("Text may be hard to read on this background in ${if (Sb.dark) "dark" else "light"} mode. Choose ${if (Sb.dark) "darker" else "lighter"} colors, or change the Theme.",
                            Modifier.padding(horizontal = 8.dp), fontSize = 14.sp, lineHeight = 20.sp, color = Sb.danger)
                    }
                    item { SettingsCard { IconRow("close", "Back to the plain page") { commit(AppBackground()) } } }
                }
            }
        }
    }
}
