package app.scrapbook.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

// The selection toolbar: long-press a scrap on All scraps or in a box to start picking, tap to pick more, then use the bar at the bottom.
// The list screens keep the picked ids; everything here is shared by both of them (ShelfScreen in Browse.kt, AllScrapsScreen in Home.kt).

/** What a card needs to know while scraps are being picked: whether it is picked, and what a tap does. Null means "not picking". */
class Pick(val selected: Boolean, val onToggle: () -> Unit)

/** While picking, a card shows a ring (empty or filled with a check) in its top right corner; a picked card also gets an accent outline and tint. */
@Composable
fun Modifier.selectMark(selecting: Boolean, selected: Boolean, radius: Dp = 28.dp): Modifier {
    if (!selecting) return this
    val acc = LocalSb.current.acc; val paper = LocalSb.current.paper; val mute = Sb.mute; val ink = Color(0xFF0B0B0B)
    return this.semantics { this.selected = selected }.drawWithContent {
        drawContent()
        val r = 13.dp.toPx(); val c = Offset(size.width - 28.dp.toPx(), 28.dp.toPx())
        if (selected) {
            val w = 3.dp.toPx()
            drawRect(acc.copy(alpha = .10f))
            drawRoundRect(acc, Offset(w / 2, w / 2), Size(size.width - w, size.height - w), CornerRadius(radius.toPx() - w / 2), style = Stroke(w))
            drawCircle(acc, r, c)
            val s = 2.2.dp.toPx()
            drawLine(ink, Offset(c.x - 5.dp.toPx(), c.y + 0.5.dp.toPx()), Offset(c.x - 1.5.dp.toPx(), c.y + 4.dp.toPx()), s, StrokeCap.Round)
            drawLine(ink, Offset(c.x - 1.5.dp.toPx(), c.y + 4.dp.toPx()), Offset(c.x + 5.5.dp.toPx(), c.y - 4.dp.toPx()), s, StrokeCap.Round)
        } else {
            drawCircle(paper.copy(alpha = .7f), r, c)
            drawCircle(mute, r, c, style = Stroke(2.dp.toPx()))
        }
    }
}

/** Replaces the screen's header while picking: close, how many are picked, and Select all / none. */
@Composable
fun SelectionHeader(count: Int, total: Int, onClose: () -> Unit, onAll: () -> Unit, pad: Dp = 2.dp) {
    Row(Modifier.fillMaxWidth().padding(start = pad, end = pad, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleBtn("Cancel selection", onClose) { Ic("close", 22.dp, Sb.ink) }
        Text("$count selected", Modifier.weight(1f), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 20.sp, textAlign = TextAlign.Center, maxLines = 1)
        Text(if (count >= total) "Select none" else "Select all", Modifier.clip(CircleShape).background(Sb.surface).tap(if (count >= total) "Select none" else "Select all", onAll).padding(horizontal = 16.dp, vertical = 11.dp),
            fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun BarAction(icon: String, label: String, tint: Color = Sb.ink, onClick: () -> Unit) {
    Column(Modifier.width(68.dp).pressScale(.92f).clip(RoundedCornerShape(24.dp)).tap(label, onClick).padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Ic(icon, 22.dp, tint)
        Text(label, fontSize = 11.sp, color = tint, maxLines = 1)
    }
}

/** The bar that takes the place of the New scrap button while picking. */
@Composable
fun SelectionBar(modifier: Modifier, allPinned: Boolean, onBox: () -> Unit, onPin: () -> Unit, onTags: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(32.dp)
    Row(modifier.padding(16.dp).shadow(10.dp, shape).clip(shape).background(Sb.surface).border(1.dp, Sb.line, shape).padding(6.dp), Arrangement.spacedBy(2.dp)) {
        BarAction("folder", "Add to box", onClick = onBox)
        BarAction(if (allPinned) "star" else "starline", if (allPinned) "Unpin" else "Pin", onClick = onPin)
        BarAction("tag", "Tags", onClick = onTags)
        BarAction("trash", "Delete", Sb.danger, onDelete)
    }
}

/** Add tags to every picked scrap: type them, or tap one already in use. Their own tags stay. */
@Composable
fun AddTagsSheet(vm: ArchiveViewModel, count: Int, onAdd: (List<String>) -> Unit, onDone: () -> Unit) {
    val all by vm.items.collectAsState()
    var text by remember { mutableStateOf("") }
    val typed = parseTags(text); val used = remember(all) { topTags(all) }
    Sheet("Add tags", onDone, doneLabel = "Add tags", primary = { onAdd(typed); onDone() }, enabled = typed.isNotEmpty(), subtitle = "To ${scrapsLabel(count)}") {
        InputBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("tag", 20.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                Field(text, { text = it }, "Tags, separated by commas", 16.sp, headFont(), modifier = Modifier.weight(1f))
            }
        }
        val suggest = used.filter { u -> typed.none { it.equals(u, true) } }
        if (suggest.isNotEmpty()) {
            SheetLabel("Used before")
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) { suggest.forEach { s -> SoftChip(s) { text = appendTag(text, s) } } }
        }
        SheetNote("Tags are added to every picked scrap. The tags they already have stay.")
    }
}

/** Shows [msg] with Undo for a finished batch. */
private fun CoroutineScope.tell(snack: SnackbarHostState, msg: String, undo: () -> Unit) {
    launch {
        snack.currentSnackbarData?.dismiss()
        if (snack.showSnackbar(msg, "Undo", duration = SnackbarDuration.Long) == SnackbarResult.ActionPerformed) undo()
    }
}

fun batchMove(vm: ArchiveViewModel, chosen: List<Item>, box: String, scope: CoroutineScope, snack: SnackbarHostState) {
    if (chosen.isEmpty()) return
    vm.moveAll(chosen, box); scope.tell(snack, "${scrapsLabel(chosen.size)} added to ${vm.shelves.value.labelOf(box)}") { vm.restoreBoxes(chosen) }
}

fun batchPin(vm: ArchiveViewModel, chosen: List<Item>, scope: CoroutineScope, snack: SnackbarHostState) {
    if (chosen.isEmpty()) return
    val pin = !allPinned(chosen)
    vm.pinAll(chosen, pin); scope.tell(snack, "${scrapsLabel(chosen.size)} ${if (pin) "pinned" else "unpinned"}") { vm.restorePins(chosen) }
}

fun batchTag(vm: ArchiveViewModel, chosen: List<Item>, tags: List<String>, scope: CoroutineScope, snack: SnackbarHostState) {
    if (chosen.isEmpty() || tags.isEmpty()) return
    vm.addTags(chosen, tags); scope.tell(snack, "Tags added to ${scrapsLabel(chosen.size)}") { vm.restoreTags(chosen) }
}

fun batchDelete(vm: ArchiveViewModel, chosen: List<Item>, scope: CoroutineScope, snack: SnackbarHostState) {
    if (chosen.isEmpty()) return
    vm.deleteAll(chosen); scope.tell(snack, "${scrapsLabel(chosen.size)} moved to the Bin") { vm.undeleteAll(chosen) }
}
