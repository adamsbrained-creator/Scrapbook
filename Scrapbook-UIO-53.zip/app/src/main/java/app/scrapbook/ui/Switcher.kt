package app.scrapbook.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// The quick switcher ("Go to…"): type a few letters and jump to a scrap or a box, from anywhere. With nothing typed it lists what you opened last.
// The rules (matching, ranking, what "recent" means) are in Switcher.kt and Recents.kt; this file draws the sheet and builds the list of places.

/** What a scrap is called in a list: its title, or the first line of its text when it has none. */
private fun nameOf(n: Item): String =
    n.title.ifBlank { n.body.lineSequence().firstOrNull { it.isNotBlank() }?.let { plainPreview(it) }?.take(60).orEmpty() }.ifBlank { "Untitled" }

/** Every scrap (not in the Bin) and every box as a place the switcher can open. */
internal fun placesOf(items: List<Item>, shelves: List<Shelf>, inboxHidden: Boolean): List<Place> {
    val out = ArrayList<Place>(items.size + shelves.size + 1)
    items.forEach { n ->
        if (n.deletedAt != 0L) return@forEach
        val box = if (n.collection.isBlank()) "" else shelves.displayName(n.collection)
        out += Place(Recents.scrap(n.id), nameOf(n), (listOf(box) + n.tags.map { "#$it" }).filter { it.isNotBlank() }.joinToString(" · "), n.savedAt, n.icon, n.kind.name)
    }
    shelves.forEach { s -> out += Place(Recents.box(s.name), s.label, if (s.parent.isNotBlank() && shelves.any { it.name == s.parent }) "in " + shelves.pathOf(s.parent) else "Box", 0L) }
    if (!inboxHidden && shelves.none { it.name == "Inbox" }) out += Place(Recents.box("Inbox"), "Inbox", "Box", 0L)
    return out
}

internal fun routeOf(key: String): String? = Recents.scrapId(key)?.let { "item/$it" } ?: Recents.boxName(key)?.let { "shelf/$it" }

@Composable
internal fun PlaceRow(p: Place, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).tap("Open ${p.title}", onClick).padding(horizontal = 6.dp, vertical = 7.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(Sb.ink.copy(alpha = .07f)), Alignment.Center) {
            if (p.icon.isNotBlank()) Text(p.icon, fontSize = 16.sp)
            else Ic(if (p.isBox) "folder" else when (p.kind) { "Quote" -> "quote"; "Image" -> "image"; "Link" -> "link"; "Voice" -> "mic"; else -> "edit" }, 18.dp, Sb.mute)
        }
        Column(Modifier.weight(1f)) {
            Text(p.title, color = Sb.ink, fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (p.hint.isNotBlank()) Text(p.hint, color = Sb.mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * The quick switcher sheet. [onOpen] gets the screen to go to ("item/12", "shelf/Trips") and does the going: the editor saves first, everywhere else it is a plain navigate.
 * Opening a scrap or box this way counts as opening it, like any other way in.
 */
@Composable
fun SwitcherSheet(vm: ArchiveViewModel, onOpen: (String) -> Unit, onDone: () -> Unit) {
    val items by vm.items.collectAsState(); val shelves by vm.shelves.collectAsState(); val recents by vm.recentPlaces.collectAsState(); val inboxHidden by vm.inboxHidden.collectAsState()
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val places = remember(items, shelves, inboxHidden) { placesOf(items, shelves, inboxHidden) }
    val shown = remember(q, places, recents) { Switcher.find(q, places, recents) }
    Sheet("Go to", onDone, doneLabel = "Cancel", soft = true, subtitle = if (q.isBlank() && shown.isNotEmpty() && recents.isNotEmpty()) "Recently opened" else null) {
        LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) { } }
        InputBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic("search", 20.dp, Sb.mute); Spacer(Modifier.width(12.dp))
                Field(q, { q = it }, "A scrap or a box", 16.sp, headFont(), modifier = Modifier.weight(1f).focusRequester(focus))
            }
        }
        if (shown.isEmpty()) SheetNote(if (q.isBlank()) "Nothing to go to yet." else "Nothing matches that.")
        else Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(2.dp)) {
            shown.forEach { p -> PlaceRow(p) { routeOf(p.key)?.let { onOpen(it) }; onDone() } }
        }
    }
}
