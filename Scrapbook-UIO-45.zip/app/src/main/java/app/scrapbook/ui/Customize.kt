package app.scrapbook.ui

import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material3.Text
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextOverflow
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val n = options.size.coerceAtLeast(1)
    // The chosen option's pill slides to the new one on a spring, instead of one pill fading out while the other fades in.
    val pos by animateFloatAsState(sel.toFloat(), spring(dampingRatio = .8f, stiffness = 600f), label = "segThumb")
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Sb.line.copy(alpha = .6f)).padding(4.dp)) {
        Box(Modifier.matchParentSize()) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(1f / n).graphicsLayer { translationX = pos * size.width }.clip(RoundedCornerShape(20.dp)).background(Sb.ink))
        }
        Row(Modifier.fillMaxWidth()) {
            options.forEachIndexed { i, o ->
                val on = i == sel
                val fg by animateColorAsState(if (on) Sb.card else Sb.ink, tween(180), label = "segText")
                Text(o, Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                    .tap { onSel(i) }.semantics { selected = on }.padding(vertical = 10.dp),
                    fontSize = 14.sp, textAlign = TextAlign.Center, color = fg)
            }
        }
    }
}

/** A rounded box around a text field (soft grey in Classic, outlined in Float). */
@Composable
fun InputBox(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxWidth().skinCard(22.dp).padding(horizontal = 18.dp, vertical = 15.dp)) { content() }
}

/**
 * The bottom sheet every small window uses: the page dims, the sheet slides up with a drag handle, a title (and an optional line under it),
 * the content, and one big button. Tapping outside or Back closes it. primary is what the big button does (the default is onDone),
 * soft turns the button into a quiet grey one for Cancel.
 *
 * The menu skin (Customize menu, MenuSkins.kt) decides how it looks: docked to the bottom or floating clear of the edges, a left or a centered title, one big
 * button or Cancel and the action side by side (only when primary is given, so Cancel never runs a save). cancelLabel names the quiet button then; footer is a small
 * line under the buttons in the skins that have one; capsule is the same action drawn as a floating pill, when the skin and the Main button choice ask for it.
 * Classic draws exactly what this sheet always drew.
 */
@Composable
fun Sheet(title: String, onDone: () -> Unit, doneLabel: String = "Done", primary: (() -> Unit)? = null, enabled: Boolean = true,
          soft: Boolean = false, subtitle: String? = null, cancelLabel: String = "Cancel", footer: String? = null, capsule: SheetCapsule? = null,
          showTitle: Boolean = true, showCancel: Boolean? = null, showButtons: Boolean = true, accent: Boolean = false, onTitleHold: (() -> Unit)? = null,
          content: @Composable ColumnScope.() -> Unit) {
    val skin = menuSkin(); val opts = menuOptions()
    // The sheet slides up when it opens and down when it is dismissed. The caller removes it, so a dismiss waits for the slide to finish first.
    var shown by remember { mutableStateOf(false) }
    var closing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val doneNow by rememberUpdatedState(onDone)
    LaunchedEffect(Unit) { shown = true }
    // Rising is a spring with no bounce (it eases in like a system sheet and the bottom edge never lifts off the screen); leaving is a short ease-out.
    val p by animateFloatAsState(if (shown) 1f else 0f,
        if (shown) spring<Float>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 420f) else tween<Float>(180, easing = FastOutLinearInEasing), label = "sheet")
    val dismiss: () -> Unit = { if (!closing) { closing = true; shown = false; scope.launch { delay(180); doneNow() } } }
    BackHandler { dismiss() }
    BlockSwipes()   // a swipe over the sheet must not take the page under it away
    val shape = if (skin.floating) RoundedCornerShape(skin.corner) else RoundedCornerShape(topStart = skin.corner, topEnd = skin.corner)
    val pill = capsule != null && skin.canPill && opts.action == 1
    val split = (showCancel ?: skin.split) && primary != null && !soft && !pill
    // The big button is the ink color, or the app's accent when the menu is set to use it (only the Home menu does).
    val fill = if (accent) LocalSb.current.acc else Sb.ink
    val onFill = if (accent) onAccent(fill) else Sb.card
    val holdNow by rememberUpdatedState(onTitleHold)
    val haptics = LocalHaptics.current
    // A docked sheet is at most 680dp tall. A floating one may use most of the screen, so the whole menu fits on a tall phone.
    val maxH = if (skin.floating) minOf(LocalConfiguration.current.screenHeightDp * .9f, 820f).dp else 680.dp
    Box(Modifier.fillMaxSize()) {
        // The dimmed backdrop is a button of its own (tap outside to close), not the parent of the sheet, so a screen reader sees each part of the sheet separately.
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = opts.dimAlpha * p)).tapIcon("Close $title", dismiss))
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = maxH)
            .graphicsLayer { translationY = (1f - p) * size.height }
            .then(if (skin.floating) Modifier.navigationBarsPadding().imePadding().padding(skin.inset).shadow(24.dp, shape) else Modifier)
            .clip(shape).background(Sb.raised)
            .then(if (skin.floating) Modifier.border(1.dp, Sb.menuLine, shape) else Modifier)
            .pointerInput(Unit) { detectTapGestures { } }.semantics { paneTitle = title }
            .then(if (skin.floating) Modifier else Modifier.navigationBarsPadding().imePadding())
            // When what is inside changes (a page swaps, a row appears, a list loads) the sheet grows or shrinks to its new height on a quick spring instead of jumping.
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium))
            .padding(horizontal = 20.dp, vertical = 14.dp)) {
            // The handle and the title. Holding them runs onTitleHold (the Home menu opens Customize menu, so the menu can always be changed, whatever it holds).
            Column(Modifier.fillMaxWidth().heightIn(min = 40.dp).then(if (onTitleHold != null) Modifier
                .pointerInput(Unit) { detectTapGestures(onLongPress = { haptics.confirm(); holdNow?.invoke() }) }
                .semantics { customActions = listOf(CustomAccessibilityAction("Customize menu") { holdNow?.invoke(); true }) } else Modifier)) {
                Box(Modifier.align(Alignment.CenterHorizontally).width(if (skin.floating) 36.dp else 40.dp).height(4.dp).clip(RoundedCornerShape(2.dp))
                    .background(if (skin.floating) Sb.mute.copy(alpha = .35f) else Sb.line))
                val titleAlign = if (skin.centerTitle) TextAlign.Center else TextAlign.Start
                if (showTitle) Text(title, Modifier.then(if (skin.centerTitle) Modifier.fillMaxWidth() else Modifier).asHeading().padding(top = 14.dp, bottom = if (subtitle == null) 4.dp else 0.dp),
                    fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = skin.titleSize, textAlign = titleAlign)
                if (subtitle != null) Text(subtitle, Modifier.then(if (skin.centerTitle) Modifier.fillMaxWidth() else Modifier).padding(top = 2.dp, bottom = 6.dp),
                    fontSize = 14.sp, color = Sb.mute, textAlign = titleAlign)
            }
            Box(Modifier.weight(1f, fill = false)) {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    content()
                    // Room under the last row for the floating pill.
                    if (pill) Spacer(Modifier.height(84.dp))
                }
                if (pill && capsule != null) CapsuleButton(capsule, Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp), accent)
            }
            if (!pill && showButtons) {
                if (split) Row(Modifier.fillMaxWidth().padding(top = 14.dp), Arrangement.spacedBy(10.dp)) {
                    Text(cancelLabel, Modifier.weight(1f).clip(RoundedCornerShape(28.dp)).background(Sb.line.copy(alpha = .6f)).tap(cancelLabel, dismiss).padding(vertical = 16.dp),
                        color = Sb.ink, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp, maxLines = 1)
                    Text(doneLabel, Modifier.weight(1.5f).clip(RoundedCornerShape(28.dp)).background(fill.copy(alpha = if (enabled) 1f else .35f))
                        .tap(doneLabel) { if (enabled) (primary ?: dismiss)() }.padding(vertical = 16.dp),
                        color = onFill, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp, maxLines = 1)
                } else Text(doneLabel, Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(28.dp))
                    .background(if (soft) Sb.line.copy(alpha = .6f) else fill.copy(alpha = if (enabled) 1f else .35f))
                    .tap(doneLabel) { if (enabled) (primary ?: dismiss)() }.padding(vertical = 16.dp),
                    color = if (soft) Sb.ink else onFill, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            }
            if (footer != null && skin.canFooter && opts.footer) Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 2.dp), Arrangement.Center, Alignment.CenterVertically) {
                Ic("lock", 14.dp, Sb.mute); Spacer(Modifier.width(6.dp))
                Text(footer, fontSize = 12.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Icons offered in the picker. Anything else can be typed in. */
private val SCRAP_ICONS = listOf("📝", "📌", "⭐", "💡", "🎯", "📚", "🔖", "💬", "🔗", "🖼️", "🎵", "🎬", "🍳", "🛒", "✈️", "🏠", "💼", "🎁", "🧠", "❤️", "🌱", "☕", "🔥", "✅", "📅", "💰", "🧩", "🎨", "🔒", "🌙")

@Composable
private fun IconCell(glyph: String, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(if (on) Sb.ink.copy(alpha = .1f) else Color.Transparent)
        .border(if (on) 2.dp else 0.dp, if (on) Sb.ink else Color.Transparent, RoundedCornerShape(14.dp))
        .tap(glyph.ifEmpty { "No icon" }, onClick).semantics { selected = on }, Alignment.Center) {
        if (glyph.isEmpty()) Ic("none", 22.dp, Sb.mute) else Text(glyph, fontSize = 22.sp)
    }
}

/** None, the ready-made icons, a cell for a custom one when it is in use, and a field to type or paste any emoji. */
@Composable
private fun IconPicker(current: String, onPick: (String) -> Unit) {
    val cells = listOf("") + (if (current.isNotBlank() && current !in SCRAP_ICONS) listOf(current) else emptyList()) + SCRAP_ICONS
    var typed by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        cells.chunked(6).forEach { row ->
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                row.forEach { g -> IconCell(g, g == current) { onPick(g) } }
                repeat(6 - row.size) { Spacer(Modifier.size(44.dp)) }
            }
        }
        InputBox {
            BasicTextField(typed, { v ->
                val g = firstGlyph(v.trim())
                if (g.isNotEmpty()) { onPick(g); typed = "" } else typed = v
            }, Modifier.fillMaxWidth(), singleLine = true, textStyle = TextStyle(fontSize = 16.sp, color = Sb.ink), cursorBrush = SolidColor(Sb.ink),
                decorationBox = { inner -> Box { if (typed.isEmpty()) Text("Or type any emoji", color = Sb.mute, fontSize = 16.sp); inner() } })
        }
    }
}

/** The pages of Page style: the list shows one row for each, and a row opens its page. */
private enum class StylePage(val title: String, val icon: String) {
    Glyph("Icon", "sparkle"), Tint("Page color", "palette"), Accent("Accent", "accent"), Cover("Cover image", "image"),
    Font("Type", "edit"), Spacing("Density", "list"), Category("Kind", "page"), Visible("Show", "eye"), Format("Layout", "layout")
}

private val TINT_NAMES = listOf("Plain", "Butter", "Sage", "Blue", "Rose", "Lilac")
private val ACCENT_NAMES = listOf("App accent", "Coral", "Sage", "Blue", "Gold", "Violet")
private val FONT_NAMES = listOf("Theme", "Serif", "Sans", "Mono")
private val DENSITY_NAMES = listOf("Airy", "Cozy", "Compact")

/** A small round sample of a color (a crossed circle when there is none). */
@Composable
private fun Swatch(c: Color?) {
    Box(Modifier.size(20.dp).clip(CircleShape).then(if (c != null) Modifier.background(c) else Modifier).border(1.dp, Sb.line, CircleShape), Alignment.Center) {
        if (c == null) Ic("none", 14.dp, Sb.mute)
    }
}

/** One line of the Page style list: icon, name, what it is now (a sample and/or a word in grey) and a chevron. */
@Composable
private fun StyleRow(p: StylePage, value: String, onClick: () -> Unit, sample: (@Composable () -> Unit)? = null) {
    Row(Modifier.pressScale(.98f).fillMaxWidth().heightIn(min = 58.dp).tap(p.title, onClick).padding(horizontal = 18.dp, vertical = 8.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Ic(p.icon, 24.dp, Sb.ink)
        Text(p.title, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        if (sample != null) sample()
        if (value.isNotEmpty()) Text(value, Modifier.widthIn(max = 150.dp), fontSize = 14.sp, color = Sb.mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Ic("chevron", 18.dp, Sb.mute)
    }
}

/** A list of choices on a page of their own: one row each, the current one checked. */
@Composable
private fun Choices(labels: List<String>, current: Int, subs: List<String?> = emptyList(), onPick: (Int) -> Unit) {
    SheetGroup {
        labels.forEachIndexed { i, l ->
            if (i > 0) SheetDivider()
            OptionRow(l, i == current, subs.getOrNull(i)) { onPick(i) }
        }
    }
}

/**
 * Per-page style, in pages: the first shows what each part of the page's look is now, and a tap on one opens a page with only that (icon, color, accent,
 * cover, type, density, kind, what shows; the layout again once there is more than one). Back (the button, or the phone's) returns to the list. Saved on the item itself.
 * The editor keeps its own copy of the page color (it is part of its undo), so it passes [color] and [onColor] and the color goes through it.
 */
@Composable
fun CustomizeSheet(item: Item, vm: ArchiveViewModel, onDone: () -> Unit, color: Int = item.color, onColor: ((Int) -> Unit)? = null, kind: Kind = item.kind, onKind: ((Kind) -> Unit)? = null) {
    var at by rememberSaveable { mutableStateOf("") }
    val page = StylePage.entries.firstOrNull { it.name == at && (it != StylePage.Format || Layout.entries.size > 1) }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) vm.importImage(u) { p -> vm.items.value.firstOrNull { it.id == item.id }?.let { cur -> vm.save(cur.copy(cover = p)) } }
    }
    fun setColor(c: Int) { if (onColor != null) onColor(c) else vm.save(item.copy(color = c)) }
    fun setKind(k: Kind) { if (onKind != null) onKind(k) else vm.save(item.copy(kind = k)) }
    Sheet(page?.title ?: "Page style", onDone, doneLabel = if (page == null) "Done" else "Back", primary = if (page == null) null else ({ at = "" }),
        subtitle = if (page == null) "Changes only this page" else "Page style", showCancel = if (page == null) null else false) {
        // Registered after the sheet's own Back (which closes it), so while a page is open Back goes to the list first.
        BackHandler(page != null) { at = "" }
        AnimatedContent(page, Modifier.fillMaxWidth(), transitionSpec = {
            val forward = targetState != null
            (fadeIn(tween(200, delayMillis = 60)) + slideInHorizontally(tween(240)) { if (forward) it / 8 else -it / 8 }) togetherWith
                (fadeOut(tween(100)) + slideOutHorizontally(tween(240)) { if (forward) -it / 8 else it / 8 })
        }, label = "stylePage") { p ->
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (p) {
                    null -> {
                        val tint = if (color <= 0) null else if (CustomColors.isCustom(color)) rgbColor(CustomColors.rgb(color)) else Sb.notes[(color - 1) % 5]
                        val tintName = if (CustomColors.isCustom(color)) "Custom" else TINT_NAMES[color.coerceIn(0, TINT_NAMES.lastIndex)]
                        val accentName = if (CustomColors.isCustom(item.accent)) "Custom" else ACCENT_NAMES[item.accent.coerceIn(0, ACCENT_NAMES.lastIndex)]
                        val shows = listOfNotNull("Metadata".takeIf { item.showMeta }, "Pinned".takeIf { item.pinned })
                        SheetGroup {
                            StyleRow(StylePage.Glyph, if (item.icon.isEmpty()) "None" else "", { at = StylePage.Glyph.name }, if (item.icon.isEmpty()) null else ({ Text(item.icon, fontSize = 20.sp) }))
                            SheetDivider(56.dp)
                            StyleRow(StylePage.Tint, tintName, { at = StylePage.Tint.name }, { Swatch(tint) })
                            SheetDivider(56.dp)
                            StyleRow(StylePage.Accent, accentName, { at = StylePage.Accent.name }, { Swatch(pageAccent(item.accent)) })
                            SheetDivider(56.dp)
                            StyleRow(StylePage.Cover, if (item.cover == null) "None" else "Added", { at = StylePage.Cover.name })
                        }
                        SheetGroup {
                            StyleRow(StylePage.Font, FONT_NAMES[item.font.coerceIn(0, FONT_NAMES.lastIndex)], { at = StylePage.Font.name })
                            SheetDivider(56.dp)
                            StyleRow(StylePage.Spacing, DENSITY_NAMES[item.density.coerceIn(0, DENSITY_NAMES.lastIndex)], { at = StylePage.Spacing.name })
                        }
                        SheetGroup {
                            StyleRow(StylePage.Category, kind.label, { at = StylePage.Category.name })
                            SheetDivider(56.dp)
                            StyleRow(StylePage.Visible, if (shows.isEmpty()) "Nothing" else shows.joinToString(", "), { at = StylePage.Visible.name })
                            if (Layout.entries.size > 1) {
                                SheetDivider(56.dp)
                                StyleRow(StylePage.Format, item.layout.label, { at = StylePage.Format.name })
                            }
                        }
                    }
                    StylePage.Glyph -> SheetGroup { Box(Modifier.padding(14.dp)) { IconPicker(item.icon) { g -> vm.save(item.copy(icon = g)) } } }
                    StylePage.Tint -> SheetGroup { Box(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) { ColorDots(color) { setColor(it) } } }
                    StylePage.Accent -> SheetGroup { Box(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) { AccentDots(item.accent) { vm.save(item.copy(accent = it)) } } }
                    StylePage.Cover -> SheetGroup {
                        ActionRow("image", if (item.cover == null) "Choose cover" else "Change cover") { pickCover.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                        if (item.cover != null) { SheetDivider(56.dp); ActionRow("close", "Remove cover") { vm.save(item.copy(cover = null)) } }
                    }
                    StylePage.Font -> Choices(FONT_NAMES, item.font, listOf("The same as the rest of the app")) { vm.save(item.copy(font = it)) }
                    StylePage.Spacing -> Choices(DENSITY_NAMES, item.density, listOf("The most room between lines", "The usual", "More on a page")) { vm.save(item.copy(density = it)) }
                    StylePage.Category -> Choices(Kind.entries.map { it.label }, kind.ordinal) { setKind(Kind.entries[it]) }
                    StylePage.Visible -> SheetGroup {
                        ToggleRow("eye", "Metadata", item.showMeta) { vm.save(item.copy(showMeta = it)) }
                        SheetDivider(56.dp)
                        ToggleRow("starline", "Pinned", item.pinned) { vm.togglePin(item) }
                    }
                    StylePage.Format -> Choices(Layout.entries.map { it.label }, item.layout.ordinal) { vm.setLayout(item.id, Layout.entries[it]) }
                }
            }
        }
    }
}

/** One line of the welcome sheet: an icon, a short title and a few words under it. */
@Composable
private fun WelcomeRow(icon: String, title: String, body: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), Arrangement.spacedBy(14.dp), Alignment.Top) {
        Ic(icon, 24.dp, Sb.ink)
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(body, fontSize = 14.sp, lineHeight = 20.sp, color = Sb.mute)
        }
    }
}

/** Shown once on first launch. */
@Composable
fun Welcome(onDone: () -> Unit, onExamples: () -> Unit) = Sheet("Welcome to Scrapbook", onDone, doneLabel = "Get started", subtitle = "Quick notes, tidy boxes.") {
    SheetGroup {
        WelcomeRow("edit", "Tap New scrap to start writing", "Select text to format it, and use the bar at the bottom for lists, quotes and checklists. It saves as you type.")
        SheetDivider(56.dp)
        WelcomeRow("layout", "Every page can change", "Give a page its own icon, color, type and spacing without losing a word.")
        SheetDivider(56.dp)
        WelcomeRow("sliders", "Make it yours", "Open the menu, then Settings, to restyle the app or back it up.")
    }
    SheetGroup { ActionRow("sparkle", "Add a few example scraps") { onExamples(); onDone() } }
}
