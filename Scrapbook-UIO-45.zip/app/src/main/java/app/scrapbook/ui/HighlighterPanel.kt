package app.scrapbook.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.CustomColors
import app.scrapbook.HighlightPrefs

/** The two tabs at the top of the toolbar's color panel: the color of the text, and the highlighter ("ab"). */
@Composable
fun ColorTabs(tab: Int, onTab: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(CircleShape).background(Sb.ink.copy(alpha = .07f)).padding(3.dp)) {
        listOf("Text", "Highlighter").forEachIndexed { i, n ->
            val on = i == tab
            Text(n, Modifier.weight(1f).clip(CircleShape).background(if (on) Sb.ink else Color.Transparent).tap(n) { onTab(i) }.semantics { selected = on }.padding(vertical = 9.dp),
                textAlign = TextAlign.Center, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (on) Sb.card else Sb.ink)
        }
    }
}

/**
 * The highlighter's panel (the second tab of the toolbar's color panel): a sample, the color (the page's accent, five ready colors or a color of your own) and how strong it is.
 * It changes the highlighter for the whole app, and every highlight in every scrap follows it, so a highlight that is too vivid can simply be made softer.
 * [onColor] gets 0 for the page's accent, 1 to 5 for a ready color, or a color of your own saved like page colors; [onOpacity] a strength from 25 to 100 percent.
 */
@Composable
fun HighlighterPanel(mk: Marker, onColor: (Int) -> Unit, onOpacity: (Int) -> Unit, tabs: @Composable () -> Unit) {
    val acc = LocalSb.current.acc
    val custom = CustomColors.isCustom(mk.color)
    var open by remember { mutableStateOf(custom) }              // the two color bars
    var live by remember { mutableStateOf<Int?>(null) }          // the color under a finger on the bars
    var level by remember { mutableFloatStateOf(HighlightPrefs.toSlider(mk.opacity)) }   // where the strength slider is while a finger drags it
    LaunchedEffect(mk.opacity) { if (HighlightPrefs.fromSlider(level) != mk.opacity) level = HighlightPrefs.toSlider(mk.opacity) }
    val shown = HighlightPrefs.fromSlider(level)
    val base = markerBase(acc, mk)
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().shadow(18.dp, shape, ambientColor = Color.Black, spotColor = Color.Black).clip(shape).background(Sb.menu).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        tabs()
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            val style = markerStyle(acc, Marker(mk.color, shown), Sb.menu)
            Text(buildAnnotatedString { append("A "); withStyle(style) { append("highlighted phrase") }; append(" in a line") }, Modifier.weight(1f), fontSize = 16.sp, color = Sb.ink)
            if (mk != Marker()) Text("Reset", Modifier.clip(CircleShape).tap("Reset the highlighter") { open = false; live = null; level = 1f; onColor(0); onOpacity(HighlightPrefs.DEFAULT_OPACITY) }.padding(horizontal = 10.dp, vertical = 8.dp),
                fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Sb.mute)
        }
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            val acOn = mk.color <= 0
            Box(Modifier.size(34.dp).clip(CircleShape).background(markerBase(acc)).border(if (acOn) 2.5.dp else 1.dp, if (acOn) Sb.ink else Sb.line, CircleShape)
                .tapIcon(HighlightPrefs.NAMES[0]) { open = false; live = null; onColor(0) }.semantics { selected = acOn }, Alignment.Center) { Ic(if (acOn) "check" else "accent", 18.dp, MARKER_INK) }
            HighlightPrefs.PRESETS.forEachIndexed { i, rgb ->
                val on = mk.color == i + 1
                Box(Modifier.size(34.dp).clip(CircleShape).background(rgbColor(rgb)).border(if (on) 2.5.dp else 1.dp, if (on) Sb.ink else Sb.line, CircleShape)
                    .tapIcon(HighlightPrefs.NAMES[i + 1]) { open = false; live = null; onColor(i + 1) }.semantics { selected = on }, Alignment.Center) { if (on) Ic("check", 18.dp, MARKER_INK) }
            }
            RgbDot(live ?: if (custom) CustomColors.rgb(mk.color) else null, { if (!custom) onColor(CustomColors.encode(CustomColors.START_RGB)); open = !open || !custom }, checkColor = MARKER_INK)
        }
        AnimatedVisibility(open, enter = fadeIn(tween(160)) + expandVertically(tween(200)), exit = fadeOut(tween(120)) + shrinkVertically(tween(160))) {
            RgbSliders(if (custom) CustomColors.rgb(mk.color) else null, { live = it }, { onColor(CustomColors.encode(it)) })
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text("Strength", fontSize = 12.sp, color = Sb.mute)
                Text("$shown%", fontSize = 12.sp, color = Sb.mute)
            }
            GradientSlider(level, Brush.horizontalGradient(listOf(base.copy(alpha = HighlightPrefs.MIN_OPACITY / 100f), base.copy(alpha = 1f))), base.copy(alpha = 1f),
                { v -> level = v; val p = HighlightPrefs.fromSlider(v); if (p != mk.opacity) onOpacity(p) }, { })
        }
    }
}
