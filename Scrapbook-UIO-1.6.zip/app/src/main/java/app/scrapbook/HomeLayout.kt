package app.scrapbook

/**
 * The parts of the Home page that can be moved and hidden. [key] is what is saved, so never rename one; [label] is what Customize home shows.
 * The order of the entries here is the default order of the page.
 */
enum class HomeElement(val key: String, val label: String) {
    Header("header", "Header"),
    Greeting("greeting", "Greeting"),
    Capture("capture", "Quick capture"),
    Continue("continue", "Continue"),
    Sort("sort", "To sort"),
    Boxes("boxes", "Boxes"),
    Pinned("pinned", "Pinned"),
    Recent("recent", "Recent");

    companion object {
        fun of(key: String): HomeElement? = entries.firstOrNull { it.key == key }
    }
}

/**
 * Which parts Home shows and in what order, top to bottom. [order] always holds every part once (hidden ones keep their place, so showing a part again
 * puts it back where it was); [hidden] are the ones that are switched off. Nothing here touches Android, so the rules are tested on their own (HomeLayoutTest).
 */
data class HomeLayout(
    val order: List<HomeElement> = HomeElement.entries.toList(),
    val hidden: Set<HomeElement> = emptySet(),
) {
    fun isHidden(e: HomeElement): Boolean = e in hidden

    /** The parts that are shown, in order. */
    val shown: List<HomeElement> get() = order.filter { it !in hidden }

    /** Moves the part at [from] to position [to]. Anything outside the list changes nothing. */
    fun move(from: Int, to: Int): HomeLayout {
        if (from == to || from !in order.indices || to !in order.indices) return this
        val list = order.toMutableList()
        list.add(to, list.removeAt(from))
        return copy(order = list)
    }

    fun withHidden(e: HomeElement, hide: Boolean): HomeLayout = copy(hidden = if (hide) hidden + e else hidden - e)

    fun encodeOrder(): String = order.joinToString(",") { it.key }
    fun encodeHidden(): String = encodeHidden(hidden)

    companion object {
        val Default = HomeLayout()

        /** The saved order. Unknown names and repeats are dropped, and any part that is missing (one added by a newer version) goes at the end. */
        fun decodeOrder(s: String?): List<HomeElement> {
            val seen = LinkedHashSet<HomeElement>()
            s.orEmpty().split(',').forEach { k -> HomeElement.of(k.trim())?.let { seen.add(it) } }
            HomeElement.entries.forEach { seen.add(it) }
            return seen.toList()
        }

        /** The saved set of hidden parts; unknown names are dropped. */
        fun decodeHidden(s: String?): Set<HomeElement> =
            s.orEmpty().split(',').mapNotNull { HomeElement.of(it.trim()) }.toSet()

        /** Hidden parts in the default order, so the saved text does not depend on the order they were switched off in. */
        fun encodeHidden(set: Set<HomeElement>): String = HomeElement.entries.filter { it in set }.joinToString(",") { it.key }
    }
}
