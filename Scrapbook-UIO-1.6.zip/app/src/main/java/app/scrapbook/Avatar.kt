package app.scrapbook

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File

/**
 * The profile picture. A picked photo is cropped to a centered square, turned upright (cameras often store photos sideways and add a note saying so),
 * made 512 pixels wide and saved as avatar_<time>.jpg in the app's own storage. The name starts with "avatar_" on purpose: clearing out unused
 * photos only touches files named img_ or imp_, so the picture is never swept away with them.
 */
object Avatar {
    const val PREFIX = "avatar_"
    private const val SIZE = 512

    /** Saves the photo at [uri] and returns the address of the new file, or null when it could not be read. Run on a background thread. */
    fun save(ctx: Context, uri: Uri): String? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        // Decode at a size that is not much bigger than needed, so a 50 megapixel photo does not fill the phone's memory.
        var sample = 1
        while (minOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= SIZE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val src = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val rotation = cr.openInputStream(uri)?.use { input ->
            runCatching {
                when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }.getOrDefault(0f)
        } ?: 0f
        val side = minOf(src.width, src.height)
        val matrix = Matrix().apply { postRotate(rotation); val k = SIZE.toFloat() / side; postScale(k, k) }
        val out = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side, matrix, true)
        val file = File(ctx.filesDir, "$PREFIX${System.currentTimeMillis()}.jpg")
        file.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        if (out !== src) src.recycle()
        out.recycle()
        return Uri.fromFile(file).toString()
    }

    /** Deletes the file behind an address saved by [save]. Anything not named avatar_ is left alone. */
    fun delete(address: String?) {
        val path = address?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it).path } ?: return
        val f = File(path)
        if (f.name.startsWith(PREFIX)) f.delete()
    }
}
