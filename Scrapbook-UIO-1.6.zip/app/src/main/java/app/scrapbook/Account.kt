package app.scrapbook

/**
 * The person using the app: a name, a picture and a few things about them. It lives only on this phone (in the settings store, the picture as a file in the
 * app's own storage) and is used for the greeting on Home. Nothing here touches Android, so the rules are tested on their own (AccountTest).
 */
data class Account(
    /** What you are called, as you would write it ("John", "John Smith"). Blank until you set it. */
    val name: String = "",
    /** Optional: greetings use this instead of the first word of [name]. */
    val nickname: String = "",
    /** A line or two about you. */
    val about: String = "",
    /** Optional, shown as written ("he/him", "they/them"). */
    val pronouns: String = "",
    /** Birthday without a year: month 1 to 12 and day 1 to 31, or 0 when not set. */
    val birthMonth: Int = 0,
    val birthDay: Int = 0,
    /** The picture, as the address of a file in the app's storage, or null. */
    val avatarUri: String? = null,
    /** The color behind the initial when there is no picture: an index into [AVATAR_COLORS], or -1 for the app accent. */
    val avatarColor: Int = -1,
    /** False only in the first moments after the app starts, before the saved account has been read. */
    val loaded: Boolean = true,
) {
    /** What greetings call you: the nickname, otherwise the first word of the name, otherwise nothing. */
    val callName: String get() = nickname.trim().ifEmpty { name.trim().substringBefore(' ') }

    val hasName: Boolean get() = callName.isNotEmpty()
    val hasBirthday: Boolean get() = birthMonth in 1..12 && birthDay in 1..31

    /** The letter shown on the avatar when there is no picture. */
    val initial: String get() = callName.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString().orEmpty()

    /** True on the day of the birthday. [month] is 1 to 12. A 29 February birthday is celebrated on 28 February in years that have none. */
    fun isBirthday(month: Int, day: Int, leapYear: Boolean): Boolean {
        if (!hasBirthday) return false
        if (birthMonth == 2 && birthDay == 29 && !leapYear) return month == 2 && day == 28
        return birthMonth == month && birthDay == day
    }

    companion object {
        const val MAX_NAME = 40
        const val MAX_ABOUT = 140
        const val MAX_PRONOUNS = 24

        /** How many days each month has (February counted with 29, so a leap-day birthday can be picked). */
        val DAYS_IN_MONTH = intArrayOf(31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        val MONTH_NAMES = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")

        /** Single line, no more than [max] characters. What a field accepts as you type. */
        fun clean(s: String, max: Int): String = s.replace('\n', ' ').replace('\r', ' ').take(max)

        /** The about text keeps its line breaks (at most two) but is capped the same way. */
        fun cleanAbout(s: String): String = s.replace("\r", "").take(MAX_ABOUT).lines().take(2).joinToString("\n")

        fun isLeap(year: Int): Boolean = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0

        /** A month and day that can exist (29 February is allowed). */
        fun validBirthday(month: Int, day: Int): Boolean = month in 1..12 && day in 1..DAYS_IN_MONTH[month - 1]
    }
}

/** The colors the initial avatar can have besides the app accent. Stored as an index, so keep the order. */
val AVATAR_COLORS = longArrayOf(0xFFF26B4E, 0xFF3DB8B3, 0xFFE0A02C, 0xFF7C6CF0, 0xFF4CB57A, 0xFFE8709A, 0xFF4A90E2, 0xFF6B6B6B)
