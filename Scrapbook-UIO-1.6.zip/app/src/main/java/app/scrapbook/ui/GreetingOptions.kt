package app.scrapbook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scrapbook.*

// The options of the greeting, opened from the Greeting row in Customize home (the sliders button). They used to be a page in Settings; every part of Home is meant to
// keep its own options here, next to where it is moved and hidden. The rows are the same ones Settings uses. The preview stays on top while the rest scrolls,
// so a slider can be seen working. Showing or hiding the greeting is the eye on its row in Customize home, so there is no switch for it here.

@Composable
fun GreetingOptions(vm: ArchiveViewModel, onBack: () -> Unit) {
    val account by vm.account.collectAsState()
    val greet by vm.greetingPrefs.collectAsState()
    val scraps by vm.items.collectAsState()
    var picker by remember { mutableStateOf<String?>(null) }
    // While a size slider is being dragged the preview follows it before anything is saved; afterwards it simply equals the saved size.
    var liveText by remember { mutableStateOf<Int?>(null) }
    var livePic by remember { mutableStateOf<Int?>(null) }
    BackHandler { onBack() }

    val picks = mapOf(
        "tone" to SettingPick("Greeting tone", GreetingPrefs.TONES, greet.tone.coerceIn(0, 3), note = "Mixed uses all three voices. The others stick to their own.") { vm.setGreetingPrefs(greet.copy(tone = it)) },
        "every" to SettingPick("Change greeting every", GreetingPrefs.EVERY.map { if (it == 0) "Never" else "$it seconds" }, GreetingPrefs.EVERY.indexOf(greet.everySec).coerceAtLeast(0),
            note = "A new greeting also appears each time Home opens, and whenever you tap it.") { vm.setGreetingPrefs(greet.copy(everySec = GreetingPrefs.EVERY[it])) },
        "sub" to SettingPick("Line under the greeting", GreetingPrefs.SUBS, greet.sub.coerceIn(0, 3)) { vm.setGreetingPrefs(greet.copy(sub = it)) },
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 20.dp, top = 12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                CircleBtn("Back to Customize home", onBack) { Ic("back", 22.dp, Sb.ink) }
                Text("Greeting", Modifier.weight(1f).asHeading(), fontFamily = headFont(), fontWeight = FontWeight.Medium, fontSize = 28.sp, letterSpacing = (-0.4).sp)
            }
            Spacer(Modifier.height(10.dp))
            SettingsCard {
                Box(Modifier.fillMaxWidth().padding(vertical = 14.dp)) {
                    GreetingHub(account, greet.copy(textSize = liveText ?: greet.textSize, picSize = livePic ?: greet.picSize), scraps.size, 0, scraps.count { it.pinned }, onProfile = {})
                }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
                SectionLabel("Look")
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsCard { SliderRow("headsize", "Text size", liveText ?: greet.textSize, GreetingPrefs.TEXT_MIN..GreetingPrefs.TEXT_MAX, { liveText = it }) { liveText = it; vm.setGreetingPrefs(greet.copy(textSize = it)) } }
                    SettingsCard { SliderRow("image", "Picture size", livePic ?: greet.picSize, GreetingPrefs.PIC_MIN..GreetingPrefs.PIC_MAX, { livePic = it }) { livePic = it; vm.setGreetingPrefs(greet.copy(picSize = it)) } }
                    SettingsCard { SwitchRow("person", "Show my picture", greet.avatar) { vm.setGreetingPrefs(greet.copy(avatar = it)) } }
                    SettingsCard { IconRow("list", "Line under the greeting", GreetingPrefs.SUBS[greet.sub.coerceIn(0, 3)]) { picker = "sub" } }
                }
                SectionLabel("Changing")
                SettingsCard { IconRow("clock", "Change greeting every", GreetingPrefs.EVERY.indexOf(greet.everySec).let { if (it <= 0) "Never" else "${greet.everySec} seconds" }) { picker = "every" } }
                Footer("Tap the greeting on Home to see another one right away.")
                SectionLabel("Greeting lines")
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsCard { IconRow("sparkle", "Greeting tone", GreetingPrefs.TONES[greet.tone.coerceIn(0, 3)]) { picker = "tone" } }
                    SettingsCard { SwitchRow("clock", "Time of day and weekdays", greet.time) { vm.setGreetingPrefs(greet.copy(time = it)) } }
                    SettingsCard { SwitchRow("sparkle", "Casual lines", greet.casual) { vm.setGreetingPrefs(greet.copy(casual = it)) } }
                    SettingsCard { SwitchRow("tag", "Lines about your scraps", greet.notes) { vm.setGreetingPrefs(greet.copy(notes = it)) } }
                }
                Footer("Your birthday, set on the Account page, always gets its own greeting.")
            }
        }
        picker?.let { key -> picks[key]?.let { PickerSheet(it) { picker = null } } }
    }
}

@Composable
private fun Footer(text: String) {
    Text(text, Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp), fontSize = 12.sp, color = Sb.mute)
}
